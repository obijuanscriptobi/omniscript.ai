# Discovery funnel QA checklist

Run this checklist in local-only mode and again after signing in with a selected cloud project.

## End-to-end flow

1. Submit a valid public HTTPS URL and valid email.
2. Confirm one CRM lead, audit result, and follow-up action appear.
3. Submit the same URL and email again; confirm the existing lead is updated, not duplicated.
4. Use the audit result booking form with a future date.
5. Confirm the appointment has the lead ID and the lead contains:
   - `meeting.provider: "native"`
   - `meeting.externalId` equal to the appointment ID
   - `meeting.scheduledAt` equal to the appointment time
   - `meeting.status: "booked"`
6. Confirm the lead stage is `discovery`, owner is assigned, and a booking activity/task exists.
7. Refresh the audit page and Leads page. Confirm all state remains.
8. Reschedule the appointment and confirm the lead meeting time changes.
9. Cancel it, then verify it cannot be rescheduled or booked again.
10. Repeat with a second appointment and mark it completed; verify it cannot be rescheduled.
11. Create a proposal draft and edit services, total, validity date, pricing, discovery notes, and objections.
12. Preview it, then progress through `draft`, `sent`, `viewed`, `negotiating`, and either `accepted` or `declined`.
13. Refresh and confirm proposal values, timestamps, and revision history remain.

## Validation and fallback cases

- Past booking time is rejected.
- Invalid booking email is rejected.
- A second active booking for the same lead is rejected after refresh.
- Queued/provider-unavailable audits say queued, have no fabricated score, and remain eligible for booking when contact details are valid.
- Cloud failure retains local appointments and leads without losing the lead-to-appointment ID link. The appointment is marked `syncStatus: "pending"`, records `syncAttemptAt` and `syncError`, and can be retried from Leads.
- After a simulated cloud failure, refresh, sign in/select the project, and use **Sync pending appointments**. Confirm one cloud appointment is created and the local record becomes `syncStatus: "synced"`.
- Cloud mode creates the appointment with the cloud lead UUID in `appointments.lead_id`, then stores the cloud appointment UUID in local `meeting.externalId`.
- Retry the same pending appointment twice; confirm the server returns the existing appointment and no duplicate is created.
- Pending cancelled or completed appointments are not recreated as active cloud appointments.
- Proposal delivery remains disabled; no public proposal URL or email is generated during QA.
- Cloud mode does not permit another user/project to access the appointment.

## Security gates before proposal delivery

Proposal delivery is intentionally not enabled yet. Before adding it, require server-side authorization, expiring random tokens, server-side status transitions, rate limiting, and audit logging. Do not put private lead data in proposal URLs.

## Record defects

For each failure capture: page, mode (local/cloud), input, expected result, actual result, browser console error, and whether refresh changes the result.
