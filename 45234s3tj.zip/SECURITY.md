# Security policy

## Supported version

Only the current default-branch release is supported with security updates.

## Reporting a vulnerability

Do not open a public issue for a suspected vulnerability and do not include credentials, access tokens, personal data, or customer content in a report.

Use the repository's **Security → Report a vulnerability** form so the maintainers can investigate privately. Include the affected URL or component, impact, reproduction steps using synthetic data, and any redacted request ID. Allow a reasonable remediation period before public disclosure.

If private vulnerability reporting is unavailable, contact the repository owner privately and provide only enough information to establish a secure reporting channel.
