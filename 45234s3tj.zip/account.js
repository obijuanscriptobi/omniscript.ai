"use strict";
(() => {
    const $ = (id) => document.getElementById(id);
    const PROFILE_KEY = "morrow-account-profile-v1";
    let avatarData = "";

    function readProfile() { try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || "{}"); } catch { return {}; } }
    function saveProfile(profile) {
        try {
            localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
        } catch (_) {
            return false;
        }
        window.dispatchEvent(new CustomEvent("omniscript:profile-updated", { detail: profile }));
        return true;
    }

    function renderProfile() {
        const profile = readProfile();
        avatarData = profile.avatar || "";
        $("account-username").value = profile.username || "";
        $("account-display-name").value = profile.displayName || "";
        renderProfilePreview(profile);
    }

    function renderProfilePreview(profile = readProfile()) {
        const avatar = $("avatar-preview");
        avatar.textContent = avatarData ? "" : (profile.displayName || profile.username || "?").trim().slice(0, 1).toUpperCase();
        avatar.style.backgroundImage = avatarData ? `url("${avatarData.replace(/"/g, "%22")}")` : "";
        avatar.classList.toggle("has-image", Boolean(avatarData));
    }

    function renderAuth() {
        const state = window.supabaseWorkspace?.getState?.() || {};
        const signedIn = Boolean(state.authenticated);
        $("account-state").classList.toggle("signed-in", signedIn);
        $("account-state").dataset.state = signedIn ? "signed-in" : "signed-out";
        $("account-state").innerHTML = `<i aria-hidden="true"></i>${signedIn ? "Signed in" : "Not signed in"}`;
        $("signed-out-panel").hidden = signedIn;
        $("signed-in-panel").hidden = !signedIn;
        if (signedIn) $("signed-in-email").textContent = state.user?.email || "Account connected";
    }

    function setStatus(message, error = false) {
        const status = $("auth-status");
        status.textContent = message;
        status.dataset.state = error ? "error" : "success";
    }

    async function providerSignIn(provider) {
        const api = window.supabaseWorkspace;
        if (!api?.signInWithProvider) return setStatus("Cloud sign-in is unavailable right now. Please try again.", true);
        try { await api.signInWithProvider(provider); }
        catch (error) { setStatus(error.message || "Social sign-in could not be started.", true); }
    }

    async function emailAuth(create = false) {
        const email = $("account-email").value.trim();
        const password = $("account-password").value;
        const api = window.supabaseWorkspace;
        try {
            if (!api) throw new Error("Cloud sign-in is still loading. Try again in a moment.");
            if (!email || !password) throw new Error("Enter your email address and password.");
            const action = create ? api.signUp : api.signIn;
            if (typeof action !== "function") throw new Error("Email authentication is unavailable right now.");
            await action.call(api, email, password);
            renderAuth();
            const signedIn = Boolean(api.getState?.().authenticated);
            setStatus(create ? (signedIn ? "Account created and signed in." : "Account created. Check your email to confirm it.") : (signedIn ? "Signed in successfully." : "Check your email and password, then try again."), !create && !signedIn);
        } catch (error) { setStatus(error.message || "Authentication failed.", true); }
    }

    function renderOperatingMode() {
        const mode = window.operatingMode?.get?.() || "self";
        document.querySelectorAll("[data-account-mode]").forEach((button) => {
            const active = button.dataset.accountMode === mode;
            button.setAttribute("aria-checked", String(active));
            button.classList.toggle("is-selected", active);
        });
        $("account-show-all-tools").checked = window.operatingMode?.getShowAllTools?.() || false;
    }

    function bind() {
        renderProfile(); renderAuth(); renderOperatingMode();
        document.querySelectorAll("[data-account-mode]").forEach((button) => button.addEventListener("click", () => {
            const changed = window.operatingMode?.set?.(button.dataset.accountMode, { source: "account" });
            renderOperatingMode();
            $("account-mode-status").textContent = changed === false ? "Mode change cancelled; your current workspace is unchanged." : "Workspace preference saved. Existing work and data are unchanged.";
        }));
        $("account-show-all-tools")?.addEventListener("change", (event) => {
            window.operatingMode?.setShowAllTools?.(event.target.checked, { source: "account" });
            $("account-mode-status").textContent = event.target.checked ? "All tools will remain visible." : "Tools will be prioritized for your selected mode.";
        });
        $("avatar-input").addEventListener("change", () => {
            const file = $("avatar-input").files?.[0];
            if (!file) return;
            if (!["image/png", "image/jpeg", "image/webp"].includes(file.type.toLowerCase())) return setStatus("Choose a JPG, PNG, or WEBP image.", true);
            if (file.size > 2 * 1024 * 1024) return setStatus("That profile picture is larger than 2 MB.", true);
            const reader = new FileReader();
            reader.onload = () => { avatarData = String(reader.result || ""); renderProfilePreview(); };
            reader.onerror = () => setStatus("That profile picture could not be read.", true);
            reader.readAsDataURL(file);
        });
        $("remove-avatar-btn").addEventListener("click", () => { avatarData = ""; $("avatar-input").value = ""; renderProfilePreview(); });
        $("identity-form").addEventListener("submit", (event) => {
            event.preventDefault();
            const profile = { username: $("account-username").value.trim().replace(/^@+/, ""), displayName: $("account-display-name").value.trim(), avatar: avatarData };
            if (!profile.username) { $("identity-status").textContent = "Choose a username first."; return; }
            if (!saveProfile(profile)) {
                $("identity-status").textContent = "Profile could not be saved because browser storage is unavailable.";
                return;
            }
            $("identity-status").textContent = "Profile saved."; renderProfile();
        });
        document.querySelectorAll("[data-provider]").forEach((button) => button.addEventListener("click", () => providerSignIn(button.dataset.provider)));
        $("email-auth-form").addEventListener("submit", (event) => { event.preventDefault(); emailAuth(false); });
        $("create-account-btn").addEventListener("click", () => emailAuth(true));
        $("password-toggle").addEventListener("click", () => {
            const input = $("account-password"); const showing = input.type === "text";
            input.type = showing ? "password" : "text"; $("password-toggle").textContent = showing ? "Show" : "Hide";
            $("password-toggle").setAttribute("aria-label", showing ? "Show password" : "Hide password");
        });
        $("sign-out-btn").addEventListener("click", async () => { await window.supabaseWorkspace?.signOut?.(); renderAuth(); setStatus("Signed out."); });
        window.addEventListener("supabase:authenticated", () => { renderAuth(); setStatus("Signed in successfully."); });
        window.addEventListener("supabase:unauthenticated", renderAuth);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
