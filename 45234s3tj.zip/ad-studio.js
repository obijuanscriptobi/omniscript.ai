"use strict";

// Original, editable ad workspace. It uses broad observations only and never copies source creative.
(() => {
    const FORMAT_META = {
        square: { label: "1:1 Square", ratio: "1 / 1", width: 1080, height: 1080, className: "format-square" },
        feed: { label: "4:5 Portrait", ratio: "4 / 5", width: 1080, height: 1350, className: "format-feed" },
        story: { label: "9:16 Vertical", ratio: "9 / 16", width: 1080, height: 1920, className: "format-story" },
        search: { label: "Search ad", ratio: "auto", width: 1200, height: 628, className: "format-search" },
        display: { label: "Display banner", ratio: "3 / 1", width: 1200, height: 400, className: "format-display" },
        email: { label: "Email promotion", ratio: "auto", width: 1200, height: 800, className: "format-email" }
    };
    const ANGLES = ["outcome", "trust", "offer"];
    const workContext = () => window.workspaceContext?.current?.() || { id: "own-business", mode: window.operatingMode?.get?.() || "own" };
    const saveKey = () => `morrow-ad-studio-draft-v4-${window.workspaceContext?.namespace?.() || `${window.operatingMode?.get?.() || "own"}:own-business`}`;
    const get = (id) => typeof document !== "undefined" ? document.getElementById(id) : null;
    const clamp = (number, min, max) => Math.max(min, Math.min(max, Number(number) || 0));
    const layerDefaults = (concept, format = "square") => {
        const meta = FORMAT_META[format] || FORMAT_META.square;
        return [
            { id: "image", type: "image", content: "", x: 0, y: 0, width: meta.width, height: meta.height, opacity: 1, visible: true, locked: false, crop: { x: .5, y: .5, scale: 1 } },
            { id: "logo", type: "logo", content: "", x: 64, y: 64, width: 150, height: 70, opacity: 1, visible: true, locked: false },
            { id: "headline", type: "text", content: concept.headline, x: 72, y: meta.height * .43, width: meta.width - 144, height: meta.height * .18, fontSize: Math.max(34, meta.width * .065), color: "#ffffff", fontWeight: 900, visible: true, locked: false },
            { id: "supportingCopy", type: "text", content: concept.supportingCopy, x: 72, y: meta.height * .62, width: meta.width - 144, height: meta.height * .12, fontSize: Math.max(18, meta.width * .025), color: "#e5e7eb", fontWeight: 400, visible: true, locked: false },
            { id: "offer", type: "text", content: concept.offer, x: 72, y: meta.height * .76, width: meta.width - 144, height: 60, fontSize: Math.max(18, meta.width * .028), color: "#d4af37", fontWeight: 800, visible: true, locked: false },
            { id: "callToAction", type: "button", content: concept.callToAction, x: 72, y: meta.height * .84, width: 300, height: 72, fontSize: Math.max(18, meta.width * .025), color: "#111827", background: "#d4af37", fontWeight: 900, visible: true, locked: false }
        ];
    };
    const ensureLayers = (concept) => { if (!concept.layers?.length) concept.layers = layerDefaults(concept.concept, concept.format); return concept.layers; };
    const layerSchema = (concept) => ({ version: 1, format: concept.format, dimensions: { width: FORMAT_META[concept.format]?.width || 1080, height: FORMAT_META[concept.format]?.height || 1080 }, layers: ensureLayers(concept), background: concept.background || { color: "#1b2945", overlay: "#08111d66", gradient: true } });
    const value = (id) => get(id)?.value?.trim() || "";
    const selected = (id, fallback) => value(id) || fallback;
    const clean = (text, fallback = "") => String(text ?? fallback).replace(/[<>]/g, "").trim();
    const defaultState = () => ({ version: 4, patternProfile: null, concepts: [], selectedIndex: 0, history: [], future: [], approved: false, assets: { hero: null, logo: null }, brandKit: { colors: ["#d4af37", "#17233b"], font: "Inter", tone: "clear", approvedClaims: [], forbiddenClaims: [] }, websiteSource: null, status: "Draft" });

    function websiteBusinessFrom(value) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return null;
        const candidates = [value.form?.business, value.profile, value.business, value.form?.businessDetails, value.project?.business, value.data?.business];
        return candidates.find((candidate) => candidate && typeof candidate === "object") || null;
    }

    function readWebsiteBusiness() {
        if (typeof localStorage === "undefined") return null;
        const target = workContext();
        const keys = [
            window.workspaceContext?.storageKey?.("luxury-engine-workspace", target),
            window.workspaceContext?.storageKey?.("morrow-live-project-context-v1", target),
            "morrow-live-project-context-v1"
        ].filter(Boolean);
        for (const key of keys) {
            try {
                const parsed = JSON.parse(localStorage.getItem(key));
                const contextId = parsed?.workContextId || parsed?.workspaceContext?.id || parsed?.projectContext?.workContextId;
                if (target.mode === "client" && contextId !== target.id) continue;
                if (target.mode === "own" && contextId && contextId !== target.id) continue;
                const business = websiteBusinessFrom(parsed) || parsed?.business;
                if (business && typeof business === "object") return { key, business };
            } catch (_) {}
        }
        return null;
    }

    function websiteValue(business, ...keys) {
        return keys.map((key) => business?.[key]).find((item) => String(item || "").trim()) || "";
    }

    function importWebsiteDetails({ announce = true } = {}) {
        const source = readWebsiteBusiness();
        if (!source) {
            if (announce) get("ad-studio-status") && (get("ad-studio-status").textContent = "No saved website details found. Complete the Website maker brief first.");
            return false;
        }
        const business = source.business;
        const fields = {
            "ad-studio-name": websiteValue(business, "name"),
            "ad-studio-offer": websiteValue(business, "pricing", "hook", "differentiator", "services"),
            "ad-studio-audience": websiteValue(business, "audience"),
            "ad-studio-location": websiteValue(business, "location", "address"),
            "ad-studio-cta": websiteValue(business, "primaryCta", "booking"),
            "ad-studio-proof": websiteValue(business, "testimonial", "credentials", "experience")
        };
        Object.entries(fields).forEach(([id, text]) => { const field = get(id); if (field && text && !field.value.trim()) field.value = clean(text); });
        const colors = [business.color, business.secondaryColor].filter((color) => /^#[0-9a-f]{3,8}$/i.test(String(color || "")));
        state.brandKit = { ...state.brandKit, colors: colors.length ? colors : state.brandKit.colors, tone: business.contentTone || state.brandKit.tone };
        state.websiteSource = { key: source.key, importedAt: new Date().toISOString(), fields: Object.keys(fields).filter((id) => fields[id]) };
        if (business.heroImageUrl && !state.assets.hero) state.assets.hero = { name: "Website hero image", sourceUrl: business.heroImageUrl, rightsConfirmed: false, alt: business.logoAlt || "" };
        if (business.logoUrl && !state.assets.logo) state.assets.logo = { name: "Website logo", sourceUrl: business.logoUrl, rightsConfirmed: false, alt: business.logoAlt || "" };
        persist();
        render();
        if (announce) get("ad-studio-status") && (get("ad-studio-status").textContent = "Website details imported. Review the offer, claims, and asset rights before generating.");
        return true;
    }
    let state = defaultState();
    let selectedLayer = "headline";
    let drag = null;
    let pendingProjectContext = null;
    let lastProjectContextRevision = "";
    let persistTimer = null;
    const editSessions = new Set();

    function projectContextBrief(context) {
        const business = context?.business || {};
        return {
            name: business.name || "", offer: business.pricing || business.hook || business.differentiator || business.services || "",
            audience: business.audience || "", location: business.location || "", cta: business.primaryCta || business.booking || "",
            proof: business.testimonial || business.credentials || business.experience || "", tone: business.contentTone || "clear",
            color: business.color || "", secondaryColor: business.secondaryColor || "", logoUrl: business.logoUrl || "", heroImageUrl: business.heroImageUrl || ""
        };
    }

    function showProjectUpdate(context) {
        const target = workContext();
        if (!context?.business || (context.operatingMode && context.operatingMode !== target.mode) || (context.workContextId && context.workContextId !== target.id)) return;
        const revision = `${context.projectId || "project"}:${context.updatedAt || ""}`;
        if (revision === lastProjectContextRevision) return;
        lastProjectContextRevision = revision;
        pendingProjectContext = context;
        const panel = get("live-project-update"), text = get("live-project-update-text");
        if (panel) panel.hidden = false;
        if (text) text.textContent = `Updated ${new Date(context.updatedAt || Date.now()).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}. Locked or manually edited ad fields will stay unchanged.`;
    }

    function refreshFromProjectContext() {
        const brief = projectContextBrief(pendingProjectContext);
        if (!brief.name && !brief.offer) return;
        const fields = { "ad-studio-name": brief.name, "ad-studio-offer": brief.offer, "ad-studio-audience": brief.audience, "ad-studio-location": brief.location, "ad-studio-cta": brief.cta, "ad-studio-proof": brief.proof };
        Object.entries(fields).forEach(([id, next]) => { const field = get(id); if (field && next) field.value = clean(next); });
        const projectColors = [brief.color, brief.secondaryColor].filter((color) => /^#[0-9a-f]{3,8}$/i.test(color));
        state.brandKit = { ...state.brandKit, colors: projectColors.length ? projectColors : state.brandKit.colors, tone: brief.tone || state.brandKit.tone };
        if (brief.heroImageUrl && !state.assets.hero) state.assets.hero = { name: "Website hero image", sourceUrl: brief.heroImageUrl, rightsConfirmed: false, alt: "" };
        if (brief.logoUrl && !state.assets.logo) state.assets.logo = { name: "Website logo", sourceUrl: brief.logoUrl, rightsConfirmed: false, alt: "" };
        state.websiteSource = { type: "live-project-context", projectId: pendingProjectContext.projectId || "local-project", importedAt: pendingProjectContext.updatedAt || new Date().toISOString(), fields: Object.keys(fields).filter((id) => fields[id]) };
        pendingProjectContext = null;
        const panel = get("live-project-update"); if (panel) panel.hidden = true;
        persist(); render();
        const status = get("ad-studio-status"); if (status) status.textContent = "Live website details refreshed. Locked ad content was preserved; regenerate concepts when ready.";
    }

    function analyzePatterns({ references = "", industry = "", channel = "display", audience = "", goal = "leads" } = {}) {
        const text = String(references).toLowerCase();
        const find = (items, fallback) => items.find((item) => text.includes(item)) || fallback;
        const layout = find(["split-screen", "split screen", "testimonial", "comparison", "carousel", "image-led", "image led"], channel === "search" ? "proof-led" : "image-led");
        const angle = find(["urgency", "urgent", "trust", "testimonial", "convenience", "aspiration", "premium"], "trust");
        const words = String(references).trim().split(/\s+/).filter(Boolean).length;
        const length = words > 45 ? "long-form" : words > 15 ? "medium" : "concise";
        const profile = {
            type: "aggregated pattern analysis", industry: industry || "general business", channel, audience, goal,
            layoutPattern: layout, emotionalAngle: angle, hierarchy: text.includes("cta") ? ["headline", "proof", "offer", "cta"] : ["headline", "benefit", "proof", "cta"], textLength: length,
            layout: { type: layout, confidence: references ? 0.72 : 0.38, evidence: references ? "Inferred from authorized observations provided by the user." : "Default category pattern; no source evidence supplied." },
            message: { angle, hierarchy: text.includes("cta") ? ["headline", "proof", "offer", "cta"] : ["headline", "benefit", "proof", "cta"], copyLength: length },
            visual: { contrast: text.includes("low contrast") ? "soft" : "high", imageRole: text.includes("image") ? "hero" : "supporting", density: text.includes("airy") || text.includes("space") ? "airy" : "balanced" },
            suitability: { channel, audience: audience || "not specified", goal },
            evidence: { observed: references ? ["user-supplied category observations"] : [], performance: [], assumptions: ["Public visibility or longevity does not prove conversion performance."], recommendations: ["Use owned or licensed assets and a visibly different composition."] },
            visualGuidance: "Use a distinct composition, licensed imagery, and brand-owned typography and colors.",
            sourceRestrictions: "Observations only; no source copy, assets, logos, targeting, or distinctive trade dress are reused."
        };
        return profile;
    }

    function validateBrief(brief = {}) {
        const offer = clean(brief.offer || brief.hook), audience = clean(brief.audience), cta = clean(brief.cta);
        const checks = [["Offer clarity", offer.length >= 8 ? "Strong" : "Needs detail", offer.length >= 8], ["Audience clarity", audience.length >= 5 ? "Strong" : "Needs detail", audience.length >= 5], ["One clear action", cta ? "Strong" : "Needs detail", Boolean(cta)], ["Benefit clarity", offer.length >= 14 ? "Strong" : "Needs detail", offer.length >= 14], ["Credible proof", brief.proof ? "Strong" : "Missing", Boolean(brief.proof)], ["Claim safety", "Review required", false]];
        return { score: checks.filter((item) => item[2]).length, total: checks.length, checks, ready: checks[0][2] && checks[1][2] };
    }

    function generateConcept({ business = {}, goal = "leads", audience = "your ideal customers", patternProfile = {}, format = "square", angle = "outcome", tone = "clear", proof = "process", color = "#d4af37" } = {}) {
        const name = clean(business.name || business.industry, "Your business"), offer = clean(business.campaignOffer || business.offer || business.hook || business.services, "a better way to get the result you need"), action = clean(business.cta) || (goal === "booking" ? "Book your first conversation" : goal === "sales" ? "Explore the collection" : goal === "awareness" ? "See what makes us different" : "Get your tailored next step");
        const headline = angle === "trust" ? `${name}: choose with confidence.` : angle === "offer" ? `A simpler way to ${offer.toLowerCase()}.` : `${offer}—made simpler for ${audience}.`;
        const support = proof === "testimonial" && business.proof ? clean(business.proof) : `${name} brings a clear, thoughtful process to ${audience} who want dependable results without the guesswork.`;
        const strategy = angle === "trust" ? { tension: "Needs confidence before taking action", promise: "Makes the decision feel considered", risk: "Proof must be verified", test: "Compare against an outcome-led message" } : angle === "offer" ? { tension: "Wants a clear reason to act now", promise: "Makes the value easy to understand", risk: "Avoid unsupported urgency", test: "Compare against a trust-led message" } : { tension: "Wants a better result without disruption", promise: "Simplifies the next step", risk: "Benefit may be too broad", test: "Compare against a trust-led message" };
        const conceptData = { headline, supportingCopy: support, offer: clean(business.offer || offer), callToAction: action, visualDirection: `Original ${angle}-led composition with ${patternProfile.emotionalAngle || "trust"} energy. Use ${proof} as supporting proof and a distinct ${tone} visual system.`, layoutPattern: FORMAT_META[format]?.label || format, assetRequirements: ["user-provided or licensed image", "brand logo only if owned", "original typography and color treatment"], color };
        const result = { id: `${angle}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, channel: patternProfile.channel || "display", format, angle, tone, locked: {}, concept: conceptData, campaign: { name: business.campaignName || "website-campaign", service: business.offer || "", destination: campaignDestination(business), landingPage: business.landingPage || "", cta: action, leadForm: { enabled: true, action: "quote-request" }, followUpMessage: `Thanks for asking about ${business.offer || "this service"}. We will follow up with the next useful step.`, utmSource: business.utmSource || "morrow", utmMedium: business.utmMedium || "campaign", budget: business.budget || "", startDate: business.startDate || "", endDate: business.endDate || "", approvalState: "draft" },
            campaignPath: `This campaign promotes “${business.offer || "your selected service"}”, sends visitors to ${business.landingPage || "the matching landing page"}, and records quote requests.`, source: { websiteConnected: Boolean(business.name || business.offer), contentOrigin: "business brief plus generated suggestion", approvalRequired: true }, strategy, sourceInfluence: { type: "aggregated pattern analysis", copiedText: false, copiedAssets: false, copiedBranding: false, copiedLayout: false }, evidence: { observed: patternProfile.evidence?.observed || [], performance: [], assumptions: ["This concept is a creative hypothesis, not a performance prediction."], recommendations: ["Review for accidental similarity before publishing."] }, disclaimer: "This original concept uses broad category patterns. Performance is not guaranteed; review claims, rights, and similarity before publishing." };
        result.layers = layerDefaults(conceptData, format);
        result.background = { color: "#1b2945", overlay: "#08111d66", gradient: true };
        return result;
    }

    function generateVariants({ business = {}, goal = "leads", audience = "your ideal customers", patternProfile = {}, format = "square", tone = "clear", proof = "process", color = "#d4af37" } = {}) { return ANGLES.map((angle) => generateConcept({ business, goal, audience, patternProfile, format, tone, proof, color, angle })); }
    function validateOriginality(concept, references = "") {
        const source = concept?.sourceInfluence || {}, text = String(references).toLowerCase(), flags = [];
        if (/\b(logo|slogan|copyright|competitor|brand name)\b/.test(text)) flags.push("Review source branding or competitor references.");
        if (/\b\d+%|\$\d+|#1|best|guaranteed|award-winning\b/.test(concept?.concept?.headline + " " + concept?.concept?.supportingCopy)) flags.push("Verify statistics, rankings, guarantees, and superlative claims.");
        const valid = Boolean(concept?.concept?.headline) && !source.copiedText && !source.copiedAssets && !source.copiedBranding && !source.copiedLayout;
        return { valid, checks: [["Original copy", !source.copiedText], ["Original or licensed assets", !source.copiedAssets], ["No copied branding", !source.copiedBranding], ["Distinct composition", !source.copiedLayout]], warnings: flags, warning: "Review this concept for accidental similarity. This is not legal clearance." };
    }
    function qualityScore(concept, brief = {}, format = concept?.format || "square") {
        const c = concept?.concept || {}, proof = Boolean(brief.proof), fields = [["Offer clarity", Boolean(c.offer), "Add a specific customer result or offer."], ["Audience relevance", String(brief.audience || "").length >= 5, "Define who this is for."], ["Message clarity", String(c.headline).length >= 10 && String(c.headline).length <= 120, "Keep the headline specific and scannable."], ["Visual hierarchy", Boolean(c.headline && c.callToAction), "Add a headline and one clear CTA."], ["CTA strength", String(c.callToAction).length >= 3, "Use one concrete next action."], ["Proof quality", proof, "Add an approved review, demonstration, or remove unsupported proof."], ["Claim safety", !/\bguaranteed|#1|best|100%\b/i.test(`${c.headline} ${c.supportingCopy}`), "Verify or remove unsupported claims."], ["Platform fit", String(c.headline).length <= (format === "search" ? 60 : 160), "Shorten the text for this format."], ["Distinctiveness", validateOriginality(concept).valid, "Review similarity and source influence."], ["Accessibility", Boolean(c.headline && c.callToAction), "Maintain readable hierarchy and contrast."]];
        return { score: fields.filter((x) => x[1]).length, total: fields.length, checks: fields.map(([label, pass, fix]) => ({ label, status: pass ? "Strong" : "Needs work", pass, reason: pass ? "Meets the current workspace check." : fix, fix })) };
    }
    function platformOutputs(concept, channel = concept?.channel || "display") { const c = concept?.concept || {}; if (channel === "search") return { headlines: [c.headline, c.callToAction, c.offer].map((x) => ({ text: x || "", characters: String(x || "").length })), descriptions: [{ text: c.supportingCopy || "", characters: String(c.supportingCopy || "").length }], keywordTheme: "Review against approved search terms.", policyWarnings: [] }; if (channel === "email") return { subjectLine: c.headline, previewText: String(c.supportingCopy || "").slice(0, 90), heroHeadline: c.headline, bodyCopy: c.supportingCopy, cta: c.callToAction, plainText: `${c.headline}\n\n${c.supportingCopy}\n\n${c.callToAction}` }; return { primaryText: c.supportingCopy, headline: c.headline, description: c.offer, cta: c.callToAction, format: FORMAT_META[concept?.format || "square"]?.label || "Creative asset", imageDimensions: FORMAT_META[concept?.format || "square"] ? `${FORMAT_META[concept.format].width}×${FORMAT_META[concept.format].height}` : "Review format" }; }
    function assetChecklist() { return { logo: state.assets.logo ? "uploaded" : "not provided", heroImage: state.assets.hero ? "user-provided" : "placeholder — upload or license an image", imageRights: state.assets.hero?.rightsConfirmed ? "confirmed" : "confirmation required", altText: state.assets.hero?.alt || "required before publishing", claims: "review required" }; }
    function validateBrand(concept, brandKit = state.brandKit) { const text = Object.values(concept?.concept || {}).join(" ").toLowerCase(); const forbidden = (brandKit.forbiddenClaims || []).filter((claim) => text.includes(String(claim).toLowerCase())); const unsupported = /\b(guaranteed|#1|best|award-winning|100%)\b/i.test(text); const color = concept?.concept?.color || ""; return { valid: !forbidden.length && !unsupported, issues: [...forbidden.map((claim) => `Forbidden claim: ${claim}`), ...(unsupported ? ["Unsupported guarantee, ranking, or superlative claim."] : []), ...(color && !(brandKit.colors || []).includes(color) ? ["Color is outside the saved brand palette."] : [])] }; }
    function duplicateConcept() { const concept = state.concepts[state.selectedIndex]; if (!concept) return null; pushHistory(); const copy = JSON.parse(JSON.stringify(concept)); copy.id = `${copy.angle}-copy-${Date.now()}`; state.concepts.splice(state.selectedIndex + 1, 0, copy); state.selectedIndex += 1; state.approved = false; render(); return copy; }
    function exportData(format = "json") { const concept = state.concepts[state.selectedIndex]; if (!concept) return null; if (format === "text") return platformOutputs(concept, concept.channel); const target = workContext(); return { version: 4, exportedAt: new Date().toISOString(), operatingMode: target.mode, workContext: { id: target.id, name: target.name, projectName: target.projectName, approvalContact: target.approvalContact || "" }, handoff: target.mode === "client" ? { permissionsConfirmed: Boolean(target.permissionsConfirmed), assetRightsConfirmed: Boolean(target.assetRightsConfirmed), approvalRequired: true } : null, status: state.status, source: { type: state.websiteSource ? "website-maker-project" : "ad-studio-brief", importedAt: state.websiteSource?.importedAt || null, fields: state.websiteSource?.fields || [] }, brief: readBrief(), concept, canvas: layerSchema(concept), platform: platformOutputs(concept, concept.channel), quality: qualityScore(concept, readBrief()), assets: assetChecklist(), brandKit: state.brandKit, brandReview: validateBrand(concept), originality: validateOriginality(concept, value("ad-studio-references")), disclaimer: concept.disclaimer }; }
    function download(data, filename, type) { if (typeof Blob === "undefined" || typeof document === "undefined" || !document.createElement) return; const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob([data], { type })); link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 0); }
    function exportPlatformPackage() {
        const gate = window.workspaceContext?.clientGate?.("assets");
        if (gate && !gate.allowed) {
            const status = get("approval-status") || get("ad-studio-status");
            if (status) status.textContent = `Export blocked: ${gate.message}`;
            return;
        }
        const output = exportData("json");
        if (!output) return;
        output.exportType = "platform-package";
        output.platforms = ["google", "meta", "youtube", "tiktok"].map((platform) => ({ platform, status: "export-ready", publishing: "manual platform upload required", creative: output.platform, policyReview: "required" }));
        output.assetProcessing = { sourceAsset: state.assets.hero?.name || null, mediaType: state.assets.hero?.mediaType || "none", videoExport: state.assets.hero?.mediaType === "video" ? "source clip included; encoded publish file requires a media pipeline" : "not applicable" };
        download(JSON.stringify(output, null, 2), "omniscript-ad-platform-package.json", "application/json");
    }
    function persist() {
        try {
            if (typeof localStorage !== "undefined") localStorage.setItem(saveKey(), JSON.stringify(state));
        } catch (_) {}
    }

    function schedulePersist() {
        clearTimeout(persistTimer);
        persistTimer = setTimeout(() => {
            persistTimer = null;
            persist();
        }, 180);
    }

    function beginEdit(key) {
        if (!editSessions.has(key)) {
            pushHistory();
            editSessions.add(key);
        }
    }

    function finishEdit(key) {
        editSessions.delete(key);
        persist();
    }

    const BRIEF_FIELD_MAP = { name: "ad-studio-name", offer: "ad-studio-offer", audience: "ad-studio-audience", location: "ad-studio-location", cta: "ad-studio-cta", proof: "ad-studio-proof", campaignOffer: "ad-studio-offer-detail", landingPage: "ad-studio-landing-page", campaignName: "ad-studio-campaign-name", utmSource: "ad-studio-utm-source", utmMedium: "ad-studio-utm-medium", budget: "ad-studio-budget", startDate: "ad-studio-start-date", endDate: "ad-studio-end-date" };
    function restoreBrief(brief = state.brief) { Object.entries(BRIEF_FIELD_MAP).forEach(([key, id]) => { const field = get(id); if (field && brief?.[key] && !field.value) field.value = brief[key]; }); }
    function restore() { try { if (typeof localStorage !== "undefined") { const scoped = localStorage.getItem(saveKey()); const legacyKey = `morrow-ad-studio-draft-v4-${window.operatingMode?.get?.() || "own"}`; const legacy = workContext().mode === "own" ? localStorage.getItem(legacyKey) : null; const saved = JSON.parse(scoped || legacy || "null"); if (!scoped && legacy) localStorage.setItem(saveKey(), legacy); if (saved?.concepts || saved?.brief) state = { ...defaultState(), ...saved, history: [], future: [] }; } } catch (_) {} }
    function canonicalProfile() {
        const service = window.profileService;
        const stateProfile = window.workspaceAPI?.getState?.()?.businessProfile;
        const raw = stateProfile || service?.readLocal?.();
        return raw && service?.normalize ? service.normalize(raw) : null;
    }

    function populateProfileServices() {
        const select = get("ad-studio-offer");
        const profile = canonicalProfile();
        if (!select || !profile) return;
        const current = select.value;
        select.replaceChildren(new Option("Choose a service from your Business profile", ""));
        (profile.services || []).forEach((service) => select.append(new Option(service, service)));
        (profile.offers || []).filter((offer) => offer.status !== "inactive" && offer.name).forEach((offer) => select.append(new Option(offer.name, offer.name)));
        if (current) select.value = current;
    }

    function readBrief() {
        const profile = canonicalProfile();
        const identity = profile?.identity || {};
        const brand = profile?.brand || {};
        const offer = profile?.offers?.find((item) => item.status !== "inactive") || {};
        const location = profile?.locations?.[0] || {};
        const launch = profile?.metadata?.launchBrief || {};
        const claim = profile?.claims?.find((item) => item.state === "approved" && item.surfaces.includes("ads"));
        return {
            operatingMode: window.operatingMode?.get?.() || "own",
            name: value("ad-studio-name") || identity.displayName,
            offer: value("ad-studio-offer") || value("ad-studio-offer-custom") || offer.description || offer.name || profile?.services?.[0] || "",
            audience: value("ad-studio-audience") || launch.audience,
            location: value("ad-studio-location") || launch.location || [location.city, location.region].filter(Boolean).join(", "),
            goal: selected("ad-studio-goal", "leads"),
            cta: value("ad-studio-cta") || (launch.goal === "booking" ? "Book an appointment" : launch.goal === "call" ? "Call the business" : launch.goal === "email" ? "Send an enquiry" : "Request a quote"),
            proof: value("ad-studio-proof") || launch.proof || claim?.text || "",
            tone: selected("ad-studio-tone", brand.voice || brand.tone?.[0] || state.brandKit.tone || "clear"),
            format: selected("format-select", "square"),
            color: value("ad-studio-color") || brand.primaryColor || state.brandKit.colors[0],
                        businessDetails: { phone: value("ad-studio-phone") || identity.phone, pricing: value("ad-studio-pricing") || offer.price, website: value("ad-studio-website") || identity.website },
            campaignOffer: value("ad-studio-offer-detail"),
            landingPage: value("ad-studio-landing-page") || value("ad-studio-website") || identity.website || "",
            campaignName: value("ad-studio-campaign-name"),
            utmSource: value("ad-studio-utm-source") || "morrow",
            utmMedium: value("ad-studio-utm-medium") || "campaign",
            budget: value("ad-studio-budget"),
            startDate: value("ad-studio-start-date"),
            endDate: value("ad-studio-end-date")
        };
    }

    function campaignDestination(brief) {
        const destination = String(brief?.landingPage || brief?.businessDetails?.website || "").trim();
        if (!destination) return "";
        try {
            const url = new URL(destination, window.location.origin);
            ["utm_source", "utm_medium", "utm_campaign", "utm_content"].forEach((key) => url.searchParams.delete(key));
            url.searchParams.set("utm_source", brief.utmSource || "morrow");
            url.searchParams.set("utm_medium", brief.utmMedium || "campaign");
            url.searchParams.set("utm_campaign", brief.campaignName || "website-campaign");
            url.searchParams.set("utm_content", state.concepts[state.selectedIndex]?.angle || "concept");
            return url.href;
        } catch (_) { return ""; }
    }

    function renderLaunchGate() {
        const status = get("launch-gate-status");
        const list = get("launch-gate-results");
        const concept = state.concepts[state.selectedIndex];
        if (!status || !list) return;
        if (!concept) {
            status.textContent = "Generate a concept to see launch requirements.";
            return;
        }
        const brief = readBrief();
        const quality = qualityScore(concept, brief, concept.format);
        const destination = campaignDestination(brief);
        const datesValid = !brief.startDate || !brief.endDate || brief.startDate <= brief.endDate;
        const checks = [
            ["Brief complete", validateBrief(brief).ready, "Add an offer, audience, and primary CTA."],
            ["One clear goal", Boolean(brief.goal), "Choose the campaign goal."],
            ["Destination configured", Boolean(destination), "Add a landing page to create a tracked destination."],
            ["Schedule valid", datesValid, "The campaign end date must be on or after the start date."],
            ["Quality review", quality.score >= Math.ceil(quality.total * .7), "Resolve the highest-impact quality warnings."],
            ["Claims reviewed", validateBrand(concept).valid, "Remove unsupported or forbidden claims."],
            ["Asset rights confirmed", !state.assets.hero || Boolean(state.assets.hero.rightsConfirmed), "Confirm that the hero image is owned or licensed."],
            ["Alt text supplied", !state.assets.hero || Boolean(state.assets.hero.alt), "Add descriptive alt text or remove the image."],
            ["Human approval", state.approved, "Approve the selected concept after reviewing it."]
        ];
        const passed = checks.filter((item) => item[1]).length;
        status.textContent = `${passed}/${checks.length} launch checks passed. This is technical readiness evidence, not a conversion guarantee.`;
        list.replaceChildren(...checks.map(([label, pass, detail]) => {
            const item = document.createElement("li");
            item.innerHTML = `<b>${label}</b><span class="${pass ? "check-good" : "check-warn"}">${pass ? "Ready" : "Needs attention"}</span><small>${pass ? "Passed for this workspace." : detail}</small>`;
            return item;
        }));
    }

    function renderMessageConsistency() {
        const status = get("message-consistency-status");
        const list = get("message-consistency-results");
        const concept = state.concepts[state.selectedIndex];
        if (!status || !list) return;
        if (!concept) { status.textContent = "Generate a concept to compare the campaign with the website message."; return; }
        const brief = readBrief();
        const website = window.businessHub?.read?.() || {};
        const checks = [
            ["Customer outcome", !website.hook || !brief.offer || brief.offer.toLowerCase().includes(String(website.hook).toLowerCase().slice(0, 18)), "Keep the ad promise aligned with the website outcome."],
            ["Primary CTA", !website.primaryCta || !brief.cta || brief.cta.toLowerCase() === String(website.primaryCta).toLowerCase(), "Review the CTA so the destination offers the same next step."],
            ["Audience", !website.audience || !brief.audience || brief.audience.toLowerCase().includes(String(website.audience).toLowerCase().split(" ")[0]), "Confirm the ad and website speak to the same audience."],
            ["Destination tracking", Boolean(campaignDestination(brief)), campaignDestination(brief) ? campaignDestination(brief) : "Add a landing page to create a measurable destination."],
            ["Approved claims", !website.forbiddenClaims?.some?.((claim) => JSON.stringify(concept.concept).toLowerCase().includes(String(claim).toLowerCase())), "Remove or review wording that conflicts with claims to avoid."]
        ];
        const passed = checks.filter((item) => item[1]).length;
        status.textContent = `${passed}/${checks.length} alignment checks passed. Review suggestions before approval; this is not performance evidence.`;
        list.replaceChildren(...checks.map(([label, pass, detail]) => { const item = document.createElement("li"); item.innerHTML = `<b>${label}</b><span class="${pass ? "check-good" : "check-warn"}">${pass ? "Aligned" : "Review"}</span><small>${detail}</small>`; return item; }));
    }

    async function assertAdPublishable() {
        const profile = canonicalProfile();
        if (!profile || !window.profileService?.assertPublishable) return true;
        try {
            await window.profileService.assertPublishable(profile, "ads", { actor: "ad-studio" });
            return true;
        } catch (error) {
            const status = get("approval-status") || get("ad-studio-status");
            if (status) status.textContent = error.issues?.[0]?.remediation || error.message;
            return false;
        }
    }
    function snapshot() { return JSON.stringify(state.concepts); }
    function pushHistory() { state.history.push(snapshot()); if (state.history.length > 30) state.history.shift(); state.future = []; }
    function render() {
        const concept = state.concepts[state.selectedIndex]; if (!concept) return; const c = concept.concept, preview = get("ad-visual-preview");
        ensureLayers(concept); if (preview) { const previewVideo = get("ad-preview-video"); if (previewVideo) { previewVideo.hidden = state.assets.hero?.mediaType !== "video"; if (state.assets.hero?.mediaType === "video") { previewVideo.src = state.assets.hero.dataUrl; previewVideo.play().catch(() => {}); } else { previewVideo.removeAttribute("src"); previewVideo.pause(); } } preview.style.setProperty("--ad-accent", c.color || state.brandKit.colors[0]); preview.style.setProperty("--ad-font", state.brandKit.font); preview.className = `ad-visual-preview ${FORMAT_META[concept.format]?.className || ""}`; preview.dataset.format = concept.format; preview.style.backgroundColor = concept.background?.color || "#1b2945"; preview.style.backgroundImage = state.assets.hero?.dataUrl ? `linear-gradient(90deg,${concept.background?.overlay || "#08111d66"},transparent),url(${state.assets.hero.dataUrl})` : concept.background?.gradient ? "linear-gradient(145deg,#526d9d,#1b2945 55%,#a55e3b)" : "none"; }
        ["headline", "supportingCopy", "offer", "callToAction"].forEach((key) => { const el = get(`edit-${key}`); if (el && document.activeElement !== el) el.value = c[key] || ""; const layer = ensureLayers(concept).find((item) => item.id === key); const visual = preview?.querySelector(`[data-layer="${key}"]`); if (visual && layer) { visual.textContent = layer.content; visual.style.left = `${layer.x / (FORMAT_META[concept.format].width || 1080) * 100}%`; visual.style.top = `${layer.y / (FORMAT_META[concept.format].height || 1080) * 100}%`; visual.style.width = `${layer.width / (FORMAT_META[concept.format].width || 1080) * 100}%`; visual.style.fontSize = `${Math.max(.7, layer.fontSize / (FORMAT_META[concept.format].width || 1080) * 100)}cqw`; visual.classList.toggle("layer-selected", selectedLayer === key); } });
        const activeLayer = ensureLayers(concept).find((layer) => layer.id === selectedLayer); const widthInput = get("layer-width"), heightInput = get("layer-height"); if (widthInput && activeLayer) widthInput.value = Math.round(activeLayer.width); if (heightInput && activeLayer) heightInput.value = Math.round(activeLayer.height); const layerList = get("layer-list"); if (layerList) layerList.innerHTML = ensureLayers(concept).slice().reverse().map((layer) => `<button type="button" class="${selectedLayer === layer.id ? "active" : ""}" data-layer-select="${layer.id}">${layer.visible === false ? "◌" : "●"} ${layer.id}${layer.locked ? " 🔒" : ""}</button>`).join("");
        const set = (id, text) => { const el = get(id); if (el) el.textContent = text; }; set("preview-headline", c.headline); set("preview-copy", c.supportingCopy); set("preview-offer", c.offer); set("preview-cta", c.callToAction); set("ad-result-channel", `${FORMAT_META[concept.format]?.label || concept.channel} / ${concept.angle}`.toUpperCase());
        set("strategy-angle", `${concept.angle}-led`); set("strategy-tension", concept.strategy?.tension); set("strategy-promise", concept.strategy?.promise); set("strategy-risk", concept.strategy?.risk); set("strategy-test", concept.strategy?.test);
        const q = qualityScore(concept, readBrief(), concept.format), quality = get("quality-list"); if (quality) quality.innerHTML = q.checks.map((x) => `<li><b>${x.label}</b><span class="${x.pass ? "check-good" : "check-warn"}">${x.status}</span><small>${x.pass ? x.reason : x.fix}</small></li>`).join(""); set("quality-score", `${q.score}/${q.total}`);
        const tabs = get("variant-list"); if (tabs) tabs.innerHTML = state.concepts.map((item, i) => `<button type="button" class="variant-card ${i === state.selectedIndex ? "selected" : ""}" data-variant="${i}"><b>${String(item.angle).toUpperCase()}-LED</b><span>${clean(item.concept.headline)}</span><small>${i === 0 ? "New audiences" : i === 1 ? "Trust-sensitive buyers" : "Warm audiences"}</small></button>`).join("");
        const briefScore = validateBrief(readBrief()), scoreEl = get("brief-score"); if (scoreEl) scoreEl.textContent = `${briefScore.score}/${briefScore.total}`; const checks = get("brief-checks"); if (checks) checks.innerHTML = briefScore.checks.map((x) => `<li><span>${x[0]}</span><strong class="${x[2] ? "check-good" : "check-warn"}">${x[1]}</strong></li>`).join("");
        const pattern = get("pattern-summary"); if (pattern && state.patternProfile) pattern.textContent = `${state.patternProfile.layoutPattern} · ${state.patternProfile.emotionalAngle} · ${state.patternProfile.message.copyLength} copy · observed patterns only`;         const source = get("website-source-status"); if (source) source.textContent = state.websiteSource ? `Business profile connected · ${state.websiteSource.fields.length} fields imported` : "Business profile not connected";
        const asset = get("asset-checklist"); if (asset) asset.innerHTML = Object.entries(assetChecklist()).map(([k, v]) => `<li><span>${k}</span><b>${v}</b></li>`).join("");
        const format = get("format-select"); if (format) format.value = concept.format; set("approval-status", state.approved ? "Approved for export. Review rights and claims again before publishing." : "Review claims, asset rights, and accidental similarity before approving."); renderLaunchGate();         set("ad-studio-result", `${c.headline}\n\n${c.supportingCopy}\n\nOFFER  ${c.offer}\nCTA  ${c.callToAction}\n\n${concept.campaignPath || "Campaign path will appear here."}\n\nFOLLOW-UP  ${concept.campaign?.followUpMessage || "Not configured"}\nTRACKING  ${concept.campaign?.destination || "Add a landing page"}\n\nVISUAL  ${c.visualDirection}\nFORMAT  ${FORMAT_META[concept.format]?.label || concept.format}\n\nORIGINALITY  Review required before publishing.`); renderMessageConsistency(); persist();
    }
    function currentStage() {
        const requested = new URLSearchParams(window.location.search).get("step");
        if (requested === "brief") return "make";
        if (requested === "concepts" || requested === "editor") return "preview";
        if (requested === "review") return "export";
        return state.concepts.length ? "preview" : "make";
    }
    function setStage(stage, { replace = false } = {}) {
        const next = ["make", "preview", "export"].includes(stage) ? stage : "make";
        document.body.dataset.adStage = next;
        document.querySelectorAll("[data-stage-link]").forEach((link) => {
            const active = link.dataset.stageLink === next;
            link.classList.toggle("active", active);
            link.setAttribute("aria-current", active ? "step" : "false");
        });
        const brief = get("brief-stage"), concepts = get("concepts-stage"), editor = get("editor-stage");
        if (brief) brief.hidden = next !== "make";
        if (concepts) concepts.hidden = next !== "preview";
        if (editor) {
            editor.hidden = next === "make";
            const controls = editor.querySelector(":scope > div:first-child");
            if (controls) controls.hidden = next === "export";
            const review = get("review-stage");
            if (review) review.hidden = next !== "export";
        }
        const url = `ad-studio.html?step=${next}`;
        if (replace) window.history.replaceState({}, "", url);
    }
    function goToStage(stage) { setStage(stage); window.scrollTo({ top: 0, behavior: "smooth" }); }
    function generate() { const target = workContext(); if (target.mode === "client" && !window.workspaceContext?.current?.()) { const status = get("ad-studio-status"); if (status) status.textContent = "Choose or create a client project before creating client work."; return; } const brief = readBrief(); state.brief = { ...brief, workContextId: target.id }; state.patternProfile = analyzePatterns({ references: value("ad-studio-references"), industry: brief.offer, channel: selected("ad-studio-channel", "display"), audience: brief.audience, goal: brief.goal }); state.concepts = generateVariants({ business: brief, goal: brief.goal, audience: brief.audience || "your ideal customers", patternProfile: state.patternProfile, format: brief.format, tone: brief.tone, proof: value("ad-studio-proof-type") || "process", color: brief.color }); state.selectedIndex = 0; state.approved = false; state.status = "Draft"; persist(); setStage("preview", { replace: false }); render(); const status = get("ad-studio-status"); if (status) status.textContent = "Three strategically different directions are ready. Choose one to continue."; }
    function updateField(key, newValue, { commit = false } = {}) {
        const concept = state.concepts[state.selectedIndex];
        if (!concept || concept.locked?.[key]) return;
        beginEdit(key);
        concept.concept[key] = clean(newValue);
        const layer = ensureLayers(concept).find((item) => item.id === key);
        if (layer) layer.content = concept.concept[key];
        state.approved = false;
        render();
        schedulePersist();
        if (commit) finishEdit(key);
    }
    function modifyLayer(action) { const concept = state.concepts[state.selectedIndex], layers = concept && ensureLayers(concept), index = layers?.findIndex((layer) => layer.id === selectedLayer); if (!layers || index < 0) return; pushHistory(); if (action === "layer-up" && index < layers.length - 1) [layers[index], layers[index + 1]] = [layers[index + 1], layers[index]]; if (action === "layer-down" && index > 0) [layers[index], layers[index - 1]] = [layers[index - 1], layers[index]]; if (action === "layer-hide") layers[index].visible = layers[index].visible === false; if (action === "layer-lock") layers[index].locked = !layers[index].locked; render(); }
    function startLayerDrag(event) { const target = event.target.closest("[data-layer]"); if (!target || target.dataset.layer === "logo" && !state.assets.logo) return; selectedLayer = target.dataset.layer; const concept = state.concepts[state.selectedIndex], layer = ensureLayers(concept).find((item) => item.id === selectedLayer); if (!layer || layer.locked) return; const rect = event.currentTarget.getBoundingClientRect(); drag = { rect, layer, startX: event.clientX, startY: event.clientY, x: layer.x, y: layer.y }; target.setPointerCapture?.(event.pointerId); render(); }
    function moveLayerDrag(event) { if (!drag) return; const scaleX = FORMAT_META[state.concepts[state.selectedIndex].format].width / drag.rect.width, scaleY = FORMAT_META[state.concepts[state.selectedIndex].format].height / drag.rect.height; drag.layer.x = clamp(drag.x + (event.clientX - drag.startX) * scaleX, 0, FORMAT_META[state.concepts[state.selectedIndex].format].width - drag.layer.width); drag.layer.y = clamp(drag.y + (event.clientY - drag.startY) * scaleY, 0, FORMAT_META[state.concepts[state.selectedIndex].format].height - drag.layer.height); render(); }
    function endLayerDrag() { if (drag) { drag = null; state.approved = false; render(); } }
    function moveLayerByKey(event) { if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) return; const concept = state.concepts[state.selectedIndex], layer = ensureLayers(concept).find((item) => item.id === selectedLayer); if (!layer || layer.locked) return; event.preventDefault(); pushHistory(); const step = event.shiftKey ? 10 : 1; layer.x += event.key === "ArrowRight" ? step : event.key === "ArrowLeft" ? -step : 0; layer.y += event.key === "ArrowDown" ? step : event.key === "ArrowUp" ? -step : 0; render(); }
    function regenerateField(key, mode = "rewrite") { const concept = state.concepts[state.selectedIndex]; if (!concept || concept.locked?.[key]) return; pushHistory(); const c = concept.concept; if (key === "headline") c.headline = mode === "shorten" ? c.headline.slice(0, 58) : mode === "premium" ? `A more considered way to ${c.offer.toLowerCase()}` : `Make ${c.offer.toLowerCase()} feel simpler.`; if (key === "supportingCopy") c.supportingCopy = mode === "local" && value("ad-studio-location") ? `${c.offer} for people in ${value("ad-studio-location")}, with a clear next step.` : `A clear, practical way for ${value("ad-studio-audience") || "your customers"} to move forward with confidence.`; if (key === "callToAction") c.callToAction = mode === "strong" ? "Get started today" : "Learn more"; const layer = ensureLayers(concept).find((item) => item.id === key); if (layer) layer.content = c[key]; state.approved = false; render(); }
    function bind() {
        restore(); restoreBrief(); populateProfileServices(); setStage(currentStage(), { replace: true }); if (!state.websiteSource && !value("ad-studio-name")) importWebsiteDetails({ announce: false });
        window.addEventListener("business-profile:updated", () => { populateProfileServices(); if (!value("ad-studio-name")) importWebsiteDetails({ announce: false }); });
        window.addEventListener("omniscript:operating-mode", () => window.location.reload());
        window.addEventListener("morrow:project-context", (event) => showProjectUpdate(event.detail));
        get("refresh-from-project-btn")?.addEventListener("click", refreshFromProjectContext);
        get("import-website-details-btn")?.addEventListener("click", () => importWebsiteDetails()); get("ad-studio-generate-btn")?.addEventListener("click", generate); get("ad-studio-analyze-btn")?.addEventListener("click", () => { state.patternProfile = analyzePatterns({ references: value("ad-studio-references"), industry: value("ad-studio-offer"), channel: selected("ad-studio-channel", "display"), audience: value("ad-studio-audience"), goal: selected("ad-studio-goal", "leads") }); render(); const el = get("ad-studio-status"); if (el) el.textContent = "Pattern notes classified as observations, assumptions, and recommendations—not performance proof."; });
        get("variant-list")?.addEventListener("click", (e) => { const b = e.target.closest("[data-variant]"); if (b) { state.selectedIndex = Number(b.dataset.variant); state.approved = false; persist(); setStage("preview"); render(); } });
        document.querySelectorAll("[data-stage-link]").forEach((link) => link.addEventListener("click", (event) => { const stage = link.dataset.stageLink; if (stage !== "make" && !state.concepts.length) { event.preventDefault(); const status = get("ad-studio-status"); if (status) status.textContent = "Start by telling us what you’re promoting."; setStage("make"); return; } event.preventDefault(); goToStage(stage); }));
        get("ad-studio-generate-btn")?.addEventListener("click", () => goToStage("preview"));
        get("continue-to-review-btn")?.addEventListener("click", () => goToStage("export"));
        ["headline", "supportingCopy", "offer", "callToAction"].forEach((key) => {
            const field = get(`edit-${key}`);
            field?.addEventListener("focus", () => beginEdit(key));
            field?.addEventListener("input", (e) => updateField(key, e.target.value));
            field?.addEventListener("blur", () => finishEdit(key));
            field?.addEventListener("change", () => finishEdit(key));
        });
        get("duplicate-btn")?.addEventListener("click", duplicateConcept); get("export-jpg-btn")?.addEventListener("click", () => exportPreview("jpg")); get("export-metadata-btn")?.addEventListener("click", () => download(JSON.stringify(exportData("json"), null, 2), "morrow-ad-metadata.json", "application/json"));
        get("layer-list")?.addEventListener("click", (e) => { const button = e.target.closest("[data-layer-select]"); if (button) { selectedLayer = button.dataset.layerSelect; render(); } });
        ["layer-width", "layer-height"].forEach((id) => get(id)?.addEventListener("input", (e) => { const concept = state.concepts[state.selectedIndex], layer = concept && ensureLayers(concept).find((item) => item.id === selectedLayer); if (!layer || layer.locked) return; pushHistory(); layer[id === "layer-width" ? "width" : "height"] = Math.max(20, Number(e.target.value) || 20); state.approved = false; render(); }));
        ["layer-up", "layer-down", "layer-hide", "layer-lock"].forEach((id) => get(id)?.addEventListener("click", () => modifyLayer(id)));
        get("ad-visual-preview")?.addEventListener("pointerdown", startLayerDrag); get("ad-visual-preview")?.addEventListener("pointermove", moveLayerDrag); get("ad-visual-preview")?.addEventListener("pointerup", endLayerDrag); get("ad-visual-preview")?.addEventListener("pointercancel", endLayerDrag); get("ad-visual-preview")?.addEventListener("keydown", moveLayerByKey);
        get("format-select")?.addEventListener("change", () => { pushHistory(); if (state.concepts[state.selectedIndex]) state.concepts[state.selectedIndex].format = value("format-select"); state.approved = false; render(); });
        get("undo-btn")?.addEventListener("click", () => { const previous = state.history.pop(); if (!previous) return; state.future.push(snapshot()); state.concepts = JSON.parse(previous); state.selectedIndex = Math.min(state.selectedIndex, state.concepts.length - 1); render(); }); get("redo-btn")?.addEventListener("click", () => { const next = state.future.pop(); if (!next) return; state.history.push(snapshot()); state.concepts = JSON.parse(next); render(); });
        get("lock-fields")?.addEventListener("click", (e) => { const b = e.target.closest("[data-lock]"); const c = state.concepts[state.selectedIndex]; if (b && c) { c.locked[b.dataset.lock] = !c.locked[b.dataset.lock]; b.classList.toggle("active", c.locked[b.dataset.lock]); b.textContent = `${c.locked[b.dataset.lock] ? "🔒" : "🔓"} ${b.dataset.lock}`; persist(); } });
        get("regenerate-tools")?.addEventListener("click", (e) => { const b = e.target.closest("[data-regenerate]"); if (b) regenerateField(b.dataset.regenerate, b.dataset.mode || "rewrite"); });
        get("approve-btn")?.addEventListener("click", () => { const target = workContext(); const contentGate = window.workspaceContext?.clientGate?.("content", target); const approvalGate = window.workspaceContext?.clientGate?.("approval", target); if (contentGate && !contentGate.allowed || approvalGate && !approvalGate.allowed) { const el = get("approval-status"); if (el) el.textContent = `Approval blocked: ${!contentGate?.allowed ? contentGate.message : approvalGate.message}`; return; } const review = validateBrand(state.concepts[state.selectedIndex]); if (!review.valid) { const el = get("approval-status"); if (el) el.textContent = `Approval blocked: ${review.issues.join(" ")}`; return; } state.approved = true; state.status = "Approved"; if (state.concepts[state.selectedIndex]) state.concepts[state.selectedIndex].campaign = { ...(state.concepts[state.selectedIndex].campaign || {}), approvalState: "approved", approvedAt: new Date().toISOString() }; render(); });         get("ad-studio-export-btn")?.addEventListener("click", async () => { if (!state.approved) { const el = get("approval-status"); if (el) el.textContent = "Approve the selected concept before exporting."; return; } if (!await assertAdPublishable()) return; download(JSON.stringify(exportData("json"), null, 2), "omniscript-ad-campaign.json", "application/json"); });
        get("ad-studio-export-btn")?.insertAdjacentHTML("afterend", "<button id=\"export-platform-package-btn\" class=\"ad-button secondary\" type=\"button\">Export platform package</button>");
        get("export-platform-package-btn")?.addEventListener("click", exportPlatformPackage); get("export-copy-btn")?.addEventListener("click", () => download(JSON.stringify(exportData("text"), null, 2), "morrow-ad-copy.json", "application/json"));
        get("export-image-btn")?.addEventListener("click", () => exportPreview("png")); get("export-image-final-btn")?.addEventListener("click", () => exportPreview("png")); get("export-jpg-final-btn")?.addEventListener("click", () => exportPreview("jpg")); get("ad-image-upload")?.addEventListener("change", (e) => readAsset(e.target.files[0], "hero")); get("ad-logo-upload")?.addEventListener("change", (e) => readAsset(e.target.files[0], "logo")); get("asset-rights")?.addEventListener("change", (e) => { if (state.assets.hero) state.assets.hero.rightsConfirmed = e.target.checked; render(); }); get("asset-alt")?.addEventListener("input", (e) => { if (state.assets.hero) state.assets.hero.alt = clean(e.target.value); persist(); });
        get("example-brief-btn")?.addEventListener("click", () => { const fields = { "ad-studio-name": "Northstar Home Care", "ad-studio-offer": "Dependable repairs for busy homeowners", "ad-studio-audience": "Busy local homeowners", "ad-studio-location": "Scottsdale, AZ", "ad-studio-cta": "Request a clear estimate", "ad-studio-proof": "A straightforward process from first call to finished work" }; Object.entries(fields).forEach(([id, val]) => { const el = get(id); if (el) el.value = val; }); const status = get("ad-studio-status"); if (status) status.textContent = "Example brief loaded. Review it, then create your ad."; }); get("clear-draft-btn")?.addEventListener("click", () => { state = defaultState(); selectedLayer = "headline"; pendingProjectContext = null; try { localStorage.removeItem(saveKey()); } catch (_) {} setStage("make", { replace: true }); render(); const el = get("ad-studio-status"); if (el) el.textContent = "Draft cleared. Start with a short brief."; }); if (state.concepts.length) render();
    }
    function readAsset(file, type) { if (!file || typeof FileReader === "undefined") return; const reader = new FileReader(); reader.onload = () => { state.assets[type] = { name: file.name, dataUrl: reader.result, mediaType: file.type.startsWith("video/") ? "video" : "image", rightsConfirmed: false, alt: "" }; render(); }; reader.readAsDataURL(file); }
    function loadImage(source) {
        return new Promise((resolve, reject) => {
            if (!source) {
                resolve(null);
                return;
            }
            const image = new Image();
            image.onload = () => resolve(image);
            image.onerror = () => reject(new Error("The selected image could not be loaded for export."));
            image.src = source;
        });
    }

    async function exportPreview(type) {
        const concept = state.concepts[state.selectedIndex];
        const meta = FORMAT_META[concept?.format || "square"];
        if (!concept || typeof document === "undefined" || !document.createElement) return;
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        canvas.width = meta.width;
        canvas.height = meta.height;
        const schema = layerSchema(concept);
        ctx.fillStyle = schema.background.color;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        if (schema.background.gradient) {
            const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            gradient.addColorStop(0, "#526d9d");
            gradient.addColorStop(.55, "#1b2945");
            gradient.addColorStop(1, "#a55e3b");
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        try {
            const hero = await loadImage(state.assets.hero?.dataUrl);
            const logo = await loadImage(state.assets.logo?.dataUrl);
            const imageLayer = schema.layers.find((item) => item.id === "image");
            if (hero && imageLayer) {
                const scale = Math.max(canvas.width / hero.width, canvas.height / hero.height) * (imageLayer.crop?.scale || 1);
                const x = (canvas.width - hero.width * scale) * (imageLayer.crop?.x ?? .5);
                const y = (canvas.height - hero.height * scale) * (imageLayer.crop?.y ?? .5);
                ctx.globalAlpha = imageLayer.opacity ?? 1;
                ctx.drawImage(hero, x, y, hero.width * scale, hero.height * scale);
                ctx.globalAlpha = 1;
            }
            drawLayers(ctx, schema.layers.filter((item) => item.id !== "image"), canvas, logo);
            const mimeType = type === "jpg" ? "image/jpeg" : "image/png";
            const extension = type === "jpg" ? "jpg" : "png";
            download(canvas.toDataURL(mimeType, type === "jpg" ? .92 : undefined), `morrow-ad.${extension}`, mimeType);
        } catch (error) {
            const status = get("ad-studio-status");
            if (status) status.textContent = error.message || "The ad could not be exported.";
        }
    }

    function drawLayers(ctx, layers, canvas, logoImage = null) {
        layers.filter((layer) => layer.visible !== false).forEach((layer) => {
            ctx.globalAlpha = layer.opacity ?? 1;
            if (layer.type === "button") {
                ctx.fillStyle = layer.background || "#d4af37";
                ctx.fillRect(layer.x, layer.y, layer.width, layer.height);
                ctx.fillStyle = layer.color || "#111827";
                ctx.font = `${layer.fontWeight || 900} ${layer.fontSize}px Arial`;
                ctx.fillText(layer.content, layer.x + 18, layer.y + layer.height / 2 + layer.fontSize / 3);
            } else if (layer.type === "logo" && logoImage) {
                ctx.drawImage(logoImage, layer.x, layer.y, layer.width, layer.height);
            } else if (layer.type !== "logo") {
                ctx.fillStyle = layer.color || "#fff";
                ctx.font = `${layer.fontWeight || 400} ${layer.fontSize}px Arial`;
                ctx.fillText(layer.content, layer.x, layer.y + layer.fontSize);
            }
        });
        ctx.globalAlpha = 1;
    }
    window.adStudio = { analyzePatterns, generateConcept, generateVariants, validateBrief, validateOriginality, validateBrand, qualityScore, platformOutputs, exportData, assetChecklist, layerSchema, duplicateConcept, importWebsiteDetails, isDirty: () => editSessions.size > 0 || Boolean(drag), exportConcept: () => get("ad-studio-export-btn")?.click(), lastPatternProfile: null };
    if (typeof document !== "undefined") { if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind(); }
})();
