"use strict";

// Loads the small editor core first, then defers optional tools until the browser
// is idle. This preserves the existing global module contracts while reducing
// first-load parse and execution work.
(() => {
    // Keep dependency boundaries explicit, but avoid parsing every core module
    // one at a time. The serial loader made startup look like an infinite loop
    // in constrained preview environments.
    // Dependency policy:
    // 1. Foundation is serial because the editor coordinator consumes these globals.
    // 2. Quality modules wait for foundation and load as a controlled group.
    // 3. Startup modules wait for both groups; optional tools load during idle time.
    const foundation = [
        "workspace-core.js",
        "operating-mode.js",
        "workspace-context.js",
        "workspace-content-safety.js",
        "workspace-server-validation.js",
        "workspace-domain-model.js",
        "design-system-catalog.js",
        "design-genome.js",
        "originality-gate.js",
        "workspace-regeneration.js",
        "design-principles-library.js",
        "website-component-registry.js",
        "planner-contract.js",
        "project-output-contract.js",
        "deterministic-repair.js",
        "llm-contract.js",
        "workspace-ai.js",
        "business-profile.js",
        "profile-service.js",
        "business-hub.js",
        "workspace-audit.js",
        "workspace-state.js",
        "workspace-config.js",
        "workspace-fields.js",
        "workspace-pages.js",
        "workspace-preview.js",
        "preview-protocol.js",
        "workspace-formatter.js",
        "workspace-responsive.js",
        "platform-contract.js",
        "workspace-shell-audit.js",
        "setup-wizard.js"
    ];
    const quality = [
        "generated-quality.js",
        "official-site-details.js",
        "workspace-validation.js",
        "workspace-quality-runtime.js",
        "workspace-quality-model.js",
        "privacy-policy.js"
    ];
    // Website-maker-specific review and advanced modules are staged by
    // website-maker-stage-loader.js. Keep the shared editor's optional group
    // limited to modules needed by the generated project workspace.
    const optional = [
        "import-flow.js",
        "workspace-fixes.js",
        "conversion-loop.js",
        "supabase-client.js",
        "workspace-enhancements.js",
        "project-health.js",
        "content-review.js",
        "workspace-release.js",
        "benchmark-ui.js"
    ];
    // Load the editor coordinator before optional workflow UI layers. A
    // workflow-layer parse error must not prevent page management and preview
    // initialization from starting.
    const startup = [
        "workflow-intelligence.js",
        "workspace-generator.js",
        "roadmap-enhancements.js",
        "workspace-preview-controller.js",
        "script.js",
        "onboarding.js"
    ];
    const deferredStartup = ["workflow-studio.js"];

    function removeLegacyInlineModules() {
        document.querySelectorAll('script[type="application/disabled-javascript"], script[type="application/legacy-onboarding"]').forEach((script) => script.remove());
    }

    let loadedGroups = 0;
    const totalGroups = 5;
    const loaderStartedAt = performance.now();
    const PERFORMANCE_BUDGETS = Object.freeze({
        initialScriptCount: 64,
        transferredScriptBytes: 2_500_000,
        stagedScriptCount: 7,
        cumulativeLayoutShift: 0.1
    });
    let cumulativeLayoutShift = 0;
    let layoutShiftObserver = null;
    try {
        layoutShiftObserver = new PerformanceObserver((list) => {
            list.getEntries().forEach((entry) => {
                if (!entry.hadRecentInput) cumulativeLayoutShift += Number(entry.value || 0);
            });
        });
        layoutShiftObserver.observe({ type: "layout-shift", buffered: true });
    } catch (_) { /* Layout Shift is not available in every browser. */ }
    const loaderApi = { foundation, quality, startup, optional };

    function announce(message, progress = null, failed = false) {
        const elapsed = Math.round(performance.now() - loaderStartedAt);
        document.documentElement.dataset.loaderElapsed = String(elapsed);
        window.dispatchEvent(new CustomEvent("workspace:loader-progress", {
            detail: { message, progress, failed, elapsed }
        }));
        const status = document.getElementById("status-vector");
        const optionalStatus = document.getElementById("optional-tools-status");
        if (status) {
            status.textContent = message;
            status.dataset.loaderState = failed ? "error" : progress === 100 ? "ready" : "loading";
        }
        if (optionalStatus && /optional tools/i.test(message)) {
            optionalStatus.hidden = false;
            optionalStatus.textContent = failed
                ? "Some optional tools could not load. Core editing remains available."
                : progress === 100
                    ? "Optional tools are ready."
                    : message;
        }
        document.documentElement.dataset.loaderState = failed ? "error" : progress === 100 ? "ready" : "loading";
    }

    const scriptLoads = new Map();

    function load(source, options = {}) {
        const attempts = Math.max(1, Number(options.attempts) || 2);
        const timeoutMs = Math.max(5000, Number(options.timeoutMs) || 15000);

        if (scriptLoads.has(source)) return scriptLoads.get(source);
        const existing = [...document.scripts].find((script) => {
            try { return new URL(script.src, document.baseURI).pathname.endsWith(`/${source}`); } catch (_) { return false; }
        });
        if (existing) return Promise.resolve(existing);

        const attempt = (number) => new Promise((resolve, reject) => {
            const script = document.createElement("script");
            let settled = false;
            const finish = (error = null) => {
                if (settled) return;
                settled = true;
                window.clearTimeout(timeout);
                script.onload = null;
                script.onerror = null;
                if (error) {
                    script.remove();
                    reject(error);
                } else {
                    resolve(script);
                }
            };
            const timeout = window.setTimeout(() => {
                finish(new Error(`Loading ${source} timed out after ${Math.round(timeoutMs / 1000)} seconds.`));
            }, timeoutMs);

            script.src = source;
            script.async = false;
            script.onload = () => finish();
            script.onerror = () => finish(new Error(`Unable to load ${source}.`));
            document.head.append(script);
        }).catch((error) => {
            if (number >= attempts) throw error;
            return new Promise((resolve) => window.setTimeout(resolve, 250 * number))
                .then(() => attempt(number + 1));
        });

        const pending = attempt(1);
        scriptLoads.set(source, pending);
        // Keep successful loads cached so callers cannot append and execute the
        // same module twice. Failed loads are removed so an explicit retry can
        // make a fresh request.
        pending.then(
            () => {},
            () => { if (scriptLoads.get(source) === pending) scriptLoads.delete(source); }
        );
        return pending;
    }

    function yieldToBrowser(delay = 16) {
        return new Promise((resolve) => window.setTimeout(resolve, delay));
    }

    function loadList(sources, label) {
        announce(label);
        const result = [];
        let index = 0;

        // Use one timer callback per dependency. This avoids recursive promise
        // scheduling, which some preview sandboxes incorrectly classify as a
        // long-running loop even though the work is asynchronous.
        return new Promise((resolve, reject) => {
            const loadNext = () => {
                if (index >= sources.length) {
                    loadedGroups += 1;
                    announce(`${label} complete`, Math.round((loadedGroups / totalGroups) * 100));
                    resolve(result);
                    return;
                }

                const source = sources[index++];
                window.setTimeout(() => {
                    load(source)
                        .then((script) => {
                            result.push(script);
                            window.setTimeout(loadNext, 0);
                        })
                        .catch(reject);
                }, 0);
            };

            window.setTimeout(loadNext, 0);
        });
    }

    function loadParallelList(sources, label) {
        announce(label);
        return Promise.all(sources.map((source) => load(source))).then((result) => {
            loadedGroups += 1;
            announce(`${label} complete`, Math.round((loadedGroups / totalGroups) * 100));
            return result;
        });
    }

    // Keep early button presses instead of dropping them. The workspace is
    // assembled dynamically, so a click can arrive before its module has
    // attached a handler. Replay the latest press once the core is ready.
    const pendingButtonClicks = new Map();
    document.addEventListener("click", (event) => {
        const button = event.target.closest("button");
        if (!button || button.disabled || button.id === "workspace-loader-retry" || document.documentElement.dataset.loaderState === "ready") return;
        // Keep the sequential brief and empty-state CTA usable while modules load.
        if (button.closest("[data-sequential-brief]") || button.id === "preview-empty-action" || button.id === "show-advanced-tools-btn" || button.id === "toggle-focus-mode-btn" || button.id === "update-contact-draft-btn" || button.id === "go-live-publish-btn" || button.id === "go-live-download-btn") return;
        event.preventDefault();
        event.stopImmediatePropagation();
        pendingButtonClicks.set(button.id || button, button);
        const status = document.getElementById("status-vector");
        if (status) {
            status.textContent = "The editor is still loading — your action will continue when it is ready.";
            status.dataset.loaderState = "loading";
        }
    }, true);

    function finishStartupLifecycle() {
        // Dynamically appended scripts can miss the browser's original
        // DOMContentLoaded event. Give their normal startup listeners one
        // consistent lifecycle signal before replaying queued actions.
        document.dispatchEvent(new Event("DOMContentLoaded"));
        pendingButtonClicks.forEach((button) => {
            if (button.isConnected && !button.disabled) {
                button.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
            }
        });
        pendingButtonClicks.clear();
    }

    // Expose only the loader contract needed by diagnostics and tests. The
    // module lists remain immutable so a failed optional group cannot mutate
    // the dependency plan for a later retry.
    window.workspaceLoader = {
        groups: loaderApi,
        load,
        loadList,
        loadParallelList,
        yieldToBrowser
    };

    let initialResourceSnapshot = null;
    function reportStartupDiagnostics(phase = "startup") {
        const entries = performance.getEntriesByType?.("resource") || [];
        const allScriptEntries = entries.filter((entry) => /\.js(?:[?#]|$)/i.test(entry.name));
        if (!initialResourceSnapshot) initialResourceSnapshot = [...allScriptEntries];
        const scriptEntries = initialResourceSnapshot;
        const scripts = scriptEntries
            .slice()
            .sort((a, b) => (b.duration || 0) - (a.duration || 0))
            .slice(0, 5)
            .map((entry) => ({
                name: entry.name.split("/").pop()?.split("?")[0] || entry.name,
                duration: Math.round(entry.duration || 0),
                transferSize: Number(entry.transferSize || entry.encodedBodySize || 0)
            }));
        // Cached resources commonly report transferSize=0. encodedBodySize keeps
        // the budget meaningful for warm navigations without double counting.
        const transferredScriptBytes = scriptEntries.reduce((total, entry) => total + Number(entry.transferSize || entry.encodedBodySize || 0), 0);
        const stagedScriptCount = window.websiteMakerStageLoader?.loadedScriptCount?.() || 0;
        const stagedExecutionCount = Object.values(window.websiteMakerStageLoader?.executionCounts?.() || {}).reduce((total, count) => total + Number(count || 0), 0);
        const diagnosticsAvailable = typeof performance.getEntriesByType === "function" && scriptEntries.length > 0;
        const budgetResults = {
            diagnosticsAvailable,
            initialScriptCount: diagnosticsAvailable && scriptEntries.length <= PERFORMANCE_BUDGETS.initialScriptCount,
            transferredScriptBytes: diagnosticsAvailable && transferredScriptBytes > 0 && transferredScriptBytes <= PERFORMANCE_BUDGETS.transferredScriptBytes,
            stagedScriptCount: stagedScriptCount <= PERFORMANCE_BUDGETS.stagedScriptCount,
            stagedExecutionCount: stagedExecutionCount <= PERFORMANCE_BUDGETS.stagedScriptCount,
            cumulativeLayoutShift: cumulativeLayoutShift <= PERFORMANCE_BUDGETS.cumulativeLayoutShift
        };
        const detail = {
            phase,
            elapsed: Math.round(performance.now() - loaderStartedAt),
            scripts,
            initialScriptCount: scriptEntries.length,
            transferredScriptBytes,
            stagedScriptCount,
            stagedExecutionCount,
            cumulativeLayoutShift: Number(cumulativeLayoutShift.toFixed(4)),
            diagnosticsAvailable,
            budgets: PERFORMANCE_BUDGETS,
            budgetResults,
            staged: {
                draft: Boolean(window.websiteMakerStageLoader?.loaded?.("draft")),
                advanced: Boolean(window.websiteMakerStageLoader?.loaded?.("advanced"))
            }
        };
        window.workspaceStartupDiagnostics = Object.freeze(detail);
        window.dispatchEvent(new CustomEvent("workspace:startup-diagnostics", { detail }));
        console.info("Workspace startup", detail);
        return detail;
    }
    window.refreshWorkspaceStartupDiagnostics = (phase = "interaction") => reportStartupDiagnostics(phase);

    function addRetryControl(error) {
        if (document.getElementById("workspace-loader-retry")) return;
        const status = document.getElementById("status-vector");
        const wrapper = status?.closest(".system-pulse-wrapper") || document.querySelector(".system-pulse-wrapper") || document.body;
        if (!wrapper) return;
        if (!document.getElementById("workspace-loader-fallback-style")) {
            const style = document.createElement("style");
            style.id = "workspace-loader-fallback-style";
            style.textContent = `.loader-error-notice{display:block;margin:.5rem 0;color:#fecaca;font:600 .8rem/1.4 system-ui,sans-serif}.loader-retry-btn{display:inline-block;padding:.55rem .8rem;border:1px solid #fca5a5;border-radius:.5rem;color:#fff;background:#7f1d1d;font:700 .8rem/1 system-ui,sans-serif;cursor:pointer}.loader-retry-btn:focus-visible{outline:3px solid #fde68a;outline-offset:2px}`;
            document.head.append(style);
        }

        const errorNotice = document.createElement("span");
        errorNotice.className = "loader-error-notice";
        errorNotice.setAttribute("role", "alert");
        errorNotice.textContent = "The editor could not finish loading. Reload the workspace to try again.";
        wrapper.append(errorNotice);

        const retry = document.createElement("button");
        retry.id = "workspace-loader-retry";
        retry.type = "button";
        retry.className = "loader-retry-btn";
        retry.textContent = "Reload workspace";
        retry.title = error?.message || "Reload the workspace and try loading the editor again.";
        retry.setAttribute("aria-label", "Reload workspace after an editor loading failure");
        retry.addEventListener("click", () => window.location.reload());
        wrapper.append(retry);
    }

    function loadDeferredStartup() {
        return loadList(deferredStartup, "Loading workflow tools").catch((error) => {
            // The workflow panel is enhancement-only; keep the editor usable if
            // this layer fails to parse or initialize.
            loadedGroups += 1;
            announce("Workflow tools unavailable; core editor is ready", Math.round((loadedGroups / totalGroups) * 100));
            window.__deferredStartupErrors = [
                ...(window.__deferredStartupErrors || []),
                { source: "workflow-studio.js", message: error?.message || String(error) }
            ];
            window.dispatchEvent(new CustomEvent("workspace:loader-error", {
                detail: { group: "deferred-startup", error }
            }));
        });
    }

    function loadOptional() {
        const start = () => {
            // Optional tools are intentionally staggered. Loading every large
            // feature module in one Promise.all creates a parse burst that can
            // trip constrained preview watchdogs and compete with first paint.
            loadList(optional, "Loading optional tools").catch((error) => {
                // Optional failures do not invalidate the core editor. Keep the
                // main status healthy and place the actionable detail beside it.
                announce("Ready to create", 100);
                const optionalStatus = document.getElementById("optional-tools-status");
                if (optionalStatus) {
                    optionalStatus.hidden = false;
                    optionalStatus.textContent = "Some optional tools could not load. Core editing remains available.";
                }
                window.__optionalLoaderErrors = [
                    ...(window.__optionalLoaderErrors || []),
                    ...optional.filter((source) => String(error?.message || "").includes(source))
                ];
                window.dispatchEvent(new CustomEvent("workspace:loader-error", {
                    detail: { group: "optional", error }
                }));
                addRetryControl(error);
            });
        };
        if ("requestIdleCallback" in window) {
            window.requestIdleCallback(start, { timeout: 1500 });
        } else {
            window.setTimeout(start, 250);
        }
    }

    // Foundation modules are appended in dependency order with async=false, so
    // the browser can fetch them concurrently while preserving execution order.
    // Quality modules are independent after foundation; startup remains serial
    // because script.js consumes globals created earlier in that group.
    const stagedMaker = document.body?.classList.contains("website-maker-shell");
    announce("Loading editor", 0);
    loadList(foundation, "Loading editor")
        // Generation depends on the canonical quality bundle, so it remains in
        // the initial creation stage; review and diagnostic UI stay deferred.
        .then(() => loadParallelList(quality, "Loading quality tools"))
        .then(() => loadList(startup, "Starting workspace"))
        .then(() => {
            removeLegacyInlineModules();
            announce("Core editor ready", stagedMaker ? 100 : Math.round((loadedGroups / totalGroups) * 100));
            finishStartupLifecycle();
            reportStartupDiagnostics();
            window.dispatchEvent(new CustomEvent("workspace:core-ready"));
        })
        .then(() => stagedMaker ? null : loadDeferredStartup())
        .then(() => stagedMaker ? null : loadOptional())
        .catch((error) => {
            announce("Workspace could not load — reload to try again", null, true);
            reportStartupDiagnostics();
            const status = document.getElementById("status-vector");
            if (status) {
                status.title = error?.message || "A workspace module failed to load. Reload the workspace or inspect the browser console for details.";
                status.setAttribute("aria-label", `Workspace loading failed: ${error?.message || "reload to try again"}`);
            }
            document.body?.classList.add("workspace-load-failed");
            addRetryControl(error);
            console.error(error);
        });
})();
