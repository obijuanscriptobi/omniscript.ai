"use strict";
(() => {
    const APPOINTMENT_KEY = "morrow-appointments-v1";
    const SETTINGS_KEY = "morrow-appointment-settings-v1";
    const storageKey = (base) => window.workspaceContext?.storageKey?.(base) || base;
    const TYPES = Object.freeze({
        discovery: { context: "work", label: "Discovery call", duration: 45, before: "Review the lead and website audit", followUp: "Create and send a proposal", questions: ["What is working today?", "Where do enquiries slow down?", "Who needs to approve the next step?"] },
        audit_review: { context: "work", label: "Audit review", duration: 45, before: "Review verified findings and choose the clearest examples", followUp: "Send the agreed website priorities", questions: ["Which finding feels most urgent?", "What result would make this worth fixing?", "Is any evidence out of date?"] },
        proposal_review: { context: "work", label: "Proposal review", duration: 30, before: "Review scope, pricing, and known objections", followUp: "Record the decision and agreed revisions", questions: ["Does the scope match the priority?", "What would prevent a decision?", "Who else needs to review it?"] },
        client_approval: { context: "work", label: "Client approval", duration: 30, before: "Open the current revision and unresolved feedback", followUp: "Approve or request specific changes", questions: ["Does this revision solve the agreed problem?", "What must change before approval?", "Is the launch scope confirmed?"] },
        kickoff: { context: "work", label: "Project kickoff", duration: 60, before: "Confirm scope, owners, assets, and milestones", followUp: "Create the project delivery checklist", questions: ["Who owns each approval?", "Which assets are still missing?", "What is the launch deadline?"] },
        revision_review: { context: "work", label: "Revision review", duration: 45, before: "Open the current revision and previous feedback", followUp: "Turn approved changes into tasks", questions: ["Which changes are approved?", "What still needs evidence?", "Is another revision required?"] },
        launch_handoff: { context: "work", label: "Launch handoff", duration: 45, before: "Verify the live URL, forms, analytics, and ownership", followUp: "Schedule the post-launch check", questions: ["Are forms reaching the correct inbox?", "Who owns future updates?", "When should results be reviewed?"] },
        follow_up: { context: "work", label: "Work follow-up", duration: 20, before: "Review the last interaction and open commitments", followUp: "Record the next agreed action", questions: ["What changed since the last conversation?", "Is the next step still relevant?", "When should we check in again?"] },
        personal_planning: { context: "personal", label: "Personal planning", duration: 30, before: "Review the goal, constraints, and information you already have", followUp: "Record the next personal action", questions: ["What outcome would make this useful?", "What decision is needed?", "What can be done next?"] },
        health: { context: "personal", label: "Health appointment", duration: 45, before: "Gather relevant dates, questions, and documents", followUp: "Record instructions and the next check-in", questions: ["What needs to be discussed?", "Which facts or dates should be confirmed?", "What follow-up is required?"] },
        family: { context: "personal", label: "Family commitment", duration: 60, before: "Confirm people, place, timing, and anything to bring", followUp: "Record any agreed follow-up", questions: ["Who needs to know?", "What needs to be prepared?", "Is travel time included?"] },
        finance: { context: "personal", label: "Personal finance", duration: 45, before: "Gather statements, dates, and questions without storing sensitive account secrets", followUp: "Record the decision and next review", questions: ["What decision is needed?", "Which figures need verification?", "When should this be reviewed again?"] },
        errand: { context: "personal", label: "Errand", duration: 30, before: "Check location, opening hours, documents, and travel time", followUp: "Mark the errand complete or reschedule it", questions: ["What must be brought?", "Are hours and location confirmed?", "Can this be combined with another trip?"] },
        social: { context: "personal", label: "Social event", duration: 90, before: "Confirm attendance, location, travel, and anything to bring", followUp: "Capture any personal follow-up", questions: ["Who is attending?", "Is the location confirmed?", "What should be brought?"] },
        personal_follow_up: { context: "personal", label: "Personal follow-up", duration: 20, before: "Review the previous commitment and current priority", followUp: "Set the next personal action", questions: ["What changed?", "Is this still important?", "What is the smallest useful next step?"] }
    });
    const OUTCOMES = Object.freeze({
        qualified: { label: "Qualified", stage: "qualified", action: "Create a proposal" },
        follow_up: { label: "Follow-up needed", action: "Send the agreed follow-up" },
        proposal_requested: { label: "Proposal requested", stage: "proposal", action: "Create and send the proposal" },
        won: { label: "Won", stage: "won", action: "Start the project kickoff" },
        lost: { label: "Lost", stage: "lost", action: "Record why the opportunity was lost" },
        no_show: { label: "No-show", action: "Offer a new appointment time" },
        rescheduled: { label: "Rescheduled", action: "Confirm the new appointment time" },
        personal_completed: { label: "Completed", action: "Record any personal follow-up" },
        personal_follow_up: { label: "Personal follow-up needed", action: "Complete the next personal action" }
    });
    const clean = (value, max = 1000) => String(value ?? "").replace(/[<>]/g, "").trim().slice(0, max);
    const validDate = (value) => { const date = new Date(value); return Number.isFinite(date.getTime()) ? date : null; };
    const dateKey = (value = new Date()) => { const date = validDate(value); return date ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}` : ""; };
    const defaultSettings = () => ({ startHour: 9, endHour: 17, minimumNoticeHours: 24, bufferMinutes: 15, dailyLimit: 4, travelBufferMinutes: 30, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Local time", focusBlocks: [] });
    function settings() { try { return { ...defaultSettings(), ...JSON.parse(localStorage.getItem(storageKey(SETTINGS_KEY)) || "{}") }; } catch (_) { return defaultSettings(); } }
    function saveSettings(value = {}) { const next = { ...defaultSettings(), ...value }; try { localStorage.setItem(storageKey(SETTINGS_KEY), JSON.stringify(next)); } catch (_) {} return next; }
    function prospects() { try { const value = JSON.parse(localStorage.getItem(storageKey("morrow-prospect-engine-v1")) || "{}"); return Array.isArray(value.prospects) ? value.prospects : []; } catch (_) { return []; } }
    function crmLeads() { return window.workspaceCRM?.read?.() || []; }
    function findLead(appointment = {}) {
        const id = appointment.leadId || appointment.localLeadId;
        const crm = crmLeads();
        const prospectList = prospects();
        return crm.find((item) => item.id === id || item.cloudId === id) || prospectList.find((item) => item.id === id || item.cloudId === id) || crm.find((item) => item.email && item.email.toLowerCase() === String(appointment.clientEmail || "").toLowerCase()) || prospectList.find((item) => item.workEmail && item.workEmail.toLowerCase() === String(appointment.clientEmail || "").toLowerCase()) || null;
    }
    function typeFor(value) { return TYPES[value] || TYPES.discovery; }
    function normalize(item = {}) {
        const requestedContext = item.context === "personal" ? "personal" : "work";
        const fallbackType = requestedContext === "personal" ? "personal_planning" : (/audit/i.test(item.service || "") ? "audit_review" : /proposal/i.test(item.service || "") ? "proposal_review" : "discovery");
        const requestedType = TYPES[item.type] ? item.type : fallbackType;
        const type = TYPES[requestedType].context === requestedContext ? requestedType : fallbackType;
        const workflow = typeFor(type);
        const history = Array.isArray(item.rescheduleHistory) ? item.rescheduleHistory.slice(-20) : [];
        const preparation = item.preparation && typeof item.preparation === "object" ? item.preparation : {};
        return { ...item, context: workflow.context, type, durationMinutes: Math.max(15, Math.min(240, Number(item.durationMinutes) || workflow.duration)), objective: clean(item.objective, 500), mode: ["video", "phone", "in_person"].includes(item.mode) ? item.mode : "video", timezone: clean(item.timezone, 100) || settings().timezone, phone: clean(item.phone, 80), preparation, outcome: OUTCOMES[item.outcome] ? item.outcome : "", outcomeNotes: clean(item.outcomeNotes, 1200), nextAction: clean(item.nextAction, 300), nextActionAt: validDate(item.nextActionAt)?.toISOString() || "", rescheduleHistory: history, reminderPlan: item.reminderPlan || { preparation: true, attendance: true, startingSoon: true, outcome: true, followUp: true }, timeline: Array.isArray(item.timeline) ? item.timeline.slice(-50) : [] };
    }
    function brief(item) {
        const appointment = normalize(item); const personal = appointment.context === "personal"; const lead = personal ? null : findLead(appointment); const workflow = typeFor(appointment.type);
        const audit = lead?.websiteAudit || lead?.audit || null;
        const findings = audit?.evidence || audit?.issues || lead?.opportunity?.problems || [];
        const questions = lead?.opportunity?.discoveryQuestions?.length ? lead.opportunity.discoveryQuestions : workflow.questions;
        const lastActivity = lead?.activity?.[0];
        const verifiedAt = audit?.checkedAt || lead?.verificationCheckedAt || lead?.updatedAt || "";
        return {
            lead, workflow,
            business: personal ? (appointment.clientBusiness || appointment.service || "Personal commitment") : (appointment.clientBusiness || lead?.company || lead?.name || "Business not linked"),
            stage: personal ? "personal" : (lead?.status || "unlinked"),
            score: personal ? NaN : Number(lead?.opportunityScore ?? lead?.qualification?.score ?? lead?.opportunity?.report?.score),
            publicDetails: personal ? [appointment.mode, appointment.timezone].filter(Boolean) : [lead?.website || lead?.websiteUrl, lead?.companyPhone || lead?.phone, lead?.workEmail || lead?.email].filter(Boolean),
            findings: personal ? [] : (Array.isArray(findings) ? findings.map((value) => typeof value === "object" ? value.text || value.problem : value).filter(Boolean).slice(0, 5) : []),
            previousNotes: appointment.notes || lead?.notes || lead?.discovery?.notes || "",
            likelyNeeds: personal ? [workflow.before] : (lead?.opportunity?.recommendations || []),
            offer: personal ? workflow.followUp : (lead?.offer?.packageName || lead?.opportunity?.suggestedOffer || "Confirm the right offer during the meeting"),
            questions: questions.slice(0, 5),
            claimsToVerify: personal ? ["Confirm dates, location, and details before relying on them"] : [!audit ? "Website findings have not been verified" : "Confirm that website findings are still current", !(lead?.phone || lead?.companyPhone || appointment.phone) ? "A public phone number is missing" : "", !(lead?.email || lead?.workEmail || appointment.clientEmail) ? "A public email is missing" : ""].filter(Boolean),
            lastInteraction: lastActivity?.at ? `${lastActivity.label || "Activity"} · ${new Date(lastActivity.at).toLocaleDateString()}` : (personal ? "No previous personal note recorded" : "No previous interaction recorded"),
            verifiedAt
        };
    }
    function checklist(item) {
        const appointment = normalize(item); const info = brief(appointment); const prep = appointment.preparation || {};
        return [
            { key: "websiteReviewed", label: appointment.context === "personal" ? "Details reviewed" : "Website reviewed", done: prep.websiteReviewed === true || Boolean(info.lead?.websiteAudit || info.lead?.audit) },
            { key: "contactVerified", label: appointment.context === "personal" ? "Time and location confirmed" : "Contact details verified", done: prep.contactVerified === true || Boolean((info.lead?.phone || info.lead?.companyPhone || appointment.phone) && (info.lead?.email || info.lead?.workEmail || appointment.clientEmail)) },
            { key: "notesReviewed", label: "Review previous notes", done: prep.notesReviewed === true },
            { key: "questionsChosen", label: appointment.context === "personal" ? "Choose questions or items to bring" : "Choose discovery questions", done: prep.questionsChosen === true },
            { key: "objectiveSet", label: appointment.context === "personal" ? "Set a personal outcome" : "Set a meeting objective", done: Boolean(appointment.objective) }
        ];
    }
    function risks(item, all = [], value = settings()) {
        const appointment = normalize(item); const info = brief(appointment); const meeting = validDate(appointment.meetingAt); const list = []; const checks = checklist(appointment);
        if (!checks.some((check) => check.done)) list.push("no preparation is complete");
        if (!appointment.objective) list.push("the meeting has no objective");
        if (appointment.context === "work" && !appointment.leadId) list.push("no lead is linked");
        if (appointment.context === "work" && !(appointment.clientEmail || appointment.phone || info.lead?.email || info.lead?.phone || info.lead?.companyPhone)) list.push("contact details are missing");
        if (appointment.nextActionAt && validDate(appointment.nextActionAt) < new Date() && !appointment.outcome) list.push("follow-up is overdue");
        if (appointment.rescheduleHistory.length >= 2) list.push(`it has been rescheduled ${appointment.rescheduleHistory.length} times`);
        if (meeting && (meeting.getHours() < Number(value.startHour) || meeting.getHours() >= Number(value.endHour))) list.push("it is outside working hours");
        if (appointment.timezone && appointment.timezone !== value.timezone) list.push(`the client time zone is ${appointment.timezone}`);
        const verified = validDate(info.verifiedAt); if (verified && (Date.now() - verified.getTime()) / 86400000 > 30) list.push(`website evidence is ${Math.floor((Date.now() - verified.getTime()) / 86400000)} days old`);
        if (meeting) { const adjacent = all.find((other) => other.id !== appointment.id && validDate(other.meetingAt) && Math.abs(validDate(other.meetingAt) - meeting) < Number(value.bufferMinutes) * 60000); if (adjacent) list.push("it conflicts with the meeting buffer"); }
        return list;
    }
    function relativeTime(value) { const date = validDate(value); if (!date) return "Time not set"; const diff = date - new Date(); const abs = Math.abs(diff); if (abs < 3600000) return `${Math.max(1, Math.round(abs / 60000))} minutes ${diff >= 0 ? "from now" : "ago"}`; if (abs < 86400000) return `${Math.round(abs / 3600000)} hours ${diff >= 0 ? "from now" : "ago"}`; const days = Math.round(abs / 86400000); return `${days} day${days === 1 ? "" : "s"} ${diff >= 0 ? "from now" : "ago"}`; }
    function recommendedSlots(items = [], value = settings(), count = 5) {
        const meetings = items.map(normalize).filter((item) => !["cancelled", "completed"].includes(item.status)); const result = []; const notice = Date.now() + Number(value.minimumNoticeHours) * 3600000;
        const focusBlocks = Array.isArray(value.focusBlocks) ? value.focusBlocks : [];
        for (let day = 0; day < 14 && result.length < count; day += 1) {
            const date = new Date(); date.setDate(date.getDate() + day);
            if ([0, 6].includes(date.getDay())) continue;
            const daily = meetings.filter((item) => dateKey(item.meetingAt) === dateKey(date)); if (daily.length >= Number(value.dailyLimit)) continue;
            for (let hour = Number(value.startHour); hour < Number(value.endHour) && result.length < count; hour += 1) {
                const slot = new Date(date); slot.setHours(hour, 30, 0, 0); if (slot.getTime() < notice) continue;
                const duration = 45 * 60000;
                const focusConflict = focusBlocks.some((block) => { const start = validDate(block?.start); const end = validDate(block?.end); return start && end && slot < end && new Date(slot.getTime() + duration) > start; });
                const conflict = daily.some((item) => { const at = validDate(item.meetingAt); const buffer = Number(value.bufferMinutes) + (item.mode === "in_person" ? Number(value.travelBufferMinutes) : 0); return at && slot < new Date(at.getTime() + (Number(item.durationMinutes) + buffer) * 60000) && new Date(slot.getTime() + duration + buffer * 60000) > at; });
                if (!focusConflict && !conflict) result.push({ at: slot.toISOString(), reason: daily.length < 2 ? "Leaves preparation time and avoids a meeting-heavy day." : "Fits the daily limit with a protected buffer." });
            }
        }
        return result;
    }

    function reminderLadder(item, now = new Date()) {
        const appointment = normalize(item); const meeting = validDate(appointment.meetingAt); if (!meeting) return [];
        const plan = appointment.reminderPlan || {}; const nextAction = validDate(appointment.nextActionAt || appointment.followUpAt);
        const reminders = [
            { key: "preparation", label: "Prepare for the meeting", at: new Date(meeting.getTime() - 24 * 3600000), enabled: plan.preparation !== false },
            { key: "attendance", label: "Confirm attendance", at: new Date(meeting.getTime() - 2 * 3600000), enabled: plan.attendance !== false },
            { key: "startingSoon", label: "Meeting starts soon", at: new Date(meeting.getTime() - 15 * 60000), enabled: plan.startingSoon !== false },
            { key: "outcome", label: "Record the meeting outcome", at: new Date(meeting.getTime() + Number(appointment.durationMinutes) * 60000), enabled: plan.outcome !== false && !appointment.outcome },
            { key: "followUp", label: "Complete the promised follow-up", at: nextAction, enabled: plan.followUp !== false && Boolean(nextAction) }
        ].filter((entry) => entry.enabled && entry.at);
        return reminders.map((entry) => ({ ...entry, due: entry.at <= now, delivery: plan.delivery === "provider-confirmed" ? "Provider confirmed" : "Local reminder only" }));
    }
    function metrics(items = []) {
        const appointments = items.map(normalize); const completed = appointments.filter((item) => item.status === "completed" || item.outcome); const attended = completed.filter((item) => !["no_show", "rescheduled"].includes(item.outcome)); const discoveries = completed.filter((item) => item.type === "discovery"); const qualified = discoveries.filter((item) => ["qualified", "proposal_requested", "won"].includes(item.outcome)); const proposals = completed.filter((item) => item.outcome === "proposal_requested"); const won = completed.filter((item) => item.outcome === "won"); const withDelay = completed.filter((item) => validDate(item.nextActionAt) && validDate(item.meetingAt)); const averageDelay = withDelay.length ? withDelay.reduce((sum, item) => sum + Math.max(0, validDate(item.nextActionAt) - validDate(item.meetingAt)), 0) / withDelay.length / 3600000 : null; const byType = Object.keys(TYPES).map((type) => ({ type, count: completed.filter((item) => item.type === type).length, wins: completed.filter((item) => item.type === type && item.outcome === "won").length })).sort((a, b) => b.wins - a.wins || b.count - a.count)[0];
        const rate = (part, whole) => whole ? `${Math.round(part / whole * 100)}%` : "—";
        return { attendance: rate(attended.length, completed.length), noShow: rate(completed.filter((item) => item.outcome === "no_show").length, completed.length), discoveryQualified: rate(qualified.length, discoveries.length), qualifiedProposal: rate(proposals.length, qualified.length), averageFollowUp: averageDelay === null ? "—" : `${averageDelay.toFixed(1)}h`, withoutNextAction: completed.filter((item) => !item.nextAction).length, effectiveType: byType?.count ? typeFor(byType.type).label : "Not enough data", wonHours: won.length ? `${won.reduce((sum, item) => sum + Number(item.durationMinutes), 0) / 60}h` : "—" };
    }
    window.appointmentIntelligence = Object.freeze({ APPOINTMENT_KEY, SETTINGS_KEY, TYPES, OUTCOMES, normalize, typeFor, brief, checklist, risks, relativeTime, settings, saveSettings, recommendedSlots, reminderLadder, metrics, findLead, dateKey });
})();
