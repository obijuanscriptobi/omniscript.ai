"use strict";

(() => {
    const token = new URLSearchParams(location.search).get("token");
    if (token) history.replaceState(null, "", `${location.pathname}${location.hash}`);
    const summary = document.getElementById("summary");
    const message = document.getElementById("message");
    const buttons = [...document.querySelectorAll("button[data-status]")];

    const disableButtons = () => buttons.forEach((button) => { button.disabled = true; });
    const idempotencyKeys = new Map();
    let updatedAt = "";

    if (!token) {
        summary.textContent = "This approval link is missing its token.";
        disableButtons();
        return;
    }

    fetch(`/api/approval?token=${encodeURIComponent(token)}`, {
        headers: { Accept: "application/json" }
    }).then(async (response) => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || "Approval link unavailable.");
        updatedAt = data.approval.updated_at || "";
        summary.textContent = `Revision ${data.approval.revision} is ready for review.`;
    }).catch((error) => {
        summary.textContent = error.message || "Approval link unavailable.";
        disableButtons();
    });

    buttons.forEach((button) => {
        button.addEventListener("click", async () => {
            button.disabled = true;
            const idempotencyKey = idempotencyKeys.get(button.dataset.status) || crypto.randomUUID();
            idempotencyKeys.set(button.dataset.status, idempotencyKey);
            try {
                const response = await fetch(`/api/approval?token=${encodeURIComponent(token)}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json",
                        "Idempotency-Key": idempotencyKey
                    },
                    body: JSON.stringify({
                        status: button.dataset.status,
                        comment: document.getElementById("comment").value,
                        updatedAt
                    })
                });
                const data = await response.json().catch(() => ({}));
                if (!response.ok) throw new Error(data.error || "Could not save response.");
                idempotencyKeys.delete(button.dataset.status);
                message.textContent = button.dataset.status === "approved"
                    ? "Thank you. The draft was approved."
                    : "Your change request was sent.";
                buttons.forEach((item) => item.remove());
            } catch (error) {
                message.textContent = error.message || "Could not save response.";
                button.disabled = false;
            }
        });
    });
})();
