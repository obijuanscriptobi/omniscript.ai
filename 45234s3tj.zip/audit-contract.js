"use strict";

// Shared evidence contract for lead-to-audit handoff. Records are local-first;
// cloud persistence can mirror the same shape under the related project/lead.
(() => {
    const KEY = "morrow-website-audits-v1";
    const storageKey = () => window.workspaceContext?.storageKey?.(KEY) || KEY;
    const clean = (value, max = 500) => String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, max);
    const now = () => new Date().toISOString();
    const id = () => globalThis.crypto?.randomUUID?.() || `audit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    function read() {
        try {
            const scopedKey = storageKey();
            let raw = localStorage.getItem(scopedKey);
            const ownContext = window.workspaceContext?.current?.()?.mode !== "client";
            if (!raw && scopedKey !== KEY && ownContext) {
                raw = localStorage.getItem(KEY);
                if (raw) localStorage.setItem(scopedKey, raw);
            }
            const value = JSON.parse(raw || "[]");
            return Array.isArray(value) ? value : [];
        } catch (_) { return []; }
    }

    function write(records) {
        const next = records.slice(-200);
        try { localStorage.setItem(storageKey(), JSON.stringify(next)); } catch (_) {}
        return next;
    }

    function normalizeFinding(finding = {}) {
        return {
            id: clean(finding.id, 100) || id(),
            issue: clean(finding.issue, 500),
            evidence: finding.evidence && typeof finding.evidence === "object" ? {
                page: clean(finding.evidence.page, 500), viewport: clean(finding.evidence.viewport, 40),
                sourceUrl: clean(finding.evidence.sourceUrl, 1000), screenshot: clean(finding.evidence.screenshot, 1000), details: clean(finding.evidence.details, 1200)
            } : {},
            impact: ["high", "medium", "low"].includes(finding.impact) ? finding.impact : "medium",
            recommendation: clean(finding.recommendation, 800), confidence: Math.max(0, Math.min(1, Number(finding.confidence) || 0)),
            remediation: ["safe-auto", "review-required", "blocked"].includes(finding.remediation) ? finding.remediation : "review-required",
            status: ["open", "accepted", "fixed", "wont-fix"].includes(finding.status) ? finding.status : "open"
        };
    }

    function upsert(input = {}) {
        const existing = read().find((item) => (input.id && item.id === input.id) || (input.leadId && item.leadId === input.leadId && input.websiteUrl && item.websiteUrl === input.websiteUrl));
        const record = {
            id: existing?.id || input.id || id(), leadId: clean(input.leadId, 100), projectId: clean(input.projectId, 100),
            workContextId: clean(input.workContextId, 100) || window.workspaceContext?.current?.()?.id || "own-business",
            websiteUrl: clean(input.websiteUrl, 1000), finalUrl: clean(input.finalUrl || input.websiteUrl, 1000),
            state: ["not-audited", "audit-in-progress", "audit-complete", "needs-review", "fix-ready"].includes(input.state) ? input.state : (existing?.state || "not-audited"),
            requestedAt: existing?.requestedAt || input.requestedAt || now(), checkedAt: input.checkedAt || existing?.checkedAt || "",
            sourceEvidence: input.sourceEvidence && typeof input.sourceEvidence === "object" ? input.sourceEvidence : (existing?.sourceEvidence || {}),
            technical: input.technical && typeof input.technical === "object" ? input.technical : (existing?.technical || {}),
            content: input.content && typeof input.content === "object" ? input.content : (existing?.content || {}),
            visual: input.visual && typeof input.visual === "object" ? input.visual : (existing?.visual || {}),
            findings: Array.isArray(input.findings) ? input.findings.map(normalizeFinding) : (existing?.findings || []),
            remediation: input.remediation && typeof input.remediation === "object" ? input.remediation : (existing?.remediation || { status: "not-started", revisionId: "", approvedAt: "" }),
            error: clean(input.error || existing?.error, 500)
        };
        return write([...read().filter((item) => item.id !== record.id), record]).find((item) => item.id === record.id);
    }

    window.websiteAuditContract = Object.freeze({ KEY, storageKey, read, write, upsert, normalizeFinding });
})();
