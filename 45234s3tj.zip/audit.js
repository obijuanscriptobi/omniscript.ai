"use strict";
(() => {
    const $ = (id) => document.getElementById(id);
    const text = (value, fallback = "—") => value === null || value === undefined || value === "" ? fallback : value;
    const params = new URLSearchParams(window.location.search);
    if (params.get("utm_campaign")) window.auditCampaign = params.get("utm_campaign");

    let currentLeadId = params.get("leadId") || "";
    let currentAuditId = params.get("auditId") || "";
    const currentProjectId = params.get("projectId") || "";
    let latestAuditRecord = null;

    function hydrateImportedLead() {
        if (!currentLeadId) return;
        const imported = window.websiteAuditContract?.read?.().find((item) => item.id === currentAuditId || item.leadId === currentLeadId);
        if (imported?.websiteUrl) $("audit-url").value = imported.websiteUrl;
    }

    hydrateImportedLead();

    function auditRecord() {
        return latestAuditRecord || window.websiteAuditContract?.read?.().find((item) => item.id === currentAuditId || (item.leadId === currentLeadId && item.websiteUrl === $("audit-url")?.value.trim())) || {};
    }

    let activeRevision = null;
    function renderRevisionPanel() {
        const root = $("audit-revision-findings"); if (!root || !activeRevision) return;
        root.replaceChildren(...(activeRevision.changes || []).map((change) => { const item = document.createElement("article"); item.className = `audit-revision-change audit-priority-${change.impact || "medium"}`; const locked = change.remediation === "blocked"; item.innerHTML = `<strong></strong><p></p><small></small><div><button type="button" data-revision-approve="true" ${locked ? "disabled" : ""}>Approve</button><button type="button" data-revision-approve="false" ${locked ? "disabled" : ""}>Reject</button></div>`; item.querySelector("strong").textContent = change.summary || "Proposed improvement"; item.querySelector("p").textContent = change.evidence?.details || "Evidence is attached to this finding."; item.querySelector("small").textContent = `${change.remediation} · ${change.approval}`; item.querySelectorAll("button").forEach((button) => button.addEventListener("click", () => { activeRevision = window.conversionLoop.approveChange(activeRevision.id, change.id, button.dataset.revisionApprove === "true"); renderRevisionPanel(); })); return item; }));
        $("audit-revision-panel").hidden = false;
    }
    function openGenerator(mode = "audit-improvement") {
        const audit = auditRecord();
        const context = window.conversionLoop?.createContext({ projectId: currentProjectId || audit.projectId, leadId: currentLeadId || audit.leadId, auditId: audit.id || currentAuditId, audit, sourceWebsite: audit.finalUrl || audit.websiteUrl, mode });
        if (!context) return;
        window.conversionLoop.saveContext(context);
        window.location.href = `index.html?mode=${encodeURIComponent(mode)}&projectId=${encodeURIComponent(context.projectId || "")}&leadId=${encodeURIComponent(context.leadId || "")}&auditId=${encodeURIComponent(context.auditId || "")}`;
    }

    $("generate-improved-site-btn")?.addEventListener("click", () => { const audit = auditRecord(); const context = window.conversionLoop?.createContext({ projectId: currentProjectId || audit.projectId, leadId: currentLeadId || audit.leadId, auditId: audit.id || currentAuditId, audit, sourceWebsite: audit.finalUrl || audit.websiteUrl, mode: "audit-improvement" }); activeRevision = window.conversionLoop?.createRevision(context); renderRevisionPanel(); $("audit-generator-status").textContent = "Draft revision created. Review each evidence-backed change before opening the website maker."; });
    $("audit-persist-revision-btn")?.addEventListener("click", async () => { if (!activeRevision) return; const saved = await window.conversionLoop.persistRevision(activeRevision); activeRevision = saved; $("audit-revision-status").textContent = saved.persistenceError ? `Saved locally; server persistence unavailable: ${saved.persistenceError}` : "Revision saved to the project."; });
    $("audit-open-revision-btn")?.addEventListener("click", () => { if (!activeRevision) return; const context = window.conversionLoop.readContext(); window.conversionLoop.saveContext({ ...context, revisionId: activeRevision.id }); window.location.href = `index.html?mode=audit-improvement&projectId=${encodeURIComponent(activeRevision.projectId || "")}&leadId=${encodeURIComponent(activeRevision.leadId || "")}&auditId=${encodeURIComponent(activeRevision.auditId || "")}`; });
    $("open-website-maker-link")?.addEventListener("click", (event) => { event.preventDefault(); openGenerator("audit-improvement"); });

    function render(report, websiteUrl, email) {
        const audit = report.audit || {};
        $("audit-results").hidden = false;
        const scores = [["Mobile performance", audit.mobileScore], ["Accessibility", audit.accessibilityScore], ["SEO", audit.seoScore]];
        $("audit-score-grid").replaceChildren(...scores.map(([label, score]) => { const item = document.createElement("div"); item.innerHTML = `<strong>${label}</strong><span>${text(score, "Not scored")}</span><small>/ 100</small>`; return item; }));
        $("audit-lcp").textContent = audit.performanceMetrics?.lcpMs === null ? "Not available" : `${text(audit.performanceMetrics?.lcpMs)} ms`;
        $("audit-cls").textContent = text(audit.performanceMetrics?.cls);
        $("audit-tbt").textContent = audit.performanceMetrics?.tbtMs === null ? "Not available" : `${text(audit.performanceMetrics?.tbtMs)} ms`;
        $("audit-summary-text").textContent = text(audit.overallSummary, "The audit returned a useful snapshot of this website.");
        $("audit-priority-text").textContent = text(audit.priorityAction, "Review the findings below and address the highest-impact item first.");
        const opportunities = Array.isArray(audit.opportunities) ? audit.opportunities : [];
        $("audit-issue-list").replaceChildren(...(opportunities.length ? opportunities.map((item, index) => {
            const card = document.createElement("article");
            card.className = `audit-opportunity audit-priority-${item.priority || "medium"}`;
            card.innerHTML = `<div class="audit-opportunity-heading"><span class="audit-rank">${index + 1}</span><div><h4></h4><span class="audit-opportunity-meta"></span></div><b>${item.score ?? "—"}/100</b></div><p class="audit-evidence"></p><p class="audit-recommendation"><strong>Next action:</strong> </p>`;
            card.querySelector("h4").textContent = item.title || "Improvement opportunity";
            card.querySelector(".audit-opportunity-meta").textContent = `${item.priority === "high" ? "High priority" : "Worth improving"}${item.displayValue ? ` · ${item.displayValue}` : ""}`;
            card.querySelector(".audit-evidence").textContent = item.description || "This check needs attention.";
            card.querySelector(".audit-recommendation").append(document.createTextNode(item.recommendation || "Review this area and fix the highest-impact issue first."));
            return card;
        }) : [Object.assign(document.createElement("p"), { className: "audit-empty", textContent: "No major opportunities were returned for this snapshot." })]));
        const passed = Array.isArray(audit.passedChecks) ? audit.passedChecks : [];
        $("audit-passed-list").replaceChildren(...(passed.length ? passed.map((item) => Object.assign(document.createElement("li"), { textContent: item })) : [Object.assign(document.createElement("li"), { textContent: "No passing checks were returned in this snapshot." })]));
        const lead = window.workspaceCRM?.read?.().find((item) => item.email === email && item.websiteUrl === websiteUrl);
        currentLeadId = lead?.id || "";
        $("audit-discovery-link").disabled = !currentLeadId;
        $("audit-booking-name").value = lead?.name || email.split("@")[0];
        $("audit-booking-email").value = email;
        $("audit-booking-status").textContent = currentLeadId ? "Book a time and we’ll attach it to this audit lead." : "Your report is ready. Open Leads to book a call.";
    }

    $("audit-discovery-link")?.addEventListener("click", () => {
        const form = $("audit-booking-form");
        if (form) { form.hidden = false; $("audit-booking-time")?.focus(); }
    });
    $("audit-booking-cancel")?.addEventListener("click", () => { $("audit-booking-form").hidden = true; });
    $("audit-booking-form")?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        if (!form.reportValidity() || !currentLeadId) return;
        const booking = {
            name: $("audit-booking-name").value.trim(), email: $("audit-booking-email").value.trim(),
            websiteUrl: $("audit-url").value.trim(), scheduledAt: $("audit-booking-time").value,
            notes: $("audit-booking-notes").value.trim()
        };
        const cloudState = window.supabaseWorkspace?.getState?.() || {};
        const book = cloudState.authenticated && cloudState.projectId && window.workspaceCRM?.bookDiscoveryWithCloud
            ? window.workspaceCRM.bookDiscoveryWithCloud(currentLeadId, booking)
            : Promise.resolve(window.workspaceCRM?.bookDiscovery?.(currentLeadId, booking));
        const appointment = await book;
        if (!appointment) { $("audit-booking-status").textContent = "That time is invalid, already booked, or the email address is not valid."; return; }
        $("audit-booking-form").hidden = true;
        $("audit-discovery-link").disabled = true;
        $("audit-booking-status").textContent = `Discovery call booked for ${new Date(appointment.meetingAt).toLocaleString()}${appointment.cloudId ? " and synced to the cloud" : " locally"}. Your lead is now in Discovery.`;
    });

    if (params.get("url")) $("audit-url").value = params.get("url");
    $("audit-form")?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const gate = window.workspaceContext?.clientGate?.("context");
        if (gate && !gate.allowed) { $("audit-status").textContent = gate.message; $("audit-status").dataset.state = "error"; return; }
        const form = event.currentTarget;
        if (!form.reportValidity() || form.dataset.busy === "true") return;
        form.dataset.busy = "true";
        const button = form.querySelector("button[type=submit]");
        const status = $("audit-status");
        button.disabled = true;
        status.textContent = "Running the mobile audit…";
        try {
            const websiteUrl = $("audit-url").value.trim();
            const email = $("audit-email").value.trim();
            const previousAudit = window.websiteAuditContract?.read?.().find((item) => item.id === currentAuditId) || {};
            const auditRecord = window.websiteAuditContract?.upsert({ id: currentAuditId, leadId: currentLeadId, projectId: currentProjectId, websiteUrl, finalUrl: websiteUrl, state: "audit-in-progress", requestedAt: new Date().toISOString(), sourceEvidence: { ...(previousAudit.sourceEvidence || {}), email } });
            currentAuditId = auditRecord?.id || currentAuditId;
            const response = await fetch("/api/audit", { method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify({ url: websiteUrl, email }) });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || !payload.success) throw new Error(payload.error || "The audit could not be completed.");
            const cloudState = window.supabaseWorkspace?.getState?.() || {};
            const leadList = cloudState.authenticated && cloudState.projectId && window.workspaceCRM?.addAuditLeadWithCloud
                ? await window.workspaceCRM.addAuditLeadWithCloud({ name: email.split("@")[0], email, websiteUrl: payload.url, campaign: window.auditCampaign || "", audit: payload.audit })
                : window.workspaceCRM?.addAuditLead?.({ name: email.split("@")[0], email, websiteUrl: payload.url, campaign: window.auditCampaign || "", audit: payload.audit });
            const lead = Array.isArray(leadList) ? leadList.find((item) => item.email === email && item.websiteUrl === payload.url) : leadList;
            if (lead) {
                window.workspaceCRM?.migrate?.();
                status.textContent = payload.queued
                    ? "Your audit is queued because the provider is busy. A follow-up has been queued too."
                    : "Audit complete. Your report is ready and a follow-up has been queued.";
            } else status.textContent = payload.queued ? "Your audit is queued. Please retry shortly for scores." : "Audit complete. Your report is ready.";
            latestAuditRecord = window.websiteAuditContract?.upsert({ id: currentAuditId, leadId: currentLeadId, projectId: currentProjectId, websiteUrl, finalUrl: payload.url, state: payload.queued ? "needs-review" : "audit-complete", checkedAt: new Date().toISOString(), technical: payload.audit, content: { provider: payload.audit?.provider || "unknown" }, findings: (payload.audit?.opportunities || []).map((item) => ({ issue: item.title, impact: item.priority, recommendation: item.recommendation, confidence: 0.8, remediation: "review-required", evidence: { page: payload.url, viewport: "mobile", sourceUrl: payload.url, details: item.description } })), error: payload.queued ? (payload.audit?.issues || [])[0] : "" });
            render(payload, payload.url, email);
            const generatorStatus = $("audit-generator-status");
            if (generatorStatus) generatorStatus.textContent = "Audit evidence is ready. Generate an improvement revision when you are ready to review changes.";
        } catch (error) { status.textContent = error.message || "The audit could not be completed."; status.dataset.state = "error"; }
        finally { form.dataset.busy = "false"; button.disabled = false; }
    });
})();
