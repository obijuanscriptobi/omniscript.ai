"use strict";

// Small, deterministic benchmark inputs for repeatable product comparisons.
const FIXTURES = Object.freeze([
    {
        id: "local-service",
        brief: {
            businessName: "Harbour & Hearth",
            audience: "homeowners in Bristol",
            offer: "boiler servicing and emergency heating repairs",
            outcome: "get reliable heating without hidden costs",
            primaryAction: "call",
            phone: "+441179460000"
        }
    },
    {
        id: "hospitality",
        brief: {
            businessName: "Northstar Studio",
            audience: "small hospitality businesses",
            offer: "brand and website strategy",
            outcome: "turn more visits into direct bookings",
            primaryAction: "booking",
            bookingUrl: "https://example.com/book"
        }
    },
    {
        id: "consulting",
        brief: {
            businessName: "Clearline Advisory",
            audience: "founders of growing software companies",
            offer: "commercial strategy and leadership coaching",
            outcome: "make confident decisions during the next stage of growth",
            primaryAction: "enquiry",
            email: "hello@example.com"
        }
    },
    {
        id: "ecommerce",
        brief: {
            businessName: "Fieldnote Goods",
            audience: "design-conscious outdoor travellers",
            offer: "durable everyday travel accessories",
            outcome: "buy better-made gear that lasts for years",
            primaryAction: "purchase",
            shopUrl: "https://example.com/shop"
        }
    },
    {
        id: "professional-service",
        brief: {
            businessName: "Marlow & Co",
            audience: "families planning their first home purchase",
            offer: "independent mortgage advice",
            outcome: "understand the options and choose a manageable mortgage",
            primaryAction: "quote",
            formAction: "https://example.com/quote"
        }
    },
    {
        id: "wellness",
        brief: {
            businessName: "Stillpoint Wellness",
            audience: "professionals seeking calmer routines",
            offer: "private massage and recovery sessions",
            outcome: "feel restored with a simple weekly routine",
            primaryAction: "booking",
            bookingUrl: "https://example.com/book"
        }
    },
    {
        id: "restaurant",
        brief: {
            businessName: "Juniper Table",
            audience: "couples and families in Bath",
            offer: "seasonal dining and private celebrations",
            outcome: "enjoy an unhurried meal worth remembering",
            primaryAction: "booking",
            bookingUrl: "https://example.com/reserve"
        }
    },
    {
        id: "creative-agency",
        brief: {
            businessName: "Northline Creative",
            audience: "independent brands ready to grow",
            offer: "brand identity and campaign design",
            outcome: "show up with a clearer point of view",
            primaryAction: "enquiry",
            email: "hello@example.com"
        }
    },
    {
        id: "health-practice",
        brief: {
            businessName: "Oakwell Physiotherapy",
            audience: "active adults recovering from injury",
            offer: "one-to-one physiotherapy and rehabilitation",
            outcome: "return to movement with a plan they understand",
            primaryAction: "booking",
            bookingUrl: "https://example.com/book"
        }
    },
    {
        id: "incomplete-brief",
        brief: {
            businessName: "Unnamed Business",
            primaryAction: "booking"
        },
        expectedValid: false
    }
]);

function getBenchmarkFixtures() {
    return FIXTURES.map((fixture) => ({
        ...fixture,
        brief: { ...fixture.brief }
    }));
}

module.exports = { FIXTURES, getBenchmarkFixtures };
