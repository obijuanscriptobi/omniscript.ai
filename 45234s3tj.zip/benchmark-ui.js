"use strict";

(() => {
    const STORAGE_KEY = "studio-benchmark-baseline";
    const get = (id) => document.getElementById(id);
    let lastReport = null;

    function currentFiles() {
        return window.workspaceAPI?.getState?.().files || {};
    }

    function audit(files) {
        if (window.workspaceCore?.auditSite) return window.workspaceCore.auditSite(files);
        const html = String(files["index.html"] || "");
        return {
            hasDoctype: /^\s*<!doctype\s+html>/i.test(html),
            hasLanguage: /<html\b[^>]*\blang=["'][^"']+["']/i.test(html),
            hasViewport: /<meta\b[^>]+name=["']viewport["']/i.test(html),
            h1Count: (html.match(/<h1\b/gi) || []).length,
            missingAlt: /<img\b(?![^>]*\balt\s*=)/i.test(html),
            hasStructuredData: /<script\b[^>]+type=["']application\/ld\+json["']/i.test(html),
            hasSocialMetadata: /<meta\b[^>]+property=["']og:title["']/i.test(html) && /<meta\b[^>]+property=["']og:description["']/i.test(html),
            localReferences: []
        };
    }

    function report(files) {
        const html = String(files["index.html"] || "");
        const site = audit(files);
        const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
        const conversion = /<form\b[^>]*action=["'][^"']+|href=["'](?:tel:|mailto:|https?:\/\/|#[^"']+)["']/i.test(html);
        const scores = {
            conversion: conversion ? 100 : 0,
            content: /<h1\b[^>]*>\s*[^<]+/i.test(html) && text.length >= 240 ? 100 : 50,
            accessibility: site.missingAlt || site.h1Count !== 1 ? 45 : 100,
            performance: /<script\b[^>]+src=["']https?:/i.test(html) ? 70 : 100,
            reliability: html && !/\b(?:eval|new\s+Function)\s*\(/.test(Object.values(files).join("\n")) ? 100 : 0,
            speed: Math.max(0, 100 - Math.round(Object.values(files).reduce((sum, value) => sum + String(value || "").length, 0) / 100000))
        };
        const overall = Math.round(Object.values(scores).reduce((sum, value) => sum + value, 0) / 6);
        const gates = [
            ["HTML document exists", Boolean(html.trim()), "Create or import index.html."],
            ["Exactly one primary heading", site.h1Count === 1, "Keep one clear H1 on the homepage."],
            ["Images have alt text", !site.missingAlt, "Add descriptive alt text to every image."],
            ["Responsive metadata exists", site.hasViewport, "Add a viewport meta tag."],
            ["Primary conversion path exists", conversion, "Connect a form, phone, email, booking, or purchase CTA."],
            ["No broken local references", site.localReferences.length === 0, `Fix: ${site.localReferences.join(", ") || "none"}.`]
        ].map(([name, pass, fix]) => ({ name, pass, fix }));
        const responsive = window.workspaceResponsive?.auditResponsiveSource?.(html, String(files["style.css"] || "")) || [];
        const responsiveDefects = responsive.filter((entry) => entry.severity === "error" || entry.blocking).length;
        const accessibilityIssues = [site.missingAlt, site.h1Count !== 1, !site.hasLanguage].filter(Boolean).length;
        const seoCompleteness = [site.hasDoctype, site.hasLanguage, site.hasViewport, site.hasStructuredData, site.hasSocialMetadata].filter(Boolean).length * 20;
        const timing = window.workspaceBenchmarkTiming;
        const measuredGenerationMs = Number(timing?.generationMs);
        return {
            generatedAt: new Date().toISOString(),
            overall,
            scores,
            gates,
            publishable: gates.every((gate) => gate.pass),
            audit: site,
            metrics: {
                generationMs: Number.isFinite(measuredGenerationMs) && measuredGenerationMs >= 0
                    ? Math.round(measuredGenerationMs)
                    : null,
                responsiveDefects,
                accessibilityIssues,
                seoCompleteness,
                manualEdits: Number(window.workspaceAPI?.getState?.().manualEditCount || 0),
                manualEditsRecorded: Number.isFinite(Number(window.workspaceAPI?.getState?.().manualEditCount))
            }
        };
    }

    function baseline() {
        try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "null"); } catch { return null; }
    }

    function render(reportData) {
        lastReport = reportData;
        const score = get("quality-score");
        const label = get("quality-score-label");
        if (score) { score.textContent = `${reportData.overall}/100`; score.dataset.scoreState = reportData.publishable ? "excellent" : "needs-attention"; }
        if (label) label.textContent = reportData.publishable ? "Technical benchmark gates pass; this is not a conversion guarantee or competitor ranking." : `${reportData.gates.filter((gate) => !gate.pass).length} technical gate(s) need attention.`;
        const mapping = { content: "content-score", conversion: "conversion-score", accessibility: "accessibility-score", performance: "performance-score" };
        Object.entries(mapping).forEach(([category, id]) => { if (get(id)) get(id).textContent = `${reportData.scores[category]}/100`; });
        if (get("seo-score")) get("seo-score").textContent = `${reportData.metrics.seoCompleteness}/100`;
        const details = get("diagnostic-details");
        if (details) details.replaceChildren(...reportData.gates.map((gate) => {
            const item = document.createElement("li");
            item.dataset.priority = gate.pass ? "low" : "high";
            const strong = document.createElement("strong");
            strong.textContent = `${gate.pass ? "PASS" : "FIX"} — ${gate.name}`;
            const explanation = document.createElement("span");
            explanation.textContent = gate.pass ? "Ready for this check." : gate.fix;
            item.append(strong, explanation);
            return item;
        }));
        const metricsHost = get("benchmark-metrics");
        if (metricsHost) {
            const metrics = reportData.metrics;
            metricsHost.replaceChildren(...[
                ["Generation", metrics.generationMs === null ? "Not recorded" : `${metrics.generationMs} ms`],
                ["Responsive defects", String(metrics.responsiveDefects)],
                ["Accessibility issues", String(metrics.accessibilityIssues)],
                ["SEO completeness", `${metrics.seoCompleteness}%`],
                ["Manual edits", metrics.manualEditsRecorded ? String(metrics.manualEdits) : "Not recorded"]
            ].map(([label, value]) => {
                const item = document.createElement("div");
                item.className = "benchmark-metric";
                if (value === "Not recorded") item.dataset.state = "unavailable";
                item.innerHTML = `<strong>${label}</strong><span>${value}</span>`;
                return item;
            }));
            metricsHost.hidden = false;
        }
        return reportData;
    }

    function run() {
        const result = render(report(currentFiles()));
        const previous = baseline();
        const change = previous ? result.overall - previous.overall : null;
        const message = change === null
            ? "Technical benchmark complete; this is workspace evidence, not a competitor ranking."
            : `Technical benchmark complete (${change >= 0 ? "+" : ""}${change} points vs saved baseline); this is not a competitor ranking.`;
        get("aiDebuggerFeedback") && (get("aiDebuggerFeedback").textContent = message);
        window.dispatchEvent(new CustomEvent("workspace:benchmark-complete", { detail: result }));
        return result;
    }

    function saveBaseline() {
        const result = lastReport || run();
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(result)); } catch {}
        get("aiDebuggerFeedback") && (get("aiDebuggerFeedback").textContent = "Benchmark baseline saved. Future checks will show score changes.");
    }

    function exportReport() {
        const result = lastReport || run();
        const payload = { ...result, projectName: window.workspaceAPI?.getState?.().projectName || "Untitled project", evidence: { scope: "local structural and configured rendered checks", limitations: ["not a conversion guarantee", "not full device coverage", "not an external competitor comparison", "does not prove real form delivery"] } };
        const link = document.createElement("a");
        link.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
        link.download = "website-benchmark-report.json";
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 0);
    }

    function bind() {
        get("run-quality-check-btn")?.addEventListener("click", run);
        get("save-benchmark-baseline-btn")?.addEventListener("click", saveBaseline);
        get("export-benchmark-report-btn")?.addEventListener("click", exportReport);
        window.addEventListener("workspace:files-changed", () => window.setTimeout(run, 0));
        window.addEventListener("workspace:benchmark-request", run);
        const homepage = String(currentFiles()["index.html"] || "").trim();
        if (homepage && !homepage.startsWith("<!-- Awaiting") && !homepage.startsWith("# Awaiting")) run();
        window.workspaceBenchmark = { audit, report, run, saveBaseline, exportReport };
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
