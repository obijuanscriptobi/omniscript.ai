"use strict";

const { qualityReport } = require("./workspace-quality.js");

const CATEGORIES = Object.freeze([
    "conversion",
    "content",
    "accessibility",
    "performance",
    "reliability",
    "speed"
]);

const DEFAULT_WEIGHTS = Object.freeze({
    conversion: 25,
    content: 20,
    accessibility: 15,
    performance: 15,
    reliability: 15,
    speed: 10
});

const REQUIRED_BRIEF_FIELDS = Object.freeze([
    "businessName",
    "audience",
    "offer",
    "outcome",
    "primaryAction"
]);

const ACTION_DESTINATIONS = Object.freeze({
    booking: ["bookingUrl", "formAction"],
    call: ["phone"],
    enquiry: ["email", "formAction"],
    quote: ["formAction", "email", "phone"],
    purchase: ["shopUrl"]
});

function clamp(value, minimum = 0, maximum = 100) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(maximum, Math.max(minimum, number)) : minimum;
}

function clean(value) {
    return typeof value === "string" ? value.trim() : "";
}

function issue(code, message, field = "") {
    return { code, message, ...(field ? { field } : {}) };
}

function normalizeBrief(input = {}) {
    const brief = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const primaryAction = clean(brief.primaryAction).toLowerCase() || "enquiry";
    return {
        businessName: clean(brief.businessName),
        audience: clean(brief.audience),
        offer: clean(brief.offer),
        outcome: clean(brief.outcome),
        location: clean(brief.location),
        differentiator: clean(brief.differentiator),
        primaryAction,
        bookingUrl: clean(brief.bookingUrl),
        phone: clean(brief.phone),
        email: clean(brief.email),
        formAction: clean(brief.formAction),
        shopUrl: clean(brief.shopUrl),
        proof: Array.isArray(brief.proof) ? brief.proof.map(clean).filter(Boolean) : []
    };
}

function validateBrief(input) {
    const brief = normalizeBrief(input);
    const issues = [];
    for (const field of REQUIRED_BRIEF_FIELDS) {
        const missing = field === "primaryAction"
            ? !clean(input?.primaryAction)
            : !brief[field];
        if (missing) issues.push(issue("BRIEF_FIELD_REQUIRED", `${field} is required.`, field));
    }
    if (clean(input?.primaryAction) && !Object.prototype.hasOwnProperty.call(ACTION_DESTINATIONS, brief.primaryAction)) {
        issues.push(issue("UNKNOWN_PRIMARY_ACTION", `Unsupported primary action: ${brief.primaryAction}.`, "primaryAction"));
    } else if (clean(input?.primaryAction) && !ACTION_DESTINATIONS[brief.primaryAction].some((field) => brief[field])) {
        issues.push(issue("ACTION_DESTINATION_REQUIRED", `Primary action “${brief.primaryAction}” needs a usable destination.`, "primaryAction"));
    }
    if (brief.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(brief.email)) {
        issues.push(issue("INVALID_EMAIL", "Provide a valid email address.", "email"));
    }
    for (const field of ["bookingUrl", "formAction", "shopUrl"]) {
        if (!brief[field]) continue;
        try {
            const url = new URL(brief[field]);
            if (!["http:", "https:"].includes(url.protocol) || !url.hostname || url.username || url.password || url.hash) throw new Error("invalid destination");
        } catch {
            issues.push(issue("INVALID_DESTINATION", `${field} must be a valid HTTP(S) URL without credentials or fragments.`, field));
        }
    }
    return { valid: issues.length === 0, brief, issues };
}

function fileText(files) {
    const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
    return Object.entries(sourceFiles)
        .map(([name, content]) => `${name}\n${String(content ?? "")}`)
        .join("\n");
}

function auditSite(files = {}) {
    const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
    const html = clean(sourceFiles["index.html"]);
    const localReferences = [];
    const normalize = (target) => target.replace(/^\/+/, "");
    const resolve = (target) => {
        try {
            return decodeURIComponent(new URL(target, "https://workspace.invalid/index.html").pathname).replace(/^\/+/, "");
        } catch {
            return normalize(target);
        }
    };
    const known = new Set(Object.keys(sourceFiles).map(normalize));
    const addReference = (target) => {
        const value = String(target || "").trim();
        if (!value || value === "/" || value.startsWith("#") || /^(?:https?:|mailto:|tel:|data:|javascript:|\/\/)/i.test(value)) return;
        const resolvedTarget = resolve(value);
        if (!known.has(resolvedTarget)) localReferences.push(value);
    };
    for (const match of html.matchAll(/\b(?:href|src)=["']([^"']+)["']/gi)) addReference(match[1].split(/[?#]/)[0]);
    for (const match of html.matchAll(/\bsrcset=["']([^"']+)["']/gi)) {
        match[1].split(",").forEach((candidate) => addReference(candidate.trim().split(/\s+/)[0]));
    }
    return {
        hasDoctype: /^\s*<!doctype\s+html>/i.test(html),
        hasLanguage: /<html\b[^>]*\blang=["'][^"']+["']/i.test(html),
        hasViewport: /<meta\b[^>]*\bname\s*=\s*["']viewport["'][^>]*>/i.test(html),
        h1Count: (html.match(/<h1\b/gi) || []).length,
        missingAlt: /<img\b(?![^>]*\balt\s*=\s*["'][^"']*["'])[^>]*>/i.test(html),
        localReferences,
        hasStructuredData: /<script\b[^>]*type=["']application\/ld\+json["']/i.test(html),
        hasSocialMetadata: /<meta\b[^>]+property=["']og:title["']/i.test(html)
    };
}

function hasConversionPath(html) {
    return /<form\b[^>]*action=["'][^"']+|href=["'](?:tel:|mailto:|https?:\/\/)[^"']+["']/i.test(html);
}

function scoreTechnicalSite(files) {
    const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
    const report = qualityReport(sourceFiles);
    const html = String(sourceFiles["index.html"] ?? "");
    const css = String(sourceFiles["style.css"] ?? sourceFiles["styles.css"] ?? "");
    const js = String(sourceFiles["script.js"] ?? "");
    const errors = report.issues.filter((entry) => entry.severity === "error").length;
    const warnings = report.issues.filter((entry) => entry.severity === "warning").length;
    const scores = {
        conversion: hasConversionPath(html) ? 100 : 0,
        content: /<h1\b[^>]*>\s*[^<]+/i.test(html) && html.replace(/<[^>]+>/g, " ").trim().length >= 240 ? 100 : 50,
        accessibility: Math.max(0, 100 - errors * 35 - warnings * 8),
        performance: Math.max(0, 100 - (/<script\b[^>]+src=["']https?:/i.test(html) ? 30 : 0) - (css.length > 50000 ? 25 : 0)),
        reliability: errors === 0 && Boolean(String(sourceFiles["index.html"] ?? "").trim()) ? 100 : Math.max(0, 100 - errors * 40),
        speed: Math.max(0, 100 - Math.round(Object.values(sourceFiles).reduce((sum, value) => sum + Buffer.byteLength(String(value ?? ""), "utf8"), 0) / 100000))
    };
    if (/\b(?:eval|new\s+Function)\s*\(/.test(fileText(sourceFiles))) scores.reliability = 0;
    return { scores, quality: report };
}

function normalizeScores(input = {}) {
    const scores = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    return Object.fromEntries(CATEGORIES.map((category) => [category, clamp(scores[category])]));
}

function validateWeights(input = DEFAULT_WEIGHTS) {
    const weights = normalizeScores(input);
    const total = Object.values(weights).reduce((sum, value) => sum + value, 0);
    if (!total) return { valid: false, weights: DEFAULT_WEIGHTS, issues: [issue("WEIGHTS_EMPTY", "At least one benchmark weight is required.")] };
    return { valid: true, weights: Object.fromEntries(CATEGORIES.map((category) => [category, (weights[category] / total) * 100])), issues: [] };
}

function scoreBenchmark(input = {}) {
    const options = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const technical = scoreTechnicalSite(options.files && typeof options.files === "object" && !Array.isArray(options.files) ? options.files : {});
    const manualEdits = Number(options.manualEdits);
    const evidence = {
        generationMs: Number.isFinite(Number(options.generationMs)) ? Math.max(0, Number(options.generationMs)) : null,
        manualEdits: Number.isFinite(manualEdits) ? Math.max(0, manualEdits) : null,
        source: options.evidenceSource || "local structural audit"
    };
    const humanScores = options.humanScores && typeof options.humanScores === "object" ? options.humanScores : {};
    const observedMetrics = options.observedMetrics && typeof options.observedMetrics === "object" ? options.observedMetrics : {};
    const human = normalizeScores(humanScores);
    const observed = normalizeScores(observedMetrics);
    const scores = {};
    for (const category of CATEGORIES) {
        const parts = [technical.scores[category]];
        if (Object.prototype.hasOwnProperty.call(humanScores, category)) parts.push(human[category]);
        if (Object.prototype.hasOwnProperty.call(observedMetrics, category)) parts.push(observed[category]);
        scores[category] = Math.round(parts.reduce((sum, value) => sum + value, 0) / parts.length);
    }
    const { weights } = validateWeights(options.weights);
    const overall = Math.round(CATEGORIES.reduce((sum, category) => sum + scores[category] * weights[category], 0) / 100);
    const blocking = technical.quality.blocking;
    return {
        overall,
        scores,
        weights,
        gates: {
            noBlockingQualityIssues: blocking.length === 0,
            primaryConversionPath: scores.conversion >= 50,
            technicallyPublishable: Boolean(options.files && typeof options.files === "object" && String(options.files["index.html"] ?? "").trim()) && blocking.length === 0
        },
        publishable: blocking.length === 0 && scores.conversion >= 50,
        quality: technical.quality,
        evidence
    };
}

function aggregateBenchmark(entries = []) {
    const results = Array.isArray(entries) ? entries.filter(Boolean) : [];
    if (!results.length) return { count: 0, averages: normalizeScores(), overall: 0, passRate: 0, results: [] };
    const averages = Object.fromEntries(CATEGORIES.map((category) => [category, Math.round(results.reduce((sum, result) => sum + clamp(result.scores?.[category]), 0) / results.length)]));
    return {
        count: results.length,
        averages,
        overall: Math.round(results.reduce((sum, result) => sum + clamp(result.overall), 0) / results.length),
        passRate: Math.round((results.filter((result) => {
            const gates = result && result.gates && typeof result.gates === "object" ? Object.values(result.gates) : [];
            return result.publishable === true && gates.length > 0 && gates.every(Boolean);
        }).length / results.length) * 100),
        results
    };
}

function createRegressionCase(input = {}) {
    const options = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const id = clean(options.id);
    if (!id || !/^[-a-z0-9_]+$/i.test(id)) throw new TypeError("Regression case id must contain only letters, numbers, hyphens, or underscores.");
    const files = options.files && typeof options.files === "object" && !Array.isArray(options.files) ? { ...options.files } : {};
    const score = scoreBenchmark({ files });
    return {
        id,
        brief: normalizeBrief(options.brief),
        files,
        expected: {
            publishable: Boolean(options.expected?.publishable ?? score.publishable),
            maxBlockingIssues: Number.isInteger(options.expected?.maxBlockingIssues) ? options.expected.maxBlockingIssues : 0
        },
        baseline: { overall: score.overall, blockingIssues: score.quality.blocking.length }
    };
}

function runRegressionCase(regressionCase) {
    const score = scoreBenchmark({ files: regressionCase?.files || {} });
    const maxBlockingIssues = regressionCase?.expected?.maxBlockingIssues ?? 0;
    return {
        id: regressionCase?.id || "unknown",
        pass: score.publishable === Boolean(regressionCase?.expected?.publishable) && score.quality.blocking.length <= maxBlockingIssues,
        score,
        failures: [
            ...(score.publishable !== Boolean(regressionCase?.expected?.publishable) ? ["PUBLISHABILITY_MISMATCH"] : []),
            ...(score.quality.blocking.length > maxBlockingIssues ? ["BLOCKING_ISSUES_EXCEEDED"] : [])
        ]
    };
}

module.exports = {
    CATEGORIES,
    DEFAULT_WEIGHTS,
    aggregateBenchmark,
    createRegressionCase,
    normalizeBrief,
    runRegressionCase,
    scoreBenchmark,
    scoreTechnicalSite,
    auditSite,
    validateBrief,
    validateWeights
};
