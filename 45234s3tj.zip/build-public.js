"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = __dirname;
const output = path.join(root, "public");
const entryFiles = [
    "404.html", "home.html", "index.html", "ad-studio.html", "audit.html",
    "leads.html", "todo.html", "account.html", "business-profile.html",
    "privacy.html", "terms.html", "acceptable-use.html", "approval.html",
    "invitation.html", "preview.html", "launch.html", "portal.html",
    "proposal.html", "site.webmanifest", "favicon.svg", "social-card.svg", "robots.txt"
];
const publicExtensions = new Set([
    ".html", ".htm", ".css", ".js", ".json", ".webmanifest", ".svg",
    ".png", ".jpg", ".jpeg", ".webp", ".avif", ".gif", ".ico",
    ".woff", ".woff2", ".ttf", ".otf", ".xml", ".txt", ".mp4", ".webm"
]);
const forbidden = [
    /^package(?:-lock)?\.json$/i, /^netlify\.toml$/i, /^\.env/i,
    /^(?:test|docs|supabase|netlify|\.github)(?:\/|$)/i, /^netlify_functions_/i, /^readiness\.html$/i,
    /^release-readiness\.js$/i, /^styles\/readiness-center\.css$/i,
    /^(?:build-public|syntax-audit|dependency-lock-audit|codewise-release-gate|visual-audit-runner|visual-audit-workflow|staging-real-adapter|staging-fixture)\.js$/i
];
const referencePattern = /["'`]((?:\.?\.?\/|\/)?[a-zA-Z0-9_./-]+\.(?:html?|css|js|json|webmanifest|svg|png|jpe?g|webp|avif|gif|ico|woff2?|ttf|otf|xml|txt|mp4|webm))(?:[?#][^"'`]*)?["'`]/g;

function normalizeReference(from, reference) {
    if (/^(?:https?:|data:|blob:|mailto:|tel:|javascript:|\/\/)/i.test(reference)) return "";
    const clean = reference.replace(/^\//, "");
    const resolved = path.posix.normalize(reference.startsWith("/") ? clean : path.posix.join(path.posix.dirname(from), clean));
    return resolved.startsWith("../") || path.isAbsolute(resolved) ? "" : resolved;
}

function isForbidden(file) {
    return forbidden.some((pattern) => pattern.test(file));
}

function discover() {
    const queue = [...entryFiles];
    const files = new Set();
    const missing = [];
    while (queue.length) {
        const file = queue.shift();
        if (!file || files.has(file) || isForbidden(file)) continue;
        const absolute = path.join(root, file);
        if (!fs.existsSync(absolute) || !fs.statSync(absolute).isFile()) {
            missing.push(file);
            continue;
        }
        if (!publicExtensions.has(path.extname(file).toLowerCase())) continue;
        files.add(file);
        const extension = path.extname(file).toLowerCase();
        if (![".html", ".htm", ".css", ".js", ".json", ".webmanifest", ".svg"].includes(extension)) continue;
        const source = fs.readFileSync(absolute, "utf8");
        for (const match of source.matchAll(referencePattern)) {
            const dependency = normalizeReference(file, match[1]);
            if (!dependency || files.has(dependency) || isForbidden(dependency)) continue;
            const dependencyExists = fs.existsSync(path.join(root, dependency));
            // JavaScript contains generated-site filenames and examples that are
            // not application assets. Follow existing dynamic module references,
            // while HTML/CSS/manifest references remain mandatory.
            if (dependencyExists || extension !== ".js") queue.push(dependency);
        }
    }
    if (missing.length) throw new Error(`Missing public runtime files:\n- ${[...new Set(missing)].sort().join("\n- ")}`);
    return [...files].sort();
}

function validateRoutes(files) {
    const config = fs.readFileSync(path.join(root, "netlify.toml"), "utf8");
    const redirects = [...config.matchAll(/from\s*=\s*"(\/api\/[^"]+)"[\s\S]*?to\s*=\s*"\/\.netlify\/functions\/([^"/]+)"/g)];
    const missingFunctions = redirects
        .filter(([, route]) => !route.includes("*"))
        .filter(([, , name]) => !fs.existsSync(path.join(root, "netlify", "functions", `${name}.js`)))
        .map(([, route, name]) => `${route} -> ${name}.js`);
    if (missingFunctions.length) throw new Error(`API redirects without functions:\n- ${missingFunctions.join("\n- ")}`);

    const leaked = files.filter(isForbidden);
    if (leaked.length) throw new Error(`Forbidden files entered the public build:\n- ${leaked.join("\n- ")}`);
}

function build() {
    const files = discover();
    validateRoutes(files);
    fs.rmSync(output, { recursive: true, force: true });
    files.forEach((file) => {
        const destination = path.join(output, file);
        fs.mkdirSync(path.dirname(destination), { recursive: true });
        fs.copyFileSync(path.join(root, file), destination);
    });
    fs.writeFileSync(path.join(output, "PUBLIC-BUILD-MANIFEST.json"), `${JSON.stringify({ schemaVersion: 1, files }, null, 2)}\n`);

    const { inspectPublicBuild } = require("./public-release-audit.js");
    const audit = inspectPublicBuild(output);
    if (!audit.ok) throw new Error(`Public release audit failed:\n${audit.findings.map((item) => `- ${item.code} ${item.file}: ${item.message}`).join("\n")}`);
    process.stdout.write(`Public build contains ${files.length} allowlisted runtime files; ${audit.inventory.references} references passed exposure and CSP checks.\n`);
}

build();
