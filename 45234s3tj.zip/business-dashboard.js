"use strict";

// Local-first command center for the website-maker workspace.
(() => {
    const BASE_TASKS_KEY = "morrow-business-tasks-v1";
    const taskKey = () => window.workspaceContext?.storageKey?.(BASE_TASKS_KEY) || BASE_TASKS_KEY;
    const STATUSES = ["new", "qualified", "discovery", "demo", "proposal", "negotiation", "won", "lost"];
    const $ = (id) => document.getElementById(id);
    const esc = (value) => String(value ?? "").replace(/[&<>\"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[char]));
    const readTasks = () => { try { const value = JSON.parse(localStorage.getItem(taskKey()) || "[]"); return Array.isArray(value) ? value : []; } catch (_) { return []; } };
    const writeTasks = (tasks) => { try { localStorage.setItem(taskKey(), JSON.stringify(tasks.slice(0, 200))); } catch (_) {} window.dispatchEvent(new CustomEvent("business-dashboard:updated")); };
    const tasks = () => readTasks().filter((task) => !task.done && task.dueAt && new Date(task.dueAt) <= new Date(Date.now() + 7 * 86400000));
    const leads = () => window.workspaceCRM?.read?.() || [];

    function ensureFollowUp(lead) {
        if (!lead?.id) return;
        const current = readTasks();
        if (current.some((task) => task.leadId === lead.id && !task.done)) return;
        const createdAt = new Date().toISOString();
        writeTasks([{ id: `task-${lead.id}`, leadId: lead.id, title: `Follow up with ${lead.name || "new lead"}`, dueAt: lead.nextAction?.dueDate ? `${lead.nextAction.dueDate}T09:00:00.000Z` : (lead.reminderAt || new Date(Date.now() + 2 * 86400000).toISOString()), owner: lead.assignedTo || "sales", done: false, createdAt }, ...current]);
        const operations = window.businessOperations?.read?.();
        if (operations && window.businessOperations?.save && !operations.notifications.some((item) => item.type === "new-lead" && item.leadId === lead.id)) {
            operations.notifications.unshift({ id: `notice-lead-${lead.id}`, type: "new-lead", leadId: lead.id, label: `New lead: ${lead.name || lead.email || "Website inquiry"}`, detail: "Acknowledgment recommended; follow-up task created.", at: createdAt, read: false });
            window.businessOperations.save(operations);
        }
    }

    function renderAttention() {
        const list = $("command-attention-list");
        if (!list) return;
        const currentLeads = leads();
        const metrics = salesMetrics(currentLeads);
        const stalled = currentLeads.filter((lead) => !["won", "lost"].includes(lead.status) && (ageDays(lead) >= 7 || !lead.nextAction?.title || isOverdue(lead) || (lead.status === "proposal" && !["accepted", "declined"].includes(lead.proposal?.status)) || (lead.status === "negotiation" && ageDays(lead) >= 3)));
        const items = [
            ...currentLeads.filter((lead) => lead.status === "new").slice(0, 3).map((lead) => ({ title: `Reply to ${lead.name || "new inquiry"}`, detail: lead.source || "Website inquiry", action: "crm" })),
            ...stalled.slice(0, 6).map((lead) => ({ title: `${lead.name || "Lead"}: ${ageDays(lead) >= 7 ? "No activity for 7+ days" : isOverdue(lead) ? "Overdue next action" : !lead.nextAction?.title ? "No next action" : lead.status === "proposal" ? "Proposal awaiting response" : "Negotiation needs a recent note"}`, detail: `${lead.status} · ${lead.company || lead.source || "No account"}`, action: "crm" })),
            ...tasks().slice(0, 3).map((task) => ({ title: task.title, detail: `Due ${new Date(task.dueAt).toLocaleDateString()}`, action: "tasks" }))
        ];
        list.replaceChildren(...(items.length ? items.map((item) => { const li = document.createElement("li"); li.innerHTML = `<strong>${esc(item.title)}</strong><span>${esc(item.detail)}</span>`; return li; }) : [Object.assign(document.createElement("li"), { className: "command-empty", textContent: "No urgent actions. Your workspace is clear." })]));
    }

    function renderPipeline() {
        const root = $("crm-pipeline");
        if (!root) return;
        const currentLeads = leads();
        root.replaceChildren(...STATUSES.map((status) => {
            const column = document.createElement("section");
            column.className = "crm-pipeline-column";
            const matches = currentLeads.filter((lead) => lead.status === status);
            const labels = { new: "New prospect", qualified: "Qualified", discovery: "Discovery", demo: "Demo / presentation", proposal: "Proposal", negotiation: "Negotiation", won: "Won", lost: "Lost" };
            column.innerHTML = `<div class="crm-column-heading"><strong>${labels[status]}</strong><span>${matches.length}</span></div>`;
            matches.slice(0, 8).forEach((lead) => {
                const card = document.createElement("article");
                card.className = "crm-lead-card";
                card.dataset.leadId = lead.id;
                card.innerHTML = `<button type="button" class="crm-lead-open" data-open-lead="${esc(lead.id)}"><strong>${esc(lead.name || "Unnamed inquiry")} ${lead.unread ? "<em class=\"crm-unread-badge\">Unread</em>" : ""}</strong><span>${esc(lead.email || lead.source || "No contact details")}</span></button><select class="matrix-text-field" data-crm-status aria-label="Update ${esc(lead.name || "lead")} status">${STATUSES.map((option) => `<option value="${option}" ${option === lead.status ? "selected" : ""}>${option}</option>`).join("")}</select><textarea class="matrix-text-area-field" data-crm-notes rows="2" placeholder="Private notes">${esc(lead.notes)}</textarea><button type="button" class="matrix-action-btn variant-outline-row" data-open-lead="${esc(lead.id)}">Open sales record</button>`;
                column.append(card);
            });
            return column;
        }));
    }

    function renderCustomer(lead) {
        const drawer = $("crm-customer-drawer");
        if (!drawer || !lead) return;
        const relatedTasks = readTasks().filter((task) => task.leadId === lead.id && !task.done);
        const operations = window.businessOperations?.read?.() || { projects: [], proposals: [] };
        const relatedProjects = operations.projects.filter((project) => project.leadId === lead.id);
        const relatedProposals = operations.proposals.filter((proposal) => proposal.leadId === lead.id || proposal.customerId === lead.id);
        const activity = (lead.activity || []).slice(0, 12);
        const brief = window.workspaceCRM?.buildCallBrief?.(lead) || lead.opportunity || {};
        const report = brief.report || {};
        const offer = lead.offer || {};
        const preview = lead.preview || {};
        const packages = window.workspaceCRM?.OFFER_PACKAGES || {};
        const packageOptions = Object.entries(packages).map(([key, item]) => `<option value="${esc(key)}" ${key === offer.packageKey ? "selected" : ""}>${esc(item.name)} — $${item.price.toLocaleString()}</option>`).join("");
        drawer.hidden = false;
        drawer.dataset.leadId = lead.id;
        const callOutcomes = window.workspaceCRM?.CALL_OUTCOMES || {};
        const callButtons = Object.entries(callOutcomes).map(([key, outcome]) => `<button type="button" class="matrix-action-btn variant-outline-row crm-call-outcome" data-call-outcome="${esc(key)}">${esc(outcome.label)}</button>`).join("");
        drawer.innerHTML = `<div class="customer-drawer-heading"><div><p class="eyebrow-label">Customer workspace</p><h3>${esc(lead.name || "Unnamed inquiry")}</h3><p>${esc(lead.company || "Individual contact")} · ${esc(lead.email || "No email")}</p></div><button type="button" class="matrix-action-btn variant-outline-row" data-close-customer>Close</button></div><div class="customer-summary-grid"><div><strong>Pipeline</strong><span>${esc(lead.status)}</span></div><div><strong>Source</strong><span>${esc(lead.source)}</span></div><div><strong>Campaign</strong><span>${esc(lead.campaign || lead.utmCampaign || "Not attributed")}</span></div><div><strong>Owner</strong><span>${esc(lead.assignedTo || "Unassigned")}</span></div></div><label class="field-label-tag" for="customer-phone">Phone</label><input id="customer-phone" class="matrix-text-field" value="${esc(lead.phone)}" data-customer-field="phone"><section><h4 class="command-section-title">Call outcome</h4><p class="field-descriptor-text">Choose the result of the latest call to update the pipeline and create the next follow-up automatically.</p><div class="crm-call-outcomes">${callButtons}</div><textarea class="matrix-text-area-field" rows="2" data-call-note placeholder="Optional call note"></textarea></section><label class="field-label-tag" for="customer-company">Company</label><input id="customer-company" class="matrix-text-field" value="${esc(lead.company)}" data-customer-field="company"><label class="field-label-tag" for="customer-owner">Assigned team member</label><input id="customer-owner" class="matrix-text-field" value="${esc(lead.assignedTo)}" placeholder="Assign an owner" data-customer-field="assignedTo"><section><h4 class="command-section-title">Cold-call brief</h4><p class="customer-message">${esc(brief.openingLine || "Add an audit to generate a call opener.")}</p><div class="customer-summary-grid"><div><strong>Offer</strong><span>${esc(brief.suggestedOffer || "Scope after discovery")}</span></div><div><strong>Price</strong><span>${esc(brief.priceRange || "Not set")}</span></div></div><p class="field-descriptor-text"><strong>Problems:</strong> ${esc((brief.problems || []).join(" · ") || "No audit findings yet.")}</p><p class="field-descriptor-text"><strong>Business consequences:</strong> ${esc((brief.consequences || []).join(" · ") || "Add plain-English impact statements.")}</p><p class="field-descriptor-text"><strong>Recommendations:</strong> ${esc((brief.recommendations || []).join(" · ") || "Add recommended improvements.")}</p></section><section class="offer-builder-card"><h4 class="command-section-title">Fixed-scope offer builder</h4><p class="field-descriptor-text">Turn the audit into a clear package with a price, timeline, and defined revision limit.</p><select class="matrix-text-field" data-offer-package aria-label="Choose an offer package"><option value="">Choose a package</option>${packageOptions}</select><p class="field-descriptor-text"><strong>Selected:</strong> ${esc(offer.packageName || "No package selected")} · <strong>Price:</strong> ${offer.price ? `$${offer.price.toLocaleString()}` : "Not set"} · <strong>Timeline:</strong> ${esc(offer.timeline || "Not set")} · <strong>Revisions:</strong> ${offer.revisions || 0}</p><p class="field-descriptor-text"><strong>Includes:</strong> ${esc((offer.services || []).join(" · ") || "Choose a package to add a fixed scope.")}</p><button type="button" class="matrix-action-btn variant-gold-fill" data-save-offer="${esc(lead.id)}">Save offer to proposal</button></section><section class="preview-sales-card"><h4 class="command-section-title">Client preview</h4><p class="field-descriptor-text">Show the owner what changed, why it matters, and what to do next.</p><div class="preview-client-copy"><span class="preview-label">Client-facing headline</span><strong>${esc(preview.headline || "A clearer mobile experience")}</strong><p>${esc(preview.impact || "Make it easier for mobile visitors to understand the offer and take action.")}</p></div><div class="customer-summary-grid"><div><strong>Before</strong><span>${esc(preview.beforeLabel)}</span></div><div><strong>After</strong><span>${esc(preview.afterLabel)}</span></div><div><strong>Offer</strong><span>${esc(preview.offerName || "Not set")}</span></div><div><strong>Price</strong><span>${preview.price ? `$${preview.price.toLocaleString()}` : "Discuss scope"}</span></div><div><strong>Status</strong><span>${esc(preview.status || "Not created")}</span></div><div><strong>Expires</strong><span>${esc(preview.expiresAt ? new Date(preview.expiresAt).toLocaleDateString() : "7 days after sharing")}</span></div></div><p class="field-descriptor-text"><strong>Changes:</strong> ${esc((preview.changes || []).join(" · ") || "Create a preview from the recommendations.")}</p><div class="customer-preview-actions"><input class="matrix-text-field" value="${esc(preview.url || brief.previewUrl || "")}" data-preview-url placeholder="Private preview URL"><button type="button" class="matrix-action-btn variant-gold-fill" data-create-preview="${esc(lead.id)}">Create/share preview</button>${preview.status && preview.status !== "draft" ? `<button type="button" class="matrix-action-btn variant-outline-row" data-revoke-preview="${esc(lead.id)}">Revoke access</button>` : ""}</div><p class="field-descriptor-text">${preview.viewedAt ? `Viewed ${esc(new Date(preview.viewedAt).toLocaleString())}` : "Not viewed yet"}${preview.approvedAt ? ` · Approved ${esc(new Date(preview.approvedAt).toLocaleString())}` : ""}</p></section><section class="sales-report-card"><h4 class="command-section-title">Sales-ready audit report</h4><p class="field-descriptor-text">${esc(report.headline || "Run an audit to generate plain-English findings.")}${report.score !== null && report.score !== undefined ? ` · Mobile score: ${esc(report.score)}/100` : ""}</p><ol class="sales-report-findings">${(report.findings || []).map((finding) => `<li><strong><span class="sales-report-priority priority-${esc(finding.priority)}">${esc(finding.priority)}</span> ${esc(finding.problem)}</strong><span><b>Business impact:</b> ${esc(finding.impact)}</span><span><b>Recommendation:</b> ${esc(finding.recommendation)}${finding.effort ? ` · ${esc(finding.effort)}` : ""}</span></li>`).join("") || `<li class="command-empty">No findings yet. Add audit results to create a client-friendly report.</li>`}</ol><p class="field-descriptor-text"><strong>Offer:</strong> ${esc(report.offer || "Mobile conversion improvement package")} · <strong>Timeline:</strong> ${esc(report.timeline || "Set after discovery")}</p></section><section><h4 class="command-section-title">Qualification</h4><div class="customer-summary-grid"><label>Budget<select class="matrix-text-field" data-sales-field="qualification.budget"><option value="unknown">Unknown</option><option value="unconfirmed">Unconfirmed</option><option value="confirmed">Confirmed</option><option value="not-fit">Not a fit</option></select></label><label>Authority<select class="matrix-text-field" data-sales-field="qualification.authority"><option value="unknown">Unknown</option><option value="influencer">Influencer</option><option value="decision-maker">Decision maker</option><option value="committee">Committee</option></select></label><label>Need<select class="matrix-text-field" data-sales-field="qualification.need"><option value="unknown">Unknown</option><option value="exploring">Exploring</option><option value="active">Active</option><option value="urgent">Urgent</option></select></label><label>Timeline<select class="matrix-text-field" data-sales-field="qualification.timeline"><option value="unknown">Unknown</option><option value="90-plus-days">90+ days</option><option value="30-90-days">30–90 days</option><option value="under-30-days">Under 30 days</option></select></label></div><p class="field-descriptor-text">Qualification score: ${lead.qualification.score}/100</p></section><section><h4 class="command-section-title">Discovery and stakeholders</h4><textarea class="matrix-text-area-field" rows="3" data-sales-field="discovery.notes" placeholder="Discovery questions, pain points, goals">${esc(lead.discovery.notes)}</textarea><textarea class="matrix-text-area-field" rows="2" data-sales-field="discovery.stakeholdersText" placeholder="Stakeholders: name, role, email">${esc((lead.discovery.stakeholders || []).map((item) => [item.name, item.role, item.email].filter(Boolean).join(", ")).join("\n"))}</textarea></section><section><h4 class="command-section-title">Demo and proposal</h4><textarea class="matrix-text-area-field" rows="2" data-sales-field="demo.notes" placeholder="Demo notes">${esc(lead.demo.notes)}</textarea><textarea class="matrix-text-area-field" rows="2" data-sales-field="demo.objectionsText" placeholder="Objections, one per line">${esc(lead.demo.objections.join("\n"))}</textarea><input class="matrix-text-field" type="number" min="0" step="0.01" value="${lead.proposal.total || ""}" data-sales-field="proposal.total" placeholder="Proposal value"><input class="matrix-text-field" value="${esc(lead.proposal.contractNotes)}" data-sales-field="proposal.contractNotes" placeholder="Proposal revisions and contract notes"><p class="field-descriptor-text"><strong>Proposal status:</strong> ${esc(lead.proposal.status)}${lead.proposal.sentAt ? ` · Sent ${esc(new Date(lead.proposal.sentAt).toLocaleString())}` : ""}${lead.proposal.approvedAt ? ` · Approved ${esc(new Date(lead.proposal.approvedAt).toLocaleString())}` : ""}</p><button type="button" class="matrix-action-btn variant-gold-fill" data-deliver-proposal="${esc(lead.id)}">Send proposal for approval</button>${lead.proposal.approvalUrl ? `<a class="matrix-action-btn variant-outline-row" href="${esc(lead.proposal.approvalUrl)}" target="_blank" rel="noopener">Open approval link</a>` : ""}</section><section><h4 class="command-section-title">Opportunity links</h4><input class="matrix-text-field" value="${esc(lead.websiteUrl)}" data-sales-field="opportunity.auditUrl" placeholder="Website or audit URL"><input class="matrix-text-field" value="${esc(brief.previewUrl || "")}" data-sales-field="opportunity.previewUrl" placeholder="Private preview URL"><input class="matrix-text-field" value="${esc(brief.priceRange || "")}" data-sales-field="opportunity.priceRange" placeholder="Suggested price range"></section><section><h4 class="command-section-title">Close and handoff</h4><textarea class="matrix-text-area-field" rows="2" data-sales-field="closeReason" placeholder="Won/lost reason">${esc(lead.closeReason)}</textarea><p class="field-descriptor-text">${lead.handoffAt ? `Handoff recorded ${esc(lead.handoffAt)}` : "Winning this lead creates a project and onboarding checklist."}</p></section><section><h4 class="command-section-title">Next action</h4><input class="matrix-text-field" value="${esc(lead.nextAction.title)}" data-sales-field="nextAction.title" placeholder="Next sales action"><input class="matrix-text-field" type="date" value="${esc(lead.nextAction.dueDate)}" data-sales-field="nextAction.dueDate"><input class="matrix-text-field" value="${esc(lead.nextAction.owner)}" data-sales-field="nextAction.owner" placeholder="Owner"></section><section><h4 class="command-section-title">Original inquiry</h4><p class="customer-message">${esc(lead.message || "No message provided.")}</p></section><section><h4 class="command-section-title">Open tasks</h4><p class="field-descriptor-text">${relatedTasks.length ? relatedTasks.map((task) => esc(task.title)).join(" · ") : "No open tasks."}</p></section><section><h4 class="command-section-title">Projects and proposals</h4><p class="field-descriptor-text">${relatedProjects.length ? relatedProjects.map((project) => esc(project.name)).join(" · ") : "No projects yet."}${relatedProposals.length ? ` · ${relatedProposals.map((proposal) => esc(proposal.title)).join(" · ")}` : ""}</p></section><section><h4 class="command-section-title">Activity timeline</h4><ol class="customer-timeline">${activity.map((entry) => `<li><strong>${esc(entry.label || entry.type)}</strong><time>${new Date(entry.at).toLocaleString()}</time></li>`).join("")}</ol></section><button type="button" class="matrix-action-btn variant-gold-fill" data-convert-project="${esc(lead.id)}">Convert to project</button><p class="field-descriptor-text" data-customer-status></p>`;
    }

    function renderTasks() {
        const list = $("command-task-list");
        if (!list) return;
        const current = readTasks().filter((task) => !task.done).slice(0, 5);
        list.replaceChildren(...(current.length ? current.map((task) => { const li = document.createElement("li"); li.innerHTML = `<label><input type="checkbox" data-task-id="${esc(task.id)}"><span><strong>${esc(task.title)}</strong><small>${task.dueAt ? `Due ${new Date(task.dueAt).toLocaleDateString()}` : "No due date"}</small></span></label>`; return li; }) : [Object.assign(document.createElement("li"), { className: "command-empty", textContent: "No tasks yet. New leads automatically get a follow-up task." })]));
    }

    const validTime = (value) => { const time = Date.parse(value); return Number.isFinite(time) ? time : 0; };
    const ageDays = (lead) => Math.floor((Date.now() - validTime(lead.updatedAt || lead.createdAt)) / 86400000);
    const isOverdue = (lead) => lead.nextAction?.dueDate && new Date(`${lead.nextAction.dueDate}T23:59:59`) < new Date() && !["won", "lost"].includes(lead.status);
    function salesMetrics(currentLeads) {
        const closed = currentLeads.filter((lead) => ["won", "lost"].includes(lead.status));
        const won = currentLeads.filter((lead) => lead.status === "won");
        const qualified = currentLeads.filter((lead) => !["new", "lost"].includes(lead.status));
        const discoveryCalls = currentLeads.filter((lead) => lead.status === "discovery" || lead.discovery?.nextMeeting);
        const proposals = currentLeads.filter((lead) => ["proposal", "negotiation"].includes(lead.status));
        const closeDays = won.map((lead) => (validTime(lead.updatedAt) - validTime(lead.createdAt)) / 86400000).filter((days) => days >= 0);
        const stages = window.workspaceCRM?.STAGE_ORDER || STATUSES;
        const transitions = stages.slice(0, -1).map((stage, index) => { const from = currentLeads.filter((lead) => lead.status === stage || stages.indexOf(lead.status) > index).length; const to = currentLeads.filter((lead) => stages.indexOf(lead.status) > index).length; return { stage, next: stages[index + 1], rate: from ? Math.round((to / from) * 100) : 0 }; });
        const sourceMap = currentLeads.reduce((map, lead) => { const source = lead.utmSource || lead.source || "website"; map[source] = map[source] || { count: 0, revenue: 0, won: 0 }; map[source].count += 1; map[source].revenue += Number(lead.proposal?.total) || 0; if (lead.status === "won") map[source].won += 1; return map; }, {});
        return { newProspects: currentLeads.filter((lead) => lead.status === "new").length, qualificationRate: currentLeads.length ? Math.round((qualified.length / currentLeads.length) * 100) : 0, discoveryCalls: discoveryCalls.length, proposalValue: proposals.reduce((sum, lead) => sum + (Number(lead.proposal?.total) || 0), 0), overdue: currentLeads.filter(isOverdue).length, noNextAction: currentLeads.filter((lead) => !["won", "lost"].includes(lead.status) && !lead.nextAction?.title).length, winRate: closed.length ? Math.round((won.length / closed.length) * 100) : 0, averageClose: closeDays.length ? Math.round(closeDays.reduce((sum, days) => sum + days, 0) / closeDays.length) : 0, stalled: currentLeads.filter((lead) => !["won", "lost"].includes(lead.status) && (ageDays(lead) >= 7 || !lead.nextAction?.title || isOverdue(lead) || (lead.status === "proposal" && !["accepted", "declined"].includes(lead.proposal?.status)) || (lead.status === "negotiation" && ageDays(lead) >= 3))).length, transitions, sources: sourceMap };
    }

    const COMMAND_CHECKLIST = [
        ["content-review", "Review generated content", "Confirm the business facts, copy, claims, and calls to action.", "Review the draft and mark this complete when the content is accurate."],
        ["form-testing", "Test contact forms", "Submit a real test and confirm the destination receives it.", "Send a test submission, then record the delivery result."],
        ["domain-connection", "Connect the business domain", "Add the final customer-facing domain before publishing.", "Enter the domain in your hosting provider and return here when it is connected."],
        ["ssl-dns", "Verify DNS and SSL", "Confirm DNS points correctly and the site uses HTTPS.", "Check the HTTPS URL and DNS records before publishing."],
        ["responsive-check", "Check mobile and desktop layouts", "Review the most important pages at both screen sizes.", "Open the preview at mobile and desktop widths and look for clipped or missing content."],
        ["analytics-verification", "Verify analytics and conversion events", "Confirm page views and the primary conversion event are recorded.", "Trigger a page view and the primary CTA event in your analytics provider."],
        ["client-approval", "Approve the site before publishing", "Keep final content and publishing approval with the business owner.", "Request approval from the business owner and record the decision."],
        ["publish", "Publish the website", "Publish only after the important checks above are complete.", "Complete the required checks first; publishing remains blocked while attention items exist."]
    ];

    const checklistStatusLabel = { pending: "Pending", in_progress: "In progress", complete: "Complete", attention: "Needs attention" };
    function checklistVerification(key, snapshot) {
        if (key === "content-review" && snapshot.hasDraft) return { status: "in_progress", result: "Draft found; review is still required." };
        if (key === "responsive-check" && snapshot.hasDraft) return { status: "in_progress", result: "Draft is available for mobile and desktop review." };
        if (key === "publish" && !snapshot.deployment) return { status: "attention", result: "Publishing is blocked until required checks are complete." };
        if (["form-testing", "domain-connection", "ssl-dns", "analytics-verification", "client-approval"].includes(key) && snapshot.hasDraft) return { status: "pending", result: "No automatic verification recorded yet." };
        return { status: "pending", result: snapshot.hasDraft ? "Ready for this check." : "Create a draft to begin." };
    }

    function workspaceSnapshot() {
        const state = window.workspaceAPI?.getState?.() || {};
        const files = state.files || {};
        const deployment = Array.isArray(state.deploymentHistory) ? state.deploymentHistory[0] : null;
        return { state, files, deployment, hasDraft: Boolean(files["index.html"] && String(files["index.html"]).trim()) };
    }

    function readCommandChecklist() {
        const snapshot = workspaceSnapshot();
        const saved = Array.isArray(snapshot.state.launchChecklist) ? snapshot.state.launchChecklist : [];
        const savedByKey = new Map(saved.map((item) => [item.key, item]));
        return COMMAND_CHECKLIST.map(([key, label, help, action]) => {
            const savedItem = savedByKey.get(key) || {};
            const verification = checklistVerification(key, snapshot);
            const status = savedItem.status === "complete" ? "complete" : (savedItem.status || verification.status);
            return { key, label, help, action, status, result: savedItem.result || verification.result, checkedAt: savedItem.checkedAt || "" };
        });
    }

    function saveCommandChecklist(key, complete, status = "") {
        const state = window.workspaceAPI?.getState?.();
        if (!state) return;
        const checklist = readCommandChecklist().map((item) => item.key === key ? { ...item, status: complete ? "complete" : (status || "pending"), checkedAt: complete ? new Date().toISOString() : item.checkedAt, result: complete ? "Marked complete by the workspace owner." : item.result } : item);
        state.launchChecklist = checklist;
        try { localStorage.setItem("luxury-engine-workspace", JSON.stringify(state)); } catch (_) {}
        window.dispatchEvent(new CustomEvent("business-dashboard:updated"));
    }

    function launchChecklistAction(key) {
        const item = readCommandChecklist().find((entry) => entry.key === key);
        const next = $("command-next-action");
        if (item && next) next.textContent = `${item.label}: ${item.action}`;
        if (item && ["form-testing", "domain-connection", "ssl-dns", "analytics-verification"].includes(key)) saveCommandChecklist(key, false, "in_progress");
    }

    function renderCommandCenter() {
        const snapshot = workspaceSnapshot();
        const checklist = readCommandChecklist();
        const completed = checklist.filter((item) => item.status === "complete").length;
        const root = $("command-launch-checklist");
        if (root) root.replaceChildren(...checklist.map((item) => {
            const li = document.createElement("li"); li.dataset.status = item.status;
            li.innerHTML = `<input type="checkbox" data-launch-check="${esc(item.key)}" ${item.status === "complete" ? "checked" : ""} aria-label="${esc(item.label)}"><span><strong>${esc(item.label)}</strong><span>${esc(checklistStatusLabel[item.status] || "Pending")} · ${esc(item.help)}</span><small>${esc(item.result)}</small></span><button type="button" class="matrix-action-btn variant-outline-row" data-launch-help="${esc(item.key)}">Help</button><button type="button" class="matrix-action-btn variant-outline-row" data-launch-retry="${esc(item.key)}">${item.status === "complete" ? "Recheck" : "Start"}</button>`;
            return li;
        }));
        const set = (id, value) => { if ($(id)) $(id).textContent = value; };
        set("command-launch-progress", `${Math.round(completed / checklist.length * 100)}%`);
        set("command-launch-summary", `${completed} of ${checklist.length} launch steps complete.`);
        const nextChecklist = checklist.find((item) => item.status !== "complete");
        const currentLeads = leads();
        const overdueLead = currentLeads.find(isOverdue);
        const nextTask = tasks()[0];
        const nextAction = nextChecklist ? nextChecklist.label : overdueLead ? `Follow up with ${overdueLead.name || "an overdue lead"}` : nextTask?.title || "Review your latest business results";
        set("command-next-action", nextAction);
        const link = $("command-next-action-link");
        if (link) { link.href = nextChecklist ? "#command-launch-title" : overdueLead ? "#crm-pipeline" : nextTask ? "#command-task-list" : "#business-command-title"; link.textContent = nextChecklist ? "Open checklist" : "Open"; }
        const appointments = window.workspaceCRM?.readAppointments?.() || [];
        const upcoming = appointments.filter((item) => item.meetingAt && new Date(item.meetingAt) > new Date() && item.status !== "cancelled").sort((a, b) => new Date(a.meetingAt) - new Date(b.meetingAt))[0];
        set("command-appointment-state", upcoming ? `${upcoming.clientName || "Appointment"} · ${new Date(upcoming.meetingAt).toLocaleString()}` : "No upcoming appointments");
        set("command-website-health", snapshot.hasDraft ? `${Object.keys(snapshot.files).filter((name) => /\\.html$/i.test(name)).length} page draft ready` : "No website draft yet");
        set("command-deployment-state", snapshot.deployment ? "Deployment recorded" : "Not published");
        const notifications = window.businessOperations?.read?.().notifications || [];
        set("command-notification-state", notifications.filter((item) => !item.read).length ? `${notifications.filter((item) => !item.read).length} unread notification${notifications.filter((item) => !item.read).length === 1 ? "" : "s"}` : "No unread notifications");
    }

    function renderMetrics() {
        const currentLeads = leads();
        const profile = window.businessHub?.read?.() || {};
        const metrics = salesMetrics(currentLeads);
        const set = (id, value) => { if ($(id)) $(id).textContent = value; };
        set("command-lead-count", currentLeads.length); set("command-new-count", metrics.newProspects); set("command-task-count", readTasks().filter((task) => !task.done).length);
        set("command-profile-state", profile.name ? "Configured" : "Needs setup"); set("command-project-state", window.workspaceAPI?.getState?.()?.files?.["index.html"] ? "Draft available" : "No draft yet");
        [["sales-new-count", metrics.newProspects], ["sales-qualification-rate", `${metrics.qualificationRate}%`], ["sales-discovery-count", metrics.discoveryCalls], ["sales-proposal-value", `$${metrics.proposalValue.toLocaleString()}`], ["sales-overdue-count", metrics.overdue], ["sales-win-rate", `${metrics.winRate}%`], ["sales-average-close", `${metrics.averageClose}d`], ["sales-no-next-action", metrics.noNextAction], ["sales-stalled-count", metrics.stalled]].forEach(([id, value]) => set(id, value));
        const report = $("sales-report-list"); if (report) report.innerHTML = metrics.transitions.map((item) => `<li><strong>${esc(item.stage)} → ${esc(item.next)}</strong><span>${item.rate}% · ${Object.entries(metrics.sources).filter(([source]) => source).map(([source, data]) => `${esc(source)} ${data.count} / $${data.revenue.toLocaleString()}`).join(" · ") || "No source data"}</span></li>`).join("") || `<li class="command-empty">Add leads to see conversion reporting.</li>`;
    }

    function render() {
        window.workspaceCRM?.migrate?.();
        leads().filter((lead) => lead.status === "new").forEach(ensureFollowUp);
        renderMetrics();
        renderCommandCenter();
        renderAttention();
        renderPipeline();
        renderTasks();
    }

    document.addEventListener("click", (event) => {
        const launchHelp = event.target.closest("[data-launch-help]");
        if (launchHelp) {
            const item = readCommandChecklist().find((entry) => entry.key === launchHelp.dataset.launchHelp);
            const next = $("command-next-action");
            if (item && next) next.textContent = `${item.label}: ${item.help}`;
            return;
        }
        const launchRetry = event.target.closest("[data-launch-retry]");
        if (launchRetry) {
            launchChecklistAction(launchRetry.dataset.launchRetry);
            render();
            return;
        }
        const deliverProposal = event.target.closest("[data-deliver-proposal]");
        if (deliverProposal) {
            const leadId = deliverProposal.dataset.deliverProposal;
            window.workspaceCRM?.deliverProposal?.(leadId);
            const updated = leads().find((item) => item.id === leadId);
            if (updated) renderCustomer(updated);
            render();
            return;
        }
        const createPreview = event.target.closest("[data-create-preview]");
        if (createPreview) {
            const drawer = event.target.closest("#crm-customer-drawer");
            const leadId = createPreview.dataset.createPreview;
            const url = drawer?.querySelector("[data-preview-url]")?.value || "";
            window.workspaceCRM?.createPreview?.(leadId, { url });
            const updated = leads().find((item) => item.id === leadId);
            if (updated) renderCustomer(updated);
            render();
            return;
        }
        const revokePreview = event.target.closest("[data-revoke-preview]");
        if (revokePreview) {
            const leadId = revokePreview.dataset.revokePreview;
            window.workspaceCRM?.revokePreview?.(leadId);
            const updated = leads().find((item) => item.id === leadId);
            if (updated) renderCustomer(updated);
            render();
            return;
        }
        const saveOffer = event.target.closest("[data-save-offer]");
        if (saveOffer) {
            const drawer = event.target.closest("#crm-customer-drawer");
            const packageKey = drawer?.querySelector("[data-offer-package]")?.value;
            if (packageKey) {
                window.workspaceCRM?.saveOffer?.(saveOffer.dataset.saveOffer, packageKey);
                const updated = leads().find((item) => item.id === saveOffer.dataset.saveOffer);
                if (updated) renderCustomer(updated);
                render();
            }
            return;
        }
        const callButton = event.target.closest("[data-call-outcome]");
        if (callButton) {
            const drawer = event.target.closest("#crm-customer-drawer");
            const leadId = drawer?.dataset.leadId;
            if (leadId) {
                const note = drawer.querySelector("[data-call-note]")?.value || "";
                window.workspaceCRM?.recordCallOutcome?.(leadId, callButton.dataset.callOutcome, note);
                const updated = leads().find((item) => item.id === leadId);
                if (updated) renderCustomer(updated);
                render();
            }
            return;
        }
        const open = event.target.closest("[data-open-lead]");
        if (open) {
            const lead = leads().find((item) => item.id === open.dataset.openLead);
            if (lead) { window.workspaceCRM?.update?.(lead.id, { unread: false }); renderCustomer({ ...lead, unread: false }); render(); }
        }
        if (event.target.closest("[data-close-customer]")) { const drawer = $("crm-customer-drawer"); if (drawer) drawer.hidden = true; }
        const convert = event.target.closest("[data-convert-project]");
        if (convert) {
            const status = event.target.closest("#crm-customer-drawer")?.querySelector("[data-customer-status]");
            if (status) status.textContent = "Project workspace queued from this customer record.";
            window.dispatchEvent(new CustomEvent("business-dashboard:project-created", { detail: { leadId: convert.dataset.convertProject } }));
        }
    });
    function setNestedValue(target, path, value) {
        const parts = path.split(".");
        let cursor = target;
        parts.slice(0, -1).forEach((part) => { cursor[part] = cursor[part] && typeof cursor[part] === "object" ? cursor[part] : {}; cursor = cursor[part]; });
        cursor[parts.at(-1)] = value;
    }

    document.addEventListener("change", (event) => {
        const launchCheck = event.target.closest("[data-launch-check]");
        if (launchCheck) { saveCommandChecklist(launchCheck.dataset.launchCheck, launchCheck.checked); render(); return; }
        const salesField = event.target.closest("[data-sales-field]");
        const salesDrawer = event.target.closest("#crm-customer-drawer")?.dataset.leadId;
        if (salesField && salesDrawer) {
            const lead = leads().find((item) => item.id === salesDrawer);
            if (lead) {
                const changes = JSON.parse(JSON.stringify(lead));
                const path = salesField.dataset.salesField;
                if (path === "discovery.stakeholdersText") { changes.discovery.stakeholders = salesField.value.split("\n").map((line) => { const [name, role, email] = line.split(",").map((item) => item.trim()); return { name, role, email }; }).filter((item) => item.name || item.email); }
                else if (path === "demo.objectionsText") changes.demo.objections = salesField.value.split("\n").map((item) => item.trim()).filter(Boolean);
                else setNestedValue(changes, path, salesField.type === "number" ? Number(salesField.value) || 0 : salesField.value);
                window.workspaceCRM?.updateWithCloud?.(salesDrawer, changes);
                if (path === "closeReason" || path === "proposal.contractNotes") renderCustomer(window.workspaceCRM?.read?.().find((item) => item.id === salesDrawer));
            }
        }
        const customerField = event.target.closest("[data-customer-field]");
        const drawerLead = event.target.closest("#crm-customer-drawer")?.dataset.leadId;
        if (customerField && drawerLead) window.workspaceCRM?.updateWithCloud?.(drawerLead, { [customerField.dataset.customerField]: customerField.value });
        const status = event.target.closest("[data-crm-status]");
        const notes = event.target.closest("[data-crm-notes]");
        const card = event.target.closest("[data-lead-id]");
        if (status && card) {
            const leadId = card.dataset.leadId;
            window.workspaceCRM?.updateWithCloud?.(leadId, { status: status.value, ...(status.value === "won" ? { handoffAt: new Date().toISOString() } : {}) });
            if (status.value === "won") {
                const lead = leads().find((item) => item.id === leadId);
                if (lead) window.businessOperations?.addProject?.({ ...lead, handoffAt: new Date().toISOString() });
            }
        }
        if (notes && card) window.workspaceCRM?.updateWithCloud?.(card.dataset.leadId, { notes: notes.value });
        const taskId = event.target.closest("[data-task-id]")?.dataset.taskId;
        if (taskId) writeTasks(readTasks().map((task) => task.id === taskId ? { ...task, done: true } : task));
        render();
    });
    window.addEventListener("crm:proposal-approved", (event) => {
        const lead = leads().find((item) => item.id === event.detail?.leadId);
        if (lead && window.businessOperations?.addProject) window.businessOperations.addProject({ ...lead, handoffAt: lead.handoffAt || new Date().toISOString() });
        render();
    });
    window.addEventListener("crm:updated", () => { leads().filter((lead) => lead.status === "new").forEach(ensureFollowUp); render(); });
    window.addEventListener("workspace:files-rendered", renderMetrics);
    window.addEventListener("business-hub:updated", renderMetrics);
    window.addEventListener("storage", render);
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", render, { once: true }); else render();
    window.businessDashboard = Object.freeze({ render, readTasks, ensureFollowUp });
})();
