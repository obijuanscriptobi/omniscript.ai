"use strict";

// Shared Business Hub contract. It normalizes the existing brief into one
// reusable source of truth for website, ads, SEO, and future CRM features.
(() => {
    const STORAGE_KEY = "morrow-business-hub-v1";
    const storageKey = () => window.workspaceContext?.storageKey?.(STORAGE_KEY) || STORAGE_KEY;
    const VERSION = 1;
    const REQUIRED = ["name", "hook", "location", "primaryCta"];
    const CLAIM_LIMIT = 40;

    const clean = (value, max = 1000) => String(value ?? "")
        .replace(/[\u0000-\u001F\u007F]/g, "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, max);

    const list = (value) => String(value ?? "")
        .split(/[\n,]/)
        .map((item) => clean(item, 240))
        .filter(Boolean)
        .slice(0, CLAIM_LIMIT);

    const get = (id) => typeof document !== "undefined" ? document.getElementById(id) : null;

    function normalize(raw = {}) {
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
                    const profile = { ...source };
        profile.websiteUrl = clean(source.websiteUrl, 500);
        profile.industry = clean(source.industry || source.businessType, 120);
        profile.decisionMaker = clean(source.decisionMaker, 180);
        profile.serviceArea = clean(source.serviceArea || source.location, 240);
        ["name", "hook", "location", "phone", "email", "address", "audience", "differentiator", "testimonial", "testimonialAuthor", "credentials", "experience", "customers", "hours", "pricing", "booking", "primaryGoal", "primaryCta", "responseTime", "businessType", "designStyle", "contentTone", "layoutDensity", "brandVoice"].forEach((key) => { profile[key] = clean(source[key], key === "testimonial" ? 1200 : 500); });
        profile.services = list(source.services).join(", ");
        profile.gallery = list(source.gallery).join(", ");
        profile.galleryAlt = list(source.galleryAlt);
        profile.heroAlt = clean(source.heroAlt, 250);
        profile.heroDecorative = Boolean(source.heroDecorative);
        profile.approvedClaims = list(source.approvedClaims);
        profile.forbiddenClaims = list(source.forbiddenClaims);
        profile.color = /^#[0-9a-f]{6}$/i.test(String(source.color || "")) ? String(source.color).toLowerCase() : "#d4af37";
        profile.secondaryColor = /^#[0-9a-f]{6}$/i.test(String(source.secondaryColor || "")) ? String(source.secondaryColor).toLowerCase() : "#18202b";
        return profile;
    }

    function completeness(profile = {}) {
        const checks = REQUIRED.map((key) => ({ key, complete: Boolean(clean(profile[key])) }));
        const optional = ["services", "audience", "primaryGoal", "primaryCta", "phone", "email", "approvedClaims"];
        const optionalComplete = optional.filter((key) => Array.isArray(profile[key]) ? profile[key].length : Boolean(clean(profile[key]))).length;
        return { required: checks, completed: checks.filter((item) => item.complete).length, total: checks.length, optionalCompleted: optionalComplete, score: Math.round((checks.filter((item) => item.complete).length / checks.length) * 100), ready: checks.every((item) => item.complete) };
    }

    function read() {
        return normalize(window.workspaceFields?.readBusiness?.((value) => value) || {});
    }

    function canonicalProfile() {
        const service = window.profileService;
        const raw = window.workspaceAPI?.getState?.()?.businessProfile || service?.readLocal?.() || read();
        return raw && service?.normalize ? service.normalize(raw) : null;
    }

    function save(profile = read(), { announce = true } = {}) {
        const normalized = normalize(profile);
        const record = { version: VERSION, updatedAt: new Date().toISOString(), profile: normalized };
        try { localStorage.setItem(storageKey(), JSON.stringify({ ...record, workContext: window.workspaceContext?.current?.() || null })); } catch (_) {}
        if (announce && typeof window !== "undefined") window.dispatchEvent(new CustomEvent("business-hub:updated", { detail: { ...record, completeness: completeness(normalized) } }));
        return record;
    }

    function load() {
        try {
            const scoped = localStorage.getItem(storageKey());
            const legacy = window.operatingMode?.get?.() === "own" ? localStorage.getItem(STORAGE_KEY) : null;
            const record = JSON.parse(scoped || legacy || "null");
            if (!scoped && legacy && record?.profile) localStorage.setItem(storageKey(), JSON.stringify({ ...record, workContext: window.workspaceContext?.current?.() || null }));
            return record?.profile ? normalize(record.profile) : null;
        } catch (_) { return null; }
    }

    function apply(profile = load()) {
        if (!profile || !window.workspaceFields?.apply) return false;
        window.workspaceFields.apply({ form: { business: normalize(profile) } });
        render();
        return true;
    }

    function render(profile = read()) {
        const summary = get("business-hub-summary");
        const score = get("business-hub-score");
        const claims = get("business-hub-claims");
        const status = get("business-hub-status");
        const result = completeness(profile);
        if (summary) summary.textContent = result.ready ? "Your core business facts are ready to reuse across your website and campaigns." : `${result.completed}/${result.total} core business facts complete. Add the missing details before generating more content.`;
        if (score) score.textContent = `${result.score}% ready`;
        if (status) status.textContent = `${profile.approvedClaims.length} approved claims · ${profile.forbiddenClaims.length} claims to avoid · ${profile.brandVoice || "No brand voice set"}`;
        if (claims) claims.replaceChildren(...profile.approvedClaims.slice(0, 5).map((claim) => { const item = document.createElement("li"); item.textContent = claim; return item; }));
        renderClaimsReview();
        const panel = get("business-hub-panel");
        if (panel) panel.dataset.ready = String(result.ready);
    }

    function renderClaimsReview() {
        const list = get("claims-review-list");
        const status = get("claims-review-status");
        if (!list) return;
        const html = window.workspaceAPI?.getState?.()?.files?.["index.html"] || "";
        const match = html.match(/name=["']morrow-claims["'][^>]*content=["']([^"']*)["']/i);
        const claims = match ? match[1].split(" | ").filter(Boolean) : [];
        if (status) status.textContent = claims.length ? `${claims.length} governed claim${claims.length === 1 ? "" : "s"} found in the generated metadata.` : "No governed claims are present in this draft.";
        list.replaceChildren(...(claims.length ? claims.map((claim) => {
            const item = document.createElement("li");
            const [source, text] = claim.split(/:\s*(.*)/s);
            item.textContent = `${source || "Generated"}: ${text || claim}`;
            item.dataset.source = source || "generated";
            return item;
        }) : [Object.assign(document.createElement("li"), { className: "field-descriptor-text", textContent: "No generated claims reviewed yet." })]));
    }

    function syncFromFields() {
        const record = save(read(), { announce: false });
        render(record.profile);
        const service = window.profileService;
        if (service) {
            const canonical = service.normalize(record.profile);
            service.saveProfile(canonical, { actor: "business-hub" }).catch(() => {});
        }
        window.dispatchEvent(new CustomEvent("business-hub:updated", { detail: { ...record, completeness: completeness(record.profile) } }));
    }

    function init() {
        const saved = load();
        if (saved && !read().name) apply(saved);
        render(read());
        document.addEventListener("input", (event) => { if (event.target?.id?.startsWith("input-")) { clearTimeout(init.timer); init.timer = setTimeout(syncFromFields, 220); } });
        document.addEventListener("change", (event) => { if (event.target?.id?.startsWith("input-")) syncFromFields(); });
        window.addEventListener("workspace:generation-complete", renderClaimsReview);
        window.addEventListener("workspace:files-rendered", renderClaimsReview);
        window.addEventListener("storage", (event) => { if (event.key === storageKey()) render(load() || read()); });
    }

    window.businessHub = Object.freeze({ VERSION, STORAGE_KEY, normalize, completeness, read, save, load, apply, render, syncFromFields });
    if (typeof document !== "undefined") {
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
        else init();
    }
})();
