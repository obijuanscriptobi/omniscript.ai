"use strict";
(() => {
    const $ = (id) => document.getElementById(id);
    const text = (id) => $(id)?.value?.trim() || "";
    const key = "morrow-business-profile-v1";
    const list = (value) => value.split(/[\n,]/).map((item) => item.trim()).filter(Boolean);
    const profile = () => window.profileService?.readLocal?.() || {};
    const projectId = () => window.supabaseWorkspace?.getState?.()?.projectId || "";

    async function cloudRequest(method, payload = {}) {
        const token = window.supabaseWorkspace?.getAccessToken?.();
        const id = projectId();
        if (!token || !id) throw new Error("Select or save a cloud project in Website Maker first.");
        const response = await fetch(`/api/business-profile?projectId=${encodeURIComponent(id)}`, {
            method,
            headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" },
            body: method === "PUT" ? JSON.stringify({ ...payload, projectId: id }) : undefined
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) { const error = new Error(data.error || "Cloud profile request failed."); error.code = data.code; throw error; }
        return data;
    }

    function bindProjectControls() {
        const selector = $("project-selector");
        const loadButton = $("load-project-btn");
        const refresh = () => {
            const state = window.supabaseWorkspace?.getState?.() || {};
            loadButton.disabled = !state.authenticated || !selector.value;
        };
        selector?.addEventListener("change", refresh);
        loadButton?.addEventListener("click", async () => {
            try { await window.supabaseWorkspace.loadProject(selector.value); await loadCloudProfile(); }
            catch (error) { $("project-status").textContent = error.message || "Project could not be loaded."; }
        });
        window.addEventListener("supabase:authenticated", refresh);
        refresh();
    }

    function configureCloudProfile() {
        window.profileService?.configure({ cloud: {
            load: async () => {
                const data = await cloudRequest("GET");
                return data.profile?.profile || data.profile || null;
            },
            save: async (next) => {
                const previous = profile();
                return cloudRequest("PUT", { profile: next, expectedRevision: Number(previous.revision || 0), changeSource: "business-profile-page" });
            }
        }});
    }

    async function loadCloudProfile() {
        if (!window.supabaseWorkspace?.getState?.()?.authenticated || !projectId()) return;
        try {
            const data = await cloudRequest("GET");
            if (data.profile?.profile) {
                window.profileService.writeLocal(data.profile.profile);
                load();
                $("profile-status").textContent = `Loaded cloud profile · revision ${data.profile.revision}.`;
            }
        } catch (error) {
            $("profile-validation").textContent = error.message || "The cloud profile could not be loaded.";
        }
    }

    function load() {
        const current = profile();
        const launch = current.metadata?.launchBrief || {};
        const identity = current.identity || {};
        const location = current.locations?.[0] || {};
        const brand = current.brand || {};
        const fields = {
            "profile-name": launch.name || identity.displayName,
            "profile-offer": launch.offer || identity.description || current.services?.[0],
            "profile-audience": launch.audience,
            "profile-location": launch.location || location.city,
            "profile-goal": launch.goal || current.metadata?.primaryAction || "quote",
            "profile-proof": launch.proof || current.claims?.find((claim) => claim.text)?.text,
            "profile-email": identity.email,
            "profile-phone": identity.phone,
            "profile-address": location.address,
            "profile-services": (current.services || []).join("\n"),
            "profile-voice": brand.voice,
            "profile-color": brand.primaryColor || "#d4af37",
            "profile-secondary-color": brand.secondaryColor || "#18202b",
            "profile-claims": (current.claims || []).map((claim) => claim.text).filter(Boolean).join("\n"),
            "profile-forbidden": (current.metadata?.forbiddenClaims || []).join("\n")
        };
        Object.entries(fields).forEach(([id, value]) => { const field = $(id); if (field && value) field.value = value; });
        renderStatus(current);
    }

    function draft() {
        const current = profile();
        const launch = {
            name: text("profile-name"), offer: text("profile-offer"), audience: text("profile-audience"),
            location: text("profile-location"), goal: text("profile-goal") || "quote", proof: text("profile-proof")
        };
        const claims = list(text("profile-claims")).map((claim) => {
            const old = (current.claims || []).find((item) => item.text === claim);
            return { ...(old || {}), text: claim, source: old?.source || "business profile", state: old?.state || "draft", surfaces: old?.surfaces || ["website", "ads", "seo", "crm", "follow-up", "analytics"] };
        });
        return {
            ...current,
            identity: { ...(current.identity || {}), displayName: launch.name, description: launch.offer, email: text("profile-email"), phone: text("profile-phone") },
            services: list(text("profile-services") || launch.offer),
            offers: [{ ...(current.offers?.[0] || {}), name: launch.offer, description: launch.offer, status: "active" }],
            locations: [{ ...(current.locations?.[0] || {}), city: launch.location, address: text("profile-address"), serviceArea: launch.location ? [launch.location] : [] }],
            brand: { ...(current.brand || {}), voice: text("profile-voice"), primaryColor: text("profile-color"), secondaryColor: text("profile-secondary-color") },
            claims,
            metadata: { ...(current.metadata || {}), launchBrief: launch, primaryAction: launch.goal, forbiddenClaims: list(text("profile-forbidden")), sourceOfTruth: "business-profile" }
        };
    }

    function renderStatus(current) {
        const status = $("profile-status");
        if (status) status.textContent = current.revision ? `Saved locally · profile revision ${current.revision}` : "No saved profile yet. Add the facts customers should see.";
    }

    async function save(event) {
        event.preventDefault();
        const gate = window.workspaceContext?.clientGate?.("content");
        if (gate && !gate.allowed) {
            $("profile-validation").textContent = gate.message;
            return;
        }
        const button = event.currentTarget.querySelector("button[type=submit]");
        const status = $("profile-status");
        const validation = $("profile-validation");
        validation.textContent = "";
        if (!event.currentTarget.reportValidity()) return;
        button.disabled = true;
        status.textContent = "Saving Business profile…";
        try {
            const next = window.businessProfile.normalizeProfile(draft());
            const current = profile();
            next.id = current.id || next.id;
            next.revision = String(Number(current.revision || 0) + 1);
            next.audit = [...(current.audit || []), { type: "profile.updated", actor: "business-profile-page", revision: next.revision, changes: {}, createdAt: new Date().toISOString() }];
            next.updatedAt = new Date().toISOString();
            window.profileService.writeLocal(next);
            if (window.supabaseWorkspace?.getState?.()?.authenticated && projectId()) {
                const cloud = await cloudRequest("PUT", { profile: next, expectedRevision: Number(current.revision || 0), changeSource: "business-profile-page" });
                if (cloud.profile?.profile) window.profileService.writeLocal(cloud.profile.profile);
            }
            const workspace = window.workspaceAPI?.getState?.();
            if (workspace) { workspace.businessProfile = next; workspace.profileRevision = next.revision; }
            window.dispatchEvent(new CustomEvent("business-profile:updated", { detail: { profile: next, revision: next.revision, persisted: "local" } }));
            renderStatus(next);
            status.textContent = `Saved. Revision ${next.revision} now powers your website, ads, SEO, follow-up, and appointments.`;
        } catch (error) {
            validation.textContent = error.issues?.map((issue) => issue.message || issue.code).join(" · ") || error.message || "The profile could not be saved.";
            status.textContent = "Save failed. Fix the highlighted information and try again.";
        } finally { button.disabled = false; }
    }

    function downloadProfile() {
        const data = JSON.stringify({ schema: "BusinessProfile", exportedAt: new Date().toISOString(), profile: profile() }, null, 2);
        const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob([data], { type: "application/json" })); link.download = "morrow-business-profile.json"; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 0);
    }

    function importProfile(event) {
        const file = event.target.files?.[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = async () => {
            try {
                const parsed = JSON.parse(reader.result);
                const imported = parsed.profile || parsed;
                const next = window.businessProfile.normalizeProfile(imported);
                const validation = window.businessProfile.validateProfile(next);
                if (!validation.valid) throw new Error(validation.issues.map((issue) => issue.code).join(" · "));
                window.profileService.writeLocal(next);
                window.dispatchEvent(new CustomEvent("business-profile:updated", { detail: { profile: next, persisted: "local", source: "import" } }));
                load(); $("profile-status").textContent = "Profile imported and saved.";
            } catch (error) { $("profile-validation").textContent = error.message || "The profile file is invalid."; }
            event.target.value = "";
        };
        reader.readAsText(file);
    }

    function bind() {
        configureCloudProfile();
        bindProjectControls();
        load();
        $("business-profile-form")?.addEventListener("submit", save);
        $("export-profile-btn")?.addEventListener("click", downloadProfile);
        $("import-profile-input")?.addEventListener("change", importProfile);
        window.addEventListener("business-profile:updated", (event) => renderStatus(event.detail?.profile || profile()));
        window.addEventListener("supabase:authenticated", loadCloudProfile);
        window.addEventListener("workspace:project-id-change", loadCloudProfile);
        loadCloudProfile();
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();