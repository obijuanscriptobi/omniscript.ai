"use strict";

// Canonical business context shared by website, ads, SEO, CRM, and follow-up
// features. Surface modules should consume this record instead of owning facts.
(() => {
    const MODEL_VERSION = 1;
    const SURFACES = Object.freeze(["website", "ads", "seo", "crm", "follow-up", "analytics"]);
    const CLAIM_STATES = Object.freeze(["draft", "pending", "approved", "rejected", "expired"]);
    const object = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const array = (value) => Array.isArray(value) ? value : [];
    const text = (value) => String(value ?? "").trim();
    const clone = (value) => JSON.parse(JSON.stringify(value));
    const now = () => new Date().toISOString();
    const id = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    function normalizeList(value) {
        if (Array.isArray(value)) return value.map(text).filter(Boolean);
        return text(value).split(/[\n,]/).map((item) => item.trim()).filter(Boolean);
    }

    function normalizeLocations(value) {
        return array(value).map((location) => {
            const item = object(location);
            return {
                id: text(item.id) || id("location"),
                name: text(item.name),
                address: text(item.address),
                city: text(item.city),
                region: text(item.region),
                postalCode: text(item.postalCode),
                country: text(item.country),
                serviceArea: normalizeList(item.serviceArea)
            };
        });
    }

    function normalizeProfile(input = {}, options = {}) {
        const source = object(input);
        const metadata = object(options.metadata);
        const identity = object(source.identity);
        const brand = object(source.brand);
        const consent = object(source.consent);
        const integrations = object(source.integrations);
        return {
            model: "BusinessProfile",
            version: MODEL_VERSION,
            id: text(source.id) || id("profile"),
            revision: text(source.revision) || "0",
            identity: {
                legalName: text(identity.legalName || source.legalName),
                displayName: text(identity.displayName || source.businessName || source.name),
                description: text(identity.description || source.description),
                businessType: text(identity.businessType || source.businessType),
                website: text(identity.website || source.website),
                phone: text(identity.phone || source.phone),
                email: text(identity.email || source.email)
            },
            services: normalizeList(source.services),
            locations: normalizeLocations(source.locations),
            offers: array(source.offers).map((offer) => ({
                id: text(offer?.id) || id("offer"),
                name: text(offer?.name),
                description: text(offer?.description),
                price: text(offer?.price),
                bookingUrl: text(offer?.bookingUrl),
                status: text(offer?.status || "active")
            })),
            contacts: array(source.contacts).map((contact) => ({
                id: text(contact?.id) || id("contact"),
                name: text(contact?.name),
                role: text(contact?.role),
                email: text(contact?.email),
                phone: text(contact?.phone)
            })),
            brand: {
                voice: text(brand.voice || source.brandVoice),
                primaryColor: text(brand.primaryColor || source.color),
                secondaryColor: text(brand.secondaryColor || source.secondaryColor),
                logoUrl: text(brand.logoUrl || source.logoUrl),
                logoAlt: text(brand.logoAlt || source.logoAlt),
                tone: normalizeList(brand.tone || source.contentTone)
            },
            claims: normalizeClaims(source.claims || source.approvedClaims),
            consent: {
                privacyPolicyUrl: text(consent.privacyPolicyUrl),
                termsUrl: text(consent.termsUrl),
                marketingOptInRequired: consent.marketingOptInRequired !== false,
                contactPermissionRequired: consent.contactPermissionRequired !== false
            },
            integrations: clone(integrations),
            createdAt: text(source.createdAt) || now(),
            updatedAt: now(),
            audit: array(source.audit).map((entry) => normalizeAuditEntry(entry)),
            // Options may control normalization behavior, but must never be able
            // to overwrite the canonical model identity or normalized fields.
            metadata
        };
    }

    function normalizeClaims(value) {
        if (typeof value === "string") return value.split(/[\n;]/).map((claim) => ({ text: claim.trim() })).filter((claim) => claim.text).map(normalizeClaim);
        return array(value).map(normalizeClaim);
    }

    function normalizeClaim(input = {}) {
        const claim = object(input);
        const surfaces = array(claim.surfaces).filter((surface) => SURFACES.includes(surface));
        return {
            id: text(claim.id) || id("claim"),
            text: text(claim.text || claim.value),
            source: text(claim.source),
            sourceUrl: text(claim.sourceUrl),
            confidence: Math.max(0, Math.min(1, Number.isFinite(Number(claim.confidence)) ? Number(claim.confidence) : 0)),
            state: CLAIM_STATES.includes(claim.state) ? claim.state : "draft",
            expiresAt: text(claim.expiresAt),
            surfaces: surfaces.length ? surfaces : [...SURFACES],
            required: claim.required === true,
            approvedBy: text(claim.approvedBy),
            approvedAt: text(claim.approvedAt),
            updatedAt: text(claim.updatedAt) || now()
        };
    }

    function normalizeAuditEntry(input = {}) {
        const entry = object(input);
        return { id: text(entry.id) || id("audit"), type: text(entry.type || "profile.updated"), actor: text(entry.actor || "system"), revision: text(entry.revision), changes: clone(entry.changes || {}), createdAt: text(entry.createdAt) || now() };
    }

    function validateProfile(profile) {
        const item = normalizeProfile(profile);
        const issues = [];
        if (!item.identity.displayName) issues.push({ code: "PROFILE_NAME_REQUIRED", field: "identity.displayName" });
        if (!item.identity.email && !item.identity.phone) issues.push({ code: "PROFILE_CONTACT_REQUIRED", field: "identity" });
        item.claims.forEach((claim) => {
            if (!claim.text) issues.push({ code: "CLAIM_TEXT_REQUIRED", id: claim.id });
            if (claim.state === "approved" && !claim.source) issues.push({ code: "APPROVED_CLAIM_SOURCE_REQUIRED", id: claim.id });
        });
        return { valid: issues.length === 0, issues, profile: item };
    }

    function claimIsUsable(claim, at = Date.now()) {
        const expiry = Date.parse(claim.expiresAt);
        return claim.state === "approved" && (!Number.isFinite(expiry) || expiry >= at);
    }

    function governance(profile, surface = "website", at = Date.now()) {
        const item = normalizeProfile(profile);
        const relevant = item.claims.filter((claim) => claim.surfaces.includes(surface));
        const blocking = relevant.filter((claim) => claim.required && !claimIsUsable(claim, at));
        const stale = relevant.filter((claim) => claim.state === "approved" && !claimIsUsable(claim, at));
        return { surface, valid: blocking.length === 0, blocking: blocking.map((claim) => ({ code: claim.state === "approved" ? "CLAIM_EXPIRED" : "CLAIM_NOT_APPROVED", claimId: claim.id, message: `Claim requires attention before ${surface} publishing.` })), stale: stale.map((claim) => claim.id), usableClaims: relevant.filter((claim) => claimIsUsable(claim, at)) };
    }

    function updateClaim(profile, claimId, patch = {}, actor = "user") {
        const item = normalizeProfile(profile);
        const index = item.claims.findIndex((claim) => claim.id === claimId);
        if (index < 0) throw new Error(`Claim not found: ${claimId}`);
        const next = normalizeClaim({ ...item.claims[index], ...patch, updatedAt: now() });
        item.claims[index] = next;
        item.revision = String(Number(item.revision) + 1);
        item.updatedAt = now();
        item.audit.push(normalizeAuditEntry({ type: "claim.updated", actor, revision: item.revision, changes: { claimId, patch } }));
        return item;
    }

    function affectedSurfaces(changes = {}) {
        const keys = Object.keys(object(changes));
        const result = new Set();
        const mapping = { identity: ["website", "ads", "seo", "crm"], services: ["website", "ads", "seo", "crm", "follow-up"], locations: ["website", "ads", "seo"], offers: ["website", "ads", "seo", "follow-up"], contacts: ["website", "crm", "follow-up"], brand: ["website", "ads", "seo"], claims: [...SURFACES], consent: ["website", "crm", "follow-up"], integrations: ["crm", "follow-up", "analytics"] };
        keys.forEach((key) => (mapping[key] || SURFACES).forEach((surface) => result.add(surface)));
        return [...result];
    }

    function recordChange(profile, changes = {}, actor = "user") {
        const item = normalizeProfile(profile);
        item.revision = String(Number(item.revision) + 1);
        item.updatedAt = now();
        const event = normalizeAuditEntry({ type: "profile.updated", actor, revision: item.revision, changes });
        item.audit.push(event);
        return { profile: item, event, affectedSurfaces: affectedSurfaces(changes) };
    }

    function exportManifest(profile, payload = {}) {
        const item = normalizeProfile(profile);
        const content = JSON.stringify({ schemaVersion: MODEL_VERSION, profile: item, ...payload });
        let hash = 2166136261;
        for (const character of content) { hash ^= character.charCodeAt(0); hash = Math.imul(hash, 16777619); }
        const bytes = typeof TextEncoder !== "undefined"
            ? new TextEncoder().encode(content).byteLength
            : unescape(encodeURIComponent(content)).length;
        return { schemaVersion: MODEL_VERSION, profileId: item.id, revision: item.revision, bytes, checksum: (hash >>> 0).toString(16).padStart(8, "0"), generatedAt: now() };
    }

    const api = Object.freeze({ MODEL_VERSION, SURFACES, CLAIM_STATES, normalizeProfile, normalizeClaim, validateProfile, governance, updateClaim, affectedSurfaces, recordChange, exportManifest });
    if (typeof window !== "undefined") window.businessProfile = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
