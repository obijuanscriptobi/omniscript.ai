"use strict";

// Makes public-URL client intake the primary entry point without coupling it to
// the Business Profile feature.
(() => {
    const get = (id) => document.getElementById(id);

    function normalize(value) {
        const raw = String(value || "").trim();
        if (!raw) return "";
        const candidate = /^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
        try {
            const url = new URL(candidate);
            if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.hash) return "";
            return url.href;
        } catch {
            return "";
        }
    }

    function bind() {
        const source = get("client-source-url");
        const legacy = get("input-scrape-url");
        const importButton = get("client-source-import-btn");
        const authorization = get("client-source-authorized");
        const status = get("client-source-status");
        if (!source || !importButton) return;

        const sync = () => {
            const url = normalize(source.value);
            if (url) {
                source.value = url;
                source.setCustomValidity("");
                if (legacy) {
                    legacy.value = url;
                    legacy.dispatchEvent(new Event("input", { bubbles: true }));
                    legacy.dispatchEvent(new Event("change", { bubbles: true }));
                }
            }
            return url;
        };
        const resetBusy = (message) => {
            importButton.disabled = false;
            importButton.removeAttribute("aria-busy");
            if (message && status) status.textContent = message;
        };

        source.addEventListener("input", () => source.setCustomValidity(""));
        authorization?.addEventListener("change", () => authorization.setCustomValidity(""));
        source.addEventListener("blur", sync);
        source.addEventListener("change", sync);
        source.addEventListener("keydown", (event) => {
            if (event.key !== "Enter") return;
            event.preventDefault();
            importButton.click();
        });
        importButton.addEventListener("click", () => {
            const url = sync();
            if (!url) {
                source.setCustomValidity("Enter a valid public HTTP or HTTPS website URL.");
                source.reportValidity();
                if (status) status.textContent = "Enter a valid public HTTP or HTTPS website URL first.";
                source.focus();
                return;
            }
            if (!authorization?.checked) {
                authorization?.setCustomValidity("Confirm that you are authorized to use this website and its content.");
                authorization?.reportValidity();
                if (status) status.textContent = "Confirm client authorization before importing.";
                authorization?.focus();
                return;
            }
            authorization.setCustomValidity("");
            const scrapeButton = get("scrape-btn");
            if (!scrapeButton || !window.workspaceAPI) {
                if (status) status.textContent = "The website importer is still loading. Wait a moment, then try again.";
                return;
            }
            importButton.disabled = true;
            importButton.setAttribute("aria-busy", "true");
            if (status) status.textContent = "Importing the client site for a safer, mobile-first rebuild…";
            try { localStorage.setItem("morrow-client-import-intent-v1", JSON.stringify({ url, createdAt: new Date().toISOString() })); } catch (_) {}
            scrapeButton.click();
            window.setTimeout(() => {
                if (!importButton.disabled) return;
                resetBusy("The import is taking longer than expected. Your URL is saved; try again or check the importer details in More options.");
            }, 30000);
        });
        document.addEventListener("workspace:files-rendered", () => resetBusy("Client site imported. Review the new draft and the import difference report."));
        document.addEventListener("workspace:import-rejected", (event) => resetBusy(event.detail?.issues?.[0]?.message || "The import was rejected because the public content did not pass safety checks."));
        window.addEventListener("workspace:project-context-cleared", () => resetBusy());
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
