"use strict";

const fs = require("node:fs");
const path = require("node:path");

const REQUIRED_FILES = [
    "netlify.toml",
    "netlify/functions/config.js",
    "netlify/functions/preflight.js",
    "netlify/functions/verify-deployment.js",
    "netlify/functions/submit-form.js",
    "netlify_functions_submit_form.js",
    "netlify/functions/_quota.js",
    "supabase/schema.sql",
    "supabase/usage-limits.sql",
    "supabase/reliability.sql",
    "supabase/work-context-isolation.sql",
    "supabase/proposal-handoffs.sql",
    "netlify/functions/handoffs.js",
    "test/staging-rls.test.js",
    "docs/PRODUCTION-READINESS.md",
    "docs/PRIVACY-RELEASE-CHECKLIST.md",
    "docs/STAGING-RELEASE-RECORD.md",
    "docs/OPERATIONS-RUNBOOK.md"
];

const REQUIRED_RUNTIME_EVIDENCE = Object.freeze({
    cleanMigration: "CODEWISE_EVIDENCE_CLEAN_MIGRATION",
    legacyMigration: "CODEWISE_EVIDENCE_LEGACY_MIGRATION",
    stagingRls: "CODEWISE_EVIDENCE_STAGING_RLS",
    publicTokenRaces: "CODEWISE_EVIDENCE_PUBLIC_TOKEN_RACES",
    fileLifecycle: "CODEWISE_EVIDENCE_FILE_LIFECYCLE",
    providerDelivery: "CODEWISE_EVIDENCE_PROVIDER_DELIVERY",
    browserAccessibility: "CODEWISE_EVIDENCE_BROWSER_A11Y",
    backupRestore: "CODEWISE_EVIDENCE_BACKUP_RESTORE",
    migrationRollback: "CODEWISE_EVIDENCE_MIGRATION_ROLLBACK",
    monitoringIncidentResponse: "CODEWISE_EVIDENCE_OPERATIONS"
});

const REQUIRED_ROUTES = [
    "/api/config",
    "/api/preflight",
    "/api/verify-deployment",
    "/api/submit-form",
    "/api/deploy",
    "/api/projects"
];

function read(root, file) {
    try {
        return fs.readFileSync(path.join(root, file), "utf8");
    } catch {
        return "";
    }
}

function validateEvidenceManifest(rawManifest, expectedCommit, evidence, expectedCiRunId = "") {
    const errors = [];
    const immutableReference = /^(?:sha256:[a-f0-9]{64}|artifact:[A-Za-z0-9._/-]+@[a-f0-9]{64}|https:\/\/[^\s?#]+\/[A-Za-z0-9._/-]+\?versionId=[A-Za-z0-9._-]+)$/i;
    const checksumPattern = /^sha256:[a-f0-9]{64}$/i;
    let manifest = null;
    try {
        manifest = JSON.parse(String(rawManifest || ""));
    } catch {
        return { valid: false, manifest: null, errors: ["CODEWISE_RELEASE_EVIDENCE_MANIFEST must be valid JSON."] };
    }
    if (!manifest || typeof manifest !== "object" || Array.isArray(manifest)) {
        return { valid: false, manifest: null, errors: ["The evidence manifest must be a JSON object."] };
    }

    const commit = String(expectedCommit || "").trim().toLowerCase();
    if (!/^[a-f0-9]{40}$/.test(commit)) errors.push("CODEWISE_RELEASE_COMMIT must be a full 40-character commit SHA.");
    if (String(manifest.releaseCommit || "").trim().toLowerCase() !== commit) errors.push("The evidence manifest releaseCommit does not match the checked-out release commit.");
    if (manifest.schemaVersion !== 1) errors.push("The evidence manifest schemaVersion must be 1.");
    if (!manifest.environment || typeof manifest.environment !== "object" || !String(manifest.environment.identity || "").trim()) errors.push("The evidence manifest requires a non-secret environment identity.");
    const createdAt = Date.parse(String(manifest.createdAt || ""));
    if (!Number.isFinite(createdAt)) errors.push("The evidence manifest requires a valid ISO-8601 createdAt value.");
    else if (createdAt > Date.now() + 5 * 60_000) errors.push("The evidence manifest createdAt value cannot be in the future.");
    if (!String(manifest.approvedBy || "").trim()) errors.push("The evidence manifest requires an approvedBy identity.");
    const ciRunId = String(expectedCiRunId || "").trim();
    if (ciRunId && String(manifest.ciRunId || "").trim() !== ciRunId) errors.push("The evidence manifest ciRunId does not match the successful CI run.");

    const manifestEvidence = manifest.evidence && typeof manifest.evidence === "object" && !Array.isArray(manifest.evidence) ? manifest.evidence : {};
    const unknownCategories = Object.keys(manifestEvidence).filter((category) => !Object.hasOwn(evidence, category));
    if (unknownCategories.length) errors.push(`The evidence manifest contains unknown categories: ${unknownCategories.join(", ")}.`);
    Object.entries(evidence).forEach(([category, item]) => {
        const entry = manifestEvidence[category];
        if (!entry || typeof entry !== "object") {
            errors.push(`The evidence manifest is missing ${category}.`);
            return;
        }
        if (entry.result !== "passed") errors.push(`Evidence ${category} must have result \"passed\".`);
        const observedAt = Date.parse(String(entry.observedAt || ""));
        if (!Number.isFinite(observedAt)) errors.push(`Evidence ${category} requires a valid ISO-8601 observedAt value.`);
        else {
            if (observedAt > Date.now() + 5 * 60_000) errors.push(`Evidence ${category} observedAt cannot be in the future.`);
            if (Number.isFinite(createdAt) && observedAt > createdAt) errors.push(`Evidence ${category} must be observed before the manifest is created.`);
        }
        if (!String(entry.reviewer || "").trim()) errors.push(`Evidence ${category} requires a reviewer identity.`);
        const reference = String(entry.reference || "").trim();
        if (!immutableReference.test(reference)) errors.push(`Evidence ${category} requires an immutable artifact reference, versioned object URL, or sha256 digest.`);
        if (!checksumPattern.test(String(entry.checksum || "").trim())) errors.push(`Evidence ${category} requires a sha256 checksum.`);
        if (!String(entry.deploymentId || "").trim()) errors.push(`Evidence ${category} requires a deploymentId.`);
        if (/migration/i.test(category) && !String(entry.migrationId || "").trim()) errors.push(`Evidence ${category} requires a migrationId.`);
        if (!item.reference || reference !== item.reference) errors.push(`Evidence ${category} must match ${item.variable}.`);
    });
    return { valid: errors.length === 0, manifest, errors };
}

function run(root = process.cwd()) {
    const findings = [];
    const add = (code, severity, message, file = "") => findings.push({ code, severity, message, file });

    REQUIRED_FILES.forEach((file) => {
        if (!read(root, file)) add("MISSING_RELEASE_FILE", "blocking", `${file} is required for the codewise release gate.`, file);
    });

    const netlify = read(root, "netlify.toml");
    REQUIRED_ROUTES.forEach((route) => {
        if (!netlify.includes(`from = "${route}"`)) add("MISSING_API_ROUTE", "blocking", `${route} is not declared in netlify.toml.`, "netlify.toml");
    });

    const config = read(root, "netlify/functions/config.js");
    ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SCRAPINGBEE_API_KEY", "PREFLIGHT_SIGNING_SECRET", "NETLIFY_AUTH_TOKEN", "UPSTASH_REDIS_REST_URL"].forEach((name) => {
        if (!config.includes(name)) add("CONFIG_CAPABILITY_UNREPORTED", "blocking", `/api/config does not report ${name}.`, "netlify/functions/config.js");
    });

    const deployedSubmit = read(root, "netlify/functions/submit-form.js");
    const submitImplementation = read(root, "netlify_functions_submit_form.js");
    const submitSource = `${deployedSubmit}\n${submitImplementation}`;
    ["limitedResponseAsync", "maxBodyResponse", "consumePublicProjectQuota", "securityHeaders"].forEach((marker) => {
        if (!deployedSubmit.includes(marker)) add("DEPLOYED_FORM_HANDLER_GAP", "blocking", `The deployed form handler is missing ${marker}.`, "netlify/functions/submit-form.js");
    });
    ["DUPLICATE_WINDOW_MS", "Idempotency-Key", "MAX_BODY_LENGTH", "LEADS_WEBHOOK_HOSTS", "persistDeliveryFailure"].forEach((marker) => {
        if (!submitSource.includes(marker)) add("FORM_SAFETY_MARKER_MISSING", "blocking", `Form delivery is missing ${marker}.`, "netlify/functions/submit-form.js");
    });

    const quota = read(root, "netlify/functions/_quota.js");
    ["projects", "versions", "imports", "deployments", "form_submissions", "preview_emails", "team_members", "audits"].forEach((resource) => {
        if (!quota.includes(resource)) add("QUOTA_RESOURCE_MISSING", "blocking", `Server quota does not declare ${resource}.`, "netlify/functions/_quota.js");
    });

    const contract = read(root, "workspace-output-contract.js");
    ["MISSING_CANONICAL", "MISSING_SITEMAP", "MISSING_ROBOTS", "IMAGE_ALT", "UNSAFE_MARKUP", "SOURCE_BUDGET"].forEach((marker) => {
        if (!contract.includes(marker)) add("OUTPUT_CONTRACT_GAP", "blocking", `Generated-output contract is missing ${marker}.`, "workspace-output-contract.js");
    });

    const isolation = read(root, "supabase/work-context-isolation.sql");
    ["approval_history_project_guard", "portal_comments_project_guard", "platform_deployments_project_guard", "analytics_events_project_guard", "projects_context_reassignment_guard"].forEach((marker) => {
        if (!isolation.includes(marker)) add("DATABASE_INTEGRITY_GAP", "blocking", `Tenant migration is missing ${marker}.`, "supabase/work-context-isolation.sql");
    });
    const reliability = read(root, "supabase/reliability.sql");
    ["begin_public_approval_decision", "begin_public_token_operation", "idempotent_operations"].forEach((marker) => {
        if (!reliability.includes(marker)) add("IDEMPOTENCY_GAP", "blocking", `Reliability migration is missing ${marker}.`, "supabase/reliability.sql");
    });
    const files = read(root, "netlify/functions/project-files.js");
    ["verification_status=eq.verified", "sha256", "detectedType", "MAX_FILES_PER_PROJECT", "file.finalize"].forEach((marker) => {
        if (!files.includes(marker)) add("FILE_SECURITY_GAP", "blocking", `File lifecycle is missing ${marker}.`, "netlify/functions/project-files.js");
    });
    const handoffSql = read(root, "supabase/proposal-handoffs.sql");
    const handoffHandler = read(root, "netlify/functions/handoffs.js");
    ["create_project_proposal", "create_project_handoff", "project_handoffs_scope_guard", "projects_handoff_context_guard", "platform_audit_events", "client_portal_shares set revoked_at", "client_approvals set status='revoked'"].forEach((marker) => {
        if (!handoffSql.includes(marker)) add("HANDOFF_PERSISTENCE_GAP", "blocking", `Proposal/handoff persistence is missing ${marker}.`, "supabase/proposal-handoffs.sql");
    });
    ["beginIdempotent", "userRequest", "create_project_handoff", "HANDOFF_WRITE_CONFLICT"].forEach((marker) => {
        if (!handoffHandler.includes(marker)) add("HANDOFF_API_GAP", "blocking", `Proposal/handoff API is missing ${marker}.`, "netlify/functions/handoffs.js");
    });
    if (!netlify.includes('from = "/api/handoffs"')) add("MISSING_API_ROUTE", "blocking", "/api/handoffs is not declared in netlify.toml.", "netlify.toml");
    const tokenClients = ["approval.js", "invitation.js", "portal.js", "proposal.js", "preview.html"].map((file) => read(root, file)).join("\n");
    if (!tokenClients.includes("history.replaceState")) add("TOKEN_URL_LEAK_GAP", "blocking", "Public-token pages must remove credentials from the address bar after capture.");
    if (!tokenClients.includes("Idempotency-Key")) add("TOKEN_IDEMPOTENCY_GAP", "blocking", "Public decisions must send idempotency keys.");

    const evidence = Object.fromEntries(Object.entries(REQUIRED_RUNTIME_EVIDENCE).map(([name, variable]) => {
        const reference = String(process.env[variable] || "").trim();
        return [name, { variable, verified: reference.length > 0, reference: reference || null }];
    }));
    const missingEvidence = Object.entries(evidence).filter(([, item]) => !item.verified).map(([name]) => name);
    const runtimeAttested = process.env.CODEWISE_RELEASE_RUNTIME_VERIFIED === "true";
    const manifestRequired = process.env.CODEWISE_ENFORCE_RUNTIME_RELEASE === "true";
    const manifestValidation = manifestRequired
        ? validateEvidenceManifest(process.env.CODEWISE_RELEASE_EVIDENCE_MANIFEST, process.env.CODEWISE_RELEASE_COMMIT, evidence, process.env.CODEWISE_CI_RUN_ID)
        : { valid: true, manifest: null, errors: [] };
    const runtimeVerified = runtimeAttested && missingEvidence.length === 0 && manifestValidation.valid;
    const incompleteReasons = [];
    if (missingEvidence.length) incompleteReasons.push(`missing categories: ${missingEvidence.join(", ")}`);
    if (!runtimeAttested) incompleteReasons.push("final attestation is missing");
    if (!manifestValidation.valid) incompleteReasons.push(...manifestValidation.errors);
    const runtimeVerification = {
        required: true,
        attested: runtimeAttested,
        verified: runtimeVerified,
        evidence,
        missingEvidence,
        manifest: {
            required: manifestRequired,
            valid: manifestValidation.valid,
            releaseCommit: manifestValidation.manifest && manifestValidation.manifest.releaseCommit || null,
            environmentIdentity: manifestValidation.manifest && manifestValidation.manifest.environment && manifestValidation.manifest.environment.identity || null,
            errors: manifestValidation.errors
        },
        message: runtimeVerified
            ? "Runtime verification was attested with a valid evidence manifest bound to the exact release commit."
            : `Runtime release evidence is incomplete: ${incompleteReasons.join("; ")}. Source checks alone are insufficient.`
    };
    if (process.env.CODEWISE_ENFORCE_RUNTIME_RELEASE === "true" && !runtimeVerified) add("RUNTIME_VERIFICATION_REQUIRED", "blocking", runtimeVerification.message, "docs/STAGING-RELEASE-RECORD.md");

    return {
        ok: !findings.some((finding) => finding.severity === "blocking"),
        generatedAt: new Date().toISOString(),
        releaseContext: {
            commit: String(process.env.CODEWISE_RELEASE_COMMIT || "").trim() || null,
            ciRunId: String(process.env.CODEWISE_CI_RUN_ID || "").trim() || null,
            ciRunUrl: String(process.env.CODEWISE_CI_RUN_URL || "").trim() || null
        },
        requiredFiles: REQUIRED_FILES,
        requiredRoutes: REQUIRED_ROUTES,
        requiredRuntimeEvidence: REQUIRED_RUNTIME_EVIDENCE,
        runtimeVerification,
        findings
    };
}

if (require.main === module) {
    const report = run(process.cwd());
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    process.exitCode = report.ok ? 0 : 1;
}

module.exports = { REQUIRED_FILES, REQUIRED_ROUTES, REQUIRED_RUNTIME_EVIDENCE, validateEvidenceManifest, run };
