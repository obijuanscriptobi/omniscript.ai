"use strict";

(() => {
    const $ = (id) => document.getElementById(id);
    let recommendations = [];

    const fields = {
        name: "input-biz-name",
        hook: "input-biz-hook",
        services: "input-biz-services",
        location: "input-biz-location",
        audience: "input-biz-audience",
        differentiator: "input-biz-differentiator",
        testimonial: "input-biz-testimonial",
        primaryCta: "input-primary-cta",
        responseTime: "input-response-time"
    };

    function canonicalProfile() {
        const service = window.profileService;
        const state = window.workspaceAPI?.getState?.();
        const raw = state?.businessProfile || service?.readLocal?.();
        return raw && service?.normalize ? service.normalize(raw) : null;
    }

    function profileValue(key) {
        const profile = canonicalProfile();
        if (!profile) return "";
        const location = profile.locations?.[0];
        const values = {
            name: profile.identity?.displayName,
            services: profile.services?.join(", "),
            location: location?.city || location?.name || location?.serviceArea?.[0],
            businessType: profile.identity?.businessType,
            brandVoice: profile.brand?.voice
        };
        return String(values[key] || "").trim();
    }

    const value = (key) => $(fields[key])?.value.trim() || profileValue(key) || "";
    const businessType = () => $("input-business-type")?.value || profileValue("businessType") || "local-service";
    const goal = () => $("input-primary-goal")?.value || "quote";

    function recommendation(id, priority, title, reason, field, suggestion) {
        return { id, priority, title, reason, field, suggestion };
    }

    function buildRecommendations() {
        const name = value("name") || "your business";
        const services = value("services").split(",").map((item) => item.trim()).filter(Boolean);
        const service = services[0] || "your service";
        const location = value("location");
        const audience = value("audience");
        const type = businessType();
        const primaryGoal = goal();
        const ctaLabels = {
            quote: "Get a clear quote",
            booking: "Book an appointment",
            call: "Talk to us today",
            email: "Send an enquiry",
            shop: "Explore the collection"
        };
        const result = [];

        if (!value("name")) {
            result.push(recommendation("name", "high", "Add your business name", "A real name makes the page feel trustworthy and gives search engines a clear entity.", "name", "Your business"));
        }
        if (!value("hook")) {
            const subject = audience ? ` for ${audience}` : location ? ` in ${location}` : "";
            result.push(recommendation("hook", "high", "Make the headline outcome-led", "Visitors should understand what changes for them within a few seconds.", "hook", `${service}${subject}, made simple.`));
        } else if (/\b(?:quality|professional|trusted|reliable|expert|solutions?|services?)\b/i.test(value("hook")) || value("hook").length < 18) {
            const subject = audience ? ` for ${audience}` : location ? ` in ${location}` : "";
            result.push(recommendation("hook", "medium", "Replace the generic headline", "The current headline describes a category but not a specific customer outcome.", "hook", `${service}${subject}, made simple.`));
        }
        if (!audience) {
            const audienceByType = {
                restaurant: "people looking for a memorable meal",
                wellness: "people ready for thoughtful personal care",
                creative: "ambitious brands ready to move forward",
                professional: "people who want clear expert guidance",
                retail: "people looking for useful, well-made products",
                "local-service": location ? `local customers in ${location}` : "local customers who value dependable service"
            };
            result.push(recommendation("audience", "high", "Name your ideal customer", "Specific audiences make the message more relevant and help the right visitors self-identify.", "audience", audienceByType[type] || audienceByType["local-service"]));
        }
        if (!value("differentiator")) {
            result.push(recommendation("differentiator", "medium", "Explain why customers choose you", "A clear difference gives visitors a reason to choose you instead of a similar provider.", "differentiator", `Thoughtful ${service.toLowerCase()} with clear communication and personal attention.`));
        }
        if (!value("primaryCta")) {
            result.push(recommendation("primaryCta", "high", "Use a specific primary CTA", "Specific action language reduces hesitation and makes the next step obvious.", "primaryCta", ctaLabels[primaryGoal] || "Start a conversation"));
        }
        if (!value("responseTime")) {
            result.push(recommendation("responseTime", "medium", "Set a response expectation", "Telling visitors what happens after they enquire makes the form feel safer to complete.", "responseTime", "We usually reply within one business day."));
        }
        if (!value("testimonial")) {
            result.push(recommendation("testimonial", "low", "Add customer proof", "A real result or customer quote is one of the strongest ways to build confidence.", "testimonial", "Add a short customer quote or measurable result here."));
        }
        if (!services.length) {
            result.push(recommendation("services", "high", "List your main services", "Visitors need to know what they can buy, book, or ask about.", "services", "Your main service"));
        }
        return result;
    }

    function render() {
        const list = $("content-review-results");
        const status = $("content-review-status");
        const score = $("content-review-score");
        if (!list || !status || !score) return;
        recommendations = buildRecommendations();
        const high = recommendations.filter((item) => item.priority === "high").length;
        const completed = Math.max(0, 100 - recommendations.reduce((total, item) => total + (item.priority === "high" ? 18 : item.priority === "medium" ? 10 : 5), 0));
        score.textContent = `${completed}/100`;
        status.textContent = recommendations.length
            ? `${recommendations.length} recommendation${recommendations.length === 1 ? "" : "s"} to review. Nothing changes until you approve it.`
            : "Your core message is clear. Review the generated page before publishing.";
        list.replaceChildren(...(recommendations.length ? recommendations : [{ title: "Content review passed", reason: "The essentials are present. Consider adding richer proof or customer-specific details as you learn more." }]).map((item) => {
            const row = document.createElement("li");
            row.dataset.priority = item.priority || "low";
            const content = document.createElement("div");
            const title = document.createElement("strong");
            title.textContent = item.title;
            const reason = document.createElement("span");
            reason.textContent = item.reason;
            content.append(title, reason);
            row.append(content);
            if (item.suggestion) {
                const suggestion = document.createElement("code");
                suggestion.textContent = item.suggestion;
                const button = document.createElement("button");
                button.type = "button";
                button.className = "matrix-action-btn variant-outline-row";
                button.textContent = "Use suggestion";
                button.addEventListener("click", () => approve(item));
                row.append(suggestion, button);
            }
            return row;
        }));
        const approveAll = $("approve-content-suggestions-btn");
        if (approveAll) approveAll.disabled = !recommendations.some((item) => item.suggestion && item.field !== "testimonial");
    }

    function approve(item) {
        const input = $(fields[item.field]);
        if (!input || !item.suggestion) return;
        input.value = item.suggestion;
        input.dispatchEvent(new Event("input", { bubbles: true }));
        render();
        $("content-review-status").textContent = `Approved: ${item.title}. Review the updated brief, then create the website.`;
        input.focus();
    }

    function approveAll() {
        buildRecommendations().filter((item) => item.suggestion && item.field !== "testimonial").forEach((item) => {
            const input = $(fields[item.field]);
            if (input) {
                input.value = item.suggestion;
                input.dispatchEvent(new Event("input", { bubbles: true }));
            }
        });
        render();
        const status = $("content-review-status");
        if (status) status.textContent = "Approved suggestions were added to your brief. Create the website when you are ready.";
    }

    function bind() {
        $("run-content-review-btn")?.addEventListener("click", render);
        $("approve-content-suggestions-btn")?.addEventListener("click", approveAll);
        document.addEventListener("input", (event) => {
            if (Object.values(fields).includes(event.target.id)) setTimeout(render, 100);
        });
        $("previewContentIframe")?.addEventListener("load", () => setTimeout(render, 150));
        render();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
    window.contentReview = Object.freeze({
        buildRecommendations,
        render,
        canonicalProfile
    });
})();
