"use strict";

// Shared lead -> audit -> generator handoff. Records stay local-first and can
// later be mirrored by the project/revision API without changing the shape.
(() => {
    const CONTEXT_KEY = "morrow-website-generator-context-v1";
    const REVISION_KEY = "morrow-site-revisions-v1";
    const clean = (value, max = 1200) => String(value ?? "").trim().slice(0, max);
    const id = (prefix) => globalThis.crypto?.randomUUID?.() || `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const scopedKey = (key) => window.workspaceContext?.storageKey?.(key) || key;
    const readJson = (key, fallback) => { try { return JSON.parse(localStorage.getItem(scopedKey(key)) || ""); } catch (_) { return fallback; } };
    const writeJson = (key, value) => { try { localStorage.setItem(scopedKey(key), JSON.stringify(value)); } catch (_) {} return value; };

    function factsFromAudit(audit = {}) {
        const source = audit.sourceEvidence || {};
        return Object.entries({
            businessName: source.businessName,
            location: source.location,
            phone: source.phone,
            email: source.email,
            rating: source.rating,
            reviewCount: source.reviewCount
        }).filter(([, value]) => value !== undefined && value !== null && String(value).trim() !== "").map(([key, value]) => ({
            key, value, sourceUrl: source.sourceUrl || audit.finalUrl || audit.websiteUrl || "", confidence: source[`${key}Evidence`]?.confidence === "direct" ? 1 : 0.5,
            status: source[`${key}Evidence`]?.confidence === "direct" ? "verified" : "needs-review"
        }));
    }

    function buildSiteBrief(audit = {}) {
        const findings = Array.isArray(audit.findings) ? audit.findings : [];
        const facts = factsFromAudit(audit);
        const blocked = findings.filter((item) => item.remediation === "blocked");
        return {
            auditId: audit.id || "", projectId: audit.projectId || "", sourceUrl: audit.finalUrl || audit.websiteUrl || "",
            verifiedFacts: facts.filter((item) => item.status === "verified"),
            missingFacts: ["bookingUrl", "hours"].filter((key) => !facts.some((item) => item.key === key)),
            findings: findings.map((item) => ({ id: item.id || id("finding"), issue: clean(item.issue, 500), impact: item.impact || "medium", recommendation: clean(item.recommendation, 900), evidence: item.evidence || {}, remediation: item.remediation || "review-required", confidence: Number(item.confidence) || 0 })),
            requestedChanges: findings.filter((item) => item.remediation !== "blocked").map((item) => clean(item.recommendation || item.issue, 500)).filter(Boolean),
            blockedChanges: blocked.map((item) => clean(item.issue, 500)).filter(Boolean)
        };
    }

    function createContext(input = {}) {
        const audit = input.audit || {};
        return {
            version: 1, mode: input.mode || "audit-improvement", createdAt: new Date().toISOString(),
            workContextId: clean(input.workContextId || audit.workContextId || window.workspaceContext?.current?.()?.id || "own-business", 120),
            projectId: clean(input.projectId || audit.projectId, 120), leadId: clean(input.leadId || audit.leadId, 120), auditId: clean(input.auditId || audit.id, 120), revisionId: clean(input.revisionId, 120),
            sourceWebsite: clean(input.sourceWebsite || audit.finalUrl || audit.websiteUrl, 1000),
            business: input.business || {}, businessFacts: input.businessFacts || factsFromAudit(audit), auditFindings: input.auditFindings || audit.findings || [],
            siteBrief: input.siteBrief || buildSiteBrief(audit), improvementPlan: input.improvementPlan || { status: "draft", requestedChanges: buildSiteBrief(audit).requestedChanges },
            approvalRequired: true
        };
    }

    function saveContext(context) { return writeJson(CONTEXT_KEY, createContext(context)); }
    function readContext() { return readJson(CONTEXT_KEY, null); }
    function changeFromFinding(finding = {}) {
        const remediation = ["safe-auto", "review-required", "blocked"].includes(finding.remediation) ? finding.remediation : "review-required";
        return { id: id("change"), findingId: finding.id || "", type: finding.type || "content", files: Array.isArray(finding.files) ? finding.files : [], summary: clean(finding.recommendation || finding.issue, 900), evidence: finding.evidence || {}, impact: finding.impact || "medium", remediation, approval: remediation === "safe-auto" ? "approved" : remediation === "blocked" ? "blocked" : "pending", operation: finding.operation && typeof finding.operation === "object" ? finding.operation : null };
    }
    function createRevision(context, changes = []) {
        const findings = changes.length ? changes : (context.auditFindings || []).map(changeFromFinding);
        const revision = { id: id("revision"), workContextId: context.workContextId || window.workspaceContext?.current?.()?.id || "own-business", projectId: context.projectId || "", leadId: context.leadId || "", auditId: context.auditId || "", parentRevisionId: context.revisionId || "", baseVersion: context.sourceWebsite || "imported-site", status: "draft", brief: context.siteBrief || {}, changes: findings, validation: { accessibility: "pending", links: "pending", forms: "pending", responsive: "pending", performance: "pending" }, screenshots: { before: {}, after: {} }, beforeScores: {}, afterScores: {}, deploymentId: "", approvedAt: "", approvedBy: "", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        const revisions = readJson(REVISION_KEY, []); writeJson(REVISION_KEY, [...(Array.isArray(revisions) ? revisions.filter((item) => item.id !== revision.id) : []), revision].slice(-100));
        return revision;
    }
    function listRevisions() { const value = readJson(REVISION_KEY, []); return Array.isArray(value) ? value : []; }
    function updateRevision(idValue, patch = {}) { const next = listRevisions().map((item) => item.id === idValue ? { ...item, ...patch, updatedAt: new Date().toISOString() } : item); writeJson(REVISION_KEY, next); return next.find((item) => item.id === idValue) || null; }
    function approveChange(revisionId, changeId, approved = true) { const revision = listRevisions().find((item) => item.id === revisionId); if (!revision) return null; const changes = (revision.changes || []).map((item) => item.id === changeId ? { ...item, approval: item.remediation === "blocked" ? "blocked" : approved ? "approved" : "rejected" } : item); return updateRevision(revisionId, { changes, status: "draft" }); }
    function applyApprovedChanges(files = {}, revision) { const next = { ...files }; const applied = []; const skipped = []; const conflicts = []; (revision?.changes || []).forEach((change) => { const operation = change.operation; if (change.approval !== "approved" || !operation) { skipped.push(change.id || "unknown"); return; } const file = String(operation.file || ""); const before = String(operation.before || ""); if (!file || typeof next[file] !== "string" || !before || !next[file].includes(before)) { const idValue = change.id || "unknown"; skipped.push(idValue); conflicts.push({ changeId: idValue, file, reason: !file || typeof next[file] !== "string" ? "file-unavailable" : "expected-text-not-found" }); return; } next[file] = next[file].replace(before, String(operation.after ?? "")); applied.push(change.id); }); return { files: next, applied, skipped, conflicts, conflicted: conflicts.length > 0 }; }
    async function persistRevision(revision, options = {}) { try { const response = await fetch(options.endpoint || "/api/revisions", { method: options.update ? "PATCH" : "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ ...revision, projectId: revision.projectId, leadId: revision.leadId, auditId: revision.auditId, deploymentId: revision.deploymentId || "" }) }); const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || "Revision persistence failed."); return data.revision || revision; } catch (error) { return { ...revision, persistenceError: error.message }; } }
    function captureVisualEvidence(revision, phase = "after", options = {}) {
        const frame = options.iframe || document.getElementById("previewContentIframe");
        const documentRef = frame?.contentDocument;
        const evidence = window.visualEvidence?.score?.(documentRef || document, options.viewport || {}) || { capturedAt: new Date().toISOString(), unavailable: true, reason: "Preview document is not accessible." };
        const screenshots = { ...(revision?.screenshots || {}) };
        screenshots[phase] = { ...evidence, source: documentRef ? "preview-dom" : "unavailable" };
        const patch = phase === "before" ? { screenshots, beforeScores: evidence } : { screenshots, afterScores: evidence };
        return revision ? updateRevision(revision.id, patch) : patch;
    }
    function compareRevisionVisualEvidence(revision) {
        return window.visualEvidence?.compare?.(revision?.beforeScores || {}, revision?.afterScores || {}) || {};
    }
    function attachVisualAuditReport(audit = {}, revision = null, report = {}) {
        const visual = report.auditPatch?.visual || report.visual || report;
        const auditPatch = { visual, checkedAt: report.auditPatch?.checkedAt || new Date().toISOString(), state: report.auditPatch?.state || "audit-complete" };
        const nextAudit = window.websiteAuditContract?.upsert?.({ ...audit, ...auditPatch });
        if (!revision) return { audit: nextAudit, revision: null };
        const patch = report.revisionPatch || {};
        const nextRevision = updateRevision(revision.id, { ...patch, validation: { ...(revision.validation || {}), ...(patch.validation || {}) } });
        return { audit: nextAudit, revision: nextRevision };
    }
    function openGenerator(context = {}) { const next = saveContext(context); const query = new URLSearchParams({ mode: next.mode, projectId: next.projectId, leadId: next.leadId, auditId: next.auditId }); window.location.href = `index.html?${query.toString()}`; }

    window.conversionLoop = Object.freeze({ CONTEXT_KEY, REVISION_KEY, factsFromAudit, buildSiteBrief, changeFromFinding, createContext, saveContext, readContext, createRevision, listRevisions, updateRevision, approveChange, applyApprovedChanges, persistRevision, captureVisualEvidence, compareRevisionVisualEvidence, attachVisualAuditReport, openGenerator });
})();
