"use strict";

(() => {
    const STORAGE_KEY = "studio-conversion-signals";
    const storageKey = () => window.workspaceContext?.storageKey?.(STORAGE_KEY) || STORAGE_KEY;
    const MAX_FIXES = 8;
    let refreshTimer = null;

    const $ = (id) => document.getElementById(id);

    function readSignals() {
        try {
            const saved = JSON.parse(localStorage.getItem(storageKey()) || "null");
            return saved && typeof saved === "object"
                ? { pageViews: 0, ctaClicks: 0, formStarts: 0, formSubmissions: 0, ...saved }
                : { pageViews: 0, ctaClicks: 0, formStarts: 0, formSubmissions: 0 };
        } catch {
            return { pageViews: 0, ctaClicks: 0, formStarts: 0, formSubmissions: 0 };
        }
    }

    function recordSignal(name) {
        const signals = readSignals();
        signals[name] = Number(signals[name] || 0) + 1;
        signals.lastEventAt = new Date().toISOString();
        try { localStorage.setItem(storageKey(), JSON.stringify(signals)); } catch {}
        renderAnalytics(signals);
    }

    function getBusiness() {
        const value = (id) => $(id)?.value.trim() || "";
        return {
            goal: $("input-primary-goal")?.value || "quote",
            cta: value("input-primary-cta"),
            phone: value("input-biz-phone"),
            email: value("input-biz-email"),
            booking: value("input-biz-booking"),
            name: value("input-biz-name"),
            hook: value("input-biz-hook"),
            services: value("input-biz-services"),
            location: value("input-biz-location"),
            audience: value("input-biz-audience"),
            differentiator: value("input-biz-differentiator"),
            credentials: value("input-biz-credentials"),
            experience: value("input-biz-experience"),
            customers: value("input-biz-customers"),
            hours: value("input-biz-hours"),
            pricing: value("input-biz-pricing"),
            testimonial: value("input-biz-testimonial"),
            responseTime: value("input-response-time"),
            endpoint: value("input-form-endpoint") || "/api/submit-form"
        };
    }

    function pageHtml() {
        const iframe = $("previewContentIframe");
        return iframe?.contentDocument?.documentElement?.outerHTML || $("outputContainerHtml")?.textContent || "";
    }

    function addFix(fixes, priority, title, detail, action) {
        fixes.push({ priority, title, detail, action });
    }

    function buildReadiness() {
        const business = getBusiness();
        const html = pageHtml();
        const fixes = [];
        const checks = [];
        const has = (pattern) => pattern.test(html);
        const addCheck = (passed, weight) => checks.push({ passed, weight });
        const goalLabels = {
            quote: "request a quote",
            booking: "book an appointment",
            call: "call the business",
            email: "send an email",
            shop: "explore products"
        };
        const goalLabel = goalLabels[business.goal] || "take the primary action";

        if (!html || /Awaiting Data Submission/i.test(html)) {
            return { score: 0, fixes: [{ priority: "high", title: "Create a website first", detail: "Compile or import a website so Studio can check its content and conversion path.", action: "Compile your website, then run the quality check." }] };
        }

        const links = [...html.matchAll(/<a\b([^>]*)href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)]
            .map((match) => ({ attrs: match[1], href: match[2], text: match[3].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim() }));
        const forms = [...html.matchAll(/<form\b([^>]*)>/gi)].map((match) => match[1]);
        const primaryAction = links.some((link) => /button|nav-cta/i.test(link.attrs) || /quote|book|call|contact|email|buy|shop|schedule/i.test(link.text))
            || forms.some((attrs) => /data-site-form|action=/i.test(attrs));
        const goalConnected = business.goal === "call" ? Boolean(business.phone) && links.some((link) => /^tel:/i.test(link.href))
            : business.goal === "email" ? Boolean(business.email) && links.some((link) => /^mailto:/i.test(link.href))
                : business.goal === "booking" ? Boolean(business.booking) && links.some((link) => link.href === business.booking || /cal\.com|book|booking|schedule/i.test(link.href))
                    : business.goal === "shop" ? links.some((link) => /shop|product|buy|cart|catalog/i.test(`${link.href} ${link.text}`))
                        : forms.some((attrs) => /data-site-form|action=/i.test(attrs));

        addCheck(Boolean(business.name), 12);
        addCheck(Boolean(business.hook), 14);
        addCheck(Boolean(business.services), 8);
        addCheck(Boolean(business.location), 6);
        addCheck(primaryAction, 16);
        addCheck(goalConnected, 20);
        addCheck(has(/<h1\b/i), 10);
        addCheck(Boolean(business.testimonial || business.differentiator || business.credentials || business.experience || business.customers), 6);
        addCheck(business.endpoint !== "/api/submit-form", 8);

        if (!business.name) addFix(fixes, "high", "Add your business name", "Visitors should immediately know who is offering the service.", "Fill in Business name.");
        if (!business.hook) addFix(fixes, "high", "Clarify the customer outcome", "Your headline needs to explain what changes for the customer, not just describe the business.", "Fill in What do you help people do?");
        if (!primaryAction) addFix(fixes, "high", `Add a clear way to ${goalLabel}`, "A visible next step gives visitors somewhere to go after reading the headline.", "Add a primary call to action or contact form.");
        if (!goalConnected) addFix(fixes, "high", `Connect the page to ${goalLabel}`, `The selected goal is not backed by a usable link, form, or product path.`, `Add the required ${business.goal === "call" ? "phone number" : business.goal === "email" ? "public email" : business.goal === "booking" ? "booking link" : "contact or product action"}.`);
        if (!business.cta) addFix(fixes, "medium", "Strengthen the CTA label", "Specific labels usually outperform vague buttons such as Learn more.", `Add a benefit-led label such as ${business.goal === "booking" ? "Book my appointment" : business.goal === "call" ? "Call for a free estimate" : "Get my free estimate"}.`);
        if (!business.testimonial && !business.differentiator && !business.credentials) addFix(fixes, "medium", "Add one trust signal", "A testimonial, credential, differentiator, or measurable result reduces hesitation before the action.", "Add trust details in the advanced tools.");
        if (!business.responseTime && ["quote", "booking", "email"].includes(business.goal)) addFix(fixes, "medium", "Set an expectation after enquiry", "Tell visitors when they can expect a reply to make submitting feel safer.", "Add a typical response time.");
        if (!/^\/(?!\/)[^\s<>"']{1,280}$/.test(business.endpoint)) addFix(fixes, "high", "Fix the form endpoint", "The form destination is not a valid same-origin path, so enquiries may not reach your server.", "Use a same-origin endpoint such as /api/submit-form.");
        else addFix(fixes, "medium", "Run a real lead-delivery test", "The form endpoint is configured, but a successful browser response does not prove that the lead reached your inbox or CRM.", "Submit a test enquiry and confirm delivery in the production system.");
        if (!business.audience) addFix(fixes, "low", "Name your best-fit audience", "Specific audience language makes the headline and offer feel more relevant.", "Add Who do you serve?");

        const total = checks.reduce((sum, check) => sum + check.weight, 0);
        const passed = checks.reduce((sum, check) => sum + (check.passed ? check.weight : 0), 0);
        return { score: Math.round((passed / total) * 100), fixes: fixes.slice(0, MAX_FIXES) };
    }

    function renderReadiness() {
        const output = buildReadiness();
        const score = $("launch-readiness-score");
        const bar = $("launch-readiness-bar");
        const summary = $("launch-readiness-summary");
        const list = $("launch-readiness-fixes");
        if (!score || !bar || !summary || !list) return output;

        score.textContent = `${output.score}/100`;
        score.dataset.scoreState = output.score >= 85 ? "excellent" : output.score >= 60 ? "needs-review" : "needs-attention";
        bar.style.width = `${output.score}%`;
        summary.textContent = output.score >= 85
            ? "Strong launch foundation. Run one test enquiry and review the mobile preview before publishing."
            : `${output.fixes.length} prioritized improvement${output.fixes.length === 1 ? "" : "s"} before launch.`;
        list.replaceChildren(...output.fixes.map((fix) => {
            const item = document.createElement("li");
            item.dataset.priority = fix.priority;
            item.innerHTML = `<strong>${escapeText(fix.title)}</strong><span>${escapeText(fix.detail)}</span><em>${escapeText(fix.action)}</em>`;
            return item;
        }));
        return output;
    }

    function escapeText(value) {
        const node = document.createElement("span");
        node.textContent = value;
        return node.innerHTML;
    }

    function renderAnalytics(signals = readSignals()) {
        const mappings = {
            "analytics-page-views": signals.pageViews,
            "analytics-cta-clicks": signals.ctaClicks,
            "analytics-form-starts": signals.formStarts,
            "analytics-form-submissions": signals.formSubmissions
        };
        Object.entries(mappings).forEach(([id, value]) => { if ($(id)) $(id).textContent = String(value || 0); });
        const insight = $("launch-analytics-insight");
        if (!insight) return;
        const views = Number(signals.pageViews || 0);
        const clicks = Number(signals.ctaClicks || 0);
        const submissions = Number(signals.formSubmissions || 0);
        if (views < 10) insight.textContent = "Publish your site and collect a few visits to receive an improvement suggestion. Preview visits are excluded from these production signals.";
        else if (!clicks) insight.textContent = "Your CTA has received no clicks yet. Try a more specific benefit-led label and check that it is visible above the fold.";
        else if (!submissions && clicks >= 5) insight.textContent = "Visitors are clicking the CTA but no submissions are recorded. Shorten the form and clarify the response time or next step.";
        else insight.textContent = `${clicks} CTA click${clicks === 1 ? "" : "s"} and ${submissions} submission${submissions === 1 ? "" : "s"} recorded. Keep testing the message and offer.`;
    }

    function bindFrame() {
        const frame = $("previewContentIframe");
        const doc = frame?.contentDocument;
        if (!doc || doc.body?.dataset.conversionBound === "true") return;
        if (doc.body) doc.body.dataset.conversionBound = "true";
        // Preview interactions are intentionally not counted as production analytics.
        // The preview is a design surface, not a real visitor session.
    }

    function scheduleRefresh() {
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(() => { renderReadiness(); bindFrame(); }, 180);
    }

    document.addEventListener("input", scheduleRefresh, true);
    document.addEventListener("change", scheduleRefresh, true);
    $("previewContentIframe")?.addEventListener("load", scheduleRefresh);
    $("run-quality-check-btn")?.addEventListener("click", scheduleRefresh);
    window.addEventListener("workspace:deployment-complete", scheduleRefresh);
    renderAnalytics();
    scheduleRefresh();

    window.conversionLoop = { buildReadiness, renderReadiness, recordSignal, readSignals };
})();
