"use strict";

const fs = require("node:fs");
const path = require("node:path");

function fail(message) {
    process.stderr.write(`Dependency lock audit failed: ${message}\n`);
    process.exitCode = 1;
}

function sameEntries(actual = {}, expected = {}) {
    const actualEntries = Object.entries(actual).sort(([left], [right]) => left.localeCompare(right));
    const expectedEntries = Object.entries(expected).sort(([left], [right]) => left.localeCompare(right));
    return JSON.stringify(actualEntries) === JSON.stringify(expectedEntries);
}

let manifest;
let lockfile;
try {
    manifest = JSON.parse(fs.readFileSync(path.join(process.cwd(), "package.json"), "utf8"));
    lockfile = JSON.parse(fs.readFileSync(path.join(process.cwd(), "package-lock.json"), "utf8"));
} catch (error) {
    fail(error instanceof Error ? error.message : "package.json and package-lock.json must be valid JSON.");
    return;
}

if (lockfile.lockfileVersion !== 3) fail("package-lock.json must use lockfileVersion 3.");
if (!lockfile.packages || typeof lockfile.packages !== "object" || !lockfile.packages[""]) {
    fail("package-lock.json must contain root package metadata.");
    return;
}

const root = lockfile.packages[""];
if (root.name !== manifest.name || root.version !== manifest.version) fail("root package name/version does not match package.json.");
if (!sameEntries(root.dependencies, manifest.dependencies)) fail("production dependencies do not match package.json.");
if (!sameEntries(root.devDependencies, manifest.devDependencies)) fail("development dependencies do not match package.json.");

for (const [location, entry] of Object.entries(lockfile.packages)) {
    if (!location || !entry || typeof entry !== "object") continue;
    if (entry.link) fail(`${location} is a local/link dependency.`);
    if (entry.resolved) {
        let resolved;
        try {
            resolved = new URL(entry.resolved);
        } catch {
            fail(`${location} has an invalid resolved URL.`);
            continue;
        }
        if (resolved.protocol !== "https:" || resolved.hostname !== "registry.npmjs.org") {
            fail(`${location} resolves outside https://registry.npmjs.org/.`);
        }
        if (!String(entry.integrity || "").match(/^sha(?:256|384|512)-[A-Za-z0-9+/=]+$/)) {
            fail(`${location} is missing a supported integrity digest.`);
        }
    }
}

if (!process.exitCode) process.stdout.write(`Dependency lock audit passed for ${Object.keys(lockfile.packages).length - 1} package entries.\n`);
