"use strict";

// Seeded art direction: creative choices vary independently while engineering,
// accessibility, evidence, and security constraints remain deterministic.
(() => {
    const DIMENSIONS = Object.freeze({
        navigation: Object.freeze(["balanced", "offset-minimal", "compact-frame", "editorial-line"]),
        hero: Object.freeze(["split-art", "centered-statement", "asymmetric-editorial", "stacked-poster"]),
        rhythm: Object.freeze(["steady", "alternating", "chaptered", "cinematic"]),
        cards: Object.freeze(["outlined", "borderless-numbered", "soft-elevated", "graphic-block"]),
        imageTreatment: Object.freeze(["framed", "full-bleed", "soft-crop", "editorial-inset"]),
        grid: Object.freeze(["balanced", "featured-first", "offset", "compact"]),
        ctaPattern: Object.freeze(["single-focus", "contextual-repeat", "sticky-mobile", "closing-emphasis"]),
        density: Object.freeze(["airy", "balanced", "compact"]),
        motion: Object.freeze(["none", "subtle-reveal", "gentle-shift"]),
        motif: Object.freeze(["linework", "oversized-index", "soft-orbit", "color-block"])
    });

    const PROFILES = Object.freeze([
        "editorial-luxury", "swiss-grid", "soft-organic", "technical-precision", "high-energy-retail",
        "cinematic-portfolio", "utility-local", "warm-hospitality", "minimal-product", "expressive-studio"
    ]);

    let sequence = 0;
    const text = (value, maximum = 160) => String(value ?? "").replace(/[<>\u0000-\u001f]/g, " ").trim().slice(0, maximum);
    function hash(value) {
        let result = 2166136261;
        for (const character of String(value)) {
            result ^= character.charCodeAt(0);
            result = Math.imul(result, 16777619);
        }
        return result >>> 0;
    }
    function pick(values, seed, salt) {
        return values[hash(`${seed}:${salt}`) % values.length];
    }
    function createVariationId(projectId = "project") {
        sequence += 1;
        const entropy = typeof crypto !== "undefined" && crypto.getRandomValues
            ? crypto.getRandomValues(new Uint32Array(1))[0].toString(36)
            : `${Date.now().toString(36)}-${sequence.toString(36)}`;
        return `${text(projectId, 48).replace(/[^a-z0-9-]/gi, "-") || "project"}-${entropy}`;
    }
    function create(input = {}) {
        const business = input.business && typeof input.business === "object" ? input.business : input;
        const design = input.design && typeof input.design === "object" ? input.design : {};
        const projectId = text(input.projectId || business.id || business.name || "project", 80);
        const variationId = text(input.variationId || design.variationId, 80) || createVariationId(projectId);
        const seed = [projectId, variationId, business.type, business.name, business.audience, design.direction].map((item) => text(item)).join("|");
        const genome = {};
        Object.entries(DIMENSIONS).forEach(([name, values]) => { genome[name] = pick(values, seed, name); });
        if (DIMENSIONS.density.includes(design.density)) genome.density = design.density;
        if (DIMENSIONS.motion.includes(design.motion)) genome.motion = design.motion;
        const profile = PROFILES.includes(design.profile) ? design.profile : pick(PROFILES, seed, "profile");
        const fingerprint = fingerprintOf({ profile, ...genome });
        return Object.freeze({ version: 1, variationId, seedHash: hash(seed).toString(36), profile, genome: Object.freeze(genome), fingerprint });
    }
    function fingerprintOf(value = {}) {
        const normalized = [value.profile, ...Object.keys(DIMENSIONS).map((key) => value.genome?.[key] || value[key] || "")].join("|");
        return hash(normalized).toString(36).padStart(7, "0");
    }
    function similarity(left = {}, right = {}) {
        const a = left.genome || left;
        const b = right.genome || right;
        const keys = Object.keys(DIMENSIONS);
        const matches = keys.filter((key) => a[key] && a[key] === b[key]).length + (left.profile && left.profile === right.profile ? 1 : 0);
        return matches / (keys.length + 1);
    }
    function createDistinct(input = {}, recent = [], threshold = 0.72) {
        let candidate;
        for (let attempt = 0; attempt < 12; attempt += 1) {
            candidate = create({ ...input, variationId: attempt ? `${input.variationId || createVariationId(input.projectId)}-${attempt}` : input.variationId });
            if (!recent.some((item) => similarity(candidate, item) >= threshold)) return candidate;
        }
        return candidate;
    }

    const api = Object.freeze({ DIMENSIONS, PROFILES, create, createDistinct, createVariationId, fingerprintOf, similarity });
    if (typeof window !== "undefined") window.workspaceDesignGenome = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
