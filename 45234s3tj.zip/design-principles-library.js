"use strict";

// Original, abstract design guidance. This stores transferable principles—not
// third-party layouts, source code, branding, screenshots, or copied wording.
(() => {
    const PRINCIPLES = Object.freeze([
        { id: "cta-contextual-reassurance", category: "cta", goals: ["booking", "consultation", "quote"], principles: ["Establish value before the primary action.", "Place concise, factual reassurance beside the action.", "Keep one visually dominant action per viewport."], avoid: ["Unsupported urgency", "Competing primary buttons", "Preselected consent"] },
        { id: "booking-progressive-commitment", category: "booking", goals: ["booking", "reservation"], principles: ["Ask for the minimum information needed at each step.", "Explain what happens after submission.", "Keep service and date preferences keyboard accessible."], avoid: ["Implied availability", "Hidden policies", "Dead-end confirmation states"] },
        { id: "sales-decision-clarity", category: "sales", goals: ["purchase"], principles: ["Lead with customer value before feature detail.", "Make comparison criteria scannable.", "Show delivery, returns, and price details only when supplied."], avoid: ["Fabricated scarcity", "Unverified savings", "Ambiguous purchase actions"] },
        { id: "proof-near-decision", category: "trust", goals: ["quote", "consultation", "purchase", "booking"], principles: ["Place verified proof near high-commitment decisions.", "Label the source and context of proof.", "Omit proof modules when evidence is absent."], avoid: ["Anonymous invented praise", "Decorative trust badges", "Unsupported guarantees"] },
        { id: "editorial-rhythm", category: "visual", goals: ["enquiry", "consultation"], principles: ["Alternate dense information with visual breathing room.", "Use scale and spacing before decoration.", "Give each section one clear reading purpose."], avoid: ["Uniform card walls", "Excessive dividers", "Decoration without hierarchy"] },
        { id: "mobile-primary-path", category: "mobile", goals: ["call", "booking", "reservation", "quote"], principles: ["Keep the next action reachable without obscuring content.", "Collapse grids without changing reading order.", "Use touch targets of at least 44 CSS pixels."], avoid: ["Wrapped navigation", "Horizontal scrolling", "Sticky controls covering form fields"] },
        { id: "form-confidence", category: "forms", goals: ["quote", "consultation", "enquiry", "booking"], principles: ["Use persistent labels and useful autocomplete tokens.", "Explain why sensitive information is requested.", "Provide an explicit success or next-step state."], avoid: ["Placeholder-only labels", "Unnecessary required fields", "Vague error messages"] }
    ]);

    function select(input = {}, maximum = 4) {
        const goal = String(input.goal || input.conversionGoal || "enquiry");
        const categories = new Set(Array.isArray(input.categories) ? input.categories : []);
        return PRINCIPLES
            .map((item) => ({ item, score: (item.goals.includes(goal) ? 3 : 0) + (categories.has(item.category) ? 2 : 0) }))
            .sort((a, b) => b.score - a.score || a.item.id.localeCompare(b.item.id))
            .slice(0, Math.max(1, Math.min(6, Number(maximum) || 4)))
            .map(({ item }) => item);
    }

    const api = Object.freeze({ PRINCIPLES, select });
    if (typeof window !== "undefined") window.workspaceDesignPrinciples = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
