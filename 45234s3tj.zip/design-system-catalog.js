"use strict";

// Curated, deterministic design choices shared by the local generator and the
// AI planning boundary. Models may select from this catalog, but cannot invent
// foundational tokens or required page structure.
(() => {
    const SYSTEMS = Object.freeze({
        premium: Object.freeze({
            id: "premium",
            label: "Quiet editorial",
            suitableFor: Object.freeze(["professional", "creative", "retail"]),
            tokens: Object.freeze({
                paper: "#f5f1e8", ink: "#17202a", surface: "#fffdf8", muted: "#66717c", dark: "#17202a", soft: "#e7dfd1",
                serif: "Georgia, 'Times New Roman', serif", radius: "2px", hero: "left", heroSize: "720px",
                heroOverlay: "linear-gradient(90deg,rgba(10,18,25,.88),rgba(10,18,25,.20))", headingWeight: "400"
            })
        }),
        modern: Object.freeze({
            id: "modern",
            label: "Clear modern",
            suitableFor: Object.freeze(["professional", "wellness", "local-service"]),
            tokens: Object.freeze({
                paper: "#eef5f7", ink: "#102331", surface: "#ffffff", muted: "#587080", dark: "#0d5260", soft: "#d9edf0",
                serif: "Inter, ui-sans-serif, system-ui, sans-serif", radius: "14px", hero: "center", heroSize: "620px",
                heroOverlay: "linear-gradient(180deg,rgba(5,35,45,.70),rgba(5,35,45,.92))", headingWeight: "750"
            })
        }),
        bold: Object.freeze({
            id: "bold",
            label: "Bold signal",
            suitableFor: Object.freeze(["creative", "restaurant", "retail"]),
            tokens: Object.freeze({
                paper: "#fff3e3", ink: "#241515", surface: "#fffaf3", muted: "#795d52", dark: "#702328", soft: "#f2c59d",
                serif: "Arial Black, Inter, ui-sans-serif, sans-serif", radius: "22px", hero: "left", heroSize: "680px",
                heroOverlay: "linear-gradient(90deg,rgba(54,8,20,.92),rgba(112,35,40,.38))", headingWeight: "800"
            })
        }),
        warm: Object.freeze({
            id: "warm",
            label: "Warm human",
            suitableFor: Object.freeze(["wellness", "restaurant", "local-service"]),
            tokens: Object.freeze({
                paper: "#f8f0df", ink: "#2e2a22", surface: "#fffaf0", muted: "#776d5b", dark: "#536044", soft: "#e6dfc8",
                serif: "'Trebuchet MS', ui-sans-serif, sans-serif", radius: "10px", hero: "left", heroSize: "640px",
                heroOverlay: "linear-gradient(135deg,rgba(35,49,35,.88),rgba(83,96,68,.38))", headingWeight: "500"
            })
        })
    });

    const RECIPES = Object.freeze({
        restaurant: Object.freeze(["navigation", "reservation-hero", "trust-strip", "menu-cards", "experience", "faq", "contact-form", "footer"]),
        wellness: Object.freeze(["navigation", "consultation-hero", "trust-strip", "care-cards", "process", "faq", "contact-form", "footer"]),
        creative: Object.freeze(["navigation", "portfolio-hero", "trust-strip", "service-cards", "selected-work", "process", "contact-form", "footer"]),
        professional: Object.freeze(["navigation", "outcome-hero", "trust-strip", "advice-cards", "process", "faq", "contact-form", "footer"]),
        retail: Object.freeze(["navigation", "collection-hero", "trust-strip", "product-grid", "buying-guide", "faq", "contact-form", "footer"]),
        "local-service": Object.freeze(["navigation", "service-area-hero", "trust-strip", "service-cards", "process", "faq", "quote-form", "footer"])
    });

    const DEFAULTS = Object.freeze({
        restaurant: "bold", wellness: "warm", creative: "premium",
        professional: "premium", retail: "bold", "local-service": "modern"
    });

    function select(input = {}) {
        const business = input.business && typeof input.business === "object" ? input.business : input;
        const design = input.design && typeof input.design === "object" ? input.design : {};
        const requested = String(design.system || design.style || business.style || "").toLowerCase();
        const type = Object.hasOwn(RECIPES, business.type) ? business.type : "local-service";
        const id = Object.hasOwn(SYSTEMS, requested) ? requested : DEFAULTS[type];
        return Object.freeze({
            id,
            label: SYSTEMS[id].label,
            tokens: SYSTEMS[id].tokens,
            recipe: RECIPES[type],
            rules: Object.freeze([
                "Use semantic landmarks and exactly one h1.",
                "Use the catalog tokens for typography, spacing, color, radius, and surfaces.",
                "Keep the primary action visible and use the approved same-origin form endpoint.",
                "Collapse multi-column layouts to one column on narrow screens.",
                "Provide focus-visible and prefers-reduced-motion states."
            ])
        });
    }

    function prepareBrief(input = {}) {
        const source = input && typeof input === "object" && !Array.isArray(input) ? input : {};
        const selected = select(source);
        const business = source.business && typeof source.business === "object"
            ? { ...source.business, style: selected.id }
            : { ...source, style: selected.id };
        const preserveDesign = source.regeneration?.preserveDesign === true || source.regeneration?.mode === "copy";
        const existingGenome = source.design?.genome && typeof source.design.genome === "object" ? source.design.genome : null;
        const genome = preserveDesign && existingGenome
            ? { variationId: source.variationId, profile: source.design.profile, genome: existingGenome, fingerprint: source.design.designFingerprint, seedHash: source.design.seedHash }
            : window.workspaceDesignGenome?.createDistinct?.(source, source.recentDesigns || []) || null;
        const goal = source.design?.conversionGoal || ({ restaurant: "reservation", wellness: "booking", creative: "enquiry", professional: "consultation", retail: "purchase", "local-service": "quote" }[business.type] || "quote");
        const inspiration = window.workspaceDesignPrinciples?.select?.({ goal, categories: ["visual", "mobile"] }, 4) || [];
        return {
            ...source,
            variationId: genome?.variationId || source.variationId,
            business,
            design: {
                ...(source.design && typeof source.design === "object" ? source.design : {}),
                system: selected.id,
                catalogLabel: selected.label,
                componentRecipe: [...selected.recipe],
                foundationRules: [...selected.rules],
                ...(genome ? { profile: genome.profile, genome: { ...genome.genome }, designFingerprint: genome.fingerprint, seedHash: genome.seedHash } : {}),
                inspiration: inspiration.map((item) => ({ id: item.id, principles: [...item.principles], avoid: [...item.avoid] }))
            }
        };
    }

    function tokens(id) {
        return (SYSTEMS[id] || SYSTEMS.premium).tokens;
    }

    const api = Object.freeze({ SYSTEMS, RECIPES, select, prepareBrief, tokens });
    if (typeof window !== "undefined") window.workspaceDesignSystems = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
