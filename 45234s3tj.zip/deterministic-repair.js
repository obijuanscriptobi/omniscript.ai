"use strict";

// Mechanical project repairs only. Every mutation is recorded; subjective copy
// and visual decisions are deliberately outside this module.
((root, factory) => {
    const api = factory();
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    if (root) root.workspaceDeterministicRepair = Object.freeze(api);
})(typeof window !== "undefined" ? window : globalThis, () => {
    const record = (audit, code, file, selector, before, after) => audit.push(Object.freeze({ code, file, selector, before, after }));

    function repairHtml(source, audit) {
        let html = String(source || "");
        const ids = new Set();
        html = html.replace(/\sid=(['"])([^'"]+)\1/gi, (match, quote, id) => {
            if (!ids.has(id)) { ids.add(id); return match; }
            let suffix = 2;
            while (ids.has(`${id}-${suffix}`)) suffix += 1;
            const next = `${id}-${suffix}`;
            ids.add(next);
            record(audit, "DUPLICATE_ID_RENAMED", "index.html", `#${id}`, id, next);
            return ` id=${quote}${next}${quote}`;
        });
        html = html.replace(/<a\b([^>]*href=['"]https?:\/\/[^'"]+['"][^>]*)>/gi, (match, attrs) => {
            let next = attrs;
            if (!/\btarget=/i.test(next)) next += ' target="_blank"';
            if (!/\brel=/i.test(next)) next += ' rel="noopener noreferrer"';
            else if (!/\bnoopener\b/i.test(next)) next = next.replace(/\brel=(['"])([^'"]*)\1/i, (_, quote, value) => `rel=${quote}${value} noopener noreferrer${quote}`);
            if (next !== attrs) record(audit, "EXTERNAL_LINK_SECURED", "index.html", "a[href^=http]", attrs, next);
            return `<a${next}>`;
        });
        html = html.replace(/<img\b([^>]*)>/gi, (match, attrs) => {
            let next = attrs;
            if (!/\bwidth=/i.test(next)) next += ' width="800"';
            if (!/\bheight=/i.test(next)) next += ' height="600"';
            if (!/\bloading=/i.test(next)) next += ' loading="lazy"';
            if (!/\balt=/i.test(next)) next += ' alt=""';
            if (next !== attrs) record(audit, "IMAGE_ATTRIBUTES_ADDED", "index.html", "img", attrs, next);
            return `<img${next}>`;
        });
        html = html.replace(/<form\b([^>]*)>/gi, (match, attrs) => {
            if (!/\baction=/i.test(attrs) || /\baction=['"]\/?api\/submit-form(?:[?#'"])/i.test(attrs)) return match;
            const next = attrs.replace(/\baction=(['"])[^'"]*\1/i, 'action="/api/submit-form"');
            record(audit, "FORM_ENDPOINT_NORMALIZED", "index.html", "form", attrs, next);
            return `<form${next}>`;
        });
        return html;
    }

    function repairCss(source, audit) {
        let css = String(source || "");
        const additions = [];
        if (!/:focus-visible\b/.test(css)) additions.push(":focus-visible{outline:3px solid currentColor;outline-offset:3px}");
        if (!/@media\s*\(prefers-reduced-motion:\s*reduce\)/i.test(css)) additions.push("@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}");
        if (!/overflow-wrap\s*:\s*(?:anywhere|break-word)/i.test(css)) additions.push("body{overflow-wrap:anywhere}img,video,svg{max-width:100%;height:auto}");
        additions.forEach((addition) => record(audit, "CSS_SAFETY_RULE_ADDED", "style.css", "stylesheet", null, addition));
        if (additions.length) css += `\n${additions.join("\n")}\n`;
        return css;
    }

    function repair(files = {}) {
        const audit = [];
        const next = { ...files };
        if (Object.hasOwn(next, "index.html")) next["index.html"] = repairHtml(next["index.html"], audit);
        if (Object.hasOwn(next, "style.css")) next["style.css"] = repairCss(next["style.css"], audit);
        return Object.freeze({ files: Object.freeze(next), audit: Object.freeze(audit), changed: audit.length > 0 });
    }

    return { repair };
});
