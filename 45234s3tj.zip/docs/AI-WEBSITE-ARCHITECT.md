# AI website architect

The AI path is optional and complements the deterministic generator. It does not put provider credentials in the browser or generated websites.

## Request flow

1. The browser calls `workspaceGenerator.createAIProject()`.
2. `website-component-registry.js` normalizes the brief into evidence-backed facts with stable fact IDs.
3. `workspace-ai.js` sends the facts, approved component IDs, design constraints, and requested pages to `/api/website-architect`.
4. The server authenticates and rate-limits the request, then asks the allowlisted model for a structured component plan—not website source code.
5. The strict planner contract rejects unknown components, unsupported claims, excessive text, invalid section counts, missing shell components, and evidence-dependent sections without evidence.
6. The deterministic assembler renders accessible HTML, responsive CSS, same-origin forms, metadata, and support files from the accepted plan.
7. Static validation and bounded repair remain in place. The browser then runs accepted files through its normal safety, compiler, formatter, and audit pipeline.
8. If AI is unavailable, the same registry creates a deterministic plan and project. Pass `{ fallback: false }` when failure must be explicit.

## Provider configuration

Configure these server-side values:

- `WEBSITE_AI_URL`: full HTTPS chat-completions-compatible endpoint, including an endpoint you own
- `WEBSITE_AI_API_KEY`: credential for that inference server
- `WEBSITE_AI_MODEL`: default API model identifier
- `WEBSITE_AI_PLANNER_MODEL`: optional planning model identifier
- `WEBSITE_AI_GENERATOR_MODEL`: optional code-generation model identifier
- `WEBSITE_AI_CRITIC_MODEL`: optional visual-critique model identifier
- `WEBSITE_AI_REPAIR_MODEL`: optional targeted-repair model identifier
- `WEBSITE_AI_ALLOWED_HOSTS`: comma-separated exact host allowlist containing the endpoint host

When role-specific IDs are omitted, every stage uses `WEBSITE_AI_MODEL`. This permits one API model initially and separate provider models later.

The endpoint is intentionally provider-independent. It must accept a JSON body containing `model`, `messages`, `temperature`, and `response_format`, and return generated text in `choices[0].message.content`, `output_text`, or `content`.

## Browser API

```js
const result = await window.workspaceGenerator.createAIProject({
  business: { name: "Example", type: "professional", primaryGoal: "quote" },
  design: { direction: "editorial", density: "airy" },
  pages: ["about.html"]
});

// result.files contains validated project files.
```

A targeted repair can be requested with:

```js
const repaired = await window.workspaceGenerator.repairAIProject(
  currentFiles,
  [{ code: "MOBILE_OVERFLOW", message: "The pricing grid overflows at 360px." }],
  { business: currentBrief }
);
```

## API pipeline

Generation uses a schema-driven planner followed by deterministic assembly. `design-system-catalog.js` selects one of four curated systems, while `website-component-registry.js` owns allowed components, conversion patterns, content limits, evidence requirements, accessible rendering, and responsive behavior. The model can choose components and bounded copy, but it cannot generate arbitrary HTML, CSS, or JavaScript during initial generation.

Testimonials, prices, team members, gallery assets, and similar claims render only when normalized source facts support them. Missing evidence removes the dependent component rather than creating placeholder claims. Static failures enter the bounded repair loop. Real viewport evidence can be submitted separately through `workspaceGenerator.critiqueAIProject(files, visualEvidence, brief)` for grounded plan revision.

## Originality without unsafe freedom

Each generation may include a seeded design genome that independently selects navigation composition, hero family, section rhythm, card and image treatments, grid geometry, CTA strategy, density, motion, and decorative motif. A `variationId` makes a saved result reproducible while a new variation explores another combination. The generated document carries a design fingerprint so recent results can be compared and near-duplicates rejected.

The inspiration library contains original, abstract principles for CTA hierarchy, booking, sales, trust, forms, mobile interaction, and visual rhythm. It does not store or reproduce third-party source code, copy, screenshots, brand systems, or recognizable page layouts. Hard constraints—accessibility, security, responsive safety, factual grounding, forms, and performance—remain fixed while composition varies.

Callers can pass `projectId`, `variationId`, `recentDesigns`, and user controls such as `design.profile`, `design.density`, and `design.motion`. Reusing a variation ID reproduces its genome; omitting it creates a new variation.

## Boundaries

- This is orchestration around the configured API model, not a newly pretrained foundation model.
- Model output is untrusted until both server and browser validation pass.
- No model can guarantee conversion performance or visual correctness.
- Rendered desktop/mobile evidence should still be reviewed before publishing.
- Asset realism, such as photoreal gemstone materials, requires authorized image assets or a dedicated rendering layer; it should not be fabricated as a factual asset by the model.
