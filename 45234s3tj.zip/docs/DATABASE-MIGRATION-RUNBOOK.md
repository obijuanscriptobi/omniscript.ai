# Database migration runbook

This runbook defines the dependency order for the current Supabase SQL files. Use disposable staging databases and synthetic data. Never paste credentials, JWTs, personal data, or unrestricted database exports into release records.

> A successful source contract test does not prove that these migrations ran successfully. Retain redacted database output for the exact release commit.

## Preconditions

- [ ] Record the exact release commit and UTC start time.
- [ ] Confirm the target is disposable staging, not production.
- [ ] Confirm a restorable backup exists before a legacy upgrade.
- [ ] Record the Supabase project label without keys or secrets.
- [ ] Confirm the required Supabase extensions and Storage schema are available.
- [ ] Prepare two synthetic users and retain their identifiers only in the protected staging fixture store.
- [ ] Do not create application fixtures until all migrations and policy checks pass.

## Canonical migration order

Apply each file in this order. Stop on the first error and retain the redacted output.

| Order | Migration | Dependency/purpose | Clean | Legacy | Evidence |
|---:|---|---|---|---|---|
| 1 | `supabase/schema.sql` | Core projects, profiles, versions, leads, collaboration, approvals, portal and storage | | | |
| 2 | `supabase/business-operations.sql` | Explicit repeatable business-operation storage | | | |
| 3 | `supabase/maturity.sql` | Preview snapshots, delivery retries and translation drafts | | | |
| 4 | `supabase/multi-tenant-milestone.sql` | Organizations, tenant membership, drafts and appointments | | | |
| 5 | `supabase/work-contexts.sql` | Own/client work contexts; requires organizations | | | |
| 6 | `supabase/next-steps.sql` | Project task storage | | | |
| 7 | `supabase/leads-prospect-upgrade.sql` | Current lead-pipeline states and indexes | | | |
| 8 | `supabase/website-audits.sql` | Audits, findings and revision evidence | | | |
| 9 | `supabase/platform.sql` | Environments, deployments, assets, approvals, analytics; requires site revisions | | | |
| 10 | `supabase/project-memberships.sql` | Repeatable project membership/invitation setup | | | |
| 11 | `supabase/collaboration-security.sql` | Collaboration, private storage and approval policy baseline | | | |
| 12 | `supabase/client-portal.sql` | Revocable shares and serialized comments; requires work contexts | | | |
| 13 | `supabase/appointment-intelligence.sql` | Appointment workflow fields; requires appointments | | | |
| 14 | `supabase/usage-limits.sql` | Atomic usage counters and reservations | | | |
| 15 | `supabase/lifecycle.sql` | Revision-scoped project lifecycle | | | |
| 16 | `supabase/operations.sql` | Audit events and operational procedures | | | |
| 17 | `supabase/work-context-isolation.sql` | Final tenant policies, guards and verified-file rules; requires all referenced parent tables | | | |
| 18 | `supabase/reliability.sql` | Authenticated/public idempotency; requires contexts, approvals and portal shares | | | |
| 19 | `supabase/proposal-handoffs.sql` | Durable proposal/handoff lifecycle; must follow isolation, reliability and operations | | | |

The separate migration files intentionally repeat some guarded definitions already present in `schema.sql`. Treat the ordered set above as the release migration set and verify repeat application in disposable staging.

## Clean-install verification

- [ ] Apply the complete ordered set to an empty staging database.
- [ ] Apply the complete set a second time to test repeatability.
- [ ] Confirm no statement was skipped manually.
- [ ] Confirm expected tables, columns, indexes, constraints, functions and triggers exist.
- [ ] Confirm RLS is enabled on every tenant-sensitive table.
- [ ] Confirm the `project-files` bucket is private.
- [ ] Confirm direct proposal/handoff table writes are denied.
- [ ] Confirm proposal/handoff RPC execution is granted only to `authenticated`.
- [ ] Confirm `create_client_portal_comment` is executable only by `service_role`.
- [ ] Retain redacted output and record its immutable reference as clean-migration evidence.

## Legacy-upgrade verification

- [ ] Restore a representative, sanitized legacy backup into a second disposable database.
- [ ] Record row counts and tenant ownership checks before migration.
- [ ] Apply the same ordered migration set without deleting or manually rewriting legacy rows.
- [ ] Confirm projects retain the correct owner and organization.
- [ ] Confirm every project receives the intended work context.
- [ ] Confirm legacy unverified files are quarantined rather than marked verified.
- [ ] Confirm raw preview, approval, invitation and portal tokens are not retained.
- [ ] Compare post-migration row counts and parent/child relationships.
- [ ] Confirm old projects remain readable only by their intended users.
- [ ] Retain redacted output and record its immutable reference as legacy-migration evidence.

## RLS and isolation verification

After migrations pass, create two users, two organizations/contexts and two projects using synthetic data.

- [ ] Enable the dedicated staging RLS fixture variables in the protected test environment.
- [ ] Use only the anon key plus each test user's JWT for direct PostgREST checks.
- [ ] Do not expose the service-role key to the RLS test.
- [ ] Verify owner, member, revoked member, anonymous caller, archived context and cross-project access.
- [ ] Verify reads and writes across projects fail.
- [ ] Verify parent IDs from another project are rejected.
- [ ] Verify project/context reassignment guards reject unsafe transfer.
- [ ] Verify pending and quarantined files return no bytes.
- [ ] Verify verified files remain scoped to active project membership.
- [ ] Retain the report and record its immutable reference as staging-RLS evidence.

## Backup, rollback and restore drill

SQL migrations are forward-only unless a reviewed reverse migration exists. “Rollback” therefore means restoring the pre-migration backup into a fresh disposable target, not improvising destructive reverse SQL.

- [ ] Capture the pre-migration backup identifier and checksum/reference.
- [ ] Complete the legacy upgrade and record its end time.
- [ ] Create a fresh disposable restore target.
- [ ] Restore the pre-migration backup into that target.
- [ ] Confirm representative projects, leads, versions, memberships and files are present.
- [ ] Confirm authentication relationships and RLS still behave as they did before migration.
- [ ] Reapply the ordered migrations to the restored target.
- [ ] Confirm the application can read and write representative synthetic records.
- [ ] Record recovery time and any manual intervention.
- [ ] Retain separate immutable evidence references for backup restoration and migration rollback.

## Cleanup

- [ ] Revoke fixture JWTs, approval links, invitations and portal shares.
- [ ] Delete synthetic projects and users after all dependent runtime checks finish.
- [ ] Delete disposable restore targets according to the approved retention policy.
- [ ] Confirm evidence contains no secrets, tokens or personal data.
