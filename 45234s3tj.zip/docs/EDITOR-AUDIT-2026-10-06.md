# Website completion audit — 2026-10-06

## Verdict

**Not ready for public launch.** The repository has unusually strong source-level controls, automated tests, deployment boundaries, security checks, and release documentation. However, source inspection cannot complete the remaining provider, database, domain, legal, real-device, and live-delivery work. Public release must remain fail-closed until the exact-commit evidence gate passes.

This audit is based on workspace source inspection only. No tests, deployment, external provider calls, database migrations, DNS checks, inbox delivery, or browser runs were executed in the editor.

## What is already implemented

- Explicit public-build allowlist and post-build exposure/CSP audit.
- Real 404 behavior and fail-closed unknown API routing.
- Security headers, no-store policies for sensitive pages, and a sandboxed generated-site iframe.
- Separate source, security, adversarial, coverage, type, browser, accessibility, responsive, and staging test suites.
- Fail-closed production workflow tied to an exact commit, successful CI run, and ten immutable runtime-evidence categories.
- Ordered database migration and restoration runbook.
- Tenant isolation, idempotency, quota, file quarantine, approval, proposal, handoff, deployment, and form-delivery contracts.
- Local-first editing, scoped project/work-context state, draft recovery, revision-bound approval, and verified deployment state.
- Privacy, terms, acceptable-use, environment, operations, usage-limit, lifecycle, and generated-output documentation.
- Internal readiness center excluded from the public build.

## Fixes completed during this audit

- Added an explicit client-import authorization checkbox before import can begin.
- Clarified that import does not transfer rights to copy, images, fonts, trademarks, or code.
- Connected brief and contact hints to their controls with `aria-describedby`.
- Marked publishing contact fields as required in HTML, aligning native semantics with JavaScript validation.
- Added accessible styling for the new authorization control.

## Repository work status

The repository-only decisions identified by this audit have been completed or explicitly bounded:

- [x] Test environment gates and broad status assertions are inventoried by `test-integrity-audit.js`; the accepted scope and exact-status requirement are recorded in `REPOSITORY-RELEASE-DECISIONS.md`.
- [x] The intentionally narrow TypeScript scope is accepted for this release with an incremental expansion rule.
- [x] The official GitHub Actions mutable-major-tag risk is formally accepted and monitored by Dependabot.
- [x] Public claims avoid guaranteed outcomes; import, delivery, and technical-evidence limitations are disclosed.
- [x] Public-home indexing and private/editor noindex behavior are explicit.
- [x] `site.webmanifest` is the single manifest; the duplicate `manifest.json` was removed.
- [x] The indexable home and legal pages share favicon, theme-color, and indexing metadata, with a source contract test.
- [x] Private vulnerability reporting instructions are published in `SECURITY.md`.
- [x] Chromebook GitHub setup and exact-commit release steps are documented in `GITHUB-CHROMEBOOK-RELEASE.md`.

The following cannot be completed honestly without owner/provider input and remain release blockers rather than unfinished generic repository work:

- [ ] Replace relative production canonical/Open Graph URLs with the final absolute HTTPS origin after the purchased domain and preferred hostname are chosen.
- [ ] Insert approved public support contact, legal entity/jurisdiction, retention, processor, and consent details after qualified legal/owner review.
- [ ] Define the initial release scope and disable any provider-backed capability the owner chooses to defer.
- [ ] Add immutable runtime evidence references and reviewer identities for the exact release commit.

## Blocking work that requires external systems or people

These items cannot truthfully be completed by source editing alone:

### Infrastructure and configuration

- [ ] Create isolated staging hosting, Supabase, Redis, deployment target, domain, inbox/CRM, provider credentials, and synthetic users/projects.
- [ ] Configure all required environment variables; inspect `/api/config` and record only readiness states.
- [ ] Confirm Node 26 behavior and lockfile provenance in the actual CI/hosting runtime.
- [ ] Configure provider budgets, quota alerts, monitoring recipients, escalation, and incident ownership.

### Database and authorization

- [ ] Apply all migrations in documented order to clean and representative legacy databases.
- [ ] Verify repeat application, schema objects, grants, revocations, triggers, constraints, and RLS.
- [ ] Run the complete owner/admin/editor/reviewer/anonymous/revoked/archived/cross-project matrix.
- [ ] Exercise backup restoration and migration rollback in disposable infrastructure.

### Runtime journeys

- [ ] Complete owner and client website-maker journeys, including refresh at every step and project switching.
- [ ] Test authorized import against redirects, loops, private hosts, auth walls, oversized pages, timeouts, quotas, and provider failures.
- [ ] Test draft generation interruption, overwrite protection, editing, undo/redo, backups, cloud restore, conflicts, and stale revisions.
- [ ] Verify revision-specific review links, expiry, revocation, concurrency, replay, approval invalidation, and handoff rules.
- [ ] Verify file upload finalization, signatures, hashes, MIME detection, quarantine, cleanup, limits, and cross-project denial.

### Deployment, forms, and domain

- [ ] Publish and verify two revisions, then roll back and verify the first revision.
- [ ] Confirm HTTPS, DNS, preferred host, redirects, headers, MIME types, canonical, sitemap, robots, and favicon on the final domain.
- [ ] Submit a synthetic enquiry and confirm actual inbox/CRM receipt, not merely HTTP acceptance.
- [ ] Exercise duplicate, replay, consent, honeypot, size, origin, rate-limit, webhook/email outage, Redis outage, and database outage paths.
- [ ] Confirm export remains available during provider or deployment outages.

### Browser, accessibility, and performance

- [ ] Run the full automated matrix on the exact candidate commit.
- [ ] Manually verify Android Chrome, iOS Safari, and tablet hardware.
- [ ] Verify keyboard and screen-reader flow, 200%/400% zoom, reduced motion, forced colors/high contrast, touch targets, long localized text, RTL, slow/offline networks, and failed assets.
- [ ] Record Core Web Vitals and representative generated-site budget evidence.

### Governance

- [ ] Approve content and asset rights, privacy, terms, acceptable use, retention/deletion, consent, sharing/revocation, subprocessors, incident response, and AI disclosure.
- [ ] Assign release, security, database, operations, legal, rollback, and post-release monitoring owners.
- [ ] Record every exception with severity, owner, mitigation, and due date.

## Exact finish sequence

1. Choose the release scope: internal, controlled beta, or public launch; disable everything outside it.
2. Complete source-only items and run all repository gates.
3. Freeze the exact passing commit.
4. Create isolated staging and configure capabilities.
5. Apply and verify clean plus legacy migrations.
6. Run tenant, token, file, provider, form, lifecycle, deployment, rollback, browser, accessibility, and recovery tests.
7. Complete legal and operational approval.
8. Put immutable, redacted references into all ten evidence categories and the exact-commit evidence manifest.
9. Trigger the protected production release gate.
10. Launch only if it passes; monitor errors, delivery, quotas, and provider health, with rollback owners active.

## Source of truth

Use these existing files for execution and evidence:

- `docs/PRODUCTION-LAUNCH-CHECKLIST.md` — exhaustive release checklist.
- `readiness.html` — local internal tracking interface.
- `docs/STAGING-RELEASE-RECORD.md` — runtime evidence record.
- `docs/DATABASE-MIGRATION-RUNBOOK.md` — migration order and restore procedure.
- `docs/EXTERNAL-VERIFICATION.md` — deployed verification plan.
- `docs/OPERATIONS-RUNBOOK.md` — failure and recovery procedures.
- `.env.example` and `docs/ENVIRONMENT.md` — configuration contract.
- `.github/workflows/ci.yml` — source/browser gates.
- `.github/workflows/production-release-gate.yml` — final fail-closed authorization.

## Definition of finished

The site is finished only when the exact release commit passes CI; clean and legacy migrations are proven; cross-tenant access is denied; the complete Brief → Draft → Reviewed → Approved → Preflight passed → Published → Verified lifecycle succeeds; real form delivery, deployment, rollback, domain, browser/accessibility, backup/restore, monitoring, and incident handling are observed; legal and operational owners approve; and all ten immutable evidence references pass the protected production release gate.
