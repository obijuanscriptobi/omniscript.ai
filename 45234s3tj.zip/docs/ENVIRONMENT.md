# Environment and capability matrix

Secrets belong in the hosting provider or CI secret store, never in exported website files, source control, browser storage, or generated `netlify.toml` files.

## Variables

| Variable | Required for | Validation/handling |
|---|---|---|
| `SUPABASE_URL` | Cloud auth and project data | HTTPS Supabase origin; server and browser config |
| `SUPABASE_ANON_KEY` or `SUPABASE_PUBLISHABLE_KEY` | Browser Supabase access | Public key only; never service-role |
| `SUPABASE_SERVICE_ROLE_KEY` | Server-side privileged migrations/functions | Server-only; never returned by `/api/config` |
| `PREFLIGHT_SIGNING_SECRET` | Signed server preflight | Long random secret; required for protected preflight |
| `SCRAPINGBEE_API_KEY` | Public-site import | Optional feature; import reports unavailable when absent |
| `NETLIFY_AUTH_TOKEN` | Deployment automation | Server-only deployment credential |
| `NETLIFY_SITE_ID` | Deployment automation | Server-only site identifier |
| `PUBLIC_SITE_ORIGIN` | Production URLs and form-origin checks | HTTPS origin without credentials/query/hash |
| `LEADS_WEBHOOK_URL` | Forwarding enquiries | HTTPS and host allowlist required |
| `LEADS_WEBHOOK_HOSTS` | Webhook allowlisting | Comma-separated approved hostnames |
| `UPSTASH_REDIS_REST_URL` | Distributed rate limiting | Optional in local development; required for distributed limits |
| `UPSTASH_REDIS_REST_TOKEN` | Distributed rate limiting | Server-only |
| `RESEND_API_KEY` | Email delivery | Optional; provider failures must be visible and retryable |
| `RESEND_FROM_EMAIL` | Email sender identity | Verified provider sender |
| `PAGESPEED_API_KEY` | Mobile performance audit quota | Optional |
| `BRAVE_SEARCH_API_KEY` | Search-first discovery | Optional |
| `WEBSITE_AI_URL` | AI website generation | Server-side HTTPS chat-completions-compatible endpoint |
| `WEBSITE_AI_API_KEY` | AI website generation | Server-only provider credential; never exposed by `/api/config` |
| `WEBSITE_AI_MODEL` | AI website generation | Provider model identifier |
| `WEBSITE_AI_ALLOWED_HOSTS` | AI provider SSRF protection | Comma-separated exact provider hostnames; must include the URL host |

## Disposable staging contract

Use a separate Netlify site, Supabase project, Redis database, provider keys, webhook/email destination, deployment target, domain, and test accounts. Never reuse production credentials or customer data.

For a strict staging check, configure `CODEWISE_STAGING=true`, an HTTPS `SITE_URL`, and `CODEWISE_STAGING_STRICT=true`. The strict contract requires the server-side variables listed in the staging smoke suite and verifies that `PUBLIC_SITE_ORIGIN` matches `SITE_URL`.

Optional provider checks require `CODEWISE_STAGING_PROVIDER_CHECKS=true` and disposable fixtures. Adversarial checks require `CODEWISE_STAGING_ADVERSARIAL=true`. Keep both disabled during ordinary tests; they may consume quota, contact a webhook, or mutate staging data.

Direct RLS verification is separately opt-in with `CODEWISE_STAGING_RLS=true`. It requires two user JWTs/IDs, each user's active project/context IDs, and revoked-member plus archived-context fixture IDs using the `CODEWISE_STAGING_RLS_*` variables documented in `.env.example`. The suite calls PostgREST with the anon key and user JWTs only; do not provide a service-role key to that test. Enabling the suite with an incomplete fixture fails closed.

Record only capability states (`ready`, `missing`, or `invalid`) and redacted request IDs. Do not record tokens, authorization headers, secret values, personal data, or full provider payloads.

## Private file finalization

Private project files use a two-step contract. The initial request creates pending metadata and a short-lived signed upload URL; the client must then call the same endpoint with `action: "finalize"` and the returned metadata `id`. Finalization reads the stored bytes, enforces the declared size and signature, computes SHA-256, and marks the record verified. Pending, expired, quarantined, active HTML/script/SVG content, and MIME-mismatched objects cannot receive download URLs. Upload requests must include `assetRightsConfirmed: true` and a non-empty `assetRightsSource`.

## Readiness behavior

- Missing required configuration must disable only the dependent capability and return a clear setup status.
- Invalid secrets must never be echoed in responses or logs.
- Browser configuration may return only the validated public Supabase URL and public key.
- The service-role key, deployment credentials, webhook tokens, Redis tokens, and email keys are never browser-readable.
- Optional import, search, audit, email, and cloud features must not prevent static export.

Check `/api/config` after deployment and retain its response with the release evidence. A successful response does not prove provider authentication, database policies, DNS, or form delivery.
