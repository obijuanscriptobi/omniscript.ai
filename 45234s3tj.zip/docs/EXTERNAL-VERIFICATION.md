# External verification plan

Run this against a deployed preview/staging environment with test credentials and a disposable destination inbox/CRM. Never use production customer data for replay or failure testing.

## End-to-end scenario

1. Create from the brief and confirm the preview.
2. Import an authorized public site and inspect preserved/rebuilt/review items.
3. Edit source and visual content.
4. Confirm local autosave, backup export, restore, and cross-tab conflict behavior.
5. Save a cloud project, sign out, sign in as another role, and verify access boundaries.
6. Run quality checks and signed server preflight.
7. Deploy, poll status, verify the published URL, pages, assets, redirects, content types, and revision.
8. Submit one real test enquiry and confirm inbox/CRM delivery.
9. Deploy a second revision, roll back, and verify the previous revision is live.
10. Change the published domain in staging and confirm canonical, sitemap, and robots regeneration.

## Database/RLS matrix

Run each operation as owner, admin, editor, reviewer/client, unauthenticated user, and a user from another project. Verify read, create, update, delete, invitation, approval, lead, task, appointment, file, and membership operations. Record SQL policy evidence and API responses.

## Domain and provider matrix

Test missing credentials, invalid credentials, quota exhaustion, timeout, provider 4xx, provider 5xx, deployment propagation, DNS changes, HTTPS-only rejection, malformed webhook responses, duplicate submissions, and provider recovery.

## Browser/device matrix

Chromium, Firefox, WebKit; iOS Safari and Android Chrome; 320px, 375px, 768px, 1024px, and 1440px; keyboard-only; 200% and 400% zoom; reduced motion; forced colors; slow network; disabled JavaScript; failed image/script requests.

## Disposable staging variables

Configure these only in the staging provider and CI secret store. Record whether each is `ready`, `missing`, or `invalid`, never its value:

| Area | Variables |
|---|---|
| Supabase | `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` |
| Import/search/audit | `SCRAPINGBEE_API_KEY`, `BRAVE_SEARCH_API_KEY`, `PAGESPEED_API_KEY` |
| Rate limits | `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN` |
| Preflight/deployment | `PREFLIGHT_SIGNING_SECRET`, `NETLIFY_AUTH_TOKEN`, `NETLIFY_SITE_ID`, `PUBLIC_SITE_ORIGIN` |
| Lead delivery | `LEADS_WEBHOOK_URL`, `LEADS_WEBHOOK_HOSTS`, or `RESEND_API_KEY`, `RESEND_FROM_EMAIL` |
| Role test fixtures | `CODEWISE_STAGING_OWNER_TOKEN`, `CODEWISE_STAGING_ADMIN_TOKEN`, `CODEWISE_STAGING_EDITOR_TOKEN`, `CODEWISE_STAGING_REVIEWER_TOKEN`, `CODEWISE_STAGING_OTHER_PROJECT_TOKEN`, `CODEWISE_STAGING_PROJECT_ID`, `CODEWISE_STAGING_OTHER_PROJECT_ID` |

The staging Playwright suite is disabled unless `CODEWISE_STAGING=true` and `SITE_URL` is HTTPS. Use synthetic accounts and a disposable project; revoke all fixture tokens after testing.

A passing local test suite does not replace this record.
