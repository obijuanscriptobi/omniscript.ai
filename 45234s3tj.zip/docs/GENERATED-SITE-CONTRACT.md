# Generated-site output contract

Every path that creates or modifies a project—brief generation, template pages, import repair, manual editing, and future model output—must pass the same formatter, validator, audit, preview, preflight, and publish gates.

## Required files

- `index.html`
- `style.css`
- `script.js`
- deployment configuration with CSP, `nosniff`, and referrer policy
- `sitemap.xml` and `robots.txt` for release output
- favicon (`favicon.svg`) or an explicit documented fallback

## Required page behavior

- Complete standards HTML document with `lang`.
- Exactly one meaningful `h1`.
- Descriptive title and meta description.
- Absolute HTTPS canonical URL for production output.
- Viewport metadata.
- Open Graph and Twitter metadata.
- Same-origin form action where a form exists.
- Labels or accessible names for every form control.
- Meaningful image alt text and intrinsic image dimensions.
- Visible keyboard focus treatment and reduced-motion behavior.
- Mobile navigation and layout that work from 320px through desktop widths.
- Form success, failure, consent, spam, and retry states.
- No placeholder copy, secrets, fabricated credentials, unsupported claims, unsafe URLs, inline event handlers, or dynamic-code APIs.

## Budgets

- Total generated source: 5 MB maximum.
- HTML: 150 KB maximum per generated page set.
- CSS: 100 KB maximum.
- JavaScript: 150 KB maximum.
- No unapproved third-party scripts.
- No blocking horizontal overflow at supported viewports.

These are technical safeguards, not a conversion guarantee, SEO ranking, legal review, or full device certification.
