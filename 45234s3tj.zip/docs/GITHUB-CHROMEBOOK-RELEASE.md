# GitHub release setup from a Chromebook

Use GitHub in Chrome. Never paste credentials, provider tokens, customer data, or service-role keys into issues, commits, Actions logs, or this repository.

## 1. Create and secure the repository

1. Create a private repository, or open the existing private repository.
2. Upload/push the complete workspace, including dot-directories such as `.github` and the dependency lockfile.
3. Open **Settings → General** and confirm the intended default branch.
4. Open **Settings → Security → Code security and analysis**. Enable Dependabot alerts, Dependabot security updates, secret scanning, push protection where available, and private vulnerability reporting.
5. Open **Settings → Actions → General**. Allow the actions used by the workflows and keep the default workflow token read-only unless a job explicitly requires more.

## 2. Confirm the dependency lock

The release requires a committed npm lockfile generated with Node 26. If `package-lock.json` is absent, use a browser-hosted development environment with Node 26 to generate it, review the diff, and commit it. Do not hand-author dependency versions or disable the lock audit. CI checks lockfile version, package metadata, registry origin, and integrity hashes.

## 3. Protect the default branch

1. Open **Settings → Branches** or **Settings → Rules → Rulesets**.
2. Create a rule targeting the default branch.
3. Require a pull request before merging.
4. Require at least one approval when another trusted reviewer is available.
5. Dismiss stale approvals after new commits.
6. Require conversation resolution.
7. Require status checks and select both checks produced by `Quality gates`:
   - `Source and contract gates`
   - `Browser and accessibility gates`
8. Require branches to be up to date before merging.
9. Block force pushes and branch deletion.
10. Apply the rule to administrators where practical.

The checks may need to run once before GitHub offers them in the required-check selector.

## 4. Review the first CI run

1. Open **Actions → Quality gates**.
2. Select the run for the exact default-branch commit.
3. Confirm both jobs pass; do not rely only on the green repository badge.
4. Open each job and inspect warnings, test counts, coverage, and duration.
5. Download and retain the `source-audit-reports` and `playwright-report` artifacts.
6. If a job fails, fix the source in a new commit. Do not weaken, skip, or remove the failing gate merely to obtain green status.

## 5. Create the protected production environment

1. Open **Settings → Environments → New environment** and name it `production` exactly.
2. Add required reviewers when the plan supports them.
3. Restrict deployment branches/tags to the protected release path.
4. Add the release evidence as **environment variables**, not secrets, because the gate references the `vars` context:
   - `CODEWISE_RELEASE_RUNTIME_VERIFIED`
   - `CODEWISE_RELEASE_EVIDENCE_MANIFEST`
   - all ten `CODEWISE_EVIDENCE_*` variables listed in `docs/STAGING-RELEASE-RECORD.md`.
5. Use only immutable, redacted artifact references matching the manifest. Do not store credentials in evidence variables.

Provider credentials belong in the hosting provider's secret store. They are not required by the GitHub source CI shown here.

## 6. Prepare exact-commit evidence

1. Open the successful default-branch `Quality gates` run.
2. Copy its commit SHA and Actions run ID.
3. Confirm every external result was observed against that same commit.
4. Complete the ten evidence references in `docs/STAGING-RELEASE-RECORD.md`.
5. Build the evidence manifest using the documented schema. Each entry needs a passing result, reviewer, observed time, immutable reference, SHA-256 checksum, and deployment ID; migration categories also need a migration ID.
6. Set `releaseCommit` to the full 40-character SHA and `ciRunId` to the successful push-run ID.
7. Store the compact valid JSON as `CODEWISE_RELEASE_EVIDENCE_MANIFEST` in the `production` environment.
8. Set each `CODEWISE_EVIDENCE_*` variable to exactly the same reference used by its manifest entry.
9. Set `CODEWISE_RELEASE_RUNTIME_VERIFIED` to `true` only after all evidence has been reviewed.

## 7. Run the release gate

1. Open **Actions → Production release gate**.
2. Choose **Run workflow**.
3. Enter the exact full commit SHA that passed the default-branch push workflow.
4. Start the workflow and approve the `production` environment review if prompted.
5. Confirm `Verify source and runtime evidence` passes.
6. Download and retain the `production-release-gate-<commit>` artifact.

A failure is a release stop. Correct the evidence or source, obtain a new passing CI run where needed, and run the gate again.

## 8. Connect hosting and the purchased domain

After repository CI is green, connect the repository in the hosting dashboard. Keep staging and production separate. Configure server secrets there, set `PUBLIC_SITE_ORIGIN` to the final preferred HTTPS origin, connect the purchased domain, and verify DNS, HTTPS, redirects, canonical/social URLs, forms, and rollback before making the site public.

## 9. Release record

Record the exact commit, CI run, release-gate artifact, deployment ID, domain, UTC time, reviewer, and redacted evidence references in `docs/STAGING-RELEASE-RECORD.md`. Do not mark a runtime item complete based only on source inspection.
