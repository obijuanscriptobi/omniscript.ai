# Website import policy

Only import a public website you are authorized to review or improve. Importing a site does not transfer ownership of its copy, images, video, fonts, trademarks, code, customer data, or third-party embeds.

## Supported input

- Public HTTP(S) homepage or landing page.
- Public, reachable pages and assets exposed by the provider.
- Content that can be safely converted into editable HTML, CSS, and JavaScript.

## Expected limitations

- Private, authenticated, paywalled, blocked, or robots-restricted content may not be imported.
- Client-rendered or JavaScript-heavy pages may be partially captured.
- Forms, booking systems, analytics, databases, memberships, checkout, video, maps, fonts, and third-party embeds may require manual reconnection.
- Redirects, quota exhaustion, timeouts, oversized pages, inaccessible assets, and provider errors must be shown as review items.
- Imported media and brand assets require permission and public licensing appropriate for the new site.

The import report must distinguish **preserved**, **rebuilt**, and **review required** items. A successful import means an editable preparation was created; it does not prove visual fidelity, legal permission, or production readiness.
