# Operations and recovery runbook

## Request tracing

Use the request ID returned in API responses and the `X-Request-ID` header when investigating import, form, preflight, deployment, or verification failures. Never request or store customer secrets in support tickets.

## Import failure

1. Capture the request ID and displayed provider reason.
2. Confirm the URL is public, authorized, HTTPS, and not private/authenticated.
3. Check provider quota, timeout, response size, and blocked-host logs.
4. Retry once after correcting the input; do not silently replace the current project.
5. Export the existing project before attempting repair again.

## Deployment failure or timeout

1. Run local quality checks and server preflight.
2. Confirm deployment credentials, site ID, origin, and ZIP size.
3. Check provider status and deployment history using the request/deployment ID.
4. Do not claim publication until provider status and published-site verification pass.
5. Use rollback only after confirming the target deployment and approval state.

## Form delivery failure

1. Separate HTTP acceptance from inbox/CRM receipt.
2. Check endpoint origin, consent, honeypot, rate limits, webhook host allowlist, provider status, and idempotency key.
3. Use a new controlled test enquiry; never replay customer data unnecessarily.
4. Confirm delivery in the destination inbox/CRM.
5. Record the failure and recovery result with request ID.

## Deleted or overwritten work

Use, in order: undo/redo, browser checkpoint, local browser backup, project JSON backup, cloud version history, then deployment rollback. Before destructive recovery, export the current project.

## Client review access

Confirm the client invitation, project membership, role, expiry, and approval state. Revoke old invitations and never grant cross-project access to resolve a missing-permission issue.
