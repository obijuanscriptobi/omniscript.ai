# Privacy and release checklist

Before public release, obtain product/legal approval for the following:

- [ ] Terms of service
- [ ] Privacy policy
- [ ] Acceptable-use policy
- [ ] Website content, image, font, trademark, and import authorization
- [ ] Lead retention and deletion period
- [ ] Analytics consent and opt-out behavior
- [ ] Form consent and privacy-policy link
- [ ] Client/project sharing and revocation
- [ ] Account deletion and project deletion
- [ ] Backups, exports, and recovery retention
- [ ] Email, hosting, database, scraping, analytics, and other subprocessors
- [ ] Data breach and provider outage response
- [ ] AI-generated content disclosure and claim verification when AI is introduced

The generated privacy page is a draft disclosure aid. It is not legal advice and must be reviewed against the actual endpoint, processors, retention, cookies, analytics, and jurisdiction before publishing.
