# Production launch checklist

> Status: **not ready for controlled beta or public launch** until every applicable blocking item has observed evidence for the exact release commit. Source implementation is not proof of external runtime behavior.

Use `[x]` only after attaching redacted evidence. Record exceptions with an owner, severity, mitigation, and due date.

## 1. Release definition

- [ ] Select internal testing, controlled beta, or public launch.
- [ ] Record and freeze the exact release commit.
- [ ] Assign release, security, database, operations, and legal owners.
- [ ] Mark website creation, authorized import, AI planning, local/cloud storage, review, approval, publishing, export, lead delivery, audits, appointments, proposals, and handoffs as required or deferred.
- [ ] Disable incomplete optional capabilities.
- [ ] Record every exception with an owner, severity, mitigation, and due date.

## 2. Repository and runtime consistency

- [x] Package metadata targets Node 26.
- [x] CI targets Node 26.
- [x] hosting targets Node 26.
- [ ] Confirm every server function works under Node 26.
- [ ] Confirm the lockfile was generated and validated under Node 26.
- [ ] Record the observed runtime version in release evidence.
- [x] Confirm referenced scripts, styles, API functions, manifest assets, and icons through the fail-closed public build/audit contract; CI execution remains required.
- [x] Configure and contract-test unknown `/api/*` routes to return errors rather than the app shell; deployed verification remains required.
- [x] Configure and contract-test unknown pages to use `404.html`; deployed verification remains required.
- [x] Decide editor and production indexing behavior; public home/legal pages are indexable and private/editor workflows are noindex.
- [x] Review HTML and sensitive-page cache policies; sensitive routes are no-store and tested.
- [x] Review CSP sources, iframe sandboxing, inline-script restrictions, and provider connections at source level; deployed-header verification remains required.
- [x] Run type checking as a required CI step.
- [x] Add the fail-closed release gate to the production release workflow.
- [x] Configure CI browser provisioning and a 30-minute browser-job timeout for the complete matrix; confirm the observed duration after the first run.
- [x] Remove duplicate browser-suite execution by running the configured Playwright matrix once.

## 3. Isolated staging

- [ ] Create separate staging hosting, Supabase, Redis, deployment, domain, inbox/CRM, and provider credentials.
- [ ] Create synthetic users and two isolated synthetic projects.
- [ ] Confirm no production secrets or customer data are reused.
- [ ] Confirm HTTPS and make `PUBLIC_SITE_ORIGIN` match the staging origin.
- [ ] Enable strict staging checks only in the intended environment.
- [ ] Keep provider-consuming and adversarial checks disabled outside the test window.
- [ ] Record staging URL, published URL, hosting ID, commit, service labels, tester, and UTC time in `STAGING-RELEASE-RECORD.md`.

## 4. Environment capabilities

- [ ] Configure Supabase URL, public key, and server-only service-role key.
- [ ] Confirm the service-role key never reaches the browser.
- [ ] Configure preflight signing, deployment token/site ID, and public origin.
- [ ] Confirm deployment credentials remain server-only and invalid preflight signatures fail.
- [ ] Configure Redis and verify distributed rate limiting and outage behavior.
- [ ] Configure authorized import, search, and audit providers where offered.
- [ ] Verify unavailable optional providers disable only their capability and do not block export.
- [ ] Configure an allowlisted webhook or verified email delivery provider.
- [ ] Verify delivery failures are visible and retryable; HTTP acceptance alone is not inbox delivery.
- [ ] If AI is enabled, configure its HTTPS endpoint, server-only credential, models, and host allowlist.
- [ ] Verify AI fallback, component validation, claim validation, and standard release validation.
- [ ] Inspect `/api/config`; record every capability as ready, missing, or invalid.
- [ ] Confirm `/api/config` discloses no secrets or secret-like identifiers.

## 5. Database and migrations

Use the dependency order and clean/legacy/restore procedure in [`DATABASE-MIGRATION-RUNBOOK.md`](./DATABASE-MIGRATION-RUNBOOK.md).

- [ ] Back up staging and document the exact SQL migration order.
- [ ] Apply all migrations to a clean database and retain output.
- [ ] Verify tables, columns, types, indexes, foreign keys, uniqueness, checks, triggers, procedures, grants, and revocations.
- [ ] Verify RLS on every tenant-sensitive table.
- [ ] Verify service-only procedures cannot be called by ordinary users.
- [ ] Verify proposal/handoff procedure roles and denial of direct table writes.
- [ ] Verify portal-comment execution permissions.
- [ ] Test a representative legacy upgrade without loss or tenant reassignment.
- [ ] Exercise rollback and restore into a disposable database.
- [ ] Retain clean-install, legacy-upgrade, rollback, and restore evidence.

## 6. Identity, tenancy, and authorization

Test owner, admin, editor, reviewer/client, anonymous, cross-project, revoked, and archived-context identities against:

- [ ] Project read/create/update/delete.
- [ ] Versions, files, finalization, download, and export.
- [ ] Leads, tasks, appointments, invitations, and memberships.
- [ ] Approval, portal, proposals, handoffs, analytics, deletion, and recovery.
- [ ] Confirm cross-project reads/writes and foreign project IDs fail.
- [ ] Confirm context reassignment cannot bypass isolation.
- [ ] Confirm revoked and archived access is enforced immediately.
- [ ] Confirm anonymous callers cannot read private records or files.
- [ ] Confirm public tokens never appear in storage, logs, analytics, or screenshots.
- [ ] Complete direct two-user PostgREST RLS verification.
- [ ] Revoke all fixture tokens after testing.

## 7. Website-maker journey

- [ ] Verify workspace mode and project type behavior.
- [ ] Complete name, offer, audience, location, action, and factual proof sequentially.
- [ ] Verify Back, Continue, missing-field hints, and 0/6 through 6/6 progress.
- [ ] Test blank, whitespace, maximum-length, pasted, non-Latin, and special-character values.
- [ ] Refresh at every step and verify restoration in the correct project/context.
- [ ] Switch projects and confirm no data leakage.
- [ ] Create a draft and verify interrupted generation recovery.
- [ ] Prevent silent overwrite; require a backup/replace decision.
- [ ] Verify empty and generated preview states plus desktop/tablet/mobile modes.
- [ ] Verify preview messages only come from the expected iframe.
- [ ] Verify preview forms cannot navigate the parent and use the strict enquiry protocol.

## 8. Contact, profile, and advanced settings

- [ ] Test phone display/dial forms and extensions, email, availability, and draft updates.
- [ ] Confirm empty optional fields do not create broken links.
- [ ] Verify advanced tools lazy-load once and recover clearly from load failures.
- [ ] Test address, booking, pricing, credentials, testimonials, colors, logo, approved claims, CTA, privacy/analytics, and form endpoint.
- [ ] Confirm stale autosave cannot write to a different project.
- [ ] Confirm page-exit flush, revision conflict handling, and safe switching during staged loading.

## 9. Authorized import

- [ ] Show authorization requirements before import.
- [ ] Allow only valid public HTTP(S) targets; reject internal/private hosts.
- [ ] Test redirects, loops, authentication, paywalls, blocks, JS-heavy pages, oversized responses, timeouts, quotas, and provider errors.
- [ ] Confirm failure never replaces the current project and require a backup before destructive replacement.
- [ ] Distinguish preserved, rebuilt, and review-required output.
- [ ] Review rights for copy, images, fonts, trademarks, code, video, and embeds.
- [ ] Reconnect forms, analytics, maps, booking, membership, checkout, and integrations.
- [ ] Never describe technical import success as legal permission or launch readiness.

## 10. Generated-site contract

- [ ] Require `index.html`, CSS, JavaScript, deployment/security config, sitemap, robots, and favicon/fallback.
- [ ] Require standards HTML, language, one meaningful H1, title, description, viewport, absolute production canonical, Open Graph, and Twitter metadata.
- [ ] Reject placeholders, fabricated claims/prices/testimonials/credentials, secrets, unsafe URLs, inline handlers, and dynamic-code APIs.
- [ ] Map claims to supplied evidence and omit unsupported content.
- [ ] Require same-origin form actions, labels, consent where needed, privacy link, success/failure/retry states, honeypot, idempotency, and retry-safe data.
- [ ] Require appropriate alt text, dimensions, working assets, no overflow, 320px navigation, desktop responsiveness, and touch targets.
- [ ] Enforce 5 MB total, 150 KB HTML, 100 KB CSS, and 150 KB JavaScript budgets.
- [ ] Reject unapproved third-party scripts and verify representative performance budgets.

## 11. Editing, persistence, and recovery

- [ ] Test visual/source editing and preview synchronization.
- [ ] Prevent invalid source from publishing.
- [ ] Test undo/redo, autosave, refresh restore, JSON backup/import, cloud save, sign-out/in, and cloud restore.
- [ ] Test simultaneous tabs, stale revisions, and visible conflict handling.
- [ ] Ensure edits invalidate approval and stale deployment evidence.
- [ ] Exercise recovery in order: undo, browser checkpoint, local backup, JSON backup, cloud version, deployment rollback.
- [ ] Export before destructive recovery and prove backup restoration.

## 12. Lifecycle and client review

Enforce **Brief → Draft → Reviewed → Approved → Preflight passed → Published → Verified** across UI, local/cloud state, APIs, collaboration, and deployment history.

- [ ] Verify draft behavior and revision-specific review links.
- [ ] Require random, expiring tokens and remove tokens from the address bar after capture.
- [ ] Retain decision notes and support approve/request-changes decisions.
- [ ] Invalidate approval after edits or project-type changes.
- [ ] Reject stale, duplicate, concurrent, expired, and revoked decisions safely.
- [ ] Document owner-project approval rules.
- [ ] Prevent UI and API publishing from bypassing preflight.
- [ ] Require current revision evidence for Published and observed live evidence for Verified.
- [ ] Ensure rollback does not approve newer source changes.

## 13. File and asset security

- [ ] Require and record rights confirmation.
- [ ] Create pending metadata and short-lived signed upload URLs.
- [ ] On finalization, verify stored bytes, declared/actual size, signature, SHA-256, and detected MIME.
- [ ] Quarantine MIME mismatches, truncation, and forged files.
- [ ] Deny pending, expired, quarantined, active HTML/script/SVG, anonymous, and cross-project downloads.
- [ ] Test missing-object recovery and pending-object cleanup.
- [ ] Enforce file-count limits server-side.

## 14. Limits and cost controls

Verify server-side limits and failure responses for:

- [ ] 25 projects/account and 50 versions/project.
- [ ] 100 imports/account/month and 2 MB import/preflight bodies.
- [ ] 4.5 MB local/cloud project storage.
- [ ] 100 deployments/account/month.
- [ ] 1,000 submissions/project/month.
- [ ] 100 preview emails/account/month.
- [ ] 10 members/project.
- [ ] 100 audit/benchmark runs/account/month.
- [ ] Provider/API monthly budget and alerts.
- [ ] Exhaustion responses include request IDs and safe retry guidance.
- [ ] No quota relies only on browser enforcement.

## 15. Automated gates

- [ ] Lint/syntax, type checking, and the full Node suite pass.
- [ ] Coverage passes 70% lines/functions/statements and 60% branches.
- [ ] Security, production safety, deployment, quota, adversarial, archive, and deployment-gate tests pass.
- [ ] Generated-site, accessibility, vitals, RTL, workflow, architecture, journey, and website-maker accessibility tests pass.
- [ ] Direct staging RLS, staging fixture, and enabled provider checks pass.
- [ ] No unexplained focused or skipped blocking test remains.
- [ ] CI passes on the exact commit and reports/traces are retained.

## 16. Browser and accessibility matrix

- [ ] Test widths 320, 375, 768, 1024, and 1440.
- [ ] Test Chromium, Firefox, WebKit, Android Chrome, iOS Safari, and tablet/iPad.
- [ ] Test keyboard order, focus, skip link, accessible names, landmarks, headings, live status, and error association.
- [ ] Test 200%/400% zoom, reduced motion, forced colors, high contrast, and touch targets.
- [ ] Test slow/offline networks, failed assets/scripts, JavaScript disabled, long/localized content, and RTL.
- [ ] Confirm no blocking overflow, keyboard traps, or inaccessible staged controls/modals.

## 17. Deployment and publishing

- [ ] Run static quality checks and obtain signed preflight for the current approved revision.
- [ ] Publish revision 1, poll to completion, and verify the HTTPS URL.
- [ ] Verify pages, assets, redirects, content types, headers, revision, canonicals, sitemap, robots, and favicon.
- [ ] Verify no secret or editor-only data is in the archive.
- [ ] Publish and verify revision 2, then roll back and verify revision 1.
- [ ] Record deployment/request IDs, timestamps, and URLs.
- [ ] Confirm export remains available during deployment outages.

## 18. Domain and SEO

- [ ] Verify domain ownership, DNS, propagation, HTTPS, HTTP redirect, preferred host, and certificate health.
- [ ] Regenerate and verify canonicals, sitemap, and robots for the final domain.
- [ ] Test domain changes, DNS failure, and propagation delay in staging.
- [ ] Document DNS and application rollback.
- [ ] Keep staging unindexed and verify the intended production indexing policy.

## 19. Forms and delivery

- [ ] Submit a synthetic enquiry from the published site and confirm endpoint plus inbox/CRM receipt.
- [ ] Confirm correct project routing, consent metadata, request ID, delivery state, and safe provider responses.
- [ ] Test duplicate/idempotent submission, replay with changed payload, invalid IDs, body size, JSON/content type, origin, honeypot, and consent.
- [ ] Test rate limits, webhook timeout/4xx/5xx/malformed response, email outage, Redis outage, and Supabase outage.
- [ ] Verify retry persistence, exactly-once effective delivery, and minimum necessary customer-data replay.

## 20. CRM, audits, appointments, proposals, and handoffs

- [ ] Verify public audit submission creates one lead, audit, and follow-up task; repeat submission updates rather than duplicates.
- [ ] Test appointment creation, linkage, provider metadata, ownership, refresh, reschedule, cancellation, and completion rules.
- [ ] Simulate cloud failure; retain local/pending state and retry without duplicates or cross-tenant access.
- [ ] Test proposal services, pricing, dates, notes, objections, status, and history.
- [ ] Require an approved current revision for proposals.
- [ ] Reject stale/wrong-recipient handoffs and make duplicate requests idempotent.
- [ ] Keep proposal delivery disabled until its full security gate passes.

## 21. Monitoring and operations

- [ ] Capture request/provider correlation IDs without secrets or unnecessary personal data.
- [ ] Monitor browser errors, promise rejections, server failures, long tasks, deployment/form failures, quotas, Redis, database, and scheduled retries.
- [ ] Configure recipients, severity, ownership, escalation, provider-outage, and breach-response procedures.
- [ ] Exercise import, deployment, form-delivery, deleted-work, and client-access runbooks.
- [ ] Confirm support can diagnose by request ID without asking for secrets.

## 22. Privacy, policy, and legal

Obtain approval for:

- [ ] Terms, privacy, acceptable use, import authorization, content/image/font/trademark rights.
- [ ] Lead/project/account deletion and lead/backup/export/recovery retention.
- [ ] Analytics consent/opt-out, form consent, and privacy-link placement.
- [ ] Client sharing, expiry, and revocation.
- [ ] Hosting, database, email, import, analytics, and AI subprocessors.
- [ ] Breach and provider-outage response.
- [ ] AI disclosure and human verification of generated claims.
- [ ] Review generated privacy copy against actual processors, cookies, retention, forms, analytics, jurisdiction, and deployment.

## 23. Evidence and fail-closed release gate

Attach redacted, immutable evidence tied to the exact release for:

- [ ] Clean migration.
- [ ] Legacy migration.
- [ ] Staging RLS.
- [ ] Public-token race/replay behavior.
- [ ] File lifecycle.
- [ ] Provider/form delivery.
- [ ] Browser/accessibility matrix.
- [ ] Backup restoration.
- [ ] Migration rollback.
- [ ] Monitoring and incident response.

For every gate record environment, tester, UTC time, commit, evidence reference, result, request/deployment ID, and any owned exception. The production job must require all evidence variables, runtime attestation, and the source release gate; missing evidence must fail closed.

## 24. Final decision

- [ ] All blocking source, browser, staging, and provider checks pass.
- [ ] Real form delivery, clean/legacy migration, RLS, restore, rollback, domain, and HTTPS are proven.
- [ ] Monitoring, budgets, and alerts are active.
- [ ] Legal, operations, security, and runtime evidence approvals are attached.
- [ ] Exceptions are accepted in writing.
- [ ] Controlled beta and public launch receive separate approval.
- [ ] Staging tokens are revoked and synthetic data is deleted.
- [ ] Post-release monitoring and rollback owners are assigned.

## Definition of done

The release is done only when configuration is consistent; CI passes on the exact commit; clean and legacy migrations succeed; multi-identity tenant isolation is proven; the full Brief-to-Verified lifecycle succeeds; a synthetic enquiry reaches its destination; deployment and rollback are proven; the browser/accessibility matrix is recorded; legal and operational controls are approved; and all ten runtime evidence references pass the fail-closed release gate.
