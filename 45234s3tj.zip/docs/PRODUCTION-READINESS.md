# Production readiness plan

The detailed, evidence-driven execution checklist is maintained in [`PRODUCTION-LAUNCH-CHECKLIST.md`](./PRODUCTION-LAUNCH-CHECKLIST.md).

This project is suitable for a controlled beta only after the infrastructure checks below are completed in a real deployment. Source-level tests are evidence of implementation, not proof that external providers, DNS, inboxes, or devices work.

## Completion gates

- [ ] Node 26 is used by package metadata, CI, hosting, and local tooling.
- [ ] `/api/config` reports the expected environment configuration and optional capabilities.
- [ ] A clean Supabase project has all migrations applied successfully in the order defined by [`DATABASE-MIGRATION-RUNBOOK.md`](./DATABASE-MIGRATION-RUNBOOK.md).
- [ ] Tenant isolation is tested with owner, admin, editor, reviewer/client, unauthenticated, and cross-project users.
- [ ] Brief creation, import, edit, local save, cloud save, restore, export, preflight, deploy, verify, form delivery, and rollback pass in a deployed environment.
- [ ] A real enquiry is confirmed in the configured inbox or CRM; HTTP acceptance alone is insufficient.
- [ ] Custom-domain DNS, HTTPS, canonical URLs, sitemap, robots, propagation, and rollback behavior are documented and tested.
- [ ] Generated output satisfies `GENERATED-SITE-CONTRACT.md` for compile, import, templates, manual edits, and future model output.
- [ ] Import limitations and authorization requirements are shown before importing.
- [ ] Monitoring, request IDs, audit history, provider quotas, and recovery procedures are available to support staff.
- [ ] Privacy, terms, acceptable use, deletion, retention, and content ownership policies are approved and published.
- [ ] Generated forms pass abuse, replay, duplicate, size, content-type, consent, provider outage, and retry tests.
- [ ] Browser/device QA covers Chromium, Firefox, WebKit, mobile widths, keyboard access, reduced motion, forced colors, high contrast, touch targets, zoom, slow network, and failed assets.
- [ ] Runtime diagnostics are reviewed for uncaught errors, unhandled rejections, long tasks, offline recovery, and provider correlation IDs without collecting unnecessary visitor data.
- [ ] Usage limits and provider-cost controls are enforced server-side before public launch.
- [ ] Project lifecycle is enforced as Brief → Draft → Reviewed → Approved → Preflight passed → Published → Verified.
- [ ] Representative generated sites meet the performance budgets in the site contract.

## Automated readiness status

The repository contains automated unit, contract, authorization, migration, security, generated-site, accessibility, responsive, and staging-workflow checks. Source-level checks do not prove live provider behavior.

- [ ] Full Node test suite completed in CI or the project runtime.
- [ ] Full Playwright browser matrix completed with the required preview server.
- [ ] Live staging/provider checks completed with redacted evidence.
- [ ] `CODEWISE_STAGING_RLS=true` direct two-user RLS verification passes against disposable staging fixtures.
- [ ] Clean-install and legacy-data upgrade migrations both complete successfully.
- [ ] Public approval decision and invitation acceptance race/replay probes pass.
- [ ] Portal cookie refresh/revocation and concurrent 100-comment-cap probes pass.
- [ ] Proposal and handoff RPCs reject stale revisions, foreign parents, wrong recipients, and duplicate requests.
- [ ] Pending and quarantined storage objects return no bytes to authenticated and anonymous callers.
- [ ] Backup restore and migration rollback have been exercised, not merely documented.
- [ ] External verification record updated from observed results; do not mark these items from source inspection alone.

The production release job should set `CODEWISE_ENFORCE_RUNTIME_RELEASE=true`. Set `CODEWISE_RELEASE_RUNTIME_VERIFIED=true` only after evidence is attached to that exact release. The release gate also requires non-empty, non-secret evidence references in `CODEWISE_EVIDENCE_CLEAN_MIGRATION`, `CODEWISE_EVIDENCE_LEGACY_MIGRATION`, `CODEWISE_EVIDENCE_STAGING_RLS`, `CODEWISE_EVIDENCE_PUBLIC_TOKEN_RACES`, `CODEWISE_EVIDENCE_FILE_LIFECYCLE`, `CODEWISE_EVIDENCE_PROVIDER_DELIVERY`, `CODEWISE_EVIDENCE_BROWSER_A11Y`, `CODEWISE_EVIDENCE_BACKUP_RESTORE`, `CODEWISE_EVIDENCE_MIGRATION_ROLLBACK`, and `CODEWISE_EVIDENCE_OPERATIONS`. A boolean attestation without those references fails closed.

## External verification record

Record the date, deployment URL, commit, environment, tester, and evidence link for every gate. Do not mark a gate complete from a local preview alone.

| Gate | Environment | Tester | Date | Evidence | Result |
|---|---|---|---|---|---|
| End-to-end deployment | | | | | |
| Form delivery | | | | | |
| Database/RLS isolation | | | | | |
| Custom domain | | | | | |
| Browser/device QA | | | | | |
