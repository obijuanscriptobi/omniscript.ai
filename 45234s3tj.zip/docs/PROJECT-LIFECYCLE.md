# Project lifecycle

The intended release state machine is:

```text
Brief → Draft → Reviewed → Approved → Preflight passed → Published → Verified
```

## Rules

- Editing a Draft keeps it a Draft.
- Editing an Approved project returns it to Draft and invalidates approval.
- Publishing requires the current revision to pass preflight.
- A failed preflight cannot be published through the UI or API.
- Importing into a non-empty project requires an explicit backup/replace decision.
- Client approval is scoped to the project revision that was reviewed.
- Rollback restores a known deployment revision; it does not silently approve newer source changes.
- Verification is evidence about the published URL, not proof of conversion performance or inbox delivery.
- Unauthenticated users cannot read private project files, approvals, leads, or memberships.

Implement and test these transitions consistently across local state, cloud state, collaboration, deployment history, and client review links.
