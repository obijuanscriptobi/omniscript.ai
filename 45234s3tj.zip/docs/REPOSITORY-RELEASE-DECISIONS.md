# Repository release decisions

These decisions close source-review questions that do not require a live provider or final domain. Runtime evidence remains mandatory and must not be inferred from this document.

## Type checking

The narrow JavaScript type-checking scope is intentional for this release. `tsconfig.json` lists only files carrying `// @ts-check` and complete JSDoc types so CI remains signal-bearing rather than suppressing large numbers of legacy errors. New or materially rewritten critical modules should add types and enter the explicit list. Broader conversion is maintenance work, not a reason to weaken the current gate.

## GitHub Actions dependencies

The workflows currently use official GitHub-maintained actions by major version (`actions/checkout`, `actions/setup-node`, `actions/upload-artifact`, and `actions/github-script`). This repository accepts the residual mutable-major-tag risk because Dependabot monitors the `github-actions` ecosystem weekly and workflow changes remain reviewable. A future organization policy may require full commit-SHA pinning; do not invent or manually copy SHAs without verifying them against the action publisher.

## Test integrity

Environment-gated tests are intentional only for disposable staging, provider-consuming, adversarial, and direct-RLS checks. They fail closed when explicitly enabled with incomplete fixtures. Ordinary source CI must continue to reject focused tests. Broad HTTP assertions are inventory findings requiring review; security-sensitive contracts must assert exact statuses and response semantics.

## Web manifest

`site.webmanifest` is the single web-app manifest. The duplicate `manifest.json` was removed to avoid divergent branding and icon metadata.

## Indexing and metadata

The public home and legal-policy pages are indexable. Editor, account, review-token, proposal, invitation, preview, and portal surfaces remain excluded through page metadata, `robots.txt`, and hosting headers. The final absolute canonical and social URLs are intentionally supplied only after the purchased domain is connected; relative values must not be treated as final production SEO evidence.

## Security contact

`SECURITY.md` directs reporters to GitHub private vulnerability reporting without publishing an email address. Private vulnerability reporting must be enabled in repository settings before release.

## Deferred owner inputs

The repository cannot truthfully invent these values:

- final production HTTPS origin and preferred hostname;
- public support contact and legal entity/jurisdiction details;
- final release scope for any optional provider-backed capability;
- immutable runtime evidence references and reviewer identities.

Record these in the release evidence and provider settings rather than hard-coding secrets or placeholders into public files.
