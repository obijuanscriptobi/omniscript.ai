# Real staging fixture adapter

`staging-real-adapter.js` is an opt-in bridge for running the complete fixture against deployed staging services. It does not provide fake responses and it refuses to start when required credentials are missing.

## Required configuration

```text
STAGING_API_BASE=https://staging.example
STAGING_ACCESS_TOKEN=<authenticated staging token>
STAGING_PROJECT_ID=<UUID>
STAGING_EXPERIMENT_ID=<UUID>
STAGING_BASELINE_URL=https://original.example
STAGING_PROPOSED_URL=https://proposed.example
STAGING_AUDIT_EMAIL=staging@example.com
STAGING_EDITOR_API=https://staging.example/editor
STAGING_PREVIEW_API=https://staging.example/preview
STAGING_DEPLOY_API=https://staging.example/deploy
SUPABASE_URL=https://project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=<server-only key>
STAGING_ARTIFACT_BUCKET=staging-visual-audits
```

The service-role key must only be supplied to the staging process, never to browser code or a deployed client bundle. Screenshot artifacts are uploaded to the configured Supabase Storage bucket. Public URLs are used by default; set `STAGING_ARTIFACT_PUBLIC=false` to request signed URLs instead.

## Route overrides

The defaults target the platform HTTP routes, but deployments can override any route with environment variables such as `STAGING_LEAD_ROUTE`, `STAGING_EDITOR_APPLY_ROUTE`, `STAGING_DEPLOY_ROUTE`, `STAGING_ANALYTICS_ROUTE`, and `STAGING_INSPECT_ROUTE`. This keeps the adapter independent of a particular staging gateway while preserving the fixture contract.

## Evidence requirements

The optional inspect route should return the actual rows or API projections for:

- `website_audits.visual`
- `site_revisions.before_scores`
- `site_revisions.after_scores`
- `site_revisions.screenshots`
- `site_revisions.deployment_id`
- `site_revisions.status`
- `project_environments.current_revision`
- `project_environments.public_url`
- analytics attribution fields

The adapter can only record that evidence when the staging service exposes that authenticated inspection route. It does not claim that migrations, browsers, providers, or database rows were checked locally.
