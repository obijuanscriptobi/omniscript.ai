# Staging release record

Use only with disposable staging services, test users, and synthetic data. Do not paste credentials or personal customer data into this document.

## Environment identity

- Staging URL:
- Published test URL:
- Netlify site:
- Git commit:
- Supabase project:
- Redis/Upstash database:
- ScrapingBee workspace/key label:
- Form destination label:
- Tester:
- Date/time (UTC):
- Observed Node version:
- Source CI run/artifact:
- Browser CI run/artifact:
- Migration run/artifact:

Do not continue if the commit above differs from the commit represented by any CI, migration, browser, provider, deployment, or release-gate artifact.

## Infrastructure isolation

| Resource | Separate from production | Synthetic/disposable only | Owner | Evidence |
|---|---|---|---|---|
| Hosting site | | | | |
| Supabase project | | | | |
| Redis/Upstash database | | | | |
| Deployment target | | | | |
| Import/search/audit providers | | | | |
| Webhook or test inbox/CRM | | | | |
| Staging domain | | | | |
| Test users and two projects | | | | |

## Environment contract

Record `ready`, `missing`, or `invalid` from `/api/config`; do not record secret values.

| Capability | Expected | Actual | Evidence |
|---|---:|---|---|
| Cloud projects | yes | | |
| Website import | yes | | |
| Distributed rate limiting | yes | | |
| Signed preflight | yes | | |
| Deployment | yes | | |
| Lead webhook/email | yes | | |
| Search/PageSpeed | optional | | |

Strict contract run (`CODEWISE_STAGING_STRICT=true`):

- [ ] Required staging variables are present in the staging secret store
- [ ] `PUBLIC_SITE_ORIGIN` matches `SITE_URL`
- [ ] `/api/config` contains no secret values or secret-like identifiers
- [ ] Capability statuses and evidence were recorded without secret values

## Database and tenancy

Before runtime testing, apply all SQL migrations to the clean Supabase project in dependency order. Verify tables, indexes, functions, triggers, constraints, and RLS policies in the Supabase dashboard or migration output. Create two synthetic projects and assign fixture users only after policy checks are enabled.

Record API responses and database/audit evidence separately. Never paste service-role keys, access tokens, customer data, or unrestricted database exports into this record.

| Check | Owner | Admin | Editor | Reviewer/client | Anonymous | Other project | Evidence |
|---|---|---|---|---|---|---|---|
| Read project | | | | | | | |
| Create/update project | | | | | | | |
| Versions/files/exports | | | | | | | |
| Leads/tasks/appointments | | | | | | | |
| Invitations/approvals/portal | | | | | | | |
| Delete/account recovery | | | | | | | |

## End-to-end workflow

| Step | Result | Evidence |
|---|---|---|
| Brief to draft | | |
| Authorized import | | |
| Visual edit | | |
| Source edit | | |
| Autosave/backup/restore/cloud save | | |
| Quality checks | | |
| Approval | | |
| Signed preflight | | |
| Deployment revision 1 | | |
| Published verification | | |
| Real staging form delivery | | |
| Deployment revision 2 | | |
| Rollback to revision 1 | | |
| Domain/canonical/sitemap/robots change | | |

## Adversarial runtime checks

| Scenario | Expected | Actual | Request ID/log evidence |
|---|---|---|---|
| Duplicate submission | | | |
| Replay/idempotency key | | | |
| Invalid submission ID | | | |
| Oversized body | | | |
| Invalid JSON/content type | | | |
| Invalid origin/honeypot | | | |
| Rate-limit exhaustion | | | |
| Webhook timeout/4xx/5xx | | | |
| Redis unavailable | | | |
| Supabase unavailable | | | |
| Deployment credential failure | | | |
| Deployment status polling | | | |
| Deployment rollback | | | |
| Import quota exhaustion | | | |
| Cross-project access | | | |
| Portal cookie survives refresh; URL token removed | | | |
| Revoked/expired portal session is cleared | | | |
| Concurrent portal comments stop at 100 | | | |
| Concurrent approval decision is single-use | | | |
| Concurrent invitation acceptance is single-use | | | |
| Same idempotency key with different payload conflicts | | | |
| Raw public tokens absent from logs/storage/analytics | | | |
| Pending upload cleanup and missing-object recovery | | | |
| Forged/truncated upload is quarantined | | | |
| Proposal requires approved current revision | | | |
| Handoff rejects unsynced revision/wrong recipient | | | |

## Migration verification

Follow the exact dependency order and verification procedure in [`DATABASE-MIGRATION-RUNBOOK.md`](./DATABASE-MIGRATION-RUNBOOK.md). Do not mark a migration from source inspection alone.

| Database | Clean install | Second application | Legacy upgrade | Rollback/restore | Schema/RPC evidence |
|---|---|---|---|---|---|
| Disposable staging A | | | n/a | | |
| Disposable staging B | n/a | | | | |

Confirm specifically that `create_client_portal_comment` is executable only by `service_role`, that proposal/handoff RPCs are executable only by `authenticated`, and that direct writes to proposal/handoff tables are denied.

## Browser and accessibility matrix

Use the Playwright project name or manual device/browser evidence in the Result column.

| Browser/device | 320 | 375 | 768 | 1024 | 1440 | Evidence |
|---|---|---|---|---|---|---|
| Chromium desktop | | | | | | |
| Firefox desktop | | | | | | |
| WebKit desktop | | | | | | |
| Android Chrome | | | | | | |
| iOS Safari | | | | | | |
| iPad/tablet | | | | | | |

| Condition | Result | Evidence |
|---|---|---|
| Keyboard-only navigation | | |
| 200% zoom | | |
| 400% zoom | | |
| Reduced motion | | |
| Forced colors | | |
| Slow network | | |
| Failed assets | | |
| JavaScript disabled | | |

## Operational and legal sign-off

- [ ] Privacy policy
- [ ] Terms of service
- [ ] Acceptable-use policy
- [ ] Import/content/image authorization
- [ ] Retention and deletion
- [ ] Consent and analytics opt-out
- [ ] Client sharing and revocation
- [ ] Account/project deletion
- [ ] Subprocessors and backups
- [ ] Incident response
- [ ] AI disclosure and claim verification
- [ ] Monitoring and alerts
- [ ] Backup restoration
- [ ] Recovery and support runbooks

## Release evidence references

Record redacted artifact URLs, immutable CI artifact IDs, or ticket references—never credentials or raw tokens. The production release job maps these fields to the corresponding environment variables.

| Release-gate variable | Evidence reference |
|---|---|
| `CODEWISE_EVIDENCE_CLEAN_MIGRATION` | |
| `CODEWISE_EVIDENCE_LEGACY_MIGRATION` | |
| `CODEWISE_EVIDENCE_STAGING_RLS` | |
| `CODEWISE_EVIDENCE_PUBLIC_TOKEN_RACES` | |
| `CODEWISE_EVIDENCE_FILE_LIFECYCLE` | |
| `CODEWISE_EVIDENCE_PROVIDER_DELIVERY` | |
| `CODEWISE_EVIDENCE_BROWSER_A11Y` | |
| `CODEWISE_EVIDENCE_BACKUP_RESTORE` | |
| `CODEWISE_EVIDENCE_MIGRATION_ROLLBACK` | |
| `CODEWISE_EVIDENCE_OPERATIONS` | |

### Exact-commit evidence manifest

After all ten references pass, store the following JSON as the protected `CODEWISE_RELEASE_EVIDENCE_MANIFEST` production environment variable. Use the exact same references as the table above and the successful default-branch CI run selected for the exact commit. The release gate rejects malformed manifests, unknown categories, future or out-of-order timestamps, non-passing entries, reference mismatches, a mismatched CI run ID, and a `releaseCommit` that differs from the checked-out 40-character commit SHA.

```json
{
  "schemaVersion": 1,
  "releaseCommit": "FULL_40_CHARACTER_COMMIT_SHA",
  "environment": { "identity": "NON_SECRET_STAGING_IDENTITY" },
  "createdAt": "YYYY-MM-DDTHH:MM:SSZ",
  "approvedBy": "RELEASE_REVIEWER_IDENTITY",
  "ciRunId": "SUCCESSFUL_EXACT_COMMIT_CI_RUN_ID",
  "evidence": {
    "cleanMigration": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "legacyMigration": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "stagingRls": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "publicTokenRaces": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "fileLifecycle": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "providerDelivery": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "browserAccessibility": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "backupRestore": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "migrationRollback": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" },
    "monitoringIncidentResponse": { "reference": "IMMUTABLE_REFERENCE", "result": "passed", "observedAt": "YYYY-MM-DDTHH:MM:SSZ", "reviewer": "REVIEWER_IDENTITY" }
  }
}
```

Do not place credentials, tokens, customer data, or personal data in this manifest.

## Release decision

- [ ] All blocking checks pass
- [ ] Runtime evidence is attached
- [ ] Known exceptions have owners and due dates
- [ ] Approved for controlled beta
- [ ] Approved for public launch

Reviewer:
Approval date:
Exceptions:

## Execution gate and evidence index

- [ ] Disposable services and credentials are confirmed separate from production
- [ ] HTTPS staging URL and public origin match
- [ ] Clean database migrations applied in dependency order
- [ ] Tables, indexes, functions, triggers, constraints, and RLS verified
- [ ] Synthetic users and two isolated projects created
- [ ] Provider-success checks enabled only for the intended run
- [ ] Adversarial checks completed with request IDs and server-log evidence
- [ ] Published deployment, form delivery, rollback, and SEO checks recorded
- [ ] Browser and accessibility matrix completed
- [ ] Legal, operational, monitoring, backup, and recovery approvals attached
- [ ] Fixture tokens revoked and synthetic data deleted

Evidence index:

| Evidence type | Location/reference | Redacted | Reviewer |
|---|---|---|---|
| Staging smoke HTML report | | | |
| Commit identifier | | | |
| Failure traces/screenshots | | | |
| Supabase migration/RLS evidence | | | |
| Provider delivery evidence | | | |
| Deployment and rollback evidence | | | |
| Logs/audit/request IDs | | | |
| Legal/operational approvals | | | |

## Evidence handling

The staging suite runs in the dedicated `staging` Playwright project. For each run, retain the HTML report, the commit identifier, and traces or screenshots for failures. Store evidence outside this record and redact tokens, authorization headers, email addresses, personal data, provider payloads, and secret-like values. Revoke all fixture tokens and delete synthetic projects after testing.
