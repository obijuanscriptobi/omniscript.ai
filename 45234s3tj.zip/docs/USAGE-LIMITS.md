# Usage and cost limits

Before public launch, choose and enforce server-side limits for each plan. UI-only limits are not controls.

| Resource | Limit | Enforcement location | Alert threshold |
|---|---:|---|---:|
| Projects per account | 25 per account | authenticated project API | 80% |
| Project versions | 50 per project | authenticated project API | 80% |
| Imports per month | 100 per account/month | scrape/search functions | 80% |
| Imported page/body size | 2 MB preflight / provider limit | request validation | 80% |
| Local/cloud project storage | 4.5 MB per project | project API and database | 80% |
| Deployments per month | 100 per account/month | deploy function | 80% |
| Form submissions | 1,000 per project/month | submit-form function | 80% |
| Preview emails | 100 per account/month | send-preview function | 80% |
| Team members | 10 per project | membership API | 80% |
| Audit/benchmark runs | 100 per account/month | audit functions | 80% |
| Provider/API spend | Set a monthly budget before public launch | provider dashboards and alerts | 70% |

Document whether an exhausted quota blocks the operation, queues it, or offers an export-only fallback. Return a request ID and retry guidance without revealing provider credentials.
