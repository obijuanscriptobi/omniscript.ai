"use strict";

// Captures website enquiries from the live preview and stores them as a lead
// plus a same-day follow-up task. Published sites still post to /api/submit-form;
// this is the no-setup path while the owner is reviewing the draft.
(() => {
    const LEAD_KEY = "morrow-lead-inbox-v1";
    const TASK_KEY = "morrow-next-steps-v2";
    const get = (id) => document.getElementById(id);
    const clean = (value, max = 500) => String(value ?? "").replace(/[\u0000-\u001F\u007F]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
    const iso = () => new Date().toISOString();
    const uid = () => globalThis.crypto?.randomUUID?.() || `00000000-0000-4000-8000-${Math.random().toString(16).slice(2, 14).padEnd(12, "0")}`;

    function readJson(key, fallback) {
        try {
            const value = JSON.parse(localStorage.getItem(key) || "");
            return value ?? fallback;
        } catch {
            return fallback;
        }
    }

    function writeJson(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
        return value;
    }

    function dueTomorrow() {
        return new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    }

    function addFollowUpTask(lead) {
        const label = lead.name
            ? `Reply to ${lead.name} within one business day`
            : "Reply to the new website enquiry within one business day";
        const tasks = Array.isArray(readJson(TASK_KEY, [])) ? readJson(TASK_KEY, []) : [];
        if (tasks.some((task) => !task.completed && String(task.text || "").toLowerCase() === label.toLowerCase())) return;
        tasks.unshift({
            id: uid(),
            text: label,
            category: "Follow-up",
            priority: "now",
            dueDate: dueTomorrow(),
            notes: clean(lead.message || lead.email || "A visitor submitted the website form.", 500),
            completed: false,
            createdAt: iso(),
            completedAt: "",
            source: "website-enquiry",
            href: "leads.html",
            effort: "About 5 minutes",
            updatedAt: iso(),
            recurring: false,
            recurrence: ""
        });
        writeJson(TASK_KEY, tasks.slice(0, 200));
    }

    function showToast(lead) {
        document.body.dataset.enquiryReady = "true";
        const toast = get("enquiry-toast");
        const detail = get("enquiry-toast-detail");
        const who = clean(lead?.name || lead?.email || "A visitor", 80);
        if (detail) detail.textContent = `${who} is saved in Leads with a follow-up for tomorrow.`;
        if (toast) {
            toast.hidden = false;
            window.clearTimeout(showToast.timer);
            showToast.timer = window.setTimeout(() => { toast.hidden = true; }, 8000);
        }
    }

    function capture(payload = {}) {
        const enquiry = {
            name: clean(payload.name, 160),
            email: clean(payload.email, 240),
            phone: clean(payload.phone, 80),
            message: clean(payload.message, 2000),
            company: clean(payload.company, 180),
            source: clean(payload.source, 80) || "website"
        };
        if (!enquiry.name && !enquiry.email && !enquiry.phone && !enquiry.message) return null;

        let lead = null;
        if (typeof window.workspaceCRM?.captureWebsiteEnquiry === "function") {
            lead = window.workspaceCRM.captureWebsiteEnquiry(enquiry);
        } else {
            const leads = Array.isArray(readJson(LEAD_KEY, [])) ? readJson(LEAD_KEY, []) : [];
            const duplicate = leads.find((item) => item.email && enquiry.email && String(item.email).toLowerCase() === enquiry.email.toLowerCase() && item.source === enquiry.source);
            if (duplicate) {
                duplicate.message = enquiry.message || duplicate.message;
                duplicate.unread = true;
                duplicate.updatedAt = iso();
                writeJson(LEAD_KEY, leads);
                addFollowUpTask(duplicate);
                lead = duplicate;
            } else {
                lead = {
                    id: uid(),
                    name: enquiry.name,
                    email: enquiry.email,
                    phone: enquiry.phone,
                    message: enquiry.message,
                    company: enquiry.company,
                    status: "new",
                    source: enquiry.source,
                    unread: true,
                    nextAction: { title: "Reply within one business day", dueDate: dueTomorrow(), owner: "owner" },
                    createdAt: iso(),
                    updatedAt: iso()
                };
                writeJson(LEAD_KEY, [lead, ...leads].slice(0, 500));
                addFollowUpTask(lead);
            }
        }

        showToast(lead || enquiry);
        document.dispatchEvent(new CustomEvent("workspace:enquiry-captured", { detail: { lead: lead || enquiry } }));
        return lead || enquiry;
    }

    function fromForm(form) {
        if (!form || typeof FormData !== "function") return null;
        const data = new FormData(form);
        return capture({
            name: data.get("name") || data.get("full_name") || data.get("fullName"),
            email: data.get("email"),
            phone: data.get("phone") || data.get("tel"),
            message: data.get("message") || data.get("details") || data.get("qualification"),
            company: data.get("company"),
            source: form.dataset.goal || "website"
        });
    }

    function markFormSuccess(form) {
        if (!form) return;
        const status = form.querySelector(".form-status, [data-form-status], output");
        if (status) {
            status.dataset.state = "success";
            status.textContent = "Thanks — your enquiry was received. We will be in touch shortly.";
        }
        form.querySelectorAll("button[type='submit'], input[type='submit']").forEach((button) => {
            button.disabled = false;
        });
    }

    function bindFrame(iframe) {
        let doc = null;
        try { doc = iframe?.contentDocument; } catch (_) { return; }
        if (!doc) return;
        if (doc.documentElement?.dataset.enquiryLoopBound === "true") return;
        doc.documentElement.dataset.enquiryLoopBound = "true";
        doc.addEventListener("submit", (event) => {
            const form = event.target;
            if (!(form instanceof doc.defaultView.HTMLFormElement)) return;
            event.preventDefault();
            event.stopPropagation();
            fromForm(form);
            markFormSuccess(form);
        }, true);
    }

    function bind() {
        const iframe = get("previewContentIframe");
        iframe?.addEventListener("load", () => bindFrame(iframe));
        document.addEventListener("workspace:files-rendered", () => bindFrame(iframe));
        window.addEventListener("message", (event) => {
            // The sandboxed srcdoc frame has an opaque origin. Authenticate it
            // by WindowProxy identity, then apply the shared strict schema.
            if (event.source !== iframe?.contentWindow) return;
            const message = window.websiteMakerPreviewProtocol?.parse?.(event.data);
            if (message?.type === "enquiry") capture(message.payload);
        });
        window.enquiryLoop = Object.freeze({ capture, fromForm });
        try { if (iframe?.contentDocument?.readyState === "complete") bindFrame(iframe); } catch (_) { /* Opaque sandbox preview uses postMessage. */ }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
