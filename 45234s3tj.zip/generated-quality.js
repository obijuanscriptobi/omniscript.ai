"use strict";

/* Generates the exported site. The editor owns persistence and preview; this layer
   owns the quality bar, content system, responsive design, and safe interactions. */
(() => {
    const $ = (id) => document.getElementById(id);

    const escapeHtml = (value) => String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

    const slugify = (value) => String(value || "business")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "") || "business";

    function safeExternalUrl(value) {
        const candidate = String(value || "").trim();
        try {
            const url = new URL(candidate);
            // Generated sites should never introduce mixed content or credentialed URLs.
            if (url.protocol !== "https:" || url.username || url.password) return "";
            return url.href.replace(/["'\\<>\n\r]/g, "");
        } catch {
            return "";
        }
    }

    function safeImageUrl(value) {
        return safeExternalUrl(value);
    }

    function safeEmail(value) {
        const candidate = String(value || "").trim();
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(candidate) && candidate.length <= 320
            ? candidate
            : "";
    }

    // Accept BCP 47-style language tags (for example es, pt-BR, zh-Hant,
    // or sr-Latn-RS) without limiting the generated site to a fixed language list.
    const normalizeLocaleTag = (value) => {
        const candidate = String(value || "").trim().replace(/_/g, "-");
        return /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/.test(candidate) ? candidate : "";
    };

    function data() {
        const value = (id, fallback = "", max = 500) => {
            const raw = $(id)?.value;
            const clean = String(raw ?? "").replace(/[\u0000-\u001F\u007F]/g, "").replace(/\s+/g, " ").trim();
            return (clean || fallback).slice(0, max);
        };
        return {
            name: value("input-biz-name", "Your business", 120),
            hook: value("input-biz-hook", "", 240),
            location: value("input-biz-location", "", 120),
            phone: value("input-biz-phone", "", 40),
            color: /^#[0-9a-f]{6}$/i.test($("input-biz-color")?.value || "") ? $("input-biz-color").value : "#c9a86a",
            secondaryColor: /^#[0-9a-f]{6}$/i.test($("input-biz-secondary-color")?.value || "") ? $("input-biz-secondary-color").value : "#18202b",
            logo: safeImageUrl(value("input-biz-logo", "")),
            heroImage: safeImageUrl(value("input-biz-hero-image", "")),
            gallery: [...new Set(value("input-biz-gallery", "").split(",").map((item) => safeImageUrl(item)).filter(Boolean))].slice(0, 6),
            logoAlt: value("input-biz-logo-alt", "", 160),
            heroAlt: value("input-biz-hero-alt", "", 250),
            heroDecorative: Boolean($("input-biz-hero-decorative")?.checked),
            galleryAlt: value("input-biz-gallery-alt", "", 1500).split("\n").map((item) => item.trim()).filter(Boolean).slice(0, 6),
            approvedClaims: value("input-biz-approved-claims", "", 2500).split("\n").map((item) => item.trim()).filter(Boolean).slice(0, 40),
            forbiddenClaims: value("input-biz-forbidden-claims", "", 1500).split("\n").map((item) => item.trim()).filter(Boolean).slice(0, 40),
            brandVoice: value("input-biz-brand-voice", "", 180),
            services: value("input-biz-services", "", 1200),
            email: safeEmail(value("input-biz-email", "", 320)),
            address: value("input-biz-address", "", 240),
            audience: value("input-biz-audience", "", 160),
            differentiator: value("input-biz-differentiator", "", 240),
            testimonial: value("input-biz-testimonial", "", 800),
            testimonialAuthor: value("input-biz-testimonial-author", "", 160),
            credentials: value("input-biz-credentials", "", 180),
            experience: value("input-biz-experience", "", 100),
            customers: value("input-biz-customers", "", 100),
            hours: value("input-biz-hours", "", 240),
            pricing: value("input-biz-pricing", "", 180),
            booking: safeImageUrl(value("input-biz-booking", "")),
            primaryGoal: ["quote", "booking", "call", "email", "shop"].includes($("input-primary-goal")?.value) ? $("input-primary-goal").value : "quote",
            primaryCta: value("input-primary-cta", "", 80),
            responseTime: value("input-response-time", "", 240),
            type: ["restaurant", "wellness", "creative", "professional", "retail", "local-service"].includes($("input-business-type")?.value) ? $("input-business-type").value : "local-service",
            style: ["premium", "modern", "bold", "warm"].includes($("input-design-style")?.value) ? $("input-design-style").value : "premium",
            tone: ["clear", "warm", "bold", "editorial"].includes($("input-content-tone")?.value) ? $("input-content-tone").value : "clear",
            density: ["airy", "balanced", "compact"].includes($("input-layout-density")?.value) ? $("input-layout-density").value : "airy",
            endpoint: /^\/(?!\/)[^\s<>"']{1,280}$/.test(value("input-form-endpoint", "/api/submit-form")) ? value("input-form-endpoint", "/api/submit-form") : "/api/submit-form",
            success: value("input-form-success", "Thanks — your enquiry was accepted. We will be in touch shortly.", 240),
            error: value("input-form-error", "We could not accept your enquiry. Please try again.", 240),
            qualificationQuestion: value("input-form-qualification", "", 240),
            consent: Boolean($("input-form-consent")?.checked),
            analyticsMode: ["essential", "anonymous"].includes($("input-privacy-analytics")?.value) ? $("input-privacy-analytics").value : "essential",
            locale: normalizeLocaleTag(value("input-locale", "en-US", 32)) || "en-US",
            direction: ["ltr", "rtl"].includes(value("input-direction", "ltr", 3)) ? value("input-direction", "ltr", 3) : "ltr",
            supportedLocales: [...new Set(value("input-supported-locales", "en-US", 500).split(",").map(normalizeLocaleTag).filter(Boolean))].slice(0, 24),
            manualTranslations: (() => {
                try {
                    const parsed = JSON.parse($("input-manual-translations")?.value || "{}");
                    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
                } catch {
                    return {};
                }
            })(),
            hostingProvider: value("hosting-provider-select", "static-export", 40),
            privacy: {
                analytics: ["essential", "anonymous"].includes($("input-privacy-analytics")?.value) ? $("input-privacy-analytics").value : "essential",
                retention: value("input-privacy-retention", "", 240),
                processors: value("input-privacy-processors", "", 300),
                rights: value("input-privacy-rights", "", 240),
                effective: value("input-privacy-effective", "", 20)
            },
            projectId: window.workspaceAPI?.getState?.()?.projectId || "",
            siteUrl: (() => {
                try {
                    const raw = value("published-site-url-input", "");
                    const url = new URL(raw);
                    if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) return "";
                    return `${url.origin}${url.pathname.replace(/\/$/, "")}`;
                } catch {
                    return "";
                }
            })()
        };
    }

    const conciseText = (value, fallback, max = 92) => {
        const clean = String(value || fallback).replace(/\s+/g, " ").trim();
        if (clean.length <= max) return clean;
        return `${clean.slice(0, max - 1).replace(/\s+\S*$/, "").trim()}…`;
    };

    const cleanPhrase = (value, fallback = "", max = 92) => conciseText(
        String(value || fallback).replace(/[.!?]+$/, ""),
        fallback,
        max
    );

    function contentPolicyFor(business) {
        const approvedClaims = [...new Set((business.approvedClaims || []).map((claim) => cleanPhrase(claim, "", 180)).filter(Boolean))].slice(0, 40);
        const forbiddenClaims = [...new Set((business.forbiddenClaims || []).map((claim) => String(claim).trim().toLowerCase()).filter(Boolean))].slice(0, 40);
        const blockedTerms = ["trusted", "best", "expert", "licensed", "guaranteed", "award-winning", "world-class", "top-rated", "#1"];
        const containsForbidden = (text) => {
            const value = String(text || "").toLowerCase();
            return forbiddenClaims.some((claim) => value.includes(claim)) || blockedTerms.some((term) => value.includes(term));
        };
        const sanitize = (text, fallback = "") => containsForbidden(text) ? fallback : String(text || fallback).trim();
        return { approvedClaims, forbiddenClaims, sanitize, generatedClaims: [] };
    }

    function copyFor(business) {
        const map = {
            restaurant: { eyebrow: "Made with intention", title: business.hook || "", intro: "", cta: "Reserve a table", proof: "", question: "Planning your next meal?" }, 
            wellness: { eyebrow: "Feel more like yourself", title: business.hook || "", intro: "", cta: "Book a consultation", proof: "", question: "Ready to feel more like yourself?" },
            creative: { eyebrow: "Ideas with direction", title: business.hook || "", intro: "", cta: "Start a project", proof: "", question: "Have a good idea that needs somewhere to go?" },
            professional: { eyebrow: "A clearer way forward", title: business.hook || "", intro: "", cta: "Book a conversation", proof: "", question: "A clearer next step starts here." },
            retail: { eyebrow: "Made for everyday living", title: business.hook || "", intro: "", cta: "Explore the collection", proof: "", question: "Find something you will keep." },
            "local-service": { eyebrow: "", title: business.hook || "", intro: "", cta: "Get a quote", proof: "", question: "Ready for a better next step?" }
        };
        const selected = { ...(map[business.type] || map["local-service"]) };
        const policy = contentPolicyFor(business);
        const audience = cleanPhrase(business.audience, "the people you serve");
        const location = cleanPhrase(business.location, "your area");
        const serviceName = cleanPhrase((business.services.split(",")[0] || "").trim(), "");
        const rawHook = cleanPhrase(business.hook, "");
        const genericHook = !rawHook || /^(?:a better way to move your business forward|quality service with a better experience|the thoughtful way to get it done)$/i.test(rawHook);
        const vagueHook = /\b(?:quality|professional|trusted|reliable|expert|solutions?|services?)\b/i.test(rawHook);
        const outcomeHook = rawHook && !vagueHook;
        const specificAudience = business.audience ? ` for ${audience}` : "";
        const specificLocation = !business.audience && business.location ? ` in ${location}` : "";
        const specificTitle = serviceName
            ? `${serviceName}${specificAudience || specificLocation}`
            : business.name;
        const differentiator = cleanPhrase(business.differentiator, "", 120);
        const audienceLead = business.audience ? ` for ${audience}` : "";
        const locationLead = business.location ? ` in ${location}` : "";
        if (genericHook || vagueHook) {
            selected.title = specificTitle;
            selected.intro = differentiator
                ? `${serviceName}${audienceLead}${locationLead}, with ${differentiator}.`
                : [serviceName, business.audience ? `for ${audience}` : "", business.location ? `in ${location}` : ""].filter(Boolean).join(" ");
        } else if (outcomeHook) {
            selected.title = rawHook;
            selected.intro = [business.audience ? `For ${audience}.` : "", business.location ? `Serving ${location}.` : ""].filter(Boolean).join(" ");
        }
        if (!selected.title || selected.title === "your service") selected.title = business.name;
        if (!selected.intro || /Add your audience/i.test(selected.intro)) {
            selected.intro = business.location
                ? `Tell us what you need and we will help you choose the right next step in ${location}.`
                : "Tell us what you need and we will help you choose the right next step.";
        }
        selected.proof = differentiator || business.credentials || business.experience || business.customers || "";
        if (business.location && selected.eyebrow && !selected.eyebrow.toLowerCase().includes(location.toLowerCase())) {
            selected.eyebrow = `${selected.eyebrow} · ${location}`;
        }
        const goalLabels = {
            quote: "Get a quote",
            booking: "Book an appointment",
            call: "Call us",
            email: "Send an enquiry",
            shop: "Explore the collection"
        };
        selected.cta = business.primaryCta || goalLabels[business.primaryGoal] || selected.cta;
        if (business.audience && !genericHook) {
            selected.intro = `${selected.intro} Built for ${audience}.`;
        }
        if (business.differentiator) {
            selected.proof = `${cleanPhrase(business.differentiator, selected.proof)}.`;
        }
        selected.intro = selected.intro.replace(/\b(high[- ]quality|top[- ]quality|world[- ]class|best[- ]in[- ]class)\b/gi, "carefully delivered");
        selected.proof = selected.proof.replace(/\b(high[- ]quality|top[- ]quality|world[- ]class|best[- ]in[- ]class)\b/gi, "carefully delivered");
        if (business.tone === "warm") {
            selected.intro = selected.intro.replace("Practical expertise and thoughtful guidance", "Personal guidance and thoughtful support");
        }
        if (business.tone === "bold") {
            selected.proof = `${selected.proof} No second-guessing.`;
        }
        if (business.tone === "editorial") {
            selected.eyebrow = `Considered ${selected.eyebrow.toLowerCase()}`;
        }
        if (policy.approvedClaims.length) {
            selected.proof = [selected.proof, policy.approvedClaims[0]].filter(Boolean).join(". ");
            policy.generatedClaims.push({ text: policy.approvedClaims[0], source: "user-supplied" });
        }
        selected.eyebrow = policy.sanitize(selected.eyebrow, "A clear next step");
        selected.title = policy.sanitize(selected.title, business.name);
        selected.intro = policy.sanitize(selected.intro, "Tell us what you need and we will help you choose the right next step.");
        selected.proof = policy.sanitize(selected.proof, "A straightforward experience, focused on what you need.");
        business.contentPolicy = policy;
        return selected;
    }

    function serviceDescriptionFor(business, serviceName, index = 0) {
        const name = cleanPhrase(serviceName, "this service", 70);
        const differentiator = business.differentiator ? `, shaped by ${cleanPhrase(business.differentiator, "your needs", 90).toLowerCase()}` : "";
        const descriptions = {
            restaurant: [
                `A carefully considered ${name.toLowerCase()} experience, made for good food and an easy occasion.`,
                `Thoughtful preparation and warm service, with the details handled for you.`,
                `A memorable option for sharing, celebrating, or taking a little more time.`
            ],
            wellness: [
                `Personal support through ${name.toLowerCase()}, with a plan that fits your goals and routine.`,
                `A calm, practical approach designed to help you feel informed and supported.`,
                `Thoughtful care that meets you where you are and helps you move forward.`
            ],
            creative: [
                `A focused ${name.toLowerCase()} engagement that gives your ideas a sharper direction.`,
                `Clear thinking and polished execution, connected to the audience you want to reach.`,
                `Work with purpose, shaped to be distinctive, useful, and ready to make an impact.`
            ],
            professional: [
                `Practical ${name.toLowerCase()} guidance that turns complexity into a clear next step.`,
                `Straightforward advice grounded in your priorities, circumstances, and desired outcome.`,
                `A considered service that helps you decide with more confidence and less uncertainty.`
            ],
            retail: [
                `A considered ${name.toLowerCase()} selection chosen for usefulness, character, and lasting appeal.`,
                `Well-made details and helpful guidance, without pressure to choose in a hurry.`,
                `A thoughtful option for everyday life, gifting, or the next adventure.`
            ],
            "local-service": [
                `A dependable ${name.toLowerCase()} service with clear communication from start to finish.`,
                `A practical approach designed around the job, your priorities, and the result you want.`,
                `Careful work, sensible recommendations, and no unnecessary complications.`
            ]
        };
        const options = descriptions[business.type] || descriptions["local-service"];
        const sentence = options[index % options.length];
        return `${sentence.replace(/[.!?]+$/, "")}${differentiator}.`;
    }

    function contentFor(business, text) {
        const knownArea = business.location ? cleanPhrase(business.location, "", 70) : "your area";
        const profiles = {
            restaurant: {
                sectionKicker: "On the menu",
                sectionTitle: "A better meal starts with the right details.",
                sectionLead: "From the first welcome to the last bite, every part of the experience is designed to make your time with us memorable.",
                steps: [
                    ["01", "Choose your moment", "Tell us when you would like to visit and we will help make the occasion feel easy."],
                    ["02", "Settle in", "Expect warm hospitality, thoughtful recommendations, and a table that feels like yours."],
                    ["03", "Enjoy the details", "Seasonal ingredients, careful preparation, and service that knows when to be there."]
                ],
                faqs: [["Do you take reservations?", "Use the booking link or contact us to reserve a table for your preferred time."], ["Can you accommodate dietary needs?", "Let us know when you enquire so we can help you choose with confidence."], ["Do you host private events?", "Tell us about your occasion, group size, and date and we will recommend the best option."], ["Where can I find you?", `We welcome guests in ${business.location} and the surrounding area.`]]
            },
            wellness: {
                sectionKicker: "Your care, considered",
                sectionTitle: "Support that fits the way you live.",
                sectionLead: "We make it easier to understand your options, choose the right support, and build progress you can sustain.",
                steps: [["01", "Talk it through", "Start with an honest conversation about what you need and what you want to change."], ["02", "Make a plan", "Together, we shape a practical approach around your goals, schedule, and comfort."], ["03", "Keep moving forward", "You will have thoughtful support and clear next steps as your needs evolve."]],
                faqs: [["Who is this for?", `We support people in ${knownArea} and nearby who want practical, personal care.`], ["What happens at the first appointment?", "We will listen, answer your questions, and recommend the most useful next step."], ["How often will I need support?", "That depends on your goals. We will explain the options clearly before you commit."], ["Can I ask questions before booking?", "Yes. Contact us and we will be happy to help you decide whether we are the right fit."]]
            },
            creative: {
                sectionKicker: "What we make",
                sectionTitle: "Ideas are stronger when they have somewhere to go.",
                sectionLead: "We connect strategy, story, and execution to help ambitious brands communicate with more clarity and distinction.",
                steps: [["01", "Find the opportunity", "We get close to the brief, the audience, and the challenge behind the challenge."], ["02", "Shape the direction", "You get a focused creative route with a clear reason behind every important choice."], ["03", "Make it matter", "We turn the direction into polished work that is ready to be seen, used, and remembered."]],
                faqs: [["What kind of projects do you take on?", "Share your goals, timing, and what you need made and we will suggest a suitable scope."], ["How do projects begin?", "We start with a focused conversation and a clear understanding of the opportunity."], ["Do you work with in-house teams?", "Yes. We can lead, collaborate, or provide specialist support where it is most useful."], ["Where do you work?", `We work with clients in ${knownArea} and beyond.`]]
            },
            professional: {
                sectionKicker: "How we help",
                sectionTitle: "Good advice should make the next step clearer.",
                sectionLead: "We turn complex questions into practical options, considered decisions, and a plan you can act on.",
                steps: [["01", "Understand the situation", "We listen carefully, ask the useful questions, and establish what matters most."], ["02", "Clarify your options", "You get straightforward guidance grounded in your goals, circumstances, and priorities."], ["03", "Move with confidence", "We help you take the next step with a clear plan and support when you need it."]],
                faqs: [["What can you help with?", "Send us a brief overview of your situation and we will explain where we can add the most value."], ["What happens in a first conversation?", "We learn what you need, answer initial questions, and outline the most sensible next step."], ["How are fees handled?", "We will explain scope, timing, and fees clearly before any work begins."], ["Who do you work with?", `We support people and businesses in ${knownArea} and the surrounding area.`]]
            },
            retail: {
                sectionKicker: "Worth discovering",
                sectionTitle: "Useful things, chosen with a little more care.",
                sectionLead: "Explore a considered collection selected for quality, character, and the way it fits into everyday life.",
                steps: [["01", "Explore the collection", "Browse pieces selected for their materials, function, and lasting appeal."], ["02", "Find your fit", "If you need a second opinion, we are here with useful guidance—not pressure."], ["03", "Take it home", "Enjoy a simpler, more personal way to find things you will use and keep."]],
                faqs: [["What makes your collection different?", "We choose products for their quality, usefulness, and details that reward a closer look."], ["Can I visit in person?", `Find us in ${knownArea}; contact us for current opening information.`], ["Do you offer gift help?", "Yes. Tell us who you are shopping for and your budget and we will suggest a few thoughtful options."], ["Can I ask about availability?", "Contact us with the item you are interested in and we will check what is currently available."]]
            },
            "local-service": {
                sectionKicker: `How ${business.name} works`,
                sectionTitle: "A better result starts with a better process.",
                sectionLead: business.location
                    ? `From the first conversation to the final detail, we make getting the help you need straightforward in ${knownArea}.`
                    : "From the first conversation to the final detail, we make getting the help you need straightforward.",
                steps: [["01", "Tell us what you need", "Share the job, the challenge, or the outcome you have in mind."], ["02", "Get a clear recommendation", "We will explain the options, timing, and next steps without unnecessary jargon."],                 ["03", "Take the next step", "Move forward with clear communication and a result shaped around your needs."]],
                faqs: [["What areas do you serve?", business.location ? `We work with customers in ${knownArea} and the surrounding area.` : "Tell us where you need help and we will confirm whether we serve your area."], ["How do I get a quote?", "Send a few details through the form and we will respond with the most useful next step."], ["How soon can you start?", "Availability depends on the work and our current schedule; contact us and we will let you know."], ["Is the service tailored to my needs?", "Yes. We will understand your requirements before recommending the right approach."]]
            }
        };
        const profile = { ...(profiles[business.type] || profiles["local-service"]) };
        const primaryService = cleanPhrase((business.services.split(",")[0] || "").trim(), "", 70);
        const locationPhrase = business.location ? ` in ${knownArea}` : "";
        if (business.services || business.audience || business.location) {
            const subject = primaryService || (business.type === "restaurant" ? "our menu" : business.type === "retail" ? "our collection" : "our services");
            const audienceLabel = business.audience ? ` for ${cleanPhrase(business.audience, "", 70)}` : "";
            profile.sectionTitle = `${subject}${audienceLabel}, made clearer.`;
            profile.sectionLead = business.hook
                ? `${cleanPhrase(business.hook, "", 150)}${locationPhrase}.`
                : `See what we offer, who it is for, and how we make the next step straightforward${locationPhrase}.`;
        }
        if (business.location) {
            profile.faqs = profile.faqs.map(([question, answer]) => [question, answer.replace(/in your city and surrounding areas|in your area|in Your city and surrounding areas/gi, `in ${business.location}`)]);
        }
        return profile;
    }

    /*
     * Design Intelligence is deliberately pattern-based rather than scraped.
     * It turns proven category conventions into original design decisions and
     * keeps the result stable for the same business brief.
     */
    function designIntelligenceFor(business) {
        const patterns = {
            restaurant: { conversion: "booking", heroFocus: "menu-and-reservation", motif: "ingredient-grid", card: "menu-card", divider: "plate-rule", missing: ["hero image", "menu or signature dish photos", "location image"] },
            wellness: { conversion: "appointment", heroFocus: "calm-consultation", motif: "soft-orbit", card: "care-card", divider: "breath-rule", missing: ["hero image", "team or practitioner image", "treatment detail"] },
            creative: { conversion: "portfolio-enquiry", heroFocus: "selected-work", motif: "studio-grid", card: "project-card", divider: "crop-rule", missing: ["hero image", "work examples", "team or studio image"] },
            professional: { conversion: "lead-qualification", heroFocus: "clear-outcome", motif: "editorial-rule", card: "advice-card", divider: "index-rule", missing: ["hero image", "team image", "proof or case study"] },
            retail: { conversion: "product-discovery", heroFocus: "collection", motif: "catalogue-grid", card: "product-card", divider: "price-rule", missing: ["hero image", "product detail photos", "location or stockist image"] },
            "local-service": { conversion: "quote-or-call", heroFocus: "service-area", motif: "route-lines", card: "service-card", divider: "measure-rule", missing: ["hero image", "work examples", "service-area image"] }
        };
        const pattern = patterns[business.type] || patterns["local-service"];
        const seedSource = `${business.name}|${business.type}|${business.primaryGoal}|${business.audience}|${business.location}|${business.style}|${business.tone}`;
        const seed = [...seedSource].reduce((total, character) => (total * 33 + character.charCodeAt(0)) % 1009, 19);
        const artDirections = [
            { name: "Quiet editorial", layout: "editorial", texture: "paper", motion: "reveal", radius: "small" },
            { name: "Geometric signal", layout: "asymmetric", texture: "grid", motion: "drift", radius: "sharp" },
            { name: "Human rhythm", layout: "stacked", texture: "rings", motion: "lift", radius: "soft" },
            { name: "Bright catalogue", layout: "offset", texture: "dots", motion: "crop", radius: "pill" }
        ];
        const art = artDirections[seed % artDirections.length];
        const hasTrust = Boolean(business.testimonial || business.credentials || business.experience || business.customers || business.differentiator);
        const hasAction = Boolean(business.phone || business.email || business.booking || business.endpoint);
        const hasSpecificity = Boolean(business.hook || business.audience || business.location || business.services || business.differentiator);
        const score = (value) => Math.max(0, Math.min(100, value));
        const scores = {
            firstScreen: score(42 + (business.hook ? 20 : 0) + (business.primaryCta ? 12 : 0) + (business.heroImage ? 10 : 0) + (business.location ? 8 : 0)),
            ctaVisibility: score(45 + (hasAction ? 20 : 0) + (business.primaryCta ? 20 : 0) + (business.primaryGoal ? 10 : 0)),
            mobileUsability: score(78 + (business.density === "compact" ? 4 : 0)),
            contrast: score(88),
            contentSpecificity: score(35 + (hasSpecificity ? 42 : 0) + (business.approvedClaims?.length ? 12 : 0)),
            trustSignals: score(28 + (hasTrust ? 52 : 0)),
            formFriction: score(78 - (business.qualificationQuestion ? 10 : 0) - (business.consent ? 5 : 0)),
            pageSpeed: score(76 - (business.gallery?.length || 0) * 3 - (business.heroImage ? 4 : 0))
        };
        const recommendations = [];
        if (!business.heroImage) recommendations.push(`Consider adding a ${pattern.missing[0]} for a stronger first screen.`);
        if (!hasTrust) recommendations.push(`Add one verified trust signal, such as a ${pattern.missing[2]}.`);
        if (!business.location && business.type === "local-service") recommendations.push("Adding a service area can improve local clarity and conversion.");
        if (!business.differentiator) recommendations.push("Add a specific difference so the page does not sound interchangeable.");
        return { ...pattern, ...art, seed, scores, recommendations: recommendations.slice(0, 4) };
    }

    function designFor(style) {
        const catalogTokens = window.workspaceDesignSystems?.tokens?.(style);
        if (catalogTokens) return catalogTokens;
        // Safe fallback for isolated embeds that do not load the catalog.
        return {
            paper: "#f5f1e8", ink: "#17202a", surface: "#fffdf8", muted: "#66717c", dark: "#17202a", soft: "#e7dfd1",
            serif: "Georgia, 'Times New Roman', serif", radius: "2px", hero: "left", heroSize: "720px",
            heroOverlay: "linear-gradient(90deg,rgba(10,18,25,.88),rgba(10,18,25,.20))", headingWeight: "400"
        };
    }

    function designVariantFor(business) {
        // A stable seed keeps the same brief consistent while making different
        // businesses feel intentionally art-directed rather than templated.
        const seedText = `${business.name}|${business.type}|${business.audience}|${business.style}|${business.tone}`;
        const seed = [...seedText].reduce((total, character) => (total * 31 + character.charCodeAt(0)) % 997, 17);
        const variants = [
            { shape: "soft", angle: "135deg", marker: "dot", offset: "8%" },
            { shape: "sharp", angle: "45deg", marker: "line", offset: "18%" },
            { shape: "pill", angle: "160deg", marker: "ring", offset: "28%" },
            { shape: "editorial", angle: "110deg", marker: "dash", offset: "12%" }
        ];
        return { ...variants[seed % variants.length], index: seed % variants.length };
    }

    function generatedCss(business) {
        const d = designFor(business.style);
        const variant = designVariantFor(business);
        const intelligence = business.designIntelligence || designIntelligenceFor(business);
        const densitySpace = { airy: "105px", balanced: "82px", compact: "62px" }[business.density] || "105px";
        const artTexture = { paper: "radial-gradient(circle at 20% 20%,rgba(255,255,255,.18),transparent 28%),", grid: "linear-gradient(rgba(255,255,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.08) 1px,transparent 1px),", rings: "radial-gradient(circle at 78% 18%,transparent 0 12%,rgba(255,255,255,.12) 12.2% 12.6%,transparent 12.8% 22%,rgba(255,255,255,.08) 22.2% 22.6%,transparent 22.8%),", dots: "radial-gradient(circle,rgba(255,255,255,.16) 1px,transparent 1.5px)," }[intelligence.texture] || "";
        return `:root{--ink:${d.ink};--muted:${d.muted};--paper:${d.paper};--surface:${d.surface};--line:rgba(23,32,42,.14);--accent:${business.color};--accent-secondary:${business.secondaryColor};--accent-dark:${business.secondaryColor};--dark:${d.dark};--soft:${d.soft};--radius:${d.radius};--section-space:${densitySpace};--serif:${d.serif};--sans:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;--heading-weight:${d.headingWeight};--hero-size:${d.heroSize};--hero-overlay:${d.heroOverlay};--art-angle:${variant.angle};--art-offset:${variant.offset};--art-delay:${(variant.index * 0.06).toFixed(2)}s;--art-texture:${artTexture}transparent;--art-layout:${intelligence.layout}}*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:24px}body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--sans);line-height:1.6;text-rendering:optimizeLegibility;-webkit-font-smoothing:antialiased}::selection{background:var(--accent);color:#17130c}a{color:inherit}img{display:block;max-width:100%;height:auto}button,input,textarea,select{font:inherit}button{cursor:pointer}:focus-visible{outline:3px solid var(--accent);outline-offset:4px}:target{scroll-margin-top:32px}@media print{.site-header,.hero-actions,.mobile-menu,.button{display:none!important}.hero{min-height:auto;background:#fff!important;color:#000;padding:24px 0}.section,.trust-strip{padding:28px 0}.contact-section{background:#fff;color:#000}.contact-section h2{color:#000}.shell{width:100%}}.skip-link{position:fixed;z-index:10;top:12px;left:12px;padding:10px 14px;border-radius:6px;background:var(--accent);color:#17130c;font-weight:700;transform:translateY(-150%)}.skip-link:focus{transform:translateY(0)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.form-note{margin:0;color:var(--muted);font-size:12px}.testimonial-section blockquote{max-width:820px;margin:0;font-family:var(--serif);font-size:clamp(30px,4vw,54px);letter-spacing:-.05em;line-height:1.08}.availability{margin:22px 0 0;color:rgba(255,255,255,.72);font-size:14px}.availability strong{color:var(--accent)}.shell{width:min(1180px,calc(100% - 48px));margin:auto}.site-header{position:absolute;z-index:3;top:0;left:0;right:0;padding:25px 0;color:#fff}.nav{display:flex;align-items:center;justify-content:space-between;gap:24px}.brand{display:inline-flex;align-items:center;gap:10px;font-weight:750;letter-spacing:-.035em;text-decoration:none}.brand-mark{width:44px;height:44px;object-fit:contain;border-radius:8px}.header-tools{display:flex;align-items:center;justify-content:flex-end;gap:18px;min-width:0}.nav-links{display:flex;align-items:center;gap:25px;font-size:13px}.nav-links a{text-decoration:none;opacity:.84}.language-switcher{display:inline-flex;align-items:center;margin:0}.header-language-switcher .language-switcher{padding-left:12px;border-left:1px solid rgba(255,255,255,.28)}.language-switcher select{min-height:38px;padding:8px 28px 8px 10px;border:1px solid rgba(255,255,255,.35);border-radius:999px;background:transparent;color:#fff;font-size:12px}.language-switcher-label{margin-right:6px;color:rgba(255,255,255,.78);font-size:11px}.language-switcher option{color:#17202a;background:#fff}.language-switcher select:focus-visible{outline:3px solid var(--accent);outline-offset:3px}.nav-links a:hover,.nav-links a:focus-visible{opacity:1}.nav-cta,.button{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:12px 19px;border:1px solid transparent;border-radius:999px;background:var(--accent);color:#17130c;text-decoration:none;font-size:13px;font-weight:700;transition:transform .2s ease,background .2s ease,box-shadow .2s ease}.button:hover,.nav-cta:hover{background:#f0cf8b;box-shadow:0 10px 24px rgba(0,0,0,.14);transform:translateY(-2px)}.button:active,.nav-cta:active{transform:translateY(0)}.button,.nav-cta,.card,.gallery-grid figure{will-change:transform}.hero-inner{animation:hero-enter .7s ease both}.hero.art-asymmetric .hero-inner{max-width:1180px;margin-inline:auto}.hero.art-offset .hero-inner{padding-top:180px}.hero.art-stacked .hero-inner{max-width:760px}.hero.art-editorial .hero-inner{max-width:980px}.hero:before{animation:art-drift 14s ease-in-out infinite alternate}.section-heading,.card,.gallery-grid figure,.faq-grid details{animation:content-rise .65s ease both;animation-delay:var(--art-delay)}.card:nth-child(2),.gallery-grid figure:nth-child(2),.faq-grid details:nth-child(2){animation-delay:.08s}.card:nth-child(3),.gallery-grid figure:nth-child(3),.faq-grid details:nth-child(3){animation-delay:.16s}@keyframes hero-enter{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}@keyframes content-rise{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}@keyframes art-drift{from{transform:scale(1) translate3d(0,0,0)}to{transform:scale(1.04) translate3d(1%, -1%,0)}}@media(prefers-reduced-motion:reduce){.hero-inner,.hero:before,.section-heading,.card,.gallery-grid figure,.faq-grid details{animation:none!important}}.button:disabled{cursor:wait;opacity:.6;transform:none}.button.secondary{border-color:var(--line);background:transparent;color:var(--ink)}.hero{position:relative;isolation:isolate;display:grid;align-items:end;min-height:var(--hero-size);overflow:hidden;background:var(--dark);color:#fff}.hero.has-image{background-image:none}.hero-image{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-2}.hero.has-image:before{position:absolute;inset:0;background:var(--hero-overlay);content:'';z-index:-1}.hero:not(.has-image){background:linear-gradient(135deg,var(--dark),var(--accent-dark))}.hero:not(.has-image):before{position:absolute;inset:-20%;content:'';z-index:-1;opacity:.24;background:var(--art-texture),radial-gradient(circle at var(--art-offset) 28%,var(--accent) 0 2px,transparent 3px),linear-gradient(var(--art-angle),transparent 0 46%,rgba(255,255,255,.14) 46.2% 46.5%,transparent 46.7%);background-size:auto,34px 34px,100% 100%;transform:rotate(-4deg)}.hero:after{position:absolute;inset:auto 0 0;height:48%;background:linear-gradient(transparent,rgba(10,18,25,.42));content:''}.hero-inner{position:relative;z-index:1;padding:150px 0 90px}.hero h1,.section h2{font-weight:var(--heading-weight)}.hero-inner[data-align="center"]{margin-inline:auto;text-align:center}.hero-inner[data-align="center"] .hero-copy{margin-inline:auto}.hero-inner[data-align="center"] .hero-actions{justify-content:center}.eyebrow{margin:0 0 19px;color:var(--accent);font-size:12px;font-weight:750;letter-spacing:.14em;text-transform:uppercase}.hero h1{max-width:850px;margin:0;font-family:var(--serif);font-size:clamp(50px,8vw,96px);font-weight:400;letter-spacing:-.065em;line-height:.98;text-wrap:balance}.hero h1,.section h2{overflow-wrap:anywhere}.hero-copy{max-width:570px;margin:28px 0 31px;color:rgba(255,255,255,.78);font-size:18px;line-height:1.55}.hero-actions{display:flex;flex-wrap:wrap;gap:12px}.hero .button.secondary{border-color:rgba(255,255,255,.36);color:#fff}.trust-strip{border-bottom:1px solid var(--line);background:var(--surface)}.trust-strip .shell{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;padding:24px 0}.trust-item{display:flex;gap:10px;align-items:center;color:var(--muted);font-size:13px}.trust-item strong{color:var(--ink);font-size:20px;font-family:var(--serif);font-weight:400}.section{padding:var(--section-space) 0}.section-heading{display:grid;grid-template-columns:minmax(220px,.7fr) minmax(0,1.3fr);gap:50px;margin-bottom:45px}.section-kicker{margin:0 0 10px;color:var(--accent-dark);font-size:12px;font-weight:750;letter-spacing:.14em;text-transform:uppercase}.section h2{max-width:650px;margin:0;font-family:var(--serif);font-size:clamp(35px,5vw,59px);font-weight:400;letter-spacing:-.06em;line-height:1.02;text-wrap:balance}.section-lead{max-width:570px;margin:0;color:var(--muted);font-size:18px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.gallery-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.gallery-grid figure{margin:0;overflow:hidden;aspect-ratio:4/3;border-radius:var(--radius);background:var(--soft)}.gallery-grid img{width:100%;height:100%;aspect-ratio:4/3;object-fit:cover;transition:transform .25s ease}.gallery-grid figure:hover img{transform:scale(1.03)}.card{min-height:230px;padding:27px;border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);transition:transform .2s ease,box-shadow .2s ease}.card:hover{transform:translateY(-4px);box-shadow:0 16px 35px rgba(23,32,42,.09)}.card-number{color:var(--accent-dark);font-size:12px;font-weight:750}.card h3{margin:62px 0 10px;font-size:19px;letter-spacing:-.03em}.card p{margin:0;color:var(--muted);font-size:14px}.statement{background:var(--soft)}.statement-inner{display:grid;grid-template-columns:.75fr 1.25fr;gap:60px;align-items:start}.statement-copy{display:grid;gap:24px}.statement-copy .section-kicker{margin:0}.statement blockquote{margin:0;font-family:var(--serif);font-size:clamp(31px,4.2vw,56px);letter-spacing:-.055em;line-height:1.05}.steps{display:grid;gap:0}.step{display:grid;grid-template-columns:50px 1fr;gap:16px;padding:18px 0;border-top:1px solid var(--line)}.step strong{color:var(--accent-dark)}.step h3{margin:0 0 4px;font-size:16px}.step p{margin:0;color:var(--muted);font-size:14px}.faq-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.faq-grid details{padding:20px;border:1px solid var(--line);background:var(--surface)}.faq-grid summary{cursor:pointer;font-weight:700}.faq-grid summary::marker{color:var(--accent-dark)}.faq-grid details p{margin:12px 0 0;color:var(--muted);font-size:14px}.contact-section{background:var(--dark);color:#fff}.contact-grid{display:grid;grid-template-columns:.9fr 1.1fr;gap:70px}.contact-section .section-kicker{color:var(--accent)}.contact-section h2{color:#fff}.contact-section .section-lead{color:rgba(255,255,255,.64)}.contact-section a{color:var(--accent)}address{margin:18px 0;color:rgba(255,255,255,.72);font-style:normal}.contact-section .section-lead{max-width:520px}form{display:grid;gap:13px;padding:27px;border-radius:var(--radius);background:#fff;color:var(--ink);box-shadow:0 20px 60px rgba(0,0,0,.18)}form h3{margin:0 0 4px;font-family:var(--serif);font-size:28px;line-height:1.1;letter-spacing:-.04em}form label{font-size:12px;font-weight:700}.response-expectation{max-width:440px;margin:18px 0;color:rgba(255,255,255,.72);font-size:14px}input,textarea{width:100%;padding:13px 14px;border:1px solid var(--line);border-radius:2px;background:#fff;color:var(--ink);font:inherit}textarea{min-height:120px;resize:vertical}.consent-field{display:flex;gap:8px;align-items:flex-start;font-size:12px;font-weight:500}.consent-field input{width:auto;margin-top:3px}input:focus,textarea:focus{outline:3px solid rgba(201,168,106,.3);border-color:var(--accent-dark)}input:user-invalid,textarea:user-invalid{border-color:#a33838}input[aria-invalid="true"],textarea[aria-invalid="true"]{border-color:#a33838;box-shadow:0 0 0 2px rgba(163,56,56,.14)}.faq-grid summary:focus-visible,.mobile-menu summary:focus-visible{outline:3px solid var(--accent);outline-offset:4px}.faq-grid details[open]{box-shadow:0 8px 24px rgba(23,32,42,.07)}.honeypot{position:absolute;left:-10000px}.form-status{min-height:24px;margin:0;font-size:13px}.form-status[data-state=success]{color:#227447}.form-status[data-state=error]{color:#a33838}.pending-submission-notice{position:fixed;z-index:7;right:18px;bottom:18px;left:18px;display:grid;gap:4px;max-width:560px;margin:auto;padding:14px 16px;border:1px solid #c9a86a;border-radius:10px;background:#fff;color:#17202a;box-shadow:0 12px 30px rgba(0,0,0,.2);font-size:13px}.pending-submission-notice span{color:#66717c}.analytics-consent-banner{position:fixed;z-index:8;right:18px;bottom:18px;left:18px;display:flex;align-items:center;justify-content:space-between;gap:18px;max-width:760px;margin:auto;padding:16px 18px;border:1px solid rgba(255,255,255,.22);border-radius:12px;background:#17202a;color:#fff;box-shadow:0 14px 35px rgba(0,0,0,.28);font-size:13px}.analytics-consent-banner p{margin:0}.analytics-consent-banner div{display:flex;flex-wrap:wrap;gap:8px}.analytics-consent-banner button{min-height:40px;padding:8px 13px;border:1px solid var(--accent);border-radius:999px;background:var(--accent);color:#17130c;font-weight:700}.analytics-consent-banner button[data-analytics-consent="deny"]{border-color:rgba(255,255,255,.4);background:transparent;color:#fff}@media(max-width:620px){.analytics-consent-banner{align-items:stretch;flex-direction:column}.analytics-consent-banner div{width:100%}.analytics-consent-banner button{flex:1}}.site-footer{padding:28px 0;background:#111920;color:rgba(255,255,255,.56);font-size:12px}.footer-row{display:flex;align-items:center;justify-content:space-between;gap:20px}.footer-row a{color:#fff;text-decoration:none}.footer-language-switcher{margin-left:auto}.footer-language-switcher .language-switcher{padding-left:0}.footer-language-switcher .language-switcher-label{color:rgba(255,255,255,.62)}.footer-language-switcher .language-switcher select{border-color:rgba(255,255,255,.3);color:#fff}.mobile-menu{display:none}.mobile-action{display:none}@media(max-width:760px){.shell{width:min(100% - 36px,600px)}.header-tools{gap:10px}.header-language-switcher{display:none}.site-header{padding:18px 0}.nav-links{display:none}.mobile-menu{display:block;position:relative}.mobile-menu summary{list-style:none;cursor:pointer;padding:9px 13px;border:1px solid rgba(255,255,255,.35);border-radius:999px;font-size:12px}.mobile-menu summary::-webkit-details-marker{display:none}.mobile-menu nav{position:absolute;right:0;top:44px;display:grid;min-width:180px;gap:3px;padding:8px;border-radius:12px;background:var(--dark);box-shadow:0 14px 30px rgba(0,0,0,.25)}.mobile-menu nav a{padding:9px 10px;text-decoration:none}.hero{min-height:650px}.hero-inner{padding:145px 0 70px}.hero h1{font-size:clamp(48px,15vw,76px)}.hero-copy{font-size:16px}.hero-actions>*{flex:1 1 180px}.trust-strip .shell{grid-template-columns:1fr;gap:13px;padding:20px 0}.section{padding:72px 0}.section-heading,.statement-inner,.contact-grid{grid-template-columns:1fr;gap:22px}.cards,.gallery-grid,.faq-grid{grid-template-columns:1fr}.card{min-height:auto}.card h3{margin-top:38px}.footer-row{align-items:flex-start;flex-direction:column}.mobile-action{display:inline-flex;position:fixed;z-index:4;right:18px;bottom:18px;left:18px;min-height:52px;box-shadow:0 12px 28px rgba(0,0,0,.22)}body{padding-bottom:88px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}.button,.card{transition:none}}@media(prefers-contrast:more){.button,.nav-cta{border-color:currentColor}.card,.faq-grid details,input,textarea{border-color:currentColor}}:where(*, *::before, *::after){min-width:0;max-width:100%}body{overflow-x:hidden}h1,h2,h3,h4,p,a,button,label,summary,blockquote,figcaption{overflow-wrap:anywhere;word-break:normal}pre,code{max-width:100%;white-space:pre-wrap;overflow-wrap:anywhere}.shell,.hero-inner,.section-heading,.statement-inner,.contact-grid,.cards,.gallery-grid,.trust-strip .shell,.footer-row{min-width:0}.nav,.nav-links,.hero-actions,.social-links,.footer-row{flex-wrap:wrap}.nav-links{min-width:0}.nav-links a,.nav-cta,.button{max-width:100%;overflow-wrap:anywhere}.cards,.gallery-grid{grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr))}.section-heading,.statement-inner,.contact-grid{grid-template-columns:minmax(0,.7fr) minmax(0,1.3fr)}.contact-grid{grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr)}img,video,iframe,svg{max-width:100%;height:auto}input,textarea,select,button{min-width:0;max-width:100%}@media(max-width:760px){.shell{width:min(100% - 36px,600px);max-width:100%}.section-heading,.statement-inner,.contact-grid{grid-template-columns:minmax(0,1fr)}.hero-actions>*{min-width:0;max-width:100%}.mobile-menu nav{max-width:calc(100vw - 36px)}form{min-width:0}.gallery-grid,.cards{grid-template-columns:minmax(0,1fr)}}`;
    }

    function generatedScript(business) {
        const scriptString = (value) => JSON.stringify(String(value || ""))
            .replace(/<\//gi, "<\\/")
            .replace(/\\u2028/g, "\\\\u2028")
            .replace(/\\u2029/g, "\\\\u2029");
        return `(function(){
    var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var analytics = window.dataLayer = window.dataLayer || [];
    var tracked = new WeakSet();
    var analyticsEnabled = ${business.analyticsMode === "anonymous" ? "true" : "false"};
    var analyticsEndpoint = ${JSON.stringify(business.analyticsMode === "anonymous" && business.projectId ? "/api/analytics" : "")};
    var analyticsConsentKey = 'morrow-analytics-consent';
    var pendingSubmissionKey = 'morrow-pending-submissions';
    function notifyWorkspace(payload){
        try { if (window.parent && window.parent !== window) window.parent.postMessage({ type: 'omniscript:enquiry', payload: payload || {} }, '*'); } catch (_) {}
    }
    try { if (!localStorage.getItem('morrow-anonymous-id')) localStorage.setItem('morrow-anonymous-id','anon-'+Date.now()+'-'+Math.random().toString(36).slice(2,8)); } catch (_) {}
    document.addEventListener('submit', function(event){
        var form = event.target;
        if (!form || !form.querySelectorAll) return;
        var payload = { source: form.getAttribute('data-goal') || 'website' };
        form.querySelectorAll('input,textarea,select').forEach(function(field){
            var name = field.getAttribute('name');
            if (!name || field.type === 'hidden' || name === 'website') return;
            payload[name] = field.value;
        });
        notifyWorkspace(payload);
        if (window.parent && window.parent !== window) {
            event.preventDefault();
            event.stopImmediatePropagation();
            var previewStatus = form.querySelector('.form-status');
            if (previewStatus) { previewStatus.setAttribute('data-state', 'success'); previewStatus.textContent = ${scriptString(business.success)}; }
        }
    }, true);
    function savePendingSubmission(){
        try {
            var pending = JSON.parse(localStorage.getItem(pendingSubmissionKey) || '[]');
            if (!Array.isArray(pending)) pending = [];
            pending.unshift({savedAt: new Date().toISOString()});
            localStorage.setItem(pendingSubmissionKey, JSON.stringify(pending.slice(0, 5)));
            return true;
        } catch (_) { return false; }
    }
    function clearPendingSubmissions(){ try { localStorage.removeItem(pendingSubmissionKey); } catch (_) {} }
    function pendingSubmissionCount(){ try { var items=JSON.parse(localStorage.getItem(pendingSubmissionKey) || '[]'); return Array.isArray(items) ? items.length : 0; } catch (_) { return 0; } }
    function showPendingNotice(){
        var count = pendingSubmissionCount();
        if (!count) return;
        var notice = document.createElement('aside');
        notice.className = 'pending-submission-notice';
        notice.setAttribute('role', 'status');
        notice.innerHTML = '<strong>Unsent enquiry saved in this browser.</strong><span>Try submitting again when your connection is available. Do not use this browser storage as your only customer-record system.</span>';
        document.body.appendChild(notice);
    }
    function hasAnalyticsConsent(){ return analyticsEnabled && window.localStorage && window.localStorage.getItem(analyticsConsentKey) === 'granted'; }
    function track(eventName, details){
        if (!hasAnalyticsConsent()) return;
        var payload = {event: eventName, timestamp: new Date().toISOString()};
        Object.keys(details || {}).forEach(function(key){
            if (typeof details[key] === 'string' && details[key].length <= 120) payload[key] = details[key];
        });
        analytics.push(payload);
        window.dispatchEvent(new CustomEvent('site:conversion', {detail: payload}));
        if (analyticsEndpoint && hasAnalyticsConsent() && window.fetch) {
            var context = window.morrowProjectContext && window.morrowProjectContext.read ? window.morrowProjectContext.read() : null;
            fetch(analyticsEndpoint, {method:'POST', credentials:'same-origin', keepalive:true, headers:{'Content-Type':'application/json',Accept:'application/json'}, body:JSON.stringify({projectId:${JSON.stringify(business.projectId)},eventName:eventName,anonymousId:window.localStorage.getItem('morrow-anonymous-id') || ('anon-'+Date.now()),path:window.location.pathname,locale:document.documentElement.lang,consent:true,metadata:{source:context && context.projectId ? 'project' : 'site'}})}).catch(function(){});
        }
    }
    function notifyWorkspace(payload){
        try {
            if (window.parent && window.parent !== window) {
                window.parent.postMessage({ type: 'omniscript:enquiry', payload: payload || {} }, '*');
            }
        } catch (_) {}
    }
    showPendingNotice();
    document.querySelectorAll('form').forEach(function(form){
        form.addEventListener('submit', function(){
            var payload = { source: form.getAttribute('data-goal') || 'website' };
            form.querySelectorAll('input,textarea,select').forEach(function(field){
                var name = field.getAttribute('name');
                if (!name || field.type === 'hidden' || name === 'website') return;
                payload[name] = field.value;
            });
            notifyWorkspace(payload);
        });
    });
    if (analyticsEnabled) {
        var consentBanner = document.createElement('aside');
        consentBanner.className = 'analytics-consent-banner';
        consentBanner.setAttribute('aria-label', 'Analytics consent');
        consentBanner.innerHTML = '<p>Allow anonymous usage measurement to help improve this website?</p><div><button type="button" data-analytics-consent="grant">Allow analytics</button><button type="button" data-analytics-consent="deny">Essential only</button></div>';
        document.body.appendChild(consentBanner);
        consentBanner.querySelector('[data-analytics-consent="grant"]').addEventListener('click', function(){ try { localStorage.setItem(analyticsConsentKey, 'granted'); } catch (_) {} consentBanner.remove(); });
        consentBanner.querySelector('[data-analytics-consent="deny"]').addEventListener('click', function(){ try { localStorage.setItem(analyticsConsentKey, 'denied'); } catch (_) {} consentBanner.remove(); });
        try { if (localStorage.getItem(analyticsConsentKey)) consentBanner.remove(); } catch (_) {}
    }
    var translationDictionary = ${JSON.stringify(business.manualTranslations || {})};
    var translationState = {locale: document.documentElement.lang || ${JSON.stringify(business.locale)}};
    function applyVisitorTranslation(locale){
        var dictionary = translationDictionary[locale];
        var nodes = document.querySelectorAll('h1,h2,h3,h4,p,a,button,label,summary,span');
        nodes.forEach(function(node){
            if (node.closest('.language-switcher') || node.querySelector('input,select,textarea')) return;
            if (!node.dataset.translationSource) node.dataset.translationSource = node.textContent;
            var source = node.dataset.translationSource;
            node.textContent = dictionary && typeof dictionary === 'object' && Object.prototype.hasOwnProperty.call(dictionary, source) ? dictionary[source] : source;
        });
        var title = document.querySelector('title');
        if (title) {
            if (!title.dataset.translationSource) title.dataset.translationSource = title.textContent;
            var titleSource = title.dataset.translationSource;
            title.textContent = dictionary && typeof dictionary === 'object' && Object.prototype.hasOwnProperty.call(dictionary, titleSource) ? dictionary[titleSource] : titleSource;
        }
        document.documentElement.lang = locale;
        document.documentElement.dir = /^(ar|arc|fa|he|iw|ku|ps|ur)(?:-|$)/i.test(locale) ? 'rtl' : ${JSON.stringify(business.direction)};
        translationState.locale = locale;
    }
    document.querySelectorAll('[data-language-switcher]').forEach(function(select){
        select.addEventListener('change', function(){ applyVisitorTranslation(select.value); });
    });
    document.querySelectorAll('a.button, .nav-cta, .mobile-action').forEach(function(link){
        link.addEventListener('click', function(){
            track('cta_click', {label: link.textContent.trim(), href: link.getAttribute('href') || ''});
        });
    });
    document.querySelectorAll('a[href^="tel:"], a[href^="mailto:"]').forEach(function(link){
        link.addEventListener('click', function(){
            track(link.href.indexOf('tel:') === 0 ? 'phone_click' : 'email_click');
        });
    });
    document.querySelectorAll('a[target="_blank"]').forEach(function(link){
        link.addEventListener('click', function(){
            track('external_action', {href: link.getAttribute('href') || ''});
        });
    });
    document.querySelectorAll('details:not(.mobile-menu)').forEach(function(detail){
        detail.addEventListener('toggle', function(){
            if (detail.open && !tracked.has(detail)) {
                tracked.add(detail);
                track('faq_open', {question: detail.querySelector('summary')?.textContent.trim() || ''});
            }
        });
    });
    document.querySelectorAll('form[data-site-form]').forEach(function(form){
        form.addEventListener('focusin', function(){
            if (!form.dataset.trackedStart) {
                form.dataset.trackedStart = 'true';
                track('form_start', {goal: form.dataset.goal || ''});
            }
        });
    });
    document.querySelectorAll('a[href^="#"]').forEach(function(link){
        link.addEventListener('click',function(event){
            var selector = link.getAttribute('href');
            var target = selector && document.querySelector(selector);
            if (!target) return;
            event.preventDefault();
            target.scrollIntoView({behavior: reducedMotion ? 'auto' : 'smooth', block: 'start'});
            target.setAttribute('tabindex','-1');
            target.focus({preventScroll:true});
        });
    });
    document.querySelectorAll('details.mobile-menu').forEach(function(menu){
        var summary = menu.querySelector('summary');
        var syncExpanded = function(){
            if(summary) summary.setAttribute('aria-expanded', menu.open ? 'true' : 'false');
        };
        var closeMenu = function(){
            if(menu.open) menu.removeAttribute('open');
        };
        syncExpanded();
        menu.addEventListener('toggle', syncExpanded);
        menu.querySelectorAll('a').forEach(function(link){
            link.addEventListener('click', closeMenu);
        });
        document.addEventListener('keydown', function(event){
            if(event.key === 'Escape' && menu.open){
                closeMenu();
                if(summary) summary.focus();
            }
        });
        document.addEventListener('click', function(event){
            if(menu.open && !menu.contains(event.target)) closeMenu();
        });
    });
    document.querySelectorAll('form[action]').forEach(function(form){
        form.addEventListener('submit',async function(event){
            if (!window.fetch || !window.URLSearchParams || !window.FormData) return;
            event.preventDefault();
            if(!form.reportValidity() || form.dataset.submitting==='true') return;
            var trap=form.querySelector('input[name="website"]');
            if(trap && trap.value) return;
            form.dataset.submitting='true';
            form.setAttribute('aria-busy','true');
            var button=form.querySelector('button[type="submit"]'), status=form.querySelector('[role="status"]');
            if(button){button.disabled=true;button.setAttribute('aria-busy','true');}
            form.querySelectorAll('input,textarea,select').forEach(function(field){
                field.addEventListener('invalid',function(){field.setAttribute('aria-invalid','true');},{once:true});
                field.addEventListener('input',function(){field.removeAttribute('aria-invalid');},{once:true});
            });
            if(status){status.textContent='Sending…';status.dataset.state='';}
            var controller=window.AbortController?new AbortController():null;
            var timeout=controller?setTimeout(function(){controller.abort();},15000):null;
            try{
                var request={method:'POST',body:new URLSearchParams(new FormData(form)),headers:{Accept:'application/json','Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','X-Requested-With':'website-form','X-Submission-ID':window.crypto&&window.crypto.randomUUID?window.crypto.randomUUID():'submission-'+Date.now()}};
                var context=window.morrowProjectContext&&window.morrowProjectContext.read?window.morrowProjectContext.read():null;
                if(context&&context.projectId) request.body.set('projectId',context.projectId);
                var params=new URLSearchParams(window.location.search); if(params.get('utm_source')) request.body.set('source',params.get('utm_source')); if(params.get('utm_campaign')) request.body.set('campaign',params.get('utm_campaign'));
                if(controller) request.signal=controller.signal;
                var action = form.getAttribute('action') || '/api/submit-form';
                var parsedAction;
                try { parsedAction = new URL(action, window.location.origin); } catch (error) { throw new Error('The form has an invalid submission endpoint.'); }
                if (parsedAction.origin !== window.location.origin || !['http:', 'https:'].includes(parsedAction.protocol)) throw new Error('The form has an invalid submission endpoint.');
                request.credentials = 'same-origin';
                var response=await fetch(parsedAction.pathname + parsedAction.search,request);
                var result=await response.json().catch(function(){return{};});
                if(!response.ok || !result.success) throw new Error(result.error || ${scriptString(business.error)});
                if(status){status.textContent=result.message || ${scriptString(business.success)};status.dataset.state='success';}
                track('form_submit', {goal: form.dataset.goal || ''});
                form.reset();
                form.querySelectorAll('[aria-invalid="true"]').forEach(function(field){field.removeAttribute('aria-invalid');});
            }catch(error){
                var saved = savePendingSubmission();
                if(status){status.textContent=(error.name==='AbortError'?'The request took too long. ': '') + (saved ? 'Your details were saved in this browser. Please try again when the connection is available.' : ${scriptString(business.error)});status.dataset.state='error';}
            }finally{
                if(timeout) clearTimeout(timeout);
                form.dataset.submitting='false';
                form.removeAttribute('aria-busy');
                if(button){button.disabled=false;button.removeAttribute('aria-busy');}
                if(status) status.focus({preventScroll:true});
            }
        });
    });
})();`;
    }

    function applyManualTranslations(html, business, locale) {
        if (locale === business.locale) return html;
        const dictionary = business.manualTranslations?.[locale];
        if (!dictionary || typeof dictionary !== "object") return html;
        const entries = Object.entries(dictionary)
            .filter(([from, to]) => String(from).trim() && typeof to === "string" && to.trim())
            .sort((a, b) => b[0].length - a[0].length);
        if (!entries.length) return html;

        let translatedHtml = html.replace(/>([^<>]+)</g, (match, content) => {
            let translated = content;
            entries.forEach(([from, to]) => {
                translated = translated.split(from).join(to);
            });
            return `>${translated}<`;
        });

        const titleOpen = translatedHtml.indexOf("<title>");
        const titleClose = translatedHtml.indexOf("</title>", titleOpen + 7);
        if (titleOpen !== -1 && titleClose !== -1) {
            let title = translatedHtml.slice(titleOpen + 7, titleClose);
            entries.forEach(([from, to]) => { title = title.split(from).join(to); });
            translatedHtml = `${translatedHtml.slice(0, titleOpen + 7)}${title}${translatedHtml.slice(titleClose)}`;
        }
        return translatedHtml;
    }

    function directionForLocale(locale, configuredDirection = "ltr") {
        if (configuredDirection === "rtl") return "rtl";
        return /^(ar|arc|fa|he|iw|ku|ps|ur)(?:-|$)/i.test(String(locale || "")) ? "rtl" : "ltr";
    }

    function generatedHtml(business, locale = business.locale) {
        const text = copyFor(business);
        const content = contentFor(business, text);
        const services = [...new Set(business.services.split(",").map((item) => item.trim()).filter(Boolean))].slice(0, 6);
        const serviceCards = (services.length ? services : ["Start with a conversation"]).map((service, index) => {
            // Accept “Service — benefit” or “Service: benefit” so owners can add
            // useful specificity without needing a separate content editor.
            const parts = service.split(/\s+[—–:]\s+/, 2);
            const serviceName = parts[0].trim();
            const serviceDescription = parts[1]?.trim() || serviceDescriptionFor(business, serviceName, index);
            return `<article class="card"><span class="card-number" aria-hidden="true">${String(index + 1).padStart(2, "0")}</span><h3>${escapeHtml(serviceName)}</h3><p>${escapeHtml(serviceDescription)}</p></article>`;
        }).join("");
        const intelligence = business.designIntelligence || designIntelligenceFor(business);
        const imageClass = business.heroImage ? " has-image" : "";
        const artClass = ` art-${escapeHtml(intelligence.layout)} art-motif-${escapeHtml(intelligence.motif)}`;
        const localeList = [...new Set((business.supportedLocales || [business.locale]).map(normalizeLocaleTag).filter(Boolean))].slice(0, 24);
        if (!localeList.includes(business.locale)) localeList.unshift(business.locale);
        const localeAlternates = localeList.map((alternateLocale) => `<link rel="alternate" hreflang="${escapeHtml(alternateLocale)}" href="${escapeHtml(business.siteUrl ? `${business.siteUrl}${alternateLocale === business.locale ? "/" : `/${alternateLocale}/`}` : alternateLocale === business.locale ? "./index.html" : `./${alternateLocale}/index.html`)}">`).join("") + `<link rel="alternate" hreflang="x-default" href="${escapeHtml(business.siteUrl || "./index.html")}">`;
        const languageSwitcher = localeList.length > 1
            ? `<label class="language-switcher"><span class="language-switcher-label">Translate</span><select data-language-switcher aria-label="Translate this page">${localeList.map((languageLocale) => `<option value="${escapeHtml(languageLocale)}"${languageLocale === business.locale ? " selected" : ""}>${escapeHtml(languageLocale)}</option>`).join("")}</select></label>`
            : "";
        const heroAlt = business.heroDecorative ? "" : (business.heroAlt || `${business.name} ${business.services.split(",")[0] || "business"}`);
        const heroImageMarkup = business.heroImage
            ? `<img class="hero-image" src="${escapeHtml(business.heroImage)}" alt="${escapeHtml(heroAlt)}" width="1920" height="1080" fetchpriority="high" decoding="async">`
            : "";
        const brandMarkup = business.logo
            ? `<img class="brand-mark" src="${escapeHtml(business.logo)}" alt="${escapeHtml(business.logoAlt || business.name)}" width="44" height="44" decoding="async">`
            : "";
        const phoneLink = business.phone ? `<a href="tel:${escapeHtml(business.phone.replace(/[^+0-9]/g, ""))}">${escapeHtml(business.phone)}</a>` : `<a href="#contact">Start a conversation</a>`;
        const emailLink = business.email ? `<a href="mailto:${escapeHtml(business.email)}">${escapeHtml(business.email)}</a>` : "";
        const addressMarkup = business.address ? `<address>${escapeHtml(business.address)}${business.location ? `<br>${escapeHtml(business.location)}` : ""}</address>` : "";
        const consent = business.consent ? `<label class="consent-field"><input id="contact-consent" type="checkbox" name="consent" value="yes" required> <span>I agree to be contacted about my enquiry.</span></label>` : "";
        const proofItems = [
            business.credentials ? `<div class="trust-item"><strong>Credentials</strong><span>${escapeHtml(business.credentials)}</span></div>` : "",
            business.experience ? `<div class="trust-item"><strong>Experience</strong><span>${escapeHtml(business.experience)}</span></div>` : "",
            business.customers ? `<div class="trust-item"><strong>Customers</strong><span>${escapeHtml(business.customers)}</span></div>` : ""
        ].filter(Boolean);
        const proofStrip = proofItems.length
            ? `<section class="trust-strip proof-strip" aria-label="Why customers choose us"><div class="shell">${proofItems.join("")}</div></section>`
            : "";
        const trustSignals = [
            business.customers ? `<div class="trust-item"><strong>${escapeHtml(business.customers)}</strong><span>Customer result</span></div>` : "",
            business.experience ? `<div class="trust-item"><strong>${escapeHtml(business.experience)}</strong><span>Years serving customers</span></div>` : "",
            business.credentials ? `<div class="trust-item"><strong>Credentials</strong><span>${escapeHtml(business.credentials)}</span></div>` : ""
        ].filter(Boolean);
        const trustStripLabel = business.testimonial || business.credentials || business.experience || business.customers
            ? "Proof and experience"
            : "What to expect";
        const trustStrip = trustSignals.length
            ? `<section class="trust-strip" aria-label="${escapeHtml(trustStripLabel)}"><div class="shell">${trustSignals.join("")}</div></section>`
            : `<section class="trust-strip" aria-label="What to expect"><div class="shell"><div class="trust-item"><strong>01</strong><span>Start with a clear conversation</span></div><div class="trust-item"><strong>02</strong><span>Understand the next step before you commit</span></div><div class="trust-item"><strong>03</strong><span>Keep the focus on what you need</span></div></div></section>`;
        const testimonialAttribution = business.testimonialAuthor ? `<cite>— ${escapeHtml(business.testimonialAuthor)}</cite>` : "";
        const proofContent = business.testimonial
            ? `<section class="section testimonial-section" aria-label="Customer testimonial"><div class="shell"><p class="section-kicker">A note from a customer</p><blockquote>“${escapeHtml(business.testimonial)}”</blockquote>${testimonialAttribution}</div></section>`
            : "";
        const galleryContent = business.gallery.length
            ? `<section class="section gallery-section" aria-labelledby="gallery-title"><div class="shell"><div class="section-heading"><div><p class="section-kicker">A closer look</p><h2 id="gallery-title">See the details for yourself.</h2></div><p class="section-lead">A selection of our work, spaces, or products.</p></div><div class="gallery-grid">${business.gallery.map((url, index) => { const alt = business.galleryAlt[index] || `${business.name} image ${index + 1}`; return `<figure><img src="${escapeHtml(url)}" alt="${escapeHtml(alt)}" width="1200" height="900" loading="lazy" decoding="async"><figcaption class="sr-only">${escapeHtml(alt)}</figcaption></figure>`; }).join("")}</div></div></section>`
            : "";
        const availability = business.hours ? `<p class="availability"><strong>Availability</strong><br>${escapeHtml(business.hours)}</p>` : "";
        const pricing = business.pricing ? `<p class="availability"><strong>Pricing</strong><br>${escapeHtml(business.pricing)}</p>` : "";
        const bookingLink = business.booking ? `<a class="button secondary" href="${escapeHtml(business.booking)}" target="_blank" rel="noopener noreferrer">Book online<span class="sr-only"> (opens in a new tab)</span></a>` : "";
        const goalHref = business.primaryGoal === "booking" && business.booking ? business.booking : business.primaryGoal === "call" && business.phone ? `tel:${business.phone.replace(/[^+0-9]/g, "")}` : business.primaryGoal === "email" && business.email ? `mailto:${business.email}` : business.primaryGoal === "shop" ? "#services" : "#contact";
        const goalTarget = business.primaryGoal === "booking" && business.booking ? ` target="_blank" rel="noopener noreferrer"` : "";
        const goalCta = `<a class="button" href="${escapeHtml(goalHref)}"${goalTarget}>${escapeHtml(text.cta)}${goalTarget ? `<span class="sr-only"> (opens in a new tab)</span>` : ""}</a>`;
        const formHeading = {
            quote: "Tell us about your project",
            booking: "Request an appointment",
            call: "Request a call",
            email: "Send us an enquiry",
            shop: "Ask about a product"
        }[business.primaryGoal] || "Tell us how we can help";
        const formMessageLabel = {
            quote: "What would you like a quote for?",
            booking: "What would you like to book?",
            call: "What would you like to discuss?",
            email: "How can we help?",
            shop: "What are you looking for?"
        }[business.primaryGoal] || "How can we help?";
        const formSubmitLabel = {
            quote: "Request a quote",
            booking: "Request an appointment",
            call: "Request a call",
            email: "Send enquiry",
            shop: "Ask about a product"
        }[business.primaryGoal] || "Send enquiry";
        const phoneField = ["booking", "call"].includes(business.primaryGoal)
            ? `<label for="contact-phone">Phone number <span class="form-note">(optional)</span></label><input id="contact-phone" name="phone" type="tel" autocomplete="tel">`
            : "";
        const qualificationField = business.qualificationQuestion
            ? `<label for="contact-qualification">${escapeHtml(business.qualificationQuestion)}</label><input id="contact-qualification" name="qualification" autocomplete="off" maxlength="300">`
            : "";
        const responseExpectation = business.responseTime || ({
            quote: "Share a few details and we will review them before recommending the clearest next step.",
            booking: "We will confirm availability and help arrange a time that works for you.",
            call: "We will get back to arrange a convenient time for a conversation.",
            email: "We will read your enquiry and reply with a useful answer.",
            shop: "We will check what is available and help you find the right option."
        }[business.primaryGoal] || "We will review your message and get back to you shortly.");
        const proofLead = business.testimonial
            ? "See why customers choose us, then take the next step with confidence."
            : business.differentiator
                ? `A clearer choice for ${business.audience || "customers who value thoughtful service"}.`
                : "A straightforward experience, from the first conversation to the final detail.";
        const differentiator = business.differentiator ? ` ${escapeHtml(business.differentiator)}` : "";
        const schemaType = business.type === "restaurant" ? "Restaurant" : business.type === "retail" ? "Store" : business.type === "professional" ? "ProfessionalService" : "LocalBusiness";
        const limitText = (value, max) => {
            const clean = String(value || "").replace(/\s+/g, " ").trim();
            if (clean.length <= max) return clean;
            const shortened = clean.slice(0, max - 1).replace(/\s+\S*$/, "").trim();
            return `${shortened || clean.slice(0, max - 1)}…`;
        };
        const seoTitle = limitText(`${text.title} — ${business.name}`, 60);
        const seoDescription = limitText(text.intro, 155);
        const shareImage = business.heroImage || business.logo;
        const shareImageMeta = shareImage ? `<meta property="og:image" content="${escapeHtml(shareImage)}"><meta property="og:image:alt" content="${escapeHtml(business.logoAlt || business.name)}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="900">` : "";
        const robotsMeta = `<meta name="robots" content="index,follow"><meta name="referrer" content="strict-origin-when-cross-origin">`;
        const siteUrl = business.siteUrl;
        const normalizedSiteUrl = (() => {
            try {
                const parsed = new URL(siteUrl);
                if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.search || parsed.hash) return "";
                return `${parsed.origin}${parsed.pathname.replace(/\/$|\/index\.html?$/i, "")}`;
            } catch {
                return "";
            }
        })();
        const absolutePageUrl = normalizedSiteUrl
            ? `${normalizedSiteUrl}${locale === business.locale ? "/" : `/${locale}/`}`
            : "";
        const schema = {"@context":"https://schema.org","@type":schemaType,"name":business.name,"description":seoDescription,"areaServed":business.location,...(absolutePageUrl ? {url: absolutePageUrl} : {}),...(shareImage ? {image: shareImage} : {}),...(business.phone ? {telephone: business.phone} : {}),...(business.email ? {email: business.email} : {}),...(business.address ? {address: {"@type":"PostalAddress", streetAddress: business.address, addressLocality: business.location}} : {}),...(business.hours ? {openingHours: business.hours} : {})};
        const nav = `<nav class="nav-links" data-site-navigation aria-label="Primary navigation"><a href="#services">What we do</a><a href="#approach">Our approach</a><a href="#faq">Questions</a><a class="nav-cta" href="${escapeHtml(goalHref)}"${goalTarget}>${escapeHtml(text.cta)}</a></nav>`;
        const mobileNav = `<nav id="mobile-navigation" data-site-navigation aria-label="Mobile navigation">${languageSwitcher}<a href="#services">What we do</a><a href="#approach">Our approach</a><a href="#faq">Questions</a><a href="${escapeHtml(goalHref)}"${goalTarget}>${escapeHtml(text.cta)}${goalTarget ? `<span class="sr-only"> (opens in a new tab)</span>` : ""}</a></nav>`;
        const socialMarkup = `<meta name="twitter:card" content="${shareImage ? "summary_large_image" : "summary"}"><meta name="twitter:title" content="${escapeHtml(seoTitle)}"><meta name="twitter:description" content="${escapeHtml(seoDescription)}">${shareImage ? `<meta name="twitter:image" content="${escapeHtml(shareImage)}">` : ""}`;
        const claimMeta = business.contentPolicy?.generatedClaims?.length
            ? `<meta name="morrow-claims" content="${escapeHtml(business.contentPolicy.generatedClaims.map((claim) => `${claim.source}: ${claim.text}`).join(" | "))}">`
            : "";
        const footerLanguageSwitcher = languageSwitcher ? `<div class="footer-language-switcher">${languageSwitcher}</div>` : "";
        return `<!doctype html>\n<html lang="${escapeHtml(locale)}" dir="${escapeHtml(directionForLocale(locale, business.direction))}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">${localeAlternates}<meta name="description" content="${escapeHtml(seoDescription)}"><meta name="theme-color" content="${escapeHtml(business.color)}"><meta name="color-scheme" content="light"><meta name="format-detection" content="telephone=no">${claimMeta}${robotsMeta}<link rel="canonical" href="${escapeHtml(absolutePageUrl || "./index.html")}"><link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23${business.color.slice(1)}'/%3E%3Cpath d='M18 44 32 16l14 28h-8l-3-7H29l-3 7h-8Zm14-14-3 6h6l-3-6Z' fill='%2317130c'/%3E%3C/svg%3E"><meta property="og:type" content="website"><meta property="og:url" content="${escapeHtml(absolutePageUrl || "./index.html")}"><meta property="og:title" content="${escapeHtml(seoTitle)}"><meta property="og:description" content="${escapeHtml(seoDescription)}">${shareImageMeta}${socialMarkup}<title>${escapeHtml(seoTitle)}</title><link rel="stylesheet" href="./style.css"><script type="application/ld+json">${JSON.stringify(schema).replace(/<\/script/gi,"<\\/script")}</script></head><body><a class="skip-link" href="#main-content">Skip to content</a><header class="site-header"><div class="shell nav"><a class="brand" href="./index.html" aria-label="${escapeHtml(business.name)} home">${brandMarkup}<span>${escapeHtml(business.name)}</span></a><div class="header-tools">${nav}<details class="mobile-menu"><summary aria-controls="mobile-navigation" aria-label="Open navigation menu" aria-expanded="false">Menu</summary>${mobileNav}</details></div></div></header><main id="main-content"><section class="hero${imageClass}${artClass}" aria-labelledby="hero-title">${heroImageMarkup}<div class="shell hero-inner" data-align="${designFor(business.style).hero}"><p class="eyebrow">${escapeHtml(text.eyebrow)}</p><h1 id="hero-title">${escapeHtml(text.title)}</h1><p class="hero-copy">${escapeHtml(text.intro)}</p><div class="hero-actions">${goalCta}<a class="button secondary" href="#services">Explore our work</a>${bookingLink}</div></div></section>${trustStrip}${proofStrip}<section class="section" id="services"><div class="shell"><div class="section-heading"><div><p class="section-kicker">${escapeHtml(content.sectionKicker)}</p><h2>${escapeHtml(content.sectionTitle)}</h2></div><div><p class="section-lead">${escapeHtml(proofLead)} ${escapeHtml(content.sectionLead)}${differentiator}</p></div></div><div class="cards">${serviceCards}</div></div></section>${proofContent}${galleryContent}<section class="section statement" id="approach"><div class="shell statement-inner"><div class="statement-copy"><p class="section-kicker">${escapeHtml(text.eyebrow)}</p><blockquote>“${escapeHtml(content.sectionTitle)}”</blockquote></div><div class="steps">${content.steps.map(([number, title, description]) => `<div class="step"><strong>${number}</strong><div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(description)}</p></div></div>`).join("")}</div></div></section><section class="section" id="faq"><div class="shell"><div class="section-heading"><div><p class="section-kicker">Good to know</p><h2>A few useful answers.</h2></div><p class="section-lead">Still have a question? ${phoneLink}</p></div><div class="faq-grid">${content.faqs.map(([question, answer]) => `<details><summary>${escapeHtml(question)}</summary><p>${escapeHtml(answer)}</p></details>`).join("")}</div></div></section><section class="section contact-section" id="contact" aria-labelledby="contact-title"><div class="shell contact-grid"><div><p class="section-kicker">Let’s talk</p><h2 id="contact-title">${escapeHtml(text.question)}</h2><p class="section-lead">Tell us a little about what you need. We will get back to you with a clear recommendation.</p><p class="response-expectation">${escapeHtml(responseExpectation)}</p><p class="conversion-prompt">${escapeHtml(text.cta)}: ${business.primaryGoal === "call" && business.phone ? phoneLink : business.primaryGoal === "email" && business.email ? emailLink : business.primaryGoal === "booking" && business.booking ? bookingLink : "Tell us what you need and we will recommend the next step."}</p><p>${phoneLink}</p>${emailLink ? `<p>${emailLink}</p>` : ""}${addressMarkup}${availability}${pricing}</div><form data-site-form data-goal="${escapeHtml(business.primaryGoal)}" action="${escapeHtml(business.endpoint)}" method="post" accept-charset="UTF-8" autocomplete="on" aria-label="${escapeHtml(formHeading)}"><input type="hidden" name="projectId" value="${escapeHtml(business.projectId || "")}"><h3>${escapeHtml(formHeading)}</h3><label for="contact-name">Your name</label><input id="contact-name" name="name" autocomplete="name" maxlength="200" required aria-describedby="form-note"><label for="contact-email">Email address</label><input id="contact-email" name="email" type="email" autocomplete="email" maxlength="320" required aria-describedby="form-note">${phoneField}${qualificationField}<label for="contact-message">${escapeHtml(formMessageLabel)}</label><textarea id="contact-message" name="message" autocomplete="on" maxlength="2000" required aria-describedby="form-note"></textarea>${consent}<input class="honeypot" name="website" tabindex="-1" autocomplete="off" aria-hidden="true"><button class="button" type="submit">${escapeHtml(formSubmitLabel)}</button><p class="form-status" role="status" aria-live="polite" tabindex="-1"></p><p class="form-note" id="form-note">This form records an accepted submission; confirm real inbox or CRM delivery after deployment. Add and publish a privacy policy before launch.</p><p class="form-note">Required fields are marked by the browser.</p></form></div></section></main><a class="button mobile-action" href="${escapeHtml(goalHref)}"${goalTarget}>${escapeHtml(text.cta)}${goalTarget ? `<span class="sr-only"> (opens in a new tab)</span>` : ""}</a><footer class="site-footer"><div class="shell footer-row"><span>© ${new Date().getFullYear()} ${escapeHtml(business.name)}</span><span>${escapeHtml(business.location)} · ${phoneLink}</span>${footerLanguageSwitcher}${socialMarkup}</div></footer><script src="./script.js" defer></script></body></html>`;
    }

    function generatedNetlifyConfig(business) {
        return `[build]
  publish = "."
  functions = "netlify/functions"

[functions]
  node_bundler = "esbuild"

# Function routes must be evaluated before the SPA fallback.
[[redirects]]
  from = "/api/submit-form"
  to = "/.netlify/functions/submit-form"
  status = 200
  force = true

[[redirects]]
  from = "/api/submit-form/"
  to = "/.netlify/functions/submit-form"
  status = 200
  force = true

# Published projects use real static pages. Unknown paths must remain 404s.
[[headers]]
  for = "/api/*"
  [headers.values]
    Cache-Control = "no-store, max-age=0"
    X-Robots-Tag = "noindex, nofollow"

[[headers]]
  for = "/.netlify/functions/*"
  [headers.values]
    Cache-Control = "no-store, max-age=0"
    X-Robots-Tag = "noindex, nofollow"

[[headers]]
  for = "/*.html"
  [headers.values]
    Cache-Control = "public, max-age=300, stale-while-revalidate=86400"

[[headers]]
  for = "/*.css"
  [headers.values]
    Cache-Control = "public, max-age=86400, stale-while-revalidate=604800"

[[headers]]
  for = "/*.js"
  [headers.values]
    Cache-Control = "public, max-age=86400, stale-while-revalidate=604800"

[[headers]]
  for = "/assets/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"
`;
    }

    function generatedSubmitFunction() {
        return `"use strict";

const MAX_BODY_BYTES = 20000;
const rateBuckets = new Map();

function response(statusCode, payload, extraHeaders = {}) {
    const enforced = {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store, max-age=0",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
                    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
            "Cross-Origin-Resource-Policy": "same-origin",
            "X-Permitted-Cross-Domain-Policies": "none"
    };
    const additional = {};
    const protectedNames = new Set(Object.keys(enforced).map((name) => name.toLowerCase()));

    for (const [name, value] of Object.entries(extraHeaders || {})) {
        if (!protectedNames.has(String(name).toLowerCase())) additional[name] = value;
    }

    return {
        statusCode,
        isBase64Encoded: false,
        headers: { ...additional, ...enforced },
        body: JSON.stringify(payload)
    };
}

function header(event, name) {
    const target = String(name).toLowerCase();
    return Object.entries(event.headers || {}).find(([key]) => String(key).toLowerCase() === target)?.[1] || "";
}

function clientKey(event) {
    const value = String(
        event.requestContext?.identity?.sourceIp ||
        header(event, "x-nf-client-connection-ip") ||
        "anonymous"
    ).split(",")[0].trim();
    return value.slice(0, 100);
}

function limited(event) {
    const key = clientKey(event);
    const now = Date.now();
    const bucket = rateBuckets.get(key);
    if (!bucket || now - bucket.startedAt >= 300000) {
        rateBuckets.set(key, { startedAt: now, count: 1 });
        return null;
    }
    bucket.count += 1;
    if (bucket.count > 5) return response(429, { success: false, error: "Too many requests. Please try again later." }, { "Retry-After": "300" });
    return null;
}

function clean(value, max = 500) {
    return typeof value === "string" ? value.replace(/[\\u0000-\\u001F\\u007F]/g, "").replace(/\\s+/g, " ").trim().slice(0, max) : "";
}

function decodeBody(event) {
    const body = String(event.body || "");

    if (!event.isBase64Encoded) return body;
    if (!body || body.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(body)) {
        throw new Error("INVALID_BODY");
    }

    const decoded = Buffer.from(body, "base64");
    if (decoded.toString("base64").replace(/=+$/, "") !== body.replace(/=+$/, "")) {
        throw new Error("INVALID_BODY");
    }

    return new TextDecoder("utf-8", { fatal: true }).decode(decoded);
}

function isPrivateHost(hostname) {
    const value = String(hostname || "").toLowerCase().replace(/\\.$/, "");
    if (value === "localhost" || value.endsWith(".localhost") || value.endsWith(".local") || value.endsWith(".internal") || value === "metadata.google.internal" || value === "metadata.google.com") return true;

    const parts = value.split(".").map(Number);
    if (parts.length === 4 && parts.every(Number.isInteger)) {
        const [a, b] = parts;
        return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 0 || b === 168)) || (a === 198 && b >= 18 && b <= 19) || a >= 224;
    }

    return /^::1$|^::$|^f[cd]/i.test(value) || /^fe[89ab]/i.test(value) || /^ff/i.test(value) || /^::ffff:(?:10\\.|127\\.|192\\.168\\.)/i.test(value);
}

function getWebhook() {
    const raw = String(process.env.LEADS_WEBHOOK_URL || "").trim();
    const allowed = String(process.env.LEADS_WEBHOOK_HOSTS || "").split(",").map((host) => host.trim().toLowerCase().replace(/\\.$/, "")).filter(Boolean);
    if (!raw || !allowed.length) throw new Error("WEBHOOK_NOT_CONFIGURED");

    let webhook;
    try { webhook = new URL(raw); } catch { throw new Error("WEBHOOK_INVALID"); }

    const hostname = webhook.hostname.toLowerCase().replace(/\\.$/, "");
    if (webhook.protocol !== "https:" || webhook.username || webhook.password || webhook.port || isPrivateHost(hostname) || !allowed.includes(hostname)) throw new Error("WEBHOOK_NOT_ALLOWED");
    return webhook;
}

async function deliver(webhook, payload, submissionId) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);

    try {
        const result = await fetch(webhook, {
            method: "POST",
            headers: { Accept: "application/json", "Content-Type": "application/json", "Idempotency-Key": submissionId, "X-Submission-ID": submissionId },
            body: JSON.stringify(payload),
            signal: controller.signal
        });
        try { await result.body?.cancel(); } catch {}
        if (!result.ok) throw new Error("DELIVERY_FAILED");
    } finally {
        clearTimeout(timer);
    }
}

exports.handler = async function handler(event = {}) {
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST requests are supported." }, { Allow: "POST" });
    const origin = String(header(event, "origin") || "").trim();
    const configuredOrigin = String(process.env.PUBLIC_SITE_ORIGIN || "").trim();
    if (origin && configuredOrigin) {
        try {
            if (new URL(origin).origin !== new URL(configuredOrigin).origin) return response(403, { success: false, error: "Origin is not allowed." });
        } catch {
            return response(403, { success: false, error: "Origin is not allowed." });
        }
    }
    const blocked = limited(event);
    if (blocked) return blocked;

    let decoded;
    try {
        decoded = decodeBody(event);
    } catch {
        return response(400, { success: false, error: "The submission body is invalid." });
    }

    if (Buffer.byteLength(decoded, "utf8") > MAX_BODY_BYTES) return response(413, { success: false, error: "The submission is too large." });

    let fields;
    try {
        const type = String(header(event, "content-type")).toLowerCase();
        fields = type.includes("application/json") ? JSON.parse(decoded || "{}") : Object.fromEntries(new URLSearchParams(decoded));
        if (!fields || typeof fields !== "object" || Array.isArray(fields)) throw new Error("INVALID_BODY");
    } catch {
        return response(400, { success: false, error: "The submission body is invalid." });
    }

    const submission = {
        name: clean(fields.name, 200),
        email: clean(fields.email, 320),
        phone: clean(fields.phone, 80),
        message: clean(fields.message, 2000),
        qualification: clean(fields.qualification, 300),
        company: clean(fields.company, 200),
        website: clean(fields.website, 200)
    };
    if (submission.website) return response(200, { success: true, message: "Thanks. Your message was received." });
    if (!submission.name || !submission.email || !submission.message) return response(400, { success: false, error: "Please complete the required fields." });
    if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/i.test(submission.email)) return response(400, { success: false, error: "Please provide a valid email address." });

    let webhook;
    try {
        webhook = getWebhook();
    } catch (error) {
        if (error.message === "WEBHOOK_NOT_CONFIGURED") return response(503, { success: false, error: "Lead delivery is not configured." });
        return response(500, { success: false, error: "Lead delivery is not securely configured." });
    }

    try {
        const suppliedId = clean(header(event, "x-submission-id"), 128);
        const submissionId = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(suppliedId) ? suppliedId : "submission-" + Date.now();
        await deliver(webhook, { source: "website-contact-form", submissionId, ...submission, receivedAt: new Date().toISOString() }, submissionId);
        return response(200, { success: true, message: "Thanks. Your message was received.", submissionId });
    } catch (error) {
        console.error("Lead delivery failed:", error?.message || error);
        return response(error?.name === "AbortError" ? 504 : 502, { success: false, error: error?.name === "AbortError" ? "Lead delivery timed out. Please try again." : "The message could not be delivered. Please try again." });
    }
};`;
    }

    function generatedSitemap(business) {
        if (!business.siteUrl) {
            return `<?xml version="1.0" encoding="UTF-8"?>\n<!-- Add the final HTTPS published website URL in the workspace before publishing to generate absolute sitemap locations. -->\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>`;
        }
        const base = business.siteUrl.replace(/\/$/, "");
        return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${escapeHtml(`${base}/`)}</loc></url>\n</urlset>`;
    }

    function createProject() {
        const business = data();
        business.designIntelligence = designIntelligenceFor(business);
        const locales = [...new Set((business.supportedLocales || [business.locale]).filter(Boolean))].slice(0, 8);
        const files = {
            "index.html": applyManualTranslations(generatedHtml({ ...business, locale: business.locale }, business.locale), business, business.locale),
            "style.css": generatedCss(business),
            "script.js": generatedScript({ ...business, locale: business.locale }),
            "netlify.toml": generatedNetlifyConfig(business),
            "submit-form.js": generatedSubmitFunction(),
            "sitemap.xml": generatedSitemap(business),
            "netlify/functions/submit-form.js": generatedSubmitFunction(),
            "robots.txt": "User-agent: *\nAllow: /\n\n# Add your published domain here before launch:\n# Sitemap: https://your-domain.example/sitemap.xml"
        };
        locales.filter((locale) => locale !== business.locale).forEach((locale) => {
            const localizedBusiness = { ...business, locale };
            files[`${locale}/index.html`] = applyManualTranslations(generatedHtml(localizedBusiness, locale), business, locale);
        });
        return files;
    }

    function designAudit(business = data()) {
        const intelligence = designIntelligenceFor(business);
        return {
            industryPattern: intelligence.conversion,
            artDirection: { name: intelligence.name, layout: intelligence.layout, texture: intelligence.texture, motion: intelligence.motion, motif: intelligence.motif },
            scores: intelligence.scores,
            recommendations: intelligence.recommendations,
            imageNeeds: intelligence.missing,
            rationale: `This ${business.type || "local-service"} layout prioritizes ${intelligence.heroFocus} and ${intelligence.conversion} because that matches the primary customer action. Visual choices are seeded from this brief so the result remains original and consistent.`
        };
    }

    window.siteGenerator = { createProject, designAudit };

    // Generation is exposed as a pure API. The editor calls this directly so
    // preview, source editing, export, and deployment all use the same files.
    // No observer mutates generated files after compilation.
    document.addEventListener("DOMContentLoaded", () => {
        document.documentElement.dataset.generatorVersion = "3.0.0";
    });
})();
