"use strict";

(() => {
    const year = document.getElementById("home-footer-year");
    if (year) year.textContent = String(new Date().getFullYear());

    const languageSelect = document.getElementById("home-language-select");
    const translations = {
        es: { "Home": "Inicio", "Website maker": "Creador de sitios", "Ad studio": "Estudio de anuncios", "Mobile audit": "Auditoría móvil", "Leads": "Clientes", "To Do": "Tareas", "Translate": "Idioma", "Create a website": "Crear un sitio web", "Explore ad studio": "Explorar anuncios", "Open website maker →": "Abrir creador de sitios →", "Open ad studio →": "Abrir estudio de anuncios →", "Open leads calendar →": "Abrir calendario de clientes →" },
        fr: { "Home": "Accueil", "Website maker": "Créateur de site", "Ad studio": "Studio publicitaire", "Mobile audit": "Audit mobile", "Leads": "Prospects", "To Do": "Tâches", "Translate": "Langue", "Create a website": "Créer un site web", "Explore ad studio": "Explorer les annonces", "Open website maker →": "Ouvrir le créateur de site →", "Open ad studio →": "Ouvrir le studio publicitaire →", "Open leads calendar →": "Ouvrir le calendrier →" },
        de: { "Home": "Startseite", "Website maker": "Website-Ersteller", "Ad studio": "Anzeigenstudio", "Mobile audit": "Mobile Prüfung", "Leads": "Kontakte", "To Do": "Aufgaben", "Translate": "Sprache", "Create a website": "Website erstellen", "Explore ad studio": "Anzeigenstudio öffnen", "Open website maker →": "Website-Ersteller öffnen →", "Open ad studio →": "Anzeigenstudio öffnen →", "Open leads calendar →": "Kalender öffnen →" },
        pt: { "Home": "Início", "Website maker": "Criador de sites", "Ad studio": "Estúdio de anúncios", "Mobile audit": "Auditoria móvel", "Leads": "Leads", "To Do": "Tarefas", "Translate": "Idioma", "Create a website": "Criar um site", "Explore ad studio": "Explorar anúncios", "Open website maker →": "Abrir criador de sites →", "Open ad studio →": "Abrir estúdio de anúncios →", "Open leads calendar →": "Abrir calendário →" },
        ar: { "Home": "الرئيسية", "Website maker": "منشئ المواقع", "Ad studio": "استوديو الإعلانات", "Mobile audit": "تدقيق الهاتف", "Leads": "العملاء المحتملون", "To Do": "المهام", "Translate": "اللغة", "Create a website": "إنشاء موقع", "Explore ad studio": "استكشاف الإعلانات", "Open website maker →": "فتح منشئ المواقع →", "Open ad studio →": "فتح استوديو الإعلانات →", "Open leads calendar →": "فتح التقويم →" }
    };

    const translateHome = (language) => {
        document.documentElement.lang = language;
        document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
        document.querySelectorAll(".home-nav-links a, .home-button, .home-feature a").forEach((node) => {
            const key = node.dataset.translationKey || node.textContent.trim();
            node.dataset.translationKey = key;
            const translated = translations[language]?.[key];
            if (translated) {
                const textNode = [...node.childNodes].find((child) => child.nodeType === Node.TEXT_NODE);
                if (textNode) textNode.nodeValue = translated + (node.querySelector("span") ? " " : "");
            }
        });
        const languageLabel = document.querySelector(".home-language");
        if (languageLabel) languageLabel.firstChild.nodeValue = (translations[language]?.Translate || "Translate") + " ";
        try { localStorage.setItem("omniscript-language", language); } catch (_) {}
    };

    languageSelect?.addEventListener("change", () => {
        translateHome(languageSelect.value);
        languageSelect.blur();
    });
    try {
        const savedLanguage = localStorage.getItem("omniscript-language");
        if (savedLanguage && languageSelect) {
            languageSelect.value = savedLanguage;
            translateHome(savedLanguage);
        }
    } catch (_) {}
})();
