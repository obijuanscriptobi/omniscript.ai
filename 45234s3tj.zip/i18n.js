"use strict";

// Small, dependency-free localization layer. Pages can opt into translation by
// adding data-i18n="key"; unknown keys remain in the source language.
(() => {
    const STORAGE_KEY = "omniscript-language";
    const dictionaries = {
        en: { language: "Language", home: "Home", websiteMaker: "Website maker", adStudio: "Ad studio", audit: "Mobile audit", leads: "Leads", todo: "To Do", profile: "Profile", settings: "Settings", save: "Save", cancel: "Cancel", continue: "Continue", loading: "Loading…", unavailable: "Translation unavailable" },
        es: { language: "Idioma", home: "Inicio", websiteMaker: "Creador de sitios", adStudio: "Estudio de anuncios", audit: "Auditoría móvil", leads: "Clientes potenciales", todo: "Tareas", profile: "Perfil", settings: "Configuración", save: "Guardar", cancel: "Cancelar", continue: "Continuar", loading: "Cargando…", unavailable: "Traducción no disponible" },
        fr: { language: "Langue", home: "Accueil", websiteMaker: "Créateur de site", adStudio: "Studio publicitaire", audit: "Audit mobile", leads: "Prospects", todo: "Tâches", profile: "Profil", settings: "Paramètres", save: "Enregistrer", cancel: "Annuler", continue: "Continuer", loading: "Chargement…", unavailable: "Traduction indisponible" },
        de: { language: "Sprache", home: "Startseite", websiteMaker: "Website-Ersteller", adStudio: "Anzeigenstudio", audit: "Mobile Prüfung", leads: "Kontakte", todo: "Aufgaben", profile: "Profil", settings: "Einstellungen", save: "Speichern", cancel: "Abbrechen", continue: "Weiter", loading: "Wird geladen…", unavailable: "Übersetzung nicht verfügbar" },
        pt: { language: "Idioma", home: "Início", websiteMaker: "Criador de sites", adStudio: "Estúdio de anúncios", audit: "Auditoria móvel", leads: "Leads", todo: "Tarefas", profile: "Perfil", settings: "Configurações", save: "Salvar", cancel: "Cancelar", continue: "Continuar", loading: "Carregando…", unavailable: "Tradução indisponível" },
        ar: { language: "اللغة", home: "الرئيسية", websiteMaker: "منشئ المواقع", adStudio: "استوديو الإعلانات", audit: "تدقيق الهاتف", leads: "العملاء المحتملون", todo: "المهام", profile: "الملف الشخصي", settings: "الإعدادات", save: "حفظ", cancel: "إلغاء", continue: "متابعة", loading: "جار التحميل…", unavailable: "الترجمة غير متاحة" }
    };
    const supported = Object.freeze(Object.keys(dictionaries));
    const get = (language) => dictionaries[supported.includes(language) ? language : "en"];
    const savedLanguage = () => {
        try { return localStorage.getItem(STORAGE_KEY) || "en"; } catch (_) { return "en"; }
    };
    const apply = (language = savedLanguage()) => {
        const active = supported.includes(language) ? language : "en";
        document.documentElement.lang = active;
        document.documentElement.dir = active === "ar" ? "rtl" : "ltr";
        document.documentElement.dataset.language = active;
        document.querySelectorAll("[data-i18n]").forEach((node) => {
            const translated = get(active)[node.dataset.i18n];
            if (translated) node.textContent = translated;
            else node.title = get(active).unavailable;
        });
        document.querySelectorAll("select[data-language-select]").forEach((select) => { select.value = active; });
        try { localStorage.setItem(STORAGE_KEY, active); } catch (_) {}
        window.dispatchEvent(new CustomEvent("omniscript:language-changed", { detail: { language: active } }));
        return active;
    };
    const bind = () => {
        document.querySelectorAll("select[data-language-select]").forEach((select) => select.addEventListener("change", () => apply(select.value)));
        apply();
    };
    window.omniscriptI18n = Object.freeze({ apply, get, supported });
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
