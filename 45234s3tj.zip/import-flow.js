"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    let lastAction = "import";
    let statusTimer = null;
    let operationStarted = false;
    let initialHtml = "";

    function setImportStatus(title, message, state = "working", options = {}) {
        const panel = get("import-status-panel");
        const titleNode = get("import-status-title");
        const messageNode = get("import-status-message");
        const retry = get("retry-import-btn");
        const useUrl = get("use-url-import-btn");

        if (!panel || !titleNode || !messageNode) return;
        panel.hidden = false;
        panel.dataset.state = state;
        titleNode.textContent = title;
        messageNode.textContent = message;
        if (retry) retry.hidden = !options.retry;
        if (useUrl) useUrl.hidden = !options.useUrl;
    }

    function normalizedUrl(value) {
        const raw = String(value || "").trim();
        if (!raw || raw.length > 2048 || /^\/\//.test(raw)) return "";
        const candidate = /^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
        try {
            const url = new URL(candidate);
            if (!["http:", "https:"].includes(url.protocol) || !url.hostname || url.username || url.password || url.hash) return "";
            return url.href;
        } catch {
            return "";
        }
    }

    function cleanReason(value) {
        let text = String(value || "")
            .replace(/Standing by for execution parameters compilation\.*/is, "")
            .replace(/\s+/g, " ")
            .trim();

        // Debugger output can contain a whole execution trace. Show the useful
        // reason, not the trace, and never allow it to overwhelm the status card.
        const markers = ["SCRAPINGBEE_NOT_CONFIGURED", "BRAVE_SEARCH", "HTTP ", "failed", "error", "unable", "timed out", "quota", "API key"];
        const markerIndex = markers
            .map((marker) => text.toLowerCase().indexOf(marker.toLowerCase()))
            .filter((index) => index >= 0)
            .sort((a, b) => a - b)[0];
        if (markerIndex > 0 && text.length > 260) text = text.slice(markerIndex);
        return text.slice(0, 420) || "The service did not provide a reason.";
    }

    function begin(action) {
        lastAction = action;
        operationStarted = true;
        // Generation timing must not be reused as import timing evidence.
        if (action === "import" || action === "discover") window.workspaceBenchmarkTiming = null;
        const url = normalizedUrl(get("input-scrape-url")?.value);
        const mode = get("import-mode-selector")?.value === "faithful" ? "faithful" : "conversion";
        if (action === "import" && !url) {
            setImportStatus("Enter a website URL", "Use a public address such as company.info or https://company.example.", "error", { retry: false });
            get("input-scrape-url")?.focus();
            return;
        }
        if (url && get("input-scrape-url")) get("input-scrape-url").value = url;
        setImportStatus(
            action === "discover" ? "Searching for a website…" : "Importing website…",
            action === "discover"
                ? "We are searching for a likely official website. The best public result will be imported if one is found."
                : mode === "faithful"
                    ? "We are preserving the original structure where possible, then reporting unsupported scripts, forms, and assets for review."
                    : "We are rebuilding the page around a clearer conversion path, responsive structure, and safer editable content." ,
            "working"
        );
        clearTimeout(statusTimer);
        statusTimer = setTimeout(() => {
            const button = get(action === "discover" ? "discover-btn" : "scrape-btn");
            if (button && !button.disabled) return;
            setImportStatus(
                "Still working…",
                "The request is taking longer than expected. The site may be slow, protected, or the provider may be at its quota.",
                "working"
            );
        }, 12000);
    }

    function handleFailure(message) {
        clearTimeout(statusTimer);
        const text = cleanReason(message);
        const lower = text.toLowerCase();
        let guidance = "Check the details and try again.";
        if (/not configured|api key|provider configuration/.test(lower)) {
            guidance = "An administrator must configure the search or scraping provider key in the deployed environment.";
        } else if (/rate limit|quota|credits|429/.test(lower)) {
            guidance = "The provider limit was reached. Wait a moment or use Import website with a known URL.";
        } else if (/401|403|blocked|authentication|protected/.test(lower)) {
            guidance = "The site blocks automated access. Try a public landing page or import a different URL.";
        } else if (/timed out|timeout/.test(lower)) {
            guidance = "The provider took too long to respond. Try again or use a simpler public page.";
        } else if (/valid public|invalid url|http 400/.test(lower)) {
            guidance = "Enter a complete public website address, such as https://example.com.";
        }
        setImportStatus("Import failed — here’s why", `${text} ${guidance}`, "error", { retry: true });
    }

    function buildImportDifferenceReport(files = {}) {
        const entries = Object.entries(files || {});
        const html = entries.filter(([name]) => /\.html?$/i.test(name)).map(([, content]) => String(content || "")).join("\n");
        const links = [...html.matchAll(/<a\b[^>]*href=["']([^"']+)["']/gi)].map((match) => match[1]).filter(Boolean);
        const images = [...html.matchAll(/<img\b[^>]*>/gi)].length;
        const scripts = [...html.matchAll(/<script\b[^>]*>/gi)].length;
        const forms = [...html.matchAll(/<form\b[^>]*>/gi)].length;
        const bookingLinks = links.filter((link) => /book|reserv|appoint|schedule|calendly|cal\.com/i.test(link)).length;
        const items = [
            { state: entries.some(([name]) => /\.html?$/i.test(name)) ? "preserved" : "review", message: `${entries.filter(([name]) => /\.html?$/i.test(name)).length} generated HTML page(s) are ready to review.` },
            { state: "preserved", message: `${links.length} navigation or action link(s), ${images} public image reference(s), and ${scripts} script reference(s) were detected.` },
            { state: forms ? "review" : "preserved", message: forms ? `${forms} form(s) were found; confirm the new same-origin endpoint and a real production delivery test.` : "No public forms were found in the imported page." },
            { state: bookingLinks ? "preserved" : "review", message: bookingLinks ? `${bookingLinks} booking or appointment link(s) were detected for review.` : "No obvious booking link was detected; add one if the business takes appointments." },
            { state: /<iframe\\b|<object\\b|<embed\\b|<video\\b/i.test(html) ? "review" : "preserved", message: /<iframe\\b|<object\\b|<embed\\b|<video\\b/i.test(html) ? "Embedded widgets or media need manual verification in the rebuilt site." : "No embedded widget or media element was detected." },
            { state: "review", message: "Private server code, CMS administration, databases, credentials, and external account settings are not imported." }
        ];
        return { preserved: items.filter((item) => item.state === "preserved").length, review: items.filter((item) => item.state !== "preserved").length, items };
    }

    function renderImportAnalysis(report) {
        const summary = get("import-analysis-summary");
        const list = get("import-analysis-list");
        if (!summary || !list || !report) return;
        summary.hidden = false;
        list.replaceChildren(...report.items.map((item) => {
            const li = document.createElement("li");
            li.dataset.state = item.state;
            li.textContent = `${item.state === "preserved" ? "Ready" : "Review"} — ${item.message}`;
            return li;
        }));
    }

    function renderImportPackage(metadata = {}) {
        const panel = get("import-analysis-summary");
        if (!panel || !metadata || typeof metadata !== "object") return;
        const existing = panel.querySelector("[data-import-package]");
        if (existing) existing.remove();
        const note = document.createElement("p");
        note.dataset.importPackage = "true";
        note.className = "field-descriptor-text";
        const pages = Number(metadata.pageCount || 0);
        const assets = Number(metadata.assetCount || 0);
        note.textContent = `Import package: ${pages} public page${pages === 1 ? "" : "s"}, ${assets} asset reference${assets === 1 ? "" : "s"}, ${Number(metadata.totalBytes || 0).toLocaleString()} collected bytes.`;
        panel.prepend(note);
    }

    function handleSuccess() {
        clearTimeout(statusTimer);
        operationStarted = false;
        const current = window.workspaceAPI?.getState?.() || {};
        const files = current.files || {};
        const sanitizedFiles = window.workspaceContentSafety?.sanitizeImportedFiles?.(files) || files;
        const safetyIssues = window.workspaceContentSafety?.validateFiles?.(sanitizedFiles, { imported: true }) || [];
        if (safetyIssues.length) {
            handleFailure(`Imported content was blocked for safety: ${safetyIssues[0].message}`);
            window.dispatchEvent(new CustomEvent("workspace:import-rejected", { detail: { issues: safetyIssues } }));
            return;
        }
        if (JSON.stringify(files) !== JSON.stringify(sanitizedFiles)) {
            try { window.workspaceAPI?.applySnapshot?.({ ...current, files: sanitizedFiles }, { dirty: true }); } catch (error) { handleFailure(error.message); return; }
        }
        const importMetadata = window.workspaceAPI?.getState?.()?.importMetadata || null;
        renderImportPackage(importMetadata);
        const report = buildImportDifferenceReport(files);
        renderImportAnalysis(report);
        window.dispatchEvent(new CustomEvent("workspace:import-report", { detail: report }));
        setImportStatus(
            "Website imported successfully",
            "Your current project was left intact while this import was prepared. Review the preview and generated files, then run a quality check before choosing what to keep.",
            "success"
        );
    }

    function clearImportContext() {
        clearTimeout(statusTimer);
        statusTimer = null;
        operationStarted = false;
        initialHtml = "";
    }

    function wire() {
        const scrape = get("scrape-btn");
        const discover = get("discover-btn");
        const retry = get("retry-import-btn");
        const useUrl = get("use-url-import-btn");
        const htmlOutput = get("outputContainerHtml");
        const statusVector = get("status-vector");
        initialHtml = htmlOutput?.textContent?.trim() || "";
        const debuggerOutput = get("aiDebuggerFeedback");

        window.addEventListener("workspace:project-context-cleared", clearImportContext);
        window.addEventListener("workspace:project-context-changed", clearImportContext);

        scrape?.addEventListener("click", () => begin("import"), true);
        discover?.addEventListener("click", () => begin("discover"), true);
        retry?.addEventListener("click", () => {
            const button = lastAction === "discover" ? discover : scrape;
            button?.click();
        });
        useUrl?.addEventListener("click", () => scrape?.click());

        const successObserver = new MutationObserver(() => {
            const contents = htmlOutput?.textContent?.trim() || "";
            const status = statusVector?.textContent || "";
            if (operationStarted && contents && contents !== initialHtml && !contents.startsWith("<!-- Awaiting") && !/error|failed|unable/i.test(status)) {
                handleSuccess();
            }
        });
        if (htmlOutput) successObserver.observe(htmlOutput, { childList: true, characterData: true, subtree: true });

        const errorObserver = new MutationObserver(() => {
            if (!operationStarted) return;
            const status = statusVector?.textContent || "";
            const detail = debuggerOutput?.textContent || "";
            const message = /error|failed|unable|invalid|rejected|timed out|not configured|restricted|unavailable|quota|api key|HTTP \d+/i.test(detail)
                ? detail
                : status;
            if (/failed|error|unable|could not|invalid|rejected|timed out|not configured|restricted|unavailable|quota|api key|HTTP \d+/i.test(message)) {
                handleFailure(message);
            }
        });
        if (statusVector) errorObserver.observe(statusVector, { childList: true, characterData: true, subtree: true });
        if (debuggerOutput) errorObserver.observe(debuggerOutput, { childList: true, characterData: true, subtree: true });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", wire, { once: true });
    else wire();
})();
