"use strict";

(() => {
    const params = new URLSearchParams(location.search);
    const token = params.get("token");
    const projectId = params.get("projectId");
    if (token || projectId) history.replaceState(null, "", `${location.pathname}${location.hash}`);
    const summary = document.getElementById("summary");
    const message = document.getElementById("message");
    const button = document.getElementById("accept");

    if (!token || !projectId) {
        summary.textContent = "This project invitation link is incomplete.";
        return;
    }

    summary.textContent = "Sign in with the invited account to accept this project invitation.";
    button.hidden = false;
    const idempotencyKey = crypto.randomUUID();
    button.addEventListener("click", async () => {
        button.disabled = true;
        try {
            const response = await fetch(`/api/project-memberships?projectId=${encodeURIComponent(projectId)}&action=accept`, {
                method: "POST",
                headers: { Accept: "application/json", "Content-Type": "application/json", "Idempotency-Key": idempotencyKey },
                body: JSON.stringify({ token })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Could not accept invitation.");
            message.textContent = "Invitation accepted. You can return to the workspace.";
            button.remove();
        } catch (error) {
            message.textContent = error.message || "Could not accept invitation.";
            button.disabled = false;
        }
    });
})();
