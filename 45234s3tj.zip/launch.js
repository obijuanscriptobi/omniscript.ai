"use strict";

(() => {
    const WORKSPACE_KEY = "luxury-engine-workspace";
    const SERVICE_KEY = "morrow-launch-service-v1";
    const get = (id) => document.getElementById(id);

    function readWorkspace() {
        try { return JSON.parse(localStorage.getItem(WORKSPACE_KEY) || "null") || {}; } catch { return {}; }
    }

    function readService() {
        try { return JSON.parse(localStorage.getItem(SERVICE_KEY) || "null") || {}; } catch { return {}; }
    }

    function saveService() {
        const service = {
            package: get("service-package")?.value || "handoff",
            maintenance: get("maintenance-plan")?.value || "none",
            owner: get("account-owner")?.value.trim() || "",
            domainProvider: get("domain-provider")?.value.trim() || "",
            formProvider: get("form-provider")?.value.trim() || "",
            notes: get("launch-notes")?.value.trim() || "",
            updatedAt: new Date().toISOString()
        };
        try { localStorage.setItem(SERVICE_KEY, JSON.stringify(service)); } catch {}
        render();
        const status = get("save-status");
        if (status) status.textContent = "Launch plan saved in this browser.";
    }

    function loadService() {
        const service = readService();
        ["service-package", "maintenance-plan", "account-owner", "domain-provider", "form-provider", "launch-notes"].forEach((id) => {
            const field = get(id);
            const key = id === "service-package" ? "package" : id === "maintenance-plan" ? "maintenance" : id.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
            if (field && service[key] !== undefined) field.value = service[key];
        });
    }

    function currentEvidence() {
        const workspace = readWorkspace();
        const files = workspace.files || {};
        const pages = Object.keys(files).filter((name) => /\.html$/i.test(name) && String(files[name]).trim());
        const html = String(files["index.html"] || "");
        const deployment = Array.isArray(workspace.deploymentHistory) ? workspace.deploymentHistory[0] : null;
        const verification = deployment?.verification || {};
        const url = String(workspace.publishedSiteUrl || "");
        const formConfigured = Boolean(files["netlify/functions/submit-form.js"]?.trim()) && /<form\b/i.test(html);
        const realDelivery = get("real-delivery")?.checked || false;
        const service = readService();
        const httpsUrl = /^https:\/\//i.test(url);
        const deployed = Boolean(deployment);
        const verified = Boolean(verification.success) && httpsUrl;
        const formTested = Boolean(workspace.formTestRevision);
        const managedConfigured = service.package === "managed" && Boolean(service.owner && service.domainProvider && service.formProvider);
        const liveVerified = verified && formTested && realDelivery;
        let status = !pages.length ? "preview" : liveVerified ? "verified" : managedConfigured && deployed ? "managed" : "handoff";
        return { workspace, pages, html, deployment, verification, url, formConfigured, realDelivery, httpsUrl, deployed, verified, formTested, managedConfigured, liveVerified, status };
    }

    function render() {
        const evidence = currentEvidence();
        const labels = { preview: "Preview only", handoff: "Ready for handoff", managed: "Managed launch", verified: "Verified live" };
        const descriptions = {
            preview: "Build or import the website first. Forms in this state are previews and do not promise delivery.",
            handoff: "Your files can be exported for customer-owned hosting. Connect hosting and a form destination before going live.",
            managed: "Deployment evidence exists and managed setup is recorded. Finish verification and confirm a real enquiry arrived.",
            verified: "HTTPS publishing, current verification, form testing, and real delivery confirmation are all recorded."
        };
        const status = get("launch-status");
        if (status) { status.textContent = labels[evidence.status]; status.dataset.state = evidence.status === "verified" ? "pass" : evidence.status === "preview" ? "warn" : "working"; }
        if (get("launch-description")) get("launch-description").textContent = descriptions[evidence.status];
        const details = {
            "evidence-pages": [evidence.pages.length > 0, evidence.pages.length ? `${evidence.pages.length} HTML page${evidence.pages.length === 1 ? "" : "s"} ready` : "Create or import a website"],
            "evidence-export": [evidence.pages.length > 0, evidence.pages.length ? "Website files can be exported" : "Export is unavailable until a site exists"],
            "evidence-domain": [evidence.httpsUrl, evidence.httpsUrl ? "Final HTTPS URL is configured" : "Add the customer’s final HTTPS domain"],
            "evidence-deployment": [evidence.deployed, evidence.deployed ? "A deployment is recorded" : "Deploy the website or hand off the files"],
            "evidence-verification": [evidence.verified, evidence.verified ? "Published pages and assets were verified" : "Run published-site verification"],
            "evidence-form": [evidence.formConfigured, evidence.formConfigured ? "Form route is present for technical testing" : "Connect a form provider or replace the form with a direct CTA"],
            "evidence-test": [evidence.formTested, evidence.formTested ? "Technical form test matches a project revision" : "Run the technical form test after deployment"],
            "evidence-real": [evidence.realDelivery, evidence.realDelivery ? "Real enquiry receipt was confirmed" : "Confirm receipt in the inbox or CRM; HTTP success is not enough"],
            "evidence-owner": [Boolean(readService().owner), readService().owner ? "Customer ownership is recorded" : "Record who owns the domain and provider accounts"]
        };
        Object.entries(details).forEach(([id, [passed, text]]) => { const item = get(id); if (!item) return; item.textContent = `${passed ? "PASS" : "TODO"} — ${text}`; item.dataset.state = passed ? "pass" : "warn"; });
        const managedHint = get("managed-hint");
        if (managedHint) managedHint.textContent = evidence.managedConfigured ? "Managed setup details are complete." : "Managed launch requires an owner, domain provider, and form/CRM provider.";
    }

    function bind() {
        loadService();
        ["service-package", "maintenance-plan", "account-owner", "domain-provider", "form-provider", "launch-notes"].forEach((id) => get(id)?.addEventListener("input", saveService));
        get("real-delivery")?.addEventListener("change", render);
        get("refresh-launch-btn")?.addEventListener("click", render);
        window.addEventListener("storage", (event) => { if ([WORKSPACE_KEY, SERVICE_KEY].includes(event.key)) render(); });
        render();
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
