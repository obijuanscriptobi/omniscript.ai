"use strict";
(() => {
    const BASE_KEY = "morrow-appointments-v1";
    const KEY = window.workspaceContext?.storageKey?.(BASE_KEY) || BASE_KEY;
    const $ = (id) => document.getElementById(id);
    let appointments = loadAppointments();
    let workflowAppointmentId = "";
    let view = "month";
    let cloudBusy = false;
    const cloudProject = () => window.supabaseWorkspace?.getState?.()?.projectId || "";
    const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    function cloudEnabled() {
        const state = window.supabaseWorkspace?.getState?.() || {};
        return Boolean(state.authenticated && cloudProject());
    }

    function setCloudStatus(message, error = false) {
        const status = $("leads-cloud-status");
        if (status) {
            status.textContent = message;
            status.style.color = error ? "#f87171" : "";
        }
    }

    function mapAppointment(item) {
        return window.appointmentIntelligence?.normalize({
            id: item.id,
            cloudId: item.id,
            clientName: item.client_name || "",
            clientBusiness: item.client_business || "",
            clientEmail: item.client_email || "",
            phone: item.client_phone || "",
            service: item.service || "",
            notes: item.notes || "",
            followUpAt: item.follow_up_at || "",
            status: item.status || "scheduled",
            meetingAt: item.meeting_at || "",
            leadId: item.lead_id || "",
            context: item.appointment_context || "work",
            type: item.appointment_type || "discovery",
            objective: item.objective || "",
            durationMinutes: item.duration_minutes || 45,
            mode: item.meeting_mode || "video",
            timezone: item.timezone || "",
            preparation: item.preparation || {},
            outcome: item.outcome || "",
            outcomeNotes: item.outcome_notes || "",
            nextAction: item.next_action || "",
            nextActionAt: item.next_action_at || "",
            rescheduleHistory: item.reschedule_history || [],
            reminderPlan: item.reminder_plan || {},
            timeline: item.timeline || []
        }) || item;
    }

    function cloudPayload(appointment) {
        return {
            clientName: appointment.clientName,
            clientBusiness: appointment.clientBusiness,
            clientEmail: appointment.clientEmail,
            clientPhone: appointment.phone,
            leadId: UUID.test(String(appointment.cloudLeadId || "")) ? appointment.cloudLeadId : null,
            appointmentContext: appointment.context || "work",
            service: appointment.service,
            notes: appointment.notes,
            followUpAt: appointment.followUpAt || null,
            meetingAt: appointment.meetingAt,
            status: appointment.status,
            appointmentType: appointment.type,
            objective: appointment.objective,
            durationMinutes: appointment.durationMinutes,
            meetingMode: appointment.mode,
            timezone: appointment.timezone,
            preparation: appointment.preparation || {},
            outcome: appointment.outcome || "",
            outcomeNotes: appointment.outcomeNotes || "",
            nextAction: appointment.nextAction || "",
            nextActionAt: appointment.nextActionAt || null,
            rescheduleHistory: appointment.rescheduleHistory || [],
            reminderPlan: appointment.reminderPlan || {},
            timeline: appointment.timeline || []
        };
    }

    async function cloudRequest(method, payload = {}, id = "") {
        const token = window.supabaseWorkspace?.getAccessToken?.();
        const projectId = cloudProject();
        if (!token || !projectId) throw new Error("Sign in and select a cloud project to sync appointments.");
        const query = new URLSearchParams({ projectId });
        if (id) query.set("id", id);
        const response = await fetch(`/api/appointments?${query}`, {
            method,
            headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" },
            body: method === "GET" || method === "DELETE" ? undefined : JSON.stringify({ ...payload, projectId })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || "Appointment request failed.");
        return data;
    }

    async function loadCloudAppointments() {
        if (!cloudEnabled()) return;
        try {
            await window.workspaceCRM?.retryPendingAppointments?.();
            const local = loadAppointments();
            const data = await cloudRequest("GET");
            const cloud = (data.appointments || []).map(mapAppointment);
            const byCloudId = new Map(cloud.map((item) => [item.id, item]));
            const merged = local.map((item) => {
                if (!item.cloudId || !byCloudId.has(item.cloudId)) return item;
                const cloudItem = byCloudId.get(item.cloudId);
                const mergedItem = { ...item, ...cloudItem };
                ["clientBusiness", "phone", "objective", "outcome", "outcomeNotes", "nextAction", "nextActionAt"].forEach((key) => { if (!cloudItem[key] && item[key]) mergedItem[key] = item[key]; });
                ["preparation", "reminderPlan"].forEach((key) => { if (!Object.keys(cloudItem[key] || {}).length && Object.keys(item[key] || {}).length) mergedItem[key] = item[key]; });
                ["rescheduleHistory", "timeline"].forEach((key) => { if (!(cloudItem[key] || []).length && (item[key] || []).length) mergedItem[key] = item[key]; });
                return { ...mergedItem, id: item.cloudId, cloudId: item.cloudId, syncStatus: "synced", syncError: "" };
            });
            const localIds = new Set(merged.map((item) => item.cloudId || item.id));
            appointments = [...merged, ...cloud.filter((item) => !localIds.has(item.id))];
            saveAppointments(false);
            setCloudStatus(`Cloud appointments loaded · ${appointments.length} saved.`);
        } catch (error) {
            setCloudStatus(`${error.message} Local appointments remain available.`, true);
        }
    }
    const cursor = new Date();
    cursor.setHours(0, 0, 0, 0);

    function loadAppointments() {
        try {
            const value = JSON.parse(localStorage.getItem(KEY) || "[]");
            const items = Array.isArray(value) ? value : [];
            return window.appointmentIntelligence ? items.map(window.appointmentIntelligence.normalize) : items;
        } catch (_) {
            return [];
        }
    }

    function saveAppointments(renderNow = true) {
        try {
            appointments = appointments.map((item) => ({ ...item, timezone: item.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone, updatedAt: new Date().toISOString() }));
        } catch (_) {}
        try {
            localStorage.setItem(KEY, JSON.stringify(appointments));
            window.dispatchEvent(new CustomEvent("appointments:updated", { detail: { count: appointments.length } }));
        } catch (_) {
            setCloudStatus("Browser storage is unavailable; cloud sync is recommended.", true);
        }
        if (renderNow) render();
    }

    async function createCloudAppointment(appointment) {
        if (!cloudEnabled()) return null;
        cloudBusy = true;
        setCloudStatus("Saving appointment to the cloud…");
        try {
            const data = await cloudRequest("POST", cloudPayload(appointment));
            return data.appointment ? mapAppointment(data.appointment) : null;
        } finally {
            cloudBusy = false;
        }
    }

    function validDate(value) {
        const date = new Date(value);
        return Number.isFinite(date.getTime()) ? date : null;
    }

    function dateKey(value) {
        const date = validDate(value);
        if (!date) return "";
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }

    function formatDate(value, options = { dateStyle: "medium", timeStyle: "short" }) {
        const date = validDate(value);
        return date ? new Intl.DateTimeFormat(undefined, options).format(date) : "Date unavailable";
    }

    function renderNextAppointment() {
        const next = appointments
            .filter((appointment) => {
                const meeting = validDate(appointment.meetingAt);
                return meeting && meeting > new Date();
            })
            .sort((a, b) => new Date(a.meetingAt) - new Date(b.meetingAt))[0];

        const client = $("next-client");
        const business = $("next-business");
        if (!client || !business) return;

        if (!next) {
            client.textContent = "No appointments yet";
            business.textContent = "Add the next client meeting below.";
            ["days", "hours", "minutes", "seconds"].forEach((unit) => {
                const element = $("count-" + unit);
                if (element) element.textContent = "—";
            });
            return;
        }

        client.textContent = next.clientName || "Unnamed client";
        business.textContent = [next.clientBusiness, formatDate(next.meetingAt)]
            .filter(Boolean)
            .join(" · ");

        const totalSeconds = Math.max(0, Math.floor((new Date(next.meetingAt) - new Date()) / 1000));
        const values = {
            days: Math.floor(totalSeconds / 86400),
            hours: String(Math.floor((totalSeconds % 86400) / 3600)).padStart(2, "0"),
            minutes: String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, "0"),
            seconds: String(totalSeconds % 60).padStart(2, "0")
        };
        Object.entries(values).forEach(([unit, value]) => {
            const element = $("count-" + unit);
            if (element) element.textContent = value;
        });
    }

    function renderCalendar() {
        const grid = $("calendar-grid");
        const title = $("calendar-title");
        if (!grid || !title) return;
        grid.replaceChildren();

        let start;
        let end;
        if (view === "month") {
            start = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
            end = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
            title.textContent = new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(cursor);
        } else if (view === "week") {
            start = new Date(cursor);
            start.setDate(start.getDate() - start.getDay());
            end = new Date(start);
            end.setDate(end.getDate() + 6);
            title.textContent = `${formatDate(start, { month: "short", day: "numeric" })} – ${formatDate(end, { month: "short", day: "numeric", year: "numeric" })}`;
        } else {
            start = new Date(cursor);
            end = new Date(cursor);
            title.textContent = formatDate(cursor, { dateStyle: "full" });
        }

        const days = [];
        if (view === "month") {
            for (let offset = start.getDay(); offset > 0; offset -= 1) {
                days.push(new Date(start.getFullYear(), start.getMonth(), 1 - offset));
            }
            for (let day = 1; day <= end.getDate(); day += 1) {
                days.push(new Date(start.getFullYear(), start.getMonth(), day));
            }
            while (days.length < 42) {
                days.push(new Date(start.getFullYear(), start.getMonth(), days.length - start.getDay() + 1));
            }
        } else {
            for (let day = new Date(start); day <= end; day.setDate(day.getDate() + 1)) {
                days.push(new Date(day));
            }
        }

        days.forEach((day) => {
            const cell = document.createElement("div");
            const key = dateKey(day);
            cell.className = "calendar-day";
            if (view === "month" && day.getMonth() !== cursor.getMonth()) cell.classList.add("muted");
            if (key === dateKey(new Date())) cell.classList.add("today");

            const heading = document.createElement("strong");
            heading.textContent = day.getDate();
            cell.append(heading);

            appointments.filter((appointment) => validDate(appointment.meetingAt) && dateKey(appointment.meetingAt) === key).forEach((appointment) => {
                const event = document.createElement("span");
                event.className = "calendar-event";
                event.textContent = `${new Date(appointment.meetingAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} ${appointment.clientName}`;
                cell.append(event);
            });
            grid.append(cell);
        });
    }

    function renderProposals() {
        const root = $("proposal-list");
        if (!root || !window.workspaceCRM?.read) return;
        root.replaceChildren();
        window.workspaceCRM.read().filter((lead) => lead.audit || lead.meeting?.scheduledAt || lead.proposal?.status !== "none").forEach((lead) => {
            const row = document.createElement("div");
            row.className = "appointment-row proposal-row";
            const details = document.createElement("div");
            const title = document.createElement("strong");
            title.textContent = `${lead.company || lead.name || lead.email} · v${lead.proposal.version || 1}`;
            const summary = document.createElement("small");
            summary.textContent = [lead.websiteUrl, lead.audit?.mobileScore !== null ? `Mobile ${lead.audit.mobileScore}/100` : "Audit pending", lead.proposal.contractNotes].filter(Boolean).join(" · ");
            details.append(title, summary);
            const controls = document.createElement("div");
            if (lead.proposal.status === "none") {
                const draft = document.createElement("button");
                draft.type = "button"; draft.textContent = "Create draft";
                draft.addEventListener("click", () => { window.workspaceCRM.saveProposal(lead.id, { status: "draft", version: 1, contractNotes: `Recommended services for ${lead.websiteUrl || "the submitted website"}. Audit issues: ${(lead.audit?.issues || []).join("; ")}` }); renderProposals(); });
                controls.append(draft);
            }
            const select = document.createElement("select");
            ["draft", "sent", "viewed", "negotiating", "accepted", "declined"].forEach((status) => { const option = new Option(status, status, false, lead.proposal.status === status); select.append(option); });
            select.addEventListener("change", () => { window.workspaceCRM.saveProposal(lead.id, { status: select.value }); renderProposals(); });
            const amount = document.createElement("input");
            amount.type = "number"; amount.min = "0"; amount.step = "0.01"; amount.value = lead.proposal.total || 0; amount.setAttribute("aria-label", "Proposal total");
            amount.addEventListener("change", () => window.workspaceCRM.saveProposal(lead.id, { total: amount.value, revisionNote: "Pricing updated" }));
            const validity = document.createElement("input"); validity.type = "date"; validity.value = lead.proposal.validityDate || ""; validity.setAttribute("aria-label", "Proposal validity date");
            validity.addEventListener("change", () => window.workspaceCRM.saveProposal(lead.id, { validityDate: validity.value, revisionNote: "Validity date updated" }));
            const notes = document.createElement("textarea"); notes.rows = 2; notes.placeholder = "Services, pricing, discovery notes, objections"; notes.value = [lead.proposal.services.join(", "), lead.proposal.pricingNotes, lead.proposal.discoveryNotes, lead.proposal.objections.join(", ")].filter(Boolean).join("\n"); notes.setAttribute("aria-label", "Proposal details");
            notes.addEventListener("change", () => window.workspaceCRM.saveProposal(lead.id, { services: notes.value.split("\n")[0].split(",").map((item) => item.trim()).filter(Boolean), pricingNotes: notes.value.split("\n").slice(1).join("\n"), revisionNote: "Proposal details updated" }));
            const preview = document.createElement("button"); preview.type = "button"; preview.textContent = "Preview";
            preview.addEventListener("click", () => window.alert(`Proposal for ${lead.company || lead.name || lead.email}\n\nWebsite: ${lead.websiteUrl || "—"}\nAudit: ${lead.audit?.mobileScore ?? "Queued"}/100\nServices: ${lead.proposal.services.join(", ") || "To be confirmed"}\nTotal: ${lead.proposal.total || 0}\nValid until: ${lead.proposal.validityDate || "—"}`));
            controls.append(select, amount, validity, notes, preview);
            row.append(details, controls); root.append(row);
        });
    }

    function createAppointmentTask(appointment, text, notes) {
        try {
            const key = window.workspaceContext?.storageKey?.("morrow-next-steps-v2") || "morrow-next-steps-v2";
            const tasks = JSON.parse(localStorage.getItem(key) || "[]");
            const dueDate = String(appointment.nextActionAt || appointment.followUpAt || new Date(Date.now() + 86400000).toISOString()).slice(0, 10);
            if (!Array.isArray(tasks) || tasks.some((item) => !item.completed && item.text === text && item.dueDate === dueDate)) return;
            tasks.push({ id: globalThis.crypto?.randomUUID?.() || `task-${Date.now()}`, text, category: appointment.context === "personal" ? "Personal" : "Appointments", context: appointment.context || "work", priority: "now", dueDate, notes, completed: false, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), source: "appointment", effort: "About 10 minutes", recurring: false, recurrence: "" });
            localStorage.setItem(key, JSON.stringify(tasks));
        } catch (_) {}
    }

    function updateLinkedLead(appointment, outcome) {
        if (!appointment?.leadId || !window.workspaceCRM?.update) return;
        const rule = window.appointmentIntelligence?.OUTCOMES?.[outcome];
        const lead = window.workspaceCRM.read().find((item) => item.id === appointment.leadId || item.cloudId === appointment.leadId);
        if (!lead) return;
        const changes = { meeting: { ...lead.meeting, status: "completed", scheduledAt: appointment.meetingAt }, nextAction: { title: appointment.nextAction, dueDate: String(appointment.nextActionAt || "").slice(0, 10), owner: lead.assignedTo || "sales" }, activity: [{ type: "meeting", label: `${window.appointmentIntelligence?.typeFor(appointment.type).label || "Appointment"} outcome: ${rule?.label || outcome}`, at: new Date().toISOString() }] };
        if (rule?.stage && window.confirm(`Move this lead to ${rule.stage}?`)) changes.status = rule.stage;
        window.workspaceCRM.update(lead.id, changes);
        if (outcome === "won") createAppointmentTask(appointment, `Start project kickoff for ${appointment.clientBusiness || appointment.clientName}`, "Created from a won appointment outcome. Confirm scope, owners, assets, and milestones.");
        if (outcome === "no_show") createAppointmentTask(appointment, `Offer ${appointment.clientName || "the client"} a new appointment time`, "Created automatically after a no-show. Confirm interest before moving the appointment.");
        if (appointment.type === "revision_review" && ["qualified", "follow_up", "proposal_requested"].includes(outcome)) createAppointmentTask(appointment, `Turn approved changes for ${appointment.clientBusiness || appointment.clientName} into delivery tasks`, "Review the linked revision and create only the changes explicitly approved in the meeting.");
        if (appointment.type === "launch_handoff") createAppointmentTask(appointment, `Verify launch follow-up for ${appointment.clientBusiness || appointment.clientName}`, "Check the live URL, forms, analytics, and ownership at the agreed follow-up date.");
    }

    function openOutcomeWorkflow(appointment) {
        const dialog = $("appointment-workflow-dialog"); if (!dialog) return;
        const personal = appointment.context === "personal";
        const workOutcomes = document.querySelector('[data-outcomes="work"]'); const personalOutcomes = document.querySelector('[data-outcomes="personal"]');
        if (workOutcomes) { workOutcomes.hidden = personal; workOutcomes.disabled = personal; }
        if (personalOutcomes) { personalOutcomes.hidden = !personal; personalOutcomes.disabled = !personal; }
        workflowAppointmentId = appointment.id; $("appointment-outcome").value = appointment.outcome || ""; $("appointment-outcome-notes").value = appointment.outcomeNotes || ""; $("appointment-next-action").value = appointment.nextAction || window.appointmentIntelligence?.typeFor(appointment.type).followUp || ""; const next = validDate(appointment.nextActionAt || appointment.followUpAt || Date.now() + 86400000); $("appointment-next-action-at").value = next ? new Date(next.getTime() - next.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : "";
        dialog.showModal?.();
    }

    function renderList() {
        const root = $("appointment-list");
        if (!root) return;
        root.replaceChildren();

        appointments
            .filter((appointment) => validDate(appointment.meetingAt))
            .slice()
            .sort((a, b) => new Date(a.meetingAt) - new Date(b.meetingAt))
            .forEach((appointment) => {
                const row = document.createElement("div");
                row.className = "appointment-row";

                const details = document.createElement("div");
                const intel = window.appointmentIntelligence; const info = intel?.brief(appointment); const checks = intel?.checklist(appointment) || []; const risks = intel?.risks(appointment, appointments) || []; const workflow = intel?.typeFor(appointment.type);
                const name = document.createElement("strong");
                name.textContent = `${appointment.context === "personal" ? "Personal" : "Work"} · ${workflow?.label || "Appointment"} · ${appointment.clientBusiness || appointment.clientName || "Unnamed appointment"}`;
                const contact = document.createElement("small");
                contact.textContent = [appointment.clientName, appointment.context === "work" ? appointment.clientEmail : "", Number.isFinite(info?.score) ? `${info.score}/100 opportunity` : appointment.context === "work" && info?.stage ? `${info.stage} stage` : "", appointment.timezone].filter(Boolean).join(" · ");
                const objective = document.createElement("small"); objective.textContent = `Objective: ${appointment.objective || "Not set"}`;
                const notes = document.createElement("small");
                notes.textContent = `Prepare: ${workflow?.before || appointment.notes || "Review context"} · ${checks.filter((item) => item.done).length}/${checks.length || 5} complete`;
                const nextAction = document.createElement("small"); nextAction.textContent = `Afterward: ${appointment.nextAction || workflow?.followUp || "Record a next action"}`;
                const last = document.createElement("small"); last.textContent = `Last interaction: ${info?.lastInteraction || "None recorded"}`;
                const risk = document.createElement("small"); risk.className = "appointment-risk"; risk.textContent = risks.length ? `Needs attention: ${risks.slice(0, 2).join(" and ")}.` : "No immediate risk found.";
                details.append(name, contact, objective, notes, nextAction, last, risk);

                const actions = document.createElement("div");
                const meeting = document.createElement("strong");
                meeting.textContent = `${formatDate(appointment.meetingAt)} · ${window.appointmentIntelligence?.relativeTime(appointment.meetingAt) || appointment.status} · ${appointment.status}`;
                const reschedule = document.createElement("button");
                reschedule.type = "button"; reschedule.textContent = "Reschedule"; reschedule.dataset.reschedule = appointment.id;
                const complete = document.createElement("button");
                complete.type = "button"; complete.textContent = appointment.status === "completed" ? (appointment.outcome ? `Outcome: ${appointment.outcome.replaceAll("_", " ")}` : "Add required outcome") : "Complete & record outcome"; complete.dataset.complete = appointment.id; complete.disabled = appointment.status === "completed" && Boolean(appointment.outcome);
                const cancel = document.createElement("button");
                cancel.type = "button"; cancel.textContent = "Cancel"; cancel.dataset.cancel = appointment.id; cancel.disabled = ["cancelled", "completed"].includes(appointment.status);
                const deleteButton = document.createElement("button");
                deleteButton.type = "button";
                deleteButton.dataset.delete = appointment.id;
                deleteButton.textContent = "Delete";
                actions.append(meeting, reschedule, complete, cancel, deleteButton);
                row.append(details, actions);
                root.append(row);
            });
    }

    function renderFunnel() {
        const root = $("funnel-metrics");
        if (!root || !window.workspaceCRM?.read) return;
        const leads = window.workspaceCRM.read();
        const audited = leads.filter((lead) => lead.audit && lead.websiteUrl);
        const booked = leads.filter((lead) => lead.meeting?.status === "booked" || lead.meeting?.status === "completed");
        const proposals = leads.filter((lead) => lead.proposal?.status && lead.proposal.status !== "none");
        const accepted = leads.filter((lead) => lead.proposal?.status === "accepted");
        const averageHours = (items, start, end) => {
            const values = items.map((lead) => { const from = new Date(start(lead)).getTime(); const to = new Date(end(lead)).getTime(); return Number.isFinite(from) && Number.isFinite(to) && to >= from ? (to - from) / 3600000 : null; }).filter((value) => value !== null);
            return values.length ? `${(values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(1)}h` : "—";
        };
        const rate = (part, whole) => whole ? `${Math.round(part / whole * 100)}%` : "0%";
        const auditToBooking = averageHours(booked, (lead) => lead.createdAt, (lead) => lead.meeting.scheduledAt);
        const bookingToProposal = averageHours(proposals.filter((lead) => lead.meeting?.scheduledAt), (lead) => lead.meeting.scheduledAt, (lead) => lead.updatedAt);
        root.replaceChildren(...[["Audits", audited.length], ["Audit → booking", `${rate(booked.length, audited.length)} (${booked.length})`], ["Booking → proposal", `${rate(proposals.length, booked.length)} (${proposals.length})`], ["Proposal acceptance", `${rate(accepted.length, proposals.length)} (${accepted.length})`], ["Average audit → booking", auditToBooking], ["Average booking → proposal", bookingToProposal]].map(([label, value]) => { const item = document.createElement("div"); item.innerHTML = `<strong>${value}</strong><span>${label}</span>`; return item; }));
    }

    function render() {
        renderNextAppointment();
        renderCalendar();
        renderList();
        renderProposals();
        renderFunnel();
    }

    $("sync-appointments-btn")?.addEventListener("click", async () => {
        if (!cloudEnabled()) return setCloudStatus("Sign in and select a cloud project before syncing appointments.", true);
        const button = $("sync-appointments-btn");
        button.disabled = true;
        try {
            await window.workspaceCRM?.retryPendingAppointments?.();
            await loadCloudAppointments();
            setCloudStatus("Pending appointments synchronized.");
        } catch (error) {
            setCloudStatus(error.message || "Appointment sync failed.", true);
        } finally { button.disabled = false; }
    });

    function setAppointmentContext(context = "work") {
        const personal = context === "personal";
        const workFields = $("work-appointment-fields");
        const email = $("client-email");
        const workOptions = document.querySelector('[data-context-options="work"]');
        const personalOptions = document.querySelector('[data-context-options="personal"]');
        if (workFields) workFields.hidden = personal;
        if (email) email.required = !personal;
        if (workOptions) { workOptions.hidden = personal; workOptions.disabled = personal; }
        if (personalOptions) { personalOptions.hidden = !personal; personalOptions.disabled = !personal; }
        if ($("appointment-type")) $("appointment-type").value = personal ? "personal_planning" : "discovery";
        if ($("appointment-form-title")) $("appointment-form-title").textContent = personal ? "Add personal appointment" : "Add work appointment";
        if ($("appointment-contact-label")) $("appointment-contact-label").textContent = personal ? "Person or appointment name" : "Client name";
    }

    document.querySelectorAll('[name="appointment-context"]').forEach((input) => input.addEventListener("change", () => setAppointmentContext(input.value)));

    $("new-lead-btn")?.addEventListener("click", () => {
        const panel = $("lead-form-panel");
        if (panel) panel.hidden = false;
        const select = $("appointment-lead");
        if (select && window.workspaceCRM?.read) {
            select.replaceChildren(new Option("Match by email when possible", ""));
            window.workspaceCRM.read().filter((lead) => !["won", "lost"].includes(lead.status)).forEach((lead) => select.append(new Option(`${lead.company || lead.name || lead.email} · ${lead.status}`, lead.id)));
        }
        $("client-name")?.focus();
    });

    $("cancel-lead-btn")?.addEventListener("click", () => {
        const panel = $("lead-form-panel");
        if (panel) panel.hidden = true;
    });

    $("lead-form")?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const gate = window.workspaceContext?.clientGate?.("context");
        if (gate && !gate.allowed) { setCloudStatus(gate.message, true); return; }
        const meetingValue = $("meeting-at")?.value;
        const meetingDate = validDate(meetingValue);
        const form = event.currentTarget;
        if (!meetingDate || !form?.reportValidity?.()) return;
        const conflict = appointments.find((item) => item.status === "scheduled" && validDate(item.meetingAt)?.getTime() === meetingDate.getTime());
        if (conflict) {
            setCloudStatus(`That time is already booked for ${conflict.clientName || "another appointment"}. Choose another time.`, true);
            return;
        }

        const context = document.querySelector('[name="appointment-context"]:checked')?.value === "personal" ? "personal" : "work";
        const type = $("appointment-type")?.value || (context === "personal" ? "personal_planning" : "discovery");
        const workflow = window.appointmentIntelligence?.typeFor(type);
        const appointment = {
            id: globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            context,
            workContextId: window.workspaceContext?.current?.()?.id || "own-business",
            clientName: $("client-name")?.value.trim() || "",
            clientBusiness: $("client-business")?.value.trim() || "",
            clientEmail: $("client-email")?.value.trim() || "",
            service: $("appointment-service")?.value.trim() || "",
            phone: $("appointment-phone")?.value.trim() || "",
            type,
            durationMinutes: workflow?.duration || 45,
            objective: $("appointment-objective")?.value.trim() || "",
            notes: $("appointment-notes")?.value.trim() || "",
            followUpAt: validDate($("appointment-followup")?.value)?.toISOString() || "",
            status: "scheduled",
            meetingAt: meetingDate.toISOString(),
            timezone: $("appointment-timezone")?.value.trim() || Intl.DateTimeFormat().resolvedOptions().timeZone,
            mode: $("appointment-mode")?.value || "video",
            preparation: {},
            reminderPlan: { preparation: true, attendance: true, startingSoon: true, outcome: true, followUp: true, delivery: "local" },
            rescheduleHistory: [],
            timeline: [{ type: "booking", label: `${workflow?.label || "Appointment"} booked`, at: new Date().toISOString() }]
        };
        const selectedLeadId = context === "work" ? ($("appointment-lead")?.value || "") : "";
        if (selectedLeadId) appointment.leadId = selectedLeadId;
        const linkedLead = context === "work" ? window.appointmentIntelligence?.findLead(appointment) : null;
        if (linkedLead) {
            appointment.leadId = linkedLead.id;
            appointment.cloudLeadId = linkedLead.cloudId || "";
        }
        const submit = form.querySelector("button[type=submit]");
        if (submit) submit.disabled = true;
        try {
            const cloudAppointment = await createCloudAppointment(appointment);
            const savedAppointment = cloudAppointment ? { ...appointment, ...cloudAppointment, id: cloudAppointment.id, leadId: appointment.leadId } : appointment;
            appointments.push(savedAppointment);
            if (savedAppointment.leadId) {
                const lead = window.workspaceCRM?.read?.().find((item) => item.id === savedAppointment.leadId || item.cloudId === savedAppointment.leadId);
                const changes = { meeting: { provider: "native", externalId: savedAppointment.id, scheduledAt: savedAppointment.meetingAt, status: "booked" }, nextAction: { title: `Prepare for ${workflow?.label || "appointment"}`, dueDate: savedAppointment.meetingAt.slice(0, 10), owner: lead?.assignedTo || "sales" }, activity: [{ type: "meeting", label: `${workflow?.label || "Appointment"} booked`, at: new Date().toISOString() }] };
                if (lead?.status === "new" && window.confirm("Move this new lead to qualified now that an appointment is booked?")) changes.status = "qualified";
                window.workspaceCRM?.update?.(lead?.id || savedAppointment.leadId, changes);
            }
            saveAppointments();
            setCloudStatus(cloudAppointment ? "Appointment saved to the cloud." : "Appointment saved locally. Sign in to sync it across devices.");
            form.reset();
            setAppointmentContext("work");
        } catch (error) {
            appointments.push(appointment);
            saveAppointments();
            setCloudStatus(`${error.message} Saved locally as a fallback; it will need syncing later.`, true);
            form.reset();
            setAppointmentContext("work");
        } finally {
            if (submit) submit.disabled = false;
        }
        const panel = $("lead-form-panel");
        if (panel) panel.hidden = true;
    });

    $("appointment-type")?.addEventListener("change", () => {
        const workflow = window.appointmentIntelligence?.typeFor($("appointment-type").value); if (!workflow) return;
        if (!$("appointment-service").value) $("appointment-service").value = workflow.label;
        if (!$("appointment-objective").value) $("appointment-objective").value = workflow.followUp;
    });
    $("appointment-outcome")?.addEventListener("change", () => {
        const rule = window.appointmentIntelligence?.OUTCOMES?.[$("appointment-outcome").value];
        if (rule) $("appointment-next-action").value = rule.action;
    });
    $("appointment-workflow-form")?.addEventListener("submit", async (event) => {
        if (event.submitter?.value !== "save") return;
        event.preventDefault();
        const appointment = appointments.find((item) => item.id === workflowAppointmentId); const outcome = $("appointment-outcome")?.value; const nextAction = $("appointment-next-action")?.value.trim(); const nextDate = validDate($("appointment-next-action-at")?.value);
        if (!appointment || !outcome || !nextAction || !nextDate) return setCloudStatus("Choose an outcome, next action, and next action date.", true);
        if (outcome === "rescheduled") { $("appointment-workflow-dialog")?.close?.(); const button = document.querySelector(`[data-reschedule="${CSS.escape(appointment.id)}"]`); button?.click(); return; }
        appointment.outcome = outcome; appointment.outcomeNotes = $("appointment-outcome-notes")?.value.trim() || ""; appointment.nextAction = nextAction; appointment.nextActionAt = nextDate.toISOString(); appointment.status = outcome === "no_show" ? "no_show" : "completed"; appointment.timeline = [...(appointment.timeline || []), { type: "outcome", label: `Outcome: ${window.appointmentIntelligence?.OUTCOMES?.[outcome]?.label || outcome}`, at: new Date().toISOString() }, { type: "next-action", label: nextAction, at: nextDate.toISOString() }];
        updateLinkedLead(appointment, outcome);
        if (outcome === "no_show" && !appointment.leadId) createAppointmentTask(appointment, `Offer ${appointment.clientName || "the attendee"} a new appointment time`, "Created automatically after a no-show.");
        if (appointment.context === "personal" && outcome === "personal_follow_up") createAppointmentTask(appointment, appointment.nextAction, appointment.outcomeNotes || "Created from a personal appointment follow-up.");
        window.workspaceCRM?.updateAppointment?.(appointment.id, { status: appointment.status, followUpAt: appointment.nextActionAt, outcome: appointment.outcome, outcomeNotes: appointment.outcomeNotes, nextAction: appointment.nextAction, nextActionAt: appointment.nextActionAt, timeline: appointment.timeline });
        if (cloudEnabled()) try { await cloudRequest("PATCH", cloudPayload(appointment), appointment.cloudId || appointment.id); } catch (error) { setCloudStatus(`${error.message} The outcome is saved locally.`, true); }
        saveAppointments(); $("appointment-workflow-dialog")?.close?.(); setCloudStatus("Outcome and required next action saved.");
    });

    document.querySelectorAll("[data-view]").forEach((button) => {
        button.addEventListener("click", () => {
            view = button.dataset.view;
            document.querySelectorAll("[data-view]").forEach((item) => item.classList.toggle("active", item === button));
            render();
        });
    });

    function movePeriod(direction) {
        if (view === "month") cursor.setMonth(cursor.getMonth() + direction);
        else if (view === "week") cursor.setDate(cursor.getDate() + direction * 7);
        else cursor.setDate(cursor.getDate() + direction);
        render();
    }

    $("previous-period")?.addEventListener("click", () => movePeriod(-1));
    $("next-period")?.addEventListener("click", () => movePeriod(1));

    document.addEventListener("click", async (event) => {
        const action = event.target.closest("[data-reschedule], [data-complete], [data-cancel]");
        if (action && !cloudBusy) {
            const id = action.dataset.reschedule || action.dataset.complete || action.dataset.cancel;
            const appointment = appointments.find((item) => item.id === id);
            if (appointment && action.dataset.reschedule) {
                if (["cancelled", "completed"].includes(appointment.status)) return setCloudStatus("Cancelled or completed appointments cannot be rescheduled.", true);
                const value = window.prompt("Enter a new date and time (for example 2026-10-01T14:00):", appointment.meetingAt.slice(0, 16));
                const nextDate = validDate(value);
                if (!nextDate || nextDate <= new Date()) return setCloudStatus("Choose a future date and time.", true);
                const reason = window.prompt("Why is this appointment being moved?", "Client requested a different time");
                if (reason === null || !reason.trim()) return setCloudStatus("Add a rescheduling reason so the appointment history stays useful.", true);
                appointment.rescheduleHistory = [...(appointment.rescheduleHistory || []), { previousAt: appointment.meetingAt, movedAt: new Date().toISOString(), reason: reason.trim(), changedBy: "workspace user" }];
                appointment.timeline = [...(appointment.timeline || []), { type: "rescheduled", label: `Moved from ${formatDate(appointment.meetingAt)}: ${reason.trim()}`, at: new Date().toISOString() }];
                appointment.meetingAt = nextDate.toISOString(); appointment.followUpAt = new Date(nextDate.getTime() + 86400000).toISOString();
                window.workspaceCRM?.updateAppointment?.(id, { meetingAt: appointment.meetingAt, followUpAt: appointment.followUpAt });
            } else if (appointment && action.dataset.complete) {
                openOutcomeWorkflow(appointment); return;
            } else if (appointment) {
                appointment.status = "cancelled";
                appointment.timeline = [...(appointment.timeline || []), { type: "cancelled", label: "Appointment cancelled", at: new Date().toISOString() }];
                window.workspaceCRM?.updateAppointment?.(id, { status: appointment.status });
            }
            if (cloudEnabled()) {
                try {
                    await cloudRequest("PATCH", cloudPayload(appointment), appointment.cloudId || id);
                } catch (error) {
                    setCloudStatus(`${error.message} The local change was retained.`, true);
                }
            }
            saveAppointments();
            return;
        }
        const button = event.target.closest("[data-delete]");
        if (!button || cloudBusy) return;
        const id = button.dataset.delete;
        button.disabled = true;
        try {
            if (cloudEnabled()) await cloudRequest("DELETE", {}, id);
            appointments = appointments.filter((appointment) => appointment.id !== id);
            saveAppointments();
            setCloudStatus(cloudEnabled() ? "Appointment deleted from the cloud." : "Appointment deleted locally.");
        } catch (error) {
            button.disabled = false;
            setCloudStatus(error.message || "Appointment could not be deleted.", true);
        }
    });

    window.addEventListener("supabase:authenticated", loadCloudAppointments);
    window.addEventListener("workspace:project-id-change", loadCloudAppointments);
    window.addEventListener("crm:sync", (event) => {
        if (event.detail?.state === "failed") setCloudStatus(`Appointment sync pending: ${event.detail.error || "retry available"}`, true);
        if (event.detail?.state === "synced") { appointments = loadAppointments(); render(); }
    });
    render();
    loadCloudAppointments();
    setInterval(renderNextAppointment, 1000);
})();
