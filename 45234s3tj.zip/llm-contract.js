"use strict";

// Backward-compatible facade over two deliberately separate boundaries:
// - workspacePlannerContract validates model-authored structured plans.
// - workspaceProjectContract validates deterministic assembler output.
// No prompt in this module asks a model to produce project source code.
(() => {
    function planner() {
        if (!window.workspacePlannerContract) throw new Error("PLANNER_CONTRACT_UNAVAILABLE");
        return window.workspacePlannerContract;
    }

    function project() {
        if (!window.workspaceProjectContract) throw new Error("PROJECT_CONTRACT_UNAVAILABLE");
        return window.workspaceProjectContract;
    }

    const api = {
        get LIMITS() { return Object.freeze({ ...planner().LIMITS, ...project().LIMITS }); },
        get SYSTEM_PROMPT() { return planner().systemPrompt(); },
        createRequest(data = {}) { return planner().createRequest(data); },
        validatePlan(raw, data = {}) { return planner().validatePlan(raw, data); },
        validateProject(files = {}, options = {}) { return project().validateFiles(files, options); },
        validateManifest(raw, options = {}) {
            const files = project().parseManifest(raw, options);
            return Object.freeze({ files: Object.entries(files).map(([path, content]) => ({ path, content })) });
        },
        isAllowedPath(path, options = {}) { return project().isAllowedPath(path, options); }
    };

    window.workspaceLLMContract = Object.freeze(api);
})();
