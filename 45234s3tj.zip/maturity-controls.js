"use strict";

// Product-surface safeguards for local data, translation review, and remote previews.
(() => {
    const get = (id) => document.getElementById(id);
    const STORAGE_KEY = "luxury-engine-workspace";
    const sensitiveKeys = [STORAGE_KEY, "morrow-ad-studio-draft-v4", "studio-release-checkpoints"];

    function status(message, type = "info") {
        const target = get("workspace-save-status");
        if (target) { target.textContent = message; target.dataset.state = type; }
    }

    function clearLocalData() {
        if (!window.confirm("Delete local drafts, checkpoints, leads, and saved workspace data from this browser? Export anything you need first.")) return;
        sensitiveKeys.forEach((key) => localStorage.removeItem(key));
        Object.keys(localStorage).filter((key) => /lead|workspace|checkpoint|morrow/i.test(key)).forEach((key) => localStorage.removeItem(key));
        status("Local workspace data was deleted from this browser.", "success");
        window.workspaceAPI?.clearProjectContext?.({ persist: false, announce: true });
    }

    async function createRemotePreview() {
        const current = window.workspaceAPI?.getState?.();
        if (!current?.files?.["index.html"]) { status("Create a website before sharing a preview.", "error"); return; }
        const response = await fetch("/api/preview", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify({ files: current.files, projectId: current.projectId || "", revision: window.workspaceDomain?.revisionOf?.(current.files || {}) || "" }) });
        const result = await response.json().catch(() => ({}));
        if (!response.ok || !result.success) throw new Error(result.error || "Preview could not be created.");
        const link = `${location.origin}/preview.html?token=${encodeURIComponent(result.token)}`;
        await navigator.clipboard.writeText(link);
        status("Authenticated read-only preview link copied. It expires automatically.", "success");
    }

    function addControls() {
        const panel = get("hosting-options-panel");
        if (!panel || get("create-remote-preview-btn")) return;
        const preview = document.createElement("button");
        preview.id = "create-remote-preview-btn"; preview.type = "button"; preview.className = "matrix-action-btn variant-outline-row"; preview.textContent = "Create secure preview link";
        preview.addEventListener("click", () => createRemotePreview().catch((error) => status(error.message, "error")));
        const privacy = document.createElement("button");
        privacy.id = "delete-local-data-btn"; privacy.type = "button"; privacy.className = "matrix-action-btn variant-danger-text"; privacy.textContent = "Delete local data"; privacy.addEventListener("click", clearLocalData);
        panel.querySelector(".hosting-options-actions")?.append(preview, privacy);
    }

    function markTranslationReview() {
        const locale = get("input-locale");
        if (!locale || locale.value === "en-US") return;
        const help = document.querySelector("[aria-labelledby='localization-settings-title'] .field-descriptor-text");
        if (help) help.textContent = "Locale metadata and translation review are required. User-supplied content is not silently translated.";
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { addControls(); markTranslationReview(); }, { once: true });
    else { addControls(); markTranslationReview(); }
})();
