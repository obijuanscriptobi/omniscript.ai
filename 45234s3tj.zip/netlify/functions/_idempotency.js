"use strict";

const { createHash } = require("node:crypto");

const KEY = /^[A-Za-z0-9._:-]{8,120}$/;

function header(event = {}, name) {
    const headers = event?.headers && typeof event.headers === "object" ? event.headers : {};
    const key = Object.keys(headers).find((entry) => entry.toLowerCase() === name.toLowerCase());
    return key ? String(headers[key] || "").trim() : "";
}

function idempotencyKey(event = {}, body = {}) {
    const supplied = header(event, "idempotency-key") || String(body?.idempotencyKey || "").trim();
    return KEY.test(supplied) ? supplied : "";
}

function requestHash(value) {
    return createHash("sha256").update(typeof value === "string" ? value : JSON.stringify(value || {})).digest("hex");
}

async function beginIdempotent({ request, actorId, projectId = null, operation, key, hash }) {
    if (!key) return { enabled: false };
    if (typeof request !== "function" || !actorId || !operation || !/^[a-f0-9]{64}$/.test(hash)) throw new Error("INVALID_IDEMPOTENCY_REQUEST");
    const payload = { p_actor_id: actorId, p_project_id: projectId, p_operation: operation, p_idempotency_key: key, p_request_hash: hash };
    const result = await request("/rest/v1/rpc/begin_idempotent_operation", { method: "POST", body: JSON.stringify(payload) });
    const row = Array.isArray(result) ? result[0] : result;
    if (!row) throw new Error("IDEMPOTENCY_UNAVAILABLE");
    if (row.state === "conflict") throw new Error("IDEMPOTENCY_CONFLICT");
    if (row.state === "in_progress") throw new Error("IDEMPOTENCY_IN_PROGRESS");
    return { enabled: true, key, operation, replay: row.state === "completed", response: row.response_payload || null };
}

async function completeIdempotent({ request, actorId, projectId = null, operation, key, response }) {
    if (!key) return;
    await request("/rest/v1/rpc/complete_idempotent_operation", {
        method: "POST",
        body: JSON.stringify({ p_actor_id: actorId, p_project_id: projectId, p_operation: operation, p_idempotency_key: key, p_response_payload: response })
    });
}

async function abandonIdempotent({ request, actorId, projectId = null, operation, key }) {
    if (!key) return;
    await request("/rest/v1/rpc/abandon_idempotent_operation", {
        method: "POST",
        body: JSON.stringify({ p_actor_id: actorId, p_project_id: projectId, p_operation: operation, p_idempotency_key: key })
    }).catch(() => null);
}

async function beginPublicApprovalDecision({ request, tokenHash, key, hash }) {
    if (!key) return { enabled: false };
    if (typeof request !== "function" || !/^[a-f0-9]{64}$/.test(tokenHash) || !/^[a-f0-9]{64}$/.test(hash)) throw new Error("INVALID_IDEMPOTENCY_REQUEST");
    const result = await request("/rest/v1/rpc/begin_public_approval_decision", {
        method: "POST",
        body: JSON.stringify({ p_token_hash: tokenHash, p_idempotency_key: key, p_request_hash: hash })
    });
    const row = Array.isArray(result) ? result[0] : result;
    if (!row) throw new Error("IDEMPOTENCY_UNAVAILABLE");
    if (row.state === "conflict") throw new Error("IDEMPOTENCY_CONFLICT");
    if (row.state === "in_progress") throw new Error("IDEMPOTENCY_IN_PROGRESS");
    return { enabled: true, key, replay: row.state === "completed", response: row.response_payload || null };
}

async function completePublicApprovalDecision({ request, tokenHash, key, response }) {
    if (!key) return;
    await request("/rest/v1/rpc/complete_public_approval_decision", {
        method: "POST",
        body: JSON.stringify({ p_token_hash: tokenHash, p_idempotency_key: key, p_response_payload: response })
    });
}

async function abandonPublicApprovalDecision({ request, tokenHash, key }) {
    if (!key) return;
    await request("/rest/v1/rpc/abandon_public_approval_decision", {
        method: "POST",
        body: JSON.stringify({ p_token_hash: tokenHash, p_idempotency_key: key })
    }).catch(() => null);
}

async function beginPublicTokenOperation({ request, tokenHash, operation, key, hash }) {
    if (!key) return { enabled: false };
    const result = await request("/rest/v1/rpc/begin_public_token_operation", { method: "POST", body: JSON.stringify({ p_token_hash: tokenHash, p_operation: operation, p_idempotency_key: key, p_request_hash: hash }) });
    const row = Array.isArray(result) ? result[0] : result;
    if (!row) throw new Error("IDEMPOTENCY_UNAVAILABLE");
    if (row.state === "conflict") throw new Error("IDEMPOTENCY_CONFLICT");
    if (row.state === "in_progress") throw new Error("IDEMPOTENCY_IN_PROGRESS");
    return { enabled: true, key, replay: row.state === "completed", response: row.response_payload || null };
}
async function completePublicTokenOperation({ request, tokenHash, operation, key, response }) {
    await request("/rest/v1/rpc/complete_public_token_operation", { method: "POST", body: JSON.stringify({ p_token_hash: tokenHash, p_operation: operation, p_idempotency_key: key, p_response_payload: response }) });
}
async function abandonPublicTokenOperation({ request, tokenHash, operation, key }) {
    if (!key) return;
    await request("/rest/v1/rpc/abandon_public_token_operation", { method: "POST", body: JSON.stringify({ p_token_hash: tokenHash, p_operation: operation, p_idempotency_key: key }) }).catch(() => null);
}

module.exports = {
    idempotencyKey,
    requestHash,
    beginIdempotent,
    completeIdempotent,
    abandonIdempotent,
    beginPublicApprovalDecision,
    completePublicApprovalDecision,
    abandonPublicApprovalDecision,
    beginPublicTokenOperation,
    completePublicTokenOperation,
    abandonPublicTokenOperation
};
