"use strict";

const { requestId } = require("./_security.js");

const SECRET_FIELD = /(authorization|api[_-]?key|token|secret|password|credential|service[_-]?role)/i;

function redact(value, depth = 0) {
    if (depth > 4 || value === null || value === undefined) return value;
    if (typeof value === "string") return value.replace(/(Bearer\\s+|api[_-]?key\\s*[:=]\\s*|token\\s*[:=]\\s*|secret\\s*[:=]\\s*)[^\\s,;]+/gi, "$1[REDACTED]").slice(0, 500);
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => redact(item, depth + 1));
    if (typeof value === "object") {
        return Object.fromEntries(Object.entries(value).slice(0, 100).map(([key, item]) => [key, SECRET_FIELD.test(key) ? "[REDACTED]" : redact(item, depth + 1)]));
    }
    return value;
}

function log(event, data = {}) {
    const safe = redact(data);
    const allowed = ["requestId", "actorId", "projectId", "operation", "provider", "durationMs", "statusCode", "outcome", "retryable", "resource", "code"];
    const fields = Object.fromEntries(allowed.filter((key) => safe[key] !== undefined).map((key) => [key, safe[key]]));
    console.info(JSON.stringify({ event: String(event || "operation.event").slice(0, 100), requestId: fields.requestId || requestId({}), timestamp: new Date().toISOString(), ...fields }));
}

async function timed(name, operation, data = {}) {
    const started = Date.now();
    try {
        const result = await operation();
        log("provider.success", { provider: name, durationMs: Date.now() - started, ...data });
        return result;
    } catch (error) {
        log("provider.failure", { provider: name, durationMs: Date.now() - started, error: error?.message || "unknown", ...data });
        throw error;
    }
}

async function auditEvent(request, payload) {
    if (typeof request !== "function") return null;
    try {
        return await request("/rest/v1/platform_audit_events", { method: "POST", headers: { Prefer: "return=minimal" }, body: JSON.stringify(payload) });
    } catch (error) {
        log("audit.write_failure", { error: error?.message || "unknown", ...payload });
        return null;
    }
}

module.exports = { log, timed, auditEvent };
