"use strict";

const { securityHeaders, limitedResponseAsync } = require("./_security.js");
const { providerClient, requestId } = require("./provider-adapters.js");

function response(statusCode, payload, extra = {}, event = {}) {
    const correlationId = requestId(event);
    const safePayload = payload && typeof payload === "object" && !Array.isArray(payload)
        ? { ...payload, requestId: payload.requestId || correlationId }
        : payload;
    return {
        statusCode,
        isBase64Encoded: false,
        headers: securityHeaders({ "Cache-Control": "no-store", ...extra, "X-Request-ID": correlationId }),
        body: JSON.stringify(safePayload)
    };
}
function header(event, name) {
    const key = Object.keys(event?.headers || {}).find((item) => item.toLowerCase() === name.toLowerCase());
    return key ? String(event.headers[key] || "") : "";
}
function config() {
    const rawUrl = String(process.env.SUPABASE_URL || "").trim();
    const key = String(process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
    let parsed;

    try {
        parsed = new URL(rawUrl);
    } catch {
        throw new Error("NOT_CONFIGURED");
    }

    if (
        parsed.protocol !== "https:" ||
        parsed.username ||
        parsed.password ||
        parsed.port ||
        parsed.pathname !== "/" ||
        parsed.search ||
        parsed.hash ||
        !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.supabase\.co$/i.test(parsed.hostname) ||
        !key
    ) {
        throw new Error("NOT_CONFIGURED");
    }

    return { url: parsed.origin, key };
}
async function request(path, options = {}) {
    const { url, key } = config();
    const configuredHeaders = options.headers && typeof options.headers === "object" && !Array.isArray(options.headers) ? options.headers : {};
    const safeHeaders = Object.fromEntries(
        Object.entries(configuredHeaders).filter(([name]) =>
            !["apikey", "authorization", "content-type"].includes(String(name).toLowerCase())
        )
    );
    const client = providerClient("supabase", {
        endpoint: url,
        retries: 0,
        timeoutMs: 10_000,
        requestId: options.requestId
    });
    const result = await client.request(path, {
        ...options,
        headers: {
            ...safeHeaders,
            apikey: key,
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json"
        }
    });
    return result.data;
}

// Use the caller's JWT for RPCs whose SQL contract verifies auth.uid().
// The public anon key identifies the application; it never replaces user auth.
async function userRequest(event, path, options = {}) {
    const authorization = header(event, "authorization");
    if (!/^Bearer\s+\S+$/i.test(authorization)) throw new Error("UNAUTHORIZED");
    const { url } = config();
    const anonKey = String(process.env.SUPABASE_ANON_KEY || "").trim();
    if (!anonKey) throw new Error("UNAUTHORIZED");
    const configuredHeaders = options.headers && typeof options.headers === "object" && !Array.isArray(options.headers) ? options.headers : {};
    const safeHeaders = Object.fromEntries(Object.entries(configuredHeaders).filter(([name]) => !["apikey", "authorization", "content-type"].includes(String(name).toLowerCase())));
    const client = providerClient("supabase", { endpoint: url, retries: 0, timeoutMs: 10_000, requestId: requestId(event) });
    const result = await client.request(path, {
        ...options,
        headers: { ...safeHeaders, apikey: anonKey, Authorization: authorization, "Content-Type": "application/json" }
    });
    return result.data;
}
async function authenticate(event) {
    const authorization = header(event, "authorization");
    if (!/^Bearer\s+\S+$/i.test(authorization)) throw new Error("UNAUTHORIZED");
    const { url } = config();
    const anonKey = String(process.env.SUPABASE_ANON_KEY || "").trim();
    if (!anonKey) throw new Error("UNAUTHORIZED");

    const client = providerClient("supabase", {
        endpoint: url,
        retries: 0,
        timeoutMs: 10_000,
        requestId: requestId(event)
    });
    try {
        const result = await client.request("/auth/v1/user", {
            headers: { apikey: anonKey, Authorization: authorization }
        });
        if (!result.data?.id) throw new Error("UNAUTHORIZED");
        return result.data;
    } catch {
        throw new Error("UNAUTHORIZED");
    }
}
function body(event, maximumBytes = 2_000_000) {
    const raw = String(event?.body || "");
    let text = raw;
    try {
        if (event?.isBase64Encoded) {
            if (!raw || raw.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(raw)) throw new Error("INVALID_BODY");
            const decoded = Buffer.from(raw, "base64");
            if (decoded.toString("base64").replace(/=+$/, "") !== raw.replace(/=+$/, "")) throw new Error("INVALID_BODY");
            text = decoded.toString("utf8");
        }
        const limit = Number.isFinite(Number(maximumBytes)) ? Math.max(0, Number(maximumBytes)) : 2_000_000;
        if (Buffer.byteLength(text, "utf8") > limit) throw new Error("TOO_LARGE");
        const value = JSON.parse(text || "{}");
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_BODY");
        return value;
    } catch (error) {
        if (error.message === "TOO_LARGE" || error.message === "INVALID_BODY") throw error;
        throw new Error("INVALID_BODY");
    }
}
function uuid(value) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || "")); }
function clean(value, max = 500) { return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, max); }
function allowedOrigin(event) {
    const origin = header(event, "origin");
    const configured = String(process.env.APP_ALLOWED_ORIGIN || process.env.ANALYTICS_ALLOWED_ORIGIN || "").trim();
    return !configured || !origin || origin === configured;
}
async function guard(event, namespace, limit = 60) {
    const blocked = await limitedResponseAsync(event, { namespace, limit, windowMs: 60_000 });
    if (blocked) return blocked;
    if (!allowedOrigin(event)) return response(403, { success: false, code: "ORIGIN_NOT_ALLOWED", error: "Origin is not allowed." }, {}, event);
    return null;
}
module.exports = { response, header, config, request, userRequest, authenticate, body, uuid, clean, guard };
