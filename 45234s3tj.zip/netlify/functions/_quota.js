"use strict";

const { randomUUID } = require("node:crypto");

const LIMITS = Object.freeze({
    projects: 25,
    versions: 50,
    imports: 100,
    ai_generations: 100,
    deployments: 100,
    form_submissions: 1000,
    preview_emails: 100,
    team_members: 10,
    audits: 100,
    storage_bytes: 4_500_000,
    request_bytes: 12_000_000
});

function periodReset(periodStart, period = "monthly") {
    const start = new Date(periodStart || Date.now());
    if (Number.isNaN(start.valueOf())) return null;
    return period === "daily"
        ? new Date(start.valueOf() + 86_400_000).toISOString()
        : new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 1)).toISOString();
}

function quotaError(resource, limit, used = null, periodStart = null, period = "monthly") {
    const error = new Error("QUOTA_EXCEEDED");
    error.resource = resource;
    error.limit = limit;
    error.used = used;
    error.period = period;
    error.resetsAt = periodReset(periodStart, period);
    error.retryable = false;
    return error;
}

async function consumeQuota({ request, userId, projectId = null, resource, amount = 1, limit = LIMITS[resource], period = "monthly" }) {
    if (!request || !userId || !resource || !Number.isFinite(Number(amount)) || Number(amount) <= 0) {
        throw new Error("INVALID_QUOTA_REQUEST");
    }
    const result = await request("/rest/v1/rpc/consume_usage_quota", {
        method: "POST",
        body: JSON.stringify({
            p_user_id: userId,
            p_project_id: projectId,
            p_resource: resource,
            p_amount: Math.ceil(Number(amount)),
            p_limit: Number(limit),
            p_period: period
        })
    });
    const row = Array.isArray(result) ? result[0] : result;
    if (!row?.allowed) throw quotaError(resource, Number(row?.quota_limit || limit), row?.used ?? null, row?.period_start, period);
    return row;
}

async function reserveQuota(options) {
    if (typeof options?.request !== "function" || !options.userId || !options.resource) throw new Error("INVALID_QUOTA_REQUEST");
    const reservationId = randomUUID();
    const result = await options.request("/rest/v1/rpc/reserve_usage_quota", {
        method: "POST",
        body: JSON.stringify({
            p_reservation_id: reservationId,
            p_user_id: options.userId,
            p_project_id: options.projectId || null,
            p_resource: options.resource,
            p_amount: Math.ceil(Number(options.amount || 1)),
            p_limit: Number(options.limit || LIMITS[options.resource]),
            p_period: options.period || "monthly"
        })
    });
    const row = Array.isArray(result) ? result[0] : result;
    if (!row?.allowed) throw quotaError(options.resource, Number(row?.quota_limit || options.limit || LIMITS[options.resource]), row?.used ?? null, row?.period_start, options.period || "monthly");
    return { ...row, reservationId, resource: options.resource, amount: Math.ceil(Number(options.amount || 1)), userId: options.userId, projectId: options.projectId || null, period: options.period || "monthly" };
}

async function commitQuota({ request, reservation }) {
    if (typeof request !== "function" || !reservation?.reservationId || !reservation?.userId) return false;
    await request("/rest/v1/rpc/commit_usage_quota_reservation", {
        method: "POST",
        body: JSON.stringify({ p_reservation_id: reservation.reservationId, p_user_id: reservation.userId })
    });
    return true;
}

async function releaseQuota({ request, reservation }) {
    if (typeof request !== "function" || !reservation?.reservationId || !reservation?.userId || !reservation?.resource) return false;
    await request("/rest/v1/rpc/release_usage_quota_reservation", {
        method: "POST",
        body: JSON.stringify({ p_reservation_id: reservation.reservationId, p_user_id: reservation.userId })
    });
    return true;
}

function quotaMetadata(row, resource, period = "monthly") {
    const limit = Number(row?.quota_limit || LIMITS[resource] || 0);
    const used = Number(row?.used || 0);
    return { resource, limit, remaining: Math.max(0, limit - used), resetsAt: periodReset(row?.period_start, period) };
}

async function consumePublicProjectQuota({ request, projectId, resource, amount = 1, limit = LIMITS[resource], period = "monthly" }) {
    if (typeof request !== "function" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(projectId || ""))) throw new Error("INVALID_QUOTA_REQUEST");
    if (!["form_submissions", "storage_bytes"].includes(resource)) throw new Error("INVALID_QUOTA_REQUEST");
    const result = await request("/rest/v1/rpc/consume_public_project_quota", {
        method: "POST",
        body: JSON.stringify({
            p_project_id: projectId,
            p_resource: resource,
            p_amount: Math.ceil(Number(amount)),
            p_limit: Number(limit),
            p_period: period
        })
    });
    const row = Array.isArray(result) ? result[0] : result;
    if (!row?.allowed) throw quotaError(resource, Number(row?.quota_limit || limit), row?.used ?? null, row?.period_start, period);
    return row;
}

function quotaResponse(error, response) {
    if (error?.message !== "QUOTA_EXCEEDED") return null;
    const resetTime = Date.parse(error.resetsAt || "");
    const retryAfter = Number.isFinite(resetTime) ? Math.max(1, Math.ceil((resetTime - Date.now()) / 1000)) : 60;
    return response(429, {
        success: false,
        code: "QUOTA_EXCEEDED",
        resource: error.resource,
        limit: error.limit,
        used: error.used,
        remaining: 0,
        resetsAt: error.resetsAt || null,
        retryable: false,
        retryAfter,
        error: `The ${String(error.resource).replace(/_/g, " ")} limit has been reached.`,
        guidance: "Export your work or try again after the quota window resets."
    }, { "Retry-After": String(retryAfter) });
}

async function consumeQuotaForEvent(event, options = {}) {
    const { authenticate, request } = options.platform || {};
    if (typeof authenticate !== "function" || typeof request !== "function") throw new Error("QUOTA_AUTH_REQUIRED");
    const user = await authenticate(event);
    const projectId = options.projectId || null;
    const row = await consumeQuota({ request, userId: user.id, projectId, resource: options.resource, amount: options.amount || 1, limit: options.limit, period: options.period || "monthly" });
    return { user, row };
}

module.exports = { LIMITS, consumeQuota, reserveQuota, commitQuota, releaseQuota, quotaMetadata, consumeQuotaForEvent, consumePublicProjectQuota, quotaError, quotaResponse };
