"use strict";

const { randomUUID } = require("node:crypto");

const REQUEST_ID = Symbol.for("omniscript.requestId");
const requestIds = new WeakMap();

function suppliedRequestId(event = {}) {
    const headers = event?.headers && typeof event.headers === "object" ? event.headers : {};
    const name = Object.keys(headers).find((key) => String(key).toLowerCase() === "x-request-id");
    const value = name ? String(headers[name] || "") : "";
    return /^[A-Za-z0-9._:-]{1,80}$/.test(value) ? value : "";
}

function requestId(event = {}) {
    if (typeof event === "string" && /^[A-Za-z0-9._:-]{1,80}$/.test(event)) return event;
    if (!event || typeof event !== "object") return `req-${randomUUID()}`;

    const explicit = /^[A-Za-z0-9._:-]{1,80}$/.test(String(event.requestId || "")) ? String(event.requestId) : "";
    const existing = event[REQUEST_ID] || requestIds.get(event) || explicit || suppliedRequestId(event);
    if (existing) return existing;

    const generated = `req-${randomUUID()}`;
    requestIds.set(event, generated);
    try {
        Object.defineProperty(event, REQUEST_ID, { value: generated, enumerable: false });
    } catch {
        // WeakMap persistence still guarantees one ID for this event object.
    }
    return generated;
}

module.exports = { requestId };
