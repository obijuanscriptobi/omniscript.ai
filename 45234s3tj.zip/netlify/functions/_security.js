"use strict";

const net = require("node:net");
const { providerClient } = require("./provider-adapters.js");
const { requestId } = require("./_request-context.js");

const buckets = new Map();

const DEFAULT_WINDOW_MS = 60_000;
const DEFAULT_LIMIT = 30;
const MAX_BUCKETS = 10_000;
const MAX_KEY_LENGTH = 100;
const CLEANUP_INTERVAL = 100;

let requestsSinceCleanup = 0;

function getHeader(event = {}, name) {
    const headers =
        event &&
        event.headers &&
        typeof event.headers === "object" &&
        !Array.isArray(event.headers)
            ? event.headers
            : {};

    const target = String(name).toLowerCase();

    for (const [key, value] of Object.entries(headers)) {
        if (String(key).toLowerCase() === target) {
            return String(value ?? "").slice(0, 500);
        }
    }

    return "";
}

function normalizeClientAddress(value) {
    const candidates = String(value || "")
        .split(",")
        .map((part) => part.trim())
        .filter(Boolean);

    for (const candidate of candidates) {
        const withoutPort = candidate
            .replace(/^\[([^\]]+)\](?::\d+)?$/, "$1")
            .replace(/^::ffff:/i, "");

        const address = net.isIP(withoutPort)
            ? withoutPort
            : withoutPort.replace(/:\d+$/, "");

        if (net.isIP(address)) {
            return address.toLowerCase().slice(0, MAX_KEY_LENGTH);
        }
    }

    return "";
}

function isJsonContentType(event = {}) {
    const value = getHeader(event, "content-type").split(";", 1)[0].trim().toLowerCase();
    return value === "application/json" || value.endsWith("+json");
}

function getClientKey(event = {}) {
    const source =
        event && typeof event === "object" ? event : {};

    const requestIdentity = source.requestContext?.identity?.sourceIp;

    // Prefer the platform-provided request context. Forwarded headers can be
    // supplied by a caller when this function is invoked directly.
    const clientIp =
        normalizeClientAddress(requestIdentity) ||
        normalizeClientAddress(getHeader(source, "x-nf-client-connection-ip")) ||
        normalizeClientAddress(getHeader(source, "client-ip")) ||
        normalizeClientAddress(getHeader(source, "x-forwarded-for"));

    return clientIp || "anonymous";
}

function removeExpiredBuckets(now) {
    for (const [key, bucket] of buckets) {
        if (now - bucket.startedAt >= bucket.windowMs) {
            buckets.delete(key);
        }
    }
}

function evictOldestBuckets() {
    if (buckets.size <= MAX_BUCKETS) return;

    const entries = [...buckets.entries()]
        .sort(([, first], [, second]) => first.startedAt - second.startedAt)
        .slice(0, Math.ceil(MAX_BUCKETS * 0.1));

    for (const [key] of entries) {
        buckets.delete(key);
    }
}

function rateLimit(event, options = {}) {
    const requestedLimit = Number(options.limit);
    const requestedWindow = Number(options.windowMs);

    const limit = Number.isFinite(requestedLimit)
        ? Math.max(1, Math.min(Math.floor(requestedLimit), 10_000))
        : DEFAULT_LIMIT;

    const windowMs = Number.isFinite(requestedWindow)
        ? Math.max(1_000, Math.min(Math.floor(requestedWindow), 86_400_000))
        : DEFAULT_WINDOW_MS;

    const namespace = String(options.namespace || "api")
        .replace(/[^a-z0-9:_-]/gi, "")
        .slice(0, 50) || "api";

    const key = `${namespace}:${getClientKey(event)}`;
    const now = Date.now();

    requestsSinceCleanup += 1;

    if (requestsSinceCleanup >= CLEANUP_INTERVAL) {
        removeExpiredBuckets(now);
        evictOldestBuckets();
        requestsSinceCleanup = 0;
    }

    let bucket = buckets.get(key);

    if (
        !bucket ||
        now - bucket.startedAt >= bucket.windowMs ||
        bucket.limit !== limit ||
        bucket.windowMs !== windowMs
    ) {
        bucket = {
            startedAt: now,
            count: 1,
            limit,
            windowMs
        };

        buckets.set(key, bucket);
        evictOldestBuckets();

        return {
            allowed: true,
            remaining: Math.max(0, limit - 1),
            retryAfter: 0
        };
    }

    bucket.count += 1;

    const retryAfter = Math.max(
        1,
        Math.ceil((bucket.windowMs - (now - bucket.startedAt)) / 1000)
    );

    if (bucket.count > bucket.limit) {
        return {
            allowed: false,
            remaining: 0,
            retryAfter
        };
    }

    return {
        allowed: true,
        remaining: Math.max(0, bucket.limit - bucket.count),
        retryAfter: 0
    };
}

function securityHeaders(extra = {}) {
    const enforced = {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store, max-age=0",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Permissions-Policy":
            "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
        "Cross-Origin-Resource-Policy": "same-origin",
        "X-Permitted-Cross-Domain-Policies": "none",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload"
    };

    const configured =
        extra &&
        typeof extra === "object" &&
        !Array.isArray(extra)
            ? extra
            : {};

    const enforcedNames = new Set(
        Object.keys(enforced).map((name) => name.toLowerCase())
    );

    const additional = {};

    for (const [name, value] of Object.entries(configured)) {
        if (!enforcedNames.has(String(name).toLowerCase())) {
            additional[name] = value;
        }
    }

    return {
        ...additional,
        ...enforced
    };
}

function jsonResponse(statusCode, payload, extraHeaders = {}, event = {}) {
    const correlationId = requestId(event);
    console.info(JSON.stringify({
        event: "api.response",
        requestId: correlationId,
        statusCode,
        method: String(event?.httpMethod || "").toUpperCase(),
        path: String(event?.path || "").slice(0, 200)
    }));
    const responsePayload =
        payload && typeof payload === "object" && !Array.isArray(payload)
            ? { ...payload, requestId: payload.requestId || correlationId }
            : payload;

    return {
        statusCode,
        isBase64Encoded: false,
        headers: securityHeaders({ ...extraHeaders, "X-Request-ID": correlationId }),
        body: JSON.stringify(responsePayload)
    };
}

async function limitedResponseAsync(event, options = {}) {
    const requireDistributed = Boolean(options.requireDistributed);
    const redisUrl = String(process.env.UPSTASH_REDIS_REST_URL || "").trim();
    const redisToken = String(process.env.UPSTASH_REDIS_REST_TOKEN || "").trim();
    if (redisUrl && redisToken) {
        try {
            const requestedLimit = Number(options.limit);
            const requestedWindow = Number(options.windowMs);
            const limit = Number.isFinite(requestedLimit) ? Math.max(1, Math.min(Math.floor(requestedLimit), 10000)) : DEFAULT_LIMIT;
            const windowMs = Number.isFinite(requestedWindow) ? Math.max(1000, Math.min(Math.floor(requestedWindow), 86400000)) : DEFAULT_WINDOW_MS;
            const namespace = String(options.namespace || "api").replace(/[^a-z0-9:_-]/gi, "").slice(0, 50) || "api";
            const key = `studio:ratelimit:${namespace}:${getClientKey(event)}`;
            const redis = providerClient("upstash-redis", {
                endpoint: redisUrl,
                retries: 0,
                timeoutMs: 5_000,
                requestId: requestId(event)
            });
            const result = await redis.request("/pipeline", {
                method: "POST",
                headers: { Authorization: `Bearer ${redisToken}`, "Content-Type": "application/json" },
                body: JSON.stringify([["EVAL", "local count=redis.call('INCR',KEYS[1]); if count==1 then redis.call('PEXPIRE',KEYS[1],ARGV[1]) end; local ttl=redis.call('PTTL',KEYS[1]); return {count,ttl}", "1", key, String(windowMs)]])
            });
            const values = result.data;
            if (!Array.isArray(values)) throw new Error("RATE_LIMIT_STORE_UNAVAILABLE");
            const rate = Array.isArray(values?.[0]?.result) ? values[0].result : [];
            const count = Number(rate[0] || 0);
            const ttlMs = Number(rate[1] || windowMs);
            const retryAfter = Math.max(1, Math.ceil(ttlMs / 1000));
            const rateHeaders = {
                "RateLimit-Limit": String(limit),
                "RateLimit-Remaining": String(Math.max(0, limit - count)),
                "RateLimit-Reset": String(Math.ceil((Date.now() + Math.max(0, ttlMs)) / 1000))
            };
            if (count <= limit) return null;
            return jsonResponse(429, { success: false, code: "RATE_LIMIT_EXCEEDED", error: "Too many requests. Please try again later.", retryable: true, retryAfter }, { ...rateHeaders, "Retry-After": String(retryAfter) }, event);
        } catch (error) {
            console.warn("Distributed rate limiter unavailable.", error?.message || error);
            if (requireDistributed) {
                return jsonResponse(503, { success: false, error: "This operation is temporarily unavailable while abuse protection recovers.", retryable: true }, { "Retry-After": "30" }, event);
            }
        }
    }
    if (requireDistributed) {
        return jsonResponse(503, { success: false, error: "This operation requires configured distributed abuse protection.", retryable: true }, { "Retry-After": "30" }, event);
    }
    return limitedResponse(event, options);
}

function limitedResponse(event, options = {}) {
    const result = rateLimit(event, options);

    if (result.allowed) return null;

    return jsonResponse(
        429,
        {
            success: false,
            code: "RATE_LIMIT_EXCEEDED",
            error: "Too many requests. Please try again later.",
            retryable: true,
            retryAfter: result.retryAfter
        },
        {
            "RateLimit-Limit": String(options.limit || DEFAULT_LIMIT),
            "RateLimit-Remaining": "0",
            "RateLimit-Reset": String(Math.ceil(Date.now() / 1000) + result.retryAfter),
            "Retry-After": String(result.retryAfter)
        },
        event
    );
}

function decodeRequestBody(event = {}) {
    const source =
        event && typeof event === "object" ? event : {};
    const body = String(source.body || "");

    if (!source.isBase64Encoded) {
        return Buffer.from(body, "utf8");
    }

    if (
        !body ||
        body.length % 4 !== 0 ||
        !/^[A-Za-z0-9+/]*={0,2}$/.test(body)
    ) {
        throw new Error("INVALID_BASE64");
    }

    const decoded = Buffer.from(body, "base64");
    const input = body.replace(/=+$/, "");
    const output = decoded.toString("base64").replace(/=+$/, "");

    if (!decoded.length || input !== output) {
        throw new Error("INVALID_BASE64");
    }

    return decoded;
}

function maxBodyResponse(event, maximumBytes) {
    const maximum = Number(maximumBytes);

    if (!Number.isFinite(maximum) || maximum < 0) {
        return jsonResponse(500, {
            success: false,
            error: "Request size validation is misconfigured."
        }, {}, event);
    }

    const contentLength = Number(getHeader(event, "content-length"));

    if (
        !event?.isBase64Encoded &&
        Number.isFinite(contentLength) &&
        contentLength >= 0 &&
        contentLength > maximum
    ) {
        return jsonResponse(413, {
            success: false,
            error: "The request payload is too large."
        }, {}, event);
    }

    let decoded;

    try {
        decoded = decodeRequestBody(event);
    } catch {
        return jsonResponse(400, {
            success: false,
            error: "The request body is invalid."
        }, {}, event);
    }

    if (decoded.length <= maximum) return null;

    return jsonResponse(413, {
        success: false,
        error: "The request payload is too large."
    }, {}, event);
}

module.exports = {
    getClientKey,
    getHeader,
    isJsonContentType,
    requestId,
    jsonResponse,
    limitedResponse,
    limitedResponseAsync,
    maxBodyResponse,
    securityHeaders
};