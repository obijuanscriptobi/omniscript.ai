"use strict";
const { response, request, authenticate, guard } = require("./_platform.js");
exports.handler = async (event = {}) => {
    const blocked = await guard(event, "account-delete", 3);
    if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST is supported." });
    try {
        const user = await authenticate(event);
        await request("/rest/v1/rpc/delete_my_account", { method: "POST", body: "{}" });
        return response(200, { success: true, deleted: true, userId: user.id });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        console.error("Account deletion failed:", error.message || error);
        return response(500, { success: false, error: "The account could not be deleted." });
    }
};
