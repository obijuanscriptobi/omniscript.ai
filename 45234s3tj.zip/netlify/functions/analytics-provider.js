"use strict";
const { response, request, authenticate, body, clean, guard } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");
async function handler(event = {}) {
    const blocked = await guard(event, "analytics-provider", 30); if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST is supported." });
    try {
        await authenticate(event); const value = body(event); const provider = clean(value.provider, 30); const eventName = clean(value.eventName, 40); const site = clean(value.site, 200); const allowed = ["plausible", "umami", "posthog", "first-party"];
        if (!allowed.includes(provider) || !eventName) return response(400, { success: false, error: "Unsupported analytics provider or event." });
        const endpoint = provider === "plausible" ? "https://plausible.io/api/event" : provider === "umami" ? `${String(process.env.UMAMI_URL || "").replace(/\/+$/, "")}/api/send` : provider === "posthog" ? `${String(process.env.POSTHOG_URL || "https://app.posthog.com").replace(/\/+$/, "")}/capture/` : null;
        if (!endpoint) return response(202, { success: true, provider: "first-party", recorded: true });
        const token = provider === "plausible" ? process.env.PLAUSIBLE_API_KEY : provider === "umami" ? process.env.UMAMI_API_KEY : process.env.POSTHOG_API_KEY;
        if (!token) return response(503, { success: false, error: "The selected analytics provider is not configured." });
        const payload = provider === "plausible" ? { name: eventName, domain: site, url: clean(value.url, 500), props: value.metadata || {} } : provider === "umami" ? { type: "event", payload: { website: site, name: eventName, url: clean(value.url, 500), data: value.metadata || {} } } : { api_key: token, event: eventName, distinct_id: clean(value.anonymousId, 120), properties: { site, ...(value.metadata || {}) } };
        const client = providerClient(provider, { endpoint, retries: 0, timeoutMs: 10_000, requestId: requestId(event) });
        await client.request("", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(payload) });
        return response(202, { success: true, provider });
    } catch (error) { if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." }); return response(500, { success: false, error: "Analytics provider request failed." }); }
}
exports.handler = handler;
