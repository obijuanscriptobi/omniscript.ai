"use strict";

const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const { providerClient, requestId } = require("./provider-adapters.js");
const EVENTS = new Set(["page_view", "cta_click", "form_start", "form_submit", "booking_start", "booking_completed", "phone_click", "email_click", "quote_request", "experiment_exposure"]);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MAX_BODY = 12000;

function response(statusCode, payload, event = response.currentEvent || {}) {
    const id = requestId(event);
    const safePayload = payload && typeof payload === "object" && !Array.isArray(payload)
        ? { ...payload, requestId: payload.requestId || id }
        : payload;
    return { statusCode, isBase64Encoded: false, headers: securityHeaders({ "Cache-Control": "no-store", "X-Request-ID": id }), body: JSON.stringify(safePayload) };
}
function header(event, name) {
    const key = Object.keys(event?.headers || {}).find((entry) => entry.toLowerCase() === name.toLowerCase());
    return key ? String(event.headers[key] || "") : "";
}
function config() {
    const url = String(process.env.SUPABASE_URL || "").replace(/\/+$/, "");
    const key = String(process.env.SUPABASE_SERVICE_ROLE_KEY || "");
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url) || !key) throw new Error("NOT_CONFIGURED");
    return { url, key };
}
function parse(event) {
    const raw = String(event.body || "");
    if (Buffer.byteLength(raw, "utf8") > MAX_BODY) throw new Error("INVALID_BODY");
    let value;
    try { value = JSON.parse(raw || "{}"); } catch { throw new Error("INVALID_BODY"); }
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_BODY");
    if (!UUID.test(String(value.projectId || "")) || !EVENTS.has(value.eventName)) throw new Error("INVALID_EVENT");
    if (value.revisionId !== undefined && value.revisionId !== null && !UUID.test(String(value.revisionId))) throw new Error("INVALID_EVENT");
    if (value.experimentId !== undefined && value.experimentId !== null && !UUID.test(String(value.experimentId))) throw new Error("INVALID_EVENT");
    if (value.occurredAt !== undefined && Number.isNaN(Date.parse(String(value.occurredAt)))) throw new Error("INVALID_EVENT");
    if (value.consent !== true) throw new Error("CONSENT_REQUIRED");
    return {
        project_id: value.projectId,
        deployment_id: String(value.deploymentId || "").slice(0, 200).replace(/[^A-Za-z0-9_-]/g, "") || null,
        revision_id: UUID.test(String(value.revisionId || "")) ? value.revisionId : null,
        experiment_id: UUID.test(String(value.experimentId || "")) ? value.experimentId : null,
        event_name: value.eventName || value.event,
        occurred_at: value.occurredAt ? new Date(value.occurredAt).toISOString() : new Date().toISOString(),
        anonymous_id: String(value.anonymousId || `anon-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`).slice(0, 120).replace(/[^a-zA-Z0-9._:-]/g, "-"),
        path: String(value.path || "/").slice(0, 500) || "/",
        locale: /^[a-z]{2,3}(?:-[A-Z]{2})?$/.test(String(value.locale || "")) ? String(value.locale).slice(0, 20) : null,
        consent: Boolean(value.consent),
        metadata: value.metadata && typeof value.metadata === "object" && !Array.isArray(value.metadata) ? value.metadata : {}
    };
}
exports.handler = async (event = {}) => {
    const blocked = await limitedResponseAsync(event, { namespace: "analytics", limit: 120, windowMs: 60_000 });
    if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST is supported." }, event);
    const origin = header(event, "origin");
    const configuredOrigin = String(process.env.ANALYTICS_ALLOWED_ORIGIN || "").trim();
    if (configuredOrigin && origin && origin !== configuredOrigin) return response(403, { success: false, error: "Origin is not allowed." }, event);
    try {
        const row = parse(event);
        const { url, key } = config();
        const client = providerClient("supabase", {
            endpoint: url,
            retries: 0,
            timeoutMs: 8_000,
            requestId: requestId(event)
        });
        await client.request("/rest/v1/analytics_events", {
            method: "POST",
            headers: {
                apikey: key,
                Authorization: `Bearer ${key}`,
                "Content-Type": "application/json",
                Prefer: "return=minimal"
            },
            body: JSON.stringify(row)
        });
        return response(202, { success: true }, event);
    } catch (error) {
        if (["INVALID_BODY", "INVALID_EVENT", "CONSENT_REQUIRED"].includes(error.message)) return response(400, { success: false, error: error.message === "CONSENT_REQUIRED" ? "Analytics consent is required." : "Analytics event is invalid." }, event);
        if (error.message === "NOT_CONFIGURED") return response(503, { success: false, error: "Analytics is not configured." }, event);
        console.error("Analytics error:", error.message || error);
        return response(500, { success: false, error: "Analytics event failed." }, event);
    }
};
