"use strict";

const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const projects = require("./projects.js");

const MAX_BODY_BYTES = 40_000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const STATUSES = ["scheduled", "confirmed", "completed", "cancelled", "no_show"];
const CONTEXTS = ["work", "personal"];
const TYPES = ["discovery", "audit_review", "proposal_review", "client_approval", "kickoff", "revision_review", "launch_handoff", "follow_up", "personal_planning", "health", "family", "finance", "errand", "social", "personal_follow_up"];
const OUTCOMES = ["", "qualified", "follow_up", "proposal_requested", "won", "lost", "no_show", "rescheduled", "personal_completed", "personal_follow_up"];
const MODES = ["video", "phone", "in_person"];

function response(statusCode, payload) {
    return { statusCode, isBase64Encoded: false, headers: securityHeaders(), body: JSON.stringify(payload) };
}

function body(event) {
    const source = String(event?.body || "");
    let buffer;
    if (event?.isBase64Encoded) {
        if (!source || source.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(source)) throw new Error("INVALID_BODY");
        buffer = Buffer.from(source, "base64");
        if (buffer.toString("base64").replace(/=+$/, "") !== source.replace(/=+$/, "")) throw new Error("INVALID_BODY");
    } else buffer = Buffer.from(source, "utf8");
    if (buffer.length > MAX_BODY_BYTES) throw new Error("TOO_LARGE");
    try {
        const value = JSON.parse(buffer.toString("utf8") || "{}");
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();
        return value;
    } catch { throw new Error("INVALID_BODY"); }
}

function clean(value, max = 1200) {
    return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
}

function projectId(event, value = {}) {
    const id = event?.queryStringParameters?.projectId || value.projectId || "";
    if (!UUID.test(String(id))) throw new Error("INVALID_PROJECT");
    return String(id);
}

function workContextId(event, value = {}) {
    const id = event?.queryStringParameters?.workContextId || value.workContextId || "";
    if (!UUID.test(String(id))) throw new Error("INVALID_CONTEXT");
    return String(id);
}

function appointmentId(event, value = {}) {
    const id = event?.queryStringParameters?.id || value.id || "";
    if (id && !UUID.test(String(id))) throw new Error("INVALID_ID");
    return String(id);
}

function isoDate(value, required = false) {
    if ((value === undefined || value === null || value === "") && !required) return null;
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) throw new Error("INVALID_DATE");
    return date.toISOString();
}

function boundedObject(value, fallback, maxBytes) {
    if (value === undefined) return fallback;
    if (!value || typeof value !== "object" || Array.isArray(value) !== Array.isArray(fallback)) throw new Error("INVALID_WORKFLOW");
    const copy = JSON.parse(JSON.stringify(value));
    if (Buffer.byteLength(JSON.stringify(copy), "utf8") > maxBytes) throw new Error("INVALID_WORKFLOW");
    return copy;
}

function requiresFuture(status, meetingAt) {
    return ["scheduled", "confirmed"].includes(status) && meetingAt && new Date(meetingAt) <= new Date();
}

function validWorkflow(status, outcome, nextAction, nextActionAt) {
    if (status !== "completed" && status !== "no_show") return true;
    return Boolean(OUTCOMES.includes(outcome) && outcome && clean(nextAction, 300) && isoDate(nextActionAt));
}

async function organizationFor(userId, project) {
    if (project.organization_id) return project.organization_id;
    const rows = await projects.supabaseRequest(`/rest/v1/organization_members?user_id=eq.${encodeURIComponent(userId)}&select=organization_id&limit=1`);
    return Array.isArray(rows) && rows[0]?.organization_id ? rows[0].organization_id : null;
}

function select() {
    return "id,organization_id,project_id,lead_id,client_name,client_email,client_business,client_phone,appointment_context,service,notes,status,meeting_at,follow_up_at,appointment_type,objective,duration_minutes,meeting_mode,timezone,preparation,outcome,outcome_notes,next_action,next_action_at,reschedule_history,reminder_plan,timeline,created_by,created_at,updated_at";
}

function workflowFields(value, partial = false) {
    const fields = {};
    const assign = (camel, snake, transform) => {
        if (!partial || Object.prototype.hasOwnProperty.call(value, camel) || Object.prototype.hasOwnProperty.call(value, snake)) fields[snake] = transform(value[camel] ?? value[snake]);
    };
    assign("clientBusiness", "client_business", (item) => clean(item, 200));
    assign("clientPhone", "client_phone", (item) => clean(item, 80));
    assign("appointmentContext", "appointment_context", (item) => { const context = item || "work"; if (!CONTEXTS.includes(context)) throw new Error("INVALID_CONTEXT"); return context; });
    assign("appointmentType", "appointment_type", (item) => { const type = item || "discovery"; if (!TYPES.includes(type)) throw new Error("INVALID_TYPE"); return type; });
    assign("objective", "objective", (item) => clean(item, 500));
    assign("durationMinutes", "duration_minutes", (item) => { const duration = Number(item) || 45; if (!Number.isInteger(duration) || duration < 15 || duration > 240) throw new Error("INVALID_DURATION"); return duration; });
    assign("meetingMode", "meeting_mode", (item) => { const mode = item || "video"; if (!MODES.includes(mode)) throw new Error("INVALID_MODE"); return mode; });
    assign("timezone", "timezone", (item) => clean(item, 100) || "UTC");
    assign("preparation", "preparation", (item) => boundedObject(item, {}, 12_000));
    assign("outcome", "outcome", (item) => { const outcome = item || ""; if (!OUTCOMES.includes(outcome)) throw new Error("INVALID_OUTCOME"); return outcome; });
    assign("outcomeNotes", "outcome_notes", (item) => clean(item, 1200));
    assign("nextAction", "next_action", (item) => clean(item, 300));
    assign("nextActionAt", "next_action_at", (item) => isoDate(item));
    assign("rescheduleHistory", "reschedule_history", (item) => boundedObject(item, [], 40_000).slice(-20));
    assign("reminderPlan", "reminder_plan", (item) => boundedObject(item, {}, 12_000));
    assign("timeline", "timeline", (item) => boundedObject(item, [], 80_000).slice(-50));
    return fields;
}

function payload(value, userId, organizationId, projectId) {
    const status = value.status || "scheduled";
    if (!STATUSES.includes(status)) throw new Error("INVALID_STATUS");
    const leadId = value.leadId || value.lead_id || null;
    if (leadId && !UUID.test(String(leadId))) throw new Error("INVALID_LEAD");
    const requestedId = value.id && UUID.test(String(value.id)) ? String(value.id) : null;
    const result = {
        ...(requestedId ? { id: requestedId } : {}), organization_id: organizationId, project_id: projectId, lead_id: leadId,
        client_name: clean(value.clientName || value.client_name, 200), client_email: clean(value.clientEmail || value.client_email, 320),
        service: clean(value.service, 240), notes: clean(value.notes, 4000), status,
        meeting_at: isoDate(value.meetingAt || value.meeting_at, true), follow_up_at: isoDate(value.followUpAt || value.follow_up_at),
        created_by: userId, ...workflowFields(value)
    };
    const personalTypes = ["personal_planning", "health", "family", "finance", "errand", "social", "personal_follow_up"];
    const personalOutcomes = ["", "personal_completed", "personal_follow_up", "no_show", "rescheduled"];
    if ((result.appointment_context === "personal") !== personalTypes.includes(result.appointment_type)) throw new Error("INVALID_CONTEXT");
    if (result.appointment_context === "personal" && !personalOutcomes.includes(result.outcome)) throw new Error("INVALID_CONTEXT");
    if (result.appointment_context === "work" && ["personal_completed", "personal_follow_up"].includes(result.outcome)) throw new Error("INVALID_CONTEXT");
    if (result.appointment_context === "personal") result.lead_id = null;
    if (!validWorkflow(result.status, result.outcome, result.next_action, result.next_action_at)) throw new Error("INCOMPLETE_OUTCOME");
    return result;
}

exports.handler = async (event = {}) => {
    const blocked = await limitedResponseAsync(event, { namespace: "appointments", limit: 60, windowMs: 60000 });
    if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const user = await projects.authenticate(event);
        const input = method === "GET" ? {} : body(event);
        const id = appointmentId(event, input);
        const project = projectId(event, input);
        const context = workContextId(event, input);
        const ownedProject = await projects.getOwnedProject(project, user.id, context);
        if (!ownedProject) return response(404, { success: false, error: "Project not found in this work context." });
        const organizationId = await organizationFor(user.id, ownedProject);
        if (!organizationId) return response(409, { success: false, error: "Workspace membership is not configured." });
        const ownership = `project_id=eq.${encodeURIComponent(project)}&organization_id=eq.${encodeURIComponent(organizationId)}&created_by=eq.${encodeURIComponent(user.id)}`;

        if (method === "GET") {
            const filter = id ? `&id=eq.${encodeURIComponent(id)}` : "";
            const rows = await projects.supabaseRequest(`/rest/v1/appointments?${ownership}${filter}&select=${select()}&order=meeting_at.asc`);
            return response(200, { success: true, appointments: Array.isArray(rows) ? rows : [] });
        }
        if (method === "POST") {
            const appointmentPayload = payload(input, user.id, organizationId, project);
            if (requiresFuture(appointmentPayload.status, appointmentPayload.meeting_at)) throw new Error("PAST_MEETING");
            if (appointmentPayload.id) {
                const existing = await projects.supabaseRequest(`/rest/v1/appointments?${ownership}&id=eq.${encodeURIComponent(appointmentPayload.id)}&select=${select()}&limit=1`);
                if (Array.isArray(existing) && existing[0]) return response(200, { success: true, appointment: existing[0], idempotent: true });
            }
            if (appointmentPayload.lead_id) {
                const linkedLead = await projects.supabaseRequest(`/rest/v1/leads?id=eq.${encodeURIComponent(appointmentPayload.lead_id)}&project_id=eq.${encodeURIComponent(project)}&user_id=eq.${encodeURIComponent(user.id)}&select=id&limit=1`);
                if (!Array.isArray(linkedLead) || !linkedLead[0]) throw new Error("INVALID_LEAD");
                const active = await projects.supabaseRequest(`/rest/v1/appointments?${ownership}&lead_id=eq.${encodeURIComponent(appointmentPayload.lead_id)}&status=in.(scheduled,confirmed)&select=id&limit=1`);
                if (Array.isArray(active) && active.length) throw new Error("DUPLICATE_BOOKING");
            }
            const result = await projects.supabaseRequest(`/rest/v1/appointments?select=${select()}`, { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(appointmentPayload) });
            return response(201, { success: true, appointment: Array.isArray(result) ? result[0] : null });
        }
        if (!id) return response(400, { success: false, error: "An appointment ID is required." });
        if (method === "DELETE") {
            const existing = await projects.supabaseRequest(`/rest/v1/appointments?${ownership}&id=eq.${encodeURIComponent(id)}&select=id&limit=1`);
            if (!Array.isArray(existing) || !existing[0]) return response(404, { success: false, error: "Appointment not found." });
            await projects.supabaseRequest(`/rest/v1/appointments?${ownership}&id=eq.${encodeURIComponent(id)}`, { method: "DELETE" });
            return response(200, { success: true });
        }

        const currentRows = await projects.supabaseRequest(`/rest/v1/appointments?${ownership}&id=eq.${encodeURIComponent(id)}&select=${select()}&limit=1`);
        const current = Array.isArray(currentRows) ? currentRows[0] : null;
        if (!current) return response(404, { success: false, error: "Appointment not found." });
        const updates = workflowFields(input, true);
        if (Object.prototype.hasOwnProperty.call(input, "status")) { if (!STATUSES.includes(input.status)) throw new Error("INVALID_STATUS"); updates.status = input.status; }
        if (Object.prototype.hasOwnProperty.call(input, "notes")) updates.notes = clean(input.notes, 4000);
        if (Object.prototype.hasOwnProperty.call(input, "followUpAt")) updates.follow_up_at = isoDate(input.followUpAt);
        if (Object.prototype.hasOwnProperty.call(input, "meetingAt")) updates.meeting_at = isoDate(input.meetingAt, true);
        if (!Object.keys(updates).length) throw new Error("INVALID_UPDATE");
        const nextStatus = updates.status || current.status;
        const nextMeetingAt = updates.meeting_at || current.meeting_at;
        const nextContext = updates.appointment_context || current.appointment_context || "work";
        const nextType = updates.appointment_type || current.appointment_type || "discovery";
        const personalTypes = ["personal_planning", "health", "family", "finance", "errand", "social", "personal_follow_up"];
        if ((nextContext === "personal") !== personalTypes.includes(nextType)) throw new Error("INVALID_CONTEXT");
        const nextOutcome = updates.outcome ?? current.outcome;
        const nextAction = updates.next_action ?? current.next_action;
        const nextActionAt = updates.next_action_at ?? current.next_action_at;
        if (requiresFuture(nextStatus, nextMeetingAt)) throw new Error("PAST_MEETING");
        if (!validWorkflow(nextStatus, nextOutcome, nextAction, nextActionAt)) throw new Error("INCOMPLETE_OUTCOME");
        const movesTerminalMeeting = updates.meeting_at && updates.meeting_at !== current.meeting_at;
        if (["cancelled", "completed"].includes(current.status) && (movesTerminalMeeting || updates.status === "scheduled" || updates.status === "confirmed")) throw new Error("TERMINAL_APPOINTMENT");
        const result = await projects.supabaseRequest(`/rest/v1/appointments?${ownership}&id=eq.${encodeURIComponent(id)}&select=${select()}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(updates) });
        return response(200, { success: true, appointment: Array.isArray(result) ? result[0] : null });
    } catch (error) {
        const code = error?.message || "";
        if (code === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (["INVALID_BODY", "INVALID_PROJECT", "INVALID_ID", "INVALID_DATE", "INVALID_STATUS", "INVALID_LEAD", "INVALID_UPDATE", "INVALID_TYPE", "INVALID_CONTEXT", "INVALID_MODE", "INVALID_DURATION", "INVALID_OUTCOME", "INVALID_WORKFLOW", "PAST_MEETING", "DUPLICATE_BOOKING", "TERMINAL_APPOINTMENT", "INCOMPLETE_OUTCOME"].includes(code)) return response(400, { success: false, error: code === "INCOMPLETE_OUTCOME" ? "Completed appointments require an outcome, next action, and next action date." : "The appointment data is invalid." });
        if (code === "TOO_LARGE") return response(413, { success: false, error: "The appointment payload is too large." });
        if (code === "NOT_CONFIGURED") return response(503, { success: false, error: "Cloud storage is not configured." });
        if (code === "INVALID_CONFIG") return response(500, { success: false, error: "Cloud storage configuration is invalid." });
        console.error("Appointment API error:", error?.message || error);
        return response(500, { success: false, error: "The appointment request failed." });
    }
};
