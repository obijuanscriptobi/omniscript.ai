"use strict";

const crypto = require("crypto");
const { response, request, userRequest, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const { requestId } = require("./_request-context.js");
const {
    idempotencyKey,
    requestHash,
    beginIdempotent,
    completeIdempotent,
    abandonIdempotent,
    beginPublicApprovalDecision,
    completePublicApprovalDecision,
    abandonPublicApprovalDecision
} = require("./_idempotency.js");
const { log, auditEvent } = require("./_ops.js");
const { getOwnedProject, getOwnedWorkContext } = require("./projects.js");

function hash(token) { return crypto.createHash("sha256").update(token).digest("hex"); }
function publicApproval(approval) {
    if (!approval || typeof approval !== "object") return approval;
    const { project_id: ignoredProjectId, ...safeApproval } = approval;
    return safeApproval;
}
function historyStatus(status) {
    return { pending: "sent_for_review", approved: "approved", "changes-requested": "changes_requested" }[status] || status;
}
async function recordHistory(approval, status, reviewerId = null, reviewerName = "", comment = "") {
    await request("/rest/v1/project_approval_history", {
        method: "POST",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({
            project_id: approval.project_id,
            approval_id: approval.id,
            status: historyStatus(status),
            revision: approval.revision,
            reviewer_id: reviewerId,
            reviewer_name: clean(reviewerName, 500),
            comment: clean(comment, 2000)
        })
    });
}

async function handler(event = {}) {
    const correlationId = requestId(event);
    const reply = (status, payload, headers = {}) => response(status, payload, headers, event);
    const method = String(event.httpMethod || "").toUpperCase();
    if (!["GET", "POST", "PATCH"].includes(method)) return reply(405, { success: false, code: "METHOD_NOT_ALLOWED", error: "Only GET, POST, and PATCH are supported." }, { Allow: "GET, POST, PATCH" });
    if (["POST", "PATCH"].includes(method) && !/^application\/json(?:\s*;|$)/i.test(String(Object.entries(event.headers || {}).find(([name]) => name.toLowerCase() === "content-type")?.[1] || ""))) {
        return reply(415, { success: false, code: "UNSUPPORTED_MEDIA_TYPE", error: "Content-Type must be application/json." });
    }
    let parsedBody;
    if (["POST", "PATCH"].includes(method)) {
        try {
            parsedBody = body(event);
        } catch (error) {
            if (error.message === "TOO_LARGE") return reply(413, { success: false, code: "PAYLOAD_TOO_LARGE", error: "The approval request is too large." });
            return reply(400, { success: false, code: "INVALID_REQUEST", error: "The approval request is invalid." });
        }
    }
    const blocked = await guard(event, "approval", 30);
    if (blocked) return blocked;
    let operation;
    let operationRequest;
    let operationUser;
    let operationProjectId = null;
    let operationName = "";
    let publicDecision;
    let publicDecisionTokenHash = "";
    let publicDecisionRequest;
    try {
        if (method === "POST") {
            const user = await authenticate(event);
            operationUser = user;
            const value = parsedBody;
            if (!uuid(value.projectId) || !uuid(value.workContextId) || !clean(value.revision, 200)) return reply(400, { success: false, code: "INVALID_REQUEST", error: "Project, work context, and revision are required." });
            if (!await getOwnedProject(value.projectId, user.id, value.workContextId)) return reply(404, { success: false, code: "NOT_FOUND", error: "Project not found in this work context." });
            const context = await getOwnedWorkContext(value.workContextId, user.id);
            if (!context?.permissions_confirmed) return reply(409, { success: false, code: "PERMISSIONS_REQUIRED", error: "Confirm permission to work on this project before creating a review link." });
            if (!context?.asset_rights_confirmed) return reply(409, { success: false, code: "ASSET_RIGHTS_REQUIRED", error: "Confirm rights to the project assets before creating a review link." });
            if (context.kind === "client" && !context.approval_contact) return reply(409, { success: false, code: "APPROVAL_CONTACT_REQUIRED", error: "Add the client approval contact before creating a review link." });
            const membership = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(value.projectId)}&user_id=eq.${encodeURIComponent(user.id)}&select=role&limit=1`);
            const role = Array.isArray(membership) ? membership[0]?.role : "";
            if (!["owner", "admin", "contributor"].includes(role)) throw new Error("FORBIDDEN");
            operationRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: correlationId });
            operationProjectId = value.projectId;
            operationName = "approval.create";
            const key = idempotencyKey(event, value);
            operation = await beginIdempotent({ request: operationRequest, actorId: user.id, projectId: operationProjectId, operation: operationName, key, hash: requestHash({ projectId: value.projectId, revision: clean(value.revision, 200), recipientEmail: clean(value.recipientEmail, 254) }) });
            if (operation.replay) return reply(200, { ...operation.response, idempotentReplay: true });
            const token = crypto.randomBytes(32).toString("base64url");
            const result = await request(`/rest/v1/client_approvals?project_id=eq.${encodeURIComponent(value.projectId)}&select=id,project_id,revision,status,expires_at`, {
                method: "POST",
                headers: { Prefer: "return=representation" },
                body: JSON.stringify({ project_id: value.projectId, revision: clean(value.revision, 200), token_hash: hash(token), recipient_email: clean(value.recipientEmail, 254) || null, expires_at: new Date(Date.now() + 7 * 86400000).toISOString(), created_by: user.id })
            });
            const approval = Array.isArray(result) ? result[0] : result;
            if (!approval || typeof approval !== "object") throw new Error("APPROVAL_CREATE_FAILED");
            await recordHistory(approval, "pending", user.id, user.name || user.email || "Project reviewer");
            const payload = { success: true, approval, token, path: `/approval.html?token=${encodeURIComponent(token)}` };
            await completeIdempotent({ request: operationRequest, actorId: user.id, projectId: operationProjectId, operation: operationName, key: operation.key, response: payload });
            log("approval.created", { requestId: correlationId, actorId: user.id, projectId: operationProjectId, operation: operationName, statusCode: 201, outcome: "succeeded" });
            return reply(201, payload);
        }

        const token = clean(event.queryStringParameters?.token, 200);
        if (!token) return reply(400, { success: false, error: "Approval token is required." });
        const rows = await request(`/rest/v1/client_approvals?token_hash=eq.${encodeURIComponent(hash(token))}&select=id,project_id,revision,status,comment,expires_at,approved_at,updated_at`);
        const approval = Array.isArray(rows) ? rows[0] : null;
        const expiresAt = approval ? Date.parse(approval.expires_at) : NaN;
        if (!approval || !Number.isFinite(expiresAt) || expiresAt < Date.now()) return reply(404, { success: false, error: "This approval link is invalid or expired." });
        const projectRows = await request(`/rest/v1/projects?id=eq.${encodeURIComponent(approval.project_id)}&select=id,organization_id,work_context_id&limit=1`);
        const approvalProject = Array.isArray(projectRows) ? projectRows[0] : null;
        const contextRows = approvalProject ? await request(`/rest/v1/work_contexts?id=eq.${encodeURIComponent(approvalProject.work_context_id)}&organization_id=eq.${encodeURIComponent(approvalProject.organization_id)}&status=eq.active&select=id&limit=1`) : [];
        if (!approvalProject || !Array.isArray(contextRows) || !contextRows[0]) return reply(404, { success: false, error: "This approval link is invalid or expired." });

        if (method === "PATCH") {
            const value = parsedBody;
            if (!["approved", "changes-requested"].includes(value.status)) return reply(400, { success: false, error: "A valid approval status is required." });
            const expectedUpdatedAt = clean(value.updatedAt, 80);
            if (!expectedUpdatedAt || Number.isNaN(Date.parse(expectedUpdatedAt))) return reply(400, { success: false, code: "APPROVAL_VERSION_REQUIRED", error: "The approval updatedAt value is required." });
            const comment = clean(value.comment, 2000);
            const reviewerName = clean(value.reviewerName, 500) || "Client reviewer";
            const key = idempotencyKey(event, value);
            if (!key) return reply(400, { success: false, code: "IDEMPOTENCY_KEY_REQUIRED", error: "An idempotency key is required for approval decisions." });
            publicDecisionTokenHash = hash(token);
            publicDecisionRequest = (path, options = {}) => request(path, { ...options, requestId: correlationId });
            publicDecision = await beginPublicApprovalDecision({
                request: publicDecisionRequest,
                tokenHash: publicDecisionTokenHash,
                key,
                hash: requestHash({ approvalId: approval.id, status: value.status, comment, reviewerName, updatedAt: expectedUpdatedAt })
            });
            if (publicDecision.replay) return reply(200, { ...publicDecision.response, idempotentReplay: true });
            if (approval.status !== "pending") throw new Error("APPROVAL_ALREADY_PROCESSED");
            const updated = await request(`/rest/v1/client_approvals?id=eq.${encodeURIComponent(approval.id)}&project_id=eq.${encodeURIComponent(approval.project_id)}&token_hash=eq.${encodeURIComponent(publicDecisionTokenHash)}&status=eq.pending&updated_at=eq.${encodeURIComponent(expectedUpdatedAt)}&expires_at=gt.${encodeURIComponent(new Date().toISOString())}&select=id,project_id,revision,status,comment,expires_at,approved_at,updated_at`, {
                method: "PATCH", headers: { Prefer: "return=representation" },
                body: JSON.stringify({ status: value.status, comment, approved_at: value.status === "approved" ? new Date().toISOString() : null })
            });
            if (!Array.isArray(updated) || !updated.length) throw new Error("APPROVAL_ALREADY_PROCESSED");
            await recordHistory(updated[0], value.status, null, reviewerName, comment);
            const payload = { success: true, approval: publicApproval(updated[0]) };
            await auditEvent(publicDecisionRequest, {
                request_id: correlationId,
                actor_id: null,
                project_id: approval.project_id,
                action: "approval.decision",
                revision: approval.revision,
                result: "succeeded",
                metadata: { approvalId: approval.id, beforeStatus: approval.status, afterStatus: value.status, reason: comment || null }
            });
            await completePublicApprovalDecision({ request: publicDecisionRequest, tokenHash: publicDecisionTokenHash, key: publicDecision.key, response: payload });
            log("approval.decision_recorded", { requestId: correlationId, projectId: approval.project_id, operation: "approval.decision", statusCode: 200, outcome: "succeeded" });
            return reply(200, payload);
        }
        let history = [];
        const authorization = Object.keys(event.headers || {}).find((key) => key.toLowerCase() === "authorization");
        if (authorization) {
            const reviewer = await authenticate(event);
            const members = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(approval.project_id)}&user_id=eq.${encodeURIComponent(reviewer.id)}&select=role&limit=1`);
            const role = Array.isArray(members) ? members[0]?.role : "";
            if (["owner", "admin", "contributor", "client_reviewer"].includes(role)) {
                const rows = await request(`/rest/v1/project_approval_history?approval_id=eq.${encodeURIComponent(approval.id)}&select=status,revision,reviewer_id,reviewer_name,comment,created_at&order=created_at.desc&limit=100`);
                history = Array.isArray(rows) ? rows : [];
            }
        }
        return reply(200, { success: true, approval: publicApproval(approval), history });
    } catch (error) {
        if (operation?.enabled && !operation.replay) await abandonIdempotent({ request: operationRequest, actorId: operationUser?.id, projectId: operationProjectId, operation: operationName, key: operation.key });
        if (publicDecision?.enabled && !publicDecision.replay) await abandonPublicApprovalDecision({ request: publicDecisionRequest, tokenHash: publicDecisionTokenHash, key: publicDecision.key });
        if (error.message === "UNAUTHORIZED") return reply(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." });
        if (error.message === "FORBIDDEN") return reply(403, { success: false, code: "FORBIDDEN", error: "Your project role cannot create approvals." });
        if (error.message === "IDEMPOTENCY_CONFLICT") return reply(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for another approval." });
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return reply(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This approval operation is already being processed." }, { "Retry-After": "2" });
        if (error.message === "APPROVAL_ALREADY_PROCESSED") return reply(409, { success: false, code: "APPROVAL_ALREADY_PROCESSED", error: "This approval has already been processed." });
        if (error.message === "INVALID_BODY") return reply(400, { success: false, code: "INVALID_REQUEST", error: "The approval request is invalid." });
        if (error.message === "TOO_LARGE") return reply(413, { success: false, code: "PAYLOAD_TOO_LARGE", error: "The approval request is too large." });
        log("approval.failed", { requestId: correlationId, actorId: operationUser?.id, projectId: operationProjectId, operation: operationName || "approval.request", statusCode: 500, outcome: "failed", retryable: true });
        return reply(500, { success: false, code: "APPROVAL_FAILED", retryable: true, error: "Approval request failed." });
    }
}
exports.handler = handler;
