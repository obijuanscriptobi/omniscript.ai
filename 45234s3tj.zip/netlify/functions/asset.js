"use strict";
const { response, request, authenticate, body, uuid, clean, guard, config } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");
const { consumeQuota, quotaResponse } = require("./_quota.js");
const { log } = require("./_ops.js");

async function handler(event = {}) {
    const blocked = await guard(event, "asset", 20);
    if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST is supported." });
    try {
        const user = await authenticate(event);
        const value = body(event);
        if (value.action === "inspect-url") {
            const rawUrl = clean(value.url, 2000);
            let parsed;
            try { parsed = new URL(rawUrl); } catch { return response(400, { success: false, error: "Enter a valid asset URL." }); }
            if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.hash) return response(400, { success: false, error: "Only public HTTPS asset URLs can be inspected." });
            const remote = providerClient("remote-asset", { retries: 0, timeoutMs: 8_000, requestId: requestId(event) });
            const probe = (await remote.request(parsed.href, { method: "HEAD", redirect: "error", headers: { Accept: "image/avif,image/webp,image/svg+xml,image/*;q=0.8" }, raw: true })).response;
            const length = Number(probe.headers.get("content-length") || 0);
            const mime = String(probe.headers.get("content-type") || "").split(";", 1)[0].toLowerCase();
            const supported = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif", "image/svg+xml"].includes(mime);
            return response(probe.ok && supported ? 200 : 422, { success: probe.ok && supported, asset: { url: parsed.href, status: probe.status, mimeType: mime, bytes: length || null, sizeKnown: length > 0, supported, optimization: length > 2_000_000 ? "Review large remote asset before publishing." : "Within the initial remote asset budget." } });
        }
        const projectId = uuid(value.projectId) ? value.projectId : "";
        const content = String(value.content || "").trim();
        const mimeType = clean(value.mimeType, 100).toLowerCase();
        const name = clean(value.name, 160).replace(/[^a-zA-Z0-9._-]/g, "-");
        const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif", "image/svg+xml"]);
        const validBase64 = content.length > 0 && content.length % 4 === 0 && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(content);
        const bytes = validBase64 ? Buffer.from(content, "base64") : Buffer.alloc(0);
        if (!projectId || !name || !validBase64 || !bytes.length || !allowedTypes.has(mimeType) || bytes.length > 25000000) return response(400, { success: false, error: "Project, supported image type, and a valid asset are required." });

        // Check ownership with the user's JWT before using the server key for storage.
        const authorization = Object.keys(event.headers || {}).find((key) => key.toLowerCase() === "authorization");
        const owned = await request(`/rest/v1/projects?id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(user.id)}&select=id`, { headers: authorization ? { Authorization: String(event.headers[authorization]) } : {} });
        if (!Array.isArray(owned) || !owned.length) return response(404, { success: false, error: "Project not found." });

        await consumeQuota({ request, userId: user.id, projectId, resource: "storage_bytes", amount: bytes.length });
        log("quota.consumed", { event, resource: "storage_bytes", amount: bytes.length, projectId, actorId: user.id });
        const path = `${projectId}/${user.id}/${Date.now()}-${name}`;
        const { url, key } = config();
        const storage = providerClient("supabase-storage", { endpoint: url, retries: 0, timeoutMs: 10_000, requestId: requestId(event) });
        const upload = (await storage.request(`/storage/v1/object/project-assets/${path}`, { method: "POST", headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": mimeType, "x-upsert": "false" }, body: bytes, raw: true })).response;
        if (!upload.ok) return response(502, { success: false, error: "Asset storage rejected the upload." });
        const item = await request("/rest/v1/project_assets", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ project_id: projectId, storage_path: path, mime_type: mimeType, byte_size: bytes.length, alt_text: clean(value.altText, 250), optimization: { original: true, optimized: false, requested: Boolean(value.optimize) }, public_url: `${url}/storage/v1/object/public/project-assets/${path}`, created_by: user.id }) });
        return response(201, { success: true, asset: item });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The asset request is invalid." });
        const quota = quotaResponse(error, response);
        if (quota) return quota;
        return response(500, { success: false, error: "Asset upload failed." });
    }
}
exports.handler = handler;
