"use strict";

const dns = require("node:dns").promises;
const net = require("node:net");
const { limitedResponseAsync, maxBodyResponse, securityHeaders } = require("./_security.js");
const { quotaResponse } = require("./_quota.js");
const { timed } = require("./_ops.js");

const MAX_BODY_BYTES = 8_000;
const TIMEOUT_MS = 15_000;
const CACHE_TTL_MS = 10 * 60_000;
const EMAIL_WINDOW_MS = 60 * 60_000;
const EMAIL_LIMIT = 3;
const MAX_CACHE_ENTRIES = 100;
const MAX_EMAIL_ENTRIES = 5_000;
const PUBLIC_PROTOCOLS = new Set(["http:", "https:"]);
const auditCache = new Map();
const emailBuckets = new Map();

function response(statusCode, payload, extraHeaders = {}) {
    return { statusCode, isBase64Encoded: false, headers: securityHeaders(extraHeaders), body: JSON.stringify(payload) };
}

function parseBody(event) {
    const raw = Buffer.from(String(event?.body || ""), event?.isBase64Encoded ? "base64" : "utf8").toString("utf8");
    try {
        const value = JSON.parse(raw || "{}");
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();
        return value;
    } catch (_) { throw new Error("INVALID_BODY"); }
}

function clean(value, max) {
    return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
}

function isPrivateAddress(address) {
    const value = String(address || "").toLowerCase();
    const mapped = value.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/);
    if (mapped) return isPrivateAddress(mapped[1]);
    if (net.isIP(value) === 4) {
        const [a, b] = value.split(".").map(Number);
        return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a >= 224;
    }
    return value === "::" || value === "::1" || value.startsWith("fc") || value.startsWith("fd") || /^fe[89ab]/.test(value) || value.startsWith("ff");
}

async function publicUrl(value) {
    try {
        const url = new URL(String(value || "").trim());
        if (!PUBLIC_PROTOCOLS.has(url.protocol) || !url.hostname || url.username || url.password || url.port || url.hash) return null;
        const host = url.hostname.toLowerCase();
        if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal") || host === "metadata.google.internal" || host === "metadata.google.com") return null;
        const addresses = await dns.lookup(host, { all: true });
        if (!addresses.length || addresses.some((entry) => isPrivateAddress(entry.address))) return null;
        url.hostname = host;
        return url.href;
    } catch (_) { return null; }
}

function metric(audit, key, digits = 0) {
    const value = audit?.[key]?.numericValue;
    return Number.isFinite(value) ? Number(value.toFixed(digits)) : null;
}

function categoryScore(data, category) {
    const value = data?.lighthouseResult?.categories?.[category]?.score;
    return Number.isFinite(value) ? Math.round(value * 100) : null;
}

function summarize(data) {
    const audit = data?.lighthouseResult?.audits || {};
    const score = (item) => Number.isFinite(item?.score) ? item.score : null;
    const priority = (item) => score(item) !== null && score(item) < 0.5 ? "high" : "medium";
    const guidance = {
        "largest-contentful-paint": "Improve the loading of the main above-the-fold content, especially on mobile networks.",
        "render-blocking-resources": "Delay or inline critical resources so visitors can see useful content sooner.",
        "unused-javascript": "Remove or defer code that is not needed for the first view.",
        "unused-css-rules": "Remove unused styles and load page-specific CSS only when it is needed.",
        "image-size-responsive": "Resize and compress images, then serve modern responsive formats.",
        "uses-optimized-images": "Compress large images and use efficient formats such as WebP or AVIF.",
        "color-contrast": "Increase contrast between text and its background so more people can read it.",
        "image-alt": "Add useful alternative text to meaningful images and mark decorative images appropriately.",
        "document-title": "Give the page a specific, descriptive title that explains its purpose.",
        "meta-description": "Add a concise description that accurately previews the page in search results.",
        "link-text": "Use descriptive link text so people and search engines know where each link leads."
    };
    const opportunities = Object.entries(audit)
        .filter(([id, item]) => item?.scoreDisplayMode !== "informative" && Number.isFinite(item?.score) && item.score < 0.9 && item?.title)
        .sort(([, a], [, b]) => (a.score - b.score) || ((b.numericValue || 0) - (a.numericValue || 0)))
        .slice(0, 8)
        .map(([id, item]) => ({
            id,
            title: clean(item.title, 180),
            description: clean(item.description || "This check needs attention.", 320),
            displayValue: clean(item.displayValue || "", 100),
            score: Math.round(item.score * 100),
            priority: priority(item),
            recommendation: guidance[id] || "Review this area and fix the highest-impact issue first."
        }));
    const passedChecks = Object.values(audit).filter((item) => item?.scoreDisplayMode !== "informative" && item?.score === 1 && item?.title).slice(0, 6).map((item) => clean(item.title, 160));
    const performanceScore = categoryScore(data, "performance");
    const accessibilityScore = categoryScore(data, "accessibility");
    const seoScore = categoryScore(data, "seo");
    const weakest = [{ label: "mobile performance", value: performanceScore }, { label: "accessibility", value: accessibilityScore }, { label: "SEO", value: seoScore }].filter((item) => item.value !== null).sort((a, b) => a.value - b.value)[0];
    const summary = weakest ? `Your strongest next opportunity is ${weakest.label}. The report found ${opportunities.length} improvement ${opportunities.length === 1 ? "area" : "areas"}; start with the high-priority items before polishing lower-impact details.` : "The provider returned an incomplete snapshot. Retry the audit for a fuller set of findings.";
    return {
        provider: "pagespeed-insights",
        status: "complete",
        mobileScore: performanceScore,
        accessibilityScore,
        seoScore,
        overallSummary: summary,
        priorityAction: opportunities[0]?.recommendation || "Review the page manually and retry the audit if the snapshot is incomplete.",
        performanceMetrics: { lcpMs: metric(audit, "largest-contentful-paint"), cls: metric(audit, "cumulative-layout-shift", 3), tbtMs: metric(audit, "total-blocking-time") },
        opportunities,
        passedChecks,
        requestedAt: new Date().toISOString()
    };
}

function fallbackAudit(reason) {
    return {
        provider: "pagespeed-insights",
        status: "queued",
        mobileScore: null,
        accessibilityScore: null,
        seoScore: null,
        performanceMetrics: { lcpMs: null, cls: null, tbtMs: null },
        issues: [reason || "The mobile audit is queued because the provider is temporarily unavailable. Try again shortly."],
        requestedAt: new Date().toISOString(),
        recommendedNextAction: "Retry the mobile audit shortly or book a discovery conversation for a manual review."
    };
}

function pruneStores(now = Date.now()) {
    for (const [key, item] of auditCache) if (item.expiresAt <= now) auditCache.delete(key);
    for (const [key, item] of emailBuckets) if (item.startedAt + EMAIL_WINDOW_MS <= now) emailBuckets.delete(key);
    while (auditCache.size > MAX_CACHE_ENTRIES) auditCache.delete(auditCache.keys().next().value);
    while (emailBuckets.size > MAX_EMAIL_ENTRIES) emailBuckets.delete(emailBuckets.keys().next().value);
}

function emailRateLimit(email) {
    const now = Date.now();
    pruneStores(now);
    const key = email.toLowerCase();
    let bucket = emailBuckets.get(key);
    if (!bucket || now - bucket.startedAt >= EMAIL_WINDOW_MS) bucket = { startedAt: now, count: 0 };
    bucket.count += 1;
    emailBuckets.set(key, bucket);
    if (bucket.count <= EMAIL_LIMIT) return null;
    const retryAfter = Math.max(1, Math.ceil((EMAIL_WINDOW_MS - (now - bucket.startedAt)) / 1000));
    return response(429, { success: false, error: "This email has reached the free audit limit. Please try again later.", retryAfter }, { "Retry-After": String(retryAfter) });
}

async function requestProvider(endpoint, event = {}) {
    for (let attempt = 0; attempt < 2; attempt += 1) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
        try {
            const provider = await timed("pagespeed", () => fetch(endpoint, { signal: controller.signal, headers: { Accept: "application/json" } }), { event });
            if (provider.status === 429 && attempt === 0) {
                await new Promise((resolve) => setTimeout(resolve, 400));
                continue;
            }
            return provider;
        } finally { clearTimeout(timer); }
    }
    return null;
}

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "audit", limit: 12, windowMs: 60_000 });
    if (blocked) return blocked;
    if (String(event.httpMethod || "POST").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST requests are supported." });
    const oversized = maxBodyResponse(event, MAX_BODY_BYTES);
    if (oversized) return oversized;
    try {
        // Audits are intentionally public: visitors can audit any public site without signing in.
        // The request and per-email limits still protect the provider from abuse.
        const body = parseBody(event);
        const url = await publicUrl(body.url);
        const email = clean(body.email, 320).toLowerCase();
        if (!url || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return response(400, { success: false, error: "Enter a valid public website URL and email address." });
        const emailBlocked = emailRateLimit(email);
        if (emailBlocked) return emailBlocked;
        const cached = auditCache.get(url);
        if (cached && cached.expiresAt > Date.now()) return response(200, { success: true, url, audit: { ...cached.audit, cached: true } });

        const endpoint = new URL("https://www.googleapis.com/pagespeedonline/v5/runPagespeed");
        endpoint.searchParams.set("url", url);
        endpoint.searchParams.set("strategy", "mobile");
        ["performance", "accessibility", "seo"].forEach((category) => endpoint.searchParams.append("category", category));
        if (process.env.PAGESPEED_API_KEY) endpoint.searchParams.set("key", String(process.env.PAGESPEED_API_KEY).trim());
        let provider;
        try { provider = await requestProvider(endpoint, event); }
        catch (error) {
            if (error?.name !== "AbortError") console.warn("PageSpeed request failed:", error?.message || error);
            provider = null;
        }
        if (!provider || !provider.ok) {
            return response(200, { success: true, url, queued: true, audit: fallbackAudit(provider?.status === 429 ? "PageSpeed is busy right now. Your audit is queued; please retry shortly." : undefined) });
        }
        const audit = summarize(await provider.json());
        auditCache.set(url, { audit, expiresAt: Date.now() + CACHE_TTL_MS });
        pruneStores();
        return response(200, { success: true, url, audit });
    } catch (error) {
        const quota = quotaResponse(error, response);
        if (quota) return quota;
        if (error?.message === "INVALID_BODY") return response(400, { success: false, error: "The audit request is invalid." });
        console.error("Audit function failed:", error?.message || error);
        return response(200, { success: true, queued: true, audit: fallbackAudit() });
    }
};
