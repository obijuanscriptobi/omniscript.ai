"use strict";

const { response, request, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const KINDS = new Set(["project", "proposal", "catalog", "invoice", "file", "approval", "activity", "notification"]);
const MAX_PAYLOAD = 100000;

function query(event) { return event.queryStringParameters || {}; }
function safePayload(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_PAYLOAD");
    const encoded = JSON.stringify(value);
    if (Buffer.byteLength(encoded, "utf8") > MAX_PAYLOAD) throw new Error("PAYLOAD_TOO_LARGE");
    return value;
}
function ownedFilter(userId, projectId = "") {
    return `user_id=eq.${encodeURIComponent(userId)}${projectId ? `&project_id=eq.${encodeURIComponent(projectId)}` : ""}`;
}

async function assertProjectAccess(userId, projectId, kind = "", write = false) {
    const rows = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}&select=role&limit=1`);
    const role = Array.isArray(rows) ? rows[0]?.role : "";
    const writeRoles = kind === "invoice" || kind === "proposal" ? ["owner", "admin", "sales"] : kind === "catalog" ? ["owner", "admin", "marketing"] : ["owner", "admin", "contributor"];
    if (!role) throw new Error("PROJECT_NOT_FOUND");
    if (write && !writeRoles.includes(role)) throw new Error("FORBIDDEN");
    return role;
}

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "business-operations", 100);
    if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const user = await authenticate(event);
        const q = query(event);
        const projectId = q.projectId ? (uuid(q.projectId) ? q.projectId : null) : "";
        const id = q.id ? (uuid(q.id) ? q.id : null) : "";
        const kind = q.kind ? clean(q.kind, 30) : "";
        if (projectId === null || id === null || (kind && !KINDS.has(kind))) return response(400, { success: false, error: "Invalid operation scope." });
        const filter = ownedFilter(user.id, projectId);
        if (method === "GET") {
            if (projectId) await assertProjectAccess(user.id, projectId, kind, false);
            const readFilter = projectId ? `project_id=eq.${encodeURIComponent(projectId)}` : `user_id=eq.${encodeURIComponent(user.id)}`;
            const kindFilter = kind ? `&kind=eq.${encodeURIComponent(kind)}` : "";
            const idFilter = id ? `&id=eq.${encodeURIComponent(id)}` : "";
            const rows = await request(`/rest/v1/business_operations?${readFilter}${kindFilter}${idFilter}&select=id,project_id,kind,payload,created_at,updated_at&order=updated_at.desc&limit=500`);
            return response(200, { success: true, items: Array.isArray(rows) ? rows : [] });
        }
        if (method === "POST") {
            if (!projectId || !kind) return response(400, { success: false, error: "Project ID and operation kind are required." });
            await assertProjectAccess(user.id, projectId, kind, true);
            const value = body(event);
            const payload = safePayload(value.payload || value);
            const rows = await request("/rest/v1/business_operations", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ user_id: user.id, project_id: projectId, kind, payload }) });
            return response(201, { success: true, item: Array.isArray(rows) ? rows[0] : rows });
        }
        if (!id) return response(400, { success: false, error: "Operation ID is required." });
        if (method === "DELETE") {
            await request(`/rest/v1/business_operations?${ownedFilter(user.id)}&id=eq.${encodeURIComponent(id)}`, { method: "DELETE" });
            return response(200, { success: true });
        }
        const value = body(event);
        const payload = safePayload(value.payload || value);
        const rows = await request(`/rest/v1/business_operations?${ownedFilter(user.id)}&id=eq.${encodeURIComponent(id)}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ payload }) });
        if (!Array.isArray(rows) || !rows.length) return response(404, { success: false, error: "Operation not found." });
        return response(200, { success: true, item: rows[0] });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "PROJECT_NOT_FOUND") return response(404, { success: false, error: "The selected project is not available to this account." });
        if (error.message === "FORBIDDEN") return response(403, { success: false, error: "Your project role does not allow this operation." });
        if (error.message === "NOT_CONFIGURED") return response(503, { success: false, error: "Cloud storage is not configured." });
        if (error.message === "INVALID_BODY" || error.message === "INVALID_PAYLOAD") return response(400, { success: false, error: "The operation data is invalid." });
        if (error.message === "PAYLOAD_TOO_LARGE") return response(413, { success: false, error: "The operation payload is too large." });
        console.error("Business operations API error:", error.message || error);
        return response(500, { success: false, error: "The business operation failed." });
    }
};
