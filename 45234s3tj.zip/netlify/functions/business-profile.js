"use strict";
const projects = require("./projects.js");
const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function response(statusCode, payload) { return { statusCode, headers: securityHeaders(), body: JSON.stringify(payload) }; }
function body(event) { try { const value = JSON.parse(String(event.body || "{}")); if (!value || Array.isArray(value)) throw 0; return value; } catch { throw new Error("INVALID_BODY"); } }
function projectId(event, value = {}) { const id = event.queryStringParameters?.projectId || value.projectId; if (!UUID.test(String(id || ""))) throw new Error("INVALID_PROJECT"); return id; }
function workContextId(event, value = {}) { const id = event.queryStringParameters?.workContextId || value.workContextId; if (!UUID.test(String(id || ""))) throw new Error("INVALID_CONTEXT"); return id; }
function profilePayload(value, userId, organizationId, projectId) {
    const profile = value.profile;
    if (!profile || typeof profile !== "object" || Array.isArray(profile)) throw new Error("INVALID_PROFILE");
    const revision = Math.max(0, Number(profile.revision || 0));
    if (!Number.isSafeInteger(revision)) throw new Error("INVALID_PROFILE");
    return { user_id: userId, organization_id: organizationId, project_id: projectId, revision, profile, audit: Array.isArray(profile.audit) ? profile.audit : [] };
}
async function organizationFor(userId, project) {
    if (project.organization_id) return project.organization_id;
    const rows = await projects.supabaseRequest(`/rest/v1/organization_members?user_id=eq.${encodeURIComponent(userId)}&select=organization_id&limit=1`);
    return Array.isArray(rows) && rows[0]?.organization_id ? rows[0].organization_id : null;
}
exports.handler = async (event = {}) => {
    const blocked = await limitedResponseAsync(event, { namespace: "business-profile", limit: 60, windowMs: 60000 });
    if (blocked) return blocked;
    try {
        const user = await projects.authenticate(event);
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "PUT"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const input = method === "PUT" ? body(event) : {};
        const id = projectId(event, input);
        const context = workContextId(event, input);
        const project = await projects.getOwnedProject(id, user.id, context);
        if (!project) return response(404, { success: false, error: "Project not found in this work context." });
        const organizationId = await organizationFor(user.id, project);
        if (!organizationId) return response(409, { success: false, error: "Workspace membership is not configured. Run the tenant migration." });
        if (method === "GET") {
            const rows = await projects.supabaseRequest(`/rest/v1/business_profiles?project_id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(user.id)}&select=id,organization_id,project_id,revision,profile,audit,created_at,updated_at&limit=1`);
            return response(200, { success: true, profile: Array.isArray(rows) ? rows[0] || null : null, organizationId });
        }
        const payload = profilePayload(input, user.id, organizationId, id);
        const currentRows = await projects.supabaseRequest(`/rest/v1/business_profiles?project_id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(user.id)}&select=id,revision&limit=1`);
        const current = Array.isArray(currentRows) ? currentRows[0] : null;
        const expected = input.expectedRevision === undefined ? null : Number(input.expectedRevision);
        if (expected !== null && (!Number.isSafeInteger(expected) || Number(current?.revision || 0) !== expected)) return response(409, { success: false, code: "PROFILE_CONFLICT", error: "The Business Profile changed elsewhere.", revision: current?.revision || 0 });
        const path = current
            ? `/rest/v1/business_profiles?id=eq.${encodeURIComponent(current.id)}&project_id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(user.id)}`
            : "/rest/v1/business_profiles";
        const separator = path.includes("?") ? "&" : "?";
        const result = await projects.supabaseRequest(`${path}${separator}select=id,organization_id,project_id,revision,profile,audit,created_at,updated_at`, { method: current ? "PATCH" : "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) });
        const saved = Array.isArray(result) ? result[0] : null;
        if (!saved) throw new Error("PROFILE_NOT_SAVED");
        await projects.supabaseRequest("/rest/v1/profile_revisions", { method: "POST", body: JSON.stringify({ organization_id: organizationId, project_id: id, profile_id: saved.id, revision: payload.revision, profile: payload.profile, updated_by: user.id, change_source: input.changeSource || "profile-page" }) });
        await projects.supabaseRequest("/rest/v1/activity_events", { method: "POST", body: JSON.stringify({ organization_id: organizationId, project_id: id, actor_id: user.id, event_type: "business_profile.updated", entity_type: "business_profile", entity_id: saved.id, payload: { revision: payload.revision, changeSource: input.changeSource || "profile-page" } }) });
        return response(200, { success: true, profile: saved, organizationId });
    } catch (error) {
        const code = error.message || "";
        if (code === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (["INVALID_BODY", "INVALID_PROJECT", "INVALID_CONTEXT", "INVALID_PROFILE"].includes(code)) return response(400, { success: false, error: "The Business Profile request is invalid." });
        if (code === "NOT_CONFIGURED") return response(503, { success: false, error: "Supabase is not configured." });
        console.error("Business Profile API error:", error);
        return response(500, { success: false, error: "The Business Profile request failed." });
    }
};
