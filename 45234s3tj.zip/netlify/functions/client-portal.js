"use strict";

const crypto = require("crypto");
const { response, request, authenticate, body, uuid, clean, guard, config } = require("./_platform.js");
const { requestId } = require("./_request-context.js");
const { auditEvent } = require("./_ops.js");

const PORTAL_COOKIE = "__Host-morrow_portal";
const MAX_COMMENTS_PER_SHARE = 100;
function hash(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function token() { return crypto.randomBytes(32).toString("base64url"); }
function query(event) { return event.queryStringParameters || {}; }
function cookie(event, name) {
    const header = Object.entries(event.headers || {}).find(([key]) => key.toLowerCase() === "cookie")?.[1] || "";
    const match = String(header).split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
    return match ? decodeURIComponent(match.slice(name.length + 1)) : "";
}
function portalToken(event) { return clean(query(event).token, 200) || clean(cookie(event, PORTAL_COOKIE), 200); }
function portalCookie(rawToken, expiresAt) {
    const seconds = Math.max(0, Math.min(30 * 86400, Math.floor((Date.parse(expiresAt) - Date.now()) / 1000)));
    return `${PORTAL_COOKIE}=${encodeURIComponent(rawToken)}; Path=/; Max-Age=${seconds}; HttpOnly; Secure; SameSite=Strict`;
}
function clearPortalCookie() {
    return `${PORTAL_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict`;
}
function portalHeaders(event, rawToken, share) {
    return query(event).token ? { "Set-Cookie": portalCookie(rawToken, share.expires_at) } : {};
}
function publicPayload(value) {
    if (!value || typeof value !== "object" || value.clientVisible !== true) return null;
    return { title: clean(value.title || value.name || "", 160), status: clean(value.status || "", 60), progress: Number.isFinite(Number(value.progress)) ? Math.max(0, Math.min(100, Number(value.progress))) : null, dueDate: clean(value.dueDate || value.deadline || "", 40), url: clean(value.publicUrl || value.url || "", 1000), fileName: clean(value.fileName || value.name || "", 240), mimeType: clean(value.mimeType || "", 120), byteSize: Number(value.byteSize) || null };
}
async function projectScope(projectId) {
    const rows = await request(`/rest/v1/projects?id=eq.${encodeURIComponent(projectId)}&select=id,name,work_context_id,organization_id&limit=1`);
    const project = Array.isArray(rows) ? rows[0] : null;
    if (!project?.work_context_id || !project?.organization_id) throw new Error("PORTAL_UNAVAILABLE");
    const contexts = await request(`/rest/v1/work_contexts?id=eq.${encodeURIComponent(project.work_context_id)}&organization_id=eq.${encodeURIComponent(project.organization_id)}&status=eq.active&select=id&limit=1`);
    if (!Array.isArray(contexts) || !contexts[0]) throw new Error("PORTAL_UNAVAILABLE");
    return project;
}
async function shareForToken(rawToken) {
    const rows = await request(`/rest/v1/client_portal_shares?token_hash=eq.${encodeURIComponent(hash(rawToken))}&select=id,project_id,created_by,expires_at,revoked_at&limit=1`);
    const share = Array.isArray(rows) ? rows[0] : null;
    if (!share || share.revoked_at || Date.parse(share.expires_at) <= Date.now()) throw new Error("PORTAL_UNAVAILABLE");
    await projectScope(share.project_id);
    return share;
}
async function ownerProject(userId, projectId) {
    const project = await projectScope(projectId);
    const members = await request(`/rest/v1/organization_members?organization_id=eq.${encodeURIComponent(project.organization_id)}&user_id=eq.${encodeURIComponent(userId)}&status=eq.active&revoked_at=is.null&select=user_id&limit=1`);
    const roles = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}&select=role&limit=1`);
    if (!Array.isArray(members) || !members[0] || !["owner", "admin"].includes(roles?.[0]?.role)) throw new Error("PROJECT_NOT_FOUND");
    return project;
}
async function handler(event = {}) {
    const blocked = await guard(event, "client-portal", 60); if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "POST", "DELETE"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const q = query(event);
        const correlationId = requestId(event);
        if (method === "POST" && q.action === "create") {
            const user = await authenticate(event); const value = body(event);
            if (!uuid(value.projectId)) return response(400, { success: false, error: "A valid project is required." });
            await ownerProject(user.id, value.projectId);
            const raw = token();
            const rows = await request("/rest/v1/client_portal_shares", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ project_id: value.projectId, created_by: user.id, token_hash: hash(raw), label: clean(value.label || "Client portal", 120), expires_at: new Date(Date.now() + 30 * 86400000).toISOString() }) });
            const share = Array.isArray(rows) ? rows[0] : rows;
            if (!share?.id) throw new Error("PORTAL_CREATE_FAILED");
            await auditEvent(request, { request_id: correlationId, actor_id: user.id, project_id: value.projectId, action: "portal.created", result: "succeeded", metadata: { shareId: share.id, expiresAt: share.expires_at } });
            return response(201, { success: true, share, token: raw, path: `/portal.html?token=${encodeURIComponent(raw)}` });
        }
        const raw = portalToken(event);
        if (!raw) return response(404, { success: false, error: "This client portal link is invalid, expired, or revoked." }, { "Set-Cookie": clearPortalCookie() }, event);
        const share = await shareForToken(raw);
        const sessionHeaders = portalHeaders(event, raw, share);
        if (method === "DELETE") {
            const user = await authenticate(event);
            const removed = await request(`/rest/v1/client_portal_shares?id=eq.${encodeURIComponent(share.id)}&project_id=eq.${encodeURIComponent(share.project_id)}&created_by=eq.${encodeURIComponent(user.id)}&select=id`, { method: "DELETE", headers: { Prefer: "return=representation" } });
            if (!Array.isArray(removed) || !removed.length) return response(404, { success: false, error: "This client portal link is invalid, expired, or revoked." });
            await auditEvent(request, { request_id: correlationId, actor_id: user.id, project_id: share.project_id, action: "portal.revoked", result: "succeeded", metadata: { shareId: share.id } });
            return response(200, { success: true }, { "Set-Cookie": clearPortalCookie() }, event);
        }
        if (method === "POST") {
            const value = body(event); const comment = clean(value.comment, 4000);
            if (!comment) return response(400, { success: false, error: "A comment is required." }, sessionHeaders, event);
            const rows = await request("/rest/v1/rpc/create_client_portal_comment", { method: "POST", body: JSON.stringify({ p_share_id: share.id, p_project_id: share.project_id, p_author_name: clean(value.authorName || "Client", 500), p_comment: comment, p_max_comments: MAX_COMMENTS_PER_SHARE }) });
            const created = Array.isArray(rows) ? rows[0] : rows;
            if (!created?.id) throw new Error("PORTAL_COMMENT_FAILED");
            await auditEvent(request, { request_id: correlationId, actor_id: null, project_id: share.project_id, action: "portal.comment_created", result: "succeeded", metadata: { shareId: share.id, commentId: created.id } });
            return response(201, { success: true, comment: created }, sessionHeaders, event);
        }
        const touched = await request(`/rest/v1/client_portal_shares?id=eq.${encodeURIComponent(share.id)}&project_id=eq.${encodeURIComponent(share.project_id)}&revoked_at=is.null&expires_at=gt.${encodeURIComponent(new Date().toISOString())}&select=id`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ last_accessed_at: new Date().toISOString() }) });
        if (!Array.isArray(touched) || !touched[0]) throw new Error("PORTAL_UNAVAILABLE");
        await auditEvent(request, { request_id: correlationId, actor_id: null, project_id: share.project_id, action: "portal.viewed", result: "succeeded", metadata: { shareId: share.id } });
        const activeProject = await projectScope(share.project_id);
        const projects = await request(`/rest/v1/projects?id=eq.${encodeURIComponent(share.project_id)}&work_context_id=eq.${encodeURIComponent(activeProject.work_context_id)}&select=id,name,preview_mode,updated_at&limit=1`);
        if (!Array.isArray(projects) || !projects[0]) throw new Error("PORTAL_UNAVAILABLE");
        const operations = await request(`/rest/v1/business_operations?project_id=eq.${encodeURIComponent(share.project_id)}&select=id,kind,payload,updated_at&order=updated_at.desc&limit=200`);
        const items = (Array.isArray(operations) ? operations : []).map((item) => { const payload = publicPayload(item.payload); return payload ? { id: item.id, kind: item.kind, updatedAt: item.updated_at, ...payload } : null; }).filter(Boolean);
        const files = await request(`/rest/v1/project_file_versions?project_id=eq.${encodeURIComponent(share.project_id)}&client_visible=eq.true&verification_status=eq.verified&select=id,file_id,version,file_name,mime_type,byte_size,storage_path,created_at&order=created_at.desc&limit=100`);
        const { url, key } = config();
        const sharedFiles = await Promise.all((Array.isArray(files) ? files : []).map(async (file) => {
            const signed = await fetch(`${url}/storage/v1/object/sign/project-files/${file.storage_path}`, { method: "POST", headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" }, body: JSON.stringify({ expiresIn: 600 }) });
            const signedData = await signed.json().catch(() => ({}));
            return { id: file.id, fileId: file.file_id, version: file.version, fileName: file.file_name, mimeType: file.mime_type, byteSize: file.byte_size, downloadUrl: signed.ok && signedData.signedURL ? `${url}/storage/v1${signedData.signedURL}` : null, createdAt: file.created_at };
        }));
        const comments = await request(`/rest/v1/client_portal_comments?share_id=eq.${encodeURIComponent(share.id)}&select=id,author_name,comment,created_at&order=created_at.asc&limit=100`);
        return response(200, { success: true, project: projects[0] || null, items, files: sharedFiles.filter((file) => file.downloadUrl), comments: Array.isArray(comments) ? comments : [] }, sessionHeaders, event);
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "PROJECT_NOT_FOUND") return response(404, { success: false, error: "Project not found." });
        if (error.message === "PORTAL_UNAVAILABLE") return response(404, { success: false, error: "This client portal link is invalid, expired, or revoked." }, { "Set-Cookie": clearPortalCookie() }, event);
        if (error.message === "PORTAL_COMMENT_LIMIT") return response(409, { success: false, code: "PORTAL_COMMENT_LIMIT", error: "This portal has reached its comment limit." });
        if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The portal request is invalid." });
        console.error("Client portal API error:", error.message || error);
        return response(500, { success: false, error: "The client portal request failed." });
    }
}
exports.handler = handler;
