"use strict";

const {
    limitedResponseAsync,
    securityHeaders,
    requestId
} = require("./_security.js");

function response(statusCode, payload, extraHeaders = {}, event = {}) {
    const id = requestId(event);
    const safePayload = payload && typeof payload === "object" && !Array.isArray(payload)
        ? { ...payload, requestId: payload.requestId || id }
        : payload;
    return {
        statusCode,
        isBase64Encoded: false,
        headers: securityHeaders({ ...extraHeaders, "X-Request-ID": id }),
        body: JSON.stringify(safePayload)
    };
}

function present(name) {
    return String(process.env[name] || "").trim();
}

function validPublicKey(value) {
    return typeof value === "string" && value.length > 0 && value.length <= 10000 && !/[\u0000-\u001f\u007f]/.test(value);
}

function forbiddenBrowserKey(value) {
    const normalized = String(value || "").toLowerCase();
    return normalized.includes("service_role") || normalized.startsWith("sb_secret_");
}

function validSupabaseUrl(value) {
    try {
        const parsed = new URL(value);
        return parsed.protocol === "https:" && !parsed.username && !parsed.password && !parsed.port && parsed.pathname === "/" && !parsed.search && !parsed.hash && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.supabase\.co$/i.test(parsed.hostname);
    } catch {
        return false;
    }
}

function validHttpsUrl(value, options = {}) {
    try {
        const parsed = new URL(value);
        return parsed.protocol === "https:" && !parsed.username && !parsed.password && !parsed.hash && (!options.allowPath ? parsed.pathname === "/" && !parsed.search : true);
    } catch {
        return false;
    }
}

function validHostList(value) {
    const hosts = String(value || "").split(",").map((host) => host.trim()).filter(Boolean);
    return hosts.length > 0 && hosts.every((host) => /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i.test(host));
}

function capabilityReport() {
    const supabaseUrl = present("SUPABASE_URL");
    const browserKey = present("SUPABASE_ANON_KEY") || present("SUPABASE_PUBLISHABLE_KEY");
    const publicOrigin = present("PUBLIC_SITE_ORIGIN");
    const webhookUrl = present("LEADS_WEBHOOK_URL");
    const webhookHosts = present("LEADS_WEBHOOK_HOSTS");
    const aiUrl = present("WEBSITE_AI_URL");
    const aiHosts = present("WEBSITE_AI_ALLOWED_HOSTS");
    const aiHostAllowed = (() => {
        try { return aiHosts.split(",").map((host) => host.trim().toLowerCase()).includes(new URL(aiUrl).hostname.toLowerCase()); } catch { return false; }
    })();
    const checks = {
        SUPABASE_URL: supabaseUrl ? (validSupabaseUrl(supabaseUrl) ? "ready" : "invalid") : "missing",
        SUPABASE_ANON_KEY: browserKey ? (validPublicKey(browserKey) && !forbiddenBrowserKey(browserKey) ? "ready" : "invalid") : "missing",
        PUBLIC_SITE_ORIGIN: publicOrigin ? (validHttpsUrl(publicOrigin) ? "ready" : "invalid") : "missing",
        LEADS_WEBHOOK_URL: webhookUrl ? (validHttpsUrl(webhookUrl, { allowPath: true }) ? "ready" : "invalid") : "missing",
        LEADS_WEBHOOK_HOSTS: webhookHosts ? (validHostList(webhookHosts) ? "ready" : "invalid") : "missing",
        WEBSITE_AI_URL: aiUrl ? (validHttpsUrl(aiUrl, { allowPath: true }) && aiHostAllowed ? "ready" : "invalid") : "missing",
        WEBSITE_AI_ALLOWED_HOSTS: aiHosts ? (validHostList(aiHosts) ? "ready" : "invalid") : "missing"
    };
    const capabilities = {
        cloudProjects: checks.SUPABASE_URL === "ready" && checks.SUPABASE_ANON_KEY === "ready",
        websiteImport: Boolean(present("SCRAPINGBEE_API_KEY")),
        searchDiscovery: Boolean(present("BRAVE_SEARCH_API_KEY")),
        mobileAuditQuota: Boolean(present("PAGESPEED_API_KEY")),
        deployment: Boolean(present("NETLIFY_AUTH_TOKEN") && present("NETLIFY_SITE_ID") && checks.PUBLIC_SITE_ORIGIN === "ready"),
        signedPreflight: Boolean(present("PREFLIGHT_SIGNING_SECRET")),
        emailDelivery: Boolean(present("RESEND_API_KEY") && present("RESEND_FROM_EMAIL")),
        distributedRateLimit: Boolean(present("UPSTASH_REDIS_REST_URL") && present("UPSTASH_REDIS_REST_TOKEN")),
        leadWebhook: checks.LEADS_WEBHOOK_URL === "ready" && checks.LEADS_WEBHOOK_HOSTS === "ready",
        aiWebsiteGeneration: checks.WEBSITE_AI_URL === "ready" && checks.WEBSITE_AI_ALLOWED_HOSTS === "ready" && Boolean(present("WEBSITE_AI_API_KEY") && present("WEBSITE_AI_MODEL"))
    };
    const optionalRequirements = {
        websiteImport: "SCRAPINGBEE_API_KEY",
        searchDiscovery: "BRAVE_SEARCH_API_KEY",
        mobileAuditQuota: "PAGESPEED_API_KEY",
        deployment: "NETLIFY_AUTH_TOKEN, NETLIFY_SITE_ID, PUBLIC_SITE_ORIGIN",
        signedPreflight: "PREFLIGHT_SIGNING_SECRET",
        emailDelivery: "RESEND_API_KEY, RESEND_FROM_EMAIL",
        distributedRateLimit: "UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN",
        leadWebhook: "LEADS_WEBHOOK_URL, LEADS_WEBHOOK_HOSTS",
        aiWebsiteGeneration: "WEBSITE_AI_URL, WEBSITE_AI_API_KEY, WEBSITE_AI_MODEL, WEBSITE_AI_ALLOWED_HOSTS"
    };
    const optionalUnavailable = Object.entries(optionalRequirements).filter(([name]) => !capabilities[name]).map(([name, variables]) => ({ capability: name, variables }));
    const requiredMissing = ["SUPABASE_URL", "SUPABASE_ANON_KEY or SUPABASE_PUBLISHABLE_KEY"].filter((name) => name.startsWith("SUPABASE_URL") ? checks.SUPABASE_URL === "missing" : checks.SUPABASE_ANON_KEY === "missing");
    const invalid = Object.entries(checks).filter(([, status]) => status === "invalid").map(([name]) => name);
    return { checks, capabilities, optionalUnavailable, requiredMissing, invalid };
}

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "config", limit: 30, windowMs: 60_000 });
    if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "GET") return response(405, { success: false, error: "Only GET requests are supported." }, { Allow: "GET" }, event);

    const report = capabilityReport();
    const cloudReady = report.capabilities.cloudProjects;
    const hasConfigurationErrors = report.requiredMissing.length > 0 || report.invalid.length > 0;
    const payload = {
        success: cloudReady && !hasConfigurationErrors,
        staticExportAvailable: true,
        error: cloudReady && !hasConfigurationErrors ? undefined : "Some optional or cloud capabilities need configuration; static export remains available.",
        capabilities: report.capabilities,
        configuration: { checks: report.checks, requiredMissing: report.requiredMissing, invalid: report.invalid },
        optionalUnavailable: report.optionalUnavailable,
        readiness: cloudReady && !hasConfigurationErrors ? "configured" : "configuration-needed"
    };
    if (report.capabilities.cloudProjects) {
        payload.url = new URL(present("SUPABASE_URL")).origin;
        payload.key = present("SUPABASE_ANON_KEY") || present("SUPABASE_PUBLISHABLE_KEY");
    }
    return response(cloudReady && !hasConfigurationErrors ? 200 : 503, payload, {}, event);
};

exports.capabilityReport = capabilityReport;
