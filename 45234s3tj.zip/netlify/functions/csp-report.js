"use strict";

const { limitedResponse, maxBodyResponse, securityHeaders, requestId } = require("./_security.js");

function response(statusCode, payload, event = {}) {
    const id = requestId(event);
    return {
        statusCode,
        isBase64Encoded: false,
        headers: securityHeaders({ "X-Request-ID": id }),
        body: payload === undefined ? "" : JSON.stringify({ ...payload, requestId: id })
    };
}

exports.handler = async function handler(event = {}) {
    const blocked = limitedResponse(event, { namespace: "csp-report", limit: 60, windowMs: 60_000 });
    if (blocked) return blocked;
    const oversized = maxBodyResponse(event, 32_000);
    if (oversized) return oversized;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") {
        return response(405, { success: false, error: "Only POST requests are supported." }, event);
    }
    try {
        const raw = Buffer.from(String(event.body || ""), event.isBase64Encoded ? "base64" : "utf8").toString("utf8");
        const report = JSON.parse(raw || "{}");
        console.warn("CSP violation", JSON.stringify({
            documentUri: String(report["csp-report"]?.["document-uri"] || report.body?.documentURL || "").slice(0, 500),
            violatedDirective: String(report["csp-report"]?.["violated-directive"] || report.body?.violatedDirective || "").slice(0, 200),
            blockedUri: String(report["csp-report"]?.["blocked-uri"] || report.body?.blockedURL || "").slice(0, 300)
        }));
    } catch {}
    return response(204, undefined, event);
};
