"use strict";

const {
    limitedResponseAsync,
    jsonResponse,
    securityHeaders,
    requestId
} = require("./_security.js");
const zlib = require("node:zlib");
const { reserveQuota, commitQuota, releaseQuota, quotaMetadata, quotaResponse } = require("./_quota.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { deploymentAdapter, providerClient } = require("./provider-adapters.js");
const { log } = require("./_ops.js");
const { validateFiles, validateRevision } = require("../../workspace-server-validation.js");
const { validateOutput } = require("../../workspace-output-contract.js");

const DEPLOY_SECURITY_HEADERS = securityHeaders();

// Base64 expands an 8 MB archive to roughly 10.7 MB.
const MAX_BODY_BYTES = 12_000_000;
const MAX_DEPLOY_BYTES = 8_000_000;
const MAX_ZIP_ENTRIES = 80;
const MAX_ENTRY_UNCOMPRESSED_BYTES = 2_000_000;
const MAX_TOTAL_UNCOMPRESSED_BYTES = 10_000_000;
const ALLOWED_ZIP_PATH = /^(?:[a-z0-9][a-z0-9._-]{0,119}\.(?:html?|css|js|json|toml|txt|xml|svg|png|jpe?g|webp|avif|gif|ico|woff2?|map)|(?:assets|images|fonts)\/[a-z0-9][a-z0-9._-]{0,119}\.(?:svg|png|jpe?g|webp|avif|gif|ico|woff2?|map)|netlify\/functions\/[a-z0-9][a-z0-9._-]{0,119}\.js)$/i;
const UPSTREAM_TIMEOUT_MS = 10_000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function createResponse(event = {}, correlationId = requestId(event)) {
    return (statusCode, payload, headers = {}) => jsonResponse(statusCode, { ...payload, requestId: correlationId }, { ...DEPLOY_SECURITY_HEADERS, ...headers, "X-Request-ID": correlationId }, event);
}

function header(event, name) {
    const headers = event?.headers || {};
    const key = Object.keys(headers).find((entry) => entry.toLowerCase() === name.toLowerCase());
    return key ? String(headers[key] || "") : "";
}

function config() {
    const token = String(process.env.NETLIFY_AUTH_TOKEN || "").trim();
    const siteId = String(process.env.NETLIFY_SITE_ID || "").trim();
    if (!token || !siteId) throw new Error("NOT_CONFIGURED");
    return { token, siteId };
}

function createDeploymentProvider(event = {}) {
    return deploymentAdapter("netlify", process.env, {
        requestId: requestId(event),
        retries: 2,
        timeoutMs: UPSTREAM_TIMEOUT_MS
    });
}

function createSupabaseProvider(event = {}, retries = 0) {
    return providerClient("supabase", {
        endpoint: String(process.env.SUPABASE_URL || "").trim().replace(/\/$/, ""),
        requestId: requestId(event),
        retries,
        timeoutMs: UPSTREAM_TIMEOUT_MS
    });
}

async function authorizeDeployment(supabase, event, user, deploymentId, projectId, allowedRoles = ["owner", "admin"]) {
    if (!UUID.test(String(projectId || ""))) return null;
    const authorization = header(event, "authorization");
    const apikey = String(process.env.SUPABASE_ANON_KEY || "").trim();
    const membership = await supabase.request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(user.id)}&role=in.(${allowedRoles.join(",")})&select=role&limit=1`, {
        headers: { apikey, Authorization: authorization }
    });
    if (!Array.isArray(membership.data) || !membership.data.length) return null;
    const deployments = await supabase.request(`/rest/v1/platform_deployments?project_id=eq.${encodeURIComponent(projectId)}&provider_deployment_id=eq.${encodeURIComponent(deploymentId)}&select=id,project_id,provider_deployment_id,status&limit=1`, {
        headers: { apikey, Authorization: authorization }
    });
    return Array.isArray(deployments.data) ? deployments.data[0] || null : null;
}

async function auditDeployment(supabase, event, payload) {
    try {
        await supabase.request("/rest/v1/platform_audit_events", {
            method: "POST",
            headers: { Prefer: "return=minimal", Authorization: header(event, "authorization") },
            body: JSON.stringify(payload)
        });
    } catch (error) {
        log("deployment.audit_failed", {
            requestId: requestId(event),
            actorId: payload?.actor_id,
            projectId: payload?.project_id,
            operation: payload?.action,
            provider: "supabase",
            outcome: "failed",
            retryable: true
        });
    }
}

async function recordDeploymentResult({ supabase, event, userId, projectId, revisionId, deploymentId, deploymentStatus, publicUrl }) {
    if (!revisionId || !deploymentId) return { success: true, retryable: false };
    try {
        await supabase.request(`/rest/v1/site_revisions?id=eq.${encodeURIComponent(revisionId)}&user_id=eq.${encodeURIComponent(userId)}`, {
            method: "PATCH",
            headers: { Prefer: "return=minimal", Authorization: header(event, "authorization") },
            body: JSON.stringify({ deployment_id: deploymentId, status: deploymentStatus })
        });
        if (UUID.test(String(projectId || ""))) {
            await supabase.request(`/rest/v1/project_environments?project_id=eq.${encodeURIComponent(projectId)}&environment=eq.production`, {
                method: "PATCH",
                headers: { Prefer: "return=minimal", Authorization: header(event, "authorization") },
                body: JSON.stringify({ status: deploymentStatus === "deployed" ? "deployed" : "failed", current_revision: revisionId, public_url: publicUrl })
            });
        }
        return { success: true, retryable: false };
    } catch {
        log("deployment.recording_failed", {
            requestId: requestId(event),
            actorId: userId,
            projectId,
            operation: "deployment.record",
            provider: "supabase",
            outcome: "failed",
            retryable: true
        });
        return { success: false, retryable: true };
    }
}

// Validate the ZIP directory structure before forwarding the archive upstream.
// This is intentionally bounded to the already limited in-memory payload.
function crc32(buffer) {
    let crc = 0xffffffff;
    for (const byte of buffer) {
        crc ^= byte;
        for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
    return (crc ^ 0xffffffff) >>> 0;
}

function inspectZipArchive(zip) {
    const fail = (code, message, file = "") => ({ valid: false, issues: [{ code, file, message }] });
    if (!Buffer.isBuffer(zip) || zip.length < 22) return fail("INVALID_ZIP", "The deployment payload is not a valid ZIP archive.");

    const minimumEnd = Math.max(0, zip.length - 65_557);
    let endOffset = -1;
    for (let cursor = zip.length - 22; cursor >= minimumEnd; cursor -= 1) {
        if (zip.readUInt32LE(cursor) === 0x06054b50 && cursor + 22 + zip.readUInt16LE(cursor + 20) === zip.length) {
            endOffset = cursor;
            break;
        }
    }
    if (endOffset < 0) return fail("INVALID_ZIP", "The ZIP central directory is missing or malformed.");

    const disk = zip.readUInt16LE(endOffset + 4);
    const directoryDisk = zip.readUInt16LE(endOffset + 6);
    const entries = zip.readUInt16LE(endOffset + 10);
    const entriesOnDisk = zip.readUInt16LE(endOffset + 8);
    const directorySize = zip.readUInt32LE(endOffset + 12);
    const directoryOffset = zip.readUInt32LE(endOffset + 16);
    if (disk || directoryDisk || entries !== entriesOnDisk || directoryOffset + directorySize > endOffset) return fail("INVALID_ZIP", "The ZIP uses unsupported disks or directory offsets.");
    if (entries > MAX_ZIP_ENTRIES) return fail("ZIP_ENTRY_LIMIT", "The deployment archive contains too many files.");

    let offset = directoryOffset;
    let totalUncompressed = 0;
    const files = {};
    const paths = new Set();
    for (let index = 0; index < entries; index += 1) {
        if (offset + 46 > endOffset || zip.readUInt32LE(offset) !== 0x02014b50) return fail("INVALID_ZIP", "The ZIP central directory entry is malformed.");
        const filenameLength = zip.readUInt16LE(offset + 28);
        const extraLength = zip.readUInt16LE(offset + 30);
        const commentLength = zip.readUInt16LE(offset + 32);
        if (offset + 46 + filenameLength + extraLength + commentLength > endOffset) return fail("INVALID_ZIP", "The ZIP entry metadata exceeds the archive boundary.");

        const filename = zip.toString("utf8", offset + 46, offset + 46 + filenameLength);
        const normalized = filename.replace(/\\/g, "/");
        const externalAttributes = zip.readUInt32LE(offset + 38);
        const method = zip.readUInt16LE(offset + 10);
        const compressedSize = zip.readUInt32LE(offset + 20);
        const uncompressedSize = zip.readUInt32LE(offset + 24);
        const crc = zip.readUInt32LE(offset + 16);
        const localOffset = zip.readUInt32LE(offset + 42);
        if (!filename || normalized !== filename || normalized.startsWith("/") || normalized.includes("../") || normalized.includes("/./") || !ALLOWED_ZIP_PATH.test(normalized) || paths.has(normalized) || (externalAttributes & 0x80000000) !== 0 || uncompressedSize > MAX_ENTRY_UNCOMPRESSED_BYTES || (totalUncompressed += uncompressedSize) > MAX_TOTAL_UNCOMPRESSED_BYTES) return fail("UNSAFE_ZIP_ENTRY", "The archive contains an unsafe, duplicate, or oversized path.", filename);
        if (![0, 8].includes(method)) return fail("UNSUPPORTED_COMPRESSION", "The archive uses an unsupported compression method.", filename);
        paths.add(normalized);

        if (localOffset + 30 > directoryOffset || zip.readUInt32LE(localOffset) !== 0x04034b50) return fail("INVALID_ZIP", "The ZIP local file header is invalid.", filename);
        const localFilenameLength = zip.readUInt16LE(localOffset + 26);
        const localExtraLength = zip.readUInt16LE(localOffset + 28);
        const dataOffset = localOffset + 30 + localFilenameLength + localExtraLength;
        const localFilename = zip.toString("utf8", localOffset + 30, localOffset + 30 + localFilenameLength);
        if (localFilename !== filename || dataOffset > directoryOffset || compressedSize > directoryOffset - dataOffset) return fail("INVALID_ZIP", "The ZIP entry data is outside the archive boundary.", filename);

        const compressed = zip.subarray(dataOffset, dataOffset + compressedSize);
        let content;
        try {
            content = method === 0 ? Buffer.from(compressed) : zlib.inflateRawSync(compressed, { maxOutputLength: MAX_ENTRY_UNCOMPRESSED_BYTES });
        } catch {
            return fail("INVALID_ZIP_CONTENT", "The ZIP entry could not be safely decompressed.", filename);
        }
        if (content.length !== uncompressedSize || crc32(content) !== crc) return fail("ZIP_CHECKSUM_MISMATCH", "The ZIP entry failed size or checksum validation.", filename);
        files[normalized] = content;
        offset += 46 + filenameLength + extraLength + commentLength;
    }
    if (offset !== directoryOffset + directorySize) return fail("INVALID_ZIP", "The ZIP central directory length is inconsistent.");
    if (!files["index.html"] || !files["netlify.toml"]) return fail("MISSING_REQUIRED_FILE", "The deployment archive must contain index.html and netlify.toml.");
    if (/<form\b/i.test(files["index.html"].toString("utf8")) && !files["netlify/functions/submit-form.js"]) return fail("FORM_HANDLER_MISSING", "A deployed contact form requires netlify/functions/submit-form.js.", "netlify/functions/submit-form.js");

    const textFiles = Object.fromEntries(Object.entries(files).filter(([name]) => /\.(?:html?|css|js|json|toml|txt|xml|svg|map)$/i.test(name)).map(([name, content]) => [name, content.toString("utf8")]));
    const contentIssues = validateFiles(textFiles, { requireDeploymentConfig: true, requireFormHandler: true });
    const output = validateOutput(textFiles);
    const outputIssues = output.issues.map((issue) => ({ ...issue, source: "server-deployment" }));
    return contentIssues.length || outputIssues.some((issue) => issue.severity === "blocking")
        ? { valid: false, issues: [...contentIssues, ...outputIssues] }
        : { valid: true, files: textFiles, paths: [...paths], warnings: outputIssues };
}

function authenticatedSupabaseHeaders(event, extra = {}) {
    return { ...extra, apikey: String(process.env.SUPABASE_ANON_KEY || "").trim(), Authorization: header(event, "authorization") };
}

async function authenticate(event) {
    const authorization = header(event, "authorization");
    const supabaseUrl = String(process.env.SUPABASE_URL || "").trim();
    const supabaseKey = String(process.env.SUPABASE_ANON_KEY || "").trim();

    if (!/^Bearer\s+\S+$/i.test(authorization) || !supabaseUrl || !supabaseKey) {
        throw new Error("UNAUTHORIZED");
    }

    let parsedUrl;
    try {
        parsedUrl = new URL(supabaseUrl);
    } catch {
        throw new Error("UNAUTHORIZED");
    }

    if (
        parsedUrl.protocol !== "https:" ||
        parsedUrl.username ||
        parsedUrl.password ||
        parsedUrl.port ||
        parsedUrl.pathname !== "/" ||
        parsedUrl.search ||
        parsedUrl.hash ||
        !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.supabase\.co$/i.test(parsedUrl.hostname)
    ) {
        throw new Error("UNAUTHORIZED");
    }

    try {
        const provider = providerClient("supabase", {
            endpoint: parsedUrl.origin,
            requestId: requestId(event),
            retries: 0,
            timeoutMs: UPSTREAM_TIMEOUT_MS
        });
        const result = await provider.request("/auth/v1/user", {
            headers: {
                apikey: supabaseKey,
                Authorization: authorization
            }
        });
        if (!result.data?.id) throw new Error("UNAUTHORIZED");
        return result.data;
    } catch {
        throw new Error("UNAUTHORIZED");
    }
}

exports.handler = async function handler(event = {}) {
    const correlationId = requestId(event);
    const response = createResponse(event, correlationId);
    const method = String(event.httpMethod || "").toUpperCase();
    let user;
    let quotaRequest;
    let reservation;
    let idempotency;
    let idempotencyOperation = "";
    let idempotencyProjectId = null;
    let operationSucceeded = false;

    if (!["GET", "POST"].includes(method)) {
        return response(405, { success: false, code: "METHOD_NOT_ALLOWED", error: "Only GET and POST are supported." }, { Allow: "GET, POST" });
    }

    if (!/^Bearer\s+\S+$/i.test(header(event, "authorization"))) {
        return response(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." });
    }
    if (method === "POST" && !/^application\/json(?:\s*;|$)/i.test(header(event, "content-type"))) {
        return response(415, { success: false, code: "UNSUPPORTED_MEDIA_TYPE", error: "Content-Type must be application/json." });
    }

    const enforceRateLimit = () => limitedResponseAsync(event, {
        namespace: "deploy",
        limit: 12,
        windowMs: 300_000,
        requireDistributed: true
    });

    try {
        if (method === "GET") {
            const deployId = String(event.queryStringParameters?.id || "").trim();
            const projectId = String(event.queryStringParameters?.projectId || "").trim();
            if (!/^[A-Za-z0-9_-]{1,200}$/.test(deployId) || !UUID.test(projectId)) {
                return response(400, { success: false, code: "INVALID_REQUEST", error: "Valid project and deployment IDs are required." });
            }
            const blocked = await enforceRateLimit();
            if (blocked) return blocked;

            user = await authenticate(event);
            const supabase = createSupabaseProvider(event);
            const deployment = await authorizeDeployment(supabase, event, user, deployId, projectId, ["owner", "admin", "contributor", "client_reviewer"]);
            if (!deployment) return response(404, { success: false, code: "DEPLOYMENT_NOT_FOUND", error: "Deployment not found." });
            const provider = createDeploymentProvider(event);
            const result = (await provider.status(deployId)).data || {};

            return response(200, {
                success: true,
                id: result.id || deployId,
                state: result.state || "unknown",
                url: result.ssl_url || result.deploy_url || result.url || null
            });
        }
        const rollbackId = String(event.queryStringParameters?.rollback || "").trim();
        if (rollbackId) {
            const projectId = String(event.queryStringParameters?.projectId || "").trim();
            if (!/^[A-Za-z0-9_-]{1,200}$/.test(rollbackId) || !UUID.test(projectId)) {
                return response(400, { success: false, code: "INVALID_REQUEST", error: "Valid project and deployment IDs are required for rollback." });
            }
            const blocked = await enforceRateLimit();
            if (blocked) return blocked;
            user = await authenticate(event);
            const supabase = createSupabaseProvider(event);
            const deployment = await authorizeDeployment(supabase, event, user, rollbackId, projectId);
            if (!deployment) return response(404, { success: false, code: "DEPLOYMENT_NOT_FOUND", error: "Deployment not found." });
            quotaRequest = async (path, options = {}) => (await supabase.request(path, { ...options, headers: authenticatedSupabaseHeaders(event, options.headers) })).data;
            idempotencyOperation = "deployment.rollback";
            idempotencyProjectId = projectId;
            const key = idempotencyKey(event, { rollbackId, projectId });
            idempotency = await beginIdempotent({ request: quotaRequest, actorId: user.id, projectId, operation: idempotencyOperation, key, hash: requestHash({ rollbackId, projectId }) });
            if (idempotency.replay) return response(200, { ...idempotency.response, idempotentReplay: true });
            await auditDeployment(supabase, event, { request_id: correlationId, actor_id: user.id, project_id: projectId, action: "deployment.rollback", result: "started", provider_id: rollbackId, metadata: {} });
            const provider = createDeploymentProvider(event);
            const result = (await provider.rollback(rollbackId)).data || {};
            await auditDeployment(supabase, event, { request_id: correlationId, actor_id: user.id, project_id: projectId, action: "deployment.rollback", result: "succeeded", provider_id: rollbackId, metadata: { restoredDeploymentId: result.id || rollbackId } });
            const payload = { success: true, id: result.id || rollbackId, state: result.state || "enqueued", url: result.ssl_url || result.deploy_url || result.url || null, rollback: true };
            await completeIdempotent({ request: quotaRequest, actorId: user.id, projectId, operation: idempotencyOperation, key: idempotency.key, response: payload });
            operationSucceeded = true;
            return response(200, payload);
        }

        const bodyText = String(event.body || "");
        let requestText = bodyText;

        if (event.isBase64Encoded) {
            if (
                !bodyText ||
                bodyText.length % 4 !== 0 ||
                !/^[A-Za-z0-9+/]*={0,2}$/.test(bodyText)
            ) {
                return response(400, { success: false, error: "The deployment request contains invalid JSON." });
            }

            const decodedBody = Buffer.from(bodyText, "base64");
            if (
                decodedBody.toString("base64").replace(/=+$/, "") !==
                bodyText.replace(/=+$/, "")
            ) {
                return response(400, { success: false, error: "The deployment request contains invalid JSON." });
            }

            requestText = decodedBody.toString("utf8");
        }

        if (Buffer.byteLength(requestText, "utf8") > MAX_BODY_BYTES) {
            return response(413, { success: false, error: "The deployment payload is too large." });
        }

        let body;
        try {
            body = JSON.parse(requestText || "{}");
        } catch {
            return response(400, { success: false, error: "The deployment request contains invalid JSON." });
        }

        if (!body || typeof body !== "object" || Array.isArray(body)) {
            return response(400, { success: false, error: "The deployment request contains invalid JSON." });
        }

        // When the client provides the manifest, enforce the same safety and
        // revision contract server-side. The ZIP remains opaque to the provider.
        if (body.files && typeof body.files === "object" && !Array.isArray(body.files)) {
            const fileIssues = validateFiles(body.files, { requireDeploymentConfig: true, requireFormHandler: true });
            const outputIssues = validateOutput(body.files).issues;
            if (fileIssues.length || outputIssues.some((issue) => issue.severity === "blocking")) return response(422, { success: false, code: "UNSAFE_PROJECT", issues: [...fileIssues, ...outputIssues] });
            const revisionCheck = validateRevision(body.files, body.projectRevision || body.revision, body.snapshotMetadata || {});
            if (!revisionCheck.valid) return response(409, { success: false, code: "STALE_REVISION", error: "The project revision is stale. Refresh before deploying.", revision: revisionCheck.actual });
        } else if (body.projectRevision || body.revision) {
            return response(400, { success: false, code: "MISSING_PROJECT_MANIFEST", error: "A project manifest is required when a revision is supplied." });
        }

        const encoded = String(body.zip || "");
        if (!encoded || !/^[A-Za-z0-9+/=]+$/.test(encoded)) {
            return response(400, { success: false, error: "A valid ZIP payload is required." });
        }

        if (
            encoded.length % 4 !== 0 ||
            !/^[A-Za-z0-9+/]*={0,2}$/.test(encoded)
        ) {
            return response(400, { success: false, error: "The deployment payload is not valid base64." });
        }

        const zip = Buffer.from(encoded, "base64");
        const canonicalEncoded = zip.toString("base64").replace(/=+$/, "");
        if (encoded.replace(/=+$/, "") !== canonicalEncoded) {
            return response(400, { success: false, error: "The deployment payload is not valid base64." });
        }

        if (!zip.length || zip.length > MAX_DEPLOY_BYTES) {
            return response(413, { success: false, error: "The deployment ZIP is too large." });
        }
        if (zip.length < 4 || zip[0] !== 0x50 || zip[1] !== 0x4b) {
            return response(400, { success: false, error: "The deployment payload is not a valid ZIP archive." });
        }
        const archive = inspectZipArchive(zip);
        if (!archive.valid) {
            const structural = archive.issues?.[0]?.code === "INVALID_ZIP" || archive.issues?.[0]?.code === "UNSUPPORTED_COMPRESSION" || archive.issues?.[0]?.code === "INVALID_ZIP_CONTENT" || archive.issues?.[0]?.code === "ZIP_CHECKSUM_MISMATCH";
            return response(structural ? 400 : 422, { success: false, code: "UNSAFE_ARCHIVE", issues: archive.issues });
        }
        if (body.files && typeof body.files === "object" && !Array.isArray(body.files)) {
            const manifestFiles = body.files;
            const archiveNames = Object.keys(archive.files).sort();
            const manifestNames = Object.keys(manifestFiles).filter((name) => String(manifestFiles[name] ?? "").trim()).sort();
            const namesMatch = archiveNames.length === manifestNames.length && archiveNames.every((name, index) => name === manifestNames[index]);
            const contentsMatch = namesMatch && archiveNames.every((name) => {
                if (!/\.(?:html?|css|js|json|toml|txt|xml|svg|map)$/i.test(name)) return true;
                return archive.files[name].toString("utf8") === String(manifestFiles[name] ?? "");
            });
            if (!namesMatch || !contentsMatch) {
                return response(409, { success: false, code: "MANIFEST_ARCHIVE_MISMATCH", error: "The uploaded archive does not match the validated project manifest." });
            }
        }

        config();
        const blocked = await enforceRateLimit();
        if (blocked) return blocked;
        user = await authenticate(event);
        const supabase = createSupabaseProvider(event);
        quotaRequest = async (path, options = {}) => {
            const result = await supabase.request(path, { ...options, headers: authenticatedSupabaseHeaders(event, options.headers) });
            return result.data;
        };
        const projectId = UUID.test(String(body.projectId || "")) ? String(body.projectId) : null;
        idempotencyOperation = "deployment.create";
        idempotencyProjectId = projectId;
        const key = idempotencyKey(event, body);
        idempotency = await beginIdempotent({ request: quotaRequest, actorId: user.id, projectId, operation: idempotencyOperation, key, hash: requestHash({ zip: encoded, projectId, revisionId: body.revisionId || null }) });
        if (idempotency.replay) return response(200, { ...idempotency.response, idempotentReplay: true });
        reservation = await reserveQuota({ request: quotaRequest, userId: user.id, resource: "deployments" });
        log("quota.reserved", { requestId: correlationId, actorId: user.id, projectId, resource: "deployments", operation: idempotencyOperation, outcome: "reserved" });
        const provider = deploymentAdapter("netlify", process.env, {
            requestId: requestId(event),
            retries: 2,
            timeoutMs: UPSTREAM_TIMEOUT_MS
        });
        const result = (await provider.deploy(zip)).data || {};
        const deploymentId = result.id || null;
        const revisionId = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(body.revisionId || "")) ? body.revisionId : "";
        const deploymentStatus = result.state === "error" || result.state === "failed" ? "validation-failed" : "deployed";
        const recording = await recordDeploymentResult({
            supabase,
            event,
            userId: user.id,
            projectId,
            revisionId,
            deploymentId,
            deploymentStatus,
            publicUrl: result.ssl_url || result.deploy_url || result.url || null
        });

        const payload = {
            success: true,
            id: result.id || null,
            revisionId: revisionId || null,
            state: result.state || "enqueued",
            url: result.ssl_url || result.deploy_url || result.url || null,
            recording,
            retryable: result.state === "error" || result.state === "failed" ? false : undefined,
            quota: quotaMetadata(reservation, "deployments")
        };
        await completeIdempotent({ request: quotaRequest, actorId: user.id, projectId: idempotencyProjectId, operation: idempotencyOperation, key: idempotency.key, response: payload });
        await commitQuota({ request: quotaRequest, reservation });
        operationSucceeded = true;
        return response(200, payload);
    } catch (error) {
        if (reservation && !operationSucceeded) {
            try { await releaseQuota({ request: quotaRequest, reservation }); }
            catch { log("quota.release_failed", { requestId: correlationId, actorId: user?.id, projectId: idempotencyProjectId, resource: "deployments", operation: idempotencyOperation, outcome: "failed" }); }
        }
        if (idempotency?.enabled && !idempotency.replay) await abandonIdempotent({ request: quotaRequest, actorId: user?.id, projectId: idempotencyProjectId, operation: idempotencyOperation, key: idempotency.key });
        if (error?.message === "IDEMPOTENCY_CONFLICT") return response(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for a different deployment." });
        if (error?.message === "IDEMPOTENCY_IN_PROGRESS") return response(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This deployment operation is already being processed." }, { "Retry-After": "2" });
        const quota = quotaResponse(error, response);
        if (quota) return quota;
        if (error?.message === "UNAUTHORIZED") {
            return response(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." });
        }
        if (error?.message === "NOT_CONFIGURED" || error?.provider === "configuration") {
            return response(503, { success: false, code: "DEPLOYMENT_NOT_CONFIGURED", retryable: false, error: "Deployment is not configured on the server." });
        }
        if (error?.name === "AbortError" || error?.status === 504 || /timed out/i.test(error?.message || "")) {
            return response(504, {
                success: false,
                code: "DEPLOYMENT_PROVIDER_TIMEOUT",
                retryable: true,
                error: "The deployment provider did not respond in time.",
                guidance: "Retry once. If it continues, download the files."
            });
        }
        console.error("Deployment error:", error?.message || error);
        return response(500, { success: false, code: "DEPLOYMENT_FAILED", retryable: true, error: "The deployment request failed temporarily." });
    }
};

exports._test = { authorizeDeployment, recordDeploymentResult };
