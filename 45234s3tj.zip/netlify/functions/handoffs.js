"use strict";

const { response, userRequest, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { requestId } = require("./_request-context.js");
const { log } = require("./_ops.js");

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ACCESS = new Set(["reviewer", "viewer", "editor"]);

async function handler(event = {}) {
    const correlationId = requestId(event);
    const reply = (status, payload, headers = {}) => response(status, payload, headers, event);
    const blocked = await guard(event, "handoffs", 20);
    if (blocked) return blocked;
    const method = String(event.httpMethod || "").toUpperCase();
    if (!["GET", "POST"].includes(method)) return reply(405, { success: false, code: "METHOD_NOT_ALLOWED", error: "Only GET and POST are supported." }, { Allow: "GET, POST" });
    let user;
    let operation;
    let scopedRequest;
    let projectId = "";
    let operationName = "";
    try {
        user = await authenticate(event);
        const query = event.queryStringParameters || {};
        if (method === "GET") {
            projectId = uuid(query.projectId) ? query.projectId : "";
            if (!projectId) return reply(400, { success: false, code: "INVALID_REQUEST", error: "A valid project is required." });
            scopedRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: correlationId });
            const [proposals, handoffs] = await Promise.all([
                scopedRequest(`/rest/v1/project_proposals?project_id=eq.${encodeURIComponent(projectId)}&select=id,approval_id,revision,recipient_email,title,scope,amount_cents,currency,status,created_at,updated_at&order=created_at.desc&limit=100`),
                scopedRequest(`/rest/v1/project_handoffs?project_id=eq.${encodeURIComponent(projectId)}&select=id,proposal_id,approval_id,revision,recipient_email,access_grant,reason,request_id,state,created_at,reversed_at&order=created_at.desc&limit=100`)
            ]);
            return reply(200, { success: true, proposals: proposals || [], handoffs: handoffs || [] });
        }
        if (!/^application\/json(?:\s*;|$)/i.test(String(event.headers?.["content-type"] || event.headers?.["Content-Type"] || ""))) return reply(415, { success: false, code: "UNSUPPORTED_MEDIA_TYPE", error: "Content-Type must be application/json." });
        const value = body(event, 30_000);
        projectId = uuid(value.projectId) ? value.projectId : "";
        const action = clean(value.action, 40);
        if (!new Set(["create-proposal", "create-handoff"]).has(action)) throw new Error("INVALID_HANDOFF_INPUT");
        const key = idempotencyKey(event, value);
        if (!projectId || !key) return reply(400, { success: false, code: !key ? "IDEMPOTENCY_KEY_REQUIRED" : "INVALID_REQUEST", error: !key ? "An idempotency key is required." : "A valid project is required." });
        scopedRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: correlationId });
        operationName = action === "create-handoff" ? "handoff.create" : "proposal.create";
        const canonical = action === "create-handoff"
            ? { projectId, proposalId: value.proposalId, recipientEmail: clean(value.recipientEmail, 254).toLowerCase(), accessGrant: value.accessGrant, reason: clean(value.reason, 1000) }
            : { projectId, approvalId: value.approvalId, recipientEmail: clean(value.recipientEmail, 254).toLowerCase(), title: clean(value.title, 200), scope: value.scope, amountCents: value.amountCents, currency: clean(value.currency || "USD", 3).toUpperCase() };
        operation = await beginIdempotent({ request: scopedRequest, actorId: user.id, projectId, operation: operationName, key, hash: requestHash(canonical) });
        if (operation.replay) return reply(200, { ...operation.response, idempotentReplay: true });
        let rows;
        if (action === "create-proposal") {
            if (!uuid(value.approvalId) || !EMAIL.test(canonical.recipientEmail) || !canonical.title || !Array.isArray(value.scope) || value.scope.length > 100 || (value.amountCents != null && (!Number.isSafeInteger(value.amountCents) || value.amountCents < 0))) throw new Error("INVALID_HANDOFF_INPUT");
            rows = await scopedRequest("/rest/v1/rpc/create_project_proposal", { method: "POST", body: JSON.stringify({ p_actor_id: user.id, p_project_id: projectId, p_approval_id: value.approvalId, p_recipient_email: canonical.recipientEmail, p_title: canonical.title, p_scope: value.scope, p_amount_cents: value.amountCents ?? null, p_currency: canonical.currency }) });
        } else if (action === "create-handoff") {
            if (!uuid(value.proposalId) || !EMAIL.test(canonical.recipientEmail) || !ACCESS.has(value.accessGrant)) throw new Error("INVALID_HANDOFF_INPUT");
            rows = await scopedRequest("/rest/v1/rpc/create_project_handoff", { method: "POST", body: JSON.stringify({ p_actor_id: user.id, p_project_id: projectId, p_proposal_id: value.proposalId, p_recipient_email: canonical.recipientEmail, p_access_grant: value.accessGrant, p_reason: canonical.reason, p_request_id: correlationId }) });
        }
        const record = Array.isArray(rows) ? rows[0] : rows;
        if (!record?.id) throw new Error("HANDOFF_WRITE_CONFLICT");
        const payload = { success: true, [action === "create-handoff" ? "handoff" : "proposal"]: record };
        await completeIdempotent({ request: scopedRequest, actorId: user.id, projectId, operation: operationName, key: operation.key, response: payload });
        log(`${operationName}.succeeded`, { requestId: correlationId, actorId: user.id, projectId, operation: operationName, statusCode: 201, outcome: "succeeded" });
        return reply(201, payload);
    } catch (error) {
        if (operation?.enabled && !operation.replay) await abandonIdempotent({ request: scopedRequest, actorId: user?.id, projectId, operation: operationName, key: operation.key });
        if (error.message === "UNAUTHORIZED") return reply(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." });
        if (/AUTHORIZATION_FAILED/.test(error.message)) return reply(403, { success: false, code: "FORBIDDEN", error: "You do not have permission for this handoff." });
        if (error.message === "INVALID_HANDOFF_INPUT" || /INPUT_INVALID/.test(error.message)) return reply(400, { success: false, code: "INVALID_REQUEST", error: "The proposal or handoff details are invalid." });
        if (error.message === "IDEMPOTENCY_CONFLICT") return reply(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was used for another request." });
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return reply(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This operation is already in progress." }, { "Retry-After": "2" });
        if (/APPROVED_DELIVERABLE_REQUIRED|ACCEPTED_PROPOSAL_REQUIRED|PROJECT_HAS_UNSYNCED_CHANGES|HANDOFF_RIGHTS_REQUIRED|HANDOFF_RECIPIENT_MISMATCH|HANDOFF_ALREADY_COMPLETED|HANDOFF_WRITE_CONFLICT/.test(error.message)) return reply(409, { success: false, code: error.message, error: "The proposal or handoff is no longer eligible for this operation." });
        log("handoff.failed", { requestId: correlationId, actorId: user?.id, projectId, operation: operationName || "handoff.request", statusCode: 500, outcome: "failed", retryable: true });
        return reply(500, { success: false, code: "HANDOFF_FAILED", retryable: true, error: "The handoff request failed." });
    }
}

exports.handler = handler;
