"use strict";
const { response, request, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const EVENTS = new Set(["page_view", "cta_click", "form_start", "form_submit", "booking_start", "phone_click", "email_click", "experiment_exposure"]);

function aggregate(rows, experimentId) {
    const byVariant = {};
    for (const row of rows) {
        const variant = clean(row.metadata?.variant || "unassigned", 80);
        const bucket = byVariant[variant] ||= { variant, exposures: 0, conversions: 0, unique: new Set() };
        bucket.unique.add(row.anonymous_id);
        if (row.event_name === "experiment_exposure") bucket.exposures++;
        if (["form_submit", "booking_start", "phone_click", "email_click"].includes(row.event_name)) bucket.conversions++;
    }
    return Object.values(byVariant).map((item) => ({ variant: item.variant, exposures: item.exposures, conversions: item.conversions, uniqueVisitors: item.unique.size, conversionRate: item.exposures ? Number((item.conversions / item.exposures).toFixed(4)) : 0, experimentId }));
}

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "insights", 40); if (blocked) return blocked;
    try {
        const user = await authenticate(event); const method = String(event.httpMethod || "").toUpperCase();
        if (method === "POST") {
            const value = body(event);
            const experimentId = clean(value.experimentId, 100);
            const variant = clean(value.variant, 80);
            const anonymousId = clean(value.anonymousId, 120);
            if (!uuid(value.projectId) || !uuid(experimentId) || !variant || !anonymousId) return response(400, { success: false, error: "Project, experiment, variant, and visitor ID are required." });
            const eventName = value.eventName === "conversion" ? "cta_click" : value.eventName;
            if (!["experiment_exposure", "cta_click"].includes(eventName) || value.consent !== true) return response(400, { success: false, error: "A valid experiment event and consent are required." });
            const owned = await request(`/rest/v1/project_experiments?id=eq.${encodeURIComponent(experimentId)}&project_id=eq.${encodeURIComponent(value.projectId)}&select=id`);
            if (!Array.isArray(owned) || !owned.length) return response(404, { success: false, error: "Experiment not found." });
            await request("/rest/v1/analytics_events", { method: "POST", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ project_id: value.projectId, event_name: eventName, anonymous_id: anonymousId, path: clean(value.path, 500) || "/", consent: true, metadata: { experimentId, variant } }) });
            return response(202, { success: true });
        }
        if (method !== "GET") return response(405, { success: false, error: "Only GET and POST are supported." });
        const q = event.queryStringParameters || {};
        if (!uuid(q.projectId)) return response(400, { success: false, error: "A valid project ID is required." });
        const experimentId = clean(q.experimentId, 100);
        if (!uuid(experimentId)) return response(400, { success: false, error: "A valid experiment ID is required." });
        const owned = await request(`/rest/v1/project_experiments?id=eq.${encodeURIComponent(experimentId)}&project_id=eq.${encodeURIComponent(q.projectId)}&select=id`);
        if (!Array.isArray(owned) || !owned.length) return response(404, { success: false, error: "Experiment not found." });
        const rows = await request(`/rest/v1/analytics_events?project_id=eq.${encodeURIComponent(q.projectId)}&metadata->>experimentId=eq.${encodeURIComponent(experimentId)}&select=event_name,anonymous_id,metadata,occurred_at&limit=10000`);
        return response(200, { success: true, projectId: q.projectId, items: aggregate(Array.isArray(rows) ? rows : [], experimentId) });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The insights request is invalid." });
        return response(500, { success: false, error: "Insights request failed." });
    }
};
