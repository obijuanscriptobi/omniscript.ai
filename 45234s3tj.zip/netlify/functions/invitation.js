"use strict";
const crypto = require("crypto");
const { response, request, userRequest, authenticate, body, clean, guard } = require("./_platform.js");
const { requestId } = require("./_request-context.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");

const digest = (value) => crypto.createHash("sha256").update(String(value)).digest("hex");

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "invitation", 30);
    if (blocked) return blocked;
    let operation;
    let operationRequest;
    let operationUser;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        const query = event.queryStringParameters || {};
        const token = clean(query.token, 200);
        if (method === "GET") {
            if (!token) return response(400, { success: false, error: "Invitation token is required." });
            const rows = await request(`/rest/v1/workspace_invitations?token_hash=eq.${encodeURIComponent(digest(token))}&select=id,workspace_id,email,role,status,expires_at`);
            const invitation = Array.isArray(rows) ? rows[0] : null;
            if (!invitation || invitation.status !== "pending" || !Number.isFinite(Date.parse(invitation.expires_at)) || Date.parse(invitation.expires_at) < Date.now()) return response(404, { success: false, error: "This invitation is invalid or expired." });
            return response(200, { success: true, invitation: { email: invitation.email, role: invitation.role, workspaceId: invitation.workspace_id, expiresAt: invitation.expires_at } });
        }
        if (method !== "POST") return response(405, { success: false, error: "Only GET and POST are supported." });
        const user = await authenticate(event);
        if (!token) return response(400, { success: false, error: "Invitation token is required." });
        const key = idempotencyKey(event, body(event));
        if (!key) return response(400, { success: false, code: "IDEMPOTENCY_KEY_REQUIRED", error: "An idempotency key is required." });
        const rows = await request(`/rest/v1/workspace_invitations?token_hash=eq.${encodeURIComponent(digest(token))}&select=*`);
        const invitation = Array.isArray(rows) ? rows[0] : null;
        const expiresAt = invitation ? Date.parse(invitation.expires_at) : NaN;
        if (!invitation || invitation.status !== "pending" || !Number.isFinite(expiresAt) || expiresAt < Date.now()) return response(404, { success: false, error: "This invitation is invalid, expired, or already used." });
        if (String(user.email || "").toLowerCase() !== String(invitation.email).toLowerCase()) return response(404, { success: false, error: "This invitation is invalid, expired, or already used." });
        operationUser = user;
        operationRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: requestId(event) });
        operation = await beginIdempotent({ request: operationRequest, actorId: user.id, operation: "workspace-invitation.accept", key, hash: requestHash({ invitationId: invitation.id, workspaceId: invitation.workspace_id, userId: user.id }) });
        if (operation.replay) return response(200, { ...operation.response, idempotentReplay: true });
        const accepted = await request(`/rest/v1/workspace_invitations?id=eq.${encodeURIComponent(invitation.id)}&workspace_id=eq.${encodeURIComponent(invitation.workspace_id)}&token_hash=eq.${encodeURIComponent(digest(token))}&status=eq.pending&expires_at=gt.${encodeURIComponent(new Date().toISOString())}&select=id`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: "accepted" }) });
        if (!Array.isArray(accepted) || !accepted.length) return response(404, { success: false, error: "This invitation is invalid, expired, or already used." });
        try {
            await request("/rest/v1/workspace_members", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify({ workspace_id: invitation.workspace_id, user_id: user.id, role: invitation.role }) });
        } catch (error) {
            await request(`/rest/v1/workspace_invitations?id=eq.${encodeURIComponent(invitation.id)}&workspace_id=eq.${encodeURIComponent(invitation.workspace_id)}&status=eq.accepted`, { method: "PATCH", body: JSON.stringify({ status: "pending" }) }).catch(() => {});
            throw error;
        }
        const payload = { success: true, workspaceId: invitation.workspace_id };
        await completeIdempotent({ request: operationRequest, actorId: user.id, operation: "workspace-invitation.accept", key: operation.key, response: payload });
        return response(200, payload);
    } catch (error) {
        if (operation?.enabled && !operation.replay) await abandonIdempotent({ request: operationRequest, actorId: operationUser?.id, operation: "workspace-invitation.accept", key: operation.key });
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "IDEMPOTENCY_CONFLICT") return response(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for another invitation." });
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return response(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This invitation is already being accepted." }, { "Retry-After": "2" });
        if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The invitation request is invalid." });
        console.error("Invitation error:", error.message || error);
        return response(500, { success: false, error: "Invitation processing failed." });
    }
};
