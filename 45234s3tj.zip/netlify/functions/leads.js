"use strict";

const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const projects = require("./projects.js");

const MAX_BODY_BYTES = 25_000;
const MAX_PAGE = 100;
const STATUSES = ["new", "verified", "contacted", "replied", "qualified", "won", "lost"];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function response(statusCode, payload) {
    return { statusCode, isBase64Encoded: false, headers: securityHeaders(), body: JSON.stringify(payload) };
}

function parseBody(event) {
    const body = String(event?.body || "");
    let buffer;
    if (event?.isBase64Encoded) {
        if (!body || body.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(body)) throw new Error("INVALID_BODY");
        buffer = Buffer.from(body, "base64");
        if (buffer.toString("base64").replace(/=+$/, "") !== body.replace(/=+$/, "")) throw new Error("INVALID_BODY");
    } else {
        buffer = Buffer.from(body, "utf8");
    }
    if (buffer.length > MAX_BODY_BYTES) throw new Error("TOO_LARGE");
    let value;
    try { value = JSON.parse(buffer.toString("utf8") || "{}"); } catch { throw new Error("INVALID_BODY"); }
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_BODY");
    return value;
}

function clean(value, max = 500) {
    return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
}

function projectId(event, body = {}) {
    const value = event?.queryStringParameters?.projectId || body.projectId || "";
    if (!UUID.test(String(value))) throw new Error("INVALID_PROJECT");
    return String(value);
}

function workContextId(event, body = {}) {
    const value = event?.queryStringParameters?.workContextId || body.workContextId || "";
    if (!UUID.test(String(value))) throw new Error("INVALID_CONTEXT");
    return String(value);
}

function parseReminder(value) {
    if (value === undefined || value === null || value === "") return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) throw new Error("INVALID_REMINDER");
    return date.toISOString();
}

function leadPayload(body, userId, project) {
    const status = STATUSES.includes(body.status) ? body.status : "new";
    return {
        user_id: userId,
        project_id: project,
        name: clean(body.name, 200),
        email: clean(body.email, 320),
        phone: clean(body.phone, 80),
        message: clean(body.message, 4000),
        status,
        source: clean(body.source, 180) || "website",
        campaign: clean(body.campaign, 180),
        notes: clean(body.notes, 4000),
        reminder_at: parseReminder(body.reminderAt)
    };
}

function select() { return "id,project_id,name,email,phone,message,status,source,campaign,notes,reminder_at,created_at,updated_at"; }

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "leads", limit: 60, windowMs: 60_000 });
    if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const user = await projects.authenticate(event);
        const body = method === "GET" ? {} : parseBody(event);
        const id = event?.queryStringParameters?.id || body.id || "";
        if (id && !UUID.test(String(id))) throw new Error("INVALID_ID");
        const project = projectId(event, body);
        const context = workContextId(event, body);
        const ownedProject = await projects.getOwnedProject(project, user.id, context);
        if (!ownedProject) return response(404, { success: false, error: "Project not found in this work context." });
        if (method === "GET") {
            const page = Math.min(Math.max(Number(event?.queryStringParameters?.page || 1) || 1, 1), MAX_PAGE);
            const limit = Math.min(Math.max(Number(event?.queryStringParameters?.limit || 50) || 50, 1), MAX_PAGE);
            const offset = (page - 1) * limit;
            const query = `project_id=eq.${encodeURIComponent(project)}&user_id=eq.${encodeURIComponent(user.id)}&select=${select()}&order=created_at.desc&limit=${limit}&offset=${offset}`;
            const leads = await projects.supabaseRequest(`/rest/v1/leads?${query}`);
            return response(200, { success: true, leads: Array.isArray(leads) ? leads : [], page, limit });
        }
        if (method === "POST") {
            const payload = leadPayload(body, user.id, project);
            const result = await projects.supabaseRequest(`/rest/v1/leads?select=${select()}`, { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) });
            return response(201, { success: true, lead: Array.isArray(result) ? result[0] : null });
        }
        if (!id) return response(400, { success: false, error: "A lead ID is required." });
        const ownership = `id=eq.${encodeURIComponent(id)}&project_id=eq.${encodeURIComponent(project)}&user_id=eq.${encodeURIComponent(user.id)}`;
        if (method === "DELETE") {
            await projects.supabaseRequest(`/rest/v1/leads?${ownership}`, { method: "DELETE" });
            return response(200, { success: true });
        }
        const updates = {};
        if (Object.prototype.hasOwnProperty.call(body, "status")) {
            if (!STATUSES.includes(body.status)) throw new Error("INVALID_STATUS");
            updates.status = body.status;
        }
        if (Object.prototype.hasOwnProperty.call(body, "notes")) updates.notes = clean(body.notes, 4000);
        if (Object.prototype.hasOwnProperty.call(body, "message")) updates.message = clean(body.message, 16000);
        if (Object.prototype.hasOwnProperty.call(body, "reminderAt")) updates.reminder_at = parseReminder(body.reminderAt);
        if (!Object.keys(updates).length) throw new Error("INVALID_UPDATE");
        const result = await projects.supabaseRequest(`/rest/v1/leads?${ownership}&select=${select()}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(updates) });
        return response(200, { success: true, lead: Array.isArray(result) ? result[0] : null });
    } catch (error) {
        const code = error?.message || "";
        if (code === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (["INVALID_BODY", "INVALID_ID", "INVALID_PROJECT", "INVALID_CONTEXT", "INVALID_STATUS", "INVALID_UPDATE", "INVALID_REMINDER"].includes(code)) return response(400, { success: false, error: "The lead data is invalid." });
        if (code === "TOO_LARGE") return response(413, { success: false, error: "The lead payload is too large." });
        if (code === "NOT_CONFIGURED") return response(503, { success: false, error: "Cloud storage is not configured." });
        if (code === "INVALID_CONFIG") return response(500, { success: false, error: "Cloud storage configuration is invalid." });
        if (error?.status === 404) return response(404, { success: false, error: "Lead or project not found." });
        console.error("Lead API error:", error?.message || error);
        return response(500, { success: false, error: "The lead request failed." });
    }
};