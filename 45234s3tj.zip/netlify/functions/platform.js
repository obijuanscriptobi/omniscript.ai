"use strict";
const { response, request, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");
const TABLES = { teams: "workspace_invitations", providers: "provider_connections", environments: "project_environments", experiments: "project_experiments", locales: "project_locales", templates: "marketplace_templates", analytics: "analytics_events", domains: "workspace_domains" };
const PROVIDERS = new Set(["netlify", "vercel", "cloudflare-pages", "static-export", "plausible", "umami", "posthog", "webhook"]);
const URL_PROTOCOLS = new Set(["http:", "https:"]);
function query(event) { return event.queryStringParameters || {}; }
function tablePath(table, filters = "") { return `/rest/v1/${table}?${filters}`; }
function validUrl(value) { try { const url = new URL(String(value)); return URL_PROTOCOLS.has(url.protocol) && !url.username && !url.password && !url.hash; } catch { return false; } }
async function handler(event = {}) {
    const blocked = await guard(event, "platform", 80); if (blocked) return blocked;
    try {
        const user = await authenticate(event);
        const authorization = Object.keys(event.headers || {}).find((key) => key.toLowerCase() === "authorization");
        const userRequest = (path, options = {}) => request(path, { ...options, headers: { ...(options.headers || {}), ...(authorization ? { Authorization: String(event.headers[authorization]) } : {}) } });
        const method = String(event.httpMethod || "").toUpperCase(); const q = query(event); const resource = clean(q.resource, 40); const id = clean(q.id, 100);
        if (resource === "analytics-report" && method === "GET") {
            if (!uuid(q.projectId)) return response(400, { success: false, error: "A valid project ID is required." });
            const filters = [`project_id=eq.${encodeURIComponent(q.projectId)}`];
            if (uuid(q.experimentId)) filters.push(`experiment_id=eq.${encodeURIComponent(q.experimentId)}`);
            if (q.since && !Number.isNaN(Date.parse(q.since))) filters.push(`occurred_at=gte.${encodeURIComponent(new Date(q.since).toISOString())}`);
            const events = await userRequest(`/rest/v1/analytics_events?${filters.join("&")}&select=event_name,revision_id,experiment_id,anonymous_id,occurred_at&limit=5000`);
            const rows = Array.isArray(events) ? events : [];
            const groups = new Map();
            rows.forEach((item) => { const key = item.revision_id || "unassigned"; const group = groups.get(key) || { revisionId: key, exposures: new Set(), conversions: new Set(), events: 0 }; group.events += 1; if (item.event_name === "experiment_exposure") group.exposures.add(item.anonymous_id); if (["booking_completed", "form_submit", "quote_request"].includes(item.event_name)) group.conversions.add(item.anonymous_id); groups.set(key, group); });
            const variants = [...groups.values()].map((group) => ({ revisionId: group.revisionId, exposures: group.exposures.size, conversions: group.conversions.size, conversionRate: group.exposures.size ? Number((group.conversions.size / group.exposures.size).toFixed(4)) : 0, events: group.events }));
            const baseline = variants.find((item) => item.revisionId === "unassigned") || variants[0] || { exposures: 0, conversions: 0, conversionRate: 0 };
            const enriched = variants.map((item) => {
                const absoluteLift = Number((item.conversionRate - baseline.conversionRate).toFixed(4));
                const relativeLift = baseline.conversionRate ? Number((absoluteLift / baseline.conversionRate).toFixed(4)) : null;
                const sampleSize = item.exposures + baseline.exposures;
                const confidence = sampleSize >= 100 ? (Math.min(0.99, 0.5 + Math.min(0.49, Math.abs(absoluteLift) * 2))) : null;
                return { ...item, absoluteLift, relativeLift, sampleSize, confidence, decision: sampleSize >= 100 && confidence >= 0.95 ? "directional-signal" : "insufficient-data" };
            });
            return response(200, { success: true, projectId: q.projectId, experimentId: uuid(q.experimentId) ? q.experimentId : null, baselineRevisionId: baseline.revisionId || null, variants: enriched, methodology: "Unique anonymous visitors with experiment exposure are the denominator; unique visitors with a booking, form, or quote event are conversions. Lift and confidence are conservative directional estimates; no winner is declared without at least 100 combined exposed visitors and a confidence threshold." });
        }
        if (!Object.keys(TABLES).includes(resource)) return response(400, { success: false, error: "Unsupported platform resource." });
        const table = TABLES[resource];
        if (method === "GET") {
            if (["providers", "domains"].includes(resource) && !uuid(q.workspaceId)) return response(400, { success: false, error: "A valid workspace ID is required." });
            if (["environments", "experiments", "locales", "analytics"].includes(resource) && !uuid(q.projectId)) return response(400, { success: false, error: "A valid project ID is required." });
            const filters = resource === "teams" ? `invited_by=eq.${encodeURIComponent(user.id)}` : resource === "templates" ? `visibility=eq.public${q.industry ? `&industry=eq.${encodeURIComponent(clean(q.industry, 80))}` : ""}` : resource === "analytics" ? `project_id=eq.${encodeURIComponent(q.projectId)}` : q.workspaceId ? `workspace_id=eq.${encodeURIComponent(q.workspaceId)}` : q.projectId ? `project_id=eq.${encodeURIComponent(q.projectId)}` : "";
            const select = resource === "analytics" ? "event_name,occurred_at,path,locale" : resource === "teams" ? "id,workspace_id,email,role,status,expires_at,created_at" : "*";
            const order = resource === "analytics" ? "occurred_at.desc" : "created_at.desc";
            return response(200, { success: true, resource, items: await userRequest(tablePath(table, `${filters}${filters ? "&" : ""}select=${select}&order=${order}&limit=500`)) });
        }
        if (resource === "teams" && method === "POST") {
            const crypto = require("crypto");
            const value = body(event); const workspaceId = uuid(value.workspaceId) ? value.workspaceId : ""; const email = clean(value.email, 254).toLowerCase(); const role = ["admin", "editor", "reviewer", "viewer"].includes(value.role) ? value.role : "viewer";
            if (!workspaceId || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return response(400, { success: false, error: "Workspace and valid email are required." });
            const token = crypto.randomBytes(32).toString("base64url");
            const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
            const invitation = await userRequest(`/rest/v1/workspace_invitations`, { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ workspace_id: workspaceId, email, role, invited_by: user.id, token_hash: tokenHash }) });
            const record = Array.isArray(invitation) ? invitation[0] : invitation;
            let emailSent = false;
            if (process.env.RESEND_API_KEY && process.env.INVITATION_FROM_EMAIL && record?.id) {
                const appUrl = String(process.env.APP_PUBLIC_URL || "").replace(/\/+$/, "");
                const inviteUrl = `${appUrl}/?invitation=${encodeURIComponent(token)}`;
                const mailClient = providerClient("resend", {
                    endpoint: "https://api.resend.com",
                    retries: 0,
                    timeoutMs: 8_000,
                    requestId: requestId(event)
                });
                try {
                    await mailClient.request("/emails", {
                        method: "POST",
                        headers: {
                            Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({ from: process.env.INVITATION_FROM_EMAIL, to: [email], subject: "You have been invited to a workspace", html: `<p>You have been invited to join a workspace as ${role}.</p><p><a href="${inviteUrl}">Review invitation</a></p>` })
                    });
                    emailSent = true;
                } catch (error) {
                    console.error("Invitation email delivery failed:", error?.message || error);
                }
            }
            const safeInvitation = record && typeof record === "object" ? (({ token_hash, ...safe }) => safe)(record) : record;
            return response(201, { success: true, invitation: safeInvitation, emailSent, token, path: `/invitation.html?token=${encodeURIComponent(token)}` });
        }
        if (method === "POST") {
            if (resource === "analytics") return response(405, { success: false, error: "Use the analytics endpoint for event ingestion." });
            const value = body(event); const projectId = uuid(value.projectId) ? value.projectId : null;
            const workspaceId = uuid(value.workspaceId) ? value.workspaceId : null;
            if (["providers", "domains"].includes(resource) && !workspaceId) return response(400, { success: false, error: "A valid workspace ID is required." });
            if (["environments", "experiments", "locales"].includes(resource) && !projectId) return response(400, { success: false, error: "A valid project ID is required." });
            if (resource === "domains") {
                const hostname = clean(value.hostname, 253).toLowerCase();
                if (!/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(hostname)) return response(400, { success: false, error: "A valid hostname is required." });
                return response(201, { success: true, item: await userRequest(tablePath(table), { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ workspace_id: workspaceId, hostname, verification_token: require("crypto").randomBytes(24).toString("hex"), status: "pending" }) }) });
            }
            if (resource === "providers" && !PROVIDERS.has(value.providerType)) return response(400, { success: false, error: "Unsupported provider type." });
            if (resource === "environments" && value.publicUrl && !validUrl(value.publicUrl)) return response(400, { success: false, error: "Environment URL must be a valid HTTP or HTTPS URL." });
            if (resource === "locales" && !/^[a-z]{2,3}(?:-[A-Z]{2})?$/.test(clean(value.locale, 20))) return response(400, { success: false, error: "A valid locale is required." });
            if (resource === "experiments" && (!clean(value.name, 120) || !clean(value.goal, 500))) return response(400, { success: false, error: "Experiment name and goal are required." });
            if (resource === "templates" && (!clean(value.slug, 100) || !clean(value.name, 120) || !clean(value.industry, 80))) return response(400, { success: false, error: "Template slug, name, and industry are required." });
            const payload = resource === "providers" ? { workspace_id: workspaceId, provider_type: value.providerType, display_name: clean(value.displayName || value.providerType, 120), config: value.config && typeof value.config === "object" && !Array.isArray(value.config) ? value.config : {}, enabled: value.enabled !== false } : resource === "environments" ? { project_id: projectId, environment: ["draft", "staging", "production"].includes(value.environment) ? value.environment : "staging", public_url: clean(value.publicUrl, 500) || null, current_revision: clean(value.currentRevision, 200) || null, status: "draft" } : resource === "experiments" ? { project_id: projectId, name: clean(value.name, 120), goal: clean(value.goal, 500), variants: Array.isArray(value.variants) ? value.variants.slice(0, 8) : [], allocation: value.allocation && typeof value.allocation === "object" && !Array.isArray(value.allocation) ? value.allocation : {} } : resource === "locales" ? { project_id: projectId, locale: clean(value.locale, 20), content: value.content && typeof value.content === "object" && !Array.isArray(value.content) ? value.content : {}, status: "draft" } : { author_id: user.id, slug: clean(value.slug, 100).toLowerCase().replace(/[^a-z0-9-]/g, "-"), name: clean(value.name, 120), industry: clean(value.industry, 80), files: value.files && typeof value.files === "object" && !Array.isArray(value.files) ? value.files : {}, metadata: value.metadata && typeof value.metadata === "object" && !Array.isArray(value.metadata) ? value.metadata : {}, visibility: ["private", "unlisted", "public"].includes(value.visibility) ? value.visibility : "private" };
            return response(201, { success: true, item: await userRequest(tablePath(table), { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) }) });
        }
        if (!["PATCH", "DELETE"].includes(method) || !id) return response(400, { success: false, error: "A resource ID is required." });
        if (resource === "locales" && !uuid(q.projectId)) return response(400, { success: false, error: "A valid project ID is required for locales." });
        const path = resource === "locales"
            ? tablePath(table, `project_id=eq.${encodeURIComponent(q.projectId)}&locale=eq.${encodeURIComponent(id)}`)
            : tablePath(table, `id=eq.${encodeURIComponent(id)}`);
        if (method === "DELETE") { await userRequest(path, { method: "DELETE" }); return response(200, { success: true }); }
        const value = body(event);
        if (resource === "providers" && value.config !== undefined && (!value.config || typeof value.config !== "object" || Array.isArray(value.config))) return response(400, { success: false, error: "Provider config must be an object." });
        if (resource === "experiments" && value.allocation !== undefined && (!value.allocation || typeof value.allocation !== "object" || Array.isArray(value.allocation))) return response(400, { success: false, error: "Experiment allocation must be an object." });
        const editable = {
            providers: ["displayName", "config", "enabled"],
            environments: ["providerConnectionId", "publicUrl", "currentRevision", "status"],
            experiments: ["name", "status", "goal", "variants", "allocation", "results"],
            locales: ["status", "content", "translatedBy"],
            templates: ["name", "industry", "version", "files", "metadata", "visibility"],
            domains: ["status", "provider"]
        }[resource] || [];
        const updates = {};
        for (const key of editable) {
            if (!(key in value)) continue;
            const column = key.replace(/[A-Z]/g, (match) => `_${match.toLowerCase()}`);
            updates[column] = value[key];
        }
        if (resource === "environments" && updates.public_url !== undefined && updates.public_url !== null && !validUrl(updates.public_url)) return response(400, { success: false, error: "Environment URL must be a valid HTTP or HTTPS URL." });
        const statusValues = {
            environments: ["draft", "deploying", "deployed", "verified", "failed", "stale"],
            experiments: ["draft", "running", "paused", "completed"],
            locales: ["draft", "in-review", "approved", "published"],
            domains: ["pending", "verified", "failed", "removed"]
        };
        if (updates.status !== undefined && statusValues[resource] && !statusValues[resource].includes(updates.status)) return response(400, { success: false, error: "Invalid status." });
        if (resource === "locales" && updates.content !== undefined && (!updates.content || typeof updates.content !== "object" || Array.isArray(updates.content))) return response(400, { success: false, error: "Locale content must be an object." });
        if (!Object.keys(updates).length) return response(400, { success: false, error: "No editable fields were provided." });
        return response(200, { success: true, item: await userRequest(path, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(updates) }) });
    } catch (error) { if (["UNAUTHORIZED", "NOT_CONFIGURED"].includes(error.message)) return response(error.message === "UNAUTHORIZED" ? 401 : 503, { success: false, error: error.message === "UNAUTHORIZED" ? "Please sign in first." : "Platform services are not configured." }); if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The platform request is invalid." }); console.error("Platform API error:", error.message || error); return response(500, { success: false, error: "The platform request failed." }); }
}
exports.handler = handler;
