"use strict";

const { limitedResponseAsync, maxBodyResponse, securityHeaders } = require("./_security.js");
const { qualityReport } = require("../../workspace-quality.js");
const { auditProject } = require("../../workspace-audit.js");
const { validateOutput } = require("../../workspace-output-contract.js");
const crypto = require("node:crypto");
const { validateFiles, validateRevision } = require("../../workspace-server-validation.js");

function validWorkspaceToken(event, body) {
    const secret = String(process.env.PREFLIGHT_SIGNING_SECRET || "").trim();
    const supplied = String(event.headers?.["x-workspace-token"] || event.headers?.["X-Workspace-Token"] || "");
    if (!secret || !supplied || !/^\d+\.[a-f0-9]{64}$/i.test(supplied)) return false;
    const [timestamp, signature] = supplied.split(".");
    if (Math.abs(Date.now() - Number(timestamp)) > 5 * 60 * 1000) return false;
    const payload = `${timestamp}:${JSON.stringify(body.files || {})}`;
    const expected = crypto.createHmac("sha256", secret).update(payload).digest("hex");
    return crypto.timingSafeEqual(Buffer.from(signature, "hex"), Buffer.from(expected, "hex"));
}

function response(statusCode, payload) {
    return {
        statusCode,
        isBase64Encoded: false,
        headers: securityHeaders({ "Cache-Control": "no-store, max-age=0" }),
        body: JSON.stringify(payload)
    };
}

function parseBody(event) {
    const raw = Buffer.from(String(event?.body || ""), event?.isBase64Encoded ? "base64" : "utf8").toString("utf8");
    if (Buffer.byteLength(raw, "utf8") > 2_000_000) throw new Error("TOO_LARGE");
    const value = JSON.parse(raw || "{}");
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_BODY");
    return value;
}

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "preflight", limit: 10, windowMs: 60_000, requireDistributed: true });
    if (blocked) return blocked;
    const oversized = maxBodyResponse(event, 2_000_000);
    if (oversized) return oversized;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") {
        return response(405, { success: false, error: "Only POST requests are supported." });
    }
    try {
        const body = parseBody(event);
        if (!String(process.env.PREFLIGHT_SIGNING_SECRET || "").trim()) {
            return response(503, { success: false, retryable: true, error: "Preflight signing is not configured." });
        }
        if (!validWorkspaceToken(event, body)) {
            return response(401, { success: false, error: "A valid short-lived preflight token is required." });
        }
        const fileIssues = validateFiles(body.files, { requireDeploymentConfig: true, requireFormHandler: true });
        const revisionCheck = validateRevision(body.files, body.projectRevision || body.revision, body.snapshotMetadata || {});
        if (!revisionCheck.valid) return response(409, { success: false, error: "The project revision is stale. Refresh the project and run preflight again.", code: "STALE_REVISION", revision: revisionCheck.actual });
        const contract = validateOutput(body.files);
        const report = qualityReport(body.files);
        fileIssues.forEach((issue) => {
            report.issues.push({ ...issue, severity: "blocking", category: "security", source: "server-preflight" });
            report.blocking.push(issue);
        });
        contract.issues.forEach((issue) => {
            report.issues.push({ ...issue, category: issue.category || "deployment" });
            if (issue.severity === "blocking") report.blocking.push(issue);
        });
        const audit = auditProject(body.files);
        const known = new Set(report.issues.map((entry) => `${entry.code}:${entry.file || ""}:${entry.message}`));
        audit.issues.forEach((entry) => {
            const key = `${entry.code}:${entry.file || ""}:${entry.message}`;
            if (known.has(key)) return;
            known.add(key);
            report.issues.push(entry);
            if (entry.severity === "blocking") report.blocking.push(entry);
        });
        report.summary = {
            ...report.summary,
            errors: report.blocking.length,
            warnings: report.issues.filter((entry) => entry.severity === "warning").length,
            passed: report.blocking.length === 0
        };
        return response(report.blocking.length ? 422 : 200, { success: report.blocking.length === 0, report });
    } catch (error) {
        return response(error.message === "TOO_LARGE" ? 413 : 400, {
            success: false,
            error: error.message === "TOO_LARGE" ? "The project payload is too large." : "The preflight request is invalid."
        });
    }
};
