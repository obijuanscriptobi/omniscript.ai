"use strict";

const crypto = require("node:crypto");
const { response, header, config, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const { getOwnedProject, getOwnedWorkContext } = require("./projects.js");
const { requestId } = require("./_request-context.js");
const { auditEvent } = require("./_ops.js");

const MAX_FILES = 80;
const MAX_TOTAL_BYTES = 5_000_000;
const TOKEN_BYTES = 32;
const MAX_TTL_MS = 7 * 24 * 60 * 60 * 1000;

function token() {
    return crypto.randomBytes(TOKEN_BYTES).toString("base64url");
}

function tokenHash(value) {
    return crypto.createHash("sha256").update(value).digest("hex");
}

function validateFiles(files) {
    if (!files || typeof files !== "object" || Array.isArray(files)) throw new Error("INVALID_FILES");
    const entries = Object.entries(files);
    if (!entries.length || entries.length > MAX_FILES) throw new Error("INVALID_FILES");
    let bytes = 0;
    for (const [name, content] of entries) {
        if (!/^[a-z0-9][a-z0-9._/-]{0,180}$/i.test(name) || name.includes("..") || name.startsWith("/") || typeof content !== "string") throw new Error("INVALID_FILES");
        bytes += Buffer.byteLength(content, "utf8");
        if (bytes > MAX_TOTAL_BYTES) throw new Error("TOO_LARGE");
    }
    if (!files["index.html"]) throw new Error("INVALID_FILES");
    return files;
}

async function rest(path, options = {}) {
    const { url, key } = config();
    const result = await fetch(`${url}${path}`, {
        ...options,
        headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", ...(options.headers || {}) },
        signal: AbortSignal.timeout(10_000)
    });
    const data = await result.json().catch(() => ({}));
    if (!result.ok) { const error = new Error(data.message || "Preview storage failed."); error.status = result.status; throw error; }
    return data;
}

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "preview", 30);
    if (blocked) return blocked;
    const method = String(event.httpMethod || "").toUpperCase();
    try {
        if (method === "GET") {
            const supplied = clean(event.queryStringParameters?.token, 160);
            if (!/^[A-Za-z0-9_-]{40,80}$/.test(supplied)) return response(400, { success: false, error: "A valid preview token is required." });
            const rows = await rest(`/rest/v1/preview_snapshots?token_hash=eq.${encodeURIComponent(tokenHash(supplied))}&revoked_at=is.null&select=project_id,files,revision,expires_at&limit=1`);
            const snapshot = Array.isArray(rows) ? rows[0] : null;
            if (!snapshot || new Date(snapshot.expires_at).getTime() <= Date.now()) return response(404, { success: false, error: "This preview is invalid, expired, or revoked." });
            const projects = await rest(`/rest/v1/projects?id=eq.${encodeURIComponent(snapshot.project_id)}&select=id,work_context_id,organization_id&limit=1`);
            const project = Array.isArray(projects) ? projects[0] : null;
            const contexts = project ? await rest(`/rest/v1/work_contexts?id=eq.${encodeURIComponent(project.work_context_id)}&organization_id=eq.${encodeURIComponent(project.organization_id)}&status=eq.active&select=id&limit=1`) : [];
            if (!project || !Array.isArray(contexts) || !contexts[0]) return response(404, { success: false, error: "This preview is invalid, expired, or revoked." });
            await auditEvent(rest, { request_id: requestId(event), actor_id: null, project_id: snapshot.project_id, action: "preview.viewed", revision: snapshot.revision, result: "succeeded", metadata: {} });
            return response(200, { success: true, files: snapshot.files, revision: snapshot.revision, expiresAt: snapshot.expires_at });
        }
        if (method !== "POST") return response(405, { success: false, error: "Only GET and POST are supported." });
        const user = await authenticate(event);
        const value = body(event, MAX_TOTAL_BYTES + 100_000);
        const files = validateFiles(value.files);
        const projectId = String(value.projectId || "");
        const workContextId = String(value.workContextId || "");
        if (!uuid(projectId) || !uuid(workContextId)) return response(400, { success: false, error: "A valid project and work context are required." });
        if (!await getOwnedProject(projectId, user.id, workContextId)) return response(404, { success: false, error: "Project not found in this work context." });
        const context = await getOwnedWorkContext(workContextId, user.id);
        if (context?.kind === "client" && context.asset_rights_confirmed !== true) return response(409, { success: false, code: "ASSET_RIGHTS_REQUIRED", error: "Confirm ownership or licences for client assets before sharing a preview." });
        const revision = clean(value.revision, 128);
        const previewToken = token();
        const expiresAt = new Date(Date.now() + Math.min(Math.max(Number(value.ttlMs) || 24 * 60 * 60 * 1000, 60_000), MAX_TTL_MS)).toISOString();
        const created = await rest("/rest/v1/preview_snapshots?select=id", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ token_hash: tokenHash(previewToken), user_id: user.id, project_id: projectId, revision, files, expires_at: expiresAt }) });
        const snapshot = Array.isArray(created) ? created[0] : created;
        if (!snapshot?.id) throw new Error("PREVIEW_CREATE_FAILED");
        await auditEvent(rest, { request_id: requestId(event), actor_id: user.id, project_id: projectId, action: "preview.created", revision, result: "succeeded", metadata: { snapshotId: snapshot.id, expiresAt } });
        return response(201, { success: true, token: previewToken, revision, expiresAt });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "TOO_LARGE") return response(413, { success: false, error: "The preview is too large." });
        if (error.message === "INVALID_BODY" || error.message === "INVALID_FILES") return response(400, { success: false, error: "The preview payload is invalid." });
        if (error.status === 404) return response(404, { success: false, error: "Preview storage is not available." });
        console.error("Preview error:", error.message || error);
        return response(500, { success: false, error: "The preview could not be saved." });
    }
};
