"use strict";

const crypto = require("crypto");
const { providerClient, requestId } = require("./provider-adapters.js");
const { response, request, authenticate, body, uuid, clean, guard, config } = require("./_platform.js");
const { consumeQuota, quotaResponse } = require("./_quota.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent, beginPublicTokenOperation, completePublicTokenOperation, abandonPublicTokenOperation } = require("./_idempotency.js");

const ROLES = new Set(["owner", "admin", "sales", "marketing", "contributor", "client_reviewer"]);
const WRITE_ROLES = new Set(["owner", "admin", "contributor"]);
const MAX_FILE = 52428800;
const MAX_FILES_PER_PROJECT = 500;
const UPLOAD_TTL_MS = 60 * 60 * 1000;
const ACTIVE_TYPES = new Set(["image/svg+xml", "text/html", "application/javascript", "text/javascript"]);
const ALLOWED_TYPES = new Set([
    "application/pdf", "application/zip", "application/json", "text/plain", "text/csv",
    "image/jpeg", "image/png", "image/gif", "image/webp",
    "text/css",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
]);

function hash(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function portalToken(event, query) {
    if (query.token) return clean(query.token, 200);
    const cookieHeader = Object.entries(event.headers || {}).find(([key]) => key.toLowerCase() === "cookie")?.[1] || "";
    const part = String(cookieHeader).split(";").map((value) => value.trim()).find((value) => value.startsWith("__Host-morrow_portal="));
    return part ? clean(decodeURIComponent(part.slice("__Host-morrow_portal=".length)), 200) : "";
}
function validType(mime) { return ALLOWED_TYPES.has(mime) || mime.startsWith("audio/") || mime.startsWith("video/"); }
function authHeader(event) {
    const key = Object.keys(event.headers || {}).find((item) => item.toLowerCase() === "authorization");
    return key ? String(event.headers[key]) : "";
}
async function authenticatedRequest(event, path, options = {}) {
    const { url } = config();
    const anonKey = String(process.env.SUPABASE_ANON_KEY || "").trim();
    const client = providerClient("supabase", { endpoint: url, retries: 0, timeoutMs: 10_000, requestId: requestId(event) });
    const result = await client.request(path, {
        ...options,
        headers: { ...(options.headers || {}), apikey: anonKey, Authorization: authHeader(event), "Content-Type": "application/json" }
    });
    return result.data;
}

async function projectScope(projectId) {
    const rows = await request(`/rest/v1/projects?id=eq.${encodeURIComponent(projectId)}&select=id,organization_id,work_context_id&limit=1`);
    const project = Array.isArray(rows) ? rows[0] : null;
    if (!project?.organization_id || !project?.work_context_id) throw new Error("FORBIDDEN");
    const contexts = await request(`/rest/v1/work_contexts?id=eq.${encodeURIComponent(project.work_context_id)}&organization_id=eq.${encodeURIComponent(project.organization_id)}&status=eq.active&select=id&limit=1`);
    if (!Array.isArray(contexts) || !contexts[0]) throw new Error("FORBIDDEN");
    return project;
}
async function access(userId, projectId, write = false) {
    const project = await projectScope(projectId);
    const members = await request(`/rest/v1/organization_members?organization_id=eq.${encodeURIComponent(project.organization_id)}&user_id=eq.${encodeURIComponent(userId)}&status=eq.active&revoked_at=is.null&select=user_id&limit=1`);
    if (!Array.isArray(members) || !members[0]) throw new Error("FORBIDDEN");
    const rows = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}&select=role&limit=1`);
    const role = Array.isArray(rows) ? rows[0]?.role : "";
    if (!ROLES.has(role) || (write && !WRITE_ROLES.has(role))) throw new Error("FORBIDDEN");
    return { role, project };
}
async function signedUrl(path, upload = false) {
    const { url, key } = config();
    const client = providerClient("supabase-storage", { endpoint: url, retries: 0, timeoutMs: 10_000 });
    const endpoint = upload ? "upload/sign" : "sign";
    const result = await client.request(`/storage/v1/object/${endpoint}/project-files/${path}`, {
        method: "POST",
        headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ expiresIn: 600 })
    });
    const data = result.data || {};
    if (!(upload ? data.url : data.signedURL)) throw new Error("STORAGE_UNAVAILABLE");
    return `${url}/storage/v1${upload ? data.url : data.signedURL}`;
}
async function removeObject(path) {
    const { url, key } = config();
    const client = providerClient("supabase-storage", { endpoint: url, retries: 0, timeoutMs: 10_000 });
    try {
        await client.request("/storage/v1/object/project-files", {
            method: "DELETE",
            headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
            body: JSON.stringify({ prefixes: [path] })
        });
    } catch (error) {
        if (error?.status !== 404) throw new Error("STORAGE_UNAVAILABLE");
    }
}
async function readObject(path) {
    const { url, key } = config();
    const client = providerClient("supabase-storage", { endpoint: url, retries: 0, timeoutMs: 15_000 });
    const result = await client.request(`/storage/v1/object/authenticated/project-files/${path}`, {
        headers: { apikey: key, Authorization: `Bearer ${key}` },
        raw: true
    });
    if (!result.response.ok) throw new Error(result.response.status === 404 ? "UPLOAD_MISSING" : "STORAGE_UNAVAILABLE");
    const length = Number(result.response.headers.get("content-length") || 0);
    if (length > MAX_FILE) throw new Error("INVALID_FILE_CONTENT");
    const bytes = Buffer.from(await result.response.arrayBuffer());
    if (!bytes.length || bytes.length > MAX_FILE) throw new Error("INVALID_FILE_CONTENT");
    return bytes;
}

function isText(bytes) {
    if (bytes.includes(0)) return false;
    return !Buffer.from(bytes).toString("utf8").includes("\uFFFD");
}
function detectedType(bytes, declared) {
    const ascii = bytes.subarray(0, 16).toString("ascii");
    if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
    if (bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
    if (ascii.startsWith("GIF87a") || ascii.startsWith("GIF89a")) return "image/gif";
    if (ascii.startsWith("RIFF") && bytes.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
    if (ascii.startsWith("%PDF-")) return "application/pdf";
    if (["PK\u0003\u0004", "PK\u0005\u0006", "PK\u0007\u0008"].some((magic) => ascii.startsWith(magic))) {
        // A ZIP signature alone is insufficient: require an end-of-central-directory record.
        if (bytes.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06])) < 0) return "invalid";
        const directory = bytes.toString("latin1");
        if (directory.includes("[Content_Types].xml") && directory.includes("word/")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (directory.includes("[Content_Types].xml") && directory.includes("xl/")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        return "application/zip";
    }
    if (ascii.startsWith("OggS")) return declared.startsWith("video/") ? "video/ogg" : "audio/ogg";
    if (ascii.startsWith("RIFF") && bytes.subarray(8, 12).toString("ascii") === "WAVE") return "audio/wav";
    if (ascii.startsWith("ID3") || (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0)) return "audio/mpeg";
    if (bytes.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]))) return declared.startsWith("audio/") ? "audio/webm" : "video/webm";
    if (bytes.subarray(4, 8).toString("ascii") === "ftyp") return declared.startsWith("audio/") ? "audio/mp4" : "video/mp4";
    if (isText(bytes) && ["application/json", "text/plain", "text/csv", "text/css"].includes(declared)) {
        if (declared === "application/json") {
            try { JSON.parse(bytes.toString("utf8")); } catch { return "invalid"; }
        }
        return declared;
    }
    return "unknown";
}
function compatibleType(declared, detected) {
    if (declared === detected) return true;
    return (declared.startsWith("audio/") && detected.startsWith("audio/")) || (declared.startsWith("video/") && detected.startsWith("video/"));
}

async function portalShare(raw) {
    const rows = await request(`/rest/v1/client_portal_shares?token_hash=eq.${encodeURIComponent(hash(raw))}&select=id,project_id,created_by,expires_at,revoked_at&limit=1`);
    const share = Array.isArray(rows) ? rows[0] : null;
    if (!share || share.revoked_at || Date.parse(share.expires_at) <= Date.now()) throw new Error("PORTAL_UNAVAILABLE");
    try { await projectScope(share.project_id); } catch { throw new Error("PORTAL_UNAVAILABLE"); }
    return share;
}
async function createUpload(projectId, value, uploadedBy, clientVisible, context) {
    const countRows = await request(`/rest/v1/project_file_versions?project_id=eq.${encodeURIComponent(projectId)}&select=id`, { headers: { Prefer: "count=exact" } });
    if (Array.isArray(countRows) && countRows.length >= MAX_FILES_PER_PROJECT) throw new Error("FILE_COUNT_LIMIT");
    const name = clean(value.fileName, 240).replace(/[^a-zA-Z0-9._-]/g, "-");
    const mime = clean(value.mimeType || "application/octet-stream", 120).toLowerCase();
    const size = Number(value.byteSize);
    const fileId = uuid(value.fileId) ? value.fileId : crypto.randomUUID();
    const rightsSource = clean(value.assetRightsSource, 200);
    if (!name || !validType(mime) || !Number.isInteger(size) || size < 1 || size > MAX_FILE || value.assetRightsConfirmed !== true || !rightsSource) throw new Error("INVALID_FILE");
    const previous = await request(`/rest/v1/project_file_versions?file_id=eq.${encodeURIComponent(fileId)}&select=version,project_id&order=version.desc&limit=1`);
    if (previous?.[0] && previous[0].project_id !== projectId) throw new Error("FILE_ID_CONFLICT");
    const version = Math.max(1, Number(value.version) || (Number(previous?.[0]?.version || 0) + 1));
    const path = `${projectId}/${fileId}/v${version}-${name}`;
    if (context.portalShareId) {
        const shares = await request(`/rest/v1/client_portal_shares?id=eq.${encodeURIComponent(context.portalShareId)}&project_id=eq.${encodeURIComponent(projectId)}&revoked_at=is.null&select=id&limit=1`);
        if (!Array.isArray(shares) || !shares[0]) throw new Error("PORTAL_UNAVAILABLE");
    }
    if (context.event?.headers && Object.keys(context.event.headers).length) {
        await consumeQuota({ request: (requestPath, options) => authenticatedRequest(context.event, requestPath, options), userId: uploadedBy, projectId, resource: "storage_bytes", amount: size, limit: undefined });
    } else {
        const { consumePublicProjectQuota } = require("./_quota.js");
        await consumePublicProjectQuota({ request, projectId, resource: "storage_bytes", amount: size });
    }
    const rows = await request("/rest/v1/project_file_versions", {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify({
            project_id: projectId,
            work_context_id: context.workContextId,
            file_id: fileId,
            version,
            storage_path: path,
            file_name: name,
            mime_type: mime,
            byte_size: size,
            client_visible: clientVisible === true,
            uploaded_by: uploadedBy,
            verification_status: "pending",
            upload_expires_at: new Date(Date.now() + UPLOAD_TTL_MS).toISOString(),
            asset_rights_confirmed: true,
            asset_rights_source: rightsSource,
            portal_share_id: context.portalShareId || null
        })
    });
    const file = Array.isArray(rows) ? rows[0] : rows;
    if (!file?.id) throw new Error("STORAGE_UNAVAILABLE");
    let uploadUrl;
    try {
        uploadUrl = await signedUrl(path, true);
    } catch (error) {
        await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(file.id)}&project_id=eq.${encodeURIComponent(projectId)}&verification_status=eq.pending`, { method: "DELETE" }).catch(() => {});
        throw error;
    }
    return { file, uploadUrl };
}
async function cleanupExpiredUploads(projectId, workContextId) {
    const expired = await request(`/rest/v1/project_file_versions?project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(workContextId)}&verification_status=eq.pending&upload_expires_at=lt.${encodeURIComponent(new Date().toISOString())}&select=id,storage_path&limit=100`);
    let removed = 0;
    for (const file of Array.isArray(expired) ? expired : []) {
        await removeObject(file.storage_path).catch(() => {});
        const rows = await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(file.id)}&project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(workContextId)}&verification_status=eq.pending&select=id`, { method: "DELETE", headers: { Prefer: "return=representation" } });
        if (Array.isArray(rows) && rows[0]) removed += 1;
    }
    return removed;
}
async function finalizeUpload(projectId, value, actorId, portalShareId = "") {
    if (!uuid(value.id)) throw new Error("INVALID_FILE");
    const shareFilter = portalShareId ? `&portal_share_id=eq.${encodeURIComponent(portalShareId)}` : "";
    const rows = await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(value.id)}&project_id=eq.${encodeURIComponent(projectId)}${shareFilter}&verification_status=in.(pending,verified)&select=id,file_id,version,file_name,project_id,work_context_id,storage_path,mime_type,byte_size,client_visible,verification_status,sha256,uploaded_by,upload_expires_at,created_at&limit=1`);
    const file = Array.isArray(rows) ? rows[0] : null;
    if (!file) throw new Error("FILE_NOT_FOUND");
    if (file.verification_status === "verified") return file;
    if (Date.parse(file.upload_expires_at) <= Date.now()) {
        await removeObject(file.storage_path);
        await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(file.id)}&project_id=eq.${encodeURIComponent(projectId)}&verification_status=eq.pending`, { method: "DELETE" });
        throw new Error("UPLOAD_EXPIRED");
    }
    let bytes;
    let detected = "unknown";
    try {
        bytes = await readObject(file.storage_path);
        detected = detectedType(bytes, file.mime_type);
        if (ACTIVE_TYPES.has(file.mime_type) || bytes.length !== Number(file.byte_size) || !compatibleType(file.mime_type, detected)) throw new Error("INVALID_FILE_CONTENT");
        const updated = await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(file.id)}&project_id=eq.${encodeURIComponent(projectId)}${shareFilter}&verification_status=eq.pending&select=id,file_id,version,file_name,mime_type,byte_size,client_visible,verification_status,sha256,created_at`, {
            method: "PATCH",
            headers: { Prefer: "return=representation" },
            body: JSON.stringify({ verification_status: "verified", detected_mime_type: detected, sha256: hash(bytes), verified_at: new Date().toISOString(), verified_by: actorId })
        });
        if (!Array.isArray(updated) || !updated[0]) throw new Error("FILE_CONFLICT");
        return updated[0];
    } catch (error) {
        if (!["INVALID_FILE_CONTENT", "UPLOAD_MISSING"].includes(error.message)) throw error;
        await removeObject(file.storage_path).catch(() => {});
        await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(file.id)}&project_id=eq.${encodeURIComponent(projectId)}${shareFilter}&verification_status=eq.pending`, {
            method: "PATCH",
            body: JSON.stringify({ verification_status: "quarantined", detected_mime_type: detected, verified_at: new Date().toISOString(), verified_by: actorId })
        });
        throw new Error("INVALID_FILE_CONTENT");
    }
}

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "project-files", 40); if (blocked) return blocked;
    let finalizeOperation;
    let finalizeRequest;
    let finalizeActorId = "";
    let finalizeProjectId = "";
    let finalizeTokenHash = "";
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        const q = event.queryStringParameters || {};
        const projectId = uuid(q.projectId) ? q.projectId : "";
        if (!projectId) return response(400, { success: false, error: "A valid project is required." });

        const rawPortalToken = portalToken(event, q);
        if (rawPortalToken) {
            if (method !== "GET" && method !== "POST") return response(405, { success: false, error: "Unsupported file request." });
            const share = await portalShare(rawPortalToken);
            if (share.project_id !== projectId) throw new Error("PORTAL_UNAVAILABLE");
            const project = await projectScope(projectId);
            if (method === "GET") {
                const files = await request(`/rest/v1/project_file_versions?project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(project.work_context_id)}&client_visible=eq.true&verification_status=eq.verified&select=id,file_id,version,file_name,mime_type,byte_size,sha256,storage_path,created_at&order=created_at.desc&limit=100`);
                const result = await Promise.all((files || []).map(async ({ storage_path: storagePath, ...file }) => ({ ...file, downloadUrl: await signedUrl(storagePath) })));
                return response(200, { success: true, files: result });
            }
            const value = body(event);
            if (value.action === "finalize") {
                const key = idempotencyKey(event, value);
                if (!key) return response(400, { success: false, code: "IDEMPOTENCY_KEY_REQUIRED", error: "An idempotency key is required to finalize an upload." });
                finalizeTokenHash = hash(rawPortalToken);
                finalizeRequest = request;
                finalizeOperation = await beginPublicTokenOperation({ request, tokenHash: finalizeTokenHash, operation: "file.finalize", key, hash: requestHash({ projectId, fileId: value.id, shareId: share.id }) });
                if (finalizeOperation.replay) return response(200, { ...finalizeOperation.response, idempotentReplay: true });
                const payload = { success: true, file: await finalizeUpload(projectId, value, share.created_by, share.id) };
                await completePublicTokenOperation({ request, tokenHash: finalizeTokenHash, operation: "file.finalize", key: finalizeOperation.key, response: payload });
                return response(200, payload);
            }
            const upload = await createUpload(projectId, value, share.created_by, true, { workContextId: project.work_context_id, portalShareId: share.id });
            return response(201, { success: true, ...upload });
        }

        const user = await authenticate(event);
        const permission = await access(user.id, projectId, method !== "GET");
        if (method === "GET") {
            const files = await request(`/rest/v1/project_file_versions?project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(permission.project.work_context_id)}&select=id,file_id,version,file_name,mime_type,detected_mime_type,byte_size,client_visible,verification_status,sha256,uploaded_by,created_at&order=created_at.desc&limit=200`);
            if (q.action === "download" && uuid(q.id)) {
                const fileRows = await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(q.id)}&project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(permission.project.work_context_id)}&verification_status=eq.verified&select=storage_path&limit=1`);
                const file = Array.isArray(fileRows) ? fileRows[0] : null;
                if (!file) return response(404, { success: false, error: "File not found." });
                return response(200, { success: true, downloadUrl: await signedUrl(file.storage_path) });
            }
            return response(200, { success: true, files: files || [] });
        }
        if (method === "POST") {
            const value = body(event);
            if (value.action === "cleanup") return response(200, { success: true, removed: await cleanupExpiredUploads(projectId, permission.project.work_context_id) });
            if (value.action === "finalize") {
                const key = idempotencyKey(event, value);
                if (!key) return response(400, { success: false, code: "IDEMPOTENCY_KEY_REQUIRED", error: "An idempotency key is required to finalize an upload." });
                finalizeActorId = user.id;
                finalizeProjectId = projectId;
                finalizeRequest = (path, options = {}) => authenticatedRequest(event, path, options);
                finalizeOperation = await beginIdempotent({ request: finalizeRequest, actorId: user.id, projectId, operation: "file.finalize", key, hash: requestHash({ projectId, fileId: value.id }) });
                if (finalizeOperation.replay) return response(200, { ...finalizeOperation.response, idempotentReplay: true });
                const payload = { success: true, file: await finalizeUpload(projectId, value, user.id) };
                await completeIdempotent({ request: finalizeRequest, actorId: user.id, projectId, operation: "file.finalize", key: finalizeOperation.key, response: payload });
                return response(200, payload);
            }
            const upload = await createUpload(projectId, value, user.id, value.clientVisible === true, { event, workContextId: permission.project.work_context_id });
            return response(201, { success: true, ...upload });
        }
        if (method === "DELETE") {
            if (!uuid(q.id)) return response(400, { success: false, error: "A valid file version is required." });
            const rows = await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(q.id)}&project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(permission.project.work_context_id)}&select=id,storage_path`);
            if (!Array.isArray(rows) || !rows.length) return response(404, { success: false, error: "File not found." });
            await removeObject(rows[0].storage_path);
            const deleted = await request(`/rest/v1/project_file_versions?id=eq.${encodeURIComponent(q.id)}&project_id=eq.${encodeURIComponent(projectId)}&work_context_id=eq.${encodeURIComponent(permission.project.work_context_id)}&select=id`, { method: "DELETE", headers: { Prefer: "return=representation" } });
            if (!Array.isArray(deleted) || !deleted[0]) return response(409, { success: false, error: "The file changed before it could be deleted." });
            return response(200, { success: true });
        }
        return response(405, { success: false, error: "Unsupported file request." });
    } catch (error) {
        if (finalizeOperation?.enabled && !finalizeOperation.replay) {
            if (finalizeTokenHash) await abandonPublicTokenOperation({ request: finalizeRequest, tokenHash: finalizeTokenHash, operation: "file.finalize", key: finalizeOperation.key });
            else await abandonIdempotent({ request: finalizeRequest, actorId: finalizeActorId, projectId: finalizeProjectId, operation: "file.finalize", key: finalizeOperation.key });
        }
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "FORBIDDEN") return response(403, { success: false, error: "You do not have permission for this project file." });
        if (error.message === "PORTAL_UNAVAILABLE") return response(404, { success: false, error: "This client portal link is invalid, expired, or revoked." });
        if (error.message === "FILE_ID_CONFLICT" || error.message === "FILE_CONFLICT") return response(409, { success: false, error: "The file changed or its identifier belongs to another project." });
        if (error.message === "FILE_COUNT_LIMIT") return response(409, { success: false, code: "FILE_COUNT_LIMIT", error: "This project has reached its file limit." });
        if (error.message === "IDEMPOTENCY_CONFLICT") return response(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was used for another upload." });
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return response(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This upload is already being finalized." });
        if (error.message === "FILE_NOT_FOUND" || error.message === "UPLOAD_MISSING") return response(404, { success: false, error: "The pending upload was not found." });
        if (error.message === "UPLOAD_EXPIRED") return response(410, { success: false, error: "The pending upload expired and was removed." });
        if (error.message === "INVALID_FILE_CONTENT") return response(422, { success: false, error: "The uploaded bytes do not match the declared safe file type." });
        if (error.message === "INVALID_BODY" || error.message === "INVALID_FILE") return response(400, { success: false, error: "The file name, type, rights evidence, or size is invalid. Files must be supported and no larger than 50 MB." });
        const quota = quotaResponse(error, response); if (quota) return quota;
        if (error.message === "STORAGE_UNAVAILABLE" || error.message === "NOT_CONFIGURED") return response(503, { success: false, error: "Private file storage is not configured." });
        console.error("Project files API error:", error.message || error);
        return response(500, { success: false, error: "The project file request failed." });
    }
};
