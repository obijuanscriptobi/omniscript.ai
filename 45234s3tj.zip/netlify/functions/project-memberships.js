"use strict";

const crypto = require("crypto");
const { response, request, userRequest, authenticate, body, uuid, clean, guard } = require("./_platform.js");
const { consumeQuota, quotaResponse } = require("./_quota.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { requestId } = require("./_request-context.js");
const { log } = require("./_ops.js");

const ROLES = new Set(["admin", "sales", "marketing", "contributor", "client_reviewer"]);
const digest = (value) => crypto.createHash("sha256").update(String(value)).digest("hex");
const rawToken = () => crypto.randomBytes(32).toString("base64url");

async function membership(userId, projectId) {
    const rows = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}&select=role&limit=1`);
    return Array.isArray(rows) ? rows[0] : null;
}
async function requireManager(userId, projectId) {
    const member = await membership(userId, projectId);
    if (!member) throw new Error("FORBIDDEN");
    if (!["owner", "admin"].includes(member.role)) throw new Error("FORBIDDEN");
    return member;
}
async function activity(projectId, userId, payload) {
    await request("/rest/v1/business_operations", {
        method: "POST",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({ user_id: userId, project_id: projectId, kind: "activity", payload })
    });
}

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "project-memberships", 40);
    if (blocked) return blocked;
    let acceptance;
    let acceptanceRequest;
    let acceptanceUser;
    let acceptanceProjectId = "";
    try {
        const user = await authenticate(event);
        const method = String(event.httpMethod || "").toUpperCase();
        const q = event.queryStringParameters || {};
        const projectId = clean(q.projectId, 80);
        if (!uuid(projectId)) return response(400, { success: false, error: "A valid project is required." });

        if (method === "GET") {
            await requireManager(user.id, projectId);
            const members = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&select=project_id,user_id,role,created_at,updated_at&order=created_at.asc`);
            const invitations = await request(`/rest/v1/project_membership_invitations?project_id=eq.${encodeURIComponent(projectId)}&status=eq.pending&select=id,email,role,expires_at,created_at&order=created_at.desc`);
            return response(200, { success: true, members: Array.isArray(members) ? members : [], invitations: Array.isArray(invitations) ? invitations : [] });
        }

        const value = body(event);
        if (method === "POST" && q.action === "accept") {
            const inviteToken = clean(value.token, 200);
            const key = idempotencyKey(event, value);
            if (!inviteToken || !key) return response(400, { success: false, code: "INVALID_REQUEST", error: "Invitation token and idempotency key are required." });
            const rows = await request(`/rest/v1/project_membership_invitations?token_hash=eq.${encodeURIComponent(digest(inviteToken))}&project_id=eq.${encodeURIComponent(projectId)}&status=eq.pending&select=id,email,role,expires_at`);
            const invitation = Array.isArray(rows) ? rows[0] : null;
            if (!invitation || Date.parse(invitation.expires_at) <= Date.now()) throw new Error("INVITATION_UNAVAILABLE");
            if (String(user.email || "").toLowerCase() !== String(invitation.email).toLowerCase()) throw new Error("INVITATION_UNAVAILABLE");
            acceptanceUser = user;
            acceptanceProjectId = projectId;
            acceptanceRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: requestId(event) });
            acceptance = await beginIdempotent({ request: acceptanceRequest, actorId: user.id, projectId, operation: "invitation.accept", key, hash: requestHash({ invitationId: invitation.id, projectId, userId: user.id }) });
            if (acceptance.replay) return response(200, { ...acceptance.response, idempotentReplay: true });
            const accepted = await request(`/rest/v1/project_membership_invitations?id=eq.${encodeURIComponent(invitation.id)}&project_id=eq.${encodeURIComponent(projectId)}&token_hash=eq.${encodeURIComponent(digest(inviteToken))}&status=eq.pending&expires_at=gt.${encodeURIComponent(new Date().toISOString())}&select=id`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: "accepted" }) });
            if (!Array.isArray(accepted) || !accepted.length) throw new Error("INVITATION_UNAVAILABLE");
            try {
                await request("/rest/v1/project_memberships", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify({ project_id: projectId, user_id: user.id, role: invitation.role }) });
            } catch (error) {
                await request(`/rest/v1/project_membership_invitations?id=eq.${encodeURIComponent(invitation.id)}&project_id=eq.${encodeURIComponent(projectId)}&status=eq.accepted`, { method: "PATCH", body: JSON.stringify({ status: "pending" }) }).catch(() => {});
                throw error;
            }
            const payload = { success: true, projectId, role: invitation.role };
            await completeIdempotent({ request: acceptanceRequest, actorId: user.id, projectId, operation: "invitation.accept", key: acceptance.key, response: payload });
            await activity(projectId, user.id, { action: "membership.accepted", userId: user.id, role: invitation.role });
            return response(200, payload);
        }

        await requireManager(user.id, projectId);
        if (method === "POST") {
            const email = clean(value.email, 254).toLowerCase();
            const role = clean(value.role, 40);
            await consumeQuota({ request, userId: user.id, projectId, resource: "team_members" });
            log("quota.consumed", { event, resource: "team_members", projectId, actorId: user.id });
            if (!email.includes("@") || !ROLES.has(role)) return response(400, { success: false, error: "A valid email and role are required." });
            const token = rawToken();
            const rows = await request("/rest/v1/project_membership_invitations", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ project_id: projectId, invited_by: user.id, email, role, token_hash: digest(token), expires_at: new Date(Date.now() + 7 * 86400000).toISOString() }) });
            await activity(projectId, user.id, { action: "membership.invited", email, role });
            return response(201, { success: true, invitation: Array.isArray(rows) ? rows[0] : rows, token, path: `/invitation.html?projectId=${encodeURIComponent(projectId)}&token=${encodeURIComponent(token)}` });
        }
        const targetId = uuid(value.userId) ? value.userId : "";
        if (!targetId) return response(400, { success: false, error: "A valid member is required." });
        if (method === "PATCH") {
            const role = clean(value.role, 40);
            if (!ROLES.has(role)) return response(400, { success: false, error: "A valid role is required." });
            const target = await membership(targetId, projectId);
            if (!target || target.role === "owner") throw new Error("FORBIDDEN");
            const expectedUpdatedAt = clean(value.updatedAt, 80);
            if (!expectedUpdatedAt || Number.isNaN(Date.parse(expectedUpdatedAt))) return response(400, { success: false, code: "MEMBERSHIP_VERSION_REQUIRED", error: "The membership updatedAt value is required." });
            const rows = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(targetId)}&updated_at=eq.${encodeURIComponent(expectedUpdatedAt)}&select=project_id,user_id,role,updated_at`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ role, updated_at: new Date().toISOString() }) });
            if (!Array.isArray(rows) || !rows[0]) return response(409, { success: false, code: "MEMBERSHIP_CONFLICT", error: "The membership changed before it could be updated." });
            await activity(projectId, user.id, { action: "membership.role_changed", userId: targetId, before: target, after: rows[0], role });
            return response(200, { success: true, member: rows[0] });
        }
        if (method === "DELETE" && q.action === "revoke-invitation") {
            const invitationId = uuid(q.invitationId) ? q.invitationId : "";
            if (!invitationId) return response(400, { success: false, error: "A valid invitation is required." });
            const revoked = await request(`/rest/v1/project_membership_invitations?id=eq.${encodeURIComponent(invitationId)}&project_id=eq.${encodeURIComponent(projectId)}&status=eq.pending&select=id`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: "revoked" }) });
            if (!Array.isArray(revoked) || !revoked[0]) return response(404, { success: false, error: "Pending invitation not found." });
            await activity(projectId, user.id, { action: "membership.invitation_revoked", invitationId });
            return response(200, { success: true });
        }
        if (method === "DELETE") {
            const target = await membership(targetId, projectId);
            if (!target || target.role === "owner" || targetId === user.id) throw new Error("FORBIDDEN");
            const expectedUpdatedAt = clean(value.updatedAt, 80);
            if (!expectedUpdatedAt || Number.isNaN(Date.parse(expectedUpdatedAt))) return response(400, { success: false, code: "MEMBERSHIP_VERSION_REQUIRED", error: "The membership updatedAt value is required." });
            const removed = await request(`/rest/v1/project_memberships?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(targetId)}&updated_at=eq.${encodeURIComponent(expectedUpdatedAt)}&select=project_id,user_id,role`, { method: "DELETE", headers: { Prefer: "return=representation" } });
            if (!Array.isArray(removed) || !removed[0]) return response(409, { success: false, code: "MEMBERSHIP_CONFLICT", error: "The membership changed before it could be revoked." });
            await activity(projectId, user.id, { action: "membership.revoked", userId: targetId, before: target });
            return response(200, { success: true });
        }
        return response(405, { success: false, error: "Unsupported membership request." });
    } catch (error) {
        if (acceptance?.enabled && !acceptance.replay) await abandonIdempotent({ request: acceptanceRequest, actorId: acceptanceUser?.id, projectId: acceptanceProjectId, operation: "invitation.accept", key: acceptance.key });
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "FORBIDDEN") return response(403, { success: false, error: "Only project owners and admins can manage members." });
        if (["INVITATION_UNAVAILABLE", "INVITATION_CONFLICT"].includes(error.message)) return response(404, { success: false, error: "This project invitation is invalid, expired, or already used." });
        if (error.message === "IDEMPOTENCY_CONFLICT") return response(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for another invitation." });
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return response(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This invitation is already being accepted." }, { "Retry-After": "2" });
        if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The membership request is invalid." });
        const quota = quotaResponse(error, response);
        if (quota) return quota;
        console.error("Project memberships API error:", error.message || error);
        return response(500, { success: false, error: "The project membership request failed." });
    }
};
