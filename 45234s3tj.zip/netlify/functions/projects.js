"use strict";

const {
    limitedResponseAsync,
    securityHeaders
} = require("./_security.js");
const { providerClient, requestId } = require("./provider-adapters.js");
const { consumeQuota, quotaResponse } = require("./_quota.js");

const MAX_BODY_BYTES = 5_000_000;
const MAX_FILE_BYTES = 1_000_000;
const MAX_TOTAL_FILE_BYTES = 4_500_000;
const MAX_FORM_VALUE_LENGTH = 2_000;
const MAX_PROJECT_VERSIONS = 50;
const UPSTREAM_TIMEOUT_MS = 10_000;

const ALLOWED_FILES = [
    "index.html",
    "style.css",
    "script.js",
    "netlify.toml",
    "submit-form.js",
    "sitemap.xml",
    "robots.txt",
    "favicon.svg",
    "privacy.html",
    "netlify/functions/submit-form.js"
];

function isAllowedFilename(filename) {
    return (
        ALLOWED_FILES.includes(filename) ||
        /^[a-z0-9][a-z0-9-]{0,119}\.html$/i.test(filename)
    );
}

const ALLOWED_PREVIEW_MODES = ["desktop", "tablet", "mobile"];

function response(statusCode, payload) {
    return {
        statusCode,
        isBase64Encoded: false,
        headers: securityHeaders(),
        body: JSON.stringify(payload)
    };
}

function header(event, name) {
    const headers =
        event && event.headers && typeof event.headers === "object"
            ? event.headers
            : {};
    const target = name.toLowerCase();

    const key = Object.keys(headers).find(
        (entry) => String(entry).toLowerCase() === target
    );

    return key ? String(headers[key] ?? "") : "";
}

function supabaseConfig() {
    const rawUrl = String(process.env.SUPABASE_URL || "").trim();
    const key = String(process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();

    if (!rawUrl || !key) throw new Error("NOT_CONFIGURED");

    let parsed;

    try {
        parsed = new URL(rawUrl);
    } catch {
        throw new Error("INVALID_CONFIG");
    }

    if (
        parsed.protocol !== "https:" ||
        parsed.username ||
        parsed.password ||
        parsed.port ||
        parsed.pathname !== "/" ||
        parsed.search ||
        parsed.hash ||
        !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.supabase\.co$/i.test(parsed.hostname)
    ) {
        throw new Error("INVALID_CONFIG");
    }

    return {
        url: parsed.origin,
        key
    };
}

async function supabaseRequest(path, options = {}) {
    const { url, key } = supabaseConfig();
    const requestOptions = options && typeof options === "object" ? options : {};
    const configuredHeaders = requestOptions.headers && typeof requestOptions.headers === "object" && !Array.isArray(requestOptions.headers)
        ? requestOptions.headers
        : {};
    const client = providerClient("supabase", {
        endpoint: url,
        retries: 0,
        timeoutMs: UPSTREAM_TIMEOUT_MS,
        requestId: requestOptions.requestId
    });
    const result = await client.request(path, {
        ...requestOptions,
        headers: {
            ...configuredHeaders,
            apikey: key,
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json"
        }
    });
    return result.data;
}

async function authenticate(event) {
    const authorization = header(event, "authorization");
    if (!/^Bearer\s+\S+$/i.test(authorization)) throw new Error("UNAUTHORIZED");
    const { url } = supabaseConfig();
    const anonKey = String(process.env.SUPABASE_ANON_KEY || "").trim();
    if (!anonKey) throw new Error("UNAUTHORIZED");
    const client = providerClient("supabase", {
        endpoint: url,
        retries: 0,
        timeoutMs: UPSTREAM_TIMEOUT_MS,
        requestId: requestId(event)
    });
    try {
        const result = await client.request("/auth/v1/user", {
            headers: { apikey: anonKey, Authorization: authorization }
        });
        if (!result.data || typeof result.data !== "object" || !result.data.id) throw new Error("UNAUTHORIZED");
        return result.data;
    } catch {
        throw new Error("UNAUTHORIZED");
    }
}

function parseBody(event) {
    const body = String(event?.body || "");
    let bodyBuffer;

    try {
        if (event?.isBase64Encoded) {
            if (
                !body ||
                body.length % 4 !== 0 ||
                !/^[A-Za-z0-9+/]*={0,2}$/.test(body)
            ) {
                throw new Error("INVALID_BODY");
            }
            bodyBuffer = Buffer.from(body, "base64");
            if (
                bodyBuffer.toString("base64").replace(/=+$/, "") !==
                body.replace(/=+$/, "")
            ) {
                throw new Error("INVALID_BODY");
            }
        } else {
            bodyBuffer = Buffer.from(body, "utf8");
        }
    } catch {
        throw new Error("INVALID_BODY");
    }

    if (bodyBuffer.length > MAX_BODY_BYTES) {
        throw new Error("TOO_LARGE");
    }

    let value;

    try {
        value = JSON.parse(bodyBuffer.toString("utf8") || "{}");
    } catch {
        throw new Error("INVALID_BODY");
    }

    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error("INVALID_BODY");
    }

    return value;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function projectId(event) {
    const value = event?.queryStringParameters?.id;

    if (typeof value !== "string" || !value) return "";

    return UUID.test(value) ? value : null;
}

function cleanString(value, maximum) {
    return String(value ?? "")
        .replace(/[\u0000-\u001f\u007f]/g, "")
        .slice(0, maximum);
}

function validateFiles(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error("INVALID_FILES");
    }

    const files = {};
    let totalBytes = 0;

    for (const [filename, contents] of Object.entries(value)) {
        if (!isAllowedFilename(filename)) {
            throw new Error("INVALID_FILES");
        }

        if (typeof contents !== "string") {
            throw new Error("INVALID_FILES");
        }

        const size = Buffer.byteLength(contents, "utf8");

        if (size > MAX_FILE_BYTES) {
            throw new Error("FILE_TOO_LARGE");
        }

        totalBytes += size;

        if (totalBytes > MAX_TOTAL_FILE_BYTES) {
            throw new Error("FILES_TOO_LARGE");
        }

        files[filename] = contents;
    }

    return files;
}

function validateFormData(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error("INVALID_FORM");
    }

    const formData = {};

    for (const [key, entry] of Object.entries(value)) {
        if (!/^[a-zA-Z0-9_-]{1,80}$/.test(key)) {
            throw new Error("INVALID_FORM");
        }

        if (
            typeof entry !== "string" &&
            typeof entry !== "number" &&
            typeof entry !== "boolean"
        ) {
            throw new Error("INVALID_FORM");
        }

        formData[key] = cleanString(entry, MAX_FORM_VALUE_LENGTH);
    }

    return formData;
}

function projectPayload(body, userId) {
    const name = cleanString(body.name || "Untitled project", 200).trim();
    const workContextId = UUID.test(String(body.workContextId || ""))
        ? String(body.workContextId)
        : (() => { throw new Error("INVALID_CONTEXT"); })();

    const files = validateFiles(body.files || {});
    const formData = validateFormData(body.formData || {});

    const previewMode = ALLOWED_PREVIEW_MODES.includes(body.previewMode)
        ? body.previewMode
        : "desktop";

    return {
        user_id: userId,
        name: name || "Untitled project",
        work_context_id: workContextId,
        files,
        form_data: formData,
        preview_mode: previewMode
    };
}

function expectedRevision(body) {
    if (body.expectedRevision === undefined || body.expectedRevision === null) {
        return "";
    }

    const value = String(body.expectedRevision).trim();

    if (!value || value.length > 100 || Number.isNaN(Date.parse(value))) {
        throw new Error("INVALID_REVISION");
    }

    return value;
}

function projectSelect() {
    return "id,name,work_context_id,files,form_data,preview_mode,lifecycle,revision,approval_revision,preflight_revision,published_revision,verified_revision,created_at,updated_at";
}

function versionId(event) {
    const value = event?.queryStringParameters?.version;

    if (typeof value !== "string" || !value) return "";

    return UUID.test(value) ? value : null;
}

async function getOwnedVersions(projectId, userId) {
    const ownership = `project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}`;
    return supabaseRequest(
        `/rest/v1/project_versions?${ownership}&select=id,project_id,files,form_data,preview_mode,created_at&order=created_at.desc`
    );
}

async function getOwnedVersion(projectId, id, userId) {
    const ownership = `id=eq.${encodeURIComponent(id)}&project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}`;
    const versions = await supabaseRequest(
        `/rest/v1/project_versions?${ownership}&select=id,project_id,files,form_data,preview_mode,created_at`
    );
    return Array.isArray(versions) ? versions[0] || null : null;
}

async function getOwnedWorkContext(workContextId, userId) {
    if (!workContextId) return null;
    const memberships = await supabaseRequest(`/rest/v1/organization_members?user_id=eq.${encodeURIComponent(userId)}&status=eq.active&revoked_at=is.null&select=organization_id`);
    const organizationIds = (Array.isArray(memberships) ? memberships : []).map((item) => item.organization_id).filter(UUID.test);
    if (!organizationIds.length) return null;
    const contexts = await supabaseRequest(`/rest/v1/work_contexts?id=eq.${encodeURIComponent(workContextId)}&organization_id=in.(${organizationIds.map(encodeURIComponent).join(",")})&status=eq.active&select=id,kind,approval_contact,permissions_confirmed,asset_rights_confirmed&limit=1`);
    return Array.isArray(contexts) ? contexts[0] || null : null;
}

async function canUseWorkContext(workContextId, userId) {
    return Boolean(await getOwnedWorkContext(workContextId, userId));
}

async function getOwnedProject(id, userId, workContextId = "") {
    if (workContextId && !await canUseWorkContext(workContextId, userId)) return null;
    const contextFilter = workContextId ? `&work_context_id=eq.${encodeURIComponent(workContextId)}` : "";
    const ownership = `id=eq.${encodeURIComponent(
        id
    )}&user_id=eq.${encodeURIComponent(userId)}${contextFilter}`;

    const projects = await supabaseRequest(
        `/rest/v1/projects?${ownership}&select=${projectSelect()}`
    );

    return Array.isArray(projects) ? projects[0] || null : null;
}

async function createVersion(projectId, userId, payload) {
    await supabaseRequest("/rest/v1/project_versions", {
        method: "POST",
        body: JSON.stringify({
            project_id: projectId,
            user_id: userId,
            files: payload.files,
            form_data: payload.form_data,
            preview_mode: payload.preview_mode
        })
    });

    // Keep version history bounded. Autosave must not create unbounded storage
    // growth or retain project content indefinitely.
    const versions = await supabaseRequest(
        `/rest/v1/project_versions?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}&select=id&order=created_at.desc`
    );
    const staleIds = (Array.isArray(versions) ? versions : [])
        .slice(MAX_PROJECT_VERSIONS)
        .map((version) => version?.id)
        .filter((id) => /^[0-9a-f-]{36}$/i.test(String(id)));

    if (staleIds.length) {
        await supabaseRequest(
            `/rest/v1/project_versions?project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(userId)}&id=in.(${staleIds.map((id) => encodeURIComponent(id)).join(",")})`,
            { method: "DELETE" }
        );
    }
}

exports.authenticate = authenticate;
exports.supabaseRequest = supabaseRequest;
exports.getOwnedProject = getOwnedProject;
exports.getOwnedWorkContext = getOwnedWorkContext;
exports.canUseWorkContext = canUseWorkContext;

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, {
        namespace: "projects",
        limit: 60,
        windowMs: 60_000
    });

    if (blocked) return blocked;

    try {
        const method = String(event.httpMethod || "").toUpperCase();

        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) {
            return response(405, {
                success: false,
                error: "Unsupported request method."
            });
        }

        const user = await authenticate(event);
        const id = projectId(event);
        const requestedVersion = versionId(event);
        const requestedContext = event?.queryStringParameters?.workContextId || "";
        if (method !== "POST" && !UUID.test(requestedContext)) return response(400, { success: false, error: "A valid work context ID is required." });

        if (id === null || requestedVersion === null) {
            return response(400, {
                success: false,
                error: "Invalid project or version ID."
            });
        }

        if (requestedVersion && (!id || method !== "GET")) {
            return response(400, {
                success: false,
                error: "A version request requires a project ID and GET method."
            });
        }

        if (id === null) {
            return response(400, {
                success: false,
                error: "Invalid project ID."
            });
        }

        if (method === "GET" && !id) {
            if (requestedContext && !await canUseWorkContext(requestedContext, user.id)) {
                return response(404, { success: false, error: "Work context not found." });
            }
            const contextFilter = requestedContext ? `&work_context_id=eq.${encodeURIComponent(requestedContext)}` : "";
            const projects = await supabaseRequest(
                `/rest/v1/projects?user_id=eq.${encodeURIComponent(
                    user.id
                )}${contextFilter}&select=${projectSelect()}&order=updated_at.desc`
            );

            return response(200, {
                success: true,
                projects: Array.isArray(projects) ? projects : []
            });
        }

        if (method === "GET" && requestedVersion) {
            const project = await getOwnedProject(id, user.id, requestedContext);
            if (!project) {
                return response(404, { success: false, error: "Project not found." });
            }

            const version = await getOwnedVersion(id, requestedVersion, user.id);
            if (!version) {
                return response(404, { success: false, error: "Version not found." });
            }

            return response(200, { success: true, version });
        }

        if (method === "GET" && !requestedVersion) {
            const project = await getOwnedProject(id, user.id, requestedContext);
            if (!project) {
                return response(404, { success: false, error: "Project not found." });
            }

            const versions = await getOwnedVersions(id, user.id);
            return response(200, {
                success: true,
                project,
                versions: Array.isArray(versions) ? versions : []
            });
        }

        if (method === "POST") {
            if (id) {
                return response(400, {
                    success: false,
                    error: "POST creates a new project and cannot include a project ID."
                });
            }

            const body = parseBody(event);
            const payload = projectPayload(body, user.id);
            if (payload.work_context_id && !await canUseWorkContext(payload.work_context_id, user.id)) {
                return response(404, { success: false, error: "Work context not found." });
            }
            await consumeQuota({ request: supabaseRequest, userId: user.id, resource: "projects" });

            const projects = await supabaseRequest(
                `/rest/v1/projects?select=${projectSelect()}`,
                {
                    method: "POST",
                    headers: { Prefer: "return=representation" },
                    body: JSON.stringify(payload)
                }
            );

            const project = Array.isArray(projects) ? projects[0] : null;

            if (!project?.id) {
                throw new Error("PROJECT_NOT_CREATED");
            }

            await createVersion(project.id, user.id, payload);

            return response(201, {
                success: true,
                project
            });
        }

        if (!id) {
            return response(400, {
                success: false,
                error: "A project ID is required."
            });
        }

        const ownership = `id=eq.${encodeURIComponent(
            id
        )}&user_id=eq.${encodeURIComponent(user.id)}${requestedContext ? `&work_context_id=eq.${encodeURIComponent(requestedContext)}` : ""}`;

        if (method === "GET") {
            const project = await getOwnedProject(id, user.id);

            if (!project) {
                return response(404, {
                    success: false,
                    error: "Project not found."
                });
            }

            return response(200, {
                success: true,
                project
            });
        }

        if (method === "DELETE") {
            if (!await getOwnedProject(id, user.id, requestedContext)) {
                return response(404, { success: false, error: "Project not found in this work context." });
            }
            await supabaseRequest(`/rest/v1/projects?${ownership}`, {
                method: "DELETE"
            });

            return response(200, {
                success: true,
                message: "Project deleted."
            });
        }

        const body = parseBody(event);
        const revision = expectedRevision(body);
        const hasProjectData = ["files", "formData", "previewMode"].some((key) => Object.prototype.hasOwnProperty.call(body, key));
        let payload;

        if (hasProjectData) {
            payload = {};
            if (Object.prototype.hasOwnProperty.call(body, "name")) {
                const name = cleanString(body.name, 200).trim();
                if (!name) {
                    throw new Error("INVALID_FORM");
                }
                payload.name = name;
            }
            if (Object.prototype.hasOwnProperty.call(body, "files")) {
                payload.files = validateFiles(body.files);
            }
            if (Object.prototype.hasOwnProperty.call(body, "formData")) {
                payload.form_data = validateFormData(body.formData);
            }
            if (Object.prototype.hasOwnProperty.call(body, "previewMode")) {
                if (!ALLOWED_PREVIEW_MODES.includes(body.previewMode)) {
                    throw new Error("INVALID_FORM");
                }
                payload.preview_mode = body.previewMode;
            }
            if (!Object.keys(payload).length) {
                throw new Error("INVALID_FORM");
            }
        } else {
            const name = cleanString(body.name, 200).trim();
            if (!name) {
                throw new Error("INVALID_FORM");
            }
            payload = { name };
        }

        const revisionFilter = revision
            ? `&updated_at=eq.${encodeURIComponent(revision)}`
            : "";

        const projects = await supabaseRequest(
            `/rest/v1/projects?${ownership}${revisionFilter}&select=${projectSelect()}`,
            {
                method: "PATCH",
                headers: { Prefer: "return=representation" },
                body: JSON.stringify(payload)
            }
        );

        if (!Array.isArray(projects) || !projects[0]) {
            const latestProject = await getOwnedProject(id, user.id, requestedContext);

            if (!latestProject) {
                return response(404, {
                    success: false,
                    error: "Project not found."
                });
            }

            if (revision) {
                return response(409, {
                    success: false,
                    code: "PROJECT_CONFLICT",
                    error: "The project was changed elsewhere.",
                    project: latestProject
                });
            }

            return response(404, {
                success: false,
                error: "Project not found."
            });
        }

        if (hasProjectData) {
            const snapshot = projects[0];
            await consumeQuota({ request: supabaseRequest, userId: user.id, projectId: id, resource: "versions" });
            await createVersion(id, user.id, {
                files: snapshot.files || {},
                form_data: snapshot.form_data || {},
                preview_mode: snapshot.preview_mode || "desktop"
            });
        }

        return response(200, {
            success: true,
            project: projects[0]
        });
    } catch (error) {
        const errorCode =
            error && typeof error.message === "string"
                ? error.message
                : "";

        if (errorCode === "UNAUTHORIZED") {
            return response(401, {
                success: false,
                error: "Please sign in first."
            });
        }

        if (errorCode === "NOT_CONFIGURED") {
            return response(503, {
                success: false,
                error: "Supabase is not configured."
            });
        }

        if (errorCode === "INVALID_CONFIG") {
            return response(500, {
                success: false,
                error: "Supabase configuration is invalid."
            });
        }

        const quota = quotaResponse(error, response);
        if (quota) return quota;

        if (errorCode === "TOO_LARGE") {
            return response(413, {
                success: false,
                error: "The project payload is too large."
            });
        }

        if (
            [
                "INVALID_BODY",
                "INVALID_FILES",
                "INVALID_FORM",
                "INVALID_REVISION",
                "INVALID_CONTEXT",
                "PROJECT_NOT_CREATED"
            ].includes(errorCode)
        ) {
            return response(400, {
                success: false,
                error: "The project data is invalid."
            });
        }

        if (["FILE_TOO_LARGE", "FILES_TOO_LARGE"].includes(errorCode)) {
            return response(413, {
                success: false,
                error: "One or more project files exceed the allowed size."
            });
        }

        console.error("Project API error:", error?.message || error);

        return response(500, {
            success: false,
            error: "The project request failed."
        });
    }
};