"use strict";

const { requestId } = require("./_request-context.js");

const DEFAULT_TIMEOUT_MS = 10_000;
const DEFAULT_RETRIES = 2;
const CIRCUIT_FAILURE_THRESHOLD = 5;
const CIRCUIT_COOLDOWN_MS = 30_000;
const circuits = new Map();
const SECRET_PATTERN = /(bearer\s+|api[_-]?key|token|secret|password|authorization)\s*[:=]?\s*[^\s,;]+/gi;

function safeMessage(error) {
    const message = String(error?.message || error || "Provider request failed.")
        .replace(SECRET_PATTERN, "$1[REDACTED]")
        .replace(/[\r\n]+/g, " ")
        .slice(0, 300);
    return message || "Provider request failed.";
}

function providerError(provider, error, details = {}) {
    const status = Number(error?.status || details.status || 0);
    const retryable = Boolean(
        error?.retryable || status === 408 || status === 425 || status === 429 || status >= 500
    );
    const normalized = new Error(safeMessage(error));
    normalized.name = "ProviderError";
    normalized.provider = provider;
    normalized.status = status || undefined;
    normalized.retryable = retryable;
    normalized.requestId = requestId(details.requestId);
    return normalized;
}

function timeoutSignal(timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    return { signal: controller.signal, controller, clear: () => clearTimeout(timer) };
}

async function fetchRaw(url, options = {}, settings = {}) {
    const provider = settings.provider || "provider";
    const fetchImpl = settings.fetch || globalThis.fetch;
    const timeoutMs = Number(settings.timeoutMs) || DEFAULT_TIMEOUT_MS;
    const id = requestId(settings.requestId);
    const control = timeoutSignal(timeoutMs);
    const externalSignal = options.signal;
    const abortExternal = () => control.signal.aborted || control.controller.abort();
    if (externalSignal?.aborted) control.controller.abort();
    if (externalSignal?.addEventListener) externalSignal.addEventListener("abort", abortExternal, { once: true });

    try {
        const response = await fetchImpl(url, {
            ...options,
            headers: { ...(options.headers || {}), "X-Request-ID": id },
            signal: control.signal
        });

        return { response, status: response.status, requestId: id };
    } catch (error) {
        if (error?.name === "AbortError") {
            error = Object.assign(new Error(externalSignal?.aborted ? "Provider request cancelled." : "Provider request timed out."), { retryable: !externalSignal?.aborted, status: externalSignal?.aborted ? 499 : 504 });
        }
        throw providerError(provider, error, { requestId: id });
    } finally {
        if (externalSignal?.removeEventListener) externalSignal.removeEventListener("abort", abortExternal);
        control.clear();
    }
}

async function fetchJson(url, options = {}, settings = {}) {
    const result = await fetchRaw(url, options, settings);
    const text = await result.response.text().catch(() => "");
    let data = {};
    if (text) {
        try {
            data = JSON.parse(text);
        } catch {
            const error = new Error("Provider returned malformed JSON.");
            error.status = result.response.status;
            error.retryable = result.response.status >= 500 || result.response.status === 429;
            throw providerError(settings.provider || "provider", error, { requestId: result.requestId });
        }
    }
    if (!result.response.ok) {
        const error = new Error(data.message || data.error || `HTTP ${result.response.status}`);
        error.status = result.response.status;
        throw providerError(settings.provider || "provider", error, { requestId: result.requestId });
    }
    return { data, status: result.status, requestId: result.requestId };
}

function circuitState(provider) {
    const now = Date.now();
    const state = circuits.get(provider) || { failures: 0, openedAt: 0, halfOpen: false };
    if (state.openedAt && now - state.openedAt < CIRCUIT_COOLDOWN_MS) throw providerError(provider, Object.assign(new Error("Provider circuit is open."), { status: 503, retryable: true }));
    if (state.openedAt) state.halfOpen = true;
    circuits.set(provider, state);
    return state;
}

async function withRetry(operation, settings = {}) {
    const retries = Number.isInteger(settings.retries) ? Math.max(0, Math.min(settings.retries, 5)) : DEFAULT_RETRIES;
    const provider = settings.provider || "provider";
    const state = circuitState(provider);
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt += 1) {
        try {
            const result = await operation(attempt);
            circuits.delete(provider);
            return result;
        } catch (error) {
            lastError = error;
            if (error?.retryable) {
                state.failures += 1;
                if (state.failures >= CIRCUIT_FAILURE_THRESHOLD || state.halfOpen) state.openedAt = Date.now();
                circuits.set(provider, state);
            }
            if (!error?.retryable || attempt === retries || state.openedAt) throw error;
            await new Promise((resolve) => setTimeout(resolve, Math.min(250 * 2 ** attempt, 2_000)));
        }
    }
    throw lastError;
}

function required(value, message) {
    if (!String(value || "").trim()) throw providerError("configuration", new Error(message));
    return String(value).trim();
}

function deploymentAdapter(name, env = process.env, options = {}) {
    const fetchImpl = options.fetch || globalThis.fetch;
    const settings = { fetch: fetchImpl, timeoutMs: options.timeoutMs, retries: options.retries, requestId: options.requestId, provider: name };
    const call = (url, request) => withRetry(() => fetchJson(url, request, { ...settings, provider: name }), settings);
    if (name !== "netlify") throw providerError(name, new Error("Unsupported deployment provider."));
    const token = () => required(env.NETLIFY_AUTH_TOKEN, "Netlify is not configured.");
    const site = () => encodeURIComponent(required(env.NETLIFY_SITE_ID, "Netlify site is not configured."));
    return {
        async deploy(zip) { return call(`https://api.netlify.com/api/v1/sites/${site()}/deploys`, { method: "POST", headers: { Authorization: `Bearer ${token()}`, "Content-Type": "application/zip" }, body: zip }); },
        async status(id) { return call(`https://api.netlify.com/api/v1/sites/${site()}/deploys/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${token()}` } }); },
        async rollback(id) { return call(`https://api.netlify.com/api/v1/sites/${site()}/deploys/${encodeURIComponent(id)}/restore`, { method: "POST", headers: { Authorization: `Bearer ${token()}` } }); }
    };
}

function providerClient(name, options = {}) {
    const env = options.env || process.env;
    const fetchImpl = options.fetch || globalThis.fetch;
    const settings = { ...options, fetch: fetchImpl, provider: name };
    const endpoint = String(options.endpoint || env[`${name.toUpperCase()}_URL`] || "").replace(/\/$/, "");
    return {
        async request(path = "", request = {}) {
            const url = /^https?:\/\//i.test(path) ? path : `${endpoint}${path}`;
            if (!endpoint && !/^https?:\/\//i.test(path)) throw providerError(name, new Error(`${name} is not configured.`));
            const operation = request.raw ? fetchRaw : fetchJson;
            const { raw, ...fetchOptions } = request;
            return withRetry(() => operation(url, fetchOptions, settings), settings);
        }
    };
}

module.exports = { deploymentAdapter, providerClient, fetchRaw, fetchJson, withRetry, providerError, safeMessage, requestId };
