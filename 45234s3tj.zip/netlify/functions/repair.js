"use strict";

const repairFunction = require("../../netlify_functions_repair.js");
const {
    limitedResponseAsync,
    maxBodyResponse,
    securityHeaders
} = require("./_security.js");

const RATE_LIMIT = Object.freeze({
    namespace: "repair",
    limit: 5,
    windowMs: 60_000
});

const MAX_BODY_BYTES = 1_200_000;

function jsonResponse(statusCode, payload, extraHeaders = {}) {
    return {
        statusCode,
        isBase64Encoded: false,
        headers: buildHeaders(extraHeaders),
        body: JSON.stringify(payload)
    };
}

function buildHeaders(configuredHeaders = {}) {
    const source =
        configuredHeaders && typeof configuredHeaders === "object"
            ? configuredHeaders
            : {};

    const enforcedHeaders = securityHeaders({
        "Content-Type": "application/json; charset=utf-8"
    });

    const enforcedNames = new Set(
        Object.keys(enforcedHeaders).map((name) => name.toLowerCase())
    );

    const headers = {};

    for (const [name, value] of Object.entries(source)) {
        if (!enforcedNames.has(name.toLowerCase())) {
            headers[name] = value;
        }
    }

    return {
        ...headers,
        ...enforcedHeaders
    };
}

function invalidResponse() {
    return jsonResponse(502, {
        success: false,
        error: "The repair service returned an invalid response."
    });
}

function normalizeResult(result) {
    if (!result || typeof result !== "object") {
        return invalidResponse();
    }

    const body =
        typeof result.body === "string"
            ? result.body
            : JSON.stringify({
                  success: false,
                  error: "The repair service returned an invalid response."
              });

    return {
        statusCode: Number.isInteger(result.statusCode)
            ? result.statusCode
            : 502,
        isBase64Encoded: Boolean(result.isBase64Encoded),
        headers: buildHeaders(result.headers),
        body
    };
}

exports.handler = async function handler(event = {}, context = {}) {
    const blocked = await limitedResponseAsync(event, RATE_LIMIT);
    if (blocked) return normalizeResult(blocked);

    const oversized = maxBodyResponse(event, MAX_BODY_BYTES);
    if (oversized) return normalizeResult(oversized);

    try {
        const result = await repairFunction.handler(event, context);
        return normalizeResult(result);
    } catch (error) {
        console.error("Repair function failed:", error?.message || error);

        return jsonResponse(500, {
            success: false,
            error: "The repair request could not be completed."
        });
    }
};