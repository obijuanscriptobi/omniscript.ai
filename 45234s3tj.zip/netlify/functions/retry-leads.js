"use strict";

const { config, request } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");

const MAX_ATTEMPTS = 8;
const MAX_BATCH = 25;

function authorized(event) {
    const expected = String(process.env.LEAD_RETRY_CRON_SECRET || "").trim();
    const supplied = String(event.headers?.authorization || event.headers?.Authorization || "").trim();
    return expected && supplied === `Bearer ${expected}`;
}

function webhook() {
    const value = String(process.env.LEADS_WEBHOOK_URL || "").trim();
    const allowed = String(process.env.LEADS_WEBHOOK_HOSTS || "").split(",").map((item) => item.trim().toLowerCase()).filter(Boolean);
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.port || !allowed.includes(url.hostname.toLowerCase())) throw new Error("WEBHOOK_NOT_ALLOWED");
    return url;
}

exports.handler = async (event = {}) => {
    if (!authorized(event)) return { statusCode: 401, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify({ success: false, error: "Unauthorized." }) };
    if (!process.env.LEAD_RETRY_CRON_SECRET) return { statusCode: 503, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify({ success: false, error: "Retry worker is not configured." }) };
    try {
        const { url, key } = config();
        const webhookClient = providerClient("webhook", { retries: 0, timeoutMs: 8_000, requestId: requestId(event) });
        const claimed = await request("/rest/v1/rpc/claim_lead_delivery_failures", { method: "POST", body: JSON.stringify({ batch_size: MAX_BATCH }) });
        const records = Array.isArray(claimed) ? claimed : [];
        let delivered = 0;
        let failed = 0;
        const target = webhook();
        for (const record of records) {
            try {
                const response = await webhookClient.request(target, { raw: true, method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json", "Idempotency-Key": record.submission_id }, body: JSON.stringify(record.payload) });
                const upstream = response.response || response;
                if (!upstream.ok) throw new Error(`HTTP_${upstream.status}`);
                await request(`/rest/v1/lead_delivery_failures?id=eq.${encodeURIComponent(record.id)}`, { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ status: "delivered", last_error: "", updated_at: new Date().toISOString() }) });
                delivered += 1;
            } catch (error) {
                failed += 1;
                await request(`/rest/v1/lead_delivery_failures?id=eq.${encodeURIComponent(record.id)}`, { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ last_error: String(error.message || "Delivery failed").slice(0, 500), status: Number(record.attempts) >= MAX_ATTEMPTS ? "dead-letter" : "pending", updated_at: new Date().toISOString() }) }).catch(() => {});
            }
        }
        return { statusCode: 200, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify({ success: true, claimed: records.length, delivered, failed, requestId: requestId(event) }) };
    } catch (error) {
        console.error("Lead retry worker failed:", error.message || error);
        return { statusCode: 502, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify({ success: false, error: "Retry worker failed.", requestId: requestId(event) }) };
    }
};
