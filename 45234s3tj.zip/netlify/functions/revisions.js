"use strict";

const { limitedResponseAsync, securityHeaders, requestId } = require("./_security.js");
const { authenticate, supabaseRequest, getOwnedProject } = require("./projects.js");
const { userRequest } = require("./_platform.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { auditEvent } = require("./_ops.js");

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const STATUSES = new Set(["draft", "validation-failed", "ready-for-review", "approved", "rejected", "deployed", "rolled-back"]);
const clean = (value, max = 20000) => String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").slice(0, max);
function response(event, statusCode, payload) { const id = requestId(event); return { statusCode, headers: securityHeaders({ "Cache-Control": "no-store", "X-Request-ID": id }), body: JSON.stringify({ ...payload, requestId: id }) }; }
function body(event) { try { const value = JSON.parse(String(event.body || "{}")); if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(); return value; } catch { throw new Error("INVALID_BODY"); } }
function id(value) { return UUID.test(String(value || "")) ? String(value) : ""; }
function deploymentId(value) { return clean(value, 200).replace(/[^A-Za-z0-9_-]/g, ""); }
function revisionPayload(input, userId) {
    const projectId = id(input.projectId); if (!projectId) throw new Error("INVALID_PROJECT");
    const status = STATUSES.has(input.status) ? input.status : "draft";
    return { project_id: projectId, lead_id: id(input.leadId) || null, audit_id: id(input.auditId) || null, parent_revision_id: id(input.parentRevisionId) || null, status, base_version: clean(input.baseVersion, 200), brief: input.brief && typeof input.brief === "object" ? input.brief : {}, changes: Array.isArray(input.changes) ? input.changes.slice(0, 200) : [], validation: input.validation && typeof input.validation === "object" ? input.validation : {}, deployment_id: deploymentId(input.deploymentId) || null, before_scores: input.beforeScores && typeof input.beforeScores === "object" ? input.beforeScores : {}, after_scores: input.afterScores && typeof input.afterScores === "object" ? input.afterScores : {}, screenshots: input.screenshots && typeof input.screenshots === "object" ? input.screenshots : {}, approved_at: input.approvedAt || null, approved_by: userId };
}
exports.handler = async (event = {}) => {
    const blocked = await limitedResponseAsync(event, { namespace: "revisions", limit: 60, windowMs: 60000 }); if (blocked) return blocked;
    try {
        const user = await authenticate(event); const method = String(event.httpMethod || "").toUpperCase(); const query = event.queryStringParameters || {}; const revisionId = id(query.id); const projectId = id(query.projectId); const workContextId = id(query.workContextId);
        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return response(event, 405, { success: false, error: "Only GET, POST, PATCH, and DELETE are supported." });
        if (!projectId) return response(event, 400, { success: false, code: "INVALID_PROJECT", error: "A valid project ID is required." });
        if (!workContextId) return response(event, 400, { success: false, code: "INVALID_CONTEXT", error: "A valid work context ID is required." });
        if (!await getOwnedProject(projectId, user.id, workContextId)) return response(event, 404, { success: false, error: "Project not found in this work context." });
        const owner = `user_id=eq.${encodeURIComponent(user.id)}`;
        const authenticatedRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: requestId(event) });
        if (method === "GET") {
            const filter = revisionId ? `&id=eq.${revisionId}&project_id=eq.${projectId}` : `&project_id=eq.${projectId}`;
            const rows = await supabaseRequest(`/rest/v1/site_revisions?${owner}${filter}&select=*&order=created_at.desc`);
            return response(event, 200, { success: true, revisions: Array.isArray(rows) ? rows : [] });
        }
        if (method === "DELETE") {
            if (!revisionId) return response(event, 400, { success: false, error: "A revision ID is required." });
            const expectedUpdatedAt = clean(query.updatedAt, 80);
            if (!expectedUpdatedAt || Number.isNaN(Date.parse(expectedUpdatedAt))) return response(event, 400, { success: false, code: "REVISION_VERSION_REQUIRED", error: "The revision updatedAt value is required." });
            const existing = await supabaseRequest(`/rest/v1/site_revisions?id=eq.${revisionId}&${owner}&project_id=eq.${projectId}&select=id,status,updated_at&limit=1`);
            if (!Array.isArray(existing) || !existing[0]) return response(event, 404, { success: false, error: "Revision not found in this work context." });
            const removed = await supabaseRequest(`/rest/v1/site_revisions?id=eq.${revisionId}&${owner}&project_id=eq.${projectId}&updated_at=eq.${encodeURIComponent(expectedUpdatedAt)}&select=id`, { method: "DELETE", headers: { Prefer: "return=representation" } });
            if (!Array.isArray(removed) || !removed[0]) return response(event, 409, { success: false, code: "REVISION_CONFLICT", error: "The revision changed before it could be deleted." });
            await auditEvent(authenticatedRequest, { request_id: requestId(event), actor_id: user.id, project_id: projectId, action: "revision.delete", revision: revisionId, result: "succeeded", metadata: { before: existing[0], reason: clean(query.reason, 500) || null } });
            return response(event, 200, { success: true });
        }
        const input = body(event);
        const inputProjectId = id(input.projectId);
        const inputWorkContextId = id(input.workContextId);
        if (!inputProjectId || !inputWorkContextId || inputProjectId !== projectId || inputWorkContextId !== workContextId) return response(event, 400, { success: false, code: "INVALID_CONTEXT", error: "The body and query scope must match." });
        if (method === "POST") {
            const payload = revisionPayload({ ...input, projectId: inputProjectId }, user.id);
            const key = idempotencyKey(event, input);
            let operation;
            try {
                operation = await beginIdempotent({ request: authenticatedRequest, actorId: user.id, projectId: payload.project_id, operation: "revision.create", key, hash: requestHash(payload) });
                if (operation.replay) return response(event, 200, { ...operation.response, idempotentReplay: true });
                const rows = await supabaseRequest("/rest/v1/site_revisions?select=*", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ ...payload, user_id: user.id }) });
                const result = { success: true, revision: rows?.[0] || null };
                await completeIdempotent({ request: authenticatedRequest, actorId: user.id, projectId: payload.project_id, operation: "revision.create", key: operation.key, response: result });
                return response(event, 201, result);
            } catch (error) {
                if (operation?.enabled && !operation.replay) await abandonIdempotent({ request: authenticatedRequest, actorId: user.id, projectId: payload.project_id, operation: "revision.create", key: operation.key });
                throw error;
            }
        }
        if (!revisionId) return response(event, 400, { success: false, error: "A revision ID is required." });
        const expectedUpdatedAt = clean(input.updatedAt, 80);
        if (!expectedUpdatedAt || Number.isNaN(Date.parse(expectedUpdatedAt))) return response(event, 400, { success: false, code: "REVISION_VERSION_REQUIRED", error: "The revision updatedAt value is required." });
        const existing = await supabaseRequest(`/rest/v1/site_revisions?id=eq.${revisionId}&${owner}&project_id=eq.${inputProjectId}&select=id,status,updated_at&limit=1`);
        if (!Array.isArray(existing) || !existing[0]) return response(event, 404, { success: false, error: "Revision not found in this work context." });
        const patch = {}; ["status", "validation", "changes", "brief", "deployment_id", "before_scores", "after_scores", "screenshots"].forEach((key) => { if (Object.prototype.hasOwnProperty.call(input, key)) patch[key] = key === "status" ? (STATUSES.has(input[key]) ? input[key] : "draft") : input[key]; });
        if (input.approvedAt) patch.approved_at = input.approvedAt; if (input.approvedBy) patch.approved_by = id(input.approvedBy) || user.id;
        if (!Object.keys(patch).length) return response(event, 400, { success: false, code: "INVALID_REQUEST", error: "At least one revision change is required." });
        const rows = await supabaseRequest(`/rest/v1/site_revisions?id=eq.${revisionId}&${owner}&project_id=eq.${inputProjectId}&updated_at=eq.${encodeURIComponent(expectedUpdatedAt)}&select=*`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(patch) });
        if (!Array.isArray(rows) || !rows[0]) return response(event, 409, { success: false, code: "REVISION_CONFLICT", error: "The revision changed before it could be updated." });
        await auditEvent(authenticatedRequest, { request_id: requestId(event), actor_id: user.id, project_id: projectId, action: "revision.update", revision: revisionId, result: "succeeded", metadata: { before: existing[0], after: { status: rows[0].status, updated_at: rows[0].updated_at }, reason: clean(input.reason, 500) || null } });
        return response(event, 200, { success: true, revision: rows[0] });
    } catch (error) {
        if (["UNAUTHORIZED"].includes(error.message)) return response(event, 401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." });
        if (error.message === "IDEMPOTENCY_CONFLICT") return response(event, 409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for another revision." });
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return response(event, 409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This revision is already being created." });
        if (["INVALID_BODY", "INVALID_PROJECT", "INVALID_CONTEXT"].includes(error.message)) return response(event, 400, { success: false, code: "INVALID_REQUEST", error: "The revision payload is invalid." });
        console.error("Revision API error:", error?.message || error); return response(event, 500, { success: false, error: "The revision request failed." });
    }
};
