"use strict";

const scrapeFunction = require("../../netlify_functions_scrape.js");
const {
    limitedResponseAsync,
    maxBodyResponse,
    securityHeaders,
    requestId,
    isJsonContentType
} = require("./_security.js");
const { authenticate, userRequest } = require("./_platform.js");
const { reserveQuota, commitQuota, releaseQuota, quotaMetadata, quotaResponse } = require("./_quota.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { log } = require("./_ops.js");

function withSecurityHeaders(response = {}, correlationId = "") {
    const safeResponse =
        response && typeof response === "object" ? response : {};

    const configuredHeaders =
        safeResponse.headers && typeof safeResponse.headers === "object"
            ? safeResponse.headers
            : {};

    const enforcedHeaders = securityHeaders();
    const enforcedNames = new Set(
        Object.keys(enforcedHeaders).map((name) => name.toLowerCase())
    );

    const headers = {};

    for (const [name, value] of Object.entries(configuredHeaders)) {
        if (!enforcedNames.has(name.toLowerCase())) {
            headers[name] = value;
        }
    }

    const requestHeader = correlationId ? { "X-Request-ID": correlationId } : {};
    return {
        statusCode: Number.isInteger(safeResponse.statusCode)
            ? safeResponse.statusCode
            : 502,
        isBase64Encoded: Boolean(safeResponse.isBase64Encoded),
        headers: {
            ...headers,
            ...requestHeader,
            ...enforcedHeaders
        },
        body:
            typeof safeResponse.body === "string"
                ? safeResponse.body
                : ""
    };
}

exports.handler = async function handler(event = {}, context = {}) {
    const correlationId = requestId(event);
    const request = (path, options = {}) => userRequest(event, path, { ...options, requestId: correlationId });
    const method = String(event.httpMethod || "").toUpperCase();
    let user;
    let reservation;
    let idempotency;
    let operationSucceeded = false;
    if (!["GET", "POST"].includes(method)) {
        return withSecurityHeaders({ statusCode: 405, headers: { Allow: "GET, POST" }, body: JSON.stringify({ success: false, code: "METHOD_NOT_ALLOWED", error: "Only GET and POST are supported.", requestId: correlationId }) }, correlationId);
    }
    if (method === "POST" && !isJsonContentType(event)) {
        return withSecurityHeaders({ statusCode: 415, body: JSON.stringify({ success: false, code: "UNSUPPORTED_MEDIA_TYPE", error: "Content-Type must be application/json.", requestId: correlationId }) }, correlationId);
    }

    const oversized = maxBodyResponse(event, 2_000_000);
    if (oversized) return withSecurityHeaders(oversized, correlationId);

    let parsedBody = null;
    if (method === "POST") {
        try {
            parsedBody = JSON.parse(String(event.body || "{}"));
            if (!parsedBody || typeof parsedBody !== "object" || Array.isArray(parsedBody) || typeof parsedBody.url !== "string") throw new Error("INVALID_BODY");
        } catch {
            return withSecurityHeaders({ statusCode: 400, body: JSON.stringify({ success: false, code: "INVALID_REQUEST", error: "Provide a valid JSON body containing a website URL.", requestId: correlationId }) }, correlationId);
        }
    }

    const blocked = await limitedResponseAsync(event, { namespace: "scrape", limit: 10, windowMs: 60_000 });
    if (blocked) return withSecurityHeaders(blocked, correlationId);

    try {
        user = await authenticate(event);
        if (!String(process.env.SCRAPINGBEE_API_KEY || process.env.SCRAPINGBEE_KEY || "").trim()) {
            return withSecurityHeaders({ statusCode: 503, body: JSON.stringify({ success: false, code: "SCRAPING_NOT_CONFIGURED", retryable: false, error: "Website importing is not configured.", requestId: correlationId }) }, correlationId);
        }
        const key = idempotencyKey(event, parsedBody || event.queryStringParameters || {});
        idempotency = await beginIdempotent({ request, actorId: user.id, operation: "website.import", key, hash: requestHash(parsedBody || event.queryStringParameters || {}) });
        if (idempotency.replay) return withSecurityHeaders({ statusCode: 200, body: JSON.stringify({ ...idempotency.response, idempotentReplay: true, requestId: correlationId }) }, correlationId);
        reservation = await reserveQuota({ request, userId: user.id, resource: "imports" });
        log("quota.reserved", { requestId: correlationId, resource: "imports", actorId: user.id, operation: "website.import", outcome: "reserved" });
        const result = await scrapeFunction.handler(event, context);
        const secured = withSecurityHeaders(result, correlationId);
        try {
            const payload = JSON.parse(secured.body || "{}");
            if (payload && typeof payload === "object") {
                payload.requestId = correlationId;
                payload.quota = quotaMetadata(reservation, "imports");
                secured.body = JSON.stringify(payload);
                if (secured.statusCode >= 200 && secured.statusCode < 300) {
                    await completeIdempotent({ request, actorId: user.id, operation: "website.import", key: idempotency.key, response: payload });
                    await commitQuota({ request, reservation });
                    operationSucceeded = true;
                }
            }
        } catch {}
        if (!operationSucceeded) throw Object.assign(new Error("SCRAPE_OPERATION_FAILED"), { retryable: secured.statusCode >= 500 });
        return secured;
    } catch (error) {
        if (reservation && !operationSucceeded) {
            try { await releaseQuota({ request, reservation }); }
            catch { log("quota.release_failed", { requestId: correlationId, actorId: user?.id, resource: "imports", operation: "website.import", outcome: "failed" }); }
        }
        if (idempotency?.enabled && !idempotency.replay) await abandonIdempotent({ request, actorId: user?.id, operation: "website.import", key: idempotency.key });
        if (error?.message === "IDEMPOTENCY_CONFLICT") return withSecurityHeaders({ statusCode: 409, body: JSON.stringify({ success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for another import.", requestId: correlationId }) }, correlationId);
        if (error?.message === "IDEMPOTENCY_IN_PROGRESS") return withSecurityHeaders({ statusCode: 409, headers: { "Retry-After": "2" }, body: JSON.stringify({ success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This import is already being processed.", requestId: correlationId }) }, correlationId);
        const quota = quotaResponse(error, (status, payload, headers = {}) => withSecurityHeaders({ statusCode: status, headers, body: JSON.stringify({ ...payload, requestId: correlationId }) }, correlationId));
        if (quota) return quota;
        if (error?.message === "UNAUTHORIZED") return withSecurityHeaders({ statusCode: 401, headers: { "X-Request-ID": correlationId }, body: JSON.stringify({ success: false, code: "UNAUTHORIZED", requestId: correlationId, error: "Please sign in first." }) }, correlationId);
        console.error("Scrape function error:", {
            requestId: correlationId,
            provider: error?.provider || "scrape",
            status: Number.isInteger(error?.status) ? error.status : undefined,
            retryable: Boolean(error?.retryable)
        });

        return withSecurityHeaders({
            statusCode: error?.retryable ? 502 : 500,
            headers: {
                "Content-Type": "application/json; charset=utf-8",
                "X-Request-ID": correlationId
            },
            body: JSON.stringify({
                success: false,
                requestId: correlationId,
                retryable: Boolean(error?.retryable),
                error: "Scrape service is temporarily unavailable."
            })
        });
    }
};