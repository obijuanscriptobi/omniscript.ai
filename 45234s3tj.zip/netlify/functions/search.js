"use strict";

const searchFunction = require("../../netlify_functions_search.js");
const {
    limitedResponseAsync,
    securityHeaders,
    requestId
} = require("./_security.js");
const { authenticate, request } = require("./_platform.js");
const { consumeQuota, quotaResponse } = require("./_quota.js");
const { log } = require("./_ops.js");

function withSecurityHeaders(response = {}) {
    const safeResponse =
        response && typeof response === "object" ? response : {};

    const configuredHeaders =
        safeResponse.headers && typeof safeResponse.headers === "object"
            ? safeResponse.headers
            : {};

    const enforcedHeaders = securityHeaders();
    const enforcedNames = new Set(
        Object.keys(enforcedHeaders).map((name) => name.toLowerCase())
    );

    const headers = {};

    for (const [name, value] of Object.entries(configuredHeaders)) {
        if (!enforcedNames.has(name.toLowerCase())) {
            headers[name] = value;
        }
    }

    return {
        statusCode: Number.isInteger(safeResponse.statusCode)
            ? safeResponse.statusCode
            : 200,
        isBase64Encoded: Boolean(safeResponse.isBase64Encoded),
        headers: {
            ...headers,
            ...enforcedHeaders
        },
        body:
            typeof safeResponse.body === "string"
                ? safeResponse.body
                : ""
    };
}

exports.handler = async function handler(event = {}, context = {}) {
    const blocked = await limitedResponseAsync(event, {
        namespace: "search",
        limit: 20,
        windowMs: 60_000
    });

    if (blocked) {
        return withSecurityHeaders(blocked);
    }

    try {
        const user = await authenticate(event);
        await consumeQuota({ request, userId: user.id, resource: "imports" });
        log("quota.consumed", { event, resource: "imports", actorId: user.id });
        const result = await searchFunction.handler(event, context);
        return withSecurityHeaders(result);
    } catch (error) {
        const quota = quotaResponse(error, withSecurityHeaders);
        if (quota) return quota;
        if (error?.message === "UNAUTHORIZED") return withSecurityHeaders({ statusCode: 401, headers: { "X-Request-ID": requestId(event) }, body: JSON.stringify({ success: false, requestId: requestId(event), error: "Please sign in first." }) });
        const correlationId = requestId(event);
        console.error("Search function error:", {
            requestId: correlationId,
            provider: error?.provider || "search",
            status: Number.isInteger(error?.status) ? error.status : undefined,
            retryable: Boolean(error?.retryable)
        });

        return withSecurityHeaders({
            statusCode: error?.retryable ? 502 : 500,
            headers: {
                "Content-Type": "application/json",
                "X-Request-ID": correlationId
            },
            body: JSON.stringify({
                success: false,
                requestId: correlationId,
                retryable: Boolean(error?.retryable),
                error: "Search service is temporarily unavailable."
            })
        });
    }
};