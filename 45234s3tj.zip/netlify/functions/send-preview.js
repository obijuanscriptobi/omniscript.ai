"use strict";

const { response, body, clean, guard, authenticate, userRequest } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");
const { reserveQuota, commitQuota, releaseQuota, quotaMetadata, quotaResponse } = require("./_quota.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { timed, log } = require("./_ops.js");

function validEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(value) && value.length <= 320;
}

exports.handler = async (event = {}) => {
    const correlationId = requestId(event);
    const method = String(event.httpMethod || "").toUpperCase();
    if (method !== "POST") return response(405, { success: false, code: "METHOD_NOT_ALLOWED", error: "Only POST is supported." }, { Allow: "POST" }, event);
    const contentType = Object.entries(event.headers || {}).find(([name]) => name.toLowerCase() === "content-type")?.[1] || "";
    if (!/^application\/json(?:\s*;|$)/i.test(String(contentType))) return response(415, { success: false, code: "UNSUPPORTED_MEDIA_TYPE", error: "Content-Type must be application/json." }, {}, event);

    let user;
    let reservation;
    let idempotency;
    let operationSucceeded = false;
    const request = (path, options = {}) => userRequest(event, path, { ...options, requestId: correlationId });
    try {
        const value = body(event, 20_000);
        const recipient = clean(value.recipient, 320).toLowerCase();
        const token = clean(value.token, 100);
        if (!validEmail(recipient) || !/^[A-Za-z0-9_-]{40,80}$/.test(token)) return response(400, { success: false, code: "INVALID_REQUEST", error: "A valid recipient and preview are required." }, {}, event);

        const appUrl = String(process.env.APP_PUBLIC_URL || process.env.PUBLIC_SITE_ORIGIN || "").trim().replace(/\/$/, "");
        const from = String(process.env.INVITATION_FROM_EMAIL || "").trim();
        if (!appUrl || !/^https:\/\//i.test(appUrl) || !from || !validEmail(from) || !process.env.RESEND_API_KEY) {
            return response(503, { success: false, code: "PREVIEW_EMAIL_NOT_CONFIGURED", error: "Preview email is not configured." }, {}, event);
        }

        user = await authenticate(event);
        const blocked = await guard(event, `send-preview:${user.id}`, 10);
        if (blocked) return blocked;
        const key = idempotencyKey(event, value);
        idempotency = await beginIdempotent({ request, actorId: user.id, operation: "preview.email", key, hash: requestHash({ recipient, token }) });
        if (idempotency.replay) return response(200, { ...idempotency.response, idempotentReplay: true }, {}, event);
        reservation = await reserveQuota({ request, userId: user.id, resource: "preview_emails" });
        log("quota.reserved", { requestId: correlationId, resource: "preview_emails", actorId: user.id, operation: "preview.email", outcome: "reserved" });

        const previewUrl = `${appUrl}/preview.html?token=${encodeURIComponent(token)}`;
        const resend = providerClient("resend", { endpoint: "https://api.resend.com", retries: 0, timeoutMs: 15_000, requestId: correlationId });
        const result = await timed("resend", () => resend.request("/emails", {
            method: "POST",
            headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
            raw: true,
            body: JSON.stringify({
                from,
                to: [recipient],
                subject: "Your website preview is ready",
                html: `<div style="background:#f4f1eb;padding:40px 20px;font-family:Arial,sans-serif;color:#17202a"><div style="max-width:560px;margin:auto;background:#fff;padding:36px;border:1px solid #ded8cc"><p style="color:#a47d2c;font-size:12px;letter-spacing:2px;text-transform:uppercase">Website preview</p><h1 style="font-family:Georgia,serif;font-weight:400;font-size:40px;line-height:1.05;margin:0 0 16px">A first look, ready for your thoughts.</h1><p style="font-size:16px;line-height:1.6;color:#66717c">Here is a private preview of the website draft. Review the story, layout, and customer journey, then share your notes.</p><p style="margin:28px 0"><a href="${previewUrl}" style="display:inline-block;background:#c9a86a;color:#17130c;text-decoration:none;padding:14px 22px;font-weight:700">Open website preview</a></p><p style="font-size:12px;line-height:1.5;color:#8a8f92">This private preview link expires automatically. It is not a published website.</p></div></div>`
            })
        }), { requestId: correlationId, actorId: user.id, operation: "preview.email" });
        const upstream = result.response || result;
        if (!upstream.ok) throw Object.assign(new Error("EMAIL_PROVIDER_REJECTED"), { status: upstream.status, retryable: upstream.status >= 500 });

        const payload = { success: true, message: `Preview sent to ${recipient}.`, quota: quotaMetadata(reservation, "preview_emails") };
        await completeIdempotent({ request, actorId: user.id, operation: "preview.email", key: idempotency.key, response: payload });
        await commitQuota({ request, reservation });
        operationSucceeded = true;
        return response(200, payload, {}, event);
    } catch (error) {
        if (reservation && !operationSucceeded) {
            try { await releaseQuota({ request, reservation }); } catch { log("quota.release_failed", { requestId: correlationId, actorId: user?.id, resource: "preview_emails", operation: "preview.email", outcome: "failed" }); }
        }
        if (idempotency?.enabled && !idempotency.replay) await abandonIdempotent({ request, actorId: user?.id, operation: "preview.email", key: idempotency.key });
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." }, {}, event);
        if (error.message === "INVALID_BODY" || error.message === "TOO_LARGE") return response(error.message === "TOO_LARGE" ? 413 : 400, { success: false, code: "INVALID_REQUEST", error: "The preview email request is invalid." }, {}, event);
        if (error.message === "IDEMPOTENCY_CONFLICT") return response(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for another email." }, {}, event);
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return response(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This email is already being sent." }, { "Retry-After": "2" }, event);
        const quota = quotaResponse(error, (status, payload, headers) => response(status, payload, headers, event));
        if (quota) return quota;
        log("preview.email.failed", { requestId: correlationId, actorId: user?.id, operation: "preview.email", provider: "resend", statusCode: error?.status || 500, outcome: "failed", retryable: Boolean(error?.retryable) });
        return response(error?.status === 504 ? 504 : 502, { success: false, code: error?.status === 504 ? "PREVIEW_EMAIL_TIMEOUT" : "PREVIEW_EMAIL_FAILED", retryable: Boolean(error?.retryable), error: "The preview email could not be sent." }, {}, event);
    }
};
