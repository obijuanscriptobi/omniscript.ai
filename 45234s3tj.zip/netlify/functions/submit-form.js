"use strict";

const submitFunction = require("../../netlify_functions_submit_form.js");
const {
    limitedResponseAsync,
    maxBodyResponse,
    requestId,
    securityHeaders
} = require("./_security.js");
const { quotaResponse, consumePublicProjectQuota } = require("./_quota.js");
const { request } = require("./_platform.js");

function errorResponse(event = {}) {
    const correlationId = requestId(event);

    return {
        statusCode: 502,
        isBase64Encoded: false,
        headers: securityHeaders({
            "Content-Type": "application/json; charset=utf-8",
            "X-Request-ID": correlationId
        }),
        body: JSON.stringify({
            success: false,
            requestId: correlationId,
            error: "The submission service could not be completed."
        })
    };
}

exports.handler = async function handler(event = {}, context = {}) {
    const correlationId = requestId(event);
    const method = String(event.httpMethod || "").toUpperCase();
    if (!["POST", "OPTIONS"].includes(method)) {
        return { statusCode: 405, isBase64Encoded: false, headers: securityHeaders({ Allow: "POST, OPTIONS", "X-Request-ID": correlationId }), body: JSON.stringify({ success: false, code: "METHOD_NOT_ALLOWED", error: "Only POST and OPTIONS are supported.", requestId: correlationId }) };
    }
    const blocked = await limitedResponseAsync(event, {
        namespace: "submit",
        limit: 5,
        windowMs: 300_000
    });

    if (blocked) return blocked;

    const oversized = maxBodyResponse(event, 20_000);

    if (oversized) return oversized;

    try {
        const projectId = event.queryStringParameters?.projectId || "";
        if (projectId) await consumePublicProjectQuota({ request, projectId, resource: "form_submissions" });
        const result = await submitFunction.handler(event, context);

        if (!result || typeof result !== "object") {
            return errorResponse(event);
        }

        const resultHeaders =
            result.headers && typeof result.headers === "object"
                ? result.headers
                : {};

        let responseBody = typeof result.body === "string"
            ? result.body
            : JSON.stringify({ success: false, error: "The submission service returned an invalid response." });
        try {
            const parsed = JSON.parse(responseBody);
            if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
                parsed.requestId = parsed.requestId || correlationId;
                responseBody = JSON.stringify(parsed);
            }
        } catch (_) {}

        return {
            statusCode: Number.isInteger(result.statusCode) ? result.statusCode : 502,
            isBase64Encoded: Boolean(result.isBase64Encoded),
            headers: securityHeaders({ ...resultHeaders, "X-Request-ID": correlationId }),
            body: responseBody
        };
    } catch (error) {
        const quota = quotaResponse(error, (status, payload, headers = {}) => ({
            statusCode: status,
            isBase64Encoded: false,
            headers: securityHeaders({ ...headers, "X-Request-ID": correlationId }),
            body: JSON.stringify({ ...payload, requestId: correlationId })
        }));
        if (quota) return quota;
        console.error("Submit function failed:", error?.message || error);
        return errorResponse(event);
    }
};