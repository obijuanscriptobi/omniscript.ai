"use strict";

const dns = require("node:dns").promises;
const net = require("node:net");
const { limitedResponseAsync, securityHeaders, requestId } = require("./_security.js");
const { providerClient } = require("./provider-adapters.js");

function response(statusCode, payload, event = {}) {
    const id = requestId(event);
    const safePayload = payload && typeof payload === "object" && !Array.isArray(payload) ? { ...payload, requestId: payload.requestId || id } : payload;
    return { statusCode, isBase64Encoded: false, headers: securityHeaders({ "Cache-Control": "no-store, max-age=0", "X-Request-ID": id }), body: JSON.stringify(safePayload) };
}
function privateAddress(address) {
    const value = String(address || "").toLowerCase();
    const mapped = value.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/);
    if (mapped) return privateAddress(mapped[1]);
    if (net.isIP(value) === 4) { const p = value.split(".").map(Number); return p[0] === 10 || p[0] === 127 || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) || (p[0] === 192 && p[1] === 168) || p[0] === 0 || p[0] >= 224; }
    return value === "::1" || value.startsWith("fc") || value.startsWith("fd") || value.startsWith("fe80:");
}
async function validateEndpoint(value) {
    let url; try { url = new URL(String(value || "")); } catch { throw new Error("Enter a valid form endpoint URL."); }
    if (url.protocol !== "https:" || url.username || url.password || url.hash || url.search) throw new Error("The test endpoint must use HTTPS without credentials, queries, or fragments.");
    const addresses = await dns.lookup(url.hostname, { all: true });
    if (!addresses.length || addresses.some((item) => privateAddress(item.address))) throw new Error("The test endpoint must resolve to a public host.");
    const currentAddresses = (await dns.lookup(url.hostname, { all: true })).map((item) => item.address).sort().join(",");
    const initialAddresses = addresses.map((item) => item.address).sort().join(",");
    if (currentAddresses !== initialAddresses) throw new Error("The test endpoint DNS answer changed during validation.");
    return url.href;
}
exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "test-form-endpoint", limit: 5, windowMs: 300_000 });
    if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST requests are supported." }, event);
    let body; try { body = JSON.parse(String(event.body || "{}")); } catch { return response(400, { success: false, error: "The test request is invalid." }, event); }
    try {
        const endpoint = await validateEndpoint(body.endpoint);
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        const payload = new URLSearchParams({ name: "Website builder delivery test", email: "form-test@example.invalid", message: "This is a delivery configuration test. Do not treat it as a customer enquiry.", website: "" });
        let result;
        try {
            const client = providerClient("form-endpoint", { retries: 0, timeoutMs: 8_000, requestId: requestId(event) });
            result = (await client.request(endpoint, { method: "POST", redirect: "manual", signal: controller.signal, headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "X-Form-Test": "true" }, body: payload, raw: true })).response;
        } finally { clearTimeout(timer); }
        return response(result.ok ? 200 : 422, { success: result.ok, status: result.status, technicalStatus: result.ok ? "accepted" : "rejected", message: result.ok ? "The endpoint accepted the test payload. This confirms HTTP acceptance, not email or CRM receipt." : `The endpoint returned HTTP ${result.status}.` }, event);
    } catch (error) { return response(422, { success: false, technicalStatus: "unverified", error: error.name === "AbortError" ? "The endpoint timed out." : "The endpoint test failed." }, event); }
};
