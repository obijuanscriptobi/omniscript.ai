"use strict";
const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const projects = require("./projects.js");
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MAX_BODY = 200000;
const CATEGORIES = ["Setup", "Website", "Leads", "Appointments", "Ads", "Follow-up"];
const PRIORITIES = ["now", "soon", "later"];
const RECURRENCES = ["", "weekly", "monthly"];
function timestamp(value, { nullable = false } = {}) {
    if ((value === "" || value == null) && nullable) return null;
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) throw new Error("INVALID_TASK");
    return date.toISOString();
}
function dateOnly(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
    if (!match) return null;
    const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
    return date.getUTCFullYear() === Number(match[1]) && date.getUTCMonth() === Number(match[2]) - 1 && date.getUTCDate() === Number(match[3]) ? value : null;
}
const SELECT = "id,project_id,user_id,text,category,priority,due_date,notes,completed,completed_at,source,href,effort,created_at,updated_at,recurring,recurrence";
function response(status, data) { return { statusCode: status, headers: securityHeaders(), body: JSON.stringify(data) }; }
function header(event, name) { const key = Object.keys(event.headers || {}).find((item) => item.toLowerCase() === name.toLowerCase()); return key ? String(event.headers[key]) : ""; }
function clean(value, max = 500) { return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, max); }
function safeHref(value) {
    const href = clean(value, 500);
    if (!href) return "";
    if (/^(?:\/|\.\/|\.\.\/)(?!\/)/.test(href)) return href;
    try {
        const url = new URL(href);
        return ["http:", "https:"].includes(url.protocol) ? url.toString() : "";
    } catch { return ""; }
}
function body(event) { const raw = String(event.body || ""); if (Buffer.byteLength(raw, "utf8") > MAX_BODY) throw new Error("TOO_LARGE"); try { const parsed = JSON.parse(raw || "{}"); if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error(); return parsed; } catch { throw new Error("INVALID_BODY"); } }
function project(event, data) { const value = event.queryStringParameters?.projectId || data.projectId || ""; if (!UUID.test(String(value))) throw new Error("INVALID_PROJECT"); return String(value); }
function workContext(event, data) { const value = event.queryStringParameters?.workContextId || data.workContextId || ""; if (!UUID.test(String(value))) throw new Error("INVALID_CONTEXT"); return String(value); }
function taskPayload(item, userId, projectId) {
    if (!item || typeof item !== "object" || !UUID.test(String(item.id || ""))) throw new Error("INVALID_TASK");
    const text = clean(item.text, 240);
    if (!text) throw new Error("INVALID_TASK");
    const completed = item.completed === true;
    return { id: item.id, user_id: userId, project_id: projectId, text, category: CATEGORIES.includes(item.category) ? item.category : "Setup", priority: PRIORITIES.includes(item.priority) ? item.priority : "soon", due_date: dateOnly(item.dueDate), notes: clean(item.notes, 500), completed, completed_at: completed ? timestamp(item.completedAt, { nullable: true }) : null, source: clean(item.source, 80) || "user", href: safeHref(item.href), effort: clean(item.effort, 80) || "About 5 minutes", recurring: item.recurring === true, recurrence: RECURRENCES.includes(item.recurrence) ? item.recurrence : "", created_at: timestamp(item.createdAt) };
}
exports.handler = async (event = {}) => {
    const blocked = await limitedResponseAsync(event, { namespace: "todos", limit: 60, windowMs: 60000 }); if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase(); if (!["GET", "PUT"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const user = await projects.authenticate(event); const data = method === "GET" ? {} : body(event); const projectId = project(event, data); const workContextId = workContext(event, data);
        if (!await projects.getOwnedProject(projectId, user.id, workContextId)) return response(404, { success: false, error: "Project not found in this work context." });
        const ownership = `project_id=eq.${encodeURIComponent(projectId)}&user_id=eq.${encodeURIComponent(user.id)}`;
        if (method === "GET") { const rows = await projects.supabaseRequest(`/rest/v1/next_steps?${ownership}&select=${SELECT}&order=created_at.asc`); return response(200, { success: true, tasks: (Array.isArray(rows) ? rows : []).map(toClient) }); }
        if (!Array.isArray(data.tasks) || data.tasks.length > 500) throw new Error("INVALID_TASKS");
        const payload = data.tasks.map((item) => taskPayload(item, user.id, projectId));
        let result = [];
        if (payload.length) {
            // The service-role client bypasses RLS, so reject IDs already owned by
            // another project/user before an upsert can reassign those records.
            const ids = payload.map((item) => item.id).join(",");
            const existing = await projects.supabaseRequest(`/rest/v1/next_steps?id=in.(${ids})&select=id,project_id,user_id`);
            const crossed = (Array.isArray(existing) ? existing : []).some((item) => item.project_id !== projectId || item.user_id !== user.id);
            if (crossed) return response(409, { success: false, error: "One or more tasks belong to another work context." });
            result = await projects.supabaseRequest(`/rest/v1/next_steps?on_conflict=id&select=${SELECT}`, { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify(payload) });
            await projects.supabaseRequest(`/rest/v1/next_steps?${ownership}&id=not.in.(${ids})`, { method: "DELETE", headers: { Prefer: "return=minimal" } });
        } else {
            await projects.supabaseRequest(`/rest/v1/next_steps?${ownership}`, { method: "DELETE", headers: { Prefer: "return=minimal" } });
        }
        return response(200, { success: true, tasks: (Array.isArray(result) ? result : []).map(toClient) });
    } catch (error) {
        const code = error?.message || ""; if (code === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (["INVALID_BODY", "INVALID_PROJECT", "INVALID_CONTEXT", "INVALID_TASK", "INVALID_TASKS"].includes(code)) return response(400, { success: false, error: "The task data is invalid." });
        if (code === "TOO_LARGE") return response(413, { success: false, error: "The task payload is too large." });
        if (code === "NOT_CONFIGURED") return response(503, { success: false, error: "Cloud storage is not configured." });
        console.error("Todo API error:", error?.message || error); return response(500, { success: false, error: "The task request failed." });
    }
};
function toClient(row) { return { id: row.id, text: row.text, category: row.category, priority: row.priority, dueDate: row.due_date || "", notes: row.notes || "", completed: row.completed === true, completedAt: row.completed_at || "", source: row.source || "user", href: row.href || "", effort: row.effort || "About 5 minutes", recurring: row.recurring === true, recurrence: row.recurrence || '', createdAt: row.created_at, updatedAt: row.updated_at }; }
