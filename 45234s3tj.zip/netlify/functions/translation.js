"use strict";
const { response, body, clean, guard, authenticate } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");

exports.handler = async (event = {}) => {
    const blocked = await guard(event, "translation", 20); if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST is supported." });
    try {
        await authenticate(event);
        const value = body(event); const source = clean(value.sourceLocale, 20); const target = clean(value.targetLocale, 20);
        const localePattern = /^[a-z]{2,3}(?:-[A-Z]{2})?$/;
        if (!source || !target || !localePattern.test(source) || !localePattern.test(target) || !value.content || typeof value.content !== "object" || Array.isArray(value.content)) return response(400, { success: false, error: "Valid source, target, and object content are required." });
        if (source === target) return response(200, { success: true, status: "in-review", content: value.content, provider: "identity" });
        if (!process.env.TRANSLATION_API_URL || !process.env.TRANSLATION_API_KEY) return response(503, { success: false, error: "Translation provider is not configured; save a draft for manual review." });
        const translation = providerClient("translation", { endpoint: String(process.env.TRANSLATION_API_URL).replace(/\/+$/, ""), retries: 1, timeoutMs: 20_000, requestId: requestId(event) });
        const result = await translation.request("", { method: "POST", headers: { Authorization: `Bearer ${process.env.TRANSLATION_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ sourceLocale: source, targetLocale: target, content: value.content }) });
        const data = result.data || {};
        if (!data.content || typeof data.content !== "object" || Array.isArray(data.content)) return response(502, { success: false, error: "Translation provider returned an invalid result." });
        return response(200, { success: true, status: "in-review", content: data.content, provider: "configured" });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error.message === "INVALID_BODY") return response(400, { success: false, error: "The translation request is invalid." });
        return response(500, { success: false, error: "Translation request failed." });
    }
};
