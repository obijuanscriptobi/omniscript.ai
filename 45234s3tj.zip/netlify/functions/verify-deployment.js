"use strict";

const dns = require("node:dns").promises;
const net = require("node:net");
const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const { authenticate } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");

const MAX_FILES = 80;
const TIMEOUT_MS = 8000;
const MAX_RESPONSE_BYTES = 1_000_000;
const FILE_RE = /^[a-z0-9][a-z0-9._/-]{0,180}$/i;

function response(statusCode, payload) {
    return { statusCode, isBase64Encoded: false, headers: securityHeaders({ "Cache-Control": "no-store, max-age=0" }), body: JSON.stringify(payload) };
}

function isPrivateAddress(address) {
    const value = String(address || "").toLowerCase();
    const mapped = value.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/);
    if (mapped) return isPrivateAddress(mapped[1]);
    if (net.isIP(value) === 4) {
        const parts = value.split(".").map(Number);
        return parts[0] === 10 || parts[0] === 127 || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) || (parts[0] === 192 && parts[1] === 168) || parts[0] === 0 || parts[0] >= 224;
    }
    return value === "::1" || value.startsWith("fc") || value.startsWith("fd") || value.startsWith("fe80:");
}

async function safeOrigin(value) {
    let url;
    try { url = new URL(String(value || "")); } catch { throw new Error("Enter a valid published URL."); }
    if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) throw new Error("The published URL must be HTTPS without credentials, query strings, or fragments.");
    const addresses = await dns.lookup(url.hostname, { all: true });
    if (!addresses.length || addresses.some((item) => isPrivateAddress(item.address))) throw new Error("The published hostname does not resolve to a public address.");
    const currentAddresses = (await dns.lookup(url.hostname, { all: true })).map((item) => item.address).sort().join(",");
    const initialAddresses = addresses.map((item) => item.address).sort().join(",");
    if (currentAddresses !== initialAddresses) throw new Error("The published hostname DNS answer changed during validation.");
    return `${url.origin}${url.pathname.replace(/\/$/, "")}`;
}

async function fetchChecked(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
        const client = providerClient("deployment-verification", {
            retries: 0,
            timeoutMs: TIMEOUT_MS,
            requestId: requestId()
        });
        const result = (await client.request(url, { raw: true, redirect: "manual", signal: controller.signal, headers: { Accept: "text/html, text/css, application/javascript, application/xml, text/plain, image/*" } })).response;
        const reader = result.body?.getReader?.();
        let bytes = 0;
        let text = "";
        if (reader) {
            const decoder = new TextDecoder();
            while (true) {
                const part = await reader.read();
                if (part.done) break;
                bytes += part.value.byteLength;
                if (bytes > MAX_RESPONSE_BYTES) { await reader.cancel(); break; }
                text += decoder.decode(part.value, { stream: true });
            }
        } else text = await result.text();
        return { status: result.status, type: result.headers.get("content-type") || "", text: text.slice(0, MAX_RESPONSE_BYTES), location: result.headers.get("location") || "" };
    } finally { clearTimeout(timer); }
}

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "verify-deployment", limit: 20, windowMs: 60_000 });
    if (blocked) return blocked;
    if (String(event.httpMethod || "").toUpperCase() !== "POST") return response(405, { success: false, error: "Only POST requests are supported." });
    let body;
    try {
        const raw = String(event.body || "");
        if (event.isBase64Encoded) {
            if (!raw || raw.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(raw)) throw new Error("INVALID_BODY");
            const decoded = Buffer.from(raw, "base64");
            if (decoded.toString("base64").replace(/=+$/, "") !== raw.replace(/=+$/, "")) throw new Error("INVALID_BODY");
            body = JSON.parse(decoded.toString("utf8") || "{}");
        } else {
            body = JSON.parse(raw || "{}");
        }
    } catch { return response(400, { success: false, error: "The verification request is invalid." }); }
    if (!body || typeof body !== "object" || Array.isArray(body)) return response(400, { success: false, error: "The verification request is invalid." });
    const files = Array.isArray(body?.files) ? body.files : ["index.html", "style.css", "script.js", "sitemap.xml", "robots.txt"];
    const expectedRevision = typeof body?.revision === "string" ? body.revision.trim().slice(0, 128) : "";
    if (files.length > MAX_FILES || files.some((file) => typeof file !== "string" || !FILE_RE.test(file) || file.startsWith("/"))) return response(400, { success: false, error: "The verification file list is invalid." });
    if (body?.revision !== undefined && !/^[A-Za-z0-9:_-]{1,128}$/.test(expectedRevision)) return response(400, { success: false, error: "The verification revision is invalid." });
    try {
        await authenticate(event);
        const origin = await safeOrigin(body.url);
        const unique = [...new Set(files)];
        const checks = await Promise.all(unique.map(async (file) => {
            const path = file === "index.html" ? "/" : `/${file}`;
            try {
                const result = await fetchChecked(`${origin}${path}`);
                const pass = result.status >= 200 && result.status < 300;
                const expectedType = /\.html?$/i.test(file) ? "text/html" : /\.css$/i.test(file) ? "text/css" : /\.js$/i.test(file) ? "javascript" : /\.xml$/i.test(file) ? "xml" : /\.txt$/i.test(file) ? "text/plain" : "";
                const contentTypePass = !expectedType || result.type.toLowerCase().includes(expectedType);
                const redirectPass = !result.location;
                const checksPass = pass && contentTypePass && redirectPass;
                return { file, pass: checksPass, status: result.status, contentType: result.type, location: result.location || undefined, message: !pass ? `Returned HTTP ${result.status}.` : !redirectPass ? `Redirected unexpectedly to ${result.location}.` : !contentTypePass ? `Returned an unexpected content type (${result.type || "missing"}).` : "Reachable with the expected response type." };
            } catch (error) { return { file, pass: false, status: 0, message: error.name === "AbortError" ? "Request timed out." : "Could not be reached." }; }
        }));
        const homepage = checks.find((item) => item.file === "index.html");
        const blocking = checks.filter((item) => !item.pass);
        if (homepage?.pass) {
            try {
                const html = await fetchChecked(`${origin}/`);
                if (!/<title\b[^>]*>\s*[^<]+/i.test(html.text)) blocking.push({ file: "index.html", pass: false, message: "Published homepage has no usable title." });
                if ((html.text.match(/<h1[\s>]/gi) || []).length !== 1) blocking.push({ file: "index.html", pass: false, message: "Published homepage must contain exactly one h1." });
            } catch {}
        }
        return response(blocking.length ? 422 : 200, { success: blocking.length === 0, verifiedAt: new Date().toISOString(), revision: expectedRevision, origin, checks, blocking, warnings: [] });
    } catch (error) {
        if (error?.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." });
        if (error?.message === "NOT_CONFIGURED") return response(503, { success: false, error: "Supabase is not configured." });
        return response(400, { success: false, error: error.message || "Verification failed." });
    }
};
