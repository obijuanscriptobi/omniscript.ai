"use strict";

const { response, body, clean, guard, authenticate, userRequest } = require("./_platform.js");
const { providerClient, requestId } = require("./provider-adapters.js");
const { reserveQuota, commitQuota, releaseQuota, quotaMetadata, quotaResponse } = require("./_quota.js");
const { idempotencyKey, requestHash, beginIdempotent, completeIdempotent, abandonIdempotent } = require("./_idempotency.js");
const { log } = require("./_ops.js");
const core = require("./website-architect-core.js");

const TOTAL_DEADLINE_MS = 45_000;
const MAX_PROMPT_CHARS = 140_000;
const MAX_OUTPUT_TOKENS = 8_000;

function providerConfiguration(env = process.env) {
    const endpoint = clean(env.WEBSITE_AI_URL, 500).replace(/\/+$/, "");
    const apiKey = clean(env.WEBSITE_AI_API_KEY, 10_000);
    const model = clean(env.WEBSITE_AI_MODEL, 120);
    if (!endpoint || !apiKey || !model) throw new Error("AI_NOT_CONFIGURED");
    let parsed;
    try { parsed = new URL(endpoint); } catch { throw new Error("AI_CONFIGURATION_INVALID"); }
    if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.hash) throw new Error("AI_CONFIGURATION_INVALID");
    const allowedHosts = clean(env.WEBSITE_AI_ALLOWED_HOSTS, 1000).split(",").map((host) => host.trim().toLowerCase()).filter(Boolean);
    if (!allowedHosts.length || !allowedHosts.includes(parsed.hostname.toLowerCase())) throw new Error("AI_CONFIGURATION_INVALID");
    return {
        endpoint: parsed.href.replace(/\/$/, ""),
        apiKey,
        model,
        plannerModel: clean(env.WEBSITE_AI_PLANNER_MODEL, 120) || model,
        generatorModel: clean(env.WEBSITE_AI_GENERATOR_MODEL, 120) || model,
        criticModel: clean(env.WEBSITE_AI_CRITIC_MODEL, 120) || model,
        repairModel: clean(env.WEBSITE_AI_REPAIR_MODEL, 120) || model
    };
}

function safeRecord(input, allowed, stringLimit = 2_000) {
    if (!input || typeof input !== "object" || Array.isArray(input)) return {};
    const output = Object.create(null);
    for (const key of allowed) {
        if (["__proto__", "prototype", "constructor"].includes(key)) continue;
        const value = input[key];
        if (typeof value === "string") output[key] = clean(value, stringLimit);
        else if (typeof value === "number" && Number.isFinite(value)) output[key] = value;
        else if (typeof value === "boolean") output[key] = value;
        else if (Array.isArray(value)) output[key] = value.slice(0, 30).map((item) => clean(item, 500));
    }
    return output;
}

function safeAsset(asset) {
    const output = safeRecord(asset, ["id", "type", "url", "alt", "caption", "source"], 2_000);
    if (output.url) {
        try {
            const parsed = new URL(output.url);
            if (!["https:", "data:"].includes(parsed.protocol)) delete output.url;
        } catch {
            delete output.url;
        }
    }
    return output;
}

function normalizeRequest(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_BODY");
    const files = Object.create(null);
    let fileBytes = 0;
    if (value.existingFiles && typeof value.existingFiles === "object" && !Array.isArray(value.existingFiles)) {
        for (const [name, content] of Object.entries(value.existingFiles).slice(0, 80)) {
            if (["__proto__", "prototype", "constructor"].includes(name)) continue;
            if (/^(?:[a-z0-9._-]+\/)*[a-z0-9._-]+$/i.test(name) && typeof content === "string") {
                const safeContent = clean(content, 200_000);
                fileBytes += Buffer.byteLength(safeContent, "utf8");
                if (fileBytes > 1_000_000) throw new Error("TOO_LARGE");
                files[name] = safeContent;
            }
        }
    }
    const normalized = {
        business: safeRecord(value.business, ["name", "industry", "description", "audience", "location", "phone", "email", "address", "services", "differentiators", "tone"]),
        design: safeRecord(value.design, ["style", "palette", "primaryColor", "secondaryColor", "accentColor", "fontPair", "density", "motion"]),
        pages: Array.isArray(value.pages) ? value.pages.slice(0, 12).filter((page) => typeof page === "string").map((page) => clean(page, 80)) : [],
        assets: Array.isArray(value.assets) ? value.assets.slice(0, 40).map(safeAsset) : [],
        importedSource: typeof value.importedSource === "string" ? clean(value.importedSource, 80_000) : "",
        searchResults: typeof value.searchResults === "string" ? clean(value.searchResults, 40_000) : "",
        mode: value.mode === "repair" ? "repair" : value.mode === "critique" ? "critique" : "generate",
        existingFiles: files,
        visualEvidence: safeRecord(value.visualEvidence, ["viewport", "summary", "issues", "metrics", "screenshotId"], 5_000),
        variationId: typeof value.variationId === "string" ? clean(value.variationId, 80) : "",
        diagnostics: Array.isArray(value.diagnostics) ? value.diagnostics.slice(0, 50).map((item) => safeRecord(item, ["code", "file", "message", "severity"], 1_000)) : []
    };
    if (Buffer.byteLength(JSON.stringify(normalized), "utf8") > MAX_PROMPT_CHARS) throw new Error("TOO_LARGE");
    return normalized;
}

async function complete(configuration, messages, event, deadline, model = configuration.model, temperature = 0.25) {
    const remaining = deadline - Date.now();
    if (remaining < 1_000) throw Object.assign(new Error("AI_DEADLINE_EXCEEDED"), { status: 504, retryable: true });
    const client = providerClient("website-ai", { endpoint: configuration.endpoint, retries: 1, timeoutMs: Math.min(remaining, 20_000), requestId: requestId(event) });
    const result = await client.request("", {
        method: "POST",
        headers: { Authorization: `Bearer ${configuration.apiKey}`, "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ model, messages, temperature, max_tokens: MAX_OUTPUT_TOKENS, response_format: { type: "json_object" } })
    });
    return core.extractModelText(result.data);
}

exports.handler = async function handler(event = {}) {
    const correlationId = requestId(event);
    const platformRequest = (path, options = {}) => userRequest(event, path, { ...options, requestId: correlationId });
    const deadline = Date.now() + TOTAL_DEADLINE_MS;
    const method = String(event.httpMethod || "").toUpperCase();
    if (method !== "POST") return response(405, { success: false, code: "METHOD_NOT_ALLOWED", error: "Only POST is supported." }, { Allow: "POST" }, event);
    const contentType = Object.entries(event.headers || {}).find(([name]) => name.toLowerCase() === "content-type")?.[1] || "";
    if (!/^application\/json(?:\s*;|$)/i.test(String(contentType))) return response(415, { success: false, code: "UNSUPPORTED_MEDIA_TYPE", error: "Content-Type must be application/json." }, {}, event);

    let user;
    let idempotency;
    let normalized;
    let reservation;
    let operationSucceeded = false;
    try {
        normalized = normalizeRequest(body(event, core.LIMITS.requestBytes));
        providerConfiguration();
        user = await authenticate(event);
        const blocked = await guard(event, `website-architect:${user.id}`, 6);
        if (blocked) return blocked;
        const key = idempotencyKey(event, normalized);
        idempotency = await beginIdempotent({ request: platformRequest, actorId: user.id, projectId: null, operation: "website.generate", key, hash: requestHash(normalized) });
        if (idempotency.replay) return response(200, { ...idempotency.response, idempotentReplay: true }, {}, event);
        reservation = await reserveQuota({ request: platformRequest, userId: user.id, resource: "ai_generations" });
        log("quota.reserved", { requestId: correlationId, actorId: user.id, resource: "ai_generations", operation: "website.generate", outcome: "reserved" });
        const request = normalized;
        const configuration = providerConfiguration();
        let files;
        let issues;
        let passes = 0;
        let plan = null;

        if (request.mode === "critique" && Object.keys(request.existingFiles).length) {
            files = request.existingFiles;
            const rawCritique = await complete(configuration, core.visualCritiqueMessages(request, files, request.visualEvidence), event, deadline, configuration.criticModel, 0.1);
            const critique = core.parsePlan(rawCritique, request);
            const payload = { success: true, files, critique, provider: "configured", model: configuration.criticModel, repairPasses: 0, diagnostics: core.diagnostics(files) };
            payload.quota = quotaMetadata(reservation, "ai_generations");
            await completeIdempotent({ request: platformRequest, actorId: user.id, operation: "website.generate", key: idempotency.key, response: payload });
            await commitQuota({ request: platformRequest, reservation });
            operationSucceeded = true;
            return response(200, payload, {}, event);
        }

        if (request.mode === "repair" && Object.keys(request.existingFiles).length) {
            throw new Error("AI_REPAIR_DISABLED");
        }

        log("provider.started", { requestId: correlationId, actorId: user.id, operation: "website.generate", provider: "website-ai", outcome: "started" });
        const rawPlan = await complete(configuration, core.planningMessages(request), event, deadline, configuration.plannerModel, 0.35);
        plan = core.parsePlan(rawPlan, request);
        const facts = core.factsFor(request);
        const assembled = core.assemblePlan(plan, facts, request.design);
        files = assembled.files;
        issues = core.diagnostics(files);

        if (issues.length) return response(422, { success: false, code: "OUTPUT_CONTRACT_FAILED", error: "The assembled draft did not pass the project-output contract.", diagnostics: issues.slice(0, 30), repairPasses: passes, repairAudit: assembled.repairAudit }, {}, event);
        const payload = { success: true, files, plan, provenance: assembled.provenance, repairAudit: assembled.repairAudit, provider: "configured", models: { planner: configuration.plannerModel, critic: configuration.criticModel }, assembler: "deterministic-v1", repairPasses: passes, diagnostics: [], schemaVersion: 1, quota: quotaMetadata(reservation, "ai_generations") };
        await completeIdempotent({ request: platformRequest, actorId: user.id, operation: "website.generate", key: idempotency.key, response: payload });
        await commitQuota({ request: platformRequest, reservation });
        operationSucceeded = true;
        log("website.generation.completed", { requestId: correlationId, actorId: user.id, operation: "website.generate", provider: "website-ai", statusCode: 200, outcome: "succeeded", durationMs: TOTAL_DEADLINE_MS - (deadline - Date.now()) });
        return response(200, payload, {}, event);
    } catch (error) {
        if (reservation && !operationSucceeded) {
            try {
                await releaseQuota({ request: platformRequest, reservation });
                log("quota.released", { requestId: correlationId, actorId: user?.id, resource: "ai_generations", operation: "website.generate", outcome: "released" });
            } catch {
                log("quota.release_failed", { requestId: correlationId, actorId: user?.id, resource: "ai_generations", operation: "website.generate", outcome: "failed" });
            }
        }
        if (idempotency?.enabled && !idempotency.replay) await abandonIdempotent({ request: platformRequest, actorId: user?.id, operation: "website.generate", key: idempotency.key });
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in before using AI website generation." }, {}, event);
        if (error.message === "IDEMPOTENCY_CONFLICT") return response(409, { success: false, code: "IDEMPOTENCY_CONFLICT", error: "This idempotency key was already used for a different request." }, {}, event);
        if (error.message === "IDEMPOTENCY_IN_PROGRESS") return response(409, { success: false, code: "IDEMPOTENCY_IN_PROGRESS", retryable: true, error: "This request is already being processed." }, { "Retry-After": "2" }, event);
        const quota = quotaResponse(error, (status, payload, headers) => response(status, payload, headers, event));
        if (quota) return quota;
        if (error.message === "AI_DEADLINE_EXCEEDED" || error.status === 504) return response(504, { success: false, code: "AI_PROVIDER_TIMEOUT", retryable: true, fallback: "deterministic", error: "AI website generation exceeded its request deadline." }, {}, event);
        if (error.message === "INVALID_BODY" || error.message === "TOO_LARGE") return response(400, { success: false, code: "INVALID_REQUEST", error: "The website generation request is invalid or too large." }, {}, event);
        if (error.message === "AI_REPAIR_DISABLED") return response(400, { success: false, code: "AI_REPAIR_DISABLED", error: "Model-authored source repair is disabled. Run deterministic repairs or request a revised structured plan." }, {}, event);
        if (error.message === "AI_NOT_CONFIGURED") return response(503, { success: false, code: "AI_NOT_CONFIGURED", retryable: false, error: "AI website generation is not configured. The deterministic generator remains available.", fallback: "deterministic" }, {}, event);
        if (error.message === "AI_CONFIGURATION_INVALID") return response(500, { success: false, code: "AI_CONFIGURATION_INVALID", retryable: false, error: "AI website generation is not securely configured.", fallback: "deterministic" }, {}, event);
        if (/^MODEL_/.test(error.message)) return response(502, { success: false, error: "The AI provider returned an invalid website manifest.", code: error.message, fallback: "deterministic" }, {}, event);
        console.error("Website architect failed:", error?.message || error);
        return response(502, { success: false, code: "AI_PROVIDER_FAILED", error: "AI website generation is temporarily unavailable.", retryable: Boolean(error?.retryable), fallback: "deterministic" }, {}, event);
    }
};

exports.providerConfiguration = providerConfiguration;
exports.normalizeRequest = normalizeRequest;
