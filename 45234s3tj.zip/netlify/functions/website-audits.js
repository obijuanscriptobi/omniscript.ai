"use strict";

const { limitedResponseAsync, securityHeaders } = require("./_security.js");
const { authenticate, getOwnedProject, supabaseRequest } = require("./projects.js");

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const AUDIT_STATES = new Set(["not-audited", "audit-in-progress", "audit-complete", "needs-review", "fix-ready"]);
const IMPACTS = new Set(["high", "medium", "low"]);
const REMEDIATION = new Set(["safe-auto", "review-required", "blocked"]);
const FINDING_STATUSES = new Set(["open", "accepted", "fixed", "wont-fix"]);

function response(statusCode, payload) {
    return {
        statusCode,
        headers: securityHeaders({ "Cache-Control": "no-store" }),
        body: JSON.stringify(payload)
    };
}

function id(value) { return UUID.test(String(value || "")) ? String(value) : ""; }
function clean(value, max = 2000) { return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, max); }
function object(value) { return value && typeof value === "object" && !Array.isArray(value) ? value : {}; }
function parseBody(event) {
    try {
        const value = JSON.parse(String(event.body || "{}"));
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();
        return value;
    } catch { throw new Error("INVALID_BODY"); }
}

function auditPayload(input, projectId, userId) {
    const websiteUrl = clean(input.websiteUrl, 2000);
    if (!websiteUrl) throw new Error("INVALID_AUDIT");
    return {
        project_id: projectId,
        lead_id: id(input.leadId) || null,
        user_id: userId,
        website_url: websiteUrl,
        final_url: clean(input.finalUrl || websiteUrl, 2000),
        state: AUDIT_STATES.has(input.state) ? input.state : "not-audited",
        checked_at: input.checkedAt || null,
        source_evidence: object(input.sourceEvidence),
        technical: object(input.technical),
        content: object(input.content),
        visual: object(input.visual),
        findings: Array.isArray(input.findings) ? input.findings.slice(0, 500) : [],
        remediation: object(input.remediation),
        error: clean(input.error, 1000)
    };
}

function auditPatch(input) {
    const patch = {};
    const fields = {
        websiteUrl: "website_url", finalUrl: "final_url", checkedAt: "checked_at",
        sourceEvidence: "source_evidence", technical: "technical", content: "content",
        visual: "visual", findings: "findings", remediation: "remediation", error: "error"
    };
    for (const [source, target] of Object.entries(fields)) {
        if (!Object.prototype.hasOwnProperty.call(input, source)) continue;
        if (["sourceEvidence", "technical", "content", "visual", "remediation"].includes(source)) patch[target] = object(input[source]);
        else if (source === "findings") patch[target] = Array.isArray(input[source]) ? input[source].slice(0, 500) : [];
        else patch[target] = clean(input[source], source === "error" ? 1000 : 2000);
    }
    if (Object.prototype.hasOwnProperty.call(input, "state")) patch.state = AUDIT_STATES.has(input.state) ? input.state : "not-audited";
    if (Object.prototype.hasOwnProperty.call(input, "leadId")) patch.lead_id = id(input.leadId) || null;
    return patch;
}

function findingPayload(input, auditId, projectId, userId) {
    return {
        audit_id: auditId,
        project_id: projectId,
        user_id: userId,
        issue: clean(input.issue, 2000),
        evidence: object(input.evidence),
        impact: IMPACTS.has(input.impact) ? input.impact : "medium",
        recommendation: clean(input.recommendation, 4000),
        confidence: Math.max(0, Math.min(1, Number(input.confidence) || 0)),
        remediation: REMEDIATION.has(input.remediation) ? input.remediation : "review-required",
        status: FINDING_STATUSES.has(input.status) ? input.status : "open"
    };
}

async function ownedAudit(auditId, projectId, userId) {
    if (!auditId) return null;
    const rows = await supabaseRequest(`/rest/v1/website_audits?id=eq.${auditId}&project_id=eq.${projectId}&user_id=eq.${userId}&select=id,project_id&limit=1`);
    return Array.isArray(rows) ? rows[0] || null : null;
}

exports.handler = async function handler(event = {}) {
    const blocked = await limitedResponseAsync(event, { namespace: "website-audits", limit: 60, windowMs: 60_000 });
    if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return response(405, { success: false, error: "Unsupported request method." });
        const user = await authenticate(event);
        const query = event.queryStringParameters || {};
        const input = method === "GET" ? {} : parseBody(event);
        const projectId = id(query.projectId || input.projectId);
        const workContextId = id(query.workContextId || input.workContextId);
        if (!projectId) return response(400, { success: false, code: "INVALID_PROJECT", error: "A valid project ID is required." });
        if (!workContextId) return response(400, { success: false, code: "INVALID_CONTEXT", error: "A valid work context ID is required." });
        if (!await getOwnedProject(projectId, user.id, workContextId)) return response(404, { success: false, error: "Project not found in this work context." });

        const resource = query.resource === "finding" || input.resource === "finding" ? "finding" : "audit";
        const auditId = id(query.auditId || input.auditId || (resource === "audit" ? query.id || input.id : ""));
        const recordId = id(query.id || input.id);
        const projectScope = `project_id=eq.${projectId}&user_id=eq.${user.id}`;

        if (resource === "finding") {
            if (!auditId || !await ownedAudit(auditId, projectId, user.id)) return response(404, { success: false, error: "Audit not found in this work context." });
            const findingScope = `project_id=eq.${projectId}&audit_id=eq.${auditId}&user_id=eq.${user.id}`;
            if (method === "GET") {
                const idFilter = recordId ? `&id=eq.${recordId}` : "";
                const rows = await supabaseRequest(`/rest/v1/audit_findings?${findingScope}${idFilter}&select=*&order=created_at.asc`);
                return response(200, { success: true, findings: Array.isArray(rows) ? rows : [] });
            }
            if (method === "POST") {
                const rows = await supabaseRequest("/rest/v1/audit_findings?select=*", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(findingPayload(input, auditId, projectId, user.id)) });
                return response(201, { success: true, finding: rows?.[0] || null });
            }
            if (!recordId) return response(400, { success: false, error: "A finding ID is required." });
            const existing = await supabaseRequest(`/rest/v1/audit_findings?id=eq.${recordId}&${findingScope}&select=id&limit=1`);
            if (!Array.isArray(existing) || !existing[0]) return response(404, { success: false, error: "Finding not found in this work context." });
            if (method === "DELETE") {
                await supabaseRequest(`/rest/v1/audit_findings?id=eq.${recordId}&${findingScope}`, { method: "DELETE" });
                return response(200, { success: true });
            }
            const payload = findingPayload(input, auditId, projectId, user.id);
            delete payload.audit_id; delete payload.project_id; delete payload.user_id;
            const rows = await supabaseRequest(`/rest/v1/audit_findings?id=eq.${recordId}&${findingScope}&select=*`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) });
            if (!Array.isArray(rows) || !rows[0]) return response(404, { success: false, error: "Finding not found in this work context." });
            return response(200, { success: true, finding: rows[0] });
        }

        if (method === "GET") {
            const idFilter = auditId ? `&id=eq.${auditId}` : "";
            const rows = await supabaseRequest(`/rest/v1/website_audits?${projectScope}${idFilter}&select=*&order=updated_at.desc`);
            return response(200, { success: true, audits: Array.isArray(rows) ? rows : [] });
        }
        if (method === "POST") {
            const rows = await supabaseRequest("/rest/v1/website_audits?select=*", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(auditPayload(input, projectId, user.id)) });
            return response(201, { success: true, audit: rows?.[0] || null });
        }
        if (!auditId || !await ownedAudit(auditId, projectId, user.id)) return response(404, { success: false, error: "Audit not found in this work context." });
        if (method === "DELETE") {
            await supabaseRequest(`/rest/v1/website_audits?id=eq.${auditId}&${projectScope}`, { method: "DELETE" });
            return response(200, { success: true });
        }
        const patch = auditPatch(input);
        const rows = await supabaseRequest(`/rest/v1/website_audits?id=eq.${auditId}&${projectScope}&select=*`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(patch) });
        if (!Array.isArray(rows) || !rows[0]) return response(404, { success: false, error: "Audit not found in this work context." });
        return response(200, { success: true, audit: rows[0] });
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, code: "UNAUTHORIZED", error: "Please sign in first." });
        if (["INVALID_BODY", "INVALID_AUDIT"].includes(error.message)) return response(400, { success: false, code: "INVALID_REQUEST", error: "The audit request is invalid." });
        console.error("Website audit API error:", error?.message || error);
        return response(500, { success: false, error: "The audit request failed." });
    }
};
