"use strict";

const { response, request, userRequest, authenticate, body, uuid, clean, guard } = require("./_platform.js");

function roleCanManage(role) {
    return ["owner", "admin", "member"].includes(role);
}

async function organizationFor(userId) {
    let memberships = await request(`/rest/v1/organization_members?user_id=eq.${encodeURIComponent(userId)}&select=organization_id,role,created_at&order=created_at.asc&limit=1`);
    let membership = Array.isArray(memberships) ? memberships[0] : null;
    if (membership) return membership;

    const organizations = await request("/rest/v1/organizations?select=id", {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify({ name: "My workspace", created_by: userId })
    });
    const organization = Array.isArray(organizations) ? organizations[0] : null;
    if (!organization?.id) throw new Error("WORKSPACE_NOT_CREATED");
    await request("/rest/v1/organization_members", {
        method: "POST",
        body: JSON.stringify({ organization_id: organization.id, user_id: userId, role: "owner" })
    });
    return { organization_id: organization.id, role: "owner" };
}

async function ensureOwnContext(event, organizationId, userId) {
    const path = `/rest/v1/work_contexts?organization_id=eq.${encodeURIComponent(organizationId)}&external_key=eq.own-business&select=*`;
    const existing = await userRequest(event, path);
    if (Array.isArray(existing) && existing[0]) return existing[0];
    const created = await userRequest(event, "/rest/v1/work_contexts?select=*", {
        method: "POST",
        headers: { Prefer: "return=representation,resolution=merge-duplicates" },
        body: JSON.stringify({ organization_id: organizationId, external_key: "own-business", kind: "own", name: "My business", project_name: "Business website", permissions_confirmed: true, asset_rights_confirmed: true, created_by: userId })
    });
    return Array.isArray(created) ? created[0] : created;
}

function record(value, organizationId, userId, existing = null) {
    const kind = value.kind === "own" ? "own" : "client";
    const name = clean(value.name, 180);
    if (!name) throw new Error("INVALID_CONTEXT");
    const externalKey = kind === "own" ? "own-business" : clean(value.externalKey || existing?.external_key, 120);
    if (!/^[a-z0-9][a-z0-9-]{0,119}$/.test(externalKey)) throw new Error("INVALID_CONTEXT");
    return {
        organization_id: organizationId,
        external_key: externalKey,
        kind,
        name,
        project_name: clean(value.projectName, 180) || `${name} website`,
        approval_contact: clean(value.approvalContact, 240),
        permissions_confirmed: kind === "own" || value.permissionsConfirmed === true,
        asset_rights_confirmed: kind === "own" || value.assetRightsConfirmed === true,
        status: value.status === "archived" ? "archived" : "active",
        created_by: existing?.created_by || userId
    };
}

exports.handler = async function handler(event = {}) {
    const blocked = await guard(event, "work-contexts", 60);
    if (blocked) return blocked;
    try {
        const method = String(event.httpMethod || "").toUpperCase();
        if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return response(405, { success: false, error: "Unsupported request method." }, {}, event);
        const user = await authenticate(event);
        const membership = await organizationFor(user.id);
        const organizationId = membership.organization_id;
        await ensureOwnContext(event, organizationId, user.id);
        const requestedId = event.queryStringParameters?.id || "";
        if (requestedId && !uuid(requestedId)) return response(400, { success: false, error: "Invalid work context ID." }, {}, event);
        const base = `/rest/v1/work_contexts?organization_id=eq.${encodeURIComponent(organizationId)}`;

        if (method === "GET") {
            const contexts = await userRequest(event, `${base}&select=*&order=created_at.asc`);
            return response(200, { success: true, organizationId, role: membership.role, contexts: Array.isArray(contexts) ? contexts : [] }, {}, event);
        }
        if (!roleCanManage(membership.role)) return response(403, { success: false, error: "Your workspace role cannot change clients." }, {}, event);

        if (method === "POST") {
            const value = body(event, 20_000);
            const payload = record(value, organizationId, user.id);
            if (payload.kind === "own") return response(409, { success: false, error: "The My business workspace already exists." }, {}, event);
            const result = await userRequest(event, "/rest/v1/work_contexts?select=*", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) });
            return response(201, { success: true, context: Array.isArray(result) ? result[0] : result }, {}, event);
        }

        if (!requestedId) return response(400, { success: false, error: "A work context ID is required." }, {}, event);
        const found = await userRequest(event, `${base}&id=eq.${encodeURIComponent(requestedId)}&select=*`);
        const existing = Array.isArray(found) ? found[0] : null;
        if (!existing) return response(404, { success: false, error: "Work context not found." }, {}, event);
        if (existing.kind === "own" && method === "DELETE") return response(409, { success: false, error: "My business cannot be deleted." }, {}, event);

        if (method === "DELETE") {
            await userRequest(event, `${base}&id=eq.${encodeURIComponent(requestedId)}`, { method: "DELETE" });
            return response(200, { success: true }, {}, event);
        }
        const value = body(event, 20_000);
        const payload = record({ ...value, kind: existing.kind, externalKey: existing.external_key }, organizationId, user.id, existing);
        const result = await userRequest(event, `${base}&id=eq.${encodeURIComponent(requestedId)}&select=*`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) });
        return response(200, { success: true, context: Array.isArray(result) ? result[0] : result }, {}, event);
    } catch (error) {
        if (error.message === "UNAUTHORIZED") return response(401, { success: false, error: "Please sign in first." }, {}, event);
        if (["INVALID_BODY", "INVALID_CONTEXT"].includes(error.message)) return response(400, { success: false, error: "The work context data is invalid." }, {}, event);
        if (error.message === "NOT_CONFIGURED") return response(503, { success: false, error: "Workspace services are unavailable." }, {}, event);
        console.error("Work context API error:", error.message || error);
        return response(500, { success: false, error: "The work context request failed." }, {}, event);
    }
};
