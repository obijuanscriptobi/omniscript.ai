"use strict";

const cheerio = require("cheerio");
const { TextDecoder } = require("node:util");

const LIMITS = Object.freeze({
    source: 1_000_000,
    output: 1_200_000,
    css: 1_000_000,
    body: 1_200_000,
    field: 500,
    services: 1_000,
    submitFunction: 20_000,
    filePath: 200,
    maxDomDepth: 180,
    recoveryText: 80_000
});

const DEFAULT_COLOR = "#d4af37";

const JSON_HEADERS = Object.freeze({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, max-age=0",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Cross-Origin-Resource-Policy": "same-origin",
    "X-Permitted-Cross-Domain-Policies": "none"
});

function response(statusCode, payload) {
    return {
        statusCode,
        isBase64Encoded: false,
        headers: JSON_HEADERS,
        body: JSON.stringify(payload)
    };
}

function cleanText(value, maximum = LIMITS.field) {
    return String(value ?? "")
        .replace(/[\u0000-\u001f\u007f]/g, "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, maximum);
}

function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[character]));
}

function validColor(value) {
    const color = String(value || "").trim();
    return /^#[\da-f]{6}$/i.test(color) ? color : DEFAULT_COLOR;
}

function validOutputPath(filePath) {
    return (
        typeof filePath === "string" &&
        filePath.length > 0 &&
        filePath.length <= LIMITS.filePath &&
        !filePath.startsWith("/") &&
        !filePath.includes("..") &&
        /^[A-Za-z0-9._/-]+$/.test(filePath)
    );
}

function validateBusiness(payload) {
    const source = payload?.business;
    const business =
        source && typeof source === "object" && !Array.isArray(source)
            ? source
            : {};

    return {
        name: cleanText(business.name),
        hook: cleanText(business.hook),
        location: cleanText(business.location),
        phone: cleanText(business.phone),
        color: validColor(cleanText(business.color, 20)),
        services: cleanText(business.services, LIMITS.services)
    };
}

function decodeUtf8(buffer) {
    try {
        return new TextDecoder("utf-8", { fatal: true }).decode(buffer);
    } catch {
        throw new Error("INVALID_BODY");
    }
}

function decodeBody(event) {
    const body = String(event.body || "");

    if (!event.isBase64Encoded) {
        return decodeUtf8(Buffer.from(body, "utf8"));
    }

    if (
        !body ||
        body.length % 4 !== 0 ||
        !/^[A-Za-z0-9+/]*={0,2}$/.test(body)
    ) {
        throw new Error("INVALID_BODY");
    }

    try {
        const decoded = Buffer.from(body, "base64");

        if (!decoded.length) throw new Error("INVALID_BODY");

        const input = body.replace(/=+$/, "");
        const output = decoded.toString("base64").replace(/=+$/, "");

        if (input !== output) throw new Error("INVALID_BODY");

        return decodeUtf8(decoded);
    } catch (error) {
        if (error?.message === "INVALID_BODY") throw error;
        throw new Error("INVALID_BODY");
    }
}

function fallbackSource(source) {
    const input = String(source || "").slice(0, LIMITS.source);
    const textOf = (value) => String(value || "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
    const headings = [...input.matchAll(/<h[1-6]\b[^>]*>([\s\S]*?)<\/h[1-6]>/gi)]
        .map((match) => textOf(match[1])).filter(Boolean).slice(0, 12);
    const paragraphs = [...input.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi)]
        .map((match) => textOf(match[1])).filter(Boolean).slice(0, 24);
    const images = [...input.matchAll(/<img\b([^>]*)>/gi)].map((match) => {
        const src = match[1].match(/\bsrc=["']([^"']+)["']/i)?.[1] || "";
        const alt = match[1].match(/\balt=["']([^"']*)["']/i)?.[1] || "";
        return /^https:\/\//i.test(src) || /^(?:\.\/|\/)/.test(src)
            ? `<img src="${escapeHtml(src)}" alt="${escapeHtml(alt)}" loading="lazy">`
            : "";
    }).filter(Boolean).slice(0, 12);
    const links = [...input.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)].map((match) => {
        const href = match[1].match(/\bhref=["']([^"']+)["']/i)?.[1] || "";
        const label = textOf(match[2]);
        return label && isAllowedUrl("href", href) ? `<a href="${escapeHtml(href)}">${escapeHtml(label)}</a>` : "";
    }).filter(Boolean).slice(0, 20);
    const plainText = textOf(input).slice(0, LIMITS.recoveryText);
    const title = headings[0] || plainText.slice(0, 120) || "Imported website";
    const content = [
        `<h1>${escapeHtml(title)}</h1>`,
        ...headings.slice(1).map((heading) => `<h2>${escapeHtml(heading)}</h2>`),
        ...paragraphs.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`),
        images.join(""),
        links.length ? `<nav aria-label="Imported links">${links.join(" ")}</nav>` : ""
    ].join("") || `<p>${escapeHtml(plainText || "Tell visitors what your business does and how to get started.")}</p>`;
    return cheerio.load(
        `<!doctype html><html lang="en"><head><title>${escapeHtml(title)}</title></head><body><main>${content}</main></body></html>`,
        { decodeEntities: true, scriptingEnabled: false },
        true
    );
}

function parseSource(source) {
    const raw = String(source || "").slice(0, LIMITS.source);
    parseSource.usedFallback = false;
    try {
        const parsed = cheerio.load(raw, { decodeEntities: true, scriptingEnabled: false });
        let tooDeep = false;
        parsed("*").each((_, element) => {
            let depth = 0;
            for (let current = element; current; current = current.parent) {
                depth += 1;
                if (depth > LIMITS.maxDomDepth) {
                    tooDeep = true;
                    break;
                }
            }
        });
        if (tooDeep) {
            parseSource.usedFallback = true;
            return fallbackSource(raw);
        }
        return parsed;
    } catch (error) {
        parseSource.usedFallback = true;
        console.warn("Repair parser fallback:", error?.message || error);
        return fallbackSource(raw);
    }
}

function isUnsafeUrl(value) {
    const candidate = String(value || "").replace(
        /[\u0000-\u0020\u007f]/g,
        ""
    );

    return /^(?:javascript|vbscript):/i.test(candidate) ||
        /^data:(?:text\/html|application\/xhtml\+xml|image\/svg\+xml)/i.test(
            candidate
        );
}

function isLocalUrl(value) {
    const candidate = String(value || "").trim();

    return (
        /^(?:#|\.\/|\.\.\/)/.test(candidate) ||
        (/^\//.test(candidate) && !candidate.startsWith("//"))
    );
}

function isAllowedUrl(attribute, value) {
    const candidate = String(value || "").trim();

    if (!candidate || isUnsafeUrl(candidate)) return false;

    const local = isLocalUrl(candidate);
    const remote = /^https:\/\//i.test(candidate);

    if (attribute === "href") {
        return local || remote || /^(?:mailto|tel):/i.test(candidate);
    }

    if (["src", "poster"].includes(attribute)) {
        return (
            local ||
            remote ||
            /^data:image\/(?:png|jpeg|gif|webp);base64,/i.test(candidate)
        );
    }

    return attribute === "action" && local;
}

function sanitizeCss(css) {
    return String(css || "")
        .replace(/<\/style/gi, "<\\/style")
        .replace(/@import[\s\S]*?(?:;|$)/gi, "")
        .replace(/expression\s*\([^)]*\)/gi, "none")
        .replace(
            /url\s*\(\s*(['"]?)\s*(?:javascript:|vbscript:|data:(?:text\/html|application\/xhtml\+xml|image\/svg\+xml))[^)]*\1\s*\)/gi,
            "none"
        )
        .replace(/(?:behavior|-moz-binding)\s*:/gi, "/* blocked: */")
        .slice(0, LIMITS.css);
}

function removeDangerousContent($) {
    const removed = new Set();

    $(
        "script,noscript,object,embed,applet,iframe,frame,frameset," +
            "portal,base,template,svg,foreignObject"
    ).each((_, element) => {
        removed.add(element.tagName || "element");
        $(element).remove();
    });

    $("meta").each((_, element) => {
        const directive = String($(element).attr("http-equiv") || "")
            .trim()
            .toLowerCase();

        if (
            ["refresh", "set-cookie", "content-security-policy"].includes(
                directive
            )
        ) {
            removed.add("meta");
            $(element).remove();
        }
    });

    $("*").each((_, element) => {
        for (const [rawName, rawValue] of Object.entries(
            element.attribs || {}
        )) {
            const name = rawName.toLowerCase();
            const value = String(rawValue || "").trim();

            if (name.startsWith("on")) {
                $(element).removeAttr(rawName);
                continue;
            }

            if (
                [
                    "srcdoc",
                    "formaction",
                    "formenctype",
                    "formmethod",
                    "formtarget",
                    "target"
                ].includes(name)
            ) {
                $(element).removeAttr(rawName);
                continue;
            }

            if (name === "style") {
                const safeStyle = sanitizeCss(value).trim();

                if (safeStyle) {
                    $(element).attr(rawName, safeStyle);
                } else {
                    $(element).removeAttr(rawName);
                }

                continue;
            }

            if (
                ["href", "src", "poster", "action"].includes(name) &&
                !isAllowedUrl(name, value)
            ) {
                $(element).removeAttr(rawName);
            }
        }

        if (element.tagName?.toLowerCase() === "link") {
            const rel = String($(element).attr("rel") || "").toLowerCase();

            if (/\b(?:import|prefetch|preconnect|dns-prefetch)\b/.test(rel)) {
                removed.add("link");
                $(element).remove();
            }
        }
    });

    return [...removed];
}

function ensureDocumentStructure($) {
    if (!$("html").length) {
        const content = $.root().html() || "";

        $.root()
            .empty()
            .append(
                $("<html>", { lang: "en" })
                    .append($("<head>"))
                    .append($("<body>").html(content))
            );
    }

    const html = $("html").first();

    html.attr("lang", cleanText(html.attr("lang") || "en", 30) || "en");

    if (!$("head").length) html.prepend("<head></head>");
    if (!$("body").length) $("html").append("<body></body>");
}

function ensureMeta($, selector, markup) {
    if (!$(selector).length) $("head").append(markup);
}

function ensureMetadata($, business) {
    const title = business.name || business.hook || "Responsive Website";
    const description =
        [business.hook, business.name, business.location]
            .filter(Boolean)
            .join(" - ") || "A responsive, accessible website.";

    ensureMeta($, "meta[charset]", '<meta charset="utf-8">');

    ensureMeta(
        $,
        "meta[name='viewport']",
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
    );

    if (!$("title").text().trim()) {
        $("head").append(`<title>${escapeHtml(title)}</title>`);
    }

    ensureMeta(
        $,
        "meta[name='description']",
        `<meta name="description" content="${escapeHtml(description)}">`
    );

    ensureMeta(
        $,
        "meta[name='theme-color']",
        `<meta name="theme-color" content="${validColor(business.color)}">`
    );

    ensureMeta(
        $,
        "meta[property='og:title']",
        `<meta property="og:title" content="${escapeHtml(title)}">`
    );

    ensureMeta(
        $,
        "meta[property='og:description']",
        `<meta property="og:description" content="${escapeHtml(
            business.hook || title
        )}">`
    );

    ensureMeta(
        $,
        "link[rel='canonical']",
        '<link rel="canonical" href="/">'
    );
}

function extractStyles($) {
    const styles = [];

    $("style").each((_, element) => {
        const css = sanitizeCss($(element).html()).trim();

        if (css) styles.push(css);
        $(element).remove();
    });

    return styles.join("\n\n").slice(0, LIMITS.css);
}

function ensureAssetLinks($) {
    const generatedStylesheet = "./style.css";
    const stylesheetLinks = $("link[rel~='stylesheet']");
    const hasGeneratedStylesheet = stylesheetLinks.is((_, element) =>
        ["style.css", generatedStylesheet].includes(
            String($(element).attr("href") || "").trim()
        )
    );

    // Keep the generated project self-contained. A remote or root-relative
    // style.css must not suppress the stylesheet returned in style.css.
    if (!hasGeneratedStylesheet) {
        $("head").append(
            `<link rel="stylesheet" href="${generatedStylesheet}">`
        );
    }

    $("script").remove();
    $("body").append('<script src="./script.js" defer></script>');
}

function secureForms($) {
    $("form").each((_, element) => {
        const form = $(element);

        form.attr({
            action: "/api/submit-form",
            method: "post",
            enctype: "application/x-www-form-urlencoded",
            "data-repair-form": "true"
        });

        form.removeAttr(
            "target formaction formenctype formmethod formtarget"
        );

        if (!form.find("input[name='website']").length) {
            form.append(
                '<input type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden">'
            );
        }

        form.find("input,textarea,select").each((index, field) => {
            const control = $(field);
            const type = String(control.attr("type") || "").toLowerCase();

            if (
                !control.attr("name") &&
                !["submit", "button", "reset"].includes(type)
            ) {
                control.attr("name", `field-${index + 1}`);
            }
        });
    });
}

function improveImages($) {
    $("img").each((_, element) => {
        const image = $(element);

        image.attr("alt", image.attr("alt") || "");
        image.attr("loading", image.attr("loading") || "lazy");
        image.attr("decoding", image.attr("decoding") || "async");

        const width = Number(image.attr("width"));
        const height = Number(image.attr("height"));

        if (
            (!Number.isFinite(width) || width <= 0) &&
            (!Number.isFinite(height) || height <= 0)
        ) {
            image.attr(
                "style",
                `${sanitizeCss(image.attr("style") || "")};max-width:100%;height:auto;`
            );
        }
    });
}

function improveLinks($) {
    $("a[target='_blank']").each((_, element) => {
        const link = $(element);
        const rel = new Set(
            String(link.attr("rel") || "").split(/\s+/).filter(Boolean)
        );

        rel.add("noopener");
        rel.add("noreferrer");
        link.attr("rel", [...rel].join(" "));
    });
}

function createNetlifyConfig() {
    return `# Generated Netlify configuration

[build]
  publish = "."
  functions = "netlify/functions"

[functions]
  node_bundler = "esbuild"

[[redirects]]
  from = "/api/submit-form"
  to = "/.netlify/functions/submit-form"
  status = 200
  force = true

[[headers]]
  for = "/*"
  [headers.values]
    Content-Security-Policy = "default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; img-src 'self' https: data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self' https: data:; form-action 'self'"
    X-Content-Type-Options = "nosniff"
    X-Frame-Options = "DENY"
    Referrer-Policy = "strict-origin-when-cross-origin"
    Permissions-Policy = "camera=(), microphone=(), geolocation=(), payment=(), usb=()"

[[headers]]
  for = "/.netlify/functions/*"
  [headers.values]
    Cache-Control = "no-store, max-age=0"
`;
}

function createMobileCss(originalCss, color, useLayoutFallback = false) {
    const extracted = sanitizeCss(originalCss);
    return `/* Extracted and sanitized styles */
${extracted || "/* No embedded styles found. */"}

${useLayoutFallback ? `/* Defensive layout fallback for malformed/deep source markup. */
*, *::before, *::after { box-sizing: border-box; }
img, video, canvas, svg { max-width: 100%; height: auto; }
[class], [id], main, header, footer, section, article, nav, form { min-width: 0; max-width: 100%; }
main, header, footer, section, article, nav, form { display: block; width: 100%; }
[class*="grid"], [class*="flex"], [class*="row"], [class*="col"], [class*="container"], [class*="layout"] { display: flex; flex-wrap: wrap; align-items: stretch; gap: 1rem; }
[class*="grid"] > *, [class*="flex"] > *, [class*="row"] > *, [class*="col"] > *, [class*="container"] > *, [class*="layout"] > * { min-width: 0; flex: 1 1 16rem; }
` : "/* Original layout rules preserved; only safe overflow guards are added. */"}

:root { --repair-accent: ${validColor(color)}; }
*,*::before,*::after { box-sizing:border-box; }
html,body { max-width:100%; min-width:0; overflow-x:hidden; }
body { margin:0; }
img,video,svg,canvas { max-width:100%; }
img,video { height:auto; }
pre,code { max-width:100%; overflow-x:auto; white-space:pre-wrap; overflow-wrap:anywhere; }
button,input,textarea,select { max-width:100%; font:inherit; }
:focus-visible { outline:3px solid var(--repair-accent); outline-offset:3px; }

@media (max-width:767px) {
    table { display:block; max-width:100%; overflow-x:auto; }
    .row,.grid,.flex,.flex-container,
    .row>*,.grid>*,.flex>*,.flex-container>* {
        min-width:0;
        max-width:100%;
    }
}

@media (prefers-reduced-motion:reduce) {
    *,*::before,*::after {
        animation-duration:.01ms!important;
        transition-duration:.01ms!important;
        scroll-behavior:auto!important;
    }
}`;
}

function createClientScript() {
    return `"use strict";

document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("img").forEach((image) => {
        if (!image.loading) image.loading = "lazy";
        if (!image.decoding) image.decoding = "async";
        if (!image.hasAttribute("alt")) image.alt = "";
    });

    document.querySelectorAll("form[data-repair-form='true']")
        .forEach((form) => {
            form.addEventListener("submit", async (event) => {
                event.preventDefault();

                if (form.dataset.submitting === "true") return;
                if (!form.reportValidity()) return;

                form.dataset.submitting = "true";

                const submit = form.querySelector(
                    "button[type='submit'],input[type='submit']"
                );
                const isInput = submit?.tagName.toLowerCase() === "input";
                const original = submit
                    ? isInput ? submit.value : submit.textContent
                    : "";
                const feedback = document.createElement("p");
                const controller = new AbortController();
                const timer = setTimeout(() => controller.abort(), 15000);
                const submissionId =
                    globalThis.crypto?.randomUUID?.() ||
                    Date.now().toString(36) + Math.random().toString(36);

                feedback.dataset.formFeedback = "true";
                feedback.setAttribute("role", "status");
                feedback.setAttribute("aria-live", "polite");
                feedback.textContent = "Sending...";
                form.querySelector("[data-form-feedback]")?.remove();
                form.append(feedback);

                if (submit) {
                    submit.disabled = true;
                    submit.setAttribute("aria-busy", "true");
                }

                try {
                    const response = await fetch("/api/submit-form", {
                        method: "POST",
                        body: new URLSearchParams(new FormData(form)),
                        headers: {
                            Accept: "application/json",
                            "Content-Type":
                                "application/x-www-form-urlencoded;charset=UTF-8",
                            "X-Submission-ID": submissionId
                        },
                        credentials: "same-origin",
                        signal: controller.signal
                    });

                    const data = await response.json().catch(() => null);

                    if (!response.ok || !data?.success) {
                        throw new Error(data?.error || "Submission failed.");
                    }

                    form.reset();
                    feedback.textContent =
                        data.message || "Thanks. Your message was sent.";
                } catch (error) {
                    feedback.setAttribute("role", "alert");
                    feedback.textContent =
                        error?.name === "AbortError"
                            ? "The request timed out. Please try again."
                            : error?.message ||
                              "We could not send your message. Please try again.";
                } finally {
                    clearTimeout(timer);
                    form.dataset.submitting = "false";

                    if (submit) {
                        submit.disabled = false;
                        submit.removeAttribute("aria-busy");

                        if (isInput) submit.value = original;
                        else submit.textContent = original;
                    }
                }
            });
        });
});`;
}

function createSubmitFunction() {
    return `"use strict";

const { TextDecoder } = require("node:util");

const MAX_BODY = 20000;
const TIMEOUT = 8000;

function reply(statusCode, payload, extraHeaders = {}) {
    const enforced = {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store, max-age=0",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
        "Cross-Origin-Resource-Policy": "same-origin",
        "X-Permitted-Cross-Domain-Policies": "none"
    };
    const configured =
        extraHeaders && typeof extraHeaders === "object" && !Array.isArray(extraHeaders)
            ? extraHeaders
            : {};
    const protectedNames = new Set(
        Object.keys(enforced).map((name) => name.toLowerCase())
    );
    const additional = {};

    for (const [name, value] of Object.entries(configured)) {
        if (!protectedNames.has(String(name).toLowerCase())) {
            additional[name] = value;
        }
    }

    return {
        statusCode,
        headers: {
            ...additional,
            ...enforced
        },
        body: JSON.stringify(payload)
    };
}

function header(event, name) {
    const headers = event.headers || {};
    const key = Object.keys(headers).find(
        (entry) => entry.toLowerCase() === name.toLowerCase()
    );
    return key ? String(headers[key] || "") : "";
}

function clean(value, maximum) {
    return String(value ?? "")
        .replace(/[\\u0000-\\u001f\\u007f]/g, "")
        .replace(/\\s+/g, " ")
        .trim()
        .slice(0, maximum);
}

function decodeUtf8(buffer) {
    try {
        return new TextDecoder("utf-8", { fatal: true }).decode(buffer);
    } catch {
        throw new Error("INVALID_BODY");
    }
}

function parse(event) {
    let body = String(event.body || "");

    if (event.isBase64Encoded) {
        if (
            !body ||
            body.length % 4 !== 0 ||
            !/^[A-Za-z0-9+/]*={0,2}$/.test(body)
        ) {
            throw new Error("INVALID_BODY");
        }

        const decoded = Buffer.from(body, "base64");
        const input = body.replace(/=+$/, "");
        const output = decoded.toString("base64").replace(/=+$/, "");

        if (!decoded.length || input !== output) {
            throw new Error("INVALID_BODY");
        }

        body = decodeUtf8(decoded);
    } else {
        body = decodeUtf8(Buffer.from(body, "utf8"));
    }

    if (Buffer.byteLength(body, "utf8") > MAX_BODY) {
        throw new Error("TOO_LARGE");
    }

    const contentType = header(event, "content-type").toLowerCase();

    if (contentType.includes("application/json")) {
        let value;

        try {
            value = JSON.parse(body || "{}");
        } catch {
            throw new Error("INVALID_BODY");
        }

        if (!value || typeof value !== "object" || Array.isArray(value)) {
            throw new Error("INVALID_BODY");
        }

        return value;
    }

    if (
        !contentType ||
        contentType.includes("application/x-www-form-urlencoded")
    ) {
        return Object.fromEntries(new URLSearchParams(body));
    }

    throw new Error("UNSUPPORTED_FORMAT");
}

function isPrivateWebhookHostname(hostname) {
    const value = String(hostname || "").toLowerCase().replace(/\\.$/, "");

    if (
        value === "localhost" ||
        value.endsWith(".localhost") ||
        value.endsWith(".local") ||
        value.endsWith(".internal") ||
        value === "metadata.google.internal" ||
        value === "metadata.google.com"
    ) return true;

    const address = value.replace(/^\\[|\\]$/g, "");
    const parts = address.split(".").map(Number);

    if (parts.length === 4 && parts.every(Number.isInteger)) {
        const [a, b, c] = parts;
        return (
            a === 0 || a === 10 || a === 127 ||
            (a === 100 && b >= 64 && b <= 127) ||
            (a === 169 && b === 254) ||
            (a === 172 && b >= 16 && b <= 31) ||
            (a === 192 && (b === 0 || b === 168)) ||
            (a === 198 && b >= 18 && b <= 19) ||
            (a === 198 && b === 51 && c === 100) ||
            (a === 203 && b === 0 && c === 113) ||
            a >= 224
        );
    }

    return /^::1$|^::$|^f[cd]/i.test(address) ||
        /^fe[89ab]/i.test(address) ||
        /^ff/i.test(address) ||
        /^::ffff:(?:10\\.|127\\.|192\\.168\\.)/i.test(address);
}

function getWebhook() {
    const raw = String(process.env.LEADS_WEBHOOK_URL || "").trim();
    const allowed = String(process.env.LEADS_WEBHOOK_HOSTS || "")
        .split(",")
        .map((host) => host.trim().toLowerCase())
        .filter(Boolean);

    if (!raw || !allowed.length) throw new Error("NOT_CONFIGURED");

    let url;

    try {
        url = new URL(raw);
    } catch {
        throw new Error("INVALID_WEBHOOK");
    }

    const hostname = url.hostname.toLowerCase();

    if (
        url.protocol !== "https:" ||
        url.username ||
        url.password ||
        url.port ||
        isPrivateWebhookHostname(hostname) ||
        !allowed.includes(hostname)
    ) {
        throw new Error("INVALID_WEBHOOK");
    }

    return url;
}

async function discardResponseBody(responseObject) {
    try {
        if (responseObject?.body) {
            await responseObject.body.cancel();
        }
    } catch {
        // The response body is being discarded.
    }
}

async function deliver(url, payload, submissionId) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT);

    try {
        const result = await fetch(url, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                "Idempotency-Key": submissionId,
                "X-Submission-ID": submissionId
            },
            body: JSON.stringify(payload),
            signal: controller.signal
        });

        if (!result.ok) {
            await discardResponseBody(result);
            throw new Error("DELIVERY_FAILED");
        }

        await discardResponseBody(result);
    } finally {
        clearTimeout(timer);
    }
}

exports.handler = async function handler(event = {}) {
    if (String(event.httpMethod || "").toUpperCase() !== "POST") {
        return reply(405, {
            success: false,
            error: "Only POST requests are supported."
        });
    }

    try {
        const input = parse(event);
        const submissionId =
            clean(header(event, "x-submission-id"), 100) ||
            globalThis.crypto?.randomUUID?.() ||
            Date.now().toString(36) + Math.random().toString(36);

        const submission = {
            name: clean(input.name, 200),
            email: clean(input.email, 320),
            phone: clean(input.phone, 80),
            company: clean(input.company, 200),
            message: clean(input.message, 2000),
            website: clean(input.website, 200)
        };

        if (
            submission.email &&
            !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/i.test(submission.email)
        ) {
            return reply(400, {
                success: false,
                error: "Please provide a valid email address."
            });
        }

        if (
            !submission.name &&
            !submission.email &&
            !submission.phone &&
            !submission.message
        ) {
            return reply(400, {
                success: false,
                error: "Please provide contact information."
            });
        }

        if (submission.website) {
            return reply(200, {
                success: true,
                message: "Thanks. Your message was received."
            });
        }

        await deliver(
            getWebhook(),
            {
                source: "website-contact-form",
                submissionId,
                name: submission.name,
                email: submission.email,
                phone: submission.phone,
                company: submission.company,
                message: submission.message,
                receivedAt: new Date().toISOString()
            },
            submissionId
        );

        return reply(200, {
            success: true,
            message: "Thanks. Your message was sent.",
            submissionId
        });
    } catch (error) {
        if (error?.message === "TOO_LARGE") {
            return reply(413, {
                success: false,
                error: "The submission is too large."
            });
        }

        if (error?.message === "INVALID_BODY") {
            return reply(400, {
                success: false,
                error: "The submission body is invalid."
            });
        }

        if (error?.message === "UNSUPPORTED_FORMAT") {
            return reply(415, {
                success: false,
                error: "Unsupported submission format."
            });
        }

        if (error?.message === "NOT_CONFIGURED") {
            return reply(503, {
                success: false,
                error: "Lead delivery is not configured."
            });
        }

        if (error?.name === "AbortError") {
            return reply(504, {
                success: false,
                error: "Lead delivery timed out. Please try again."
            });
        }

        console.error("Generated lead delivery failed:", error?.message);

        return reply(502, {
            success: false,
            error: "The message could not be delivered. Please try again."
        });
    }
};`;
}

function validateOutput($) {
    const warnings = [];

    if (!$("main,[role='main']").length) {
        warnings.push("No main landmark was found.");
    }

    if (!$("h1").length) warnings.push("No H1 heading was found.");
    if (!$("title").text().trim()) warnings.push("The page title is missing.");

    if (!$("meta[name='viewport']").length) {
        warnings.push("Viewport metadata is missing.");
    }

    $("img").each((_, element) => {
        if (!$(element).attr("alt")) {
            warnings.push("An image is missing alternative text.");
        }
    });

    $("form").each((_, element) => {
        const form = $(element);

        if (
            form.attr("action") !== "/api/submit-form" ||
            form.attr("method")?.toLowerCase() !== "post"
        ) {
            warnings.push("A form could not be normalized safely.");
        }
    });

    return [...new Set(warnings)];
}

function serializeDocument($) {
    return `<!doctype html>\n${$.html()}`;
}

exports.handler = async function handler(event = {}) {
    if (String(event.httpMethod || "").toUpperCase() !== "POST") {
        return response(405, {
            success: false,
            error: "Only POST requests are supported."
        });
    }

    try {
        const body = decodeBody(event);

        if (Buffer.byteLength(body, "utf8") > LIMITS.body) {
            return response(413, {
                success: false,
                error: "The request payload is too large."
            });
        }

        let payload;

        try {
            payload = JSON.parse(body || "{}");
        } catch {
            return response(400, {
                success: false,
                error: "The request body must contain valid JSON."
            });
        }

        if (
            !payload ||
            typeof payload !== "object" ||
            Array.isArray(payload)
        ) {
            return response(400, {
                success: false,
                error: "The request body must be a JSON object."
            });
        }

        if (
            typeof payload.rawSource !== "string" ||
            !payload.rawSource.trim()
        ) {
            return response(400, {
                success: false,
                error: "No source code was provided."
            });
        }

        const rawSource = payload.rawSource.trim();

        if (Buffer.byteLength(rawSource, "utf8") > LIMITS.source) {
            return response(413, {
                success: false,
                error: "The submitted source code is too large."
            });
        }

        const business = validateBusiness(payload);
        let $ = parseSource(rawSource);
        let parserUsedFallback = Boolean(parseSource.usedFallback);
        let originalCss = "";
        try {
            originalCss = extractStyles($);
        } catch (error) {
            console.warn("Style extraction fallback:", error?.message || error);
            originalCss = "";
        }
        let removedElements = [];
        try {
            removedElements = removeDangerousContent($);
        } catch (error) {
            console.warn("DOM sanitization fallback:", error?.message || error);
            // Keep the recovered document usable even if a malformed subtree
            // defeats a selector pass.
            removedElements = ["malformed-subtree"];
        }

        try {
            ensureDocumentStructure($);
            ensureMetadata($, business);
            ensureAssetLinks($);
            secureForms($);
            improveImages($);
            improveLinks($);
        } catch (error) {
            console.warn("Document transformation fallback:", error?.message || error);
            $ = fallbackSource(rawSource);
            parserUsedFallback = true;
            ensureDocumentStructure($);
            ensureMetadata($, business);
            ensureAssetLinks($);
            secureForms($);
            improveImages($);
            improveLinks($);
        }

        /* Keep the transformation pipeline total: a malformed DOM must still
           produce a readable, deployable project rather than a 500 response. */
        const files = {
            "index.html": serializeDocument($),
            "style.css": createMobileCss(originalCss, business.color, parserUsedFallback),
            "script.js": createClientScript(),
            "netlify.toml": createNetlifyConfig(),
            "submit-form.js": createSubmitFunction(),
            "netlify/functions/submit-form.js": createSubmitFunction()
        };

        for (const filePath of Object.keys(files)) {
            if (!validOutputPath(filePath)) {
                return response(500, {
                    success: false,
                    error: "The repair engine generated an unsafe file path."
                });
            }
        }

        const totalOutputLength = Object.values(files).reduce(
            (total, value) => total + Buffer.byteLength(value, "utf8"),
            0
        );

        if (
            Buffer.byteLength(files["index.html"], "utf8") > LIMITS.output ||
            Buffer.byteLength(files["style.css"], "utf8") > LIMITS.css ||
            Buffer.byteLength(files["submit-form.js"], "utf8") >
                LIMITS.submitFunction ||
            totalOutputLength > LIMITS.output
        ) {
            return response(413, {
                success: false,
                error: "The repaired website is too large to generate safely."
            });
        }

        const warnings = validateOutput($);

        if (originalCss) {
            warnings.push("Embedded CSS was moved into style.css.");
        }
        if (parserUsedFallback) {
            warnings.push("The source used unusually deep or malformed markup; a safe block-flow recovery was used to preserve readable content.");
        }

        if (removedElements.length) {
            warnings.push(
                `Removed unsafe elements: ${removedElements.join(", ")}.`
            );
        }

        return response(200, {
            success: true,
            fixesApplied: [
                "Normalized the source HTML structure and metadata.",
                "Removed unsafe executable and embedded content.",
                "Blocked protocol-relative and unsafe resource URLs.",
                "Sanitized inline styles and moved embedded styles into style.css.",
                "Added responsive, focus, and reduced-motion CSS.",
                "Secured forms and added honeypot protection.",
                "Added submission IDs for webhook traceability.",
                "Improved image loading and external-link security.",
                "Preserved headings, paragraphs, images, and safe links during parser recovery.",
                "Added flex/block layout fallbacks for deep or malformed source structures.",
                "Generated a complete deployable Netlify project."
            ],
            warnings: [...new Set(warnings)],
            diagnostics: {
                sourceLength: Buffer.byteLength(rawSource, "utf8"),
                outputLength: Buffer.byteLength(files["index.html"], "utf8"),
                totalOutputLength,
                originalCssLength: Buffer.byteLength(originalCss, "utf8"),
                removedElementCount: removedElements.length,
                businessFieldsReceived: Object.keys(business).filter((key) =>
                    Boolean(business[key])
                )
            },
            files
        });
    } catch (error) {
        if (error?.message === "INVALID_BODY") {
            return response(400, {
                success: false,
                error: "The request body is invalid."
            });
        }

        console.error("Repair pipeline error:", error?.message || error);

        return response(400, {
            success: false,
            error: "The repair engine could not process the submitted website."
        });
    }
};