"use strict";

const dns = require("node:dns").promises;
const net = require("node:net");
const { providerClient, requestId } = require("./netlify/functions/provider-adapters.js");

const LIMITS = Object.freeze({
    maxUrlLength: 2_048,
    htmlBytes: 1_000_000,
    crawlPages: 6,
    crawlPageBytes: 350_000,
    crawlTotalBytes: 1_500_000,
    redirects: 5,
    // Stay within common serverless execution limits while allowing the
    // provider enough time to fetch a normal page.
    timeoutMs: 15_000
});

const SCRAPINGBEE_ENDPOINT = "https://app.scrapingbee.com/api/v1/";
const HTTP_PROTOCOLS = new Set(["http:", "https:"]);
const REDIRECT_STATUSES = new Set([301, 302, 303, 307, 308]);

const JSON_HEADERS = Object.freeze({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, max-age=0",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-origin"
});

function response(statusCode, payload, extraHeaders = {}) {
    const headers = {};
    const protectedNames = new Set(
        Object.keys(JSON_HEADERS).map((name) => name.toLowerCase())
    );

    for (const [name, value] of Object.entries(extraHeaders || {})) {
        if (!protectedNames.has(String(name).toLowerCase())) {
            headers[name] = value;
        }
    }

    return {
        statusCode,
        headers: {
            ...headers,
            ...JSON_HEADERS
        },
        isBase64Encoded: false,
        body: JSON.stringify(payload)
    };
}

function normalizeIp(address) {
    const value = String(address || "").trim().toLowerCase();

    if (value.startsWith("::ffff:")) {
        const mapped = value.slice(7);

        if (net.isIP(mapped) === 4) return mapped;
    }

    return value.replace(/^\[|\]$/g, "");
}

function expandIpv6(value) {
    const normalized = String(value || "").toLowerCase();

    if (!normalized || normalized.includes(":::")) return null;

    const halves = normalized.split("::");

    if (halves.length > 2) return null;

    const parseHalf = (half) => {
        if (!half) return [];

        const parts = half.split(":");

        if (!parts.every((part) => /^[0-9a-f]{1,4}$/.test(part))) {
            return null;
        }

        return parts.map((part) => parseInt(part, 16));
    };

    const left = parseHalf(halves[0]);
    if (!left) return null;

    const right = halves.length === 2 ? parseHalf(halves[1]) : [];
    if (!right) return null;

    if (halves.length === 1) {
        return left.length === 8 ? left : null;
    }

    const missing = 8 - left.length - right.length;

    if (missing < 1) return null;

    return [
        ...left,
        ...Array.from({ length: missing }, () => 0),
        ...right
    ];
}

function isPrivateAddress(address) {
    const normalized = normalizeIp(address);
    const version = net.isIP(normalized);

    if (version === 4) {
        const [a, b, c] = normalized.split(".").map(Number);

        return (
            a === 0 ||
            a === 10 ||
            a === 127 ||
            (a === 100 && b >= 64 && b <= 127) ||
            (a === 169 && b === 254) ||
            (a === 172 && b >= 16 && b <= 31) ||
            (a === 192 && b === 0) ||
            (a === 192 && b === 168) ||
            (a === 198 && [18, 19].includes(b)) ||
            (a === 198 && b === 51 && c === 100) ||
            (a === 192 && b === 0 && c === 2) ||
            (a === 203 && b === 0 && c === 113) ||
            a >= 224
        );
    }

    if (version === 6) {
        const value = normalized.toLowerCase();
        const embeddedIpv4 = value.match(
            /^(?:[0-9a-f]{1,4}:)*(\d{1,3}(?:\.\d{1,3}){3})$/
        );

        if (embeddedIpv4 && net.isIP(embeddedIpv4[1]) === 4) {
            if (isPrivateAddress(embeddedIpv4[1])) return true;
        }

        const groups = expandIpv6(value);
        if (!groups) return true;

        const first = groups[0];
        const second = groups[1];

        // 6to4 addresses can embed a private IPv4 address.
        if (first === 0x2002) {
            const embedded = [
                groups[1] >> 8,
                groups[1] & 255,
                groups[2] >> 8,
                groups[2] & 255
            ].join(".");

            if (isPrivateAddress(embedded)) return true;
        }

        return (
            groups.slice(0, 7).every((group) => group === 0) ||
            (groups.slice(0, 5).every((group) => group === 0) &&
                groups[5] === 0xffff) ||
            (first & 0xfe00) === 0xfc00 ||
            (first & 0xffc0) === 0xfe80 ||
            first >= 0xff00 ||
            (first === 0x2001 && second === 0x0db8) ||
            (first === 0x2001 && second === 0x0002)
        );
    }

    return true;
}

function isBlockedHostname(hostname) {
    const value = String(hostname || "")
        .toLowerCase()
        .replace(/\.$/, "");

    return (
        !value ||
        value.length > 253 ||
        value === "localhost" ||
        value.endsWith(".localhost") ||
        value.endsWith(".local") ||
        value.endsWith(".internal") ||
        value === "metadata.google.internal" ||
        value === "metadata.google.com" ||
        value === "instance-data.ec2.internal"
    );
}

async function isSafeTarget(url) {
    if (
        !url ||
        !HTTP_PROTOCOLS.has(url.protocol) ||
        url.username ||
        url.password ||
        url.hash ||
        url.hostname.length > 253
    ) {
        return false;
    }

    const hostname = url.hostname.toLowerCase().replace(/\.$/, "");

    if (isBlockedHostname(hostname)) return false;

    if (url.port) {
        const port = Number(url.port);
        const expectedPort = url.protocol === "https:" ? 443 : 80;

        if (!Number.isInteger(port) || port < 1 || port > 65535) {
            return false;
        }

        if (port !== expectedPort) return false;
    }

    if (net.isIP(hostname)) {
        return !isPrivateAddress(hostname);
    }

    try {
        const addresses = await dns.lookup(hostname, {
            all: true,
            verbatim: true
        });

        return (
            addresses.length > 0 &&
            addresses.every(({ address }) => !isPrivateAddress(address))
        );
    } catch {
        return false;
    }
}

function decodeBody(event) {
    const body = String(event?.body || "");

    if (!event?.isBase64Encoded) return body;

    if (
        body.length % 4 !== 0 ||
        !/^[A-Za-z0-9+/]*={0,2}$/.test(body)
    ) {
        return "";
    }

    try {
        const decoded = Buffer.from(body, "base64");
        const canonicalInput = body.replace(/=+$/, "");
        const canonicalOutput = decoded
            .toString("base64")
            .replace(/=+$/, "");

        if (!decoded.length || canonicalInput !== canonicalOutput) {
            return "";
        }

        return decoded.toString("utf8");
    } catch {
        return "";
    }
}

function getRequestedUrl(event) {
    const queryUrl = event?.queryStringParameters?.url;

    if (queryUrl) return queryUrl;

    if (String(event?.httpMethod || "").toUpperCase() !== "POST") {
        return "";
    }

    const contentType = String(
        Object.entries(event?.headers || {}).find(
            ([name]) => name.toLowerCase() === "content-type"
        )?.[1] || ""
    ).toLowerCase();
    const body = decodeBody(event).trim();

    if (!body) return "";

    try {
        if (contentType.includes("application/json")) {
            const parsed = JSON.parse(body);
            return parsed && typeof parsed.url === "string" ? parsed.url : "";
        }

        if (contentType.includes("application/x-www-form-urlencoded")) {
            return new URLSearchParams(body).get("url") || "";
        }

        // Accept a plain URL as a compatibility fallback for older clients.
        if (/^https?:\/\//i.test(body)) return body;
    } catch {
        return "";
    }

    return "";
}

function extractTargetUrl(event) {
    const rawUrl = String(getRequestedUrl(event) || "").trim();

    if (!rawUrl || rawUrl.length > LIMITS.maxUrlLength) {
        return null;
    }

    // Accept bare public domains such as example.info or example.co.uk while
    // keeping protocol-relative and non-HTTP URLs invalid.
    const candidate = /^[a-z][a-z\d+.-]*:\/\//i.test(rawUrl)
        ? rawUrl
        : `https://${rawUrl}`;

    try {
        const url = new URL(candidate);

        if (
            !HTTP_PROTOCOLS.has(url.protocol) ||
            !url.hostname ||
            url.username ||
            url.password ||
            url.hash ||
            (url.port && !/^\d{1,5}$/.test(url.port)) ||
            (url.port && Number(url.port) > 65535)
        ) {
            return null;
        }

        return url;
    } catch {
        return null;
    }
}

function getScrapingBeeKey() {
    const key = [
        process.env.SCRAPINGBEE_API_KEY,
        process.env.SCRAPINGBEE_KEY
    ]
        .map((value) => String(value || "").trim())
        .find((value) => value && !/^(your[_-]?key|change[_-]?me|undefined|null)$/i.test(value)) || "";

    // A missing or placeholder value must never be sent as a provider key.
    return key;
}

function createScrapingBeeUrl(url, apiKey) {
    const endpoint = new URL(SCRAPINGBEE_ENDPOINT);
    endpoint.searchParams.set("api_key", apiKey);
    endpoint.searchParams.set("url", String(url));
    endpoint.searchParams.set("render_js", "true");
    endpoint.searchParams.set("wait", "1000");
    endpoint.searchParams.set("premium_proxy", "true");
    endpoint.searchParams.set("block_resources", "false");
    // Let ScrapingBee resolve normal website redirects. Its response is the
    // rendered/fetched document; a manual provider redirect is not the
    // target site's final HTML and would otherwise be reported as an error.
    endpoint.searchParams.set("follow_redirects", "true");
    // ScrapingBee expects timeout in milliseconds. Keep the provider timeout
    // aligned with the server-side AbortController timeout.
    endpoint.searchParams.set("timeout", String(LIMITS.timeoutMs));
    return endpoint;
}

async function fetchWithTimeout(url) {
    const scrapingBeeKey = getScrapingBeeKey();

    if (!scrapingBeeKey) throw new Error("SCRAPINGBEE_NOT_CONFIGURED");

    const client = providerClient("scrapingbee", {
        endpoint: "https://app.scrapingbee.com",
        timeoutMs: LIMITS.timeoutMs,
        retries: 1,
        requestId: requestId()
    });
    const requestUrl = createScrapingBeeUrl(url, scrapingBeeKey);
    const result = await client.request(`${requestUrl.pathname}${requestUrl.search}`, {
        raw: true,
        method: "GET",
        redirect: "follow",
        headers: {
            Accept: "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.8",
            "Accept-Encoding": "identity",
            "User-Agent": "WebsiteWorkspaceScraper/1.2"
        }
    });

    return { webResponse: result.response, timer: null, viaScrapingBee: true };
}

async function discardResponseBody(responseObject) {
    try {
        if (responseObject?.body) {
            await responseObject.body.cancel();
        }
    } catch {
        // The response is already being discarded.
    }
}

async function readProviderError(responseObject) {
    try {
        const text = await responseObject.text();
        const contentType = (
            responseObject.headers.get("content-type") || ""
        ).toLowerCase();

        if (contentType.includes("json")) {
            try {
                const payload = JSON.parse(text);
                const message = payload?.message || payload?.error;
                if (typeof message === "string" && message.trim()) {
                    return message.trim().slice(0, 300);
                }
            } catch {
                // Fall through to the bounded plain-text response.
            }
        }

        return String(text || "").replace(/\s+/g, " ").trim().slice(0, 300);
    } catch {
        return "";
    }
}

async function readHtml(responseObject) {
    const contentLengthHeader =
        responseObject.headers.get("content-length") || "";
    const contentLength = Number(contentLengthHeader);

    if (
        contentLengthHeader &&
        (!/^\d+$/.test(contentLengthHeader.trim()) ||
            !Number.isSafeInteger(contentLength) ||
            contentLength < 0)
    ) {
        throw new Error("INVALID_CONTENT_LENGTH");
    }

    if (contentLength > LIMITS.htmlBytes) {
        throw new Error("TOO_LARGE");
    }

    if (
        !responseObject.body ||
        typeof responseObject.body.getReader !== "function"
    ) {
        const text = await responseObject.text();

        if (Buffer.byteLength(text, "utf8") > LIMITS.htmlBytes) {
            throw new Error("TOO_LARGE");
        }

        return text;
    }

    const reader = responseObject.body.getReader();
    const chunks = [];
    let totalBytes = 0;

    try {
        while (true) {
            const { done, value } = await reader.read();

            if (done) break;
            if (!value || !value.byteLength) continue;

            totalBytes += value.byteLength;

            if (totalBytes > LIMITS.htmlBytes) {
                await reader.cancel();
                throw new Error("TOO_LARGE");
            }

            chunks.push(Buffer.from(value));
        }
    } finally {
        reader.releaseLock();
    }

    return Buffer.concat(chunks, totalBytes).toString("utf8");
}

function analyzeHtml(contents) {
    const html = String(contents || "");
    const links = [...html.matchAll(/<a\b[^>]*href=["']([^"']+)["']/gi)].map((match) => match[1]).filter(Boolean).slice(0, 100);
    const emails = [...new Set((html.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || []).map((value) => value.toLowerCase()))].slice(0, 20);
    const phones = [...new Set((html.match(/(?:\+?\d[\d\s().-]{7,}\d)/g) || []).map((value) => value.replace(/\s+/g, " ").trim()))].slice(0, 20);
    const colors = [...new Set((html.match(/#[0-9a-f]{3,8}\b/gi) || []).map((value) => value.toLowerCase()))].slice(0, 40);
    const logo = html.match(/<(?:img|svg)\b[^>]*(?:alt|class|id)=["'][^"']*logo[^"']*["'][^>]*(?:src|href)=["']([^"']+)["']/i)?.[1] ||
        html.match(/<(?:img|svg)\b[^>]*(?:src|href)=["']([^"']+)["'][^>]*(?:alt|class|id)=["'][^"']*logo[^"']*["']/i)?.[1] || "";
    const assets = [...html.matchAll(/<(?:img|source)\b[^>]*(?:src|srcset)=["']([^"']+)["']/gi)].map((match) => match[1]).filter(Boolean).slice(0, 100);
    const headings = [...html.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi)].map((match) => ({ level: Number(match[1]), text: match[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 180) })).filter((item) => item.text).slice(0, 60);
    return {
        title: (html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 180),
        headings,
        links,
        assets,
        forms: (html.match(/<form\b/gi) || []).length,
        scripts: (html.match(/<script\b/gi) || []).length,
        stylesheets: (html.match(/<link\b[^>]+rel=["'][^"']*stylesheet/i) || []).length,
        bookingLinks: links.filter((link) => /book|reserv|appoint|schedule|calendly|cal\.com/i.test(link)).length,
        reputation: (() => { const visibleText = html.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " "); const rating = visibleText.match(/\b([45](?:\.\d)?)\s*(?:\/\s*5|stars?|out of 5)\b/i); const reviews = visibleText.match(/\b([\d,]+)\s*(?:reviews?|ratings?)\b/i); return { rating: rating ? Number(rating[1]) : 0, reviewCount: reviews ? Number(reviews[1].replace(/,/g, "")) : 0, source: rating || reviews ? "audited public website" : "" }; })(),
        contact: { emails, phones },
        brand: { colors, logo },
        limitations: ["Only public response content is analyzed; private server code, databases, CMS administration, credentials, and external account settings are not accessible."]
    };
}

function redirectResponse(message) {
    return response(502, { error: message });
}

function absolutePublicUrl(value, baseUrl) {
    try {
        const url = new URL(String(value || ""), baseUrl);
        if (!HTTP_PROTOCOLS.has(url.protocol) || url.username || url.password || url.hash) return null;
        return url;
    } catch {
        return null;
    }
}

function sameOrigin(a, b) {
    return a.protocol === b.protocol && a.hostname === b.hostname && (a.port || "") === (b.port || "");
}

function extractImportLinks(html, baseUrl) {
    const links = [];
    for (const match of String(html || "").matchAll(/<a\\b[^>]*href=["']([^"']+)["']/gi)) {
        const url = absolutePublicUrl(match[1], baseUrl);
        if (url && sameOrigin(url, baseUrl) && !url.search && !/\\.(?:pdf|zip|docx?|xlsx?|png|jpe?g|gif|svg|webp|mp4|mp3)$/i.test(url.pathname)) {
            url.hash = "";
            if (!links.some((item) => item.href === url.href)) links.push(url);
        }
    }
    return links;
}

function extractPublicAssets(html, baseUrl) {
    const assets = [];
    const pattern = /<(?:img|source|link)\\b[^>]*(?:src|href|srcset)=["']([^"']+)["']/gi;
    for (const match of String(html || "").matchAll(pattern)) {
        const candidates = match[1].split(",").map((item) => item.trim().split(/\\s+/)[0]);
        for (const candidate of candidates) {
            const url = absolutePublicUrl(candidate, baseUrl);
            if (url && !assets.includes(url.href)) assets.push(url.href);
        }
    }
    return assets.slice(0, 150);
}

async function crawlAdditionalPages(homeHtml, targetUrl) {
    const base = new URL(targetUrl);
    const queue = extractImportLinks(homeHtml, base).slice(0, LIMITS.crawlPages - 1);
    const pages = [{ url: base.href, html: homeHtml, status: 200 }];
    let totalBytes = Buffer.byteLength(homeHtml, "utf8");

    for (const pageUrl of queue) {
        if (pages.length >= LIMITS.crawlPages || totalBytes >= LIMITS.crawlTotalBytes) break;
        if (!(await isSafeTarget(pageUrl))) continue;
        let request;
        try {
            request = await fetchWithTimeout(pageUrl);
            if (!request.webResponse.ok) {
                await discardResponseBody(request.webResponse);
                continue;
            }
            const contentType = (request.webResponse.headers.get("content-type") || "").toLowerCase();
            if (contentType && !contentType.includes("text/html") && !contentType.includes("application/xhtml+xml")) {
                await discardResponseBody(request.webResponse);
                continue;
            }
            const html = await readHtml(request.webResponse);
            const bytes = Buffer.byteLength(html, "utf8");
            if (!html.trim() || bytes > LIMITS.crawlPageBytes || totalBytes + bytes > LIMITS.crawlTotalBytes) continue;
            pages.push({ url: pageUrl.href, html, status: 200 });
            totalBytes += bytes;
        } catch {
            // A failed secondary page should not discard a usable homepage import.
        } finally {
            if (request) clearTimeout(request.timer);
        }
    }

    return {
        pages,
        assets: [...new Set(pages.flatMap((page) => extractPublicAssets(page.html, page.url)))].slice(0, 150),
        totalBytes
    };
}

exports.handler = async function handler(event = {}) {
    const method = String(event.httpMethod || "").toUpperCase();

    if (method !== "GET" && method !== "POST") {
        return response(
            405,
            { error: "Only GET and POST requests are supported." },
            { Allow: "GET, POST" }
        );
    }

    const targetUrl = extractTargetUrl(event);

    if (!targetUrl || !(await isSafeTarget(targetUrl))) {
        return response(400, {
            error: "Provide a valid public HTTP or HTTPS website URL."
        });
    }

    // ScrapingBee is the required provider. The target is validated locally
    // before its URL is sent to ScrapingBee; no direct-fetch fallback is used.
    const currentUrl = targetUrl;

    try {
        for (
            let redirectCount = 0;
            redirectCount <= LIMITS.redirects;
            redirectCount += 1
        ) {
            const request = await fetchWithTimeout(currentUrl);
            const webResponse = request.webResponse;

            try {
                // ScrapingBee follows target redirects internally.
                if (!webResponse.ok) {
                    const providerDetail = request.viaScrapingBee
                        ? await readProviderError(webResponse)
                        : "";

                    if (request.viaScrapingBee) {
                        const providerMessages = {
                            400: "ScrapingBee rejected the request parameters. Verify the target URL and provider configuration.",
                            401: "ScrapingBee rejected the API key. Verify SCRAPINGBEE_API_KEY in the deployed Netlify environment.",
                            402: "ScrapingBee account credits or subscription access are unavailable.",
                            403: "ScrapingBee denied the request. Verify the API key, account permissions, and provider quota.",
                            429: "ScrapingBee rate-limited the request. Check the provider quota and try again later."
                        };
                        const providerMessage = providerMessages[webResponse.status];

                        if (providerMessage) {
                            return response(502, {
                                error: `${providerMessage} (HTTP ${webResponse.status}).${providerDetail ? ` Provider response: ${providerDetail}` : ""}`
                            });
                        }
                    }

                    if ([401, 403].includes(webResponse.status)) {
                        return response(502, {
                            error:
                                "The target website requires authentication or blocks automated requests (HTTP " +
                                webResponse.status + "). Try a public URL or import the page source instead."
                        });
                    }

                    if (webResponse.status === 429) {
                        const retryAfter = webResponse.headers.get("retry-after");
                        const headers = /^\d+$/.test(String(retryAfter || "").trim())
                            ? { "Retry-After": String(retryAfter).trim() }
                            : {};

                        return response(502, {
                            error:
                                "The target website is rate-limiting automated requests (HTTP 429). Try again later or import the page source instead."
                        }, headers);
                    }

                    const providerHint = request.viaScrapingBee
                        ? " Check SCRAPINGBEE_API_KEY and the provider request quota."
                        : "";

                    return response(502, {
                        error:
                            "Failed to fetch target site. Server returned status: " +
                            webResponse.status +
                            "." +
                            providerHint +
                            (providerDetail ? ` Provider response: ${providerDetail}` : "")
                    });
                }

                const contentType = (
                    webResponse.headers.get("content-type") || ""
                ).toLowerCase();

                if (
                    contentType &&
                    !contentType.includes("text/html") &&
                    !contentType.includes("application/xhtml+xml")
                ) {
                    await discardResponseBody(webResponse);

                    return response(415, {
                        error: "The target URL did not return an HTML document."
                    });
                }

                const contents = await readHtml(webResponse);

                if (!contents.trim()) {
                    return response(422, {
                        error: "The target website returned empty content."
                    });
                }

                const imported = await crawlAdditionalPages(contents, currentUrl);
                const combinedHtml = imported.pages
                    .map((page) => `<!-- Imported page: ${page.url} -->\\n${page.html}`)
                    .join("\\n");
                const analysis = analyzeHtml(combinedHtml);
                const environmentVariables = [
                    { name: "SCRAPINGBEE_API_KEY", required: true, reason: "Public website rendering and controlled page import." }
                ];
                if (analysis.forms) environmentVariables.push({ name: "SUPABASE_URL", required: false, reason: "Optional lead storage for generated contact forms." }, { name: "SUPABASE_ANON_KEY", required: false, reason: "Optional browser-safe Supabase client access." });
                if (analysis.bookingLinks) environmentVariables.push({ name: "BOOKING_URL", required: false, reason: "Detected booking or appointment action; provide the client’s approved booking destination." });
                if (analysis.contact.emails.length) environmentVariables.push({ name: "RESEND_API_KEY", required: false, reason: "Optional transactional email delivery for form notifications." });

                return response(200, {
                    success: true,
                    contents,
                    pages: imported.pages,
                    assets: imported.assets,
                    import: {
                        sourceUrl: targetUrl.href,
                        pageCount: imported.pages.length,
                        assetCount: imported.assets.length,
                        totalBytes: imported.totalBytes,
                        environmentVariables,
                        limits: {
                            maxPages: LIMITS.crawlPages,
                            maxPageBytes: LIMITS.crawlPageBytes,
                            maxTotalBytes: LIMITS.crawlTotalBytes
                        }
                    },
                    analysis
                });
            } finally {
                clearTimeout(request.timer);
            }
        }

        return redirectResponse(
            "The target website could not be reached safely."
        );
    } catch (error) {
        console.error("Scraper function failed:", error?.message || error);

        if (error?.message === "SCRAPINGBEE_NOT_CONFIGURED") {
            return response(503, {
                error: "ScrapingBee is not configured. Add SCRAPINGBEE_API_KEY to the deployed Netlify environment, then redeploy."
            });
        }

        if (error?.name === "AbortError") {
            return response(504, {
                error: "The ScrapingBee request timed out. Check the provider quota and try again."
            });
        }

        if (error?.cause?.code === "ENOTFOUND" || error?.code === "ENOTFOUND") {
            return response(502, {
                error: "The scraping provider could not be reached. Verify ScrapingBee availability and try again."
            });
        }

        if (error?.message === "Failed to fetch") {
            return response(502, {
                error: "The scraping provider request failed before receiving a response. Verify the deployed environment and try again."
            });
        }

        if (error?.message === "TOO_LARGE") {
            return response(413, {
                error: "The target website returned too much content."
            });
        }

        if (error?.message === "INVALID_CONTENT_LENGTH") {
            return response(502, {
                error: "The target website returned an invalid response."
            });
        }

        return response(502, {
            error: `The scraper could not fetch the website. ${error?.message || "The provider returned an unexpected error."}`.slice(0, 500)
        });
    }
};