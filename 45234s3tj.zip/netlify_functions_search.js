"use strict";

const { providerClient, requestId } = require("./netlify/functions/provider-adapters.js");

const SEARCH_ENDPOINT = "https://api.search.brave.com/res/v1/web/search";

const LIMITS = Object.freeze({
    query: 300,
    providerResponse: 2_000_000,
    errorResponse: 16_384,
    results: 100,
    timeoutMs: 12_000
});

const HTTP_PROTOCOLS = new Set(["http:", "https:"]);
const VALID_PORTS = new Set(["", "80", "443"]);
const AUTH_FAILURES = new Set([401, 403]);

const JSON_HEADERS = Object.freeze({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
});

const response = (statusCode, payload, cacheControl = "no-store") => ({
    statusCode,
    headers: {
        ...JSON_HEADERS,
        "Cache-Control": cacheControl
    },
    body: JSON.stringify(payload)
});

function normalizeQuery(value) {
    const query = Array.isArray(value) ? value[0] : value;

    return String(query || "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, LIMITS.query);
}

function isValidIpv4(hostname) {
    const parts = hostname.split(".");

    return (
        parts.length === 4 &&
        parts.every(
            (part) =>
                /^\d{1,3}$/.test(part) &&
                Number(part) >= 0 &&
                Number(part) <= 255
        )
    );
}

function isPrivateIpv4(hostname) {
    if (!isValidIpv4(hostname)) return false;

    const [a, b, c] = hostname.split(".").map(Number);

    return (
        a === 0 ||
        a === 10 ||
        a === 127 ||
        (a === 100 && b >= 64 && b <= 127) ||
        (a === 169 && b === 254) ||
        (a === 172 && b >= 16 && b <= 31) ||
        (a === 192 && b === 0 && (c === 0 || c === 2)) ||
        (a === 192 && b === 168) ||
        (a === 198 && (b === 18 || b === 19)) ||
        (a === 198 && b === 51 && c === 100) ||
        (a === 203 && b === 0 && c === 113) ||
        a >= 224
    );
}

function expandIpv6(value) {
    const normalized = value.toLowerCase().replace(/^\[|\]$/g, "");

    if (!normalized || normalized.includes(":::")) return null;

    const halves = normalized.split("::");

    if (halves.length > 2) return null;

    const parseHalf = (half) => {
        if (!half) return [];

        const parts = half.split(":");

        if (
            parts.some(
                (part) => !/^[0-9a-f]{1,4}$/.test(part)
            )
        ) {
            return null;
        }

        return parts.map((part) => parseInt(part, 16));
    };

    const left = parseHalf(halves[0]);

    if (!left) return null;

    const right = halves.length === 2 ? parseHalf(halves[1]) : [];

    if (!right) return null;

    if (halves.length === 1) {
        return left.length === 8 ? left : null;
    }

    const missing = 8 - left.length - right.length;

    if (missing < 1) return null;

    return [
        ...left,
        ...Array.from({ length: missing }, () => 0),
        ...right
    ];
}

function isPrivateIpv6(hostname) {
    const value = String(hostname || "")
        .toLowerCase()
        .replace(/^\[|\]$/g, "");

    // This helper is also called for ordinary DNS hostnames. Only treat a
    // value as IPv6 when it contains a colon; otherwise it must not block
    // normal search results such as example.com.
    if (!value.includes(":")) return false;

    const mappedIpv4Match = value.match(
        /^(?:.*:)(\d{1,3}(?:\.\d{1,3}){3})$/
    );

    if (mappedIpv4Match) {
        return isPrivateIpv4(mappedIpv4Match[1]);
    }

    const groups = expandIpv6(value);

    // Reject malformed IPv6 hostnames rather than allowing them through the
    // result filter. URL normally validates these, but provider data is
    // untrusted and should fail closed.
    if (!groups) return true;

    const first = groups[0];
    const second = groups[1];
    const isUnspecified = groups.every((group) => group === 0);
    const isIpv4Mapped = groups.slice(0, 5).every((group) => group === 0) && groups[5] === 0xffff;

    return (
        isUnspecified ||
        isIpv4Mapped ||
        (first & 0xfe00) === 0xfc00 ||
        (first >= 0xfe80 && first <= 0xfebf) ||
        first >= 0xff00 ||
        (first === 0 && second === 0)
    );
}

function isPrivateHostname(hostname) {
    const value = String(hostname || "")
        .toLowerCase()
        .replace(/\.$/, "");

    return (
        value === "localhost" ||
        value.endsWith(".localhost") ||
        value.endsWith(".local") ||
        value.endsWith(".internal") ||
        value === "metadata.google.internal" ||
        value === "metadata.google.com" ||
        /^\d+$/.test(value) ||
        isPrivateIpv4(value) ||
        isPrivateIpv6(value)
    );
}

function isSupportedResultUrl(value) {
    try {
        const url = new URL(String(value || "").trim());

        if (
            !HTTP_PROTOCOLS.has(url.protocol) ||
            !url.hostname ||
            url.username ||
            url.password ||
            !VALID_PORTS.has(url.port) ||
            isPrivateHostname(url.hostname)
        ) {
            return false;
        }

        return !/\.(?:pdf|zip|rar|7z|jpe?g|png|gif|webp|svg|mp4|mp3|docx?|xlsx?)$/i
            .test(url.pathname);
    } catch {
        return false;
    }
}

async function readLimitedText(responseObject, maximumBytes) {
    const rawLength = responseObject.headers.get("content-length");
    const declaredLength = rawLength === null ? 0 : Number(rawLength);

    if (
        rawLength !== null &&
        (!/^\d+$/.test(rawLength.trim()) || !Number.isSafeInteger(declaredLength) || declaredLength < 0)
    ) {
        throw new Error("Provider returned an invalid response length.");
    }

    if (declaredLength > maximumBytes) {
        throw new Error("Provider response exceeded the allowed size.");
    }

    if (
        !responseObject.body ||
        typeof responseObject.body.getReader !== "function"
    ) {
        const text = await responseObject.text();

        if (Buffer.byteLength(text, "utf8") > maximumBytes) {
            throw new Error("Provider response exceeded the allowed size.");
        }

        return text;
    }

    const reader = responseObject.body.getReader();
    const chunks = [];
    let totalBytes = 0;

    try {
        while (true) {
            const { done, value } = await reader.read();

            if (done) break;

            if (!value || typeof value.byteLength !== "number") {
                throw new Error("Provider returned an invalid response stream.");
            }

            totalBytes += value.byteLength;

            if (totalBytes > maximumBytes) {
                await reader.cancel();
                throw new Error("Provider response exceeded the allowed size.");
            }

            chunks.push(Buffer.from(value));
        }
    } finally {
        reader.releaseLock();
    }

    return Buffer.concat(chunks, totalBytes).toString("utf8");
}

function createTimeout() {
    const controller = new AbortController();
    const timer = setTimeout(
        () => controller.abort(),
        LIMITS.timeoutMs
    );

    return { controller, timer };
}

function mapResults(data) {
    const items = Array.isArray(data?.web?.results)
        ? data.web.results
        : [];

    return items
        .map((item) => ({
            url: String(item?.url || "").trim().slice(0, 2048),
            title: String(item?.title || "").trim().slice(0, 300),
            description: String(item?.description || "").trim().slice(0, 1000)
        }))
        .filter((item) => isSupportedResultUrl(item.url))
        .slice(0, LIMITS.results);
}

exports.handler = async function handler(event = {}) {
    if (String(event.httpMethod || "GET").toUpperCase() !== "GET") {
        return response(405, {
            error: "Only GET requests are supported."
        });
    }

    const query = normalizeQuery(event.queryStringParameters?.q);

    if (!query) {
        return response(400, {
            error: "A search query is required."
        });
    }

    const apiKey = String(process.env.BRAVE_SEARCH_API_KEY || "").trim();

    if (!apiKey) {
        console.error("Missing BRAVE_SEARCH_API_KEY environment variable.");

        return response(503, {
            error: "Search is not configured because BRAVE_SEARCH_API_KEY is missing from the deployed environment. Add it in Netlify site settings and redeploy."
        });
    }

    const endpoint = new URL(SEARCH_ENDPOINT);
    endpoint.searchParams.set("q", query);
    endpoint.searchParams.set("count", String(Math.min(LIMITS.results, 100)));
    endpoint.searchParams.set("safesearch", "moderate");

    const timeout = createTimeout();

    try {
        const client = providerClient("brave-search", {
            endpoint: "https://api.search.brave.com",
            timeoutMs: LIMITS.timeoutMs,
            retries: 1,
            requestId: requestId(event)
        });
        const providerResult = await client.request(`${endpoint.pathname}${endpoint.search}`, {
            method: "GET",
            signal: timeout.controller.signal,
            raw: true,
            headers: {
                Accept: "application/json",
                "User-Agent": "WebsiteGenerationEngine/1.0",
                "X-Subscription-Token": apiKey
            }
        });
        const providerResponse = providerResult.response || providerResult;

        if (!providerResponse.ok) {
            const details = await readLimitedText(
                providerResponse,
                LIMITS.errorResponse
            );

            console.error(
                "Brave Search error:",
                providerResponse.status,
                details.slice(0, 500)
            );

            if (AUTH_FAILURES.has(providerResponse.status)) {
                return response(502, {
                    error: `Brave Search rejected the API key (HTTP ${providerResponse.status}). Verify BRAVE_SEARCH_API_KEY and redeploy.`
                });
            }

            if (providerResponse.status === 429) {
                return response(429, {
                    error: "Brave Search rate limit reached. Try again later."
                });
            }

            return response(502, {
                error: `Brave Search returned HTTP ${providerResponse.status}.`
            });
        }

        const body = await readLimitedText(
            providerResponse,
            LIMITS.providerResponse
        );

        let data;

        try {
            data = JSON.parse(body);
        } catch {
            return response(502, {
                error: "Brave Search returned an invalid response."
            });
        }

        return response(
            200,
            { results: mapResults(data) },
            "public, max-age=300, stale-while-revalidate=600"
        );
    } catch (error) {
        if (error?.name === "AbortError") {
            console.error("Brave Search request timed out.");

            return response(504, {
                error: "Search timed out. Use the public website URL instead."
            });
        }

        if (error?.message?.includes("exceeded the allowed size")) {
            console.error("Brave Search response was too large.");

            return response(502, {
                error: "Brave Search returned an oversized response."
            });
        }

        console.error("Brave Search function failed:", error);

        return response(502, {
            error: `The search provider could not be reached. ${error?.message || "Check the deployed function and provider configuration."}`.slice(0, 500)
        });
    } finally {
        clearTimeout(timeout.timer);
    }
};