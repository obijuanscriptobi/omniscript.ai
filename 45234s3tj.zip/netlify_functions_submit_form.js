"use strict";

const crypto = require("node:crypto");
const net = require("node:net");
const { TextDecoder } = require("node:util");
const { providerClient, requestId } = require("./netlify/functions/provider-adapters.js");

const MAX_BODY_LENGTH = 20_000;
const MAX_RETRIES = 2;
const WEBHOOK_TIMEOUT_MS = 8_000;
const DUPLICATE_WINDOW_MS = 5 * 60 * 1000;
const MAX_DUPLICATE_KEYS = 2_000;
const MAX_SUBMISSION_ID_LENGTH = 128;

const recentSubmissions = new Map();

const JSON_HEADERS = Object.freeze({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, max-age=0",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Cross-Origin-Resource-Policy": "same-origin",
    "X-Permitted-Cross-Domain-Policies": "none"
});

function result(statusCode, payload, extraHeaders = {}) {
    const configuredHeaders =
        extraHeaders && typeof extraHeaders === "object" && !Array.isArray(extraHeaders)
            ? extraHeaders
            : {};
    const protectedNames = new Set(
        Object.keys(JSON_HEADERS).map((name) => name.toLowerCase())
    );
    const additionalHeaders = {};

    for (const [name, value] of Object.entries(configuredHeaders)) {
        if (!protectedNames.has(String(name).toLowerCase())) {
            additionalHeaders[name] = value;
        }
    }

    return {
        statusCode,
        isBase64Encoded: false,
        headers: {
            ...additionalHeaders,
            ...JSON_HEADERS
        },
        body: JSON.stringify(payload)
    };
}

function clean(value, maximum = 500) {
    if (typeof value !== "string" && typeof value !== "number") {
        return "";
    }

    return String(value)
        .replace(/[\u0000-\u001F\u007F]/g, "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, maximum);
}

function getHeader(event = {}, name) {
    const source = event.headers || {};
    const target = String(name).toLowerCase();

    for (const [key, value] of Object.entries(source)) {
        if (String(key).toLowerCase() === target) {
            return String(value ?? "").slice(0, 500);
        }
    }

    return "";
}

function decodeUtf8(buffer) {
    try {
        return new TextDecoder("utf-8", { fatal: true }).decode(buffer);
    } catch {
        throw new Error("INVALID_BODY");
    }
}

function decodeBody(event = {}) {
    const encodedBody = String(event.body || "");

    if (!event.isBase64Encoded) {
        return Buffer.from(encodedBody, "utf8");
    }

    if (
        !encodedBody ||
        encodedBody.length % 4 !== 0 ||
        !/^[A-Za-z0-9+/]*={0,2}$/.test(encodedBody)
    ) {
        throw new Error("INVALID_BODY");
    }

    let decoded;

    try {
        decoded = Buffer.from(encodedBody, "base64");
    } catch {
        throw new Error("INVALID_BODY");
    }

    const canonicalInput = encodedBody.replace(/=+$/, "");
    const canonicalOutput = decoded
        .toString("base64")
        .replace(/=+$/, "");

    if (
        !decoded.length ||
        canonicalInput !== canonicalOutput
    ) {
        throw new Error("INVALID_BODY");
    }

    decodeUtf8(decoded);

    return decoded;
}

function parseSubmission(event = {}) {
    const declaredLength = getHeader(event, "content-length");

    if (declaredLength) {
        if (!/^\d+$/.test(declaredLength)) {
            throw new Error("INVALID_BODY");
        }

        const length = Number(declaredLength);

        if (!Number.isSafeInteger(length) || length > MAX_BODY_LENGTH) {
            throw new Error("TOO_LARGE");
        }
    }

    const bodyBuffer = decodeBody(event);

    if (bodyBuffer.length > MAX_BODY_LENGTH) {
        throw new Error("TOO_LARGE");
    }

    const body = decodeUtf8(bodyBuffer);
    const contentType = getHeader(event, "content-type").toLowerCase();

    try {
        if (contentType.includes("application/json")) {
            const parsed = JSON.parse(body || "{}");

            if (
                !parsed ||
                typeof parsed !== "object" ||
                Array.isArray(parsed)
            ) {
                throw new Error("INVALID_BODY");
            }

            return parsed;
        }

        if (
            contentType.includes("application/x-www-form-urlencoded") ||
            !contentType
        ) {
            return Object.fromEntries(new URLSearchParams(body));
        }
    } catch {
        throw new Error("INVALID_BODY");
    }

    throw new Error("UNSUPPORTED_FORMAT");
}

function createSubmissionId(event = {}) {
    const supplied = clean(
        getHeader(event, "x-submission-id"),
        MAX_SUBMISSION_ID_LENGTH
    );

    if (
        supplied &&
        /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(supplied)
    ) {
        return supplied;
    }

    return crypto.randomUUID();
}

function allowedOrigin(event = {}) {
    const origin = getHeader(event, "origin");
    const referer = getHeader(event, "referer");
    const fetchSite = getHeader(event, "sec-fetch-site").toLowerCase();
    const configured = String(process.env.PUBLIC_SITE_ORIGIN || "").trim();

    if (["cross-site", "none"].includes(fetchSite)) return false;
    if (!configured) return false;

    let expected;
    try {
        expected = new URL(configured);
        if (expected.protocol !== "https:" || expected.username || expected.password || expected.search || expected.hash) return false;
    } catch {
        return false;
    }

    return [origin, referer].filter(Boolean).some((value) => {
        try {
            const actual = new URL(value);
            return actual.protocol === "https:" && actual.origin === expected.origin;
        } catch {
            return false;
        }
    });
}

function getClientKey(event = {}) {
    const candidates = [
        event.requestContext?.identity?.sourceIp,
        getHeader(event, "x-nf-client-connection-ip"),
        getHeader(event, "client-ip"),
        getHeader(event, "x-forwarded-for")
    ];

    const value = candidates
        .flatMap((candidate) => String(candidate || "").split(","))
        .map((candidate) => candidate.trim())
        .find(Boolean);

    return (value || "anonymous").slice(0, 100);
}

function cleanupDuplicateCache(now = Date.now()) {
    for (const [key, entry] of recentSubmissions) {
        if (now - entry.timestamp >= DUPLICATE_WINDOW_MS) {
            recentSubmissions.delete(key);
        }
    }

    while (recentSubmissions.size > MAX_DUPLICATE_KEYS) {
        recentSubmissions.delete(recentSubmissions.keys().next().value);
    }
}

function hashSubmission(submission, clientKey) {
    return crypto
        .createHash("sha256")
        .update(
            JSON.stringify({
                clientKey,
                name: submission.name,
                email: submission.email.toLowerCase(),
                phone: submission.phone,
                message: submission.message,
                company: submission.company
            })
        )
        .digest("hex");
}

function reserveSubmission(submission, event, submissionId) {
    cleanupDuplicateCache();

    const clientKey = getClientKey(event);
    const fingerprint = hashSubmission(submission, clientKey);
    const keys = [
        `id:${clientKey}:${submissionId}`,
        `fingerprint:${fingerprint}`
    ];

    if (keys.some((key) => recentSubmissions.has(key))) {
        return null;
    }

    const timestamp = Date.now();

    keys.forEach((key) => {
        recentSubmissions.set(key, {
            timestamp,
            keys
        });
    });

    cleanupDuplicateCache();

    return keys;
}

function releaseSubmission(keys) {
    if (!Array.isArray(keys)) return;

    keys.forEach((key) => {
        recentSubmissions.delete(key);
    });
}

function getAllowedWebhookHosts() {
    return String(process.env.LEADS_WEBHOOK_HOSTS || "")
        .split(",")
        .map((host) => host.trim().toLowerCase().replace(/\.$/, ""))
        .filter((host) => {
            if (host.length > 253 || host.startsWith(".") || host.endsWith(".")) {
                return false;
            }

            return host
                .split(".")
                .every(
                    (label) =>
                        label.length > 0 &&
                        label.length <= 63 &&
                        /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label)
                );
        });
}

function isPrivateWebhookHostname(hostname) {
    const value = String(hostname || "")
        .toLowerCase()
        .replace(/\.$/, "");

    if (
        value === "localhost" ||
        value.endsWith(".localhost") ||
        value.endsWith(".local") ||
        value.endsWith(".internal") ||
        value === "metadata.google.internal" ||
        value === "metadata.google.com"
    ) {
        return true;
    }

    const address = value.replace(/^\[|\]$/g, "");
    const version = net.isIP(address);

    if (version === 4) {
        const [a, b, c] = address.split(".").map(Number);

        return (
            a === 0 ||
            a === 10 ||
            a === 127 ||
            (a === 100 && b >= 64 && b <= 127) ||
            (a === 169 && b === 254) ||
            (a === 172 && b >= 16 && b <= 31) ||
            (a === 192 && b === 0) ||
            (a === 192 && b === 168) ||
            (a === 198 && b >= 18 && b <= 19) ||
            (a === 198 && b === 51 && c === 100) ||
            (a === 203 && b === 0 && c === 113) ||
            a >= 224
        );
    }

    if (version === 6) {
        return (
            address === "::" ||
            address === "::1" ||
            address.startsWith("fc") ||
            address.startsWith("fd") ||
            address.startsWith("fe8") ||
            address.startsWith("fe9") ||
            address.startsWith("fea") ||
            address.startsWith("feb") ||
            address.startsWith("ff") ||
            address.startsWith("::ffff:192.168.") ||
            address.startsWith("::ffff:10.") ||
            address.startsWith("::ffff:127.")
        );
    }

    return false;
}

function getWebhookUrl() {
    const value = String(process.env.LEADS_WEBHOOK_URL || "").trim();

    if (!value) {
        throw new Error("WEBHOOK_NOT_CONFIGURED");
    }

    let webhookUrl;

    try {
        webhookUrl = new URL(value);
    } catch {
        throw new Error("WEBHOOK_INVALID");
    }

    const hostname = webhookUrl.hostname.toLowerCase();
    const allowedHosts = getAllowedWebhookHosts();

    if (
        webhookUrl.protocol !== "https:" ||
        webhookUrl.username ||
        webhookUrl.password ||
        webhookUrl.port ||
        hostname.length > 253 ||
        isPrivateWebhookHostname(hostname) ||
        !allowedHosts.includes(hostname)
    ) {
        throw new Error("WEBHOOK_NOT_ALLOWED");
    }

    return webhookUrl;
}

function validateSubmission(parsed) {
    const submission = {
        name: clean(parsed.name, 200),
        email: clean(parsed.email, 320),
        phone: clean(parsed.phone, 80),
        message: clean(parsed.message, 2_000),
        company: clean(parsed.company, 200),
        website: clean(parsed.website, 200),
        source: clean(parsed.source, 180) || "website",
        campaign: clean(parsed.campaign, 180),
        projectId: clean(parsed.projectId, 80)
    };

    if (
        submission.email &&
        !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(submission.email)
    ) {
        throw new Error("INVALID_EMAIL");
    }

    if (
        !submission.name &&
        !submission.email &&
        !submission.phone &&
        !submission.message
    ) {
        throw new Error("EMPTY_SUBMISSION");
    }

    return submission;
}

function isRetryableWebhookStatus(status) {
    return (
        status === 408 ||
        status === 425 ||
        status === 429 ||
        status >= 500
    );
}

function escapeEmail(value) {
    return clean(value, 2_000)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

async function notifyOwner(submission, submissionId) {
    const apiKey = String(process.env.RESEND_API_KEY || "").trim();
    const from = String(process.env.INVITATION_FROM_EMAIL || "").trim();
    const to = String(process.env.LEADS_NOTIFY_EMAIL || "").trim();
    if (!apiKey || !from || !to) return false;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(from) || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(to)) return false;

    try {
        const client = providerClient("resend", {
            endpoint: "https://api.resend.com",
            retries: 0,
            timeoutMs: 8_000,
            requestId: submissionId
        });
        const name = escapeEmail(submission.name) || "A visitor";
        const email = escapeEmail(submission.email) || "not provided";
        const phone = escapeEmail(submission.phone) || "not provided";
        const message = escapeEmail(submission.message) || "No message included.";
        const upstream = await client.request("/emails", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${apiKey}`,
                "Content-Type": "application/json"
            },
            raw: true,
            body: JSON.stringify({
                from,
                to: [to],
                subject: `New website enquiry from ${clean(submission.name || "a visitor", 80)}`,
                html: `<p>${name} sent an enquiry from your website.</p><p>Email: ${email}<br>Phone: ${phone}</p><p>${message}</p><p style="color:#66717c;font-size:12px">Submission ${escapeEmail(submissionId)}</p>`
            })
        });
        const status = upstream?.response?.status || upstream?.status;
        return Number(status) >= 200 && Number(status) < 300;
    } catch (error) {
        console.error("Owner enquiry email failed:", error?.message || error);
        return false;
    }
}

async function persistLead(submission) {
    const projectId = submission.projectId;
    const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    if (!projectId || !uuid.test(projectId)) return false;

    const rawUrl = String(process.env.SUPABASE_URL || "").trim();
    const key = String(process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
    if (!rawUrl || !key) return false;

    let baseUrl;
    try {
        const parsed = new URL(rawUrl);
        if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.port || parsed.pathname !== "/" || parsed.search || parsed.hash || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.supabase\.co$/i.test(parsed.hostname)) return false;
        baseUrl = parsed.origin;
    } catch {
        return false;
    }

    const client = providerClient("supabase", {
        endpoint: baseUrl,
        retries: 0,
        timeoutMs: 8_000,
        requestId: submission.projectId
    });
    const headers = {
        apikey: key,
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json"
    };
    let projects;
    try {
        projects = await client.request(`/rest/v1/projects?id=eq.${encodeURIComponent(projectId)}&select=id,user_id`, { headers });
    } catch (error) {
        console.error("Lead ownership lookup failed:", error?.message || error);
        return false;
    }
    const ownerId = Array.isArray(projects.data) ? projects.data[0]?.user_id : null;
    if (!uuid.test(String(ownerId || ""))) return false;

    try {
        await client.request("/rest/v1/leads", {
            method: "POST",
            headers: { ...headers, Prefer: "return=minimal" },
            body: JSON.stringify({ user_id: ownerId, project_id: projectId, name: submission.name, email: submission.email, phone: submission.phone, message: submission.message, source: submission.source, campaign: submission.campaign, status: "new" })
        });
        return true;
    } catch (error) {
        console.error("Lead persistence failed:", error?.message || error);
        return false;
    }
}

async function persistDeliveryFailure(submission, submissionId, error) {
    const projectId = submission.projectId;
    const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const rawUrl = String(process.env.SUPABASE_URL || "").trim();
    const key = String(process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
    if (!uuid.test(projectId) || !rawUrl || !key) return false;
    let baseUrl;
    try {
        const parsed = new URL(rawUrl);
        if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.port || parsed.pathname !== "/" || parsed.search || parsed.hash || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.supabase\.co$/i.test(parsed.hostname)) return false;
        baseUrl = parsed.origin;
    } catch { return false; }
    const headers = { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" };
    const client = providerClient("supabase", {
        endpoint: baseUrl,
        retries: 0,
        timeoutMs: 8_000,
        requestId: submissionId
    });
    let projects;
    try {
        projects = (await client.request(`/rest/v1/projects?id=eq.${encodeURIComponent(projectId)}&select=id,user_id`, { headers })).data;
    } catch {
        return false;
    }
    const userId = Array.isArray(projects) ? projects[0]?.user_id : "";
    if (!uuid.test(String(userId || ""))) return false;
    try {
        await client.request("/rest/v1/lead_delivery_failures", {
            method: "POST",
            headers: { ...headers, Prefer: "resolution=merge-duplicates,return=minimal" },
            body: JSON.stringify({ project_id: projectId, user_id: userId, submission_id: submissionId, payload: { name: submission.name, email: submission.email, phone: submission.phone, message: submission.message, source: submission.source, campaign: submission.campaign }, attempts: 1, status: "pending", last_error: clean(error?.message || "Delivery failed", 500), next_attempt_at: new Date(Date.now() + 60_000).toISOString() })
        });
        return true;
    } catch {
        return false;
    }
}

async function sendToWebhook(webhookUrl, submission, submissionId, providerRequest = null) {
    let lastError;

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
        const controller = new AbortController();
        const timer = setTimeout(
            () => controller.abort(),
            WEBHOOK_TIMEOUT_MS
        );

        try {
            const webhookResponse = providerRequest
                ? await providerRequest(webhookUrl, {
                    method: "POST",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        "Idempotency-Key": submissionId,
                        "X-Submission-ID": submissionId
                    },
                    body: JSON.stringify({
                        source: "website-contact-form",
                        submissionId,
                        name: submission.name,
                        email: submission.email,
                        phone: submission.phone,
                        company: submission.company,
                        message: submission.message,
                        source: submission.source,
                        campaign: submission.campaign,
                        projectId: submission.projectId,
                        receivedAt: new Date().toISOString()
                    }),
                    signal: controller.signal
                })
                : await fetch(webhookUrl, {
                    method: "POST",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        "Idempotency-Key": submissionId,
                        "X-Submission-ID": submissionId
                    },
                    body: JSON.stringify({
                        source: "website-contact-form",
                        submissionId,
                        name: submission.name,
                        email: submission.email,
                        phone: submission.phone,
                        company: submission.company,
                        message: submission.message,
                        source: submission.source,
                        campaign: submission.campaign,
                        projectId: submission.projectId,
                        receivedAt: new Date().toISOString()
                    }),
                    signal: controller.signal
                });

            if (webhookResponse.ok) return;
            lastError = Object.assign(new Error(`Webhook HTTP ${webhookResponse.status}`), { status: webhookResponse.status });

            if (!isRetryableWebhookStatus(webhookResponse.status) || attempt === MAX_RETRIES) {
                if (isRetryableWebhookStatus(webhookResponse.status)) lastError.retryable = true;
                throw lastError;
            }
        } catch (error) {
            lastError = error;

            const isTimeout = error?.name === "AbortError";
            const isNetworkError =
                !(error instanceof Error) ||
                !/^Webhook HTTP \d+$/.test(error.message);

            const isRetryableHttpError =
                /^Webhook HTTP (408|425|429|5\d\d)$/.test(
                    error?.message || ""
                );

            if (
                attempt === MAX_RETRIES ||
                (!isTimeout && !isNetworkError && !isRetryableHttpError)
            ) {
                if (isTimeout || isNetworkError || isRetryableHttpError) {
                    error.retryable = true;
                }
                throw error;
            }
        } finally {
            clearTimeout(timer);
        }

        await new Promise((resolve) =>
            setTimeout(resolve, 250 * 2 ** attempt)
        );
    }

    throw lastError || new Error("Webhook delivery failed.");
}

exports.handler = async function handler(event = {}) {
    if (String(event.httpMethod || "").toUpperCase() !== "POST") {
        return result(
            405,
            {
                success: false,
                error: "Only POST requests are supported."
            },
            { Allow: "POST" }
        );
    }

    let reservationKeys = null;

    if (!allowedOrigin(event)) {
        return result(403, {
            success: false,
            error: "Origin is not allowed."
        });
    }

    try {
        const parsed = parseSubmission(event);
        const submission = validateSubmission(parsed);
        const submissionId = createSubmissionId(event);

        if (submission.website) {
            return result(200, {
                success: true,
                message: "Thanks. Your message was received."
            });
        }

        reservationKeys = reserveSubmission(
            submission,
            event,
            submissionId
        );

        if (!reservationKeys) {
            return result(200, {
                success: true,
                message: "Thanks. Your message was received.",
                submissionId
            });
        }

        let webhookDelivered = false;
        let deliveryError = null;
        if (String(process.env.LEADS_WEBHOOK_URL || "").trim()) {
            try {
                const webhookUrl = getWebhookUrl();
                const webhookClient = providerClient("webhook", {
                    retries: 0,
                    timeoutMs: WEBHOOK_TIMEOUT_MS,
                    requestId: requestId(event)
                });
                const providerRequest = async (url, options) => {
                    try {
                        const upstream = await webhookClient.request(url, options);
                        return { ok: true, status: upstream.status };
                    } catch (error) {
                        return { ok: false, status: error.status || 502 };
                    }
                };
                await sendToWebhook(webhookUrl, submission, submissionId, providerRequest);
                webhookDelivered = true;
            } catch (error) {
                deliveryError = error;
                console.error("Lead webhook delivery failed; attempting durable persistence.", error?.message || error);
                await persistDeliveryFailure(submission, submissionId, error).catch((persistenceError) => console.error("Durable delivery queue unavailable.", persistenceError?.message || persistenceError));
            }
        }
        const persisted = await persistLead(submission);
        const emailed = await notifyOwner(submission, submissionId);
        if (!webhookDelivered && !persisted && !emailed) throw deliveryError || new Error("WEBHOOK_NOT_CONFIGURED");
        if (deliveryError && (persisted || emailed)) {
            return result(202, { success: true, accepted: true, retryable: true, message: "Your enquiry was accepted and queued for delivery.", submissionId, leadPersisted: persisted, webhookDelivered: false, ownerNotified: emailed });
        }

        return result(200, {
            success: true,
            message: "Thanks. Your message was received.",
            submissionId,
            leadPersisted: persisted,
            webhookDelivered,
            ownerNotified: emailed
        });
    } catch (error) {
        releaseSubmission(reservationKeys);

        const code = error?.message;

        if (code === "TOO_LARGE") {
            return result(413, {
                success: false,
                error: "The submission is too large."
            });
        }

        if (code === "INVALID_BODY") {
            return result(400, {
                success: false,
                error: "The submission body is invalid."
            });
        }

        if (code === "UNSUPPORTED_FORMAT") {
            return result(415, {
                success: false,
                error: "Unsupported submission format."
            });
        }

        if (code === "INVALID_EMAIL") {
            return result(400, {
                success: false,
                error: "Please provide a valid email address."
            });
        }

        if (code === "EMPTY_SUBMISSION") {
            return result(400, {
                success: false,
                error: "Please provide contact information."
            });
        }

        if (code === "WEBHOOK_NOT_CONFIGURED") {
            console.error("Lead delivery is not configured.");

            return result(503, {
                success: false,
                error: "Lead delivery is not configured."
            });
        }

        if (
            code === "WEBHOOK_INVALID" ||
            code === "WEBHOOK_NOT_ALLOWED"
        ) {
            console.error("Lead webhook configuration is invalid.");

            return result(500, {
                success: false,
                error: "Lead delivery is not securely configured."
            });
        }

        if (error?.name === "AbortError") {
            console.error("Lead webhook timed out.");

            return result(504, {
                success: false,
                retryable: true,
                error: "Lead delivery timed out. Please try again."
            });
        }

        const retryable = Boolean(error?.retryable);
        console.error("Submit-form delivery failed:", code || "unknown error");

        return result(retryable ? 503 : 502, {
            success: false,
            retryable,
            error: retryable
                ? "Lead delivery is temporarily unavailable. Please try again."
                : "The message could not be delivered. Please try again."
        });
    }
};