"use strict";

// Adds the small production details visitors, browsers, crawlers, and security
// contacts expect from an established website. This stays outside the copy
// generator so it also works for imported or future generated projects.
(() => {
    const escapeHtml = (value) => String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

    const read = (html, expression, fallback = "") => String(html || "").match(expression)?.[1]?.trim() || fallback;
    const has = (html, pattern) => pattern.test(String(html || ""));

    function addHeadDetails(html, files) {
        let page = String(html || "");
        const title = read(page, /<title[^>]*>([\s\S]*?)<\/title>/i, "Official website");
        const description = read(page, /<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)["']/i, `Official website for ${title}.`);
        const canonical = read(page, /<link[^>]+rel=["'][^"']*canonical[^"']*[^>]+href=["']([^"']+)["']/i, "./index.html");
        const origin = (() => { try { return new URL(canonical).origin; } catch { return ""; } })();
        const additions = [];
        if (!has(page, /<meta[^>]+name=["']robots["']/i)) additions.push('<meta name="robots" content="index,follow">');
        if (!has(page, /<meta[^>]+name=["']theme-color["']/i)) additions.push('<meta name="theme-color" content="#17202a">');
        if (!has(page, /<meta[^>]+name=["']color-scheme["']/i)) additions.push('<meta name="color-scheme" content="light">');
        if (!has(page, /<meta[^>]+property=["']og:description["']/i)) additions.push(`<meta property="og:description" content="${escapeHtml(description)}">`);
        if (!has(page, /<meta[^>]+property=["']og:url["']/i)) additions.push(`<meta property="og:url" content="${escapeHtml(canonical)}">`);
        if (!has(page, /<meta[^>]+property=["']og:site_name["']/i)) additions.push(`<meta property="og:site_name" content="${escapeHtml(title.split(/[—|-]/)[0].trim())}">`);
        if (!has(page, /<meta[^>]+name=["']twitter:title["']/i)) additions.push(`<meta name="twitter:title" content="${escapeHtml(title)}">`);
        if (!has(page, /<meta[^>]+name=["']twitter:description["']/i)) additions.push(`<meta name="twitter:description" content="${escapeHtml(description)}">`);
        if (!has(page, /<link[^>]+rel=["'][^"']*manifest/i)) additions.push('<link rel="manifest" href="./site.webmanifest">');
        if (!has(page, /<link[^>]+rel=["'][^"']*(?:apple-touch-icon|icon)["']/i)) additions.push('<link rel="icon" href="./favicon.svg" type="image/svg+xml">');

        if (additions.length && /<\/head>/i.test(page)) page = page.replace(/<\/head>/i, `${additions.join("\n")}</head>`);

        if (!has(page, /application\/ld\+json/i)) {
            const name = read(page, /<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']*)["']/i, title);
            const structured = {
                "@context": "https://schema.org",
                "@type": "Organization",
                name,
                url: origin || canonical,
                description
            };
            page = page.replace(/<\/head>/i, `<script type="application/ld+json">${JSON.stringify(structured).replace(/<\//g, "<\\/")}</script></head>`);
        }
        return page;
    }

    function createManifest(indexHtml) {
        const title = read(indexHtml, /<title[^>]*>([\s\S]*?)<\/title>/i, "Official website");
        const name = title.split(/[—|-]/)[0].trim() || "Website";
        const theme = read(indexHtml, /<meta[^>]+name=["']theme-color["'][^>]+content=["']([^"']*)["']/i, "#17202a");
        return JSON.stringify({ name, short_name: name.slice(0, 32), start_url: "./index.html", display: "standalone", background_color: theme, theme_color: theme, icons: [{ src: "./favicon.svg", sizes: "any", type: "image/svg+xml", purpose: "any maskable" }] }, null, 2) + "\n";
    }

    function createNotFound(indexHtml) {
        const title = read(indexHtml, /<title[^>]*>([\s\S]*?)<\/title>/i, "Website");
        const name = escapeHtml(title.split(/[—|-]/)[0].trim() || "Website");
        const canonical = read(indexHtml, /<link[^>]+rel=["'][^"']*canonical[^"']*[^>]+href=["']([^"']+)["']/i, "./index.html");
        return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,follow"><meta name="description" content="Page not found on ${name}."><meta name="theme-color" content="#17202a"><title>Page not found — ${name}</title><link rel="canonical" href="${escapeHtml(canonical)}"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><link rel="manifest" href="./site.webmanifest"><link rel="stylesheet" href="./style.css"></head><body><main class="hero"><div class="hero-inner"><p class="eyebrow">${name}</p><h1>That page is not here.</h1><p class="hero-copy">The link may be outdated or the page may have moved.</p><a class="button" href="./index.html">Return to the homepage</a></div></main></body></html>\n`;
    }

    function createSecurityContact(indexHtml) {
        let origin = read(indexHtml, /<link[^>]+rel=["'][^"']*canonical[^"']*[^>]+href=["']([^"']+)["']/i, "");
        try { origin = new URL(origin).origin; } catch { origin = "https://example.com"; }
        return `# Security policy\n\nContact: ${origin}/\nPreferred-Languages: en\nCanonical: ${origin}/.well-known/security.txt\nPolicy: ${origin}/\nExpires: 2027-01-01T00:00:00.000Z\n`;
    }

    function enhance(files = {}) {
        const next = { ...files };
        const htmlPages = Object.keys(next).filter((name) => /\.html?$/i.test(name));
        htmlPages.forEach((name) => { next[name] = addHeadDetails(next[name], next); });
        const index = next["index.html"] || "";
        if (index) {
            if (!next["site.webmanifest"]) next["site.webmanifest"] = createManifest(index);
            if (!next["404.html"]) next["404.html"] = createNotFound(index);
            const canonical = read(index, /<link[^>]+rel=["'][^"']*canonical[^"']*[^>]+href=["']([^"']+)["']/i, "");
            try {
                if (new URL(canonical).protocol === "https:") {
                    if (!next["security.txt"]) next["security.txt"] = createSecurityContact(index);
                    if (!next[".well-known/security.txt"]) next[".well-known/security.txt"] = next["security.txt"];
                }
            } catch (_) {
                // Do not publish a fabricated security contact before a real domain is configured.
            }
        }
        return next;
    }

    function install() {
        const generator = window.siteGenerator;
        if (!generator || typeof generator.createProject !== "function" || generator.__officialDetailsInstalled) return;
        const original = generator.createProject.bind(generator);
        generator.createProject = (options = {}) => enhance(original(options));
        Object.defineProperty(generator, "__officialDetailsInstalled", { value: true, configurable: false });
    }

    install();
    window.addEventListener("workspace:core-ready", install, { once: true });
    window.officialSiteDetails = Object.freeze({ enhance });
})();
