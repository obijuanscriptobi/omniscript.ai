"use strict";

(() => {
    if (window.__workspaceOnboardingInitialized) return;
    window.__workspaceOnboardingInitialized = true;
    window.__workspaceOnboardingInitCount = (window.__workspaceOnboardingInitCount || 0) + 1;

    const guide = document.getElementById("getting-started-panel");
    const secondaryColor = document.getElementById("input-biz-secondary-color");
    const secondaryColorHelp = document.getElementById("secondary-color-help");
    const advancedTools = document.getElementById("advanced-workspace-tools");
    const advancedToggle = document.getElementById("show-advanced-tools-btn");
    const compileButton = document.getElementById("compile-pipeline-btn");
    const primaryCreateButton = document.getElementById("primary-create-website-btn");

    secondaryColor?.addEventListener("input", () => {
        if (secondaryColorHelp) secondaryColorHelp.textContent = secondaryColor.value;
    });

    const setAdvancedVisibility = (visible) => {
        if (advancedTools) advancedTools.hidden = !visible;
        advancedToggle?.setAttribute("aria-expanded", String(visible));
        if (advancedToggle) advancedToggle.textContent = visible ? "Hide options" : "More options";
    };

    advancedToggle?.addEventListener("click", () => setAdvancedVisibility(Boolean(advancedTools?.hidden)));
    document.getElementById("preview-empty-action")?.addEventListener("click", () => {
        const panel = document.querySelector(".client-intake-panel:not([hidden]), .launch-brief-panel:not([hidden])")
            || document.getElementById("business-details");
        panel?.scrollIntoView({ behavior: "smooth", block: "center" });
        const field = panel?.querySelector("[data-brief-steps] > label:not([hidden]) input, [data-brief-steps] > label:not([hidden]) select, input:not([type='hidden']), select");
        field?.focus({ preventScroll: true });
    });
    document.getElementById("toggle-focus-mode-btn")?.addEventListener("click", (event) => {
        const button = event.currentTarget;
        const enabled = button.getAttribute("aria-pressed") !== "true";
        button.setAttribute("aria-pressed", String(enabled));
        document.body.classList.toggle("focus-mode", enabled);
        button.textContent = enabled ? "Exit focus" : "Focus mode";
    });
    if (compileButton) {
        compileButton.disabled = false;
        compileButton.removeAttribute("aria-disabled");
    }
    setAdvancedVisibility(false);

    if (!guide) return;

    const essentials = [
        ["input-biz-name", "Add your business name."],
        ["input-biz-hook", "Describe the result you help people achieve."],
        ["input-biz-services", "List your main services, separated by commas."],
        ["input-biz-location", "Add your primary city or service area."],
        ["input-biz-audience", "Name the audience you most want to attract."]
    ];
    const label = document.getElementById("onboarding-progress-label");
    const percent = document.getElementById("onboarding-progress-percent");
    const bar = document.getElementById("onboarding-progress-bar");
    const next = document.getElementById("onboarding-next-step");
    const wizardSteps = [
        { selector: "#business-details", summary: "Add the business name, result, service area, and audience that shape the first draft." },
        { selector: "#creative-direction-title", summary: "Choose the visual tone, content voice, and layout density." },
        { selector: "#previewContentIframe", summary: "Review the responsive preview, refine the message, and run launch checks." },
        { selector: "#workspace-status-title", summary: "Configure publishing, verify the technical launch path, and share with confidence." }
    ];
    let wizardIndex = 0;

    const updateWizard = () => {
        const summary = document.getElementById("guided-wizard-summary");
        const nextButton = document.getElementById("wizard-next-btn");
        const backButton = document.getElementById("wizard-back-btn");
        const step = wizardSteps[wizardIndex];
        if (summary) summary.textContent = step.summary;
        if (nextButton) nextButton.textContent = wizardIndex === wizardSteps.length - 1 ? "Open publish tools" : wizardIndex === 0 ? "Continue to style" : wizardIndex === 1 ? "Continue to review" : "Continue to publish";
        if (backButton) backButton.disabled = wizardIndex === 0;
        document.querySelectorAll(".creation-stage").forEach((stage, index) => {
            stage.classList.toggle("active", index === wizardIndex);
            if (index === wizardIndex) stage.setAttribute("aria-current", "step");
        });
    };

    const goToWizardStep = (index) => {
        wizardIndex = Math.max(0, Math.min(wizardSteps.length - 1, index));
        const target = document.querySelector(wizardSteps[wizardIndex].selector);
        if (wizardIndex === 1 || wizardIndex === 3) setAdvancedVisibility(true);
        target?.scrollIntoView({ behavior: "smooth", block: "center" });
        updateWizard();
    };

    const update = () => {
        const completedCount = essentials.filter(([id]) => document.getElementById(id)?.value.trim()).length;
        const value = Math.round((completedCount / essentials.length) * 100);
        if (label) label.textContent = `${completedCount} of ${essentials.length} essentials complete`;
        if (percent) percent.textContent = `${value}%`;
        if (bar) bar.style.width = `${value}%`;
        const complete = completedCount === essentials.length;
        const missing = essentials.find(([id]) => !document.getElementById(id)?.value.trim());
        if (next) next.textContent = complete
            ? "Brief complete — create the draft, then review the conversion path and launch checks."
            : missing?.[1] || "Start with your business name.";
        guide.classList.toggle("onboarding-complete", complete);
        if (primaryCreateButton) primaryCreateButton.textContent = complete ? "Create my website" : "Complete the brief first";
        document.querySelectorAll(".creation-stage").forEach((stage, index) => {
            const done = index === 0 ? completedCount > 0 : index === 1 ? completedCount === essentials.length : Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]);
            stage.classList.toggle("complete", done);
            stage.setAttribute("aria-current", done ? "step" : "false");
        });
    };

    essentials.forEach(([id]) => document.getElementById(id)?.addEventListener("input", update));
    document.getElementById("onboarding-create-btn")?.addEventListener("click", () => {
        const missing = essentials.find(([id]) => !document.getElementById(id)?.value.trim());
        const target = document.getElementById(missing?.[0] || "advanced-workspace-tools");
        if (!missing || target?.closest("#advanced-workspace-tools")) setAdvancedVisibility(true);
        target?.scrollIntoView({ behavior: "smooth", block: "center" });
        if (missing) document.getElementById(missing[0])?.focus({ preventScroll: true });
    });
    document.getElementById("onboarding-import-btn")?.addEventListener("click", () => {
        setAdvancedVisibility(true);
        const input = document.getElementById("input-scrape-url");
        input?.scrollIntoView({ behavior: "smooth", block: "center" });
        input?.focus({ preventScroll: true });
    });
    primaryCreateButton?.addEventListener("click", () => {
        const missing = essentials.find(([id]) => !document.getElementById(id)?.value.trim());
        if (missing) {
            const field = document.getElementById(missing[0]);
            field?.scrollIntoView({ behavior: "smooth", block: "center" });
            field?.focus({ preventScroll: true });
            update();
            return;
        }
        document.getElementById("compile-pipeline-btn")?.click();
    });
    document.querySelectorAll(".creation-stage").forEach((stage, index) => stage.addEventListener("click", (event) => {
        const target = document.querySelector(stage.getAttribute("href"));
        if (!target) return;
        event.preventDefault();
        goToWizardStep(index);
    }));
    document.getElementById("wizard-next-btn")?.addEventListener("click", () => goToWizardStep(wizardIndex + 1));
    document.getElementById("wizard-back-btn")?.addEventListener("click", () => goToWizardStep(wizardIndex - 1));
    document.getElementById("dismiss-onboarding-btn")?.addEventListener("click", () => {
        guide.hidden = true;
        try { localStorage.setItem("studio-onboarding-dismissed", "true"); } catch {}
    });
    try { guide.hidden = localStorage.getItem("studio-onboarding-dismissed") === "true"; } catch {}
    updateWizard();
    update();
})();
