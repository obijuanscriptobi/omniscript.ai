"use strict";

// One platform-wide audience choice. This controls defaults and presentation;
// it is not an authorization boundary.
(() => {
    if (window.operatingMode) return;
    const STORAGE_KEY = "omniscript-operating-mode-v1";
    const LEGACY_KEY = "morrow-creation-mode-v1";
    const SHOW_ALL_KEY = "omniscript-show-all-tools-v1";
    const PENDING_SYNC_KEY = "omniscript-preferences-pending-v1";
    const MODES = Object.freeze({
        self: Object.freeze({
            label: "My business",
            short: "My business",
            title: "Grow your business",
            description: "Build and grow one business you own."
        }),
        client: Object.freeze({
            label: "Client work",
            short: "Client work",
            title: "Manage client growth",
            description: "Build and manage websites, ads, leads, and campaigns for other businesses."
        })
    });
    const CAPABILITIES = Object.freeze({
        self: Object.freeze({
            responsiveWebsites: true, websiteMaintenance: true, ads: true,
            leads: true, tasks: true, mobileAudits: true, publishing: true,
            analytics: true, businessProfile: true, multipleBusinesses: false,
            clientImport: false, clientApprovals: false, reviewLinks: true,
            handoff: false, proposals: false, clientPortal: false,
            multiProjectReporting: false
        }),
        client: Object.freeze({
            responsiveWebsites: true, websiteMaintenance: true, ads: true,
            leads: true, tasks: true, mobileAudits: true, publishing: true,
            analytics: true, businessProfile: true, multipleBusinesses: true,
            clientImport: true, clientApprovals: true, reviewLinks: true,
            handoff: true, proposals: true, clientPortal: true,
            multiProjectReporting: true
        })
    });

    const subscribers = new Set();
    const normalize = (value) => value === "client" ? "client" : "self";
    const parseRecord = (raw) => {
        if (!raw) return null;
        try {
            const value = JSON.parse(raw);
            if (typeof value === "string") return { version: 1, mode: normalize(value), selectedAt: "", source: "migration" };
            if (value && typeof value === "object" && ["self", "own", "owner", "client"].includes(value.mode)) {
                return { version: 1, mode: normalize(value.mode === "client" ? "client" : "self"), selectedAt: value.selectedAt || "", source: value.source || "migration" };
            }
        } catch (_) {
            if (["self", "own", "owner", "client"].includes(raw)) return { version: 1, mode: normalize(raw), selectedAt: "", source: "migration" };
        }
        return null;
    };

    function readSaved() {
        try {
            const current = parseRecord(localStorage.getItem(STORAGE_KEY));
            if (current) return current;
            const legacyRaw = localStorage.getItem(LEGACY_KEY);
            const legacy = parseRecord(legacyRaw);
            if (legacy) {
                const migrated = { ...legacy, selectedAt: legacy.selectedAt || new Date().toISOString(), source: "migration" };
                localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));

                // Mode is account-level. Keep legacy client details separately as
                // project defaults so migration never discards project context.
                try {
                    const legacyDetails = JSON.parse(legacyRaw || "{}");
                    if (legacyDetails && typeof legacyDetails === "object" && (legacyDetails.contact || legacyDetails.note)) {
                        localStorage.setItem("omniscript-client-project-defaults-v1", JSON.stringify({
                            contact: String(legacyDetails.contact || ""),
                            note: String(legacyDetails.note || ""),
                            migratedAt: new Date().toISOString()
                        }));
                    }
                } catch (_) { /* A plain legacy mode still migrates correctly. */ }
                return migrated;
            }
        } catch (_) { /* Storage may be unavailable. */ }
        return null;
    }

    const queryMode = new URLSearchParams(location.search).get("mode");
    const temporaryMode = ["client", "self", "own", "owner"].includes(queryMode) ? normalize(queryMode) : "";
    let record = readSaved();
    let current = temporaryMode || record?.mode || "self";

    function getCapabilities(mode = current) { return { ...CAPABILITIES[normalize(mode)] }; }
    function isSelf() { return current === "self"; }
    function isClient() { return current === "client"; }
    function showAllTools() {
        try { return localStorage.getItem(SHOW_ALL_KEY) === "true"; }
        catch (_) { return false; }
    }

    function setShowAllTools(enabled, options = {}) {
        try { localStorage.setItem(SHOW_ALL_KEY, String(enabled === true)); } catch (_) {}
        apply();
        notify(current);
        if (options.source !== "storage") syncAccountRecord();
        return enabled === true;
    }

    function apply() {
        const capabilities = getCapabilities();
        document.documentElement.dataset.operatingMode = current;
        document.documentElement.dataset.modeSource = temporaryMode ? "query" : (record?.source || "default");
        document.documentElement.dataset.showAllTools = String(showAllTools());
        document.body?.setAttribute("data-operating-mode", current);
        document.body?.setAttribute("data-show-all-tools", String(showAllTools()));
        document.querySelectorAll("[data-capability]").forEach((node) => {
            const required = String(node.dataset.capability || "").split(/\s+/).filter(Boolean);
            const available = required.every((key) => capabilities[key] === true);
            node.hidden = !available && !showAllTools();
        });
        document.querySelectorAll("[data-mode-only]").forEach((node) => {
            const modes = String(node.dataset.modeOnly || "").split(/\s+/);
            node.hidden = !modes.includes(current) && !showAllTools();
        });
        document.querySelectorAll("[data-mode-choice]").forEach((button) => {
            const active = normalize(button.dataset.modeChoice) === current;
            button.setAttribute("aria-pressed", String(active));
            button.classList.toggle("active", active);
        });
        document.querySelectorAll("[data-mode-self-text][data-mode-client-text]").forEach((node) => {
            node.textContent = current === "client" ? node.dataset.modeClientText : node.dataset.modeSelfText;
        });
        document.querySelectorAll("[data-mode-self-placeholder][data-mode-client-placeholder]").forEach((node) => {
            node.setAttribute("placeholder", current === "client" ? node.dataset.modeClientPlaceholder : node.dataset.modeSelfPlaceholder);
        });
        const title = document.getElementById("operating-mode-title");
        const description = document.getElementById("operating-mode-description");
        if (title) title.textContent = MODES[current].title;
        if (description) description.textContent = MODES[current].description;

        const creationValue = isClient() ? "client" : "owner";
        const creationChoice = document.querySelector(`input[name="creation-mode"][value="${creationValue}"]`);
        if (creationChoice && !creationChoice.checked) {
            creationChoice.checked = true;
            creationChoice.dispatchEvent(new Event("change", { bubbles: true }));
        }

        const makerTitle = document.getElementById("configuration-title");
        if (makerTitle) makerTitle.textContent = isClient() ? "Create a client website" : "Create my website";
        const makerStatus = document.getElementById("creation-mode-status");
        if (makerStatus) makerStatus.textContent = isClient()
            ? "Client tools include public-site import, isolated project context, review, approval, and handoff."
            : "Your brief, website, ads, leads, tasks, publishing, and analytics stay focused on your business.";
        const homeEyebrow = document.querySelector(".home-hero-copy .home-eyebrow");
        const homeHeading = document.querySelector(".home-hero-copy h1");
        const homeIntro = document.querySelector(".home-hero-copy > p:not(.home-quote)");
        const homePrimaryAction = document.querySelector('.home-actions a[href="index.html"]');
        if (homeEyebrow) homeEyebrow.textContent = isClient() ? "A connected studio for client delivery" : "Trustworthy websites that drive action";
        if (homeHeading) homeHeading.textContent = isClient() ? "Turn client briefs into websites and campaigns you can sell." : "Turn your business into a clear path to growth.";
        if (homeIntro) homeIntro.textContent = isClient()
            ? "Build and maintain responsive client websites, campaigns, leads, tasks, approvals, and handoffs from one connected workspace."
            : "Create, launch, and improve a trustworthy business website while keeping your profile, campaigns, leads, tasks, and follow-up connected.";
        if (homePrimaryAction) homePrimaryAction.childNodes[0].nodeValue = isClient() ? "Create a client website " : "Create my website ";
    }

    function notify(previous) {
        const detail = { mode: current, previous, capabilities: getCapabilities(), ...MODES[current] };
        document.dispatchEvent(new CustomEvent("operating-mode:changed", { detail }));
        window.dispatchEvent(new CustomEvent("omniscript:operating-mode", { detail }));
        subscribers.forEach((callback) => { try { callback(detail); } catch (_) {} });
    }

    function set(mode, options = {}) {
        const next = normalize(mode);
        // A query-string mode is temporary. If it matches the requested mode but
        // differs from the saved record, still persist the explicit account choice.
        if (next === current && record?.mode === current) return true;
        if (window.workspaceContext?.prepareModeSwitch && next !== current && !window.workspaceContext.prepareModeSwitch(next)) return false;
        const previous = current;
        current = next;
        record = { version: 1, mode: current, selectedAt: new Date().toISOString(), source: options.source || "account" };
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(record)); } catch (_) {}
        apply();
        notify(previous);
        syncAccountRecord();
        return true;
    }

    function preferenceStatus(message, state = "ok") {
        const node = document.getElementById("account-mode-status");
        if (node) { node.textContent = message; node.dataset.state = state; }
        window.dispatchEvent(new CustomEvent("omniscript:preference-sync", { detail: { message, state } }));
    }

    async function syncAccountRecord() {
        const account = window.supabaseWorkspace;
        if (!record || !account?.getState?.().authenticated || !account.updatePreferences) return false;
        let pending = null;
        try { pending = JSON.parse(localStorage.getItem(PENDING_SYNC_KEY) || "null"); } catch (_) {}
        const payload = pending && typeof pending === "object"
            ? pending
            : { operatingMode: record, showAllTools: showAllTools(), selectedAt: record.selectedAt };
        preferenceStatus("Syncing workspace preferences…", "pending");
        try {
            await account.updatePreferences(payload);
            localStorage.removeItem(PENDING_SYNC_KEY);
            preferenceStatus("Workspace preferences saved across devices.", "synced");
            return true;
        } catch (_) {
            try { localStorage.setItem(PENDING_SYNC_KEY, JSON.stringify(payload)); } catch (_) {}
            preferenceStatus("Preferences are saved on this device; cloud sync is pending.", "warning");
            return false;
        }
    }

    async function hydrateAccountRecord() {
        const account = window.supabaseWorkspace;
        if (!account?.getState?.().authenticated) return;
        const cloud = account.getPreferences?.() || {};
        const cloudRecord = parseRecord(JSON.stringify(cloud.operatingMode || null));
        if (cloudRecord && (!record || Date.parse(cloudRecord.selectedAt || 0) > Date.parse(record.selectedAt || 0))) {
            const previous = current;
            record = cloudRecord;
            if (!temporaryMode) current = record.mode;
            try { localStorage.setItem(STORAGE_KEY, JSON.stringify(record)); } catch (_) {}
            if (typeof cloud.showAllTools === "boolean") {
                try { localStorage.setItem(SHOW_ALL_KEY, String(cloud.showAllTools)); } catch (_) {}
            }
            apply();
            notify(previous);
        } else await syncAccountRecord();
    }

    function syncPendingState() {
        let pending = false;
        try { pending = Boolean(localStorage.getItem(PENDING_SYNC_KEY)); } catch (_) {}
        if (typeof navigator !== "undefined" && navigator.onLine === false) {
            preferenceStatus(pending ? "Offline · preference changes are queued." : "Offline · preferences are stored on this device.", pending ? "pending" : "offline");
        } else if (pending) {
            preferenceStatus("Preference changes are waiting to sync.", "pending");
        }
    }

    function subscribe(callback) {
        if (typeof callback !== "function") return () => {};
        subscribers.add(callback);
        return () => subscribers.delete(callback);
    }

    function showFirstRun() {
        // A temporary URL override is sufficient intent for this visit, but it
        // must never become the saved account preference implicitly.
        if (record || temporaryMode || document.getElementById("operating-mode-onboarding")) return;
        const dialog = document.createElement("dialog");
        dialog.id = "operating-mode-onboarding";
        dialog.className = "operating-mode-onboarding";
        dialog.setAttribute("aria-labelledby", "operating-mode-onboarding-title");
        dialog.innerHTML = `<form method="dialog" class="operating-mode-onboarding-card"><p class="operating-mode-eyebrow">Set up your workspace</p><h2 id="operating-mode-onboarding-title">How will you use the studio?</h2><p class="operating-mode-intro">Choose once to personalize tools and defaults. You can change this later in Account without deleting any work.</p><div class="operating-mode-first-options"><button type="button" data-first-mode="self"><strong>For my business</strong><span>Build and grow one business I own.</span></button><button type="button" data-first-mode="client"><strong>For client work</strong><span>Build and manage websites, ads, leads, and campaigns for other businesses.</span></button></div></form>`;
        document.body.append(dialog);
        dialog.addEventListener("click", (event) => {
            const button = event.target.closest("[data-first-mode]");
            if (!button) return;
            set(button.dataset.firstMode, { source: "onboarding" });
            dialog.close();
            dialog.remove();
        });
        dialog.addEventListener("cancel", (event) => event.preventDefault());
        dialog.showModal();
    }

    function mount() {
        apply();
        showFirstRun();
        syncPendingState();
        window.addEventListener("supabase:authenticated", hydrateAccountRecord);
        window.addEventListener("online", () => { syncAccountRecord(); });
        window.addEventListener("offline", syncPendingState);
        window.addEventListener("storage", (event) => {
            if (event.key !== STORAGE_KEY && event.key !== SHOW_ALL_KEY) return;
            const previous = current;
            if (event.key === STORAGE_KEY) {
                const saved = parseRecord(event.newValue);
                // A URL override remains temporary for the lifetime of this page.
                // The saved account preference still updates for the next normal visit.
                if (saved) {
                    record = saved;
                    if (!temporaryMode) current = saved.mode;
                }
            }
            apply();
            if (previous !== current || event.key === SHOW_ALL_KEY) notify(previous);
        });
        window.dispatchEvent(new CustomEvent("omniscript:operating-mode-ready", { detail: { mode: current, capabilities: getCapabilities(), ...MODES[current] } }));
    }

    window.operatingMode = Object.freeze({
        get: () => current,
        getRecord: () => record ? { ...record } : null,
        set, isSelf, isClient, subscribe, getCapabilities, apply,
        getShowAllTools: showAllTools, setShowAllTools,
        modes: MODES, capabilities: CAPABILITIES, storageKey: STORAGE_KEY
    });
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount, { once: true });
    else mount();
})();
