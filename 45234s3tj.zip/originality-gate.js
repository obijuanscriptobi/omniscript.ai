"use strict";

// Originality is enforced with reproducible design decisions, not unbounded
// randomness. Visual features are derived from rendered pixels supplied by the
// preview/audit layer; this module never fetches or compares external websites.
(() => {
    const STORAGE_KEY = "workspace-originality-history-v1";
    const MAX_HISTORY = 30;
    const DEFAULT_THRESHOLD = 0.78;
    const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, Number(value) || 0));
    const object = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const text = (value, maximum = 120) => String(value ?? "").replace(/[<>\u0000-\u001f]/g, " ").trim().slice(0, maximum);
    const hash = (value) => {
        let result = 2166136261;
        for (const character of String(value)) { result ^= character.charCodeAt(0); result = Math.imul(result, 16777619); }
        return (result >>> 0).toString(36);
    };
    const componentKind = (id) => text(id).split("-")[0];

    function structuralFingerprint(plan = {}, components = {}) {
        const sections = Array.isArray(plan.sections) ? plan.sections : [];
        const sequence = sections.map((section) => section.component);
        const definitions = components.COMPONENTS || components;
        return Object.freeze({
            sequence,
            sectionCount: sequence.length,
            heroFamily: sequence.find((id) => definitions[id]?.kind === "hero") || "",
            gridGeometry: sequence.map((id) => definitions[id]?.geometry || componentKind(id)),
            ctaPositions: sections.map((section, index) => section?.content?.primaryAction ? index : -1).filter((index) => index >= 0),
            imagePlacement: sequence.filter((id) => /hero|gallery|product/.test(id)),
            hash: hash(sequence.join("|"))
        });
    }

    function stylisticFingerprint(design = {}) {
        const genome = object(design.genome);
        const value = {
            profile: text(design.profile), system: text(design.system), typography: text(design.typography || design.variant),
            palette: text(design.palette || design.system), spacing: text(genome.density), borders: text(genome.cards),
            alignment: text(genome.grid), motif: text(genome.motif), backgrounds: text(genome.rhythm),
            hero: text(genome.hero), navigation: text(genome.navigation), imagery: text(genome.imageTreatment), cta: text(genome.ctaPattern)
        };
        return Object.freeze({ ...value, hash: hash(Object.values(value).join("|")) });
    }

    function visualFingerprint(imageData, options = {}) {
        const data = imageData?.data || imageData;
        const width = Number(imageData?.width || options.width) || 0;
        const height = Number(imageData?.height || options.height) || 0;
        if (!data || !width || !height || data.length < width * height * 4) return null;
        const histogram = new Array(12).fill(0);
        const luminance = [];
        let edges = 0;
        let occupied = 0;
        const step = Math.max(1, Math.floor(Math.sqrt((width * height) / 4096)));
        for (let y = 0; y < height; y += step) {
            for (let x = 0; x < width; x += step) {
                const index = (y * width + x) * 4;
                const r = data[index], g = data[index + 1], b = data[index + 2], alpha = data[index + 3];
                const light = Math.round(.2126 * r + .7152 * g + .0722 * b);
                luminance.push(light);
                histogram[Math.min(3, r >> 6)] += 1; histogram[4 + Math.min(3, g >> 6)] += 1; histogram[8 + Math.min(3, b >> 6)] += 1;
                if (alpha > 20 && light < 242) occupied += 1;
                if (x >= step) {
                    const previous = index - step * 4;
                    const priorLight = .2126 * data[previous] + .7152 * data[previous + 1] + .0722 * data[previous + 2];
                    if (Math.abs(light - priorLight) > 36) edges += 1;
                }
            }
        }
        const average = luminance.reduce((sum, value) => sum + value, 0) / Math.max(1, luminance.length);
        const perceptualHash = luminance.filter((_, index) => index % Math.max(1, Math.floor(luminance.length / 64)) === 0).slice(0, 64).map((value) => value >= average ? "1" : "0").join("");
        const total = Math.max(1, luminance.length);
        return Object.freeze({ perceptualHash, colorHistogram: histogram.map((value) => Number((value / (total * 3)).toFixed(4))), edgeDensity: Number((edges / total).toFixed(4)), occupiedArea: Number((occupied / total).toFixed(4)), hash: hash(`${perceptualHash}|${histogram.join(",")}|${edges}|${occupied}`) });
    }

    const positionalSimilarity = (left = [], right = []) => {
        const length = Math.max(left.length, right.length, 1);
        let matches = 0;
        for (let index = 0; index < Math.min(left.length, right.length); index += 1) if (left[index] === right[index]) matches += 1;
        return matches / length;
    };
    const objectSimilarity = (left = {}, right = {}, ignored = new Set(["hash"])) => {
        const keys = [...new Set([...Object.keys(left), ...Object.keys(right)])].filter((key) => !ignored.has(key));
        if (!keys.length) return 0;
        return keys.filter((key) => JSON.stringify(left[key]) === JSON.stringify(right[key])).length / keys.length;
    };
    const hammingSimilarity = (left = "", right = "") => {
        if (!left || !right) return 0;
        const length = Math.max(left.length, right.length); let matches = 0;
        for (let index = 0; index < length; index += 1) if (left[index] === right[index]) matches += 1;
        return matches / length;
    };
    const histogramSimilarity = (left = [], right = []) => clamp(1 - left.reduce((sum, value, index) => sum + Math.abs(value - (right[index] || 0)), 0) / 2);

    function compare(left = {}, right = {}) {
        const structural = positionalSimilarity(left.structural?.sequence, right.structural?.sequence) * .65
            + objectSimilarity(left.structural, right.structural, new Set(["hash", "sequence"])) * .35;
        const stylistic = objectSimilarity(left.stylistic, right.stylistic);
        let visual = 0;
        if (left.visual && right.visual) visual = hammingSimilarity(left.visual.perceptualHash, right.visual.perceptualHash) * .5
            + histogramSimilarity(left.visual.colorHistogram, right.visual.colorHistogram) * .25
            + clamp(1 - Math.abs(left.visual.edgeDensity - right.visual.edgeDensity)) * .125
            + clamp(1 - Math.abs(left.visual.occupiedArea - right.visual.occupiedArea)) * .125;
        const overall = structural * (visual ? .4 : .55) + stylistic * (visual ? .35 : .45) + visual * .25;
        const dimensions = [];
        if (structural >= .8) dimensions.push("structure");
        Object.keys(left.stylistic || {}).filter((key) => key !== "hash" && left.stylistic[key] && left.stylistic[key] === right.stylistic?.[key]).forEach((key) => dimensions.push(key));
        if (visual >= .85) dimensions.push("visual");
        return Object.freeze({ overall: Number(overall.toFixed(4)), structural: Number(structural.toFixed(4)), stylistic: Number(stylistic.toFixed(4)), visual: Number(visual.toFixed(4)), similarDimensions: [...new Set(dimensions)] });
    }

    function fingerprint(plan, design, visual = null, components = {}) {
        const structural = structuralFingerprint(plan, components);
        const stylistic = stylisticFingerprint(design);
        return Object.freeze({ version: 1, structural, stylistic, visual, hash: hash(`${structural.hash}|${stylistic.hash}|${visual?.hash || ""}`) });
    }

    function readHistory(projectId = "project") {
        if (typeof localStorage === "undefined") return [];
        try { const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); return Array.isArray(all[text(projectId, 80)]) ? all[text(projectId, 80)].slice(0, MAX_HISTORY) : []; } catch (_) { return []; }
    }
    function saveHistory(projectId = "project", history = []) {
        if (typeof localStorage === "undefined") return;
        try { const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); all[text(projectId, 80)] = history.slice(0, MAX_HISTORY); localStorage.setItem(STORAGE_KEY, JSON.stringify(all)); } catch (_) {}
    }
    function record(projectId, entry) {
        const history = readHistory(projectId);
        const normalized = { variationId: text(entry.variationId, 100), fingerprint: entry.fingerprint, recordedAt: entry.recordedAt || new Date().toISOString() };
        saveHistory(projectId, [normalized, ...history.filter((item) => item.variationId !== normalized.variationId)]);
        return normalized;
    }

    function recordVisual(projectId, variationId, imageData) {
        const history = readHistory(projectId);
        const index = history.findIndex((item) => item.variationId === text(variationId, 100));
        if (index < 0) return null;
        const visual = visualFingerprint(imageData);
        if (!visual) return null;
        const current = history[index];
        const fingerprintValue = Object.freeze({ ...current.fingerprint, visual, hash: hash(`${current.fingerprint?.structural?.hash || ""}|${current.fingerprint?.stylistic?.hash || ""}|${visual.hash}`) });
        const updated = { ...current, fingerprint: fingerprintValue, visualRecordedAt: new Date().toISOString() };
        history[index] = updated;
        saveHistory(projectId, history);
        return updated;
    }

    function assessRendered(projectId, variationId, imageData, threshold = DEFAULT_THRESHOLD) {
        const updated = recordVisual(projectId, variationId, imageData);
        if (!updated) return null;
        const comparisons = readHistory(projectId)
            .filter((item) => item.variationId !== updated.variationId && item.fingerprint?.visual)
            .map((item) => ({ variationId: item.variationId, ...compare(updated.fingerprint, item.fingerprint) }))
            .sort((left, right) => right.overall - left.overall);
        const nearest = comparisons[0] || null;
        return Object.freeze({ accepted: !nearest || nearest.overall < threshold, threshold, nearest, variationId: updated.variationId, fingerprint: updated.fingerprint, reason: nearest && nearest.overall >= threshold ? "RENDERED_SIMILARITY_THRESHOLD_NOT_MET" : "" });
    }

    function select(input = {}, makePlan, options = {}) {
        const genomeEngine = options.genomeEngine || (typeof window !== "undefined" ? window.workspaceDesignGenome : null);
        if (!genomeEngine?.create || typeof makePlan !== "function") throw new Error("ORIGINALITY_DEPENDENCY_UNAVAILABLE");
        const projectId = text(input.projectId || input.business?.id || input.business?.name || "project", 80);
        const recent = Array.isArray(options.recent) ? options.recent : readHistory(projectId);
        const threshold = clamp(options.threshold || DEFAULT_THRESHOLD, .5, .98);
        const maxAttempts = Math.max(1, Math.min(12, Number(options.maxAttempts) || 8));
        const locks = new Set(Array.isArray(options.lockDimensions) ? options.lockDimensions : []);
        const initialGenome = object(input.design?.genome);
        const reselections = [];
        let selected = null;
        let previousDesign = null;
        let dimensionsToChange = null;
        const styleToGenome = { spacing: "density", borders: "cards", alignment: "grid", backgrounds: "rhythm", imagery: "imageTreatment", cta: "ctaPattern" };
        for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
            const variationId = attempt === 0 && input.variationId ? input.variationId : genomeEngine.createVariationId(projectId);
            const generated = genomeEngine.create({ ...input, variationId, design: { ...input.design, genome: undefined } });
            const genome = { ...generated.genome };
            if (previousDesign && dimensionsToChange) {
                Object.keys(genome).forEach((key) => { if (!dimensionsToChange.has(key)) genome[key] = previousDesign.genome[key]; });
            }
            locks.forEach((key) => { if (initialGenome[key]) genome[key] = initialGenome[key]; });
            const profile = locks.has("profile") && input.design?.profile ? input.design.profile : previousDesign && dimensionsToChange && !dimensionsToChange.has("profile") ? previousDesign.profile : generated.profile;
            const design = { ...input.design, profile, genome, designFingerprint: genomeEngine.fingerprintOf({ profile, genome }), seedHash: generated.seedHash };
            const plan = makePlan(design);
            const candidateFingerprint = fingerprint(plan, design, null, options.components || {});
            const comparisons = recent.map((item) => ({ variationId: item.variationId, ...compare(candidateFingerprint, item.fingerprint || item) })).sort((a, b) => b.overall - a.overall);
            const nearest = comparisons[0] || null;
            selected = { variationId, design, plan, fingerprint: candidateFingerprint, nearest, attempts: attempt + 1 };
            if (!nearest || nearest.overall < threshold) break;
            reselections.push({ attempt: attempt + 1, rejectedVariationId: variationId, similarity: nearest.overall, similarDimensions: nearest.similarDimensions, reason: "SIMILAR_TO_RECENT_GENERATION" });
            previousDesign = design;
            dimensionsToChange = new Set(nearest.similarDimensions.map((key) => styleToGenome[key] || key));
            if (dimensionsToChange.has("structure") || dimensionsToChange.has("visual")) ["hero", "grid", "rhythm", "imageTreatment", "navigation"].forEach((key) => dimensionsToChange.add(key));
            locks.forEach((key) => dimensionsToChange.delete(key));
            if (!dimensionsToChange.size) Object.keys(genome).filter((key) => !locks.has(key)).forEach((key) => dimensionsToChange.add(key));
        }
        return Object.freeze({ ...selected, accepted: !selected.nearest || selected.nearest.overall < threshold, threshold, capped: Boolean(selected.nearest && selected.nearest.overall >= threshold), reselections });
    }

    const api = Object.freeze({ STORAGE_KEY, MAX_HISTORY, DEFAULT_THRESHOLD, structuralFingerprint, stylisticFingerprint, visualFingerprint, fingerprint, compare, readHistory, record, recordVisual, assessRendered, select });
    if (typeof window !== "undefined") window.workspaceOriginality = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
