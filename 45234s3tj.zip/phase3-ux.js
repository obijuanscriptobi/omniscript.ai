"use strict";

// Small, dependency-free UX layer for clear offline, recovery, and status states.
(() => {
    const BANNER_ID = "workspace-connectivity-banner";
    const TOAST_ID = "workspace-ux-toast";
    let offline = !navigator.onLine;
    let lastMessage = "";

    function make(tag, attributes = {}, text = "") {
        const node = document.createElement(tag);
        Object.entries(attributes).forEach(([key, value]) => {
            if (value === null || value === undefined) return;
            if (key === "hidden") node.hidden = Boolean(value);
            else node.setAttribute(key, String(value));
        });
        if (text) node.textContent = text;
        return node;
    }

    function ensureStyles() {
        if (document.getElementById("workspace-ux-styles")) return;
        const style = make("style", { id: "workspace-ux-styles" });
        style.textContent = `
            #${BANNER_ID}{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 16px;border-bottom:1px solid rgba(224,189,115,.35);background:#211d14;color:#f4efe4;font:600 12px/1.4 system-ui,sans-serif}
            #${BANNER_ID}[data-state="online"]{border-color:rgba(74,222,128,.3);background:#102018}
            #${BANNER_ID} span{min-width:0}
            #${BANNER_ID} button{flex:0 0 auto;border:1px solid currentColor;border-radius:7px;padding:5px 9px;background:transparent;color:inherit;font:inherit;cursor:pointer}
            #${TOAST_ID}{position:fixed;right:20px;bottom:20px;z-index:1200;max-width:min(420px,calc(100vw - 40px));padding:12px 14px;border:1px solid rgba(255,255,255,.16);border-left:3px solid #d6b477;border-radius:10px;background:#171e2b;color:#f5f2ec;box-shadow:0 14px 35px rgba(0,0,0,.28);font:600 12px/1.5 system-ui,sans-serif}
            #${TOAST_ID}[data-state="error"]{border-left-color:#ff8b8b}
            #${TOAST_ID}[data-state="success"]{border-left-color:#4ade80}
            @media(max-width:640px){#${BANNER_ID}{align-items:flex-start;padding:9px 12px}#${TOAST_ID}{right:12px;bottom:12px;max-width:calc(100vw - 24px)}}
        `;
        document.head.append(style);
    }

    function banner() {
        let node = document.getElementById(BANNER_ID);
        if (node) return node;
        node = make("div", { id: BANNER_ID, role: "status", "aria-live": "polite", hidden: true });
        node.append(make("span"), make("button", { type: "button", hidden: true }, "Try again"));
        const header = document.querySelector(".matrix-app-bar");
        if (header) header.after(node);
        else document.body.prepend(node);
        node.lastElementChild.addEventListener("click", () => {
            if (!navigator.onLine) return;
            window.location.reload();
        });
        return node;
    }

    function showToast(message, type = "info") {
        if (!message || message === lastMessage) return;
        lastMessage = message;
        let toast = document.getElementById(TOAST_ID);
        if (!toast) {
            toast = make("div", { id: TOAST_ID, role: "status", "aria-live": "polite", "aria-atomic": "true", hidden: true });
            document.body.append(toast);
        }
        clearTimeout(toast._timer);
        toast.textContent = message;
        toast.dataset.state = type;
        toast.hidden = false;
        toast._timer = window.setTimeout(() => {
            toast.hidden = true;
            lastMessage = "";
        }, 4200);
    }

    function updateConnectivity(isOnline, announce = true) {
        offline = !isOnline;
        document.documentElement.dataset.connection = isOnline ? "online" : "offline";
        const node = banner();
        const message = isOnline
            ? "You are back online. Cloud actions are available again; local edits remain preserved."
            : "You are offline. Local editing and browser autosave remain available; cloud actions will wait until you reconnect.";
        node.dataset.state = isOnline ? "online" : "offline";
        node.firstElementChild.textContent = message;
        node.lastElementChild.hidden = !isOnline;
        node.hidden = isOnline && !announce;

        const status = document.getElementById("status-vector");
        if (status && !isOnline) {
            status.textContent = "Working offline — local changes are preserved.";
            status.dataset.loaderState = "loading";
        }
        if (announce) showToast(message, isOnline ? "success" : "info");
    }

    function recordRuntimeIssue(kind, error) {
        const detail = {
            kind,
            message: String(error?.message || error || "Unknown workspace error").slice(0, 300),
            timestamp: new Date().toISOString()
        };
        window.workspaceRuntimeIssues = [...(window.workspaceRuntimeIssues || []), detail].slice(-20);
        window.dispatchEvent(new CustomEvent("workspace:runtime-issue", { detail }));
    }

    function bindPerformanceObservers() {
        if (!window.PerformanceObserver) return;
        if (PerformanceObserver.supportedEntryTypes?.includes("longtask")) {
            new PerformanceObserver((list) => list.getEntries().forEach((entry) => {
                if (entry.duration >= 100) recordRuntimeIssue("long-task", { message: `${Math.round(entry.duration)}ms` });
            })).observe({ type: "longtask", buffered: true });
        }
    }

    function bind() {
        ensureStyles();
        updateConnectivity(navigator.onLine, false);
        if (navigator.onLine) banner().hidden = true;
        window.addEventListener("offline", () => updateConnectivity(false));
        window.addEventListener("online", () => updateConnectivity(true));
        window.addEventListener("error", (event) => recordRuntimeIssue("error", event.error || event.message));
        window.addEventListener("unhandledrejection", (event) => recordRuntimeIssue("unhandled-rejection", event.reason));
        bindPerformanceObservers();

        window.addEventListener("workspace:loader-error", (event) => {
            const message = event.detail?.error?.message || "Some workspace tools could not load.";
            showToast(`${message} Core editing remains available.`, "error");
        });
        window.addEventListener("workspace:files-rendered", () => {
            if (!offline) return;
            const saveStatus = document.getElementById("workspace-save-status");
            if (saveStatus && saveStatus.getAttribute("aria-invalid") !== "true") {
                saveStatus.textContent = "Offline changes are saved in this browser.";
            }
        });
    }

    window.workspaceUX = Object.freeze({
        isOffline: () => offline,
        notify: showToast,
        updateConnectivity
    });

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
