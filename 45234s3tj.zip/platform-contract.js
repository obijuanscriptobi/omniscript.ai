"use strict";

// Stable contracts for the backend-backed platform features. Providers are
// adapters, not UI components, so deployment and analytics vendors can change
// without changing the editor workflow.
(() => {
    const EVENTS = Object.freeze([
        "page_view", "cta_click", "form_start", "form_submit",
        "booking_start", "phone_click", "email_click"
    ]);
    const LOCALES = Object.freeze(["en-US", "en-GB", "fr-FR", "de-DE", "es-ES", "it-IT", "pt-BR", "nl-NL", "ja-JP", "ko-KR", "ar"]);
    const PROVIDERS = Object.freeze({
        deployment: ["netlify", "vercel", "cloudflare-pages", "static-export"],
        analytics: ["plausible", "umami", "posthog", "first-party"],
        storage: ["supabase-storage", "s3-compatible"]
    });

    const safeIdentifier = (value, fallback = "") => String(value || "").trim().slice(0, 200).replace(/[^a-zA-Z0-9._:-]/g, "-") || fallback;
    const eventPayload = ({ projectId, deploymentId, eventName, anonymousId, path, locale, consent = false, metadata = {} } = {}) => {
        if (!/^[0-9a-f-]{36}$/i.test(String(projectId || ""))) throw new Error("A valid project ID is required.");
        if (!EVENTS.includes(eventName)) throw new Error("Unsupported analytics event.");
        return {
            projectId,
            deploymentId: /^[0-9a-f-]{36}$/i.test(String(deploymentId || "")) ? deploymentId : null,
            eventName,
            anonymousId: safeIdentifier(anonymousId, globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`),
            path: safeIdentifier(path, "/").slice(0, 500),
            locale: LOCALES.includes(locale) ? locale : null,
            consent: Boolean(consent),
            metadata: metadata && typeof metadata === "object" && !Array.isArray(metadata) ? Object.fromEntries(Object.entries(metadata).slice(0, 12).map(([key, value]) => [safeIdentifier(key), String(value).slice(0, 200)])) : {}
        };
    };

    async function track(input) {
        const payload = eventPayload(input);
        if (!payload.consent) return { success: false, skipped: true, reason: "consent-required" };
        const response = await fetch("/api/analytics", {
            method: "POST",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            credentials: "same-origin",
            body: JSON.stringify(payload),
            keepalive: true
        });
        return { success: response.ok, status: response.status };
    }

    const providerConfig = Object.freeze({
        deployment: { netlify: "/api/deploy", vercel: "/api/platform", "cloudflare-pages": "/api/platform", "static-export": "download" },
        analytics: { plausible: "/api/analytics-provider", umami: "/api/analytics-provider", posthog: "/api/analytics-provider", "first-party": "/api/analytics" },
        storage: { "supabase-storage": "/api/asset", "s3-compatible": "/api/asset" }
    });
    const chooseExperimentVariant = (variants = [], anonymousId = "") => { const list = Array.isArray(variants) ? variants.filter(item => item && item.name) : []; if (!list.length) return null; let hash = 0; for (const char of String(anonymousId)) hash = (hash * 31 + char.charCodeAt(0)) >>> 0; const total = list.reduce((sum, item) => sum + Math.max(0, Number(item.weight) || 0), 0) || list.length; let cursor = hash % total; for (const item of list) { cursor -= Math.max(0, Number(item.weight) || 0) || 1; if (cursor < 0) return item.name; } return list[list.length - 1].name; };
    window.workspacePlatformContract = Object.freeze({ EVENTS, LOCALES, PROVIDERS, providerConfig, eventPayload, track, chooseExperimentVariant, version: 3 });
})();
