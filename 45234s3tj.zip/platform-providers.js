"use strict";

// Provider-neutral server contracts. Concrete credentials stay in server
// environment variables or secret storage; this module never exposes them to
// the browser.
const PROVIDER_NAMES = Object.freeze({
    deployment: ["netlify", "vercel", "cloudflare-pages", "static-export"],
    analytics: ["plausible", "umami", "posthog", "first-party"],
    storage: ["supabase-storage", "s3-compatible"]
});

class ProviderRegistry {
    constructor() { this.adapters = new Map(); }
    register(type, name, adapter) {
        if (!PROVIDER_NAMES[type]?.includes(name) || !adapter || typeof adapter !== "object") throw new Error("Unsupported provider adapter.");
        for (const method of type === "deployment" ? ["deploy", "status", "rollback"] : type === "analytics" ? ["track"] : ["upload", "remove"]) {
            if (typeof adapter[method] !== "function") throw new Error(`Provider adapter must implement ${method}.`);
        }
        this.adapters.set(`${type}:${name}`, Object.freeze({ ...adapter }));
    }
    get(type, name) { return this.adapters.get(`${type}:${name}`) || null; }
    async deploy(name, payload) { const adapter = this.get("deployment", name); if (!adapter) throw new Error("Provider adapter is not configured."); return adapter.deploy(payload); }
    async status(name, deploymentId) { const adapter = this.get("deployment", name); if (!adapter) throw new Error("Provider adapter is not configured."); return adapter.status(deploymentId); }
    async rollback(name, deploymentId) { const adapter = this.get("deployment", name); if (!adapter) throw new Error("Provider adapter is not configured."); return adapter.rollback(deploymentId); }
    list(type) { return PROVIDER_NAMES[type] || []; }
}

module.exports = { ProviderRegistry, PROVIDER_NAMES };
