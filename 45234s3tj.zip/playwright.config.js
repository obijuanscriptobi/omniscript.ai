import { defineConfig, devices } from "@playwright/test";

const baseURL = process.env.SITE_URL || "http://127.0.0.1:8888";

export default defineConfig({
    testDir: "./test",
    timeout: 30_000,
    expect: { timeout: 5_000 },
    fullyParallel: true,
    forbidOnly: Boolean(process.env.CI),
    retries: process.env.CI ? 2 : 0,
    reporter: [["list"], ["html", { open: "never" }]],
    webServer: process.env.SITE_URL ? undefined : {
        command: "node test/static-server.js",
        url: baseURL,
        reuseExistingServer: !process.env.CI,
        timeout: 30_000
    },
    use: {
        baseURL,
        trace: "retain-on-failure",
        colorScheme: "light",
        reducedMotion: "no-preference",
        screenshot: "only-on-failure",
        video: "retain-on-failure",
        serviceWorkers: "block"
    },
    projects: [
        { name: "chromium-desktop", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"] } },
        { name: "firefox-desktop", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Firefox"] } },
        { name: "webkit-desktop", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Safari"] } },
        { name: "chromium-mobile", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Pixel 5"] } },
        { name: "webkit-mobile", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["iPhone 13"] } },
        { name: "chromium-tablet", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["iPad Mini"] } },
        { name: "chromium-320", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], viewport: { width: 320, height: 800 } } },
        { name: "chromium-375", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], viewport: { width: 375, height: 812 } } },
        { name: "chromium-768", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], viewport: { width: 768, height: 900 } } },
        { name: "chromium-1024", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], viewport: { width: 1024, height: 900 } } },
        { name: "chromium-1440", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } } },
        { name: "chromium-reduced-motion", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], reducedMotion: "reduce" } },
        { name: "chromium-forced-colors", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], forcedColors: "active" } },
        { name: "chromium-no-javascript", testIgnore: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], javaScriptEnabled: false } },
        { name: "staging", testMatch: /staging-smoke\.spec\.js/, use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } } }
    ]
});
