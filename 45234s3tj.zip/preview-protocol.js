"use strict";

// Shared contract for messages crossing the opaque preview iframe boundary.
(() => {
    const CHANNEL = "website-maker-preview-v1";
    const LIMITS = Object.freeze({ error: 500, name: 160, email: 240, phone: 80, message: 2000, company: 180, source: 80 });
    const allowedKeys = Object.freeze({
        error: new Set(["message"]),
        enquiry: new Set(["name", "email", "phone", "message", "company", "source"])
    });
    const clean = (value, max) => String(value ?? "").replace(/[\u0000-\u001F\u007F]/g, "").trim().slice(0, max);

    function parse(data) {
        if (!data || typeof data !== "object" || Array.isArray(data) || data.channel !== CHANNEL) return null;
        if (!Object.prototype.hasOwnProperty.call(allowedKeys, data.type)) return null;
        const payload = data.payload;
        if (!payload || typeof payload !== "object" || Array.isArray(payload)) return null;
        if (Object.keys(data).some((key) => !["channel", "type", "payload"].includes(key))) return null;
        if (Object.keys(payload).some((key) => !allowedKeys[data.type].has(key))) return null;
        if (data.type === "error") {
            if (typeof payload.message !== "string" || payload.message.length > LIMITS.error * 2) return null;
            return { type: "error", payload: { message: clean(payload.message, LIMITS.error) } };
        }
        const result = {};
        for (const key of allowedKeys.enquiry) {
            if (payload[key] !== undefined && typeof payload[key] !== "string") return null;
            if (typeof payload[key] === "string" && payload[key].length > LIMITS[key] * 2) return null;
            result[key] = clean(payload[key], LIMITS[key]);
        }
        if (!result.name && !result.email && !result.phone && !result.message) return null;
        return { type: "enquiry", payload: result };
    }

    window.websiteMakerPreviewProtocol = Object.freeze({ CHANNEL, LIMITS, parse });
})();
