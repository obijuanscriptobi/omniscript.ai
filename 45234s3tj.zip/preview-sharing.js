"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    const status = () => get("preview-share-status");
    const setStatus = (message) => { if (status()) status().textContent = message; };

    async function send() {
        const recipient = String(get("preview-recipient-email")?.value || "").trim();
        const state = window.workspaceAPI?.getState?.();
        const files = state?.files || {};
        const button = get("send-preview-email-btn");
        const activeContext = window.workspaceContext?.current?.();
        const gate = window.workspaceContext?.clientGate?.("assets", activeContext) || { allowed: true };
        if (!gate.allowed) { setStatus(gate.message); return; }
        if (!state?.projectId || !activeContext?.cloudId) { setStatus("Save this project and connect its workspace before sharing a preview."); return; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(recipient)) { setStatus("Enter a valid recipient email address first."); return; }
        if (!files["index.html"] || String(files["index.html"]).startsWith("<!-- Awaiting")) { setStatus("Create a website draft before emailing a preview."); return; }
        if (!button) return;
        button.disabled = true;
        setStatus("Preparing a private preview…");
        try {
            const preview = await fetch("/api/preview", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify({ files, revision: state.revision || "draft", projectId: state.projectId, workContextId: activeContext.cloudId }) });
            const previewResult = await preview.json().catch(() => ({}));
            if (!preview.ok || !previewResult.success) throw new Error(previewResult.error || "The preview could not be prepared.");
            const email = await fetch("/api/send-preview", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify({ recipient, token: previewResult.token }) });
            const emailResult = await email.json().catch(() => ({}));
            if (!email.ok || !emailResult.success) throw new Error(emailResult.error || "The preview email could not be sent.");
            setStatus(emailResult.message || "Preview sent.");
        } catch (error) {
            setStatus(error.message || "The preview email could not be sent.");
        } finally {
            button.disabled = false;
        }
    }

    function bind() {
        get("send-preview-email-btn")?.addEventListener("click", () => send());
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
