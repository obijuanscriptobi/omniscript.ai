"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    const fields = [
        ["input-biz-name", "business name", "Your business"],
        ["input-biz-email", "privacy contact email", ""],
        ["input-biz-location", "jurisdiction or operating location", ""],
        ["input-privacy-retention", "retention period", "We retain enquiry data only as long as necessary to respond and meet legal obligations."],
        ["input-privacy-processors", "service providers", "List the hosting, form delivery, analytics, CRM, and cloud storage providers you use."],
        ["input-privacy-rights", "privacy rights instructions", "Explain how visitors can request access, correction, deletion, or portability."],
        ["input-privacy-analytics", "analytics and cookies", "Describe analytics, cookies, consent, and opt-out choices."],
        ["input-privacy-effective", "policy effective date", new Date().toISOString().slice(0, 10)]
    ];

    function value(id, fallback = "") { return get(id)?.value.trim() || fallback; }
    function escape(value) { const node = document.createElement("textarea"); node.textContent = value; return node.innerHTML; }

    function createPolicyPage() {
        const name = value("input-biz-name", "Your business");
        const email = value("input-biz-email", "[Add a privacy contact email]");
        const location = value("input-biz-location", "[Add the relevant jurisdiction]");
        const retention = value("input-privacy-retention");
        const processors = value("input-privacy-processors");
        const rights = value("input-privacy-rights");
        const analytics = value("input-privacy-analytics");
        const effective = value("input-privacy-effective", new Date().toISOString().slice(0, 10));
        const incomplete = [email, location, retention, processors, rights, analytics].some((item) => item.startsWith("[") || !item);
        if (incomplete) throw new Error("Complete the privacy policy inputs before creating the privacy page.");
        const sections = [
            ["Information we collect", "Explain the information visitors submit, such as name, email address, telephone number, and enquiry details."],
            ["How we use information", "Explain how information is used to respond to enquiries, provide services, prevent abuse, and meet legal obligations."],
            ["Service providers", processors || "[Complete this section with the providers that process data for your business.]"],
            ["Retention", retention || "[State how long each category of information is retained and why.]"],
            ["Your rights", rights || "[Explain how visitors can exercise applicable privacy rights.]"],
            ["Cookies and analytics", analytics || "[State whether cookies or analytics are used and how visitors can control them.]"],
            ["Contact", `For privacy questions, contact ${email}. Operating location or jurisdiction: ${location}.`]
        ];
        const content = sections.map(([title, body]) => `<section><h2>${escape(title)}</h2><p>${escape(body)}</p></section>`).join("\n");
        return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="index,follow"><meta name="description" content="Privacy policy for ${escape(name)}."><title>Privacy Policy — ${escape(name)}</title><link rel="canonical" href="./privacy.html"><link rel="stylesheet" href="./style.css"></head><body><header class="hero"><div class="hero-inner"><p class="eyebrow"><a href="./index.html">${escape(name)}</a></p><h1>Privacy Policy</h1><p class="lead">Effective date: ${escape(effective)}</p>${incomplete ? '<p class="form-note">This draft contains placeholders. Review it with a qualified privacy professional before publishing.</p>' : ""}</div></header><main id="main-content">${content}<p><a class="button" href="./index.html">Return home</a></p></main><script src="./script.js" defer></script></body></html>`;
    }

    function addControls() {
        const panel = document.querySelector('[aria-labelledby="brand-content-title"]');
        if (!panel || document.getElementById("privacy-settings-title")) return;
        const section = document.createElement("section");
        section.className = "input-card-group panel-accent-glow";
        section.setAttribute("aria-labelledby", "privacy-settings-title");
        section.innerHTML = `<h3 id="privacy-settings-title" class="field-label-tag">Privacy policy inputs</h3><p class="field-descriptor-text">These inputs create a reviewable draft, not legal advice. Complete every field and obtain appropriate professional review before publishing.</p>${fields.slice(3).map(([id, label, placeholder]) => `<label for="${id}" class="field-label-tag">${label}</label><textarea id="${id}" class="matrix-text-area-field" rows="2" placeholder="${placeholder}"></textarea>`).join("")}<button id="create-privacy-page-btn" type="button" class="matrix-action-btn variant-outline-row">Create or update privacy page</button>`;
        panel.after(section);
        section.querySelector("#create-privacy-page-btn")?.addEventListener("click", () => {
            const state = window.workspaceAPI?.getState?.();
            if (!state?.files) return;
            const files = { ...state.files, "privacy.html": createPolicyPage() };
            try {
                window.workspaceAPI.applySnapshot({ ...state, files, activePage: "privacy.html" });
                window.workspaceAPI.markDirty?.();
            } catch (error) {
                get("privacy-settings-title")?.nextElementSibling?.replaceChildren(document.createTextNode(error.message));
            }
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", addControls, { once: true });
    else addControls();
    window.workspacePrivacy = { createPolicyPage };
})();
