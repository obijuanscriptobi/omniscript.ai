"use strict";

// Local-first persistence boundary for the canonical BusinessProfile contract.
// Cloud adapters are optional and can be supplied by an authenticated host.
(() => {
    // Governance/audit records are separate from the website maker's canonical
    // profile cache; only website-maker-profile-store writes that cache.
    const STORAGE_KEY = "morrow-governed-business-profile-v1";
    const storageKey = () => window.workspaceContext?.storageKey?.(STORAGE_KEY) || STORAGE_KEY;
    const api = () => window.businessProfile;
    const clone = (value) => JSON.parse(JSON.stringify(value));
    const stateOf = () => window.workspaceAPI?.getState?.() || window.workspaceState?.createWorkspaceState?.() || null;
    let cloudAdapter = null;

    function configure(options = {}) {
        cloudAdapter = options.cloud || options.adapter || null;
        return service;
    }

    function readLocal() {
        try {
            const scoped = localStorage.getItem(storageKey());
            const legacy = window.operatingMode?.get?.() === "own" ? localStorage.getItem(STORAGE_KEY) : null;
            const record = JSON.parse(scoped || legacy || "null");
            if (!scoped && legacy && record?.profile) writeLocal(record.profile);
            return record?.profile || null;
        } catch (_) {
            return null;
        }
    }

    function writeLocal(profile) {
        try {
            localStorage.setItem(storageKey(), JSON.stringify({ version: profile.version, revision: profile.revision, workContext: window.workspaceContext?.current?.() || null, profile, savedAt: new Date().toISOString() }));
            return true;
        } catch (_) {
            return false;
        }
    }

    function normalize(input = {}) {
        if (!api()?.normalizeProfile) throw new Error("The BusinessProfile contract is unavailable.");
        return api().normalizeProfile(input);
    }

    function currentStateProfile() {
        const state = stateOf();
        return state?.businessProfile || null;
    }

    async function getProfile(options = {}) {
        let raw = options.profile || (!options.force && currentStateProfile()) || (!options.force && readLocal());
        if (!raw && cloudAdapter?.load) {
            try {
                const loaded = await cloudAdapter.load();
                raw = loaded?.profile && typeof loaded.profile === "object" ? loaded.profile : loaded;
            } catch (_) { raw = null; }
        }
        if (!raw && options.create !== false) raw = {};
        return raw ? normalize(raw) : null;
    }

    function applyState(profile) {
        const state = stateOf();
        if (!state) return profile;
        state.businessProfile = clone(profile);
        state.profileRevision = profile.revision;
        state.profileAudit = clone(profile.audit || []);
        state.propagationPreview = null;
        return profile;
    }

    function changesFor(profile, next) {
        const changes = {};
        Object.keys(next).forEach((key) => {
            if (["updatedAt", "revision", "audit"].includes(key)) return;
            if (JSON.stringify(profile?.[key]) !== JSON.stringify(next[key])) changes[key] = { previous: profile?.[key], next: next[key] };
        });
        return changes;
    }

    async function saveProfile(input = {}, options = {}) {
        const current = await getProfile({ create: true });
        const next = normalize(input);
        const validation = api().validateProfile(next);
        if (!validation.valid) {
            const error = new Error("Business profile validation failed.");
            error.code = "PROFILE_INVALID";
            error.issues = validation.issues;
            throw error;
        }
        const changes = options.changes || changesFor(current, next);
        next.id = current.id || next.id;
        next.revision = String(Number(current.revision || 0) + 1);
        next.audit = [...(current.audit || []), {
            id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            type: "profile.updated", actor: String(options.actor || "user"), revision: next.revision,
            changes: clone(changes), createdAt: new Date().toISOString()
        }];
        next.updatedAt = new Date().toISOString();
        applyState(next);
        writeLocal(next);
        let persisted = "local";
        if (cloudAdapter?.save) {
            try { await cloudAdapter.save(clone(next)); persisted = "cloud"; } catch (_) { persisted = "local-fallback"; }
        }
        const result = { profile: clone(next), revision: next.revision, event: next.audit.at(-1), affectedSurfaces: api().affectedSurfaces(changes), persisted };
        const state = stateOf();
        if (state) state.propagationPreview = getPropagationPreview(changes, next);
        if (typeof window.dispatchEvent === "function") window.dispatchEvent(new CustomEvent("business-profile:updated", { detail: result }));
        return result;
    }

    function recordChange(profile, changes = {}, actor = "user") {
        const base = normalize(profile);
        const next = normalize({ ...base, ...changes });
        const result = api().recordChange(base, changes, actor);
        result.profile = normalize({ ...next, revision: result.profile.revision, audit: result.profile.audit });
        return result;
    }

    function getPropagationPreview(changes = {}, profile = null) {
        const affectedSurfaces = api().affectedSurfaces(changes);
        return { affectedSurfaces, changes: clone(changes), profileId: profile?.id || null, revision: profile?.revision || null, status: "pending", createdAt: new Date().toISOString() };
    }

    function governance(profile, surface) {
        const validation = api().validateProfile(profile);
        const result = api().governance(profile, surface);
        return { valid: validation.valid && result.valid, surface, validationIssues: validation.issues, blocking: result.blocking.map((item) => ({ ...item, remediation: `Approve or update claim ${item.claimId} before publishing.` })), stale: result.stale, usableClaims: result.usableClaims };
    }

    async function recordPublishingAttempt(profile, surface, options = {}) {
        const item = normalize(profile);
        const review = governance(item, surface);
        const event = { id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type: "publishing.attempted", actor: String(options.actor || "user"), revision: item.revision, changes: { surface, valid: review.valid, blocking: review.blocking }, createdAt: new Date().toISOString() };
        item.audit.push(event);
        applyState(item);
        writeLocal(item);
        return { ...review, event, profile: item };
    }

    async function assertPublishable(profile, surface, options = {}) {
        const result = await recordPublishingAttempt(profile, surface, options);
        if (!result.valid) {
            const error = new Error(`Publishing blocked for ${surface}.`);
            error.code = "PUBLISHING_BLOCKED";
            error.surface = surface;
            error.issues = [...result.validationIssues, ...result.blocking];
            throw error;
        }
        return result;
    }

    const service = Object.freeze({ STORAGE_KEY, configure, normalize, getProfile, saveProfile, recordChange, getPropagationPreview, governance, recordPublishingAttempt, assertPublishable, readLocal, writeLocal });
    window.profileService = service;
    if (typeof module !== "undefined" && module.exports) module.exports = service;
})();
