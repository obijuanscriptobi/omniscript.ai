"use strict";

// Lightweight same-browser project bridge. It uses DOM events for open tabs,
// BroadcastChannel for separate tabs, and a small local snapshot for recovery.
(() => {
    const CHANNEL_NAME = "morrow-project-context-v1";
    const STORAGE_KEY = "morrow-live-project-context-v1";
    const contextStorageKey = () => window.workspaceContext?.storageKey?.(STORAGE_KEY) || STORAGE_KEY;
    const SOURCE = "website-maker";
    const get = (id) => typeof document !== "undefined" ? document.getElementById(id) : null;
    const read = (id) => String(get(id)?.value || "").trim();
    const business = () => {
        const profile = window.websiteMakerProfileStore?.getState?.();
        if (profile) return window.workspaceGenerator?.businessFromProfile?.(profile) || {
            name: profile.identity?.displayName || "",
            hook: profile.messaging?.hook || profile.services?.[0] || "",
            location: profile.locations?.[0]?.city || "",
            phone: profile.identity?.phoneDisplay || "",
            email: profile.identity?.email || "",
            services: (profile.services || []).join(", "),
            audience: profile.audience || "",
            primaryGoal: profile.primaryGoal || ""
        };
        return {
        name: read("input-biz-name"), hook: read("input-biz-hook"), location: read("input-biz-location"),
        phone: read("input-biz-phone"), color: read("input-biz-color"), secondaryColor: read("input-biz-secondary-color"),
        logoUrl: read("input-biz-logo"), heroImageUrl: read("input-biz-hero-image"), logoAlt: read("input-biz-logo-alt"),
        services: read("input-biz-services"), audience: read("input-biz-audience"), differentiator: read("input-biz-differentiator"),
        testimonial: read("input-biz-testimonial"), testimonialAuthor: read("input-biz-testimonial-author"), credentials: read("input-biz-credentials"),
        experience: read("input-biz-experience"), customers: read("input-biz-customers"), hours: read("input-biz-hours"), pricing: read("input-biz-pricing"),
        booking: read("input-biz-booking"), approvedClaims: read("input-biz-approved-claims"), forbiddenClaims: read("input-biz-forbidden-claims"), brandVoice: read("input-biz-brand-voice"), primaryGoal: read("input-primary-goal"), primaryCta: read("input-primary-cta"),
        responseTime: read("input-response-time"), businessType: read("input-business-type"), designStyle: read("input-design-style"),
        contentTone: read("input-content-tone"), layoutDensity: read("input-layout-density"),
        locale: read("input-locale") || "en-US", direction: read("input-direction") || "ltr",
        supportedLocales: read("input-supported-locales") || "en-US", hostingProvider: read("hosting-provider-select") || "static-export"
        };
    };
    const createContext = () => ({ version: 2, source: SOURCE, operatingMode: window.operatingMode?.get?.() || "own", workContextId: window.workspaceContext?.current?.()?.id || "own-business", projectId: read("project-name-input") || "local-project", updatedAt: new Date().toISOString(), business: business() });
    let timer;
    let channel = null;
    try { if (typeof BroadcastChannel !== "undefined") channel = new BroadcastChannel(CHANNEL_NAME); } catch (_) {}
    function publish() {
        const context = createContext();
        try { if (typeof localStorage !== "undefined") { localStorage.setItem(contextStorageKey(), JSON.stringify(context)); localStorage.setItem(STORAGE_KEY, JSON.stringify(context)); } } catch (_) {}
        try { channel?.postMessage(context); } catch (_) {}
        if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("morrow:project-context", { detail: context }));
    }
    function schedulePublish() { clearTimeout(timer); timer = setTimeout(publish, 180); }
    function onContext(context) {
        const active = window.workspaceContext?.current?.();
        if ((!context || context.source === "website-maker") && (!context?.workContextId || context.workContextId === active?.id)) {
            if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("morrow:project-context", { detail: context }));
        }
    }
    channel?.addEventListener("message", (event) => onContext(event.data));
    if (typeof window !== "undefined") window.addEventListener("storage", (event) => { if (event.key === STORAGE_KEY && event.newValue) { try { onContext(JSON.parse(event.newValue)); } catch (_) {} } });
    if (typeof document !== "undefined") {
        const isWebsiteMaker = document.body?.classList.contains("website-maker-shell") || Boolean(document.getElementById("outcome-name-input"));
        if (isWebsiteMaker) {
            document.addEventListener("website-maker:profile-changed", schedulePublish);
            document.addEventListener("input", (event) => { if (event.target?.id === "project-name-input") schedulePublish(); });
            document.addEventListener("change", (event) => { if (event.target?.id === "project-name-input") schedulePublish(); });
            window.addEventListener("omniscript:operating-mode", schedulePublish);
            if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", publish, { once: true }); else setTimeout(publish, 0);
        }
    }
    window.morrowProjectContext = Object.freeze({ publish, read: createContext, storageKey: contextStorageKey });
})();
