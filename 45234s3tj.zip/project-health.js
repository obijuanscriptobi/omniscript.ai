"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    const escapeText = (value) => { const node = document.createElement("span"); node.textContent = value; return node.innerHTML; };

    function calculate() {
        const frame = get("previewContentIframe");
        const doc = frame?.contentDocument;
        const scores = { content: 0, conversion: 0, accessibility: 0, seo: 0, performance: 0 };
        if (!doc || !doc.body || /Awaiting Data Submission/i.test(doc.documentElement?.outerHTML || "")) return { scores, total: 0, findings: ["Compile or import a website first."] };
        const findings = [];
        const add = (category, points, message) => { scores[category] += points; if (message) findings.push(message); };
        const text = (doc.body.innerText || "").replace(/\s+/g, " ").trim();
        add("content", text.length >= 240 ? 25 : text.length >= 120 ? 14 : 0, text.length < 120 ? "Add more specific customer-focused content." : "");
        add("content", doc.querySelectorAll("main section").length >= 3 ? 25 : 12, "");
        add("content", doc.querySelector("h1")?.textContent.trim() ? 25 : 0, !doc.querySelector("h1") ? "Add a clear primary heading." : "");
        add("content", doc.querySelector("img, .gallery-grid, .proof-grid") ? 25 : 15, "");
        const action = doc.querySelector("form, a[href^='tel:'], a[href^='mailto:'], a[href*='booking'], .hero-actions .button");
        add("conversion", action ? 40 : 0, action ? "" : "Connect visitors to a primary action.");
        add("conversion", doc.querySelector(".hero-actions .button, .nav-cta") ? 30 : 0, "");
        add("conversion", doc.querySelector("form") ? 30 : 10, doc.querySelector("form") ? "" : "Consider adding a contact path.");
        const images = [...doc.images];
        const labeled = [...doc.querySelectorAll("input:not([type='hidden']), textarea, select")].every((field) => field.labels?.length || field.getAttribute("aria-label") || field.getAttribute("aria-labelledby"));
        add("accessibility", doc.documentElement.lang ? 25 : 0, doc.documentElement.lang ? "" : "Declare the document language.");
        add("accessibility", images.every((image) => image.hasAttribute("alt")) ? 25 : 0, images.every((image) => image.hasAttribute("alt")) ? "" : "Add alt text to every image.");
        add("accessibility", labeled ? 25 : 0, labeled ? "" : "Connect labels to form controls.");
        add("accessibility", doc.querySelector("main") ? 25 : 0, doc.querySelector("main") ? "" : "Add a main landmark.");
        add("seo", doc.title.length >= 10 && doc.title.length <= 60 ? 30 : 0, doc.title.length >= 10 && doc.title.length <= 60 ? "" : "Keep the page title descriptive and concise.");
        add("seo", doc.querySelector("meta[name='description']")?.content ? 25 : 0, doc.querySelector("meta[name='description']") ? "" : "Add a meta description.");
        add("seo", doc.querySelector("link[rel='canonical']") ? 20 : 0, doc.querySelector("link[rel='canonical']") ? "" : "Add a canonical URL.");
        add("seo", doc.querySelector("script[type='application/ld+json']") ? 25 : 0, doc.querySelector("script[type='application/ld+json']") ? "" : "Add structured data.");
        add("performance", images.every((image) => image.loading === "lazy" || image.loading === "eager" || !image.src) ? 35 : 0, images.some((image) => !image.loading) ? "Set loading behavior on images." : "");
        add("performance", !doc.querySelector("script[src^='http']") ? 35 : 0, doc.querySelector("script[src^='http']") ? "Review external scripts." : "");
        add("performance", !doc.querySelector("iframe, object, embed") ? 30 : 10, "");
        Object.keys(scores).forEach((key) => { scores[key] = Math.min(100, scores[key]); });
        return { scores, total: Math.round(Object.values(scores).reduce((sum, value) => sum + value, 0) / 5), findings };
    }

    function render() {
        const report = calculate();
        const score = get("project-health-score");
        const grid = get("project-health-grid");
        const summary = get("project-health-summary");
        if (score) score.textContent = report.total ? `${report.total}/100` : "Pending";
        if (grid) grid.replaceChildren(...Object.entries(report.scores).map(([key, value]) => { const card = document.createElement("div"); card.className = "project-health-card"; card.innerHTML = `<strong>${escapeText(key)}</strong><span>${value}/100</span>`; return card; }));
        if (summary) summary.textContent = report.total ? (report.findings.length ? report.findings.slice(0, 3).join(" ") : "Core launch checks look healthy. Run smoke tests before publishing.") : report.findings[0];
    }

    function bind() { get("previewContentIframe")?.addEventListener("load", () => setTimeout(render, 120)); document.addEventListener("input", () => setTimeout(render, 250), true); render(); }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
    window.projectHealth = { calculate, render };
})();
