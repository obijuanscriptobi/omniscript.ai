"use strict";

// Shared boundary for deterministic assembler output. Model-authored page plans
// are validated before assembly; this contract validates only assembled files.
((root, factory) => {
    const api = factory(
        typeof module !== "undefined" && module.exports ? require("./workspace-server-validation.js") : root.workspaceServerValidation,
        typeof module !== "undefined" && module.exports ? require("./workspace-output-contract.js") : null
    );
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    if (root) root.workspaceProjectContract = Object.freeze(api);
})(typeof window !== "undefined" ? window : globalThis, (serverValidation, outputContract) => {
    const LIMITS = Object.freeze({ outputBytes: 1_200_000, fileBytes: 1_000_000, fileCount: 24 });
    const BASE_PATHS = new Set(["index.html", "style.css", "script.js", "favicon.svg", "sitemap.xml", "robots.txt", "site.webmanifest", "404.html", "security.txt", "netlify.toml", "submit-form.js", "netlify/functions/submit-form.js"]);

    function byteLength(value) {
        const text = String(value ?? "");
        if (typeof TextEncoder === "function") return new TextEncoder().encode(text).byteLength;
        return Buffer.byteLength(text, "utf8");
    }

    function isAllowedPath(path, options = {}) {
        if (BASE_PATHS.has(path)) return true;
        const requested = new Set((options.requestedPages || []).map((page) => String(page || "").trim().toLowerCase()).filter((page) => /^[a-z0-9]+(?:-[a-z0-9]+)*\.html$/.test(page)));
        return requested.has(path) || (Boolean(options.allowRequestedPages) && /^[a-z0-9]+(?:-[a-z0-9]+)*\.html$/.test(path) && path !== "index.html");
    }

    function parseManifest(raw, options = {}) {
        let manifest;
        if (typeof raw === "object" && raw) manifest = raw;
        else {
            const text = String(raw || "").trim();
            if (!text || byteLength(text) > LIMITS.outputBytes) throw new Error("PROJECT_OUTPUT_INVALID");
            try { manifest = JSON.parse(text); } catch { throw new Error("PROJECT_OUTPUT_MUST_BE_JSON"); }
        }
        if (!manifest || Array.isArray(manifest) || Object.keys(manifest).length !== 1 || !Array.isArray(manifest.files)) throw new Error("PROJECT_MANIFEST_INVALID");
        if (!manifest.files.length || manifest.files.length > LIMITS.fileCount) throw new Error("PROJECT_FILE_COUNT_INVALID");
        const files = {};
        let total = 0;
        for (const file of manifest.files) {
            if (!file || Array.isArray(file) || Object.keys(file).length !== 2 || typeof file.path !== "string" || typeof file.content !== "string") throw new Error("PROJECT_FILE_ENTRY_INVALID");
            if (!isAllowedPath(file.path, options) || Object.hasOwn(files, file.path) || file.path.includes("..") || file.path.startsWith("/") || file.path.includes("\\")) throw new Error("PROJECT_FILE_PATH_INVALID");
            const size = byteLength(file.content);
            if (size > LIMITS.fileBytes || /\u0000/.test(file.content)) throw new Error("PROJECT_FILE_CONTENT_INVALID");
            total += size;
            files[file.path] = file.content;
        }
        if (total > LIMITS.outputBytes) throw new Error("PROJECT_OUTPUT_TOO_LARGE");
        return validateFiles(files, options).files;
    }

    function validateFiles(files = {}, options = {}) {
        if (!files || typeof files !== "object" || Array.isArray(files)) throw new Error("PROJECT_FILES_INVALID");
        const entries = Object.entries(files);
        if (!entries.length || entries.length > LIMITS.fileCount) throw new Error("PROJECT_FILE_COUNT_INVALID");
        let total = 0;
        for (const [path, content] of entries) {
            if (!isAllowedPath(path, options) || typeof content !== "string") throw new Error("PROJECT_FILE_ENTRY_INVALID");
            const size = byteLength(content);
            if (size > LIMITS.fileBytes || /\u0000/.test(content)) throw new Error("PROJECT_FILE_CONTENT_INVALID");
            total += size;
        }
        if (total > LIMITS.outputBytes) throw new Error("PROJECT_OUTPUT_TOO_LARGE");
        const issues = serverValidation?.validateFiles?.(files, options) || [];
        const output = outputContract?.validateOutput?.(files);
        if (output?.issues) issues.push(...output.issues.filter((issue) => issue.severity === "blocking"));
        if (issues.length) {
            const error = new Error("PROJECT_OUTPUT_UNSAFE");
            error.diagnostics = issues;
            throw error;
        }
        return { files: Object.freeze({ ...files }), diagnostics: [] };
    }

    return { LIMITS, isAllowedPath, parseManifest, validateFiles };
});
