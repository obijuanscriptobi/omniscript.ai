"use strict";

(() => {
    const token = new URLSearchParams(location.search).get("token");
    if (token) {
        const cleanUrl = new URL(location.href);
        cleanUrl.searchParams.delete("token");
        history.replaceState(null, "", `${cleanUrl.pathname}${cleanUrl.search}${cleanUrl.hash}`);
    }
    const title = document.getElementById("title");
    const intro = document.getElementById("intro");
    const price = document.getElementById("price");
    const timeline = document.getElementById("timeline");
    const revisions = document.getElementById("revisions");
    const services = document.getElementById("services");
    const message = document.getElementById("message");
    const comment = document.getElementById("comment");
    const buttons = [...document.querySelectorAll("button[data-status]")];
    const setDisabled = (value) => buttons.forEach((button) => { button.disabled = value; });
    const money = (value) => Number(value) ? `$${Number(value).toLocaleString()}` : "Scope to be confirmed";
    const isLocalToken = /^proposal-[a-z0-9-]+$/i.test(token || "");
    let localLead = null;
    let remoteApprovalAvailable = false;
    let localFallbackAllowed = false;

    setDisabled(true);

    if (!token) {
        title.textContent = "This proposal link is missing its token.";
        return;
    }

    const readLocalLead = () => typeof window.workspaceCRM?.read === "function"
        ? window.workspaceCRM.read().find((lead) => lead.proposal?.approvalToken === token)
        : null;

    const renderLocalProposal = (lead) => {
        const proposal = lead.proposal || {};
        const offer = lead.offer || {};
        title.textContent = `${offer.packageName || "Website improvement"} for ${lead.company || lead.name || "your business"}`;
        intro.textContent = lead.opportunity?.report?.headline || "A fixed-scope plan to improve your website experience and conversion path.";
        price.textContent = money(proposal.total || offer.price);
        timeline.textContent = offer.timeline || lead.opportunity?.report?.timeline || "To be confirmed";
        revisions.textContent = offer.revisions ? `${offer.revisions} included` : "Included in scope";
        services.replaceChildren(...(offer.services || proposal.services || []).map((item) => Object.assign(document.createElement("li"), { textContent: item })));
        if (!services.children.length) services.replaceChildren(Object.assign(document.createElement("li"), { textContent: "A tailored improvement plan based on the discovery call." }));
    };

    const loadApproval = async () => {
        let response;
        try {
            response = await fetch(`/api/approval?token=${encodeURIComponent(token)}`, { headers: { Accept: "application/json" } });
        } catch (error) {
            error.networkFailure = true;
            throw error;
        }
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
            const error = new Error(data.error || "This proposal is unavailable.");
            error.serverRejected = true;
            throw error;
        }
        return data;
    };

    loadApproval().then((data) => {
        remoteApprovalAvailable = true;
        localLead = readLocalLead();
        if (localLead) renderLocalProposal(localLead);
        if (!localLead) {
            title.textContent = `Proposal revision ${data.approval.revision}`;
            intro.textContent = "Review the proposed website improvements and share your decision below.";
        }
        setDisabled(false);
    }).catch((error) => {
        localLead = readLocalLead();
        // A local proposal is only a fallback for an unavailable network, never for
        // a server-rejected token that may be expired, revoked, or already used.
        localFallbackAllowed = Boolean(error.networkFailure && isLocalToken && localLead);
        if (localFallbackAllowed) {
            renderLocalProposal(localLead);
            setDisabled(false);
        } else {
            title.textContent = error.message || "This proposal is unavailable.";
            setDisabled(true);
        }
    });

    buttons.forEach((button) => button.addEventListener("click", async () => {
        setDisabled(true);
        const status = button.dataset.status;
        try {
            if (localFallbackAllowed && localLead && typeof window.workspaceCRM?.updateProposalResponse === "function") {
                window.workspaceCRM.updateProposalResponse(localLead.id, status === "accepted" ? "accepted" : "declined", { contractNotes: comment.value });
                message.textContent = status === "accepted" ? "Thank you. Your proposal was approved and project handoff is starting." : "Your change request was saved. We will follow up with an updated proposal.";
                buttons.forEach((item) => item.remove());
                return;
            }
            if (!remoteApprovalAvailable) throw new Error("This proposal is unavailable.");
            const current = await loadApproval();
            const response = await fetch(`/api/approval?token=${encodeURIComponent(token)}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                    "Idempotency-Key": globalThis.crypto?.randomUUID?.() || `proposal-${Date.now()}-${Math.random().toString(36).slice(2)}`
                },
                body: JSON.stringify({ status: status === "accepted" ? "approved" : "changes-requested", comment: comment.value, updatedAt: current.approval.updated_at })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Could not save your response.");
            message.textContent = status === "accepted" ? "Thank you. Your proposal was approved and project handoff is starting." : "Your change request was sent. We will follow up with an updated proposal.";
            buttons.forEach((item) => item.remove());
        } catch (error) {
            message.textContent = error.message || "Could not save your response.";
            setDisabled(true);
        }
    }));
})();
