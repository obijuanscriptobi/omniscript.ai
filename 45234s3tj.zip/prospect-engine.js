"use strict";
(() => {
    const BASE_KEY = "morrow-prospect-engine-v1";
    const KEY = window.workspaceContext?.storageKey?.(BASE_KEY) || BASE_KEY;
    const $ = (id) => document.getElementById(id);
    const load = () => { try { const value = JSON.parse(localStorage.getItem(KEY) || "{}"); return { market: value.market || {}, prospects: Array.isArray(value.prospects) ? value.prospects : [], offers: Array.isArray(value.offers) && value.offers.length ? value.offers : defaultOffers() }; } catch (_) { return { market: {}, prospects: [], offers: defaultOffers() }; } };
    const PIPELINE = ["new", "verified", "contacted", "replied", "qualified", "won", "lost"];
    const cloudProject = () => window.supabaseWorkspace?.getState?.()?.projectId || "";
    const cloudEnabled = () => Boolean(window.supabaseWorkspace?.getState?.()?.authenticated && cloudProject());
    async function cloudRequest(method, payload = {}, id = "") { const token = window.supabaseWorkspace?.getAccessToken?.(); if (!token || !cloudProject()) throw new Error("Sign in and select a cloud project to save leads in the cloud."); const query = new URLSearchParams({ projectId: cloudProject() }); if (id) query.set("id", id); const response = await fetch(`/api/leads?${query}`, { method, headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" }, body: method === "GET" || method === "DELETE" ? undefined : JSON.stringify({ ...payload, projectId: cloudProject() }) }); const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || "Lead storage request failed."); return data; }
    function qualification() { const ratingValue = Number($("research-min-rating")?.value); const reviewsValue = Number($("research-min-reviews")?.value); const gapValue = Number($("research-min-website-gap")?.value); return { minRating: Number.isFinite(ratingValue) ? ratingValue : 4.5, minReviews: Number.isFinite(reviewsValue) ? reviewsValue : 0, minWebsiteGap: Number.isFinite(gapValue) ? gapValue : 55, area: text($("research-area")?.value) }; }
    function qualificationPass(prospect) { const q = state.market.qualification || qualification(); const rating = Number(prospect.ratingSignal || 0); const reviews = Number(prospect.reviewCountSignal || 0); const hasRatingEvidence = prospect.ratingEvidence?.confidence === "direct"; const hasReviewEvidence = prospect.reviewEvidence?.confidence === "direct"; const hasUsableContact = Boolean(prospect.companyPhone || prospect.workEmail); return rating >= q.minRating && reviews >= q.minReviews && Number(prospect.websiteAudit?.score || 0) >= q.minWebsiteGap && hasUsableContact && (q.minRating <= 0 || (rating > 0 && hasRatingEvidence)) && (q.minReviews <= 0 || (reviews > 0 && hasReviewEvidence)); }
    function cloudPayload(prospect) { return { name: prospect.name, email: prospect.workEmail || prospect.personalEmail || "", phone: prospect.companyPhone || prospect.ownerPhone || "", message: JSON.stringify({ prospect }), status: PIPELINE.includes(prospect.status) ? prospect.status : "new", source: "prospect-engine", campaign: prospect.sourceUrl || "public-research", notes: prospect.notes || "", reminderAt: prospect.followUpAt || null }; }
    function hydrateCloudLead(item) { try { const parsed = JSON.parse(item.message || "{}"); return { ...(parsed.prospect || {}), id: `cloud-${item.id}`, cloudId: item.id, name: item.name || parsed.prospect?.name || "", workEmail: item.email || parsed.prospect?.workEmail || "", companyPhone: item.phone || parsed.prospect?.companyPhone || "", status: PIPELINE.includes(item.status) ? item.status : "new", notes: item.notes || parsed.prospect?.notes || "", followUpAt: item.reminder_at || parsed.prospect?.followUpAt || "", savedAt: item.updated_at || item.created_at }; } catch (_) { return null; } }
    async function loadCloudProspects() { if (!cloudEnabled()) return; try { const data = await cloudRequest("GET", {}); const cloud = (data.leads || []).map(hydrateCloudLead).filter(Boolean); const localByKey = new Map(state.prospects.map((item) => [domainOf(item.website || item.sourceUrl) || normalizedName(item.name), item])); cloud.forEach((item) => { const key = domainOf(item.website || item.sourceUrl) || normalizedName(item.name); const local = localByKey.get(key); if (local) Object.assign(local, item); else state.prospects.push(item); }); save(); renderQueue(); } catch (_) {} }
    async function persistProspect(prospect) { if (!cloudEnabled()) return; try { const data = await cloudRequest("POST", cloudPayload(prospect)); if (data.lead?.id) prospect.cloudId = data.lead.id; } catch (error) { prospect.cloudSaveError = error.message; } }
    async function updateCloudProspect(prospect) { if (!cloudEnabled() || !prospect.cloudId) return; try { await cloudRequest("PATCH", { status: PIPELINE.includes(prospect.status) ? prospect.status : "new", notes: prospect.notes || "", reminderAt: prospect.followUpAt || null, message: JSON.stringify({ prospect }) }, prospect.cloudId); prospect.cloudSaveError = ""; } catch (error) { prospect.cloudSaveError = error.message; } }
    let state = load();
    const selectedProspects = new Set();
    let auditController = null;
    const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (_) {} };
    const id = () => globalThis.crypto?.randomUUID?.() || `prospect-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const text = (value) => String(value || "").trim();
    const daysSince = (value) => value ? Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 86400000)) : Infinity;
    function scoreBreakdown(prospect) {
        const rating = Number(prospect.ratingSignal || 0);
        const reviews = Number(prospect.reviewCountSignal || 0);
        const demand = Math.min(20, Math.round((rating / 5) * 12 + Math.min(8, Math.log10(Math.max(1, reviews)) * 3)));
        const websiteGap = Math.min(20, Math.round(Number(prospect.websiteAudit?.score || prospect.opportunity || 0) / 5));
        const contactability = Math.min(20, (prospect.companyPhone ? 8 : 0) + (prospect.workEmail ? 8 : 0) + ((prospect.socials || []).length ? 4 : 0));
        const fit = Math.min(20, Number(prospect.fit || 0));
        const websiteAge = daysSince(prospect.websiteAudit?.checkedAt || prospect.verificationCheckedAt || prospect.createdAt);
        const contactAge = daysSince(prospect.contactCheckedAt || prospect.verificationCheckedAt || prospect.createdAt);
        const reputationAge = daysSince(prospect.reputationCheckedAt || prospect.verificationCheckedAt || prospect.createdAt);
        const freshness = Math.round(((websiteAge <= 30 ? 20 : websiteAge <= 60 ? 10 : 2) + (contactAge <= 60 ? 20 : contactAge <= 90 ? 10 : 2) + (reputationAge <= 30 ? 20 : reputationAge <= 60 ? 10 : 2)) / 3);
        return { demand, websiteGap, contactability, fit, freshness };
    }
    const score = (prospect) => Object.values(scoreBreakdown(prospect)).reduce((sum, value) => sum + value, 0);
    function freshnessLabel(value, recheckDays, staleDays, subject) {
        const age = daysSince(value);
        if (!Number.isFinite(age)) return `${subject}: not verified`;
        if (age > staleDays) return `${subject}: stale (${age} days)`;
        if (age > recheckDays) return `${subject}: Recheck recommended (${age} days)`;
        return `${subject}: verified ${age === 0 ? "today" : `${age} day${age === 1 ? "" : "s"} ago`}`;
    }
    function evidenceFreshness(prospect) {
        const websiteAge = daysSince(prospect.websiteAudit?.checkedAt || prospect.verificationCheckedAt);
        const contactAge = daysSince(prospect.contactCheckedAt || prospect.verificationCheckedAt);
        const reputationAge = daysSince(prospect.reputationCheckedAt || prospect.verificationCheckedAt);
        return {
            label: [
                freshnessLabel(prospect.websiteAudit?.checkedAt || prospect.verificationCheckedAt, 30, 60, "Website"),
                freshnessLabel(prospect.contactCheckedAt || prospect.verificationCheckedAt, 60, 90, "Contact"),
                freshnessLabel(prospect.reputationCheckedAt || prospect.verificationCheckedAt, 30, 60, "Reputation")
            ].join(" · "),
            stale: websiteAge > 30 || contactAge > 60 || reputationAge > 30
        };
    }
    function verificationLabel(prospect) { return prospect.verificationStatus === "verified-opportunity" && prospect.qualificationPassed ? "Verified opportunity" : prospect.verificationStatus === "needs-review" ? "Needs review" : "Unverified"; }
    function statusLabel(status) { return ({ new: "New", verified: "Verified", contacted: "Contacted", replied: "Replied", qualified: "Qualified", won: "Won", lost: "Lost" })[status] || "New"; }
    function renderPipeline(prospect) { return `<label class="pipeline-control">Stage <select data-stage-prospect="${escapeHtml(prospect.id)}">${PIPELINE.map((status) => `<option value="${status}" ${prospect.status === status ? "selected" : ""}>${statusLabel(status)}</option>`).join("")}</select></label><label class="pipeline-control">Follow-up <input type="datetime-local" data-followup-prospect="${escapeHtml(prospect.id)}" value="${escapeHtml(prospect.followUpAt ? new Date(prospect.followUpAt).toISOString().slice(0,16) : "")}"></label><label class="pipeline-control">Notes <textarea data-notes-prospect="${escapeHtml(prospect.id)}" rows="2" placeholder="Sales notes">${escapeHtml(prospect.notes || "")}</textarea></label><button type="button" class="leads-button secondary" data-save-prospect="${escapeHtml(prospect.id)}">Save pipeline details</button>`; }
    function verificationClass(prospect) { return prospect.verificationStatus === "verified-opportunity" ? "verified-opportunity" : prospect.verificationStatus === "needs-review" ? "needs-review" : "unverified"; }
    function websiteVerification(analysis) {
        const textBlob = `${analysis?.title || ""} ${(analysis?.headings || []).map((item) => item.text).join(" ")}`.toLowerCase();
        const links = Array.isArray(analysis?.links) ? analysis.links : [];
        const bookingLinks = Number(analysis?.bookingLinks || 0);
        const forms = Number(analysis?.forms || 0);
        const mobileSignals = /mobile|responsive|viewport/.test(textBlob);
        const weakSignals = /outdated|old website|under construction|welcome to|no website|coming soon/.test(textBlob);
        const missingConversionPath = !bookingLinks && !forms;
        const score = Math.min(100, (weakSignals ? 35 : 12) + (missingConversionPath ? 25 : 5) + (!mobileSignals ? 20 : 5) + (links.length < 8 ? 12 : 3));
        return { score, weakSignals, missingConversionPath, mobileSignals, pageCount: Number(analysis?.pageCount || 0) };
    }
    function applyVerification(prospect, analysis) {
        const audit = websiteVerification(analysis);
        prospect.verificationSourceUrl = prospect.website || prospect.sourceUrl || "";
        prospect.verificationCheckedAt = new Date().toISOString();
        prospect.websiteAudit = { ...audit, sourceUrl: prospect.verificationSourceUrl, checkedAt: prospect.verificationCheckedAt, evidence: [audit.weakSignals ? "Weak/outdated language detected" : "No explicit weak-language signal", audit.missingConversionPath ? "No booking or enquiry path detected" : "Booking or enquiry path detected", audit.mobileSignals ? "Mobile/responsive signal detected" : "No mobile/responsive signal detected", `Analysed ${audit.pageCount || 0} public page(s)`] };
        const reputation = analysis?.reputation || {};
        if (reputation.rating) { prospect.ratingSignal = reputation.rating; prospect.ratingEvidence = { source: prospect.verificationSourceUrl, text: `${reputation.rating}/5 from audited public website`, confidence: "direct" }; }
        if (reputation.reviewCount) { prospect.reviewCountSignal = reputation.reviewCount; prospect.reviewEvidence = { source: prospect.verificationSourceUrl, text: `${reputation.reviewCount} reviews from audited public website`, confidence: "direct" }; }
        if (prospect.companyPhone || prospect.workEmail) prospect.contactCheckedAt = prospect.verificationCheckedAt;
        if (reputation.rating || reputation.reviewCount) prospect.reputationCheckedAt = prospect.verificationCheckedAt;
        prospect.qualificationPassed = qualificationPass({ ...prospect, websiteAudit: prospect.websiteAudit });
        prospect.verificationStatus = audit.score >= 55 && Number(prospect.ratingSignal || 0) >= 4.5 && prospect.qualificationPassed ? "verified-opportunity" : "needs-review";
        if (prospect.verificationStatus === "verified-opportunity") prospect.status = "verified";
        prospect.verificationCheckedAt = new Date().toISOString();
        prospect.opportunity = Math.min(20, Math.max(1, Math.round(audit.score / 5)));
        prospect.opportunityScore = score(prospect);
        prospect.signals = [...(prospect.signals || []), evidence(`Website verification score: ${audit.score}/100; ${audit.missingConversionPath ? "no obvious booking or enquiry path" : "a conversion path was found"}.`, "website verification")];
        prospect.reason = `${Number(prospect.ratingSignal || 0) >= 4.5 ? `Visible rating signal: ${prospect.ratingSignal}/5. ` : "Rating needs verification. "}${audit.score >= 55 ? "Website audit found meaningful conversion or quality gaps. " : "Website audit found possible gaps, but the opportunity needs manual review. "}Confirm the public evidence before outreach.`;
        return prospect;
    }
    function defaultOffers() { return [
        { id: "website-launch", name: "Website launch package", price: "Fixed price", delivery: "2–3 weeks", revisions: "2 rounds" },
        { id: "mobile-rebuild", name: "Mobile conversion rebuild", price: "Fixed price", delivery: "5–10 days", revisions: "1 round" },
        { id: "care-plan", name: "Monthly optimization plan", price: "Monthly", delivery: "Ongoing", revisions: "Monthly review" }
    ]; }
    function escapeHtml(value) { return text(value).replace(/[&<>\"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[char])); }
    function evidence(value, kind = "observation") { return { text: text(value), kind, source: "Entered by you", researchedAt: new Date().toISOString() }; }
    function renderMarket() {
        const fields = { industry: "research-industry", location: "research-location", size: "research-size", count: "research-count", traits: "research-traits", minRating: "research-min-rating", minReviews: "research-min-reviews", minWebsiteGap: "research-min-website-gap", area: "research-area" };
        Object.entries(fields).forEach(([key, id]) => { const field = $(id); if (field && state.market[key] && !field.value) field.value = state.market[key]; });
    }
    function matchesActiveFilters(prospect) {
        const filterStatus = text($("prospect-filter-status")?.value);
        const filterScore = Number($("prospect-filter-score")?.value || 0);
        const filterLocation = text($("prospect-filter-location")?.value).toLowerCase();
        const filterVerification = text($("prospect-filter-verification")?.value);
        return (!filterStatus || prospect.status === filterStatus || (filterStatus === "needs-review" && prospect.verificationStatus === "needs-review")) && score(prospect) >= filterScore && (!filterLocation || text(prospect.location).toLowerCase().includes(filterLocation)) && (!filterVerification || verificationClass(prospect) === filterVerification);
    }
    function getVisibleProspects() { return state.prospects.filter(matchesActiveFilters).sort((a, b) => score(b) - score(a)); }
    function selectedVisibleProspects() { return getVisibleProspects().filter((prospect) => selectedProspects.has(prospect.id)); }
    function updateSelectionCount() { const node = $("prospect-selected-count"); if (node) node.textContent = `${selectedProspects.size} selected`; }
    function renderQueue() {
        const root = $("prospect-queue"); if (!root) return;
        const sorted = getVisibleProspects();
        root.replaceChildren(...(sorted.length ? sorted.map((prospect, index) => {
            const card = document.createElement("article"); card.className = "prospect-card";
            const signals = (prospect.signals || []).filter(Boolean).map((item) => `<li><span class="evidence-${escapeHtml(item.kind)}">${escapeHtml(item.kind)}</span> ${escapeHtml(item.text)}</li>`).join("");
            const phone = prospect.ownerPhone || prospect.companyPhone;
            const phoneLabel = prospect.ownerPhone ? "Owner phone · publicly listed" : "Company phone";
            const verification = verificationLabel(prospect);
            const socials = (prospect.socials || []).map((url) => `<a href="${escapeHtml(url)}" target="_blank" rel="noopener">${escapeHtml(url)}</a>`).join(" · ");
            const breakdown = scoreBreakdown(prospect);
            const freshness = evidenceFreshness(prospect);
            card.innerHTML = `<label class="prospect-select"><input type="checkbox" data-select-prospect="${escapeHtml(prospect.id)}" ${selectedProspects.has(prospect.id) ? "checked" : ""}> Select ${escapeHtml(prospect.name)}</label><details class="prospect-details"><summary><div class="prospect-card-heading"><div><span class="prospect-rank">#${index + 1}</span><h3>${escapeHtml(prospect.name)}</h3><p>${escapeHtml(prospect.industry || "Business")} · ${escapeHtml(prospect.location || "Location not set")}</p><span class="verification-badge ${verificationClass(prospect)}">${escapeHtml(verification)}</span>${prospect.possibleDuplicateOf ? `<p class="possible-duplicate">Possible duplicate of ${escapeHtml(prospect.possibleDuplicateOf)}</p>` : ""}</div><strong class="prospect-score">${score(prospect)}<small>/100</small></strong></div></summary><div class="prospect-card-body"><div class="score-breakdown" aria-label="Opportunity score breakdown"><span><strong>${breakdown.demand}/20</strong>Demand</span><span><strong>${breakdown.websiteGap}/20</strong>Website gap</span><span><strong>${breakdown.contactability}/20</strong>Contact</span><span><strong>${breakdown.fit}/20</strong>Fit</span><span><strong>${breakdown.freshness}/20</strong>Freshness</span></div><p class="evidence-freshness ${freshness.stale ? "is-stale" : ""}">${escapeHtml(freshness.label)}</p><dl class="prospect-contact-grid"><div><dt>${escapeHtml(phoneLabel)}</dt><dd>${phone ? `<a href="tel:${escapeHtml(phone)}">${escapeHtml(phone)}</a>` : "Not publicly found"}</dd></div><div><dt>Work email</dt><dd>${prospect.workEmail ? `<a href="mailto:${escapeHtml(prospect.workEmail)}">${escapeHtml(prospect.workEmail)}</a>` : "Not publicly found"}</dd></div><div><dt>Personal email · public only</dt><dd>${prospect.personalEmail ? `<a href="mailto:${escapeHtml(prospect.personalEmail)}">${escapeHtml(prospect.personalEmail)}</a>` : "Not publicly found"}</dd></div><div><dt>Location</dt><dd>${escapeHtml(prospect.location || "Not publicly found")}</dd></div><div><dt>Website</dt><dd>${prospect.website ? `<a href="${escapeHtml(prospect.website)}" target="_blank" rel="noopener">${escapeHtml(prospect.website)}</a>` : "Not publicly found"}</dd></div><div><dt>Social profiles</dt><dd>${socials || "Not publicly found"}</dd></div></dl><p class="prospect-reason"><strong>Why contact now:</strong> ${escapeHtml(prospect.reason || "Review the public signals and confirm the opportunity.")}</p>${prospect.websiteAudit ? `<p class="verification-summary"><strong>Website verification:</strong> ${prospect.websiteAudit.score}/100 · ${prospect.websiteAudit.missingConversionPath ? "No obvious booking or enquiry path" : "Conversion path detected"} · ${prospect.websiteAudit.mobileSignals ? "Mobile signals found" : "Mobile quality needs review"} · Checked ${escapeHtml(new Date(prospect.websiteAudit.checkedAt || prospect.verificationCheckedAt).toLocaleString())} · <a href="${escapeHtml(prospect.websiteAudit.sourceUrl || prospect.website)}" target="_blank" rel="noopener">Source</a><br>${(prospect.websiteAudit.evidence || []).map(escapeHtml).join(" · ")}</p>` : ""}<ul class="prospect-signals">${signals || "<li>Research signals have not been added yet.</li>"}</ul><div class="prospect-card-actions"><button type="button" class="leads-button" data-open-prospect="${escapeHtml(prospect.id)}">Open brief</button><button type="button" class="leads-button secondary" data-import-audit="${escapeHtml(prospect.id)}">Import site to audit</button><button type="button" class="leads-button secondary" data-call-prospect="${escapeHtml(prospect.id)}">Open call cockpit</button></div><div class="prospect-feedback"><label>Search feedback <select data-feedback-prospect="${escapeHtml(prospect.id)}"><option value="">Choose feedback</option><option value="good-fit">Good fit</option><option value="wrong-industry">Wrong industry</option><option value="too-large">Too large</option><option value="duplicate">Duplicate</option><option value="weak-evidence">Weak evidence</option><option value="low-opportunity">Not enough website opportunity</option></select></label><button type="button" class="leads-button secondary" data-save-feedback="${escapeHtml(prospect.id)}">Save feedback</button></div><div class="prospect-pipeline">${renderPipeline(prospect)}</div></div></details>`;
            return card;
        }) : [Object.assign(document.createElement("p"), { className: "leads-help", textContent: "Add a prospect to build your prioritized call list." })]));
        const next = sorted[0]; const action = $("next-best-action"); if (action) action.textContent = next ? `Call ${next.name} — ${score(next)}/100 priority. ${next.reason || "Review the evidence before reaching out."}` : "Set your target market and add the first prospect to get a next best action.";
        updateSelectionCount();
    }
    function importSiteToAudit(prospect) {
        const website = normalizeUrl(prospect?.website);
        if (!website) return;
        const projectId = cloudProject();
        const audit = window.websiteAuditContract?.upsert({
            leadId: prospect.id,
            projectId,
            websiteUrl: website,
            state: "not-audited",
            sourceEvidence: { businessName: prospect.name, industry: prospect.industry, location: prospect.location, phone: prospect.companyPhone, email: prospect.workEmail, rating: prospect.ratingSignal, reviewCount: prospect.reviewCountSignal, ratingEvidence: prospect.ratingEvidence, reviewEvidence: prospect.reviewEvidence, sourceUrl: prospect.sourceUrl || website }
        });
        const params = new URLSearchParams({ url: website, leadId: prospect.id });
        if (projectId) params.set("projectId", projectId);
        if (audit?.id) params.set("auditId", audit.id);
        window.location.href = `audit.html?${params.toString()}`;
    }
    function renderBrief(prospect) {
        const panel = $("prospect-brief-panel"); if (!panel || !prospect) return;
        panel.hidden = false; panel.dataset.prospectId = prospect.id;
        const offer = state.offers[0];
        $("prospect-brief-content").innerHTML = `<div class="brief-header"><div><p class="leads-eyebrow">Evidence-aware prospect brief</p><h2>${escapeHtml(prospect.name)}</h2><p>${escapeHtml(prospect.summary || "Business summary needs confirmation.")}</p></div><strong>${score(prospect)}/100</strong></div><dl class="brief-grid"><div><dt>Public contact</dt><dd>${escapeHtml(prospect.contact || "Needs confirmation")}</dd></div><div><dt>Website</dt><dd>${prospect.website ? `<a href="${escapeHtml(prospect.website)}" target="_blank" rel="noopener">${escapeHtml(prospect.website)}</a>` : "Needs confirmation"}</dd></div><div><dt>Likely customer</dt><dd>${escapeHtml(prospect.customer || "Needs confirmation")}</dd></div><div><dt>Recommended offer</dt><dd>${escapeHtml(offer?.name || "Choose an offer")}</dd></div></dl><h3>Suggested opening line</h3><p class="script-block">Hi ${escapeHtml(prospect.contactName || prospect.name)}, I noticed ${escapeHtml(prospect.reason || "a few opportunities on your public customer path")}. I put together a quick review—would it be useful to compare notes for two minutes?</p><p class="evidence-note">Verified details are entered by you. Observations must be checked before sending. Researched ${new Date().toLocaleDateString()}.</p>`;
    }
    function openCockpit(prospect) { const panel = $("call-cockpit-panel"); if (!panel || !prospect) return; panel.hidden = false; panel.dataset.prospectId = prospect.id; $("call-cockpit-title").textContent = `Call cockpit · ${prospect.name}`; $("call-objective").textContent = prospect.reason || "Confirm whether the opportunity is relevant."; $("call-notes").value = prospect.callNotes || ""; panel.scrollIntoView({ behavior: "smooth", block: "start" }); }
    function renderOffers() { const root = $("offer-list"); if (!root) return; root.replaceChildren(...state.offers.map((offer) => { const item = document.createElement("li"); item.innerHTML = `<strong>${escapeHtml(offer.name)}</strong><span>${escapeHtml(offer.price)} · ${escapeHtml(offer.delivery)} · ${escapeHtml(offer.revisions)}</span>`; return item; })); }
    function normalizeUrl(value) { const raw = text(value); if (!raw) return ""; try { const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`); url.hash = ""; return ["http:", "https:"].includes(url.protocol) ? url.href.replace(/\/$/, "") : ""; } catch (_) { return ""; } }
    function normalizedName(value) { return text(value).toLowerCase().replace(/\b(incorporated|inc|llc|ltd|limited|company|co)\b/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
    function domainOf(value) { try { return new URL(normalizeUrl(value)).hostname.replace(/^www\./i, "").toLowerCase(); } catch (_) { return ""; } }
    function normalizedPhone(value) { return text(value).replace(/\D/g, "").replace(/^1(?=\d{10}$)/, "").slice(-10); }
    function socialIds(values = []) { return new Set(values.map((value) => { try { const url = new URL(normalizeUrl(value)); return `${url.hostname.replace(/^www\./, "")}${url.pathname.replace(/\/$/, "").toLowerCase()}`; } catch (_) { return ""; } }).filter(Boolean)); }
    function duplicateMatch(candidate, prospects = state.prospects) {
        const domain = domainOf(candidate.canonicalUrl || candidate.website || candidate.sourceUrl);
        const phone = normalizedPhone(candidate.companyPhone || candidate.ownerPhone);
        const nameArea = `${normalizedName(candidate.name)}|${text(candidate.location).toLowerCase()}`;
        const socials = socialIds(candidate.socials);
        return prospects.find((item) => {
            if (domain && domain === domainOf(item.canonicalUrl || item.website || item.sourceUrl)) return true;
            if (phone && phone === normalizedPhone(item.companyPhone || item.ownerPhone)) return true;
            if (nameArea !== "|" && nameArea === `${normalizedName(item.name)}|${text(item.location).toLowerCase()}`) return true;
            const existingSocials = socialIds(item.socials);
            return [...socials].some((social) => existingSocials.has(social));
        });
    }
    function resultName(result) { return text(result.title).split(" | ")[0].split(" - ")[0].replace(/\s+\|\s+.*$/, "").trim().slice(0, 180); }
    function contactFromResult(result) { const blob = `${result.title || ""} ${result.description || ""}`; const emails = [...new Set(blob.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [])]; const phones = [...new Set(blob.match(/(?:\+?\d[\d\s().-]{7,}\d)/g) || [])]; return { emails, phones }; }
    function relevantResult(result, location, area = "") { const haystack = `${result.title || ""} ${result.description || ""} ${result.url || ""}`.toLowerCase(); const locationTerms = `${text(location)} ${text(area)}`.toLowerCase().split(/[^a-z0-9]+/).filter((term) => term.length > 2 && !["within", "miles", "mile", "radius", "of"].includes(term)); return !locationTerms.length || locationTerms.some((term) => haystack.includes(term)); }
    function opportunitySignals(result) { const blob = `${result.title || ""} ${result.description || ""}`.toLowerCase(); const rating = blob.match(/([45](?:\.\d)?)\s*(?:\/\s*5|stars?|out of 5)/i); const reviewCount = blob.match(/([\d,]+)\s*(?:reviews?|ratings?)/i); const directory = /facebook\.com|instagram\.com|yelp\.com|yellowpages|mapquest|tripadvisor|bbb\.org|directory/i.test(blob); const franchise = /franchise|franchising|locations nationwide|multiple locations/i.test(blob); const weakWebsite = /no website|outdated|mobile|slow|old website|poor website|under construction|coming soon/i.test(blob) || directory; return { rating: rating ? Number(rating[1]) : 0, reviewCount: reviewCount ? Number(reviewCount[1].replace(/,/g, "")) : 0, weakWebsite, directory, franchise, ratingEvidence: rating ? `${rating[0]} from public search result` : "", reviewEvidence: reviewCount ? `${reviewCount[0]} from public search result` : "" }; }
    function opportunityScore(result, contact) { const signals = opportunitySignals(result); return Math.min(100, Math.round((signals.rating >= 4.8 ? 30 : signals.rating >= 4.5 ? 24 : signals.rating >= 4 ? 15 : 5) + Math.min(20, Math.log10(Math.max(1, signals.reviewCount)) * 8) + (signals.weakWebsite ? 28 : 10) + (contact.phones.length || contact.emails.length ? 12 : 4))); }
    function enrichProspect(prospect, result, analysis) { const contact = analysis?.contact || contactFromResult(result); const links = Array.isArray(analysis?.links) ? analysis.links : []; const socials = links.filter((url) => /linkedin\.com|facebook\.com|instagram\.com|x\.com|twitter\.com|youtube\.com|tiktok\.com/i.test(url)); prospect.summary = prospect.summary || text(analysis?.title) || text(result.description); prospect.signals = [...(prospect.signals || []), evidence(text(result.description) || "Public page reviewed", "public page")]; prospect.companyPhone = prospect.companyPhone || contact.phones?.[0] || ""; prospect.workEmail = prospect.workEmail || contact.emails?.[0] || ""; prospect.socials = [...new Set([...(prospect.socials || []), ...socials])].slice(0, 12); prospect.sourceUrl = prospect.sourceUrl || result.url; prospect.researchStatus = "public-source-reviewed"; return prospect; }
    async function scrapePublicProfile(prospect, result, attempt = 0, signal) { try { const controller = new AbortController(); const abort = () => controller.abort(); signal?.addEventListener("abort", abort, { once: true }); const timer = setTimeout(() => controller.abort(), 18000); const response = await fetch(`/api/scrape?url=${encodeURIComponent(result.url)}`, { headers: { Accept: "application/json" }, signal: controller.signal }); clearTimeout(timer); signal?.removeEventListener("abort", abort); const data = await response.json().catch(() => ({})); if (response.ok && data.analysis) { enrichProspect(prospect, result, data.analysis); prospect.canonicalUrl = normalizeUrl(data.analysis.canonicalUrl || data.analysis.url || result.url); applyVerification(prospect, { ...data.analysis, pageCount: data.import?.pageCount }); prospect.verificationError = ""; } else { const error = new Error(data.error || `Website audit failed (${response.status})`); error.retryable = response.status === 429 || response.status >= 500; error.retryAfter = Number(response.headers.get("retry-after") || data.retryAfter || 0); throw error; } } catch (error) { if (error.name === "AbortError" && signal?.aborted) { prospect.verificationError = "Audit cancelled"; return; } if (attempt < 2 && (error.retryable || error.name === "AbortError")) { const delay = Math.max(error.retryAfter * 1000, 500 * (2 ** attempt)); await new Promise((resolve) => setTimeout(resolve, delay)); return scrapePublicProfile(prospect, result, attempt + 1, signal); } prospect.verificationStatus = "needs-review"; prospect.verificationError = error.name === "AbortError" ? "Audit timed out" : error.message || "Audit unavailable"; prospect.verificationCheckedAt = new Date().toISOString(); } }
    async function runAuditQueue(targets, resultFor, status) {
        auditController?.abort(); auditController = new AbortController();
        const cancel = $("cancel-audits-btn"); if (cancel) cancel.disabled = false;
        let completed = 0; let cursor = 0;
        const worker = async () => { while (cursor < targets.length && !auditController.signal.aborted) { const index = cursor++; const prospect = targets[index]; await scrapePublicProfile(prospect, resultFor(prospect, index), 0, auditController.signal); completed += 1; if (status) status.textContent = `Audited ${completed} of ${targets.length}${prospect.verificationError ? ` · ${prospect.verificationError}` : ""}`; save(); renderQueue(); } };
        await Promise.all(Array.from({ length: Math.min(3, targets.length) }, worker));
        if (cancel) cancel.disabled = true;
        const cancelled = auditController.signal.aborted; auditController = null;
        return { completed, cancelled };
    }
    async function verifyProspects() {
        const status = $("prospect-scan-status"); const button = $("verify-prospects-btn"); const targets = getVisibleProspects().filter((prospect) => prospect.website && prospect.verificationStatus !== "verified-opportunity").slice(0, 20);
        if (!targets.length) { if (status) status.textContent = "No unverified websites need checking."; return; }
        if (button) button.disabled = true; if (status) status.textContent = `Auditing ${targets.length} public websites…`;
        const result = await runAuditQueue(targets, (prospect) => ({ url: prospect.website, description: "Website audited" }), status);
        const verified = targets.filter((prospect) => prospect.verificationStatus === "verified-opportunity").length;
        await Promise.all(targets.map(updateCloudProspect)); save(); renderQueue(); if (status) status.textContent = result.cancelled ? `Audit cancelled after ${result.completed} of ${targets.length}. Partial results were saved.` : `Verified ${verified} high-opportunity website${verified === 1 ? "" : "s"}. Other leads remain marked for manual review.`; if (button) button.disabled = false;
    }
    function addScannedProspect(result, index) { const contact = contactFromResult(result); const website = normalizeUrl(result.url); const signals = opportunitySignals(result); const priority = opportunityScore(result, contact); const name = resultName(result) || `Public prospect ${index + 1}`; return { id: id(), name, contactName: "", companyPhone: contact.phones[0] || "", ownerPhone: "", workEmail: contact.emails[0] || "", personalEmail: "", contact: "", location: text($("research-location")?.value), website, socials: [], industry: "", customer: "", summary: text(result.description), reason: `${signals.rating >= 4.5 ? `Strong visible rating (${signals.rating}/5). ` : "Review strength needs verification. "}${signals.weakWebsite ? "Public signals suggest a weak or limited website presence. " : "Website opportunity needs a direct audit. "}Prioritize businesses with clear demand and a credible redesign opportunity.`, fit: 18, urgency: signals.weakWebsite ? 17 : 10, value: 16, access: contact.phones.length || contact.emails.length ? 14 : 7, opportunity: Math.round(priority / 5), signals: [evidence(result.description || "Public search result found", "search result"), evidence(signals.rating >= 4.5 ? `Visible rating signal: ${signals.rating}/5` : "No reliable rating found in this result", "reputation"), evidence(signals.weakWebsite ? "Possible weak website or directory-only presence" : "Website quality requires an audit", "website opportunity")], sourceUrl: website, createdAt: new Date().toISOString(), status: "new", opportunityScore: priority, ratingSignal: signals.rating, reviewCountSignal: signals.reviewCount, ratingEvidence: signals.ratingEvidence ? { source: result.url, text: signals.ratingEvidence, confidence: "snippet" } : null, reviewEvidence: signals.reviewEvidence ? { source: result.url, text: signals.reviewEvidence, confidence: "snippet" } : null, sourceType: signals.directory ? "directory" : "business website", franchiseSignal: signals.franchise, verificationStatus: "unverified" }; }
    async function scanProspects() {
        const status = $("prospect-scan-status"); const button = $("scan-prospects-btn");
        const industry = text($("research-industry")?.value); const location = text($("research-location")?.value); const size = text($("research-size")?.value); const traits = text($("research-traits")?.value); const requested = Math.min(100, Math.max(1, Number($("research-count")?.value) || 10));
        const subject = industry || traits || size || "local business";
        const feedback = state.prospects.map((item) => item.searchFeedback?.value).filter(Boolean);
        const avoidLarge = feedback.includes("too-large") ? " independent owner operated" : "";
        const evidenceIntent = feedback.includes("weak-evidence") ? " official website contact" : "";
        const queries = [...new Set([`${subject}${avoidLarge} in ${location}`, `best ${subject} in ${location}`, `${subject} ${location} reviews`, `local ${subject} near ${location}`, `${traits || subject} business ${location}${evidenceIntent}`].map(text).filter(Boolean))];
        if (button) button.disabled = true; if (status) status.textContent = `Discovering candidates across ${queries.length} targeted searches…`;
        try {
            const searches = await Promise.allSettled(queries.map(async (query) => { const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`, { headers: { Accept: "application/json" } }); const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || "Public search is unavailable."); return Array.isArray(data.results) ? data.results : []; }));
            const batches = searches.filter((result) => result.status === "fulfilled").map((result) => result.value);
            const failedSearches = searches.length - batches.length;
            if (!batches.length) throw searches.find((result) => result.status === "rejected")?.reason || new Error("Public search is unavailable.");
            const seen = new Set(); const merged = batches.flat().filter((result) => { const key = domainOf(result.url) || `${normalizedName(resultName(result))}|${text(location).toLowerCase()}`; if (!key || seen.has(key)) return false; seen.add(key); return true; });
            const candidates = merged.filter((item) => { const website = normalizeUrl(item.url); const signals = opportunitySignals(item); return website && !signals.franchise && relevantResult(item, location, qualification().area); }).sort((a, b) => opportunityScore(b, contactFromResult(b)) - opportunityScore(a, contactFromResult(a))).slice(0, requested);
            const additions = candidates.map((candidate, index) => { const prospect = addScannedProspect(candidate, index); prospect.industry = industry; const duplicate = duplicateMatch(prospect, [...state.prospects, ...candidates.slice(0, index).map(addScannedProspect)]); if (duplicate) prospect.possibleDuplicateOf = duplicate.name; return prospect; });
            state.prospects.push(...additions);
            const auditResult = await runAuditQueue(additions, (_, index) => candidates[index], status);
            await Promise.all(additions.map(persistProspect));
            state.market = { industry, location, size, count: requested, traits, qualification: qualification() };
            save(); renderQueue();
            if (status) status.textContent = auditResult.cancelled ? `Discovery kept ${additions.length} candidates; auditing stopped after ${auditResult.completed}. Partial results were saved.` : `Discovered and enriched ${additions.length} candidate${additions.length === 1 ? "" : "s"} from ${merged.length} public results${failedSearches ? `; ${failedSearches} search${failedSearches === 1 ? "" : "es"} failed without discarding successful results` : ""}.`;
        } catch (error) { if (status) status.textContent = error.message || "Public search failed."; } finally { if (button) button.disabled = false; }
    }
    function addProspect(event) { event.preventDefault(); const form = event.currentTarget; if (!form.reportValidity()) return; const prospect = { id: id(), name: text($("prospect-name").value), contactName: text($("prospect-contact-name").value), companyPhone: text($("prospect-company-phone").value), ownerPhone: text($("prospect-owner-phone").value), workEmail: text($("prospect-work-email").value), personalEmail: text($("prospect-personal-email").value), contact: text($("prospect-contact").value), location: text($("prospect-business-location").value) || text($("research-location").value), website: text($("prospect-website").value), socials: text($("prospect-socials").value).split("\n").map(text).filter(Boolean), industry: "", customer: text($("prospect-customer").value), summary: text($("prospect-summary").value), reason: text($("prospect-reason").value), fit: $("score-fit").value, urgency: $("score-urgency").value, value: $("score-value").value, access: $("score-access").value, opportunity: $("score-opportunity").value, signals: text($("prospect-signals-input").value).split("\n").filter(Boolean).map((item) => evidence(item, "observation")), createdAt: new Date().toISOString(), status: "new", verificationStatus: "unverified" }; state.market = { industry: text($("research-industry").value), location: text($("research-location").value), size: text($("research-size").value), traits: text($("research-traits").value) }; state.prospects.push(prospect); save(); renderQueue(); renderMarket(); form.reset(); $("prospect-form-panel").hidden = true; renderBrief(prospect); }
    function exportCsv() { const headers = ["name", "status", "rating", "reviews", "website", "companyPhone", "workEmail", "location", "verification", "verificationSourceUrl", "verificationCheckedAt", "auditEvidence", "followUpAt", "notes"]; const selected = selectedVisibleProspects(); const exportTargets = selected.length ? selected : getVisibleProspects(); const rows = exportTargets.map((p) => headers.map((key) => key === "verification" ? verificationLabel(p) : key === "verificationSourceUrl" ? (p.websiteAudit?.sourceUrl || p.verificationSourceUrl || "") : key === "verificationCheckedAt" ? (p.websiteAudit?.checkedAt || p.verificationCheckedAt || "") : key === "auditEvidence" ? (p.websiteAudit?.evidence || []).join(" | ") : p[key] ?? "")); const csv = [headers, ...rows].map((row) => row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\n"); const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" })); link.download = `prospects-${new Date().toISOString().slice(0,10)}.csv`; link.click(); URL.revokeObjectURL(link.href); }
    async function savePipeline(event) { const id = event.target.dataset.saveProspect; const prospect = state.prospects.find((item) => item.id === id); if (!prospect) return; const card = event.target.closest(".prospect-card"); prospect.status = card.querySelector(`[data-stage-prospect="${CSS.escape(id)}"]`).value; prospect.followUpAt = card.querySelector(`[data-followup-prospect="${CSS.escape(id)}"]`).value ? new Date(card.querySelector(`[data-followup-prospect="${CSS.escape(id)}"]`).value).toISOString() : ""; prospect.notes = card.querySelector(`[data-notes-prospect="${CSS.escape(id)}"]`).value.trim(); save(); await updateCloudProspect(prospect); renderQueue(); }
    function saveNotes() { const panel = $("call-cockpit-panel"); const prospect = state.prospects.find((item) => item.id === panel?.dataset.prospectId); if (!prospect) return; prospect.callNotes = text($("call-notes").value); prospect.lastContactedAt = new Date().toISOString(); prospect.nextAction = "Review notes and schedule the next step"; save(); renderQueue(); $("call-status").textContent = "Notes saved locally. Confirm extracted fields before adding them to the CRM."; }
    $("research-market-form")?.addEventListener("submit", (event) => { event.preventDefault(); state.market = { industry: text($("research-industry")?.value), location: text($("research-location")?.value), size: text($("research-size")?.value), traits: text($("research-traits")?.value), qualification: qualification() }; save(); $("research-status").textContent = "Opportunity criteria saved. Discovery stays broad; enrichment verifies reputation, website weakness, and contactability."; });
    $("prospect-form")?.addEventListener("submit", addProspect);
    ["prospect-filter-status", "prospect-filter-score", "prospect-filter-location", "prospect-filter-verification"].forEach((filterId) => $(filterId)?.addEventListener("input", renderQueue));
    $("select-visible-btn")?.addEventListener("click", () => { getVisibleProspects().forEach((prospect) => selectedProspects.add(prospect.id)); renderQueue(); });
    $("clear-selected-btn")?.addEventListener("click", () => { selectedProspects.clear(); renderQueue(); });
    $("cancel-audits-btn")?.addEventListener("click", () => auditController?.abort());
    $("verify-selected-btn")?.addEventListener("click", async () => { const targets = selectedVisibleProspects().filter((p) => p.website); const status = $("prospect-scan-status"); if (!targets.length) { if (status) status.textContent = "Select at least one visible lead with a website."; return; } const result = await runAuditQueue(targets, (p) => ({ url: p.website, description: "Website audited" }), status); await Promise.all(targets.map(updateCloudProspect)); save(); renderQueue(); if (status) status.textContent = result.cancelled ? `Audit cancelled after ${result.completed} of ${targets.length}. Partial results were saved.` : `Completed ${result.completed} selected website audits. Failed audits remain Needs review.`; });
    $("mark-selected-btn")?.addEventListener("click", async () => { const selected = selectedVisibleProspects(); if (!selected.length || !window.confirm(`Mark ${selected.length} selected leads as contacted? This does not send messages.`)) return; selected.forEach((p) => { p.status = "contacted"; p.lastContactedAt = new Date().toISOString(); }); await Promise.all(selected.map(updateCloudProspect)); save(); renderQueue(); });
    $("scan-prospects-btn")?.addEventListener("click", scanProspects);
    $("verify-prospects-btn")?.addEventListener("click", verifyProspects);
    $("export-prospects-btn")?.addEventListener("click", exportCsv);
    document.addEventListener("change", (event) => { const checkbox = event.target.closest("[data-select-prospect]"); if (!checkbox) return; if (checkbox.checked) selectedProspects.add(checkbox.dataset.selectProspect); else selectedProspects.delete(checkbox.dataset.selectProspect); updateSelectionCount(); });
    document.addEventListener("click", (event) => {
        if (event.target.closest("[data-save-prospect]")) savePipeline(event);
        const feedbackButton = event.target.closest("[data-save-feedback]");
        if (feedbackButton) {
            const prospect = state.prospects.find((item) => item.id === feedbackButton.dataset.saveFeedback);
            const select = feedbackButton.closest(".prospect-feedback")?.querySelector("[data-feedback-prospect]");
            if (prospect && select?.value) { prospect.searchFeedback = { value: select.value, recordedAt: new Date().toISOString() }; if (select.value === "good-fit") prospect.fit = Math.min(20, Number(prospect.fit || 0) + 3); if (["wrong-industry", "too-large", "low-opportunity"].includes(select.value)) prospect.fit = Math.max(0, Number(prospect.fit || 0) - 5); save(); renderQueue(); }
        }
    });
    window.addEventListener("supabase:authenticated", loadCloudProspects);
    window.addEventListener("workspace:project-id-change", loadCloudProspects);
    $("show-prospect-form")?.addEventListener("click", () => { $("prospect-form-panel").hidden = false; $("prospect-name")?.focus(); });
    $("cancel-prospect-form")?.addEventListener("click", () => { $("prospect-form-panel").hidden = true; });
    $("save-call-notes")?.addEventListener("click", saveNotes);
    $("close-brief")?.addEventListener("click", () => { $("prospect-brief-panel").hidden = true; });
    $("close-cockpit")?.addEventListener("click", () => { $("call-cockpit-panel").hidden = true; });
    document.addEventListener("click", (event) => { const brief = event.target.closest("[data-open-prospect]"); const audit = event.target.closest("[data-import-audit]"); const call = event.target.closest("[data-call-prospect]"); const prospect = state.prospects.find((item) => item.id === (brief?.dataset.openProspect || audit?.dataset.importAudit || call?.dataset.callProspect)); if (prospect && brief) renderBrief(prospect); if (prospect && audit) importSiteToAudit(prospect); if (prospect && call) openCockpit(prospect); });
    renderMarket(); renderQueue(); renderOffers(); loadCloudProspects();
})();
