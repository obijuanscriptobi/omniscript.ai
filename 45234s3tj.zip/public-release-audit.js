"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = __dirname;
const output = path.join(root, "public");
const textExtensions = new Set([".html", ".htm", ".css", ".js", ".json", ".webmanifest", ".svg", ".xml", ".txt"]);
const forbiddenPaths = [
    /(?:^|\/)package(?:-lock)?\.json$/i, /(?:^|\/)netlify\.toml$/i, /(?:^|\/)\.env/i,
    /(?:^|\/)(?:test|docs|supabase|netlify|\.github|node_modules)(?:\/|$)/i,
    /(?:^|\/)readiness\.html$/i, /(?:^|\/)release-readiness\.js$/i,
    /(?:^|\/)(?:production-release-gate|public-release-audit)\.json$/i,
    /(?:^|\/)(?:tsconfig[^/]*|playwright\.config)\.json$/i, /\.map$/i
];
const referencePattern = /(?:src|href|action|formaction|poster)\s*=\s*["']([^"']+)["']|url\(\s*["']?([^"')]+)|["'`]((?:\.?\.?\/|\/)[a-zA-Z0-9_./-]+\.(?:html?|css|js|json|webmanifest|svg|png|jpe?g|webp|avif|gif|ico|woff2?|ttf|otf|xml|txt|mp4|webm))(?:[?#][^"'`]*)?["'`]/gi;

function walk(directory, prefix = "") {
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
        const relative = path.posix.join(prefix, entry.name);
        return entry.isDirectory() ? walk(path.join(directory, entry.name), relative) : [relative];
    });
}

function localTarget(from, reference) {
    const value = String(reference || "").trim();
    if (!value || /^(?:#|https?:|data:|blob:|mailto:|tel:|javascript:|\/\/)/i.test(value)) return "";
    const clean = value.split(/[?#]/, 1)[0];
    const resolved = path.posix.normalize(clean.startsWith("/") ? clean.slice(1) : path.posix.join(path.posix.dirname(from), clean));
    return resolved.startsWith("../") ? "" : resolved;
}

function inspectPublicBuild(directory = output) {
    const findings = [];
    const inventory = { files: 0, references: 0, frames: 0, remoteResources: [], formActions: [], workers: [] };
    const add = (code, file, message) => findings.push({ code, file, message });
    if (!fs.existsSync(directory)) return { ok: false, findings: [{ code: "PUBLIC_BUILD_MISSING", file: "public", message: "The public build does not exist." }], inventory };

    const files = walk(directory);
    const fileSet = new Set(files);
    inventory.files = files.length;
    files.forEach((file) => {
        if (forbiddenPaths.some((pattern) => pattern.test(file))) add("FORBIDDEN_PUBLIC_FILE", file, "Repository-only or sensitive content entered the public build.");
        const extension = path.extname(file).toLowerCase();
        if (!textExtensions.has(extension)) return;
        const source = fs.readFileSync(path.join(directory, file), "utf8");

        const secretChecks = [
            ["PRIVATE_KEY", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
            ["JWT", /\beyJ[A-Za-z0-9_-]{20,}\.eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\b/],
            ["SERVICE_ROLE_KEY", /(?:SUPABASE_SERVICE_ROLE_KEY|service_role_key)\s*[:=]\s*["'][A-Za-z0-9._-]{24,}["']/i],
            ["EMBEDDED_CREDENTIAL", /(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)\s*[:=]\s*["'][A-Za-z0-9_./+=-]{32,}["']/i]
        ];
        secretChecks.forEach(([code, pattern]) => { if (pattern.test(source)) add(`PUBLIC_${code}`, file, "A credential-like value is embedded in a public text asset."); });

        for (const match of source.matchAll(referencePattern)) {
            const reference = match[1] || match[2] || match[3] || "";
            inventory.references += 1;
            if (/^https?:\/\//i.test(reference)) inventory.remoteResources.push({ file, reference });
            const target = localTarget(file, reference);
            if (target && !fileSet.has(target)) add("MISSING_PUBLIC_REFERENCE", file, `Referenced asset does not exist in the public build: ${reference}`);
        }

        if (/\.html?$/.test(extension)) {
            if (/<script\b(?![^>]*\bsrc=)[^>]*>[\s\S]*?\S[\s\S]*?<\/script>/i.test(source)) add("CSP_INLINE_SCRIPT", file, "Inline script conflicts with script-src 'self' unless explicitly hashed or nonced.");
            if (/\son[a-z]+\s*=/i.test(source)) add("CSP_EVENT_HANDLER", file, "Inline event handlers are blocked by script-src-attr 'none'.");
            for (const match of source.matchAll(/<iframe\b([^>]*)>/gi)) {
                inventory.frames += 1;
                const attributes = match[1];
                const sandbox = attributes.match(/\bsandbox(?:\s*=\s*["']([^"']*)["'])?/i);
                if (!sandbox) add("UNSANDBOXED_FRAME", file, "Every iframe must declare an explicit sandbox policy.");
                else if (/\ballow-scripts\b/i.test(sandbox[1] || "") && /\ballow-same-origin\b/i.test(sandbox[1] || "")) add("FRAME_SANDBOX_ESCAPE", file, "A same-origin frame must not combine allow-scripts and allow-same-origin.");
            }
            for (const match of source.matchAll(/<a\b([^>]*)>/gi)) {
                const attributes = match[1];
                if (/\btarget\s*=\s*["']_blank["']/i.test(attributes) && !/\brel\s*=\s*["'][^"']*\bnoopener\b/i.test(attributes)) add("BLANK_LINK_OPENER", file, "target=_blank links must include rel=noopener.");
            }
            for (const match of source.matchAll(/<form\b([^>]*)>/gi)) {
                const action = match[1].match(/\baction\s*=\s*["']([^"']*)["']/i)?.[1] || "";
                inventory.formActions.push({ file, action });
                if (/^(?:javascript:|data:|https?:\/\/)/i.test(action)) add("UNSAFE_FORM_ACTION", file, `Form action is not same-origin: ${action}`);
            }
        }
        if (/\.js$/.test(extension)) {
            for (const match of source.matchAll(/new\s+(?:Shared)?Worker\s*\(\s*["'`]([^"'`]+)["'`]/g)) {
                inventory.workers.push({ file, reference: match[1] });
                if (/^(?:https?:|\/\/)/i.test(match[1])) add("REMOTE_WORKER", file, `Workers must be same-origin: ${match[1]}`);
            }
            if (/\b(?:eval|Function)\s*\(/.test(source)) add("DYNAMIC_CODE_EXECUTION", file, "Dynamic string-based code execution conflicts with the deployed CSP.");
        }
    });

    return { ok: findings.length === 0, findings, inventory: { ...inventory, remoteResources: [...new Map(inventory.remoteResources.map((item) => [`${item.file}:${item.reference}`, item])).values()] } };
}

function main() {
    const report = inspectPublicBuild();
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    process.exitCode = report.ok ? 0 : 1;
}

if (require.main === module) main();
module.exports = { inspectPublicBuild, localTarget };
