"use strict";

(() => {
    const STORAGE_KEY = "omniscript-release-readiness-v1";
    const groups = [
        { id: "automatic", title: "Automatic checks in this browser", automatic: true, items: [
            ["lockfile", "Dependency lockfile is present and consistent", "Checks lockfile v3, root metadata, dependency declarations, registry provenance, and integrity fields."],
            ["critical-assets", "Critical pages and assets are reachable", "Checks the home, maker, audit, account, legal pages, manifest, styles, and primary scripts."],
            ["config", "Deployed capability configuration is healthy", "Reads /api/config when available and reports missing or invalid capabilities without exposing values."],
            ["routing", "Unknown pages and API routes fail closed", "Checks that missing pages return a non-success response and unknown API paths do not return an HTML application shell."],
            ["csp", "The deployed Content Security Policy matches the page", "Checks for a deployed CSP and detects inline scripts that the policy would block."],
            ["deployment-surface", "Repository-only files are not publicly deployed", "Samples package metadata, hosting configuration, SQL, tests, and internal release records. The public-build manifest remains the authoritative boundary."],
            ["secure-context", "The deployed page uses a secure context", "HTTPS is required outside local development."],
            ["storage", "Local progress can be persisted", "Checks whether this browser can retain readiness decisions and evidence notes."]
        ]},
        { id: "repository", title: "Repository and CI release candidate", items: [
            ["toolchain", "Record exact Node 26 and npm versions", "Record immutable output from the environment that generated the lockfile."],
            ["lock-clean", "Clean dependency installation leaves no changes", "The committed lockfile must reproduce without modifying package or lock metadata."],
            ["dependency-review", "Review dependency sources and advisories", "Account for registries, integrity, production/dev classification, advisories, and Playwright version alignment."],
            ["actions-policy", "Document the GitHub Actions pinning decision", "Pin reviewed immutable SHAs or explicitly accept and own the mutable-tag risk."],
            ["type-scope", "Accept or expand the current type-checking scope", "The current check is intentionally incremental; document that scope rather than implying whole-repository coverage."],
            ["source-ci", "Source CI passes on the exact candidate commit", "Lint, typecheck, security, adversarial, coverage, release gate, and lock audit must pass."],
            ["browser-ci", "Browser CI passes on the exact candidate commit", "Review every browser project, duration, warning, failure artifact, and intentional skip."],
            ["coverage", "Coverage scope and report are reviewed", "Confirm critical production modules appear in the denominator and retain node-test-coverage.txt."],
            ["test-integrity", "Test skips and broad assertions are reviewed", "No focused test, accidental environment skip, or permissive assertion may hide a release failure."],
            ["candidate-sha", "Freeze the final passing 40-character commit SHA", "Any release-affecting change invalidates the frozen candidate and requires CI again."],
            ["public-publish-boundary", "Define an explicit public publish boundary", "The hosting publish directory must contain only intended browser assets, not source tests, SQL migrations, internal documents, package metadata, or release evidence."],
            ["workflow-pins", "Pin or formally accept mutable workflow dependencies", "Use reviewed immutable Action SHAs where policy requires them, or record the owner and accepted mutable-tag risk."],
            ["npm-version", "Record the npm version that generated the lockfile", "Add the observed version to release evidence and optionally packageManager; never infer it from Node alone."]
        ]},
        { id: "site", title: "Website content and customer journey", items: [
            ["business-facts", "Business identity and facts are approved", "Names, contact details, locations, hours, pricing, qualifications, and claims are accurate."],
            ["content-rights", "Content and asset rights are documented", "Account for copy, images, fonts, trademarks, imports, and AI-assisted material."],
            ["page-purpose", "Every page has a clear purpose and next action", "Check headings, navigation, calls to action, empty states, errors, and confirmation states."],
            ["links", "All internal and external links are verified", "Include navigation, footer, email, telephone, downloads, social links, canonicals, and redirects."],
            ["forms", "Forms are validated end to end", "Test labels, validation, consent, spam controls, failure recovery, duplicate handling, and actual destination receipt."],
            ["responsive", "Responsive layouts are reviewed", "Check 320, 375, 768, 1024, and 1440 widths with long content and orientation changes."],
            ["accessibility", "Accessibility review is complete", "Keyboard, focus, landmarks, names, contrast, zoom, reduced motion, forced colors, errors, and screen-reader flow."],
            ["seo", "Search and sharing metadata are complete", "Titles, descriptions, canonical URLs, indexing rules, sitemap, robots, favicon, and social cards."],
            ["performance", "Performance and resilience are acceptable", "Review Core Web Vitals, image sizing, fonts, scripts, caching, slow networks, failed assets, and JavaScript-disabled behavior."],
            ["privacy", "Privacy and tracking behavior is approved", "Verify consent, analytics opt-out, retention, deletion, legal pages, and no secrets or customer data in client files."],
            ["readiness-visibility", "Release readiness information stays internal", "The register is separate from the customer home page and excluded from the public build; confirm staff handle exported reports securely."],
            ["export", "Exported site contents are inspected", "No editor-only code, credentials, source maps, private data, broken paths, or unexpected executable content."],
            ["404", "404 and API failure behavior is verified", "Unknown pages return a real non-success response and unknown /api routes never return an HTML shell."]
        ]},
        { id: "staging", title: "External staging and security evidence", items: [
            ["isolation", "Staging infrastructure is isolated", "Use disposable hosting, database, Redis, providers, domain, inbox, users, and two synthetic projects."],
            ["environment", "Environment contract is verified", "Capabilities are accurate, origin matches, required secrets exist server-side, and /api/config exposes no secret."],
            ["clean-migration", "Clean and repeat migration passes", "Apply the complete ordered migration set twice and retain schema, RPC, grants, and RLS evidence."],
            ["legacy-migration", "Legacy upgrade preserves data and tenancy", "Use a sanitized representative backup and compare ownership, relationships, and row counts."],
            ["rls", "Role and cross-project isolation passes", "Cover owner, admin, editor, reviewer, anonymous, revoked, archived, and other-project access."],
            ["token-races", "Public-token concurrency and replay tests pass", "Verify single-use decisions, expiry, revocation, URL token removal, limits, and raw-token absence."],
            ["files", "File lifecycle and quarantine tests pass", "Verify signed upload, bytes, signatures, hashes, MIME, limits, missing objects, cleanup, and authorization."],
            ["workflow", "Brief-to-verified workflow passes", "Cover draft, edits, autosave, restore, approval, preflight, publish, observed verification, proposal, and handoff."],
            ["providers", "Provider and delivery failure paths pass", "Exercise import, AI, webhook, email, Redis, database, timeouts, quotas, retries, and exactly-once behavior."],
            ["deployment", "Deployment, domain, SEO, and rollback pass", "Publish two revisions, verify live behavior, roll back, then verify HTTPS, DNS, headers, MIME, and metadata."],
            ["browser-manual", "Real-device browser and accessibility evidence is retained", "Include mobile Safari/Chrome, tablet, keyboard, zoom, assistive technology, and adverse conditions."],
            ["operations", "Monitoring, incident, backup, and support drills pass", "Verify alerts, request IDs, retry jobs, escalation, restore time, and support diagnosis."],
            ["legal", "Legal and operational approvals are recorded", "Privacy, terms, acceptable use, rights, retention, subprocessors, incidents, AI disclosure, and jurisdiction requirements."]
        ]},
        { id: "evidence", title: "Final evidence and release authorization", items: [
            ["evidence-clean", "Clean migration evidence reference", "CODEWISE_EVIDENCE_CLEAN_MIGRATION"],
            ["evidence-legacy", "Legacy migration evidence reference", "CODEWISE_EVIDENCE_LEGACY_MIGRATION"],
            ["evidence-rls", "Staging RLS evidence reference", "CODEWISE_EVIDENCE_STAGING_RLS"],
            ["evidence-token", "Public-token race evidence reference", "CODEWISE_EVIDENCE_PUBLIC_TOKEN_RACES"],
            ["evidence-file", "File lifecycle evidence reference", "CODEWISE_EVIDENCE_FILE_LIFECYCLE"],
            ["evidence-provider", "Provider delivery evidence reference", "CODEWISE_EVIDENCE_PROVIDER_DELIVERY"],
            ["evidence-browser", "Browser/accessibility evidence reference", "CODEWISE_EVIDENCE_BROWSER_A11Y"],
            ["evidence-backup", "Backup/restore evidence reference", "CODEWISE_EVIDENCE_BACKUP_RESTORE"],
            ["evidence-rollback", "Migration rollback evidence reference", "CODEWISE_EVIDENCE_MIGRATION_ROLLBACK"],
            ["evidence-operations", "Operations evidence reference", "CODEWISE_EVIDENCE_OPERATIONS"],
            ["manifest", "Exact-commit evidence manifest is approved", "Must bind all references, passing results, reviewers, timestamps, staging identity, CI run ID, and frozen SHA."],
            ["release-approval", "Controlled-beta or public-release decision is approved", "Record reviewers, owned exceptions, mitigations, due dates, rollback owner, and monitoring owner."],
            ["cleanup", "Post-validation cleanup is complete", "Revoke fixtures and tokens, remove temporary permissions, delete synthetic resources per policy, and retain redacted evidence."]
        ]}
    ];
    const automatic = new Map();
    let saved = readSaved();
    let lastScanAt = "";
    const $ = (id) => document.getElementById(id);

    function readSaved() {
        try { const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); return value && typeof value === "object" ? value : {}; }
        catch (_) { return {}; }
    }

    function persist() {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(saved)); return true; }
        catch (_) { return false; }
    }

    function itemKey(group, id) {
        return `${group.id}:${id}`;
    }

    function savedItem(group, id) {
        return saved[itemKey(group, id)] || saved[id] || {};
    }

    function statusFor(group, id) {
        if (group.automatic) return automatic.get(id)?.status || "pending";
        const item = savedItem(group, id);
        if (item.exception === true) return "exception";
        return item.complete ? "passed" : "pending";
    }

    function statusLabel(status, automaticItem) {
        if (status === "passed") return "Verified";
        if (status === "exception") return "Owned exception";
        if (status === "failed") return "Fix required";
        return automaticItem ? "Checking" : "Not verified";
    }

    function render() {
        const root = $("readiness-groups");
        if (!root) return;
        root.replaceChildren(...groups.map((group, groupIndex) => {
            const details = document.createElement("details");
            details.className = "readiness-group";
            details.open = groupIndex < 2 || group.items.some(([id]) => statusFor(group, id) === "failed");
            const complete = group.items.filter(([id]) => statusFor(group, id) === "passed").length;
            const summary = document.createElement("summary");
            const title = document.createElement("span"); title.textContent = group.title;
            const count = document.createElement("span"); count.className = "readiness-group-count"; count.textContent = `${complete}/${group.items.length} complete`;
            summary.append(title, count);
            const list = document.createElement("ul"); list.className = "readiness-list";
            group.items.forEach(([id, label, description]) => {
                const status = statusFor(group, id);
                const li = document.createElement("li"); li.className = "readiness-item"; li.dataset.status = status;
                const record = savedItem(group, id);
                const checkbox = document.createElement("input"); checkbox.type = "checkbox"; checkbox.checked = status === "passed"; checkbox.disabled = Boolean(group.automatic); checkbox.dataset.readinessId = id; checkbox.dataset.readinessGroup = group.id; checkbox.setAttribute("aria-label", `Mark ${label} verified`);
                const copy = document.createElement("div"); copy.className = "readiness-item-copy";
                const heading = document.createElement("div"); heading.className = "readiness-item-heading";
                const strong = document.createElement("strong"); strong.textContent = label;
                const badge = document.createElement("span"); badge.className = "readiness-badge"; badge.textContent = statusLabel(status, group.automatic);
                const detail = document.createElement("p"); detail.textContent = automatic.get(id)?.message || description;
                heading.append(strong, badge); copy.append(heading, detail);
                if (!group.automatic) {
                    const fields = document.createElement("div"); fields.className = "readiness-evidence-grid";
                    const evidence = document.createElement("input"); evidence.className = "readiness-evidence"; evidence.dataset.readinessEvidence = id; evidence.dataset.readinessGroup = group.id; evidence.value = record.evidence || ""; evidence.placeholder = "Required: evidence reference or verification note"; evidence.setAttribute("aria-label", `Evidence for ${label}`);
                    const owner = document.createElement("input"); owner.className = "readiness-evidence"; owner.dataset.readinessField = "owner"; owner.dataset.readinessId = id; owner.dataset.readinessGroup = group.id; owner.value = record.owner || ""; owner.placeholder = "Owner"; owner.setAttribute("aria-label", `Owner for ${label}`);
                    const due = document.createElement("input"); due.className = "readiness-evidence"; due.type = "date"; due.dataset.readinessField = "dueDate"; due.dataset.readinessId = id; due.dataset.readinessGroup = group.id; due.value = record.dueDate || ""; due.setAttribute("aria-label", `Due date for ${label}`);
                    const severity = document.createElement("select"); severity.className = "readiness-evidence"; severity.dataset.readinessField = "severity"; severity.dataset.readinessId = id; severity.dataset.readinessGroup = group.id; severity.setAttribute("aria-label", `Severity for ${label}`); ["blocking", "high", "medium", "low"].forEach((value) => { const option = document.createElement("option"); option.value = value; option.textContent = value[0].toUpperCase() + value.slice(1); option.selected = (record.severity || "blocking") === value; severity.append(option); });
                    const exception = document.createElement("label"); exception.className = "readiness-exception"; const exceptionBox = document.createElement("input"); exceptionBox.type = "checkbox"; exceptionBox.checked = record.exception === true; exceptionBox.dataset.readinessField = "exception"; exceptionBox.dataset.readinessId = id; exceptionBox.dataset.readinessGroup = group.id; exception.append(exceptionBox, document.createTextNode(" Accept as owned exception"));
                    const mitigation = document.createElement("input"); mitigation.className = "readiness-evidence"; mitigation.dataset.readinessField = "mitigation"; mitigation.dataset.readinessId = id; mitigation.dataset.readinessGroup = group.id; mitigation.value = record.mitigation || ""; mitigation.placeholder = "Mitigation (required for exception)"; mitigation.setAttribute("aria-label", `Mitigation for ${label}`);
                    fields.append(evidence, owner, due, severity, exception, mitigation); copy.append(fields);
                }
                li.append(checkbox, copy); list.append(li);
            });
            details.append(summary, list); return details;
        }));
        updateSummary();
    }

    function updateSummary() {
        const all = groups.flatMap((group) => group.items.map(([id]) => ({ group, id })));
        const passed = all.filter(({ group, id }) => statusFor(group, id) === "passed").length;
        const failed = all.filter(({ group, id }) => statusFor(group, id) === "failed").length;
        const exceptions = all.filter(({ group, id }) => statusFor(group, id) === "exception").length;
        const pending = all.length - passed - failed - exceptions;
        $("readiness-passed").textContent = String(passed);
        $("readiness-failed").textContent = String(failed);
        $("readiness-pending").textContent = String(pending);
        $("readiness-total").textContent = String(all.length);
        const status = $("readiness-status");
        const context = ["localhost", "127.0.0.1"].includes(location.hostname) ? "Local preview" : "Deployed environment";
        const scanLabel = lastScanAt ? ` Last scan: ${new Date(lastScanAt).toLocaleString()}.` : "";
        const exceptionLabel = exceptions ? ` ${exceptions} owned exception${exceptions === 1 ? " is" : "s are"} recorded and still require release approval.` : "";
        status.textContent = (failed
            ? `${failed} detected blocker${failed === 1 ? "" : "s"} must be fixed. ${pending} additional item${pending === 1 ? "" : "s"} still require verification or an owned exception.`
            : pending ? `No automatic blocker is currently visible, but ${pending} item${pending === 1 ? "" : "s"} still require verification or an owned exception. This is not release approval.`
                : "Every listed item is accounted for. Confirm the frozen commit and protected release approval before launch.") + exceptionLabel + ` ${context}.${scanLabel}`;
    }

    async function fetchJson(path) {
        const response = await fetch(path, { cache: "no-store", headers: { Accept: "application/json" } });
        if (!response.ok) throw new Error(`${path} returned ${response.status}`);
        return response.json();
    }

    async function checkLockfile() {
        const local = ["localhost", "127.0.0.1"].includes(location.hostname);
        try {
            const [manifest, lock] = await Promise.all([fetchJson("package.json"), fetchJson("package-lock.json")]);
            const root = lock?.packages?.[""];
            const same = (left = {}, right = {}) => JSON.stringify(Object.entries(left).sort()) === JSON.stringify(Object.entries(right).sort());
            const entries = Object.entries(lock?.packages || {}).filter(([name]) => name);
            const unsafe = entries.filter(([, item]) => item?.link || (item?.resolved && !String(item.resolved).startsWith("https://registry.npmjs.org/")) || (item?.resolved && !/^sha(?:256|384|512)-[A-Za-z0-9+/=]+$/.test(String(item.integrity || ""))));
            const valid = lock.lockfileVersion === 3 && root?.name === manifest.name && root?.version === manifest.version && same(root.dependencies, manifest.dependencies) && same(root.devDependencies, manifest.devDependencies) && entries.length > 0 && unsafe.length === 0;
            return { status: valid ? "passed" : "failed", message: valid ? `Lockfile v3 matches package.json and contains ${entries.length} audited package entries. Hide both package files from the public deployment after CI.` : "The lockfile is present but its format, root dependencies, registry provenance, or integrity metadata does not match the release contract." };
        } catch (error) {
            return local
                ? { status: "failed", message: `A genuine package-lock.json could not be validated: ${error.message}` }
                : { status: "pending", message: "Package metadata is correctly unavailable from the public site; verify the genuine lockfile in source CI and attach its artifact." };
        }
    }

    async function checkAssets() {
        const paths = ["home.html", "index.html", "audit.html", "account.html", "privacy.html", "terms.html", "acceptable-use.html", "site.webmanifest", "styles.css", "script.js", "home-page.js", "site-nav.js"];
        const results = await Promise.all(paths.map(async (path) => { try { const response = await fetch(path, { method: "HEAD", cache: "no-store" }); return response.ok ? "" : `${path} (${response.status})`; } catch (_) { return path; } }));
        const missing = results.filter(Boolean);
        return { status: missing.length ? "failed" : "passed", message: missing.length ? `Missing or unreachable: ${missing.join(", ")}.` : `${paths.length} critical pages and assets are reachable.` };
    }

    async function checkConfig() {
        try {
            const response = await fetch("/api/config", { cache: "no-store", headers: { Accept: "application/json" } });
            const type = response.headers.get("content-type") || "";
            if (!type.includes("application/json")) return { status: "pending", message: "The config API is not available in this static preview; verify it on the deployed environment." };
            const payload = await response.json();
            const invalid = payload.configuration?.invalid || [];
            const missing = payload.configuration?.requiredMissing || [];
            if (invalid.length || missing.length) return { status: "failed", message: `Configuration requires attention. Invalid: ${invalid.join(", ") || "none"}. Required missing: ${missing.join(", ") || "none"}.` };
            return { status: response.ok ? "passed" : "pending", message: response.ok ? "Required cloud configuration reports ready; review optional unavailable capabilities separately." : "Configuration endpoint is reachable, but deployment readiness is not complete." };
        } catch (_) { return { status: "pending", message: "The config API could not be reached here; verify it on the deployed environment." }; }
    }

    async function checkRouting() {
        const nonce = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
        try {
            const [page, api] = await Promise.all([
                fetch(`/readiness-missing-${nonce}`, { cache: "no-store", redirect: "manual" }),
                fetch(`/api/readiness-missing-${nonce}`, { cache: "no-store", redirect: "manual", headers: { Accept: "application/json" } })
            ]);
            const apiType = (api.headers.get("content-type") || "").toLowerCase();
            const pageClosed = !page.ok;
            const apiClosed = !api.ok && !apiType.includes("text/html");
            return {
                status: pageClosed && apiClosed ? "passed" : "failed",
                message: pageClosed && apiClosed
                    ? `Unknown page and API probes failed closed (${page.status} and ${api.status}).`
                    : `Routing is unsafe: unknown page status ${page.status}; unknown API status/type ${api.status} ${apiType || "unknown"}.`
            };
        } catch (_) { return { status: "pending", message: "Routing probes could not be completed here; verify 404 and unknown API behavior after deployment." }; }
    }

    async function checkCsp() {
        try {
            const response = await fetch(location.href, { cache: "no-store" });
            const policy = response.headers.get("content-security-policy") || document.querySelector("meta[http-equiv='Content-Security-Policy']")?.content || "";
            if (!policy) return { status: "pending", message: "No CSP is visible in this preview response; verify the hosting header after deployment." };
            const inlineScripts = [...document.scripts].filter((script) => !script.src && script.textContent.trim());
            const allowsInline = /script-src[^;]*'unsafe-inline'/i.test(policy);
            const blockedInline = inlineScripts.length > 0 && !allowsInline;
            return { status: blockedInline ? "failed" : "passed", message: blockedInline ? `${inlineScripts.length} inline script block(s) conflict with the deployed script-src policy.` : "A CSP is present and this page has no visibly blocked inline script." };
        } catch (_) { return { status: "pending", message: "The CSP response header could not be inspected here; verify it on the deployed environment." }; }
    }

    async function checkDeploymentSurface() {
        const internal = ["package.json", "netlify.toml", "supabase/schema.sql", "test/static-server.js", "docs/STAGING-RELEASE-RECORD.md"];
        const exposed = [];
        await Promise.all(internal.map(async (path) => {
            try { const response = await fetch(path, { method: "HEAD", cache: "no-store" }); if (response.ok) exposed.push(path); } catch (_) {}
        }));
        const local = ["localhost", "127.0.0.1"].includes(location.hostname);
        if (local) return { status: "pending", message: `Local preview exposes repository files by design. Confirm the deployed publish boundary hides: ${internal.join(", ")}.` };
        return exposed.length
            ? { status: "failed", message: `Internal repository files are publicly reachable: ${exposed.sort().join(", ")}. Publish only intended site assets.` }
            : { status: "passed", message: "Sampled package, hosting, SQL, test, and internal evidence files are not publicly reachable." };
    }

    async function scan() {
        const button = $("readiness-scan"); if (button) { button.disabled = true; button.textContent = "Scanning…"; }
        const [lockfile, criticalAssets, config, routing, csp, deploymentSurface] = await Promise.all([
            checkLockfile(), checkAssets(), checkConfig(), checkRouting(), checkCsp(), checkDeploymentSurface()
        ]);
        automatic.set("lockfile", lockfile);
        automatic.set("critical-assets", criticalAssets);
        automatic.set("config", config);
        automatic.set("routing", routing);
        automatic.set("csp", csp);
        automatic.set("deployment-surface", deploymentSurface);
        const local = ["localhost", "127.0.0.1"].includes(location.hostname);
        automatic.set("secure-context", { status: window.isSecureContext ? "passed" : local ? "pending" : "failed", message: window.isSecureContext ? "This page is running in a secure context." : local ? "Local preview detected; HTTPS must be verified after deployment." : "This deployed page is not using a secure context." });
        const storageOk = (() => { try { localStorage.setItem(`${STORAGE_KEY}-probe`, "1"); localStorage.removeItem(`${STORAGE_KEY}-probe`); return true; } catch (_) { return false; } })();
        automatic.set("storage", { status: storageOk ? "passed" : "failed", message: storageOk ? "Readiness decisions can be stored in this browser." : "Browser storage is unavailable; export the report or progress will be lost." });
        lastScanAt = new Date().toISOString();
        render();
        if (button) { button.disabled = false; button.textContent = "Scan again"; }
    }

    function exportReport() {
        const report = {
            schemaVersion: 2,
            exportedAt: new Date().toISOString(),
            page: location.href,
            warning: "Manual completion records an assertion and evidence note; it is not independent verification.",
            checks: groups.flatMap((group) => group.items.map(([id, label, description]) => ({ id, groupId: group.id, group: group.title, label, description, status: statusFor(group, id), ...savedItem(group, id), automaticMessage: automatic.get(id)?.message || "" })))
        };
        const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
        const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `release-readiness-${new Date().toISOString().slice(0, 10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 0);
    }

    async function importReport(file) {
        try {
            const report = JSON.parse(await file.text());
            if (![1, 2].includes(report?.schemaVersion) || !Array.isArray(report?.checks)) throw new Error("Unsupported readiness report format.");
            const known = new Set(groups.flatMap((group) => group.automatic ? [] : group.items.map(([id]) => itemKey(group, id))));
            const imported = {};
            report.checks.forEach((item) => {
                const key = item.groupId ? `${item.groupId}:${item.id}` : [...known].find((candidate) => candidate.endsWith(`:${item.id}`));
                if (!key || !known.has(key)) return;
                imported[key] = { complete: item.status === "passed" || item.complete === true, exception: item.status === "exception" || item.exception === true, evidence: String(item.evidence || "").trim(), owner: String(item.owner || "").trim(), dueDate: String(item.dueDate || "").trim(), severity: String(item.severity || "blocking"), mitigation: String(item.mitigation || "").trim(), updatedAt: new Date().toISOString() };
            });
            saved = { ...saved, ...imported };
            persist(); render();
            $("readiness-status").textContent = `Imported ${Object.keys(imported).length} recognized manual records. Re-scan automatic checks before relying on this report.`;
        } catch (error) { $("readiness-status").textContent = `Import failed: ${error.message}`; }
    }

    document.addEventListener("change", (event) => {
        const target = event.target;
        const groupId = target?.dataset?.readinessGroup;
        const id = target?.dataset?.readinessId;
        const group = groups.find((item) => item.id === groupId);
        if (id && group && !group.automatic && target.type === "checkbox" && !target.dataset.readinessField) {
            const key = itemKey(group, id); const current = savedItem(group, id); const evidence = String(current.evidence || "").trim();
            if (target.checked && !evidence) { target.checked = false; $("readiness-status").textContent = "Add an evidence reference or verification note before marking an item verified."; return; }
            saved[key] = { ...current, complete: target.checked, exception: false, updatedAt: new Date().toISOString() }; persist(); render(); return;
        }
        const evidence = target.closest?.("[data-readiness-evidence]");
        if (evidence) { const evidenceGroup = groups.find((item) => item.id === evidence.dataset.readinessGroup); const key = itemKey(evidenceGroup, evidence.dataset.readinessEvidence); saved[key] = { ...savedItem(evidenceGroup, evidence.dataset.readinessEvidence), evidence: evidence.value.trim(), updatedAt: new Date().toISOString() }; persist(); return; }
        const field = target.closest?.("[data-readiness-field]");
        if (field) {
            const fieldGroup = groups.find((item) => item.id === field.dataset.readinessGroup); const key = itemKey(fieldGroup, field.dataset.readinessId); const current = savedItem(fieldGroup, field.dataset.readinessId); const value = field.type === "checkbox" ? field.checked : field.value.trim();
            if (field.dataset.readinessField === "exception" && value && (!current.evidence?.trim() || !current.owner?.trim() || !current.mitigation?.trim() || !current.dueDate)) { field.checked = false; $("readiness-status").textContent = "An exception requires evidence, owner, mitigation, and due date."; return; }
            saved[key] = { ...current, [field.dataset.readinessField]: value, complete: field.dataset.readinessField === "exception" && value ? false : current.complete, updatedAt: new Date().toISOString() }; persist(); render();
        }
        if (target.id === "readiness-import-file" && target.files?.[0]) { importReport(target.files[0]); target.value = ""; }
    });
    $("readiness-scan")?.addEventListener("click", scan);
    $("readiness-import")?.addEventListener("click", () => $("readiness-import-file")?.click());
    $("readiness-export")?.addEventListener("click", exportReport);
    render();
    scan();
})();
