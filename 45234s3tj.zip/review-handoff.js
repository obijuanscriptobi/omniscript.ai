"use strict";

// Client review is a first-class maker step: share this revision, collect a
// decision, and keep publish locked until the client approves it.
(() => {
    const STORAGE_KEY = "morrow-client-reviews-v1";
    const reviewStorageKey = () => window.workspaceContext?.storageKey?.(STORAGE_KEY) || "";
    const SNAPSHOT_PREFIX = "morrow-preview-snapshot-";
    const DECISION_PREFIX = "morrow-preview-decision-";
    const get = (id) => document.getElementById(id);
    const clean = (value, max = 500) => String(value ?? "").replace(/[\u0000-\u001F\u007F]/g, "").trim().slice(0, max);

    function readReviews() {
        const key = reviewStorageKey();
        if (!key) return [];
        try {
            const value = JSON.parse(localStorage.getItem(key) || "[]");
            return Array.isArray(value) ? value : [];
        } catch {
            return [];
        }
    }

    function writeReviews(reviews) {
        const key = reviewStorageKey();
        if (!key) return reviews;
        try { localStorage.setItem(key, JSON.stringify(reviews.slice(0, 50))); } catch (_) {}
        return reviews;
    }

    function currentReview() {
        const revision = window.workspaceAPI?.getState?.()?.revision || "draft";
        // Approval belongs to one exact revision. Falling back to an older
        // review could incorrectly unlock publishing for a changed draft.
        return readReviews().find((item) => item.revision === revision) || null;
    }

    function saveReview(patch = {}) {
        const state = window.workspaceAPI?.getState?.() || {};
        const current = currentReview() || {
            id: globalThis.crypto?.randomUUID?.() || `review-${Date.now()}`,
            revision: state.revision || "draft",
            status: "draft",
            createdAt: new Date().toISOString()
        };
        const next = { ...current, ...patch, revision: state.revision || current.revision, updatedAt: new Date().toISOString() };
        writeReviews([next, ...readReviews().filter((item) => item.id !== next.id)]);
        applyState(next);
        return next;
    }

    function contactComplete() {
        const controls = [
            get("outcome-phone-input") || get("input-biz-phone"),
            get("outcome-email-input") || get("input-biz-email"),
            get("outcome-hours-input") || get("input-biz-hours")
        ];
        return controls.every((control) => Boolean(control?.value.trim()) && control.checkValidity());
    }

    function setStatus(message, focus = false) {
        const node = get("client-review-status");
        if (!node) return;
        node.textContent = message;
        if (focus) {
            node.tabIndex = -1;
            node.focus({ preventScroll: true });
        }
    }

    function setLiveStatus(message) {
        const node = get("go-live-status");
        if (node) node.textContent = message;
    }

    function applyState(review = currentReview()) {
        const approved = review?.status === "approved";
        const clientMode = document.body.dataset.creationMode === "client";
        window.websiteMakerWorkflow?.setReviewStatus?.(review?.status || "draft", {
            source: "client-review",
            approvedRevision: review?.status === "approved" ? review.revision : ""
        });
        document.body.dataset.contactReady = contactComplete() ? "true" : "false";
        const urlField = get("client-review-link");
        if (urlField && review?.url) urlField.value = review.url;
        const decision = get("client-review-decision");
        if (decision) {
            decision.textContent = approved
                ? "This revision is approved. You can publish."
                : review?.status === "changes-requested"
                    ? `Changes requested: ${review.note || "the client asked for updates."}`
                    : review?.status === "shared"
                        ? "Review link ready. Publish stays locked until the client approves."
                        : "Share this draft, then wait for approve or requested changes.";
        }
        const publish = get("publish-site-btn");
        const goLive = get("go-live-publish-btn");
        const blocked = (clientMode && !approved) || !contactComplete();
        [publish, goLive].forEach((button) => {
            if (!button) return;
            button.disabled = Boolean(blocked && button.id === "publish-site-btn");
            if (button.id === "publish-site-btn") {
                button.setAttribute("aria-disabled", blocked ? "true" : "false");
                button.title = clientMode && !approved
                    ? "Client approval is required before publishing."
                    : !contactComplete()
                        ? "Add phone, email, and hours before publishing."
                        : "";
            }
        });
        if (!contactComplete()) setLiveStatus("Add phone, email, and hours, then publish or download.");
        else if (clientMode && !approved) setLiveStatus("Share the review link. Publishing waits for approval.");
        else setLiveStatus("Ready to publish a URL you can send, or download the files.");
        document.dispatchEvent(new CustomEvent("workspace:review-updated", { detail: { review, contactReady: contactComplete() } }));
    }

    function localPreviewUrl(files, revision) {
        const token = `local-${(globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`)}`;
        try {
            localStorage.setItem(`${SNAPSHOT_PREFIX}${token}`, JSON.stringify({
                files,
                revision: revision || "draft",
                createdAt: new Date().toISOString(),
                expiresAt: new Date(Date.now() + 7 * 86400000).toISOString()
            }));
        } catch {
            return "";
        }
        return `${window.location.origin}${window.location.pathname.replace(/[^/]+$/, "")}preview.html?token=${encodeURIComponent(token)}`;
    }

    async function createShareableLink() {
        const state = window.workspaceAPI?.getState?.();
        const files = state?.files || {};
        if (!files["index.html"] || String(files["index.html"]).startsWith("<!-- Awaiting")) {
            setStatus("Create a website draft before sharing a review.");
            return "";
        }
        setStatus("Preparing a private review link…");
        const localUrl = localPreviewUrl(files, state.revision);
        try {
            const preview = await fetch("/api/preview", {
                method: "POST",
                credentials: "same-origin",
                headers: { Accept: "application/json", "Content-Type": "application/json" },
                body: JSON.stringify({ files, revision: state.revision || "draft", projectId: state.projectId || "" })
            });
            const result = await preview.json().catch(() => ({}));
            if (!preview.ok || !result.token) throw new Error(result.error || "Sign in to create a shareable review link.");

            let approvalToken = "";
            if (state.projectId) {
                const approval = await fetch("/api/approval", {
                    method: "POST",
                    credentials: "same-origin",
                    headers: { Accept: "application/json", "Content-Type": "application/json" },
                    body: JSON.stringify({ projectId: state.projectId, revision: state.revision || "draft" })
                });
                const approvalResult = await approval.json().catch(() => ({}));
                if (!approval.ok || !approvalResult.token) throw new Error(approvalResult.error || "The client approval link could not be prepared.");
                approvalToken = approvalResult.token;
            }

            const url = new URL("preview.html", window.location.href);
            url.searchParams.set("token", result.token);
            if (approvalToken) url.searchParams.set("approval", approvalToken);
            saveReview({ token: result.token, approvalToken, url: url.href, status: "shared", localUrl });
            const field = get("client-review-link");
            if (field) field.value = url.href;
            setStatus(approvalToken
                ? "Review link ready. The client can comment, approve, or request changes — publishing stays locked."
                : "Preview link ready. Save this as a cloud project to collect approval from another device.", true);
            return url.href;
        } catch (error) {
            if (localUrl) {
                saveReview({ token: new URL(localUrl, window.location.origin).searchParams.get("token"), url: localUrl, status: "shared", local: true });
                const field = get("client-review-link");
                if (field) field.value = localUrl;
                setStatus("Local review link ready on this device. Sign in to send a private link the client can open on their phone.", true);
                return localUrl;
            }
            saveReview({ status: "local" });
            setStatus(error.message || "Sign in to create a shareable review link. The draft stays in this workspace until then.", true);
            return "";
        }
    }

    async function copyLink() {
        const url = get("client-review-link")?.value.trim() || await createShareableLink();
        if (!url) return;
        try {
            await navigator.clipboard.writeText(url);
            setStatus("Review link copied. The client can comment from a phone or laptop.");
        } catch {
            setStatus("Copy the review link from the field above.");
        }
    }

    function applyRemoteDecision(decision) {
        if (!decision?.status) return;
        if (decision.status === "approved") {
            saveReview({ status: "approved", approvedAt: decision.at || new Date().toISOString(), note: clean(decision.comment || decision.note, 500) });
            setStatus("The client approved this revision. You can publish.");
        } else if (decision.status === "changes-requested") {
            saveReview({ status: "changes-requested", note: clean(decision.comment || decision.note, 500) });
            setStatus(decision.comment ? `Changes requested: ${clean(decision.comment, 180)}` : "The client requested changes.");
        }
    }

    async function pollDecision() {
        const review = currentReview();
        const token = review?.token;
        if (!token || review.status === "approved") return;
        try {
            const raw = localStorage.getItem(`${DECISION_PREFIX}${token}`);
            if (raw) applyRemoteDecision(JSON.parse(raw));
        } catch (_) { /* ignore */ }
        if (!review.approvalToken) return;
        try {
            const response = await fetch(`/api/approval?token=${encodeURIComponent(review.approvalToken)}`, {
                credentials: "same-origin",
                headers: { Accept: "application/json" }
            });
            const result = await response.json().catch(() => ({}));
            if (response.ok && result.approval?.status) applyRemoteDecision(result.approval);
        } catch (_) { /* polling retries later */ }
    }

    function bindContactSync() {
        const map = {
            "outcome-phone-input": "input-biz-phone",
            "outcome-email-input": "input-biz-email",
            "outcome-hours-input": "input-biz-hours"
        };
        Object.entries(map).forEach(([sourceId, targetId]) => {
            const source = get(sourceId);
            const target = get(targetId);
            if (!source) return;
            if (target?.value && !source.value) source.value = target.value;
            source.addEventListener("input", () => {
                if (target) {
                    target.value = source.value.trim();
                    target.dispatchEvent(new Event("input", { bubbles: true }));
                    target.dispatchEvent(new Event("change", { bubbles: true }));
                }
                applyState();
            });
        });
    }

    function bind() {
        bindContactSync();
        document.querySelectorAll('input[name="creation-mode"]').forEach((option) => {
            option.addEventListener("change", () => applyState());
        });
        get("client-review-share-btn")?.addEventListener("click", () => createShareableLink());
        get("client-review-copy-btn")?.addEventListener("click", () => copyLink());
        get("client-review-approve-btn")?.addEventListener("click", () => {
            saveReview({ status: "approved", approvedAt: new Date().toISOString(), note: clean(get("client-review-note-field")?.value, 500) });
            setStatus("Revision approved. You can publish this version.", true);
        });
        get("client-review-changes-btn")?.addEventListener("click", () => {
            const note = clean(get("client-review-note-field")?.value, 500);
            if (!note) {
                get("client-review-note-field")?.focus();
                setStatus("Add a short note so the requested changes are specific.");
                return;
            }
            saveReview({ status: "changes-requested", note });
            setStatus("Changes requested. Update the draft, then share a new review.");
        });
        document.addEventListener("click", (event) => {
            const publish = event.target.closest("#publish-site-btn, #go-live-publish-btn");
            if (!publish) return;
            const clientMode = document.body.dataset.creationMode === "client";
            const approved = document.body.dataset.reviewApproved === "true";
            if (clientMode && !approved) {
                event.preventDefault();
                event.stopImmediatePropagation();
                setStatus("Wait for the client to approve this revision before publishing.");
                setLiveStatus("Publishing is locked until this revision is approved.");
                get("client-review-share-btn")?.focus();
                return;
            }
            if (!contactComplete()) {
                event.preventDefault();
                event.stopImmediatePropagation();
                const contactStatus = get("launch-contact-status");
                if (contactStatus) contactStatus.textContent = "Add a phone number, email, and hours before publishing. Visitors need a way to reach you.";
                setLiveStatus("Add phone, email, and hours before publishing.");
                get("outcome-phone-input")?.focus();
            }
        }, true);
        window.addEventListener("storage", (event) => {
            if (event.key && event.key.startsWith(DECISION_PREFIX) && event.newValue) {
                try { applyRemoteDecision(JSON.parse(event.newValue)); } catch (_) {}
            }
        });
        try {
            const channel = new BroadcastChannel("omniscript-review");
            channel.addEventListener("message", (event) => applyRemoteDecision(event.data || {}));
        } catch (_) { /* BroadcastChannel can be unavailable */ }
        window.setInterval(pollDecision, 4000);
        pollDecision();
        applyState();
        window.reviewHandoff = Object.freeze({ createShareableLink, saveReview, currentReview, contactComplete });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
