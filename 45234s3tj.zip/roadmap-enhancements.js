"use strict";

// Product roadmap enhancements that are safe to load independently from the
// editor coordinator. These features improve the default experience without
// changing the existing workspace API contract.
(() => {
    const $ = (id) => document.getElementById(id);
    const state = { assetPreviewUrl: "", performance: [], locale: "en-US" };

    function toast(message, type = "info") {
        const node = $("workspace-toast");
        if (!node) return;
        node.textContent = message;
        node.dataset.state = type;
        node.hidden = false;
        clearTimeout(toast.timer);
        toast.timer = setTimeout(() => { node.hidden = true; }, 4500);
    }

    function updateAssetPreview(file) {
        const preview = $("asset-preview");
        const image = $("asset-preview-image");
        if (!preview || !image || !file) return;
        if (!file.type.startsWith("image/")) {
            toast("Choose an image file.", "error");
            return;
        }
        if (file.size > 8 * 1024 * 1024) {
            toast("Images must be smaller than 8 MB.", "error");
            return;
        }
        if (state.assetPreviewUrl) URL.revokeObjectURL(state.assetPreviewUrl);
        state.assetPreviewUrl = URL.createObjectURL(file);
        image.src = state.assetPreviewUrl;
        image.alt = file.name.replace(/\.[^.]+$/, "");
        preview.hidden = false;
        const alt = $("input-biz-logo-alt");
        if (alt && !alt.value.trim()) alt.value = image.alt;
        toast(`${file.name} is ready for review. Add a public URL before publishing so the asset is available to visitors.`, "success");
    }

    function clearAsset() {
        if (state.assetPreviewUrl) URL.revokeObjectURL(state.assetPreviewUrl);
        state.assetPreviewUrl = "";
        const preview = $("asset-preview");
        const image = $("asset-preview-image");
        const input = $("input-asset-upload");
        if (image) image.removeAttribute("src");
        if (preview) preview.hidden = true;
        if (input) input.value = "";
    }

    function auditGeneratedDocument() {
        const files = window.workspaceAPI?.getState?.()?.files || {};
        const pages = Object.entries(files).filter(([name]) => /\.html$/i.test(name));
        const pageTitles = pages.map(([name, html]) => ({ name, title: String(html).match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "" }));
        const duplicateTitles = pageTitles.filter((page, index) => page.title && pageTitles.findIndex((item) => item.title.toLowerCase() === page.title.toLowerCase()) !== index);
        if (duplicateTitles.length) window.dispatchEvent(new CustomEvent("workspace:content-consistency-warning", { detail: { message: "Multiple pages share the same title; review page-specific SEO copy.", pages: duplicateTitles.map((page) => page.name) } }));
        const documentNode = $("previewContentIframe")?.contentDocument;
        const results = [];
        if (!documentNode?.body) return results;
        const add = (pass, message) => results.push({ pass, message });
        const controls = [...documentNode.querySelectorAll("input:not([type='hidden']), textarea, select, button")];
        const images = [...documentNode.images];
        add(Boolean(documentNode.documentElement.lang), "Generated page declares a language.");
        add(documentNode.querySelectorAll("h1").length === 1, "Generated page has exactly one primary heading.");
        add(Boolean(documentNode.querySelector("main")), "Generated page has a main landmark.");
        add(!images.some((image) => !image.hasAttribute("alt")), "Generated images have alternative text.");
        add(!controls.some((control) => !control.textContent.trim() && !control.getAttribute("aria-label") && !control.getAttribute("title") && !control.id), "Generated controls have accessible names.");
        const ids = [...documentNode.querySelectorAll("[id]")].map((node) => node.id);
        add(new Set(ids).size === ids.length, "Generated page has no duplicate IDs.");
        return results;
    }

    function renderAccessibilitySignals() {
        const results = auditGeneratedDocument();
        const failed = results.filter((item) => !item.pass).length;
        const status = $("visual-qa-status");
        if (status && results.length && failed) {
            status.textContent = `${failed} accessibility review${failed === 1 ? "" : "s"} recommended`;
            status.dataset.state = "warn";
        }
        window.dispatchEvent(new CustomEvent("workspace:generated-accessibility-audit", { detail: { results, failed } }));
    }

    function observePerformance() {
        if (!window.PerformanceObserver) return;
        const names = ["largest-contentful-paint", "layout-shift", "first-input", "event"];
        names.forEach((name) => {
            try {
                const observer = new PerformanceObserver((list) => {
                    list.getEntries().forEach((entry) => {
                        state.performance.push({ name, value: entry.startTime || entry.duration || 0, recordedAt: Date.now() });
                    });
                    state.performance = state.performance.slice(-100);
                    window.dispatchEvent(new CustomEvent("workspace:performance-signal", { detail: { name, entries: state.performance.slice(-10) } }));
                });
                observer.observe({ type: name, buffered: true, durationThreshold: name === "event" ? 40 : undefined });
            } catch {}
        });
    }

    function addLocaleControl() {
        const header = document.querySelector(".canvas-title-group");
        if (!header || $("workspace-locale-select")) return;
        const label = document.createElement("label");
        label.className = "workspace-locale-control field-descriptor-text";
        label.textContent = "Language ";
        const select = document.createElement("select");
        select.id = "workspace-locale-select";
        select.className = "preview-zoom-select";
        [["en-US", "English"], ["en-GB", "English (UK)"], ["fr-FR", "Français"], ["de-DE", "Deutsch"], ["es-ES", "Español"], ["ar", "العربية (RTL preview)" ]].forEach(([value, text]) => {
            const option = document.createElement("option");
            option.value = value;
            option.textContent = text;
            select.append(option);
        });
        select.value = state.locale;
        select.addEventListener("change", () => {
            state.locale = select.value;
            document.documentElement.lang = state.locale.split("-")[0];
            document.documentElement.dir = state.locale === "ar" ? "rtl" : "ltr";
            toast("Language preference saved for this workspace. Generated copy still needs translation review.", "info");
            window.dispatchEvent(new CustomEvent("workspace:locale-changed", { detail: { locale: state.locale, rtl: state.locale === "ar" } }));
        });
        label.append(select);
        header.append(label);
    }

    function exposePlatformContracts() {
        const platform = {
            version: 1,
            providers: {},
            deploymentProviders: ["netlify", "static-export"],
            analytics: { mode: "first-party-ready", productionConnected: false, endpoint: "/api/analytics", disclaimer: "Production analytics are not connected until a provider and consent policy are configured. Preview counters remain local to this browser." },
            collaboration: { teams: false, approvals: false, clientLinks: false },
            environments: ["draft", "staging", "production"],
            analyticsProviders: ["local-preview", "plausible", "umami", "posthog"],
            localeSupport: ["en-US", "en-GB", "fr-FR", "de-DE", "es-ES", "ar"],
            capabilities: {
                teams: false,
                approvals: false,
                staging: false,
                experiments: false,
                whiteLabel: false,
                marketplace: false
            },
            registerProvider(name, provider) {
                if (!/^[a-z][a-z0-9-]{1,40}$/i.test(String(name || "")) || !provider || typeof provider !== "object") throw new Error("Invalid provider registration.");
                platform.providers[name] = provider;
            }
        };
        window.workspacePlatform = platform;
    }

    function dialog(options = {}) {
        const node = $("workspace-dialog");
        const title = $("workspace-dialog-title");
        const message = $("workspace-dialog-message");
        const input = $("workspace-dialog-input");
        const confirm = $("workspace-dialog-confirm");
        if (!node || !title || !message || !confirm || typeof node.showModal !== "function") {
            return Promise.resolve(options.input ? { confirmed: window.confirm(options.message || "Continue?"), value: options.defaultValue || "" } : { confirmed: window.confirm(options.message || "Continue?") });
        }
        title.textContent = options.title || "Confirm action";
        message.textContent = options.message || "Continue?";
        confirm.textContent = options.confirmLabel || "Continue";
        confirm.classList.toggle("variant-danger-text", Boolean(options.destructive));
        confirm.classList.toggle("variant-gold-fill", !options.destructive);
        input.hidden = !options.input;
        input.value = options.defaultValue || "";
        if (options.input) {
            input.placeholder = options.placeholder || "";
            input.required = Boolean(options.required);
        }
        return new Promise((resolve) => {
            const finish = () => {
                node.removeEventListener("close", finish);
                resolve({ confirmed: node.returnValue === "confirm", value: input.value.trim() });
            };
            node.addEventListener("close", finish, { once: true });
            node.showModal();
            (options.input ? input : confirm).focus();
        });
    }

    window.workspaceDialog = dialog;

    function bind() {
        $("input-asset-upload")?.addEventListener("change", (event) => updateAssetPreview(event.target.files?.[0]));
        $("clear-asset-btn")?.addEventListener("click", clearAsset);
        $("previewContentIframe")?.addEventListener("load", () => setTimeout(renderAccessibilitySignals, 120));
        window.addEventListener("workspace:generation-complete", () => setTimeout(renderAccessibilitySignals, 120));
        addLocaleControl();
        exposePlatformContracts();
        observePerformance();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
