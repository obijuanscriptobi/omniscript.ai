"use strict";

(() => {
    const state = window.workspaceState?.createWorkspaceState?.() || {
        files: {},
        form: {},
        projectName: "",
        projectId: null,
        activePage: "index.html",
        previewMode: "desktop",
        dirty: false,
        lastPreviewKey: "",
        requestController: null,
        requestBusy: false,
        initialized: false,
        history: [],
        redoHistory: [],
        historyLimit: 20,
        previewTimer: null,
        previewAuditTimer: null,
        localSaveTimer: null,
        toastTimer: null,
        visualSelection: null,
        visualSection: null,
        previewZoom: 1,
        deploymentHistory: [],
        runtimeErrors: [],
        publishedSiteUrl: "",
        lastSavedSnapshot: "",
        operationToken: 0,
        generationManifest: null,
        repairLog: [],
        manualEditCount: 0,
        manualEditLog: [],
        projectSessionId: "",
        formTestRevision: "",
        importMetadata: null,
        importAnalysis: null,
        importPages: [],
        importAssets: []
    };

    window.addEventListener("crm:sync", (event) => {
        const detail = event.detail || {};
        const status = document.getElementById("lead-inbox-status");
        if (!status || !detail.state) return;
        const messages = {
            pending: "Saving lead changes to the cloud…",
            synced: "Lead changes saved to the cloud.",
            failed: detail.retryable
                ? `Cloud sync failed: ${detail.error || "Try again when the service is available."} Retry is available on the lead.`
                : `Cloud sync was not completed: ${detail.error || "Sign in and select a cloud project first."}`
        };
        status.textContent = messages[detail.state] || "Cloud sync status updated.";
        status.dataset.state = detail.state;
        if (detail.state !== "pending") {
            renderLeadInbox();
            if (detail.state === "failed" && detail.retryable) {
                const leadItem = document.querySelector(`[data-lead-id="${CSS.escape(String(detail.id || ""))}"]`);
                if (leadItem && !leadItem.querySelector("[data-crm-retry]")) {
                    const retry = document.createElement("button");
                    retry.type = "button";
                    retry.className = "matrix-action-btn variant-outline-row";
                    retry.dataset.crmRetry = detail.id;
                    retry.textContent = "Retry cloud sync";
                    leadItem.append(retry);
                }
            }
        }
    });

    document.addEventListener("click", (event) => {
        const retry = event.target.closest("[data-crm-retry]");
        if (!retry || !window.workspaceCRM) return;
        retry.disabled = true;
        retry.textContent = "Retrying…";
        window.workspaceCRM.retryWithCloud(retry.dataset.crmRetry);
    });

    // Protect generated work when the user navigates away with unsaved changes.
    window.addEventListener("beforeunload", (event) => {
        if (!state.dirty || state.requestBusy) return;
        event.preventDefault();
        event.returnValue = "";
    });

    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden" && state.dirty) {
            readEditedFiles();
            saveLocal();
        }
    });

    // Keep multiple workspace tabs from silently overwriting one another.
    window.addEventListener("storage", (event) => {
        if (event.key !== "luxury-engine-workspace" || !event.newValue) return;
        if (event.newValue === state.lastSavedSnapshot) return;

        if (state.dirty) {
            state.externalChangePending = true;
            setStatus("Another workspace tab has newer changes. Save or export this tab before switching.", true);
            showToast("Another tab has newer workspace changes.", "error");
            return;
        }

        loadLocal();
        renderFiles({ dirty: false });
        setStatus("Workspace updated from another tab.");
    });

    const FILE_IDS = window.workspaceConfig?.FILE_IDS || {
        "index.html": "outputContainerHtml",
        "style.css": "outputContainerStyle",
        "script.js": "outputContainerScript",
        "netlify.toml": "outputContainerToml",
        "submit-form.js": "outputContainerFunction"
    };

    const DEFAULT_FILES = window.workspaceConfig?.DEFAULT_FILES || {
        "index.html": "<!-- Awaiting Data Submission -->",
        "style.css": "/* Awaiting Data Submission */",
        "script.js": "// Awaiting Data Submission",
        "netlify.toml": "# Awaiting Data Submission",
        "submit-form.js": "// Awaiting Data Submission"
    };

    const pageTools = window.workspacePages || {};

    function isPageFile(filename) {
        return pageTools.isPageFile?.(filename) || /^([a-z0-9-]+)\.html$/i.test(filename || "");
    }

    function pageFiles() {
        const files = Object.keys(state.files).filter(isPageFile);
        return pageTools.sortPageFiles?.(files) || files.sort((a, b) => a === "index.html" ? -1 : b === "index.html" ? 1 : a.localeCompare(b));
    }

    // Older/partial workspace snapshots can contain only the home page. Recover
    // missing generated pages from the most recent local workflow checkpoint
    // before the page selector is rendered. Never replace the current files.
    function recoverSavedPageFiles() {
        const existingPages = pageFiles();
        if (existingPages.length > 1) return false;
        let candidates = [];
        try {
            const history = JSON.parse(localStorage.getItem("workflow-studio-history") || "[]");
            candidates = Array.isArray(history) ? history.slice().reverse() : [];
        } catch {}
        for (const snapshot of candidates) {
            const files = snapshot?.files;
            if (!files || typeof files !== "object") continue;
            const recovered = Object.entries(files).filter(([filename, content]) => isPageFile(filename) && filename !== "index.html" && String(content || "").trim());
            if (!recovered.length) continue;
            recovered.forEach(([filename, content]) => {
                if (!state.files[filename]) state.files[filename] = String(content);
            });
            return true;
        }
        return false;
    }

    function syncSiteNavigation() {
        if (pageTools.syncNavigation) {
            state.files = pageTools.syncNavigation(state.files);
            return;
        }
        pageFiles().forEach((filename) => {
            if (!/<nav\b[^>]*data-site-navigation[^>]*>/i.test(state.files[filename] || "")) return;
        });
    }

    function syncPageSelector() {
        const selector = $("page-selector");
        if (!selector) return;

        const pages = pageFiles();
        if (!pages.includes(state.activePage)) state.activePage = pages[0] || "index.html";
        selector.replaceChildren(...pages.map((filename) => {
            const option = document.createElement("option");
            option.value = filename;
            option.textContent = filename === "index.html"
                ? "Home — index.html"
                : filename.replace(/\.html$/i, "").replace(/-/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase()) + ` — ${filename}`;
            return option;
        }));
        selector.value = state.activePage;
        const deleteButton = $("delete-page-btn");
        if (deleteButton) {
            deleteButton.disabled = state.activePage === "index.html" || pages.length < 2;
            deleteButton.setAttribute("aria-disabled", String(deleteButton.disabled));
        }
    }

    function activatePage(filename) {
        if (!isPageFile(filename) || !state.files[filename]) return;
        readEditedFiles();
        state.activePage = filename;
        syncPageSelector();
        renderFiles({ dirty: state.dirty });
        const label = filename === "index.html"
            ? "Home (index.html)"
            : `${filename.replace(/\.html$/i, "").replace(/-/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase())} (${filename})`;
        setDebugger(`Editing ${label}. This page is shown in the preview and source editor.`);
    }

    function createPageTemplate(template, title = template, filename = `${template}.html`) {
        const business = getBusinessPayload();
        const name = business.name || "Professional Business";
        const safeTitle = title.trim() || template;
        const pageCopy = {
            about: "Learn more about our approach, experience, and commitment to thoughtful service.",
            services: "Explore the services and solutions we provide for customers like you.",
            contact: "Tell us what you need and we will make the next step simple.",
            faq: "Find clear answers to the questions customers ask most often.",
            privacy: "This page explains how we handle information submitted through this website."
        }[template] || "Tell your visitors more about this part of your business.";
        const formSettings = getFormSettings();
        const publishedSiteUrl = getPublishedSiteUrl();
        const canonicalUrl = publishedSiteUrl
            ? `${publishedSiteUrl}/${filename}`
            : `./${filename}`;
        const extra = template === "contact"
            ? `<form data-site-form action="${escapeHtml(formSettings.endpoint)}" method="post" aria-describedby="page-contact-status"><label for="page-contact-name">Name</label><input id="page-contact-name" name="name" autocomplete="name" required><label for="page-contact-email">Email</label><input id="page-contact-email" name="email" type="email" autocomplete="email"><label for="page-contact-message">Message</label><textarea id="page-contact-message" name="message" required></textarea><input name="website" tabindex="-1" autocomplete="off" aria-hidden="true" class="honeypot"><button class="button" type="submit">Send Message</button><p id="page-contact-status" role="status" aria-live="polite"></p></form>`
            : template === "faq"
                ? `<details><summary>How do I get started?</summary><p>Contact us and we will recommend the right next step.</p></details><details><summary>Where do you serve?</summary><p>${escapeHtml(business.location || "Our local service area")}</p></details>`
                : `<p>${escapeHtml(pageCopy)}</p>`;
        return `<!doctype html>\n<html lang="en">\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1">\n    <meta name="description" content="${escapeHtml(safeTitle)} — ${escapeHtml(name)}">\n    <meta name="robots" content="index,follow">\n    <link rel="canonical" href="${escapeHtml(canonicalUrl)}">\n    <meta property="og:type" content="website">\n    <meta property="og:title" content="${escapeHtml(safeTitle)} — ${escapeHtml(name)}">\n    <meta property="og:description" content="${escapeHtml(pageCopy)}">\n    <meta name="twitter:card" content="summary">\n    <title>${escapeHtml(safeTitle)} — ${escapeHtml(name)}</title>\n    <link rel="stylesheet" href="./style.css">\n</head>\n<body>\n    <header class="hero"><p class="eyebrow"><a href="./index.html">${escapeHtml(name)}</a></p><h1>${escapeHtml(safeTitle)}</h1></header>\n    <main><nav data-site-navigation aria-label="Primary navigation"><a href="./index.html">Home</a> · <a href="./about.html">About</a> · <a href="./services.html">Services</a> · <a href="./contact.html">Contact</a></nav><section>${extra}</section><p><a class="button" href="./index.html">Return home</a></p></main>\n    <script src="./script.js" defer></script>\n</body>\n</html>`;
    }

    function addTemplatePage() {
        const template = $("page-template-selector")?.value || "about";
        const filename = `${template}.html`;
        if (state.files[filename]) {
            state.activePage = filename;
            syncPageSelector();
            renderFiles({ dirty: state.dirty });
            showToast(`${filename} is already available.`, "info");
            return;
        }
        pushHistory();
        state.files[filename] = createPageTemplate(template, template.charAt(0).toUpperCase() + template.slice(1));
        syncSiteNavigation();
        state.activePage = filename;
        syncPageSelector();
        renderFiles({ dirty: true });
        setDebugger(`Added ${filename} template.`);
    }

    async function addPage() {
        const result = await window.workspaceDialog?.({ title: "Add a page", message: "Choose a short page name. The page starts from an editable template.", input: true, defaultValue: "About", placeholder: "About or Services", required: true, confirmLabel: "Add page" }) || { confirmed: false };
        if (!result.confirmed) return;
        const rawName = result.value;
        const slug = rawName.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
        if (!slug || slug === "index") {
            showToast("Choose a different page name.", "error");
            return;
        }
        const filename = `${slug}.html`;
        if (state.files[filename]) {
            showToast("That page already exists.", "error");
            return;
        }
        pushHistory();
        const title = rawName.trim() || slug;
        const business = getBusinessPayload();
        state.files[filename] = createPageTemplate("custom", title, filename);
        syncSiteNavigation();
        state.activePage = filename;
        syncPageSelector();
        renderFiles({ dirty: true });
        setDebugger(`Added ${filename}. Edit the page source or create another page.`);
    }

    async function deletePage() {
        if (state.activePage === "index.html") return;
        const filename = state.activePage;
        const result = await window.workspaceDialog?.({ title: "Delete page", message: `Delete ${filename}? This removes the page from the current project.`, confirmLabel: "Delete page", destructive: true }) || { confirmed: false };
        if (!result.confirmed) return;
        pushHistory();
        delete state.files[filename];
        syncSiteNavigation();
        state.activePage = "index.html";
        syncPageSelector();
        renderFiles({ dirty: true });
        setDebugger(`${filename} deleted.`);
    }

    function $(id) {
        return document.getElementById(id);
    }

    function setStatus(message, error = false) {
        const element = $("status-vector");

        if (element) {
            element.textContent = message;
            element.style.color = error ? "#f87171" : "";
        }
    }

    function setDebugger(message, error = false) {
        const element = $("aiDebuggerFeedback");

        if (element) {
            element.textContent = message;
            element.style.color = error ? "#f87171" : "";
        }
    }

    function showToast(message, type = "info") {
        const toast = $("workspace-toast");

        if (!toast) return;

        clearTimeout(state.toastTimer);
        toast.textContent = message;
        toast.dataset.state = type;
        toast.hidden = false;
        state.toastTimer = setTimeout(() => {
            toast.hidden = true;
        }, 4200);
    }

    function recordManualEdit(operation = "edit", changedFiles = []) {
        state.manualEditCount = Number(state.manualEditCount || 0) + 1;
        state.manualEditLog = [{ operation, files: [...new Set(changedFiles)].slice(0, 20), createdAt: new Date().toISOString() }, ...(state.manualEditLog || [])].slice(0, 100);
        window.dispatchEvent(new CustomEvent("workspace:manual-edit", { detail: { operation, count: state.manualEditCount } }));
    }

    function recordRepairChange(sourceFiles, nextFiles, operation = "repair") {
        const changes = Object.keys({ ...sourceFiles, ...nextFiles }).map((filename) => {
            const before = String(sourceFiles?.[filename] || "");
            const after = String(nextFiles?.[filename] || "");
            return before === after ? null : {
                filename,
                beforeBytes: new TextEncoder().encode(before).length,
                afterBytes: new TextEncoder().encode(after).length,
                beforeHash: simpleHash(before),
                afterHash: simpleHash(after)
            };
        }).filter(Boolean);
        if (changes.length) {
            state.repairLog = [{ operation, createdAt: new Date().toISOString(), changes }, ...state.repairLog].slice(0, 20);
        }
        return changes;
    }

    function renderRuntimeErrors() {
        const panel = document.querySelector(".workspace-error-panel");
        const list = $("workspace-error-list");
        if (panel) panel.hidden = state.runtimeErrors.length === 0;
        if (list) {
            list.replaceChildren(...state.runtimeErrors.map((item) => {
                const row = document.createElement("li");
                row.textContent = `${new Date(item.createdAt).toLocaleTimeString()} — ${item.message}`;
                return row;
            }));
        }
    }

    function recordRuntimeError(error, context = "Runtime error") {
        const message = error?.message || String(error || "Unknown error");
        const entry = { message: `${context}: ${message}`.slice(0, 500), createdAt: new Date().toISOString() };
        state.runtimeErrors = [entry, ...state.runtimeErrors].slice(0, 10);
        renderRuntimeErrors();
        scheduleLocalSave();
    }

    function runWorkspaceTests() {
        const tests = [];
        const check = (name, condition) => tests.push({ name, passed: Boolean(condition) });
        const generated = window.workspaceGenerator?.createProject?.() || createGeneratedProject();
        const report = getQualityReport();
        const zip = createZip({ "index.html": generated["index.html"], "style.css": generated["style.css"] });
        let restored = false;
        try {
            const snapshot = workspaceSnapshot();
            applySnapshot(snapshot, { dirty: false });
            restored = state.files["index.html"] === snapshot.files["index.html"];
        } catch (error) {
            recordRuntimeError(error, "Workspace test");
        }
        check("Project generation returns HTML, CSS, JavaScript, and deployment files", generated["index.html"] && generated["style.css"] && generated["script.js"] && generated["netlify.toml"]);
        check("Generated HTML contains title, heading, form, and structured data", /<title[ >]/i.test(generated["index.html"]) && /<h1[ >]/i.test(generated["index.html"]) && /<form[ >]/i.test(generated["index.html"]) && generated["index.html"].includes("application/ld+json"));
        check("Quality report returns blocking and advisory issue arrays", Array.isArray(report.blocking) && Array.isArray(report.issues));
        check("ZIP export creates a non-empty archive", zip instanceof Uint8Array && zip.length > 30);
        check("Workspace snapshot restores without losing the active file", restored && Boolean(state.activePage) && Boolean(state.files[state.activePage]));
        check("Preview iframe is wired", Boolean($("previewContentIframe")));
        const shellIssues = window.workspaceShellAudit?.auditWorkspaceShell?.(document) || [];
        check("Workspace shell has no duplicate IDs", !shellIssues.some((issue) => issue.message.startsWith("Duplicate id")));
        check("Workspace shell keeps form controls accessible", !shellIssues.some((issue) => issue.message.includes("no accessible label")));
        const fileIssues = window.workspaceShellAudit?.auditFiles?.(state.files) || [];
        const headingIssues = window.workspaceShellAudit?.auditHeadings?.(state.files) || [];
        check("Generated pages contain no broken local links", !fileIssues.some((issue) => issue.severity === "error"));
        check("Generated pages have a usable heading structure", !headingIssues.some((issue) => issue.severity === "error"));
        const responsiveIssues = window.workspaceResponsive?.runResponsiveAudit?.(
            generated,
            $("previewContentIframe")?.contentDocument || null
        ) || [];
        check("Responsive audit covers fluid widths from 320px to 1440px", Boolean(window.workspaceResponsive?.VIEWPORTS?.includes(320)) && Boolean(window.workspaceResponsive?.VIEWPORTS?.includes(1440)));
        check("Generated source has no blocking responsive overflow findings", !responsiveIssues.some((entry) => entry.severity === "error"));

        const list = $("workspace-test-results");
        const status = $("workspace-test-status");
        const passed = tests.filter((test) => test.passed).length;
        if (list) list.replaceChildren(...tests.map((test) => {
            const item = document.createElement("li");
            item.dataset.state = test.passed ? "pass" : "fail";
            item.textContent = `${test.passed ? "PASS" : "FAIL"} — ${test.name}`;
            return item;
        }));
        if (status) status.textContent = `${passed}/${tests.length} workspace checks passed.`;
        showToast(passed === tests.length ? "Workspace checks passed." : "Some workspace checks need attention.", passed === tests.length ? "success" : "error");
        return tests;
    }

    async function runProductionIntegrationCheck() {
        const button = $("run-production-check-btn");
        const status = $("production-check-status");
        const results = $("production-check-results");
        const routes = [
            { name: "Configuration", path: "/api/config", method: "GET", expected: [200, 401, 403] },
            { name: "Website search", path: "/api/search", method: "POST", expected: [400, 401, 403, 415] },
            { name: "Website scrape", path: "/api/scrape", method: "POST", expected: [400, 401, 403, 415] },
            { name: "Website repair", path: "/api/repair", method: "POST", expected: [400, 401, 403, 415] },
            { name: "Project preflight", path: "/api/preflight", method: "POST", expected: [400, 401, 403, 415] },
            { name: "Form submission", path: "/api/submit-form", method: "OPTIONS", expected: [200, 204, 405] },
            { name: "Deployment", path: "/api/deploy", method: "POST", expected: [400, 401, 403, 405] },
            { name: "Published-site verification", path: "/api/verify-deployment", method: "POST", expected: [400, 401, 403, 415] }
        ];
        const checks = [];
        const setCheck = (name, passed, message) => checks.push({ name, passed, message });
        const classifyRoute = async ({ name, path, method, expected }) => {
            try {
                const response = await fetch(path, {
                    method,
                    credentials: "same-origin",
                    cache: "no-store",
                    headers: { Accept: "application/json", "Content-Type": "application/json" },
                    body: method === "POST" ? "{}" : undefined
                });
                if (response.status === 404) {
                    setCheck(name, false, `${path} was not found after deployment.`);
                } else if (response.status >= 500) {
                    setCheck(name, false, `${path} returned a server error (HTTP ${response.status}). Check function configuration and environment variables.`);
                } else if (!expected.includes(response.status)) {
                    setCheck(name, false, `${path} returned HTTP ${response.status}; expected one of ${expected.join(", ")}.`);
                } else {
                    setCheck(name, true, `${path} handled ${method} as expected (HTTP ${response.status}).`);
                }
            } catch (error) {
                setCheck(name, false, `${path} could not be reached: ${error.message || "network error"}.`);
            }
        };

        if (button) setButtonBusy(button, true, "Checking…");
        if (status) status.textContent = "Checking the deployed API routes…";
        if (results) results.replaceChildren();

        try {
            await Promise.all(routes.map(classifyRoute));
            const passed = checks.filter((check) => check.passed).length;
            const allPassed = passed === checks.length;
            if (status) status.textContent = `${passed}/${checks.length} production integrations reachable.`;
            if (results) {
                results.replaceChildren(...checks.map((check) => {
                    const item = document.createElement("li");
                    item.dataset.state = check.passed ? "pass" : "fail";
                    item.textContent = `${check.passed ? "PASS" : "FIX"} — ${check.name}: ${check.message}`;
                    return item;
                }));
            }
            showToast(allPassed ? "Production integrations are reachable." : "Some production integrations need attention.", allPassed ? "success" : "error");
            return checks;
        } finally {
            if (button) setButtonBusy(button, false);
        }
    }

    function clearRuntimeErrors() {
        state.runtimeErrors = [];
        const panel = document.querySelector(".workspace-error-panel");
        const list = $("workspace-error-list");
        if (panel) panel.hidden = true;
        if (list) list.replaceChildren();
        renderRuntimeErrors();
        scheduleLocalSave();
    }

    // One shared busy-state contract for every workspace action. Keep the
    // visible label and dimensions unchanged; CSS adds a non-layout spinner.
    function setButtonBusy(button, busy) {
        if (!button) return;

        if (busy) {
            if (button.dataset.loading === "true") return false;
            button.dataset.loading = "true";
            button.dataset.originalDisabled = String(button.disabled);
            button.dataset.originalAriaDisabled = button.getAttribute("aria-disabled") || "";
            button.dataset.originalAriaLabel = button.getAttribute("aria-label") || "";
            button.disabled = true;
            button.setAttribute("aria-busy", "true");
            button.setAttribute("aria-disabled", "true");
            const label = button.dataset.originalAriaLabel || button.textContent.trim();
            button.setAttribute("aria-label", `${label} (in progress)`);
            return true;
        }

        if (button.dataset.loading !== "true") return false;
        button.disabled = button.dataset.originalDisabled === "true";
        if (button.dataset.originalAriaDisabled) {
            button.setAttribute("aria-disabled", button.dataset.originalAriaDisabled);
        } else {
            button.removeAttribute("aria-disabled");
        }
        if (button.dataset.originalAriaLabel) {
            button.setAttribute("aria-label", button.dataset.originalAriaLabel);
        } else {
            button.removeAttribute("aria-label");
        }
        delete button.dataset.loading;
        delete button.dataset.originalDisabled;
        delete button.dataset.originalAriaDisabled;
        delete button.dataset.originalAriaLabel;
        button.removeAttribute("aria-busy");
        return true;
    }

    // Delegation covers buttons rendered after initial startup and blocks rapid
    // duplicate activation before an individual handler gets to run.
    document.addEventListener("click", (event) => {
        const button = event.target.closest("button[data-loading=\"true\"]");
        if (button) event.preventDefault();
    }, true);

    function beginOperation() {
        state.operationToken += 1;
        return state.operationToken;
    }

    function isCurrentOperation(token) {
        return token === state.operationToken;
    }

    function createFileManifest(files = state.files) {
        return Object.fromEntries(Object.entries(files || {}).map(([filename, content]) => [
            filename,
            { bytes: new TextEncoder().encode(String(content || "")).length, hash: simpleHash(String(content || "")) }
        ]));
    }

    function simpleHash(value) {
        let hash = 2166136261;
        for (let index = 0; index < value.length; index += 1) {
            hash ^= value.charCodeAt(index);
            hash = Math.imul(hash, 16777619);
        }
        return (hash >>> 0).toString(16).padStart(8, "0");
    }

    function setRequestBusy(busy, controller = null) {
        state.requestBusy = Boolean(busy);

        const cancel = $("cancel-generation-btn");

        if (cancel) {
            cancel.disabled = !state.requestBusy;
            cancel.setAttribute(
                "aria-disabled",
                String(!state.requestBusy)
            );
        }

        if (!busy && (!controller || state.requestController === controller)) {
            state.requestController = null;
        }
    }

    function parseResponseBody(response, text) {
        const type = response.headers.get("content-type") || "";

        if (type.includes("json")) {
            try {
                return JSON.parse(text || "{}");
            } catch {
                return {};
            }
        }

        return text ? { message: text.slice(0, 500) } : {};
    }

    function rememberImportPackage(payload) {
        if (!payload || typeof payload !== "object") return;
        state.importMetadata = payload.import || null;
        state.importAnalysis = payload.analysis || null;
        state.importPages = Array.isArray(payload.pages) ? payload.pages.map((page) => ({ url: page.url, status: page.status })) : [];
        state.importAssets = Array.isArray(payload.assets) ? payload.assets.slice(0, 150) : [];
        scheduleLocalSave();
        window.dispatchEvent(new CustomEvent("workspace:import-package", { detail: payload }));
    }

    async function requestJson(url, options = {}) {
        let response;
        const timeoutMs = Number.isFinite(options.timeoutMs) ? options.timeoutMs : 30_000;
        const { timeoutMs: _timeoutOption, ...fetchOptions } = options;
        const controller = new AbortController();
        const externalSignal = fetchOptions.signal;
        const relayAbort = () => controller.abort();
        if (externalSignal) {
            if (externalSignal.aborted) controller.abort();
            else externalSignal.addEventListener("abort", relayAbort, { once: true });
        }
        const timeout = setTimeout(() => controller.abort(), timeoutMs);

        try {
            response = await fetch(url, {
                ...fetchOptions,
                credentials: "same-origin",
                signal: controller.signal,
                headers: {
                    Accept: "application/json",
                    ...(options.body
                        ? { "Content-Type": "application/json" }
                        : {}),
                    ...(options.headers || {})
                }
            });
        } catch (error) {
            // Preserve an intentional user cancellation so callers can show the
            // correct cancelled state instead of reporting a timeout.
            if (error?.name === "AbortError" && externalSignal?.aborted) {
                throw error;
            }
            if (error?.name === "AbortError") {
                throw new Error(`The request timed out after ${Math.round(timeoutMs / 1000)} seconds. Confirm the deployed functions are available, then try again.`);
            }
            throw new Error(
                "The service could not be reached. Confirm the deployed site includes its serverless functions and that site protection allows this request, then try again."
            );
        } finally {
            clearTimeout(timeout);
            externalSignal?.removeEventListener("abort", relayAbort);
        }

        const text = await response.text();
        const body = parseResponseBody(response, text);

        if (!response.ok) {
            const statusMessage = response.status === 401 || response.status === 403
                ? "The deployed workspace is access-protected. Sign in or disable site protection for the public import endpoint."
                : response.status === 404
                    ? "The import service endpoint was not found. Deploy the Netlify functions and confirm the /api route configuration."
                    : "";
            const error = new Error(
                body?.error ||
                    body?.message ||
                    statusMessage ||
                    `Request failed with status ${response.status}.`
            );

            error.status = response.status;
            error.body = body;
            throw error;
        }

        if (body?.success && body?.import) rememberImportPackage(body);
        return body;
    }

    function syncClientSourceUrl() {
        const source = $("client-source-url");
        const legacy = $("input-scrape-url");
        if (!source || !legacy) return;
        const normalized = normalizePublicUrl(source.value);
        if (normalized) legacy.value = normalized;
    }

    function normalizePublicUrl(value, options = {}) {
        let candidate = String(value || "").trim();
        if (!candidate) return "";
        if (options.allowRelative && candidate.startsWith("/") && !candidate.startsWith("//")) return candidate;

        // Accept the common `example.com` form without turning it into a
        // relative URL on the workspace itself.
        if (!/^[a-z][a-z\d+.-]*:\/\//i.test(candidate)) {
            candidate = `https://${candidate}`;
        }

        try {
            const parsed = new URL(candidate);
            if (
                ["https:", "http:"].includes(parsed.protocol) &&
                parsed.hostname &&
                !parsed.username &&
                !parsed.password &&
                !parsed.hash
            ) {
                return parsed.href;
            }
        } catch {}
        return "";
    }

    function getPublishedSiteUrl() {
        const input = $("published-site-url-input");
        const value = input ? input.value.trim() : state.publishedSiteUrl || "";
        try {
            const url = new URL(value);
            if (
                url.protocol !== "https:" ||
                url.username ||
                url.password ||
                url.search ||
                url.hash
            ) return "";
            return `${url.origin}${url.pathname.replace(/\/$/, "")}`;
        } catch {
            return "";
        }
    }

    function safeGeneratedFormAction(value) {
        const raw = String(value || "").trim();

        if (!raw || raw.startsWith("//") || /^[a-z][a-z\d+.-]*:/i.test(raw)) {
            return "";
        }

        try {
            const url = new URL(raw, window.location.origin);
            if (url.origin !== window.location.origin) return "";
            return `${url.pathname}${url.search}`;
        } catch {
            return "";
        }
    }

    function getBusinessPayload() {
        // The canonical profile is the source of truth. Workspace fields only
        // mirror it for older tools and imported projects.
        const profile = window.websiteMakerProfileStore?.getState?.();
        if (profile && window.workspaceGenerator?.businessFromProfile) {
            const business = window.workspaceGenerator.businessFromProfile(profile);
            ["logoUrl", "heroImageUrl", "booking"].forEach((key) => { business[key] = normalizePublicUrl(business[key]); });
            return business;
        }
        return window.workspaceFields.readBusiness((value) => normalizePublicUrl(value));
    }

    /* Legacy profile-driven mapping removed. */
    /*
        const location = profile.locations?.[0] || {};
        const offer = profile.offers?.find((item) => item.status !== "inactive") || {};
        const launch = profile.metadata?.launchBrief || {};
        const known = {
            name: profile.identity?.displayName || "",
            hook: profile.identity?.description || offer.description || offer.name || "",
            location: location.city || location.name || "",
            phone: profile.identity?.phone || "",
            email: profile.identity?.email || "",
            audience: launch.audience || "",
            services: (profile.services || []).join(", "),
            primaryGoal: profile.metadata?.primaryAction || "quote",
            primaryCta: launch.goal === "booking" ? "Book an appointment" : launch.goal === "call" ? "Call the business" : launch.goal === "email" ? "Send an enquiry" : "Request a quote",
            differentiator: launch.proof || "",
            approvedClaims: (profile.claims || []).filter((claim) => claim.state === "approved").map((claim) => claim.text).join("\n"),
            brandVoice: profile.brand?.voice || "",
            color: profile.brand?.primaryColor || "",
            secondaryColor: profile.brand?.secondaryColor || "",
            logoUrl: profile.brand?.logoUrl || "",
            logoAlt: profile.brand?.logoAlt || ""
        };
        // The canonical profile is authoritative; optional workspace controls are
        // still read for presentation settings and form configuration.
        return { ...known, ...window.workspaceFields.readBusiness((value) => normalizePublicUrl(value)), ...known, profileRevision: state.businessProfileRevision };
    }

    */

    function getFormSettings() {
        const profile = window.websiteMakerProfileStore?.getState?.();
        if (profile?.form) return { ...profile.form, privacy: { ...(profile.privacy || {}) } };
        return window.workspaceFields.readFormSettings();
    }

    function getSubmissionId() {
        if (window.crypto?.randomUUID) return window.crypto.randomUUID();
        return `submission-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    }

    function bindGeneratedForms(root = document) {
        root.querySelectorAll("form[action], form[data-repair-form='true']").forEach((form) => {
            if (form.dataset.workspaceBound === "true") return;
            form.dataset.workspaceBound = "true";
            form.addEventListener("submit", async (event) => {
                event.preventDefault();
                if (!form.reportValidity() || form.dataset.submitting === "true") return;

                form.dataset.submitting = "true";
                const submit = form.querySelector("button[type='submit'], input[type='submit']");
                const status = form.querySelector("[role='status']");
                if (submit) submit.disabled = true;
                if (status) status.textContent = "Sending…";

                try {
                    const action = safeGeneratedFormAction(
                        form.getAttribute("action") || "/api/submit-form"
                    );

                    if (!action) {
                        throw new Error("This form has an invalid submission endpoint.");
                    }

                    const response = await fetch(action, {
                        method: "POST",
                        body: new URLSearchParams(new FormData(form)),
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                            "X-Submission-ID": getSubmissionId()
                        },
                        credentials: "same-origin"
                    });
                    const result = await response.json().catch(() => ({}));
                    if (!response.ok || !result.success) throw new Error(result.error || "Submission failed.");
                    if (status) {
                        status.textContent = result.message || "Thanks — your request was sent.";
                        status.dataset.state = "success";
                    }
                    const submissionData = new FormData(form);
                    const lead = {
                        name: submissionData.get("name"),
                        email: submissionData.get("email"),
                        phone: submissionData.get("phone"),
                        message: submissionData.get("message"),
                        source: "website-form",
                        campaign: new URLSearchParams(window.location.search).get("utm_campaign") || "",
                        projectId: window.workspaceAPI?.getState?.()?.projectId || ""
                    };
                    window.workspaceCRM?.addWithCloud?.(lead) || window.workspaceCRM?.add?.(lead);
                    form.reset();
                } catch (error) {
                    if (status) {
                        status.textContent = error.message || "The form could not be submitted.";
                        status.dataset.state = "error";
                    }
                } finally {
                    form.dataset.submitting = "false";
                    if (submit) submit.disabled = false;
                }
            });
        });
    }

    function getPrivacySettings() {
        const privacy = window.websiteMakerProfileStore?.getState?.().privacy;
        if (privacy) return {
            retention: privacy.retention || "",
            processors: privacy.processors || "",
            rights: privacy.rightsContact || "",
            analytics: privacy.analytics || "essential",
            effective: privacy.effectiveDate || ""
        };
        return window.workspaceFields.readPrivacySettings();
    }

    function getWorkspaceFieldValues(snapshot = state) {
        return window.workspaceFields.getValues(snapshot);
    }

    function applyWorkspaceFieldValues(snapshot = state) {
        window.workspaceFields.apply(snapshot);
    }

    function getWorkspaceForm() {
        return {
            scrapeUrl: $("client-source-url")?.value.trim() || $("input-scrape-url")?.value.trim() || "",
            business: getBusinessPayload(),
            formSettings: getFormSettings(),
            privacy: getPrivacySettings()
        };
    }

    function workspaceSnapshot() {
        readEditedFiles();
        const businessFields = window.workspaceFields?.readBusiness?.((value) => value) || state.businessFields || {};
        const formSettings = getFormSettings();
        const metadata = { businessFields, formSettings, activePage: state.activePage, workflowStep: Number(state.workflowStep || 0) };
        const projectRevision = window.workspaceDomain?.revisionOf?.(state.files || {}) || simpleHash(JSON.stringify({ files: state.files, metadata }));
        return {
            schemaVersion: 1,
            files: { ...state.files },
            businessFields: JSON.parse(JSON.stringify(businessFields)),
            formSettings: JSON.parse(JSON.stringify(formSettings)),
            designTokens: JSON.parse(JSON.stringify(state.designTokens || {})),
            activePage: state.activePage,
            workflowStep: Number(state.workflowStep || 0),
            projectRevision,
            releaseEvidence: state.releaseEvidence || null,
            form: JSON.parse(JSON.stringify(state.form || {})),
            projectName: state.projectName,
            projectId: state.projectId,
            publishedSiteUrl: getPublishedSiteUrl(),
            previewMode: state.previewMode
        };
    }

    function pushHistory() {
        const snapshot = {
            files: { ...state.files },
            form: JSON.parse(JSON.stringify(state.form || {})),
            projectName: state.projectName,
            projectId: state.projectId,
            activePage: state.activePage,
            previewMode: state.previewMode
        };

        const previous = state.history[state.history.length - 1];

        if (
            previous &&
            JSON.stringify(previous) === JSON.stringify(snapshot)
        ) {
            return;
        }

        state.history.push(snapshot);
        state.redoHistory = [];

        if (state.history.length > state.historyLimit) {
            state.history.shift();
        }

        updateUndoButton();
    }

    function updateUndoButton() {
        const button = $("undo-workspace-btn");
        const redoButton = $("redo-workspace-btn");

        if (button) {
            button.disabled = state.history.length === 0;
            button.setAttribute("aria-disabled", String(button.disabled));
        }
        if (redoButton) {
            redoButton.disabled = state.redoHistory.length === 0;
            redoButton.setAttribute("aria-disabled", String(redoButton.disabled));
        }
    }

    function saveLocal() {
        if (state.externalChangePending) {
            const saveStatus = $("workspace-save-status");
            if (saveStatus) {
                saveStatus.textContent = "Another tab has newer changes. Export this workspace before continuing.";
                saveStatus.setAttribute("aria-invalid", "true");
            }
            return false;
        }

        try {
            const snapshot = workspaceSnapshot();
            const serializedWorkspace = JSON.stringify({
                schemaVersion: 1,
                ...snapshot,
                files: state.files,
                form: state.form,
                projectName: state.projectName,
                projectId: state.projectId,
                publishedSiteUrl: getPublishedSiteUrl(),
                activePage: state.activePage,
                previewMode: state.previewMode,
                previewZoom: state.previewZoom,
                deploymentHistory: state.deploymentHistory,
                runtimeErrors: state.runtimeErrors,
                generationManifest: state.generationManifest,
                repairLog: state.repairLog,
                manualEditCount: state.manualEditCount,
                manualEditLog: state.manualEditLog,
                projectSessionId: state.projectSessionId,
                formTestRevision: state.formTestRevision,
                importMetadata: state.importMetadata,
                importAnalysis: state.importAnalysis,
                importPages: state.importPages,
                importAssets: state.importAssets
            });
            if (serializedWorkspace.length > 4_000_000) {
                const saveStatus = $("workspace-save-status");
                if (saveStatus) {
                    saveStatus.textContent = "Local backup is too large. Export a project backup to avoid browser storage limits.";
                    saveStatus.setAttribute("aria-invalid", "true");
                }
                return false;
            }
            localStorage.setItem("luxury-engine-workspace", serializedWorkspace);
            state.lastSavedSnapshot = serializedWorkspace;
            state.localSaveAttempts = 0;
            state.externalChangePending = false;
            return true;
        } catch (error) {
            const saveStatus = $("workspace-save-status");
            if (saveStatus) {
                saveStatus.textContent = "Local autosave is unavailable. Retrying shortly; export your work if this continues.";
                saveStatus.setAttribute("aria-invalid", "true");
            }
            state.localSaveAttempts = Number(state.localSaveAttempts || 0) + 1;
            const entry = { message: `Local autosave: ${error?.message || "storage unavailable"}`.slice(0, 500), createdAt: new Date().toISOString() };
            state.runtimeErrors = [entry, ...state.runtimeErrors].slice(0, 10);
            renderRuntimeErrors();
            if (state.localSaveAttempts <= 3) {
                clearTimeout(state.localSaveTimer);
                state.localSaveTimer = setTimeout(() => {
                    state.localSaveTimer = null;
                    saveLocal();
                }, Math.min(2_000 * (2 ** (state.localSaveAttempts - 1)), 8_000));
            } else {
                showToast("Local autosave failed repeatedly. Export your work now.", "error");
            }
            return false;
        }
    }

    function renderDeploymentHistory() {
        const list = $("deployment-history-list");
        const clearButton = $("clear-deployment-history-btn");
        if (!list) return;

        if (!state.deploymentHistory.length) {
            list.replaceChildren(Object.assign(document.createElement("li"), {
                className: "field-descriptor-text",
                textContent: "No deployments recorded yet."
            }));
        } else {
            list.replaceChildren(...state.deploymentHistory.map((deployment) => {
                const item = document.createElement("li");
                item.className = "deployment-history-item";
                const details = document.createElement("span");
                details.className = "field-descriptor-text";
                details.textContent = `${deployment.projectName || "Untitled project"} · ${deployment.state || "published"} · ${new Date(deployment.createdAt).toLocaleString()}`;
                item.append(details);
                        if (normalizePublicUrl(deployment.url)) {
                    const link = document.createElement("a");
                    link.href = normalizePublicUrl(deployment.url);
                    link.target = "_blank";
                    link.rel = "noopener noreferrer";
                    link.textContent = "Open";
                    item.append(link);
                }
                return item;
            }));
        }

        if (clearButton) {
            clearButton.disabled = state.deploymentHistory.length === 0;
            clearButton.setAttribute("aria-disabled", String(clearButton.disabled));
        }
    }

    function recordDeployment(deployment = {}) {
        const deployedUrl = normalizePublicUrl(deployment.url || "");
        if (deployedUrl) {
            state.publishedSiteUrl = deployedUrl;
            const siteUrlInput = $("published-site-url-input");
            if (siteUrlInput) siteUrlInput.value = deployedUrl;
        }
        const entry = {
            id: deployment.id || `local-${Date.now()}`,
            projectName: state.projectName || "Untitled project",
            state: deployment.state || "published",
            url: deployment.url || "",
            files: deployment.files || null,
            manifest: deployment.files ? createFileManifest(deployment.files) : null,
            verification: deployment.verification || null,
            createdAt: new Date().toISOString()
        };
        state.deploymentHistory = [entry, ...state.deploymentHistory].slice(0, 8);
        renderDeploymentHistory();
        window.dispatchEvent(new CustomEvent("workspace:deployment-complete", { detail: { ...entry } }));
        updateRedeployControl();
        scheduleLocalSave();
    }

    function clearDeploymentHistory() {
        if (!state.deploymentHistory.length || !window.confirm("Clear deployment history from this browser?")) return;
        state.deploymentHistory = [];
        renderDeploymentHistory();
        scheduleLocalSave();
        showToast("Deployment history cleared.", "success");
    }

    function scheduleLocalSave() {
        clearTimeout(state.localSaveTimer);
        state.localSaveTimer = setTimeout(() => {
            state.localSaveTimer = null;
            saveLocal();
        }, 250);
    }

    function schedulePreviewUpdate() {
        clearTimeout(state.previewTimer);
        if (typeof window.cancelIdleCallback === "function" && state.previewAuditTimer) {
            window.cancelIdleCallback(state.previewAuditTimer);
        }
        clearTimeout(state.previewAuditTimer);
        state.previewTimer = setTimeout(() => {
            state.previewTimer = null;
            updatePreview();

            const runAudits = () => {
                state.previewAuditTimer = null;
                updateDiagnostics();
                runVisualQualityCheck();
                window.projectHealth?.render?.();
                runPreviewSmokeTests();
            };

            if (typeof window.requestIdleCallback === "function") {
                state.previewAuditTimer = window.requestIdleCallback(runAudits, { timeout: 800 });
            } else {
                state.previewAuditTimer = setTimeout(runAudits, 0);
            }
        }, 120);
    }

    function loadLocal() {
        try {
            const saved = JSON.parse(
                localStorage.getItem("luxury-engine-workspace") || "null"
            );

            if (!saved || typeof saved !== "object") return;

            state.lastSavedSnapshot = JSON.stringify(saved);
            state.externalChangePending = false;

            state.files = {
                ...DEFAULT_FILES,
                ...(saved.files || {})
            };
            recoverSavedPageFiles();
            state.form = saved.form || {};
            state.businessFields = saved.businessFields || saved.form?.business || {};
            state.formSettings = saved.formSettings || saved.form?.formSettings || {};
            state.designTokens = saved.designTokens || {};
            state.workflowStep = Number(saved.workflowStep || 0);
            state.projectRevision = saved.projectRevision || "";
            state.releaseEvidence = saved.releaseEvidence || null;
            state.projectName = saved.projectName || "";
            state.projectId = saved.projectId || null;
            state.publishedSiteUrl = saved.publishedSiteUrl || "";
            state.deploymentHistory = Array.isArray(saved.deploymentHistory) ? saved.deploymentHistory.slice(0, 8) : [];
            state.runtimeErrors = Array.isArray(saved.runtimeErrors) ? saved.runtimeErrors.slice(0, 10) : [];
            state.generationManifest = saved.generationManifest || null;
            state.repairLog = Array.isArray(saved.repairLog) ? saved.repairLog.slice(0, 20) : [];
            state.manualEditCount = Number(saved.manualEditCount || 0);
            state.manualEditLog = Array.isArray(saved.manualEditLog) ? saved.manualEditLog.slice(0, 100) : [];
            state.projectSessionId = saved.projectSessionId || getSubmissionId();
            state.formTestRevision = saved.formTestRevision || "";
            state.importMetadata = saved.importMetadata || null;
            state.importAnalysis = saved.importAnalysis || null;
            state.importPages = Array.isArray(saved.importPages) ? saved.importPages : [];
            state.importAssets = Array.isArray(saved.importAssets) ? saved.importAssets : [];
            state.activePage = saved.activePage || "index.html";
            state.previewMode = ["desktop", "tablet", "mobile"].includes(
                saved.previewMode
            )
                ? saved.previewMode
                : "desktop";
            state.previewZoom = [0.5, 0.75, 0.9, 1].includes(Number(saved.previewZoom)) ? Number(saved.previewZoom) : 1;
            if ($("preview-zoom-select")) $("preview-zoom-select").value = String(state.previewZoom);

            if ($("project-name-input")) {
                $("project-name-input").value = state.projectName;
            }
            if ($("published-site-url-input")) {
                $("published-site-url-input").value = state.publishedSiteUrl;
            }

            applyWorkspaceFieldValues(state);
            renderDeploymentHistory();
            renderRuntimeErrors();
            updateRedeployControl();
        } catch {}
    }

    function currentFilesRevision() {
        return String(
            window.workspaceDomain?.compile?.(state.files || {})?.revision ||
            simpleHash(JSON.stringify(state.files || {}))
        );
    }

    function setDirty(value = true) {
        state.dirty = Boolean(value);
        document.body.classList.toggle("workspace-dirty", state.dirty);
        const saveStatus = $("workspace-save-status");
        if (saveStatus && saveStatus.getAttribute("aria-invalid") !== "true") {
            saveStatus.innerHTML = state.dirty
                ? 'Unsaved local changes.<span class="workspace-save-warning">Save before leaving or publishing.</span>'
                : "Changes are saved locally in this browser.";
        }

        const exportButton = $("export-zip-btn");

        if (exportButton) {
            exportButton.disabled = !Object.values(state.files).some(
                (value) => String(value || "").trim()
            );
            exportButton.setAttribute(
                "aria-disabled",
                String(exportButton.disabled)
            );
        }

        updateUndoButton();
        window.dispatchEvent(new CustomEvent("workspace:files-rendered", {
            detail: { revision: currentFilesRevision(), dirty: state.dirty }
        }));
        if (state.dirty) setPublishReady(false);
        scheduleLocalSave();
    }

    function renderFiles(options = {}) {
        const { dirty = false } = options;

        syncPageSelector();
        const visibleFiles = { ...FILE_IDS };
        if (state.activePage !== "index.html") delete visibleFiles["index.html"];
        visibleFiles[state.activePage] = "outputContainerHtml";
        Object.entries(visibleFiles).forEach(([filename, id]) => {
            const element = $(id);

            if (!element) return;

            const source = state.files[filename] || "";
            element.textContent = window.workspaceFormatter?.formatFile
                ? window.workspaceFormatter.formatFile(filename, source)
                : source;
            element.contentEditable = "true";
            element.spellcheck = false;
            element.dataset.file = filename;
            element.setAttribute("aria-label", `Editable ${filename}`);
        });

        updatePreview();
        updateDiagnostics();
        setDirty(dirty);
    }

    function readEditedFiles() {
        const before = { ...state.files };
        Object.entries(FILE_IDS).forEach(([filename, id]) => {
            if (filename === "index.html" && state.activePage !== "index.html") return;
            const element = $(id);

            if (element?.isContentEditable) {
                state.files[filename] = element.textContent || "";
            }
        });

        if (state.activePage !== "index.html") {
            const activePageElement = $("outputContainerHtml");
            if (activePageElement?.isContentEditable) {
                state.files[state.activePage] = activePageElement.textContent || "";
            }
        }

        state.form = getWorkspaceForm();
        state.projectName =
            $("project-name-input")?.value.trim() || state.projectName;
        state.publishedSiteUrl = getPublishedSiteUrl();
        const changedFiles = Object.keys({ ...before, ...state.files }).filter((filename) => String(before[filename] || "") !== String(state.files[filename] || ""));
        if (changedFiles.length && !state.requestBusy) recordManualEdit("source-edit", changedFiles);
    }

    function applySnapshot(snapshot = {}, options = {}) {
        const candidateFiles = snapshot && typeof snapshot.files === "object" && !Array.isArray(snapshot.files)
            ? Object.fromEntries(Object.entries(snapshot.files).map(([name, content]) => [String(name), String(content ?? "")]))
            : null;
        const safetyIssues = candidateFiles ? (window.workspaceContentSafety?.validateFiles?.(candidateFiles) || []) : [{ message: "Snapshot files are missing or invalid." }];
        if (safetyIssues.length) {
            const error = new Error(`Snapshot rejected: ${safetyIssues[0].message}`);
            window.dispatchEvent(new CustomEvent("workspace:snapshot-rejected", { detail: { error: error.message, issues: safetyIssues } }));
            throw error;
        }
        const nextFiles = { ...DEFAULT_FILES, ...candidateFiles };
        const nextForm = snapshot.form && typeof snapshot.form === "object" && !Array.isArray(snapshot.form)
            ? JSON.parse(JSON.stringify(snapshot.form))
            : {};
        const nextBusinessFields = snapshot.businessFields && typeof snapshot.businessFields === "object" ? JSON.parse(JSON.stringify(snapshot.businessFields)) : {};
        const nextFormSettings = snapshot.formSettings && typeof snapshot.formSettings === "object" ? JSON.parse(JSON.stringify(snapshot.formSettings)) : {};
        const nextDesignTokens = snapshot.designTokens && typeof snapshot.designTokens === "object" ? JSON.parse(JSON.stringify(snapshot.designTokens)) : {};
        const nextMode = ["desktop", "tablet", "mobile"].includes(snapshot.previewMode) ? snapshot.previewMode : "desktop";
        const nextActivePage = typeof snapshot.activePage === "string" && (nextFiles[snapshot.activePage] || snapshot.activePage === "index.html")
            ? snapshot.activePage
            : "index.html";

        // All validation and cloning happens before the live state is touched.
        // A malformed backup therefore cannot leave a half-restored workspace.
        if (options.replaceContext) {
            clearProjectContext({ persist: false, announce: false });
            state.projectSessionId = getSubmissionId();
        }
        state.files = nextFiles;
        state.form = nextForm;
        state.businessFields = nextBusinessFields;
        state.formSettings = nextFormSettings;
        state.designTokens = nextDesignTokens;
        state.workflowStep = Number.isFinite(Number(snapshot.workflowStep)) ? Number(snapshot.workflowStep) : 0;
        state.projectRevision = String(snapshot.projectRevision || "");
        state.releaseEvidence = options.dirty ? null : (snapshot.releaseEvidence || null);
        state.projectName = String(snapshot.projectName || "");
        state.projectId = snapshot.projectId || null;
        state.publishedSiteUrl = String(snapshot.publishedSiteUrl || "");
        state.activePage = nextActivePage;
        state.previewMode = nextMode;

        if ($("project-name-input")) $("project-name-input").value = state.projectName;
        if ($("published-site-url-input")) $("published-site-url-input").value = state.publishedSiteUrl;
        applyWorkspaceFieldValues({ ...state, form: { ...state.form, business: state.businessFields, formSettings: state.formSettings } });
        renderFiles({ dirty: options.dirty ?? false });
        setPreviewMode(state.previewMode);
        window.dispatchEvent(new CustomEvent("workspace:project-context-changed", {
            detail: { projectId: state.projectId, sessionId: state.projectSessionId }
        }));
    }

    function clearVisualSelection() {
        state.visualSelection = null;
        state.visualSection = null;
        const sectionLabel = $("section-editor-selection");
        if (sectionLabel) sectionLabel.textContent = "No section selected";
        ["section-move-up-btn", "section-move-down-btn", "section-duplicate-btn", "section-delete-btn"].forEach((id) => {
            const button = $(id);
            if (button) button.disabled = true;
        });
        const input = $("visual-editor-text");
        const link = $("visual-editor-link");
        const color = $("visual-editor-color");
        const size = $("visual-editor-size");
        const apply = $("visual-editor-apply-btn");
        const clear = $("visual-editor-clear-btn");
        const label = $("visual-editor-selection");
        [input, link, color, size].forEach((control) => {
            if (!control) return;
            control.value = control.type === "color" ? "#18202b" : control.type === "range" ? "1" : "";
            control.disabled = true;
        });
        if (apply) apply.disabled = true;
        if (clear) clear.disabled = true;
        if (label) label.textContent = "Nothing selected";
    }

    function selectVisualElement(element) {
        if (!element || !element.matches("h1, h2, h3, p, a, button, label, li, span, img")) return;
        const text = element.textContent.trim();
        if (!text && element.tagName !== "IMG") return;
        if (text.length > 500) return;
        state.visualSelection = { selector: element.dataset.visualSelector || "", text };
        const input = $("visual-editor-text");
        const link = $("visual-editor-link");
        const color = $("visual-editor-color");
        const size = $("visual-editor-size");
        const apply = $("visual-editor-apply-btn");
        const clear = $("visual-editor-clear-btn");
        const label = $("visual-editor-selection");
        if (input) {
            input.value = text;
            input.disabled = element.tagName === "IMG";
            input.focus();
        }
        if (link) {
            link.value = element.tagName === "A" ? element.getAttribute("href") || "" : "";
            link.disabled = element.tagName !== "A";
        }
        if (color) {
            const candidate = element.ownerDocument.defaultView.getComputedStyle(element).color;
            color.value = /^#[0-9a-f]{6}$/i.test(candidate) ? candidate : "#18202b";
            color.disabled = false;
        }
        if (size) {
            const pixels = parseFloat(element.ownerDocument.defaultView.getComputedStyle(element).fontSize) || 16;
            size.value = Math.min(4, Math.max(0.75, (pixels / 16).toFixed(2)));
            size.disabled = false;
        }
        if (apply) apply.disabled = false;
        if (clear) clear.disabled = false;
        if (label) label.textContent = `Selected <${element.tagName.toLowerCase()}>`;
    }

    function selectVisualSection(section) {
        if (!section || !section.matches("main > section, header.hero, footer.site-footer")) return;
        const iframe = $("previewContentIframe");
        const sections = [...(iframe?.contentDocument?.querySelectorAll("main > section, header.hero, footer.site-footer") || [])];
        state.visualSection = { index: sections.indexOf(section), title: section.querySelector("h1,h2,h3")?.textContent.trim() || section.className || "Section" };
        const label = $("section-editor-selection");
        if (label) label.textContent = `Selected ${state.visualSection.title}`;
        const index = state.visualSection.index;
        const controls = {
            "section-move-up-btn": index > 0,
            "section-move-down-btn": index >= 0 && index < sections.length - 1,
            "section-duplicate-btn": true,
            "section-delete-btn": sections.length > 1 && !section.matches("header.hero")
        };
        Object.entries(controls).forEach(([id, enabled]) => { if ($(id)) $(id).disabled = !enabled; });
        sections.forEach((item) => item.style.outline = item === section ? "2px solid #d6b477" : "");
    }

    function updateVisualSection(action) {
        const iframe = $("previewContentIframe");
        const sections = [...(iframe?.contentDocument?.querySelectorAll("main > section, header.hero, footer.site-footer") || [])];
        const index = state.visualSection?.index;
        const section = Number.isInteger(index) ? sections[index] : null;
        if (!section) return;
        readEditedFiles();
        pushHistory();
        if (action === "up" && section.previousElementSibling) section.parentNode.insertBefore(section, section.previousElementSibling);
        if (action === "down" && section.nextElementSibling) section.parentNode.insertBefore(section.nextElementSibling, section);
        if (action === "duplicate") section.parentNode.insertBefore(section.cloneNode(true), section.nextElementSibling);
        if (action === "delete") section.remove();
        sections.forEach((item) => item.style.removeProperty("outline"));
        const html = iframe.contentDocument.documentElement.outerHTML;
        state.files[state.activePage || "index.html"] = `<!doctype html>\n${html}`;
        renderFiles({ dirty: true });
        clearVisualSelection();
        setDebugger(`Section ${action === "delete" ? "deleted" : action === "duplicate" ? "duplicated" : "moved"}.`);
    }

    function bindVisualEditorFrame() {
        const iframe = $("previewContentIframe");
        const documentNode = iframe?.contentDocument;
        if (!documentNode) return;
        clearVisualSelection();
        documentNode.querySelectorAll("a[data-preview-page]").forEach((link) => {
            link.addEventListener("click", (event) => {
                const target = link.dataset.previewPage;
                if (!target || !state.files[target]) return;
                event.preventDefault();
                event.stopPropagation();
                activatePage(target);
            });
        });
        documentNode.querySelectorAll("main > section, header.hero, footer.site-footer").forEach((section) => {
            section.addEventListener("click", (event) => {
                if (event.target.closest("h1, h2, h3, p, a, button, label, li, span, img, input, textarea, select")) return;
                event.preventDefault();
                event.stopPropagation();
                selectVisualSection(section);
            }, true);
        });
        documentNode.querySelectorAll("h1, h2, h3, p, a, button, label, li, span, img").forEach((element, index) => {
            if (element.tagName !== "IMG" && (!element.textContent.trim() || element.textContent.trim().length > 500)) return;
            element.dataset.visualSelector = `${element.tagName.toLowerCase()}[data-visual-index=\"${index}\"]`;
            element.dataset.visualIndex = String(index);
            element.addEventListener("click", (event) => {
                event.preventDefault();
                event.stopPropagation();
                selectVisualElement(element);
            });
        });
    }

    function applyVisualText() {
        const input = $("visual-editor-text");
        const link = $("visual-editor-link");
        const color = $("visual-editor-color");
        const size = $("visual-editor-size");
        const selection = state.visualSelection;
        const iframe = $("previewContentIframe");
        if (!selection || !iframe?.contentDocument) return;
        const elements = iframe.contentDocument.querySelectorAll("h1, h2, h3, p, a, button, label, li, span, img");
        const target = [...elements].find((element) => element.dataset.visualSelector === selection.selector);
        if (!target) return;
        const text = input?.value.trim();
        if (target.tagName !== "IMG" && !text) return;
        readEditedFiles();
        pushHistory();
        if (target.tagName !== "IMG") target.textContent = text;
        if (target.tagName === "A" && link?.value.trim()) {
            const href = link.value.trim();
            const safeHref = /^(?:#|\/|\.\/|\.\.\/|https?:\/\/|mailto:|tel:)/i.test(href) && !/^javascript:/i.test(href);
            if (safeHref) target.setAttribute("href", href);
        }
        const targetIndex = target.dataset.visualIndex || "0";
        const editClass = `workspace-visual-edit-${targetIndex}`;
        target.classList.add(editClass);
        let editorCss = String(state.files["style.css"] || "");
        const rules = [];
        if (color?.value) rules.push(`color: ${color.value};`);
        if (size?.value) rules.push(`font-size: ${size.value}rem;`);
        if (rules.length) {
            const rule = `.${editClass} { ${rules.join(" ")} }`;
            const rulePattern = new RegExp(`\\.${editClass}\\s*\\{[^}]*\\}`, "i");
            editorCss = rulePattern.test(editorCss)
                ? editorCss.replace(rulePattern, rule)
                : `${editorCss.trim()}\n\n${rule}\n`;
            state.files["style.css"] = editorCss;
        }
        const html = iframe.contentDocument.documentElement.outerHTML;
        const targetPage = state.activePage || "index.html";
        state.files[targetPage] = `<!doctype html>\n${html}`;
        renderFiles({ dirty: true });
        setDebugger(`Visual changes applied to ${targetPage}.`);
        showToast("Visual changes applied.", "success");
    }

    function renderLeadInbox() {
        const crm = window.workspaceCRM;
        const list = $("lead-inbox-list");
        const count = $("lead-inbox-count");
        const next = $("lead-inbox-next");
        if (!crm || !list) return;
        const leads = crm.read();
        if (count) count.textContent = `${leads.length} lead${leads.length === 1 ? "" : "s"}`;
        const due = leads.filter((lead) => lead.reminderAt && new Date(lead.reminderAt) <= new Date()).length;
        if (next) next.textContent = due ? `${due} follow-up${due === 1 ? "" : "s"} due.` : "No follow-ups due.";
                list.replaceChildren(...(leads.length ? leads.slice(0, 5).map((lead) =>
             {
            const item = document.createElement("li"); item.dataset.status = lead.status;
            const title = document.createElement("strong"); title.textContent = lead.name || lead.email || "Unnamed lead";
            const meta = document.createElement("span"); meta.textContent = `${lead.source}${lead.campaign ? ` · ${lead.campaign}` : ""}`;
            const controls = document.createElement("div"); controls.className = "lead-inbox-controls";
            const status = document.createElement("select"); status.className = "matrix-text-field"; status.setAttribute("aria-label", `Status for ${lead.name || lead.email || "lead"}`);
            window.workspaceCRM.STATUSES.forEach((value) => { const option = new Option(value, value); option.selected = value === lead.status; status.append(option); });
            status.addEventListener("change", () => window.workspaceCRM.updateWithCloud(lead.id, { status: status.value }));
            const notes = document.createElement("input"); notes.className = "matrix-text-field"; notes.value = lead.notes || ""; notes.maxLength = 2000; notes.placeholder = "Follow-up note"; notes.setAttribute("aria-label", `Notes for ${lead.name || lead.email || "lead"}`);
            notes.addEventListener("change", () => window.workspaceCRM.updateWithCloud(lead.id, { notes: notes.value }));
            controls.append(status, notes); item.append(title, meta, controls); return item;
        }) : [Object.assign(document.createElement("li"), { className: "field-descriptor-text", textContent: "No leads captured yet." })]));
    }

    async function syncCloudLeads() {
        const projectId = window.workspaceAPI?.getState?.()?.projectId || "";
        const status = $("lead-inbox-status");
        if (!projectId || !window.supabaseWorkspace?.getState?.().authenticated) { if (status) status.textContent = "Sign in and select a cloud project before refreshing cloud leads."; return; }
        try {
            const response = await fetch(`/api/leads?projectId=${encodeURIComponent(projectId)}`, { credentials: "same-origin", headers: { Accept: "application/json" } });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Cloud leads could not be loaded.");
            data.leads?.slice().reverse().forEach((lead) => window.workspaceCRM.add({ id: lead.id, name: lead.name, email: lead.email, phone: lead.phone, message: lead.message, status: lead.status, source: lead.source, campaign: lead.campaign, notes: lead.notes, reminderAt: lead.reminder_at, createdAt: lead.created_at }));
            if (status) status.textContent = `${data.leads?.length || 0} cloud leads refreshed.`;
        } catch (error) { if (status) status.textContent = error.message; }
    }

    function bindLeadInbox() {
        renderLeadInbox();
        window.addEventListener("crm:updated", renderLeadInbox);
        $("sync-leads-btn")?.addEventListener("click", syncCloudLeads);
        $("export-leads-btn")?.addEventListener("click", () => {
            const csv = window.workspaceCRM?.exportCsv?.();
            if (!csv) return;
            const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob); link.download = "morrow-leads.csv"; link.click();
            setTimeout(() => URL.revokeObjectURL(link.href), 0);
        });
    }

    bindLeadInbox();

    const previewController = window.workspacePreviewController?.create({
        state,
        get: $,
        onLoad: () => {
            bindVisualEditorFrame();
            runVisualQualityCheck();
        }
    });

    function updatePreview() {
        if (previewController) {
            previewController.update();
            return;
        }
        setDebugger("Preview controller is unavailable.", true);
    }

    function runPreviewSmokeTests() {
        const iframe = $("previewContentIframe");
        const documentNode = iframe?.contentDocument;
        const results = $("visual-qa-results");
        const status = $("visual-qa-status");
        if (!documentNode || !results || !status) return [];
        const checks = [];
        const add = (passed, message) => checks.push({ state: passed ? "pass" : "fail", message });
        add(Boolean(documentNode.querySelector("h1")), "A primary heading renders.");
        add(Boolean(documentNode.querySelector("main")), "A main content landmark renders.");
        add(!documentNode.querySelector("[href=\"#\"]"), "No placeholder hash links remain.");
        add([...documentNode.querySelectorAll("a[href^=\"#\"]")].every((link) => documentNode.querySelector(link.getAttribute("href"))), "Anchor links resolve to visible targets.");
        add([...documentNode.images].every((image) => image.complete && image.naturalWidth > 0 || !image.src || image.src.startsWith("data:")), "Preview images load or have local data sources.");
        add([...documentNode.querySelectorAll("form")].every((form) => form.querySelector("button[type=\"submit\"]")), "Forms have a submit action.");
        add(!documentNode.querySelector("script[src^=\"http\"]"), "No remote scripts bypass the generated security boundary.");
        const failures = checks.filter((check) => check.state === "fail").length;
        status.dataset.state = failures ? "fail" : "pass";
        status.textContent = failures ? `${failures} smoke test${failures === 1 ? "" : "s"} failed` : "Smoke tests passed";
        results.replaceChildren(...checks.map((check) => { const item = document.createElement("li"); item.dataset.state = check.state; item.textContent = `${check.state === "pass" ? "PASS" : "FIX"} — ${check.message}`; return item; }));
        return checks;
    }

    function runVisualQualityCheck() {
        const iframe = $("previewContentIframe");
        const results = $("visual-qa-results");
        const status = $("visual-qa-status");
        if (!results || !status) return [];

        const checks = [];
        const add = (state, message) => checks.push({ state, message });
        const documentNode = iframe?.contentDocument;
        const html = state.files[state.activePage] || state.files["index.html"] || "";

        if (!documentNode || !html || html.startsWith("<!-- Awaiting")) {
            add("warn", "Compile or import a website before running the visual check.");
        } else {
            const root = documentNode.documentElement;
            const body = documentNode.body;
            const viewportWidth = iframe.clientWidth || 1024;
            const scrollWidth = Math.max(root?.scrollWidth || 0, body?.scrollWidth || 0);
            const hasOverflow = scrollWidth > viewportWidth + 2;
            const images = [...documentNode.images];
            const brokenImages = images.filter((image) => !image.complete || image.naturalWidth === 0);
            const heading = documentNode.querySelector("h1");
            const primaryAction = documentNode.querySelector(".hero-actions .button, .nav-cta, form button[type='submit']");
            const business = getBusinessPayload();
            const expectedGoalTarget = business.primaryGoal === "booking"
                ? (business.booking ? "booking link" : "booking link or contact fallback")
                : business.primaryGoal === "call"
                    ? (business.phone ? "phone link" : "phone number")
                    : business.primaryGoal === "email"
                        ? (business.email ? "email link" : "public email")
                        : "contact form";
            const goalAction = business.primaryGoal === "booking" && business.booking
                ? [...documentNode.querySelectorAll("a")].some((link) => link.href === business.booking)
                : business.primaryGoal === "call" && business.phone
                    ? Boolean(documentNode.querySelector("a[href^='tel:']"))
                    : business.primaryGoal === "email" && business.email
                        ? Boolean(documentNode.querySelector("a[href^='mailto:']"))
                        : Boolean(documentNode.querySelector("form[data-site-form], form[action]"));
            const emptySections = [...documentNode.querySelectorAll("main section")].filter((section) => section.textContent.trim().length < 12);
            const visibleText = (body?.innerText || "").replace(/\s+/g, " ").trim();
            const fixedElements = [...documentNode.querySelectorAll("*")].filter((element) => {
                const style = documentNode.defaultView?.getComputedStyle(element);
                return style && (style.position === "fixed" || style.position === "sticky") && element.getBoundingClientRect().width > viewportWidth;
            });

            add(hasOverflow ? "fail" : "pass", hasOverflow
                ? `Fix: horizontal overflow detected at the ${state.previewMode} viewport. Why it matters: visitors may need to scroll sideways. Check wide images, fixed elements, and oversized sections.`
                : "Pass: no horizontal overflow detected at the selected viewport.");
            add(brokenImages.length ? "fail" : "pass", brokenImages.length
                ? `Fix: ${brokenImages.length} image${brokenImages.length === 1 ? "" : "s"} failed to load or has no usable source. Why it matters: broken images reduce trust and can damage layout. Check each image URL and use a public HTTPS asset.`
                : "Pass: all preview images loaded successfully.");
            add(!heading ? "fail" : "pass", !heading
                ? "Fix: the preview is missing its primary heading. Add one clear <h1> that explains the customer outcome."
                : "Pass: a primary heading is visible in the preview.");
            add(!primaryAction ? "warn" : "pass", !primaryAction
                ? "Review: no prominent call to action is visible. Add one specific next step, such as Request a quote, Book an appointment, or Call us."
                : "Pass: a primary call to action is visible.");
            add(goalAction ? "pass" : "fail", goalAction
                ? `Pass: the primary goal is connected to a ${expectedGoalTarget}.`
                : `Fix: the primary goal is not connected to a usable ${expectedGoalTarget}. Why it matters: visitors may not know how to take the intended action.`);
            const formSettings = getFormSettings();
            if (formSettings.endpoint === "/api/submit-form") {
                add("warn", "Fix before publishing: lead delivery is using the default endpoint. Configure a production form endpoint and submit a test enquiry so leads do not disappear.");
            }
            add(emptySections.length ? "warn" : "pass", emptySections.length
                ? `${emptySections.length} section${emptySections.length === 1 ? " is" : "s are"} nearly empty.`
                : "No nearly empty main sections detected.");
            add(visibleText.length < 120 ? "warn" : "pass", visibleText.length < 120
                ? "The preview contains very little visible content."
                : "The preview contains enough visible content for a useful first review.");
            add(fixedElements.length ? "warn" : "pass", fixedElements.length
                ? "A fixed or sticky element may be wider than the viewport."
                : "No oversized fixed or sticky elements detected.");
        }

        const failures = checks.filter((check) => check.state === "fail").length;
        const warnings = checks.filter((check) => check.state === "warn").length;
        const overall = failures ? "fail" : warnings ? "warn" : "pass";
        status.dataset.state = overall;
        status.textContent = failures ? `${failures} issue${failures === 1 ? "" : "s"} found` : warnings ? `${warnings} review${warnings === 1 ? "" : "s"} recommended` : "Looks good";
        results.replaceChildren(...checks.map((check) => {
            const item = document.createElement("li");
            item.dataset.state = check.state;
            item.textContent = `${check.state === "pass" ? "PASS" : check.state === "warn" ? "REVIEW" : "FIX"} — ${check.message}`;
            return item;
        }));
        return checks;
    }

    function getStructuralQualityIssues(html, css = "") {
        if (window.workspaceQuality?.getStructuralQualityIssues) {
            return window.workspaceQuality.getStructuralQualityIssues(html, css);
        }
        const issues = [];
        const lowerHtml = html.toLowerCase();
        const hasDoctype = /<!doctype\s+html\s*>/i.test(html);
        const hasHead = /<head\b[\s\S]*?<\/head>/i.test(html);
        const hasBody = /<body\b[\s\S]*?<\/body>/i.test(html);
        const hasCharset = /<meta\b[^>]+charset\s*=/i.test(html);
        const hasViewport = /<meta\b[^>]+name=["']viewport["']/i.test(html);
        const headingTags = [...html.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi)].map((match) => ({
            level: Number(match[1]),
            text: match[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim()
        }));
        const fields = [...html.matchAll(/<(input|textarea|select)\b([^>]*)>/gi)]
            .map((match) => match[2])
            .filter((attrs) => !/\baria-hidden=["']true["']|\btype=["']hidden["']/i.test(attrs));
        const labels = [...html.matchAll(/<label\b[^>]*for=["']([^"']+)["'][^>]*>/gi)].map((match) => match[1]);
        const ids = new Set([...html.matchAll(/\bid=["']([^"']+)["']/gi)].map((match) => match[1]));
        const namedButtons = [
            ...html.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/gi)
        ].filter((match) => {
            const attrs = match[1];
            const label = match[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
            return !label && !/\baria-label=["'][^"']+/.test(attrs) && !/\btitle=["'][^"']+/.test(attrs);
        });
        namedButtons.push(...[
            ...html.matchAll(/<input\b([^>]*)>/gi)
        ].filter((match) => /\btype=["'](?:submit|button|reset)["']/i.test(match[1]))
            .filter((match) => !/\baria-label=["'][^"']+/.test(match[1]) && !/\btitle=["'][^"']+/.test(match[1]) && !/\bvalue=["'][^"']+/.test(match[1])));
        const hasCanonical = /<link\b[^>]+rel=["'][^"']*canonical/i.test(html);
        const hasOgTitle = /<meta\b[^>]+property=["']og:title["']/i.test(html);
        const hasOgDescription = /<meta\b[^>]+property=["']og:description["']/i.test(html);
        const hasStructuredData = /<script\b[^>]+type=["']application\/ld\+json["']/i.test(html);
        const cssColors = [...css.matchAll(/(?:color|background(?:-color)?)\s*:\s*(#[0-9a-f]{3,8}|rgba?\([^)]*\)|[a-z]+)/gi)].map((match) => match[1]);
        const hasPotentialContrastRisk = cssColors.some((color) => /#(?:fff|ffffff|f8fafc|f5fafc|f5f5f5)/i.test(color)) && cssColors.some((color) => !/#(?:fff|ffffff|f8fafc|f5fafc|f5f5f5)/i.test(color));

        if (!hasDoctype) issues.push("Structure: Add <!doctype html> so browsers use standards mode.");
        if (!hasHead || !hasBody) issues.push("Structure: Include complete <head> and <body> elements.");
        if (!hasCharset) issues.push("Accessibility: Add a UTF-8 charset declaration.");
        if (!hasViewport) issues.push("Responsive: Add a viewport meta tag for mobile layouts.");
        if (headingTags.length && headingTags[0].level !== 1) issues.push("Accessibility: Start the page heading hierarchy with an <h1>.");
        if (headingTags.some((heading, index) => index > 0 && heading.level - headingTags[index - 1].level > 1)) {
            issues.push("Accessibility: Avoid skipping heading levels (for example, h2 directly to h4).");
        }
        if (fields.some((attrs) => !/\baria-label=["']|\baria-labelledby=["']|\bid=["']/.test(attrs))) {
            issues.push("Accessibility: Give every form control an id, label, or accessible name.");
        }
        if (fields.some((attrs) => /\bid=["']([^"']+)["']/.test(attrs) && !labels.includes(attrs.match(/\bid=["']([^"']+)["']/)[1]) && !/\baria-label|\baria-labelledby/.test(attrs))) {
            issues.push("Accessibility: Associate form controls with visible labels or aria-labels.");
        }
        if (labels.some((id) => !ids.has(id))) issues.push("Accessibility: Fix labels that reference missing form-control IDs.");
        if (namedButtons.length) issues.push(`Accessibility: Give ${namedButtons.length} button${namedButtons.length === 1 ? "" : "s"} an accessible name.`);
        if (!hasCanonical) issues.push("SEO: Add a canonical link when the page can be reached at multiple URLs.");
        if (!hasOgTitle || !hasOgDescription) issues.push("SEO: Add og:title and og:description metadata for social sharing.");
        if (!hasStructuredData) issues.push("SEO: Consider adding relevant JSON-LD structured data.");
        if (hasPotentialContrastRisk) issues.push("Accessibility: Review text and background color contrast, especially light text on light surfaces.");
        if (lowerHtml.includes("<iframe") && !/title=["'][^"']+/.test(html)) issues.push("Accessibility: Give every iframe a descriptive title.");

        return issues;
    }

    function renderQualityScore(report = { issues: [], blocking: [] }) {
        const hasProject = Object.values(state.files || {}).some((value) => {
            const text = String(value || "").trim();
            return text && !/^<!-- Awaiting Data Submission -->$/i.test(text) && !/^\/\* Awaiting Data Submission \*\/$/i.test(text) && !/^\/\/ Awaiting Data Submission$/i.test(text);
        });
        const model = window.workspaceQualityModel?.evaluate?.(report, state.files, {
            business: getBusinessPayload(),
            publishedSiteUrl: getPublishedSiteUrl()
        });
        if (model && !hasProject) {
            ["quality-score", "content-score", "conversion-score", "seo-score", "accessibility-score", "performance-score"].forEach((id) => {
                const element = $(id);
                if (element) {
                    element.textContent = "Pending";
                    element.removeAttribute("data-score-state");
                }
            });
            const labelElement = $("quality-score-label");
            if (labelElement) labelElement.textContent = "Create or import a website to calculate launch confidence.";
            return;
        }
        if (model) {
            const totalElement = $("quality-score");
            const labelElement = $("quality-score-label");
            if (totalElement) totalElement.textContent = `${model.overall}/100`;
            if (labelElement) labelElement.textContent = model.blockers.length
                ? `${model.blockers.length} blocking issue${model.blockers.length === 1 ? "" : "s"} must be resolved before publishing.`
                : model.recommendations.length
                    ? `${model.recommendations.length} recommendation${model.recommendations.length === 1 ? "" : "s"} to review before launch.`
                    : "Launch evidence is complete for the current project state.";
            Object.entries(model.scores).forEach(([category, score]) => {
                const element = $(`${category}-score`);
                if (element) element.textContent = `${score}/100`;
            });
            if (totalElement) totalElement.dataset.scoreState = model.overall >= 90 ? "excellent" : model.overall >= 75 ? "good" : "needs-attention";
            return;
        }
        const issues = [...(report.issues || []), ...(report.blocking || [])];
        const categoryScore = (category) => {
            const count = issues.filter((issue) => issue.toLowerCase().startsWith(`${category.toLowerCase()}:`)).length;
            return Math.max(0, 100 - count * 18);
        };
        const content = categoryScore("Content");
        const business = getBusinessPayload();
        const formSettings = getFormSettings();
        const conversionGaps = [
            !business.hook,
            !business.services,
            !business.audience,
            !business.differentiator,
            !business.testimonial,
            !business.responseTime,
            !business.pricing,
            !business.phone && !business.email,
            !business.primaryCta,
            !/<form\b/i.test(state.files["index.html"] || ""),
            formSettings.endpoint === "/api/submit-form",
            business.primaryGoal === "booking" && !business.booking,
            business.primaryGoal === "call" && !business.phone,
            business.primaryGoal === "email" && !business.email
        ].filter(Boolean);
        const conversion = Math.max(0, 100 - conversionGaps.length * 10);
        const seo = categoryScore("SEO");
        const accessibility = categoryScore("Accessibility");
        const performance = categoryScore("Performance");
        const total = Math.round((content + conversion + seo + accessibility + performance) / 5);
        const label = total >= 90 ? "Excellent — ready to publish" : total >= 75 ? "Strong — review the remaining recommendations" : total >= 50 ? "Good foundation — a few improvements will help" : "Needs attention before publishing";
        const values = {
            "quality-score": `${total}/100`,
            "quality-score-label": label,
            "content-score": `${content}/100`,
            "conversion-score": `${conversion}/100`,
            "seo-score": `${seo}/100`,
            "accessibility-score": `${accessibility}/100`,
            "performance-score": `${performance}/100`
        };
        Object.entries(values).forEach(([id, value]) => {
            const element = $(id);
            if (element) element.textContent = value;
        });
        const totalElement = $("quality-score");
        if (totalElement) totalElement.dataset.scoreState = total >= 90 ? "excellent" : total >= 75 ? "good" : "needs-attention";
    }

    function getQualityReport() {
        readEditedFiles();

        const html = state.files["index.html"] || "";
        const css = state.files["style.css"] || "";
        const issues = [];
        const business = getBusinessPayload();
        const formSettings = getFormSettings();
        const goalRequirements = {
            booking: !business.booking && "Conversion: Add a booking link because the primary goal is an appointment.",
            call: !business.phone && "Conversion: Add a phone number because the primary goal is a call.",
            email: !business.email && "Conversion: Add a public email because the primary goal is email contact.",
            shop: !business.services && "Conversion: Add products or services so visitors have something specific to explore."
        };
        const conversionRecommendations = [
            !business.hook && "Conversion: Add a specific customer outcome to the headline.",
            !business.audience && "Conversion: Name the audience you most want to attract.",
            !business.services && "Conversion: Add the services or products visitors can choose from.",
            !business.differentiator && "Conversion: Explain what makes your approach different.",
            !business.testimonial && "Conversion: Add a customer testimonial or measurable result.",
            !business.responseTime && "Conversion: Tell visitors when they can expect a reply.",
            !business.pricing && "Conversion: Add pricing guidance or a starting price to reduce uncertainty.",
            !business.phone && !business.email && "Conversion: Add a phone number or public email for visitors who prefer direct contact.",
            !business.primaryCta && "Conversion: Customize the primary call to action around the visitor's benefit.",
            goalRequirements[business.primaryGoal],
            formSettings.endpoint === "/api/submit-form" && "Conversion: Configure the form endpoint before publishing so enquiries reach your business."
        ].filter(Boolean);
        issues.push(...conversionRecommendations);
        const allPages = pageFiles();
        syncSiteNavigation();
        const blocking = [];
        const title = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "";
        const description = html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)/i)?.[1]?.trim() || "";
        const canonical = html.match(/<link[^>]+rel=["'][^"']*canonical[^"']*["'][^>]+href=["']([^"']+)["']/i)?.[1]?.trim() || "";
        const ogTitle = /<meta[^>]+property=["']og:title["'][^>]+content=["'][^"']+/i.test(html);
        const ogDescription = /<meta[^>]+property=["']og:description["'][^>]+content=["'][^"']+/i.test(html);
        const twitterCard = /<meta[^>]+name=["']twitter:card["'][^>]+content=["'][^"']+/i.test(html);
        const h1Count = (html.match(/<h1[\s>]/gi) || []).length;
        const images = [...html.matchAll(/<img\b[^>]*>/gi)].map((match) => match[0]);
        const missingAlt = images.filter((image) => !/\balt=["']/i.test(image)).length;
        const missingImageSource = images.filter((image) => !/\bsrc=["'][^"']+["']/i.test(image)).length;
        const forms = [...html.matchAll(/<form\b[\s\S]*?<\/form>/gi)].map((match) => match[0]);
        const links = [...html.matchAll(/<a\b[^>]*>/gi)].map((match) => match[0]);
        const emptyLinks = links.filter((link) => {
            const href = link.match(/\bhref=["']([^"']*)["']/i)?.[1]?.trim();
            return !href || href === "#" || /^javascript:/i.test(href);
        }).length;
        const localPageLinks = links
            .map((link) => link.match(/\bhref=["']([^"']*)["']/i)?.[1]?.trim() || "")
            .filter((href) => href && !/^(?:#|https?:|mailto:|tel:|javascript:)/i.test(href));
        const knownFiles = new Set(Object.keys(state.files));
        const brokenLocalLinks = localPageLinks.filter((href) => {
            const path = href.split(/[?#]/)[0].replace(/^\.\//, "");
            return /\.html?$/i.test(path) && path !== "index.html" && !knownFiles.has(path);
        }).length;
        const duplicateIdIssues = pageFiles().flatMap((filename) => {
            const pageHtml = state.files[filename] || "";
            const ids = [...pageHtml.matchAll(/\bid=["']([^"']+)["']/gi)].map((match) => match[1]);
            const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
            return duplicates.length ? [`Accessibility: ${filename} contains duplicate id values (${[...new Set(duplicates)].slice(0, 4).join(", ")}).`] : [];
        });
        const allPageIssues = pageFiles().flatMap((filename) => {
            const pageHtml = state.files[filename] || "";
            const pageLinks = [...pageHtml.matchAll(/<a\b[^>]*href=["']([^"']+)["']/gi)].map((match) => match[1]);
            const ids = new Set([...pageHtml.matchAll(/\bid=["']([^"']+)["']/gi)].map((match) => match[1]));
            const missing = pageLinks.filter((href) => {
                const path = href.split(/[?#]/)[0].replace(/^\.\//, "");
                return /\.html?$/i.test(path) && !knownFiles.has(path);
            });
            const missingAnchors = pageLinks.filter((href) => href.startsWith("#") && href.length > 1 && !ids.has(href.slice(1)));
            const formControls = [...pageHtml.matchAll(/<(input|textarea|select)\b([^>]*)>/gi)].map((match) => match[2]).filter((attrs) => !/type=["']hidden["']/i.test(attrs));
            const missingAutocomplete = formControls.filter((attrs) => /\btype=["'](?:email|tel|text)["']/i.test(attrs) && !/\bautocomplete=/i.test(attrs));
            const issues = [];
            if (missing.length) issues.push(`Content: ${filename} links to ${missing.length} missing page${missing.length === 1 ? "" : "s"}.`);
            if (missingAnchors.length) issues.push(`Accessibility: ${filename} contains ${missingAnchors.length} link${missingAnchors.length === 1 ? "" : "s"} to missing section anchors.`);
            if (missingAutocomplete.length) issues.push(`Accessibility: ${filename} has ${missingAutocomplete.length} text field${missingAutocomplete.length === 1 ? "" : "s"} without autocomplete hints.`);
            if (!/<main\b/i.test(pageHtml)) issues.push(`Structure: ${filename} should include a main landmark.`);
            return issues;
        });
        const placeholderMatches = html.match(/lorem ipsum|coming soon|replace (?:this|with)|your (?:business|company) name|example\.com|awaiting data submission|TODO/gi) || [];
        const hasSubmitEndpoint = /<form\b[^>]*action=["'][^"']+[^"']*["']/i.test(html) || /fetch\([^)]*action/i.test(state.files["script.js"] || "");

        if (!html.trim() || html.startsWith("<!-- Awaiting")) {
            blocking.push("Compile or import a website before exporting.");
        }
        if (!/<html\b/i.test(html) || !/<\/html>/i.test(html)) {
            blocking.push("index.html is missing a complete <html> document.");
        }
        if (!title) blocking.push("Add a descriptive page title before exporting.");
        if (h1Count !== 1) blocking.push(`Use exactly one primary <h1> heading before exporting (found ${h1Count}).`);
        if (!/<html\b[^>]+lang=["'][^"']+["']/i.test(html)) blocking.push("Declare the document language on the <html> element before exporting.");
        if (missingAlt) blocking.push(`Add alt text to ${missingAlt} image${missingAlt === 1 ? "" : "s"} before exporting.`);
        if (forms.length && !hasSubmitEndpoint) {
            blocking.push("Configure a form submission endpoint before exporting.");
        }
        if (missingImageSource) {
            issues.push(`Content: Add a source URL to ${missingImageSource} image${missingImageSource === 1 ? "" : "s"}.`);
        }
        if (emptyLinks) {
            issues.push(`Content: Replace ${emptyLinks} empty or placeholder link${emptyLinks === 1 ? "" : "s"}.`);
        }
        if (brokenLocalLinks) {
            issues.push(`Content: ${brokenLocalLinks} local page link${brokenLocalLinks === 1 ? " points" : "s point"} to a missing HTML file.`);
        }
        issues.push(...duplicateIdIssues, ...allPageIssues);
        if (placeholderMatches.length) {
            issues.push(`Content: Replace ${placeholderMatches.length} placeholder phrase${placeholderMatches.length === 1 ? "" : "s"} before publishing.`);
        }
        if (title && (title.length < 10 || title.length > 70)) {
            issues.push("SEO: Keep the page title between 10 and 70 characters.");
        }
        if (!description) issues.push("SEO: Add a meta description for search previews.");
        if (description && (description.length < 50 || description.length > 160)) {
            issues.push("SEO: Keep the meta description between 50 and 160 characters.");
        }
        if (!canonical) issues.push("SEO: Add a canonical URL to clarify the preferred page address.");
        if (!ogTitle || !ogDescription || !twitterCard) issues.push("SEO: Complete Open Graph and Twitter metadata for stronger social sharing previews.");
        if (h1Count > 1) issues.push("SEO: Use one primary <h1> heading for a clearer page hierarchy.");
        if (missingAlt) issues.push(`Accessibility: Add alt text to ${missingAlt} image${missingAlt === 1 ? "" : "s"}.`);
        if (images.length && !images.every((image) => /loading=["']lazy/i.test(image))) {
            issues.push("Performance: Add loading=\"lazy\" to below-the-fold images.");
        }
        if (css.length > 50_000) issues.push("Performance: Reduce stylesheet size before publishing.");
        if (/<script\b[^>]+src=["'][^"']*https?:/i.test(html)) {
            issues.push("Security: Review external scripts before publishing.");
        }

        issues.push(...getStructuralQualityIssues(html, css));

        // A multi-page export is only as strong as its weakest page. Keep the
        // publish gate project-wide so secondary pages cannot ship unfinished.
        pageFiles().forEach((filename) => {
            const pageHtml = String(state.files[filename] || "");
            const pageTitle = pageHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "";
            const pageH1Count = (pageHtml.match(/<h1[\s>]/gi) || []).length;
            const pageImages = [...pageHtml.matchAll(/<img\b[^>]*>/gi)].map((match) => match[0]);
            const pageForms = [...pageHtml.matchAll(/<form\b[\s\S]*?<\/form>/gi)].map((match) => match[0]);
            const pageHasEndpoint = pageForms.every((form) => /\baction=["'][^"']+["']/i.test(form));

            if (!/<html\b[^>]*>[\s\S]*<\/html>/i.test(pageHtml)) {
                blocking.push(`${filename} must contain a complete <html> document.`);
            }
            if (!pageTitle) {
                blocking.push(`${filename} needs a descriptive <title>.`);
            }
            if (pageH1Count !== 1) {
                blocking.push(`${filename} should contain exactly one primary <h1> heading.`);
            }
            if (pageImages.some((image) => !/\balt=["']/i.test(image))) {
                blocking.push(`${filename} contains an image without alternative text.`);
            }
            if (pageForms.length && !pageHasEndpoint) {
                blocking.push(`${filename} contains a form without a submission endpoint.`);
            }
        });

        return { issues, blocking };
    }

    function fixSafeQualityIssues() {
        readEditedFiles();
        const pages = pageFiles();
        if (!pages.length || pages.every((filename) => !String(state.files[filename] || "").trim() || state.files[filename].startsWith("<!-- Awaiting"))) {
            showToast("Compile or import a website first.", "error");
            return;
        }

        const business = getBusinessPayload();
        const name = business.name || "Professional Business";
        const fallbackDescription = business.hook || `${name} provides thoughtful service and clear next steps.`;
        const knownFiles = new Set(pages);
        const historyLength = state.history.length;
        pushHistory();
        let changed = false;

        const escapeAttribute = (value) => escapeHtml(String(value || "").replace(/[\r\n]+/g, " ").trim());
        const pageTitle = (filename) => filename === "index.html"
            ? name
            : `${filename.replace(/\.html$/i, "").replace(/[-_]+/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase())} — ${name}`;
        const ensureTag = (source, pattern, tag) => pattern.test(source) ? source : source.replace(/<head\b[^>]*>/i, (match) => `${match}\n    ${tag}`);

        pages.forEach((filename) => {
            let html = String(state.files[filename] || "");
            if (!html.trim() || html.startsWith("<!-- Awaiting")) return;
            const before = html;
            const title = escapeAttribute(pageTitle(filename));
            const description = escapeAttribute(fallbackDescription);

            if (!/^\s*<!doctype\s+html/i.test(html)) html = `<!doctype html>\n${html}`;
            if (!/<html\b/i.test(html)) html = `<!doctype html>\n<html lang="en">\n<head></head>\n<body>\n${html}\n</body>\n</html>`;
            html = html.replace(/<html\b([^>]*)>/i, (match, attrs) => /\blang\s*=/.test(attrs) ? match : `<html${attrs} lang="en">`);
            if (!/<head\b/i.test(html)) html = html.replace(/<body\b/i, "<head></head>\n<body");
            if (!/<body\b/i.test(html)) html = html.replace(/<\/html>/i, "<body></body>\n</html>");
            html = ensureTag(html, /<meta\b[^>]+charset\s*=/i, '<meta charset="utf-8">');
            html = ensureTag(html, /<meta\b[^>]+name=["']viewport["']/i, '<meta name="viewport" content="width=device-width, initial-scale=1">');

            if (/<title\b[^>]*>\s*<\/title>/i.test(html)) html = html.replace(/<title\b[^>]*>[\s\S]*?<\/title>/i, `<title>${title}</title>`);
            else if (!/<title\b/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (match) => `${match}\n    <title>${title}</title>`);
            if (/<meta\b[^>]+name=["']description["'][^>]*>/i.test(html)) html = html.replace(/<meta\b([^>]+name=["']description["'][^>]*)>/i, (match, attrs) => /content=["'][^"']*["']/i.test(attrs) ? match.replace(/content=["'][^"']*["']/i, `content="${description}"`) : `<meta${attrs} content="${description}">`);
            else html = html.replace(/<head\b[^>]*>/i, (match) => `${match}\n    <meta name="description" content="${description}">`);
            if (!/<link\b[^>]+rel=["'][^"']*canonical/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (match) => `${match}\n    <link rel="canonical" href="./${filename}">`);
            if (!/<meta\b[^>]+property=["']og:title["']/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (match) => `${match}\n    <meta property="og:title" content="${title}">`);
            if (!/<meta\b[^>]+property=["']og:description["']/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (match) => `${match}\n    <meta property="og:description" content="${description}">`);
            if (!/<main\b/i.test(html)) html = html.replace(/<body\b([^>]*)>([\s\S]*?)<\/body>/i, (match, attrs, content) => `<body${attrs}><main id="main-content">${content}</main></body>`);
            if (!/<h1\b/i.test(html)) html = html.replace(/<main\b[^>]*>/i, (match) => `${match}<h1>${title}</h1>`);

            html = html.replace(/<img\b(?![^>]*\balt\s*=)([^>]*)>/gi, '<img$1 alt="Business image">');
            html = html.replace(/<img\b(?![^>]*\bloading\s*=)([^>]*)>/gi, '<img$1 loading="lazy">');
            html = html.replace(/<iframe\b(?![^>]*\btitle\s*=)([^>]*)>/gi, '<iframe$1 title="Embedded content">');
            html = html.replace(/<button\b([^>]*)>\s*<\/button>/gi, (match, attrs) => /\baria-label=|\btitle=/i.test(attrs) ? match : `<button${attrs} aria-label="Action">Action</button>`);
            html = html.replace(/<(input|textarea|select)\b([^>]*)>/gi, (match, tag, attrs) => {
                if (/\baria-hidden=["']true|\btype=["']hidden/i.test(attrs)) return match;
                let next = attrs;
                if (!/\bid=["']/i.test(next) && !/\baria-label=["']/i.test(next)) next += ` aria-label="${tag === "textarea" ? "Message" : "Form field"}"`;
                if (/\btype=["'](?:email|tel|text)["']/i.test(next) && !/\bautocomplete=["']/i.test(next)) next += ' autocomplete="off"';
                return `<${tag}${next}>`;
            });
            html = html.replace(/\bhref=["'](?:javascript:|#)["']/gi, 'href="./index.html"');
            html = html.replace(/\bhref=["'](?:\.\/)?([^"'#?]+\.html)(?:#[^"']*)?["']/gi, (match, target) => knownFiles.has(target) ? match : 'href="./index.html"');
            html = html.replace(/lorem ipsum|coming soon|replace (?:this|with)|your (?:business|company) name|example\.com|awaiting data submission|TODO/gi, () => fallbackDescription);

            if (html !== before) {
                state.files[filename] = html;
                changed = true;
            }
        });

        if (!changed) {
            if (state.history.length === historyLength + 1) state.history.pop();
            updateUndoButton();
            runQualityCheck(false);
            showToast("No safe automatic fixes were available.", "info");
            return;
        }

        if (state.history.length > historyLength + 1) state.history.splice(historyLength + 1);
        syncSiteNavigation();
        renderFiles({ dirty: true });
        setDebugger(`Applied safe export fixes across ${pages.length} page${pages.length === 1 ? "" : "s"}.`);
        showToast("Safe export fixes applied.", "success");
        runQualityCheck(false);
    }

    function showRepairPlan() {
        const report = getQualityReport();
        const issues = [...report.blocking, ...report.issues].map((item) => typeof item === "string" ? { message: item, severity: "warning" } : item);
        const details = $("diagnostic-details");
        if (!details) return;
        details.replaceChildren(...(issues.length ? issues : [{ message: "No repair actions are currently required.", severity: "success" }]).slice(0, 20).map((item) => {
            const row = document.createElement("li");
            row.dataset.priority = item.severity === "error" ? "high" : item.severity === "success" ? "low" : "medium";
            const title = document.createElement("strong");
            title.textContent = item.severity === "error" ? "Critical repair" : item.severity === "success" ? "Ready" : "Recommended repair";
            const message = document.createElement("span");
            message.textContent = item.message || String(item);
            row.append(title, message);
            return row;
        }));
        setDebugger(`${issues.length} repair recommendation${issues.length === 1 ? "" : "s"} found. Safe fixes can be applied with approval using Fix Safe Issues.`);
    }

    function runQualityCheck(showToastMessage = true) {
        const report = getQualityReport();
        const messages = [
            ...report.blocking.map((message) => `BLOCKING: ${message}`),
            ...report.issues
        ];
        const output = messages.length
            ? messages.join("\n")
            : "Quality check passed. The project is ready for export.";

        setDebugger(output, report.blocking.length > 0);
        if (showToastMessage) {
            showToast(
                report.blocking.length
                    ? `${report.blocking.length} issue${report.blocking.length === 1 ? "" : "s"} must be fixed before export.`
                    : "Quality check passed.",
                report.blocking.length ? "error" : "success"
            );
        }

        return report;
    }

    function getDeploymentAuthToken() {
        try {
            const session = JSON.parse(sessionStorage.getItem("supabase_session") || "null");
            const expiresAt = Number(session?.expires_at || 0);
            if (!session?.access_token || (expiresAt && expiresAt * 1000 <= Date.now())) return "";
            return String(session.access_token);
        } catch {
            return "";
        }
    }

    function setPublishReady(ready) {
        const button = $("publish-site-btn");
        if (!button) return;
        button.disabled = !ready;
        button.setAttribute("aria-disabled", String(!ready));
    }

    function updateRedeployControl() {
        const button = $("redeploy-site-btn");
        const rollbackButton = $("rollback-site-btn");
        const available = Boolean(state.deploymentHistory[0]?.files);
        const rollbackAvailable = Boolean(state.deploymentHistory[1]?.id && getDeploymentAuthToken());
        [button, rollbackButton].forEach((control) => {
            if (!control) return;
            const enabled = control === rollbackButton ? rollbackAvailable : available;
            control.disabled = !enabled;
            control.setAttribute("aria-disabled", String(!enabled));
        });
        const status = $("redeploy-status");
        if (status) {
            status.textContent = available
                ? `Ready to redeploy ${state.deploymentHistory[0].projectName || "the latest saved version"}.`
                : "Redeployment is unavailable until a deployment has been recorded.";
        }
    }

    async function runServerPreflight(files) {
        const result = await requestJson("/api/preflight", {
            method: "POST",
            body: JSON.stringify({ files }),
            timeoutMs: 15_000
        });
        if (!result.success || result.report?.blocking?.length) {
            const first = result.report?.blocking?.[0]?.message || result.error || "Server preflight rejected the project.";
            throw new Error(first);
        }
        return result.report;
    }

    async function rollbackLatestDeployment() {
        const latest = state.deploymentHistory[1];
        const button = $("rollback-site-btn");
        if (!latest?.id || !getDeploymentAuthToken()) {
            showToast("Sign in and publish at least two deployments before rolling back.", "error");
            return;
        }
        if (!window.confirm("Roll back production to the latest recorded deployment?")) return;
        setButtonBusy(button, true, "Rolling back…");
        try {
            const result = await requestJson(`/api/deploy?rollback=${encodeURIComponent(latest.id)}`, {
                method: "POST",
                headers: { Authorization: `Bearer ${getDeploymentAuthToken()}` },
                body: "{}"
            });
            if (!result.success) throw new Error(result.error || "Rollback failed.");
            setDebugger("Production rollback submitted successfully.");
            showToast("Production rollback submitted.", "success");
        } catch (error) {
            setDebugger(error.message || "Rollback failed.", true);
            showToast("Rollback failed.", "error");
        } finally {
            setButtonBusy(button, false);
            updateRedeployControl();
        }
    }

    function runDeploymentPreflight(showToastMessage = true) {
        readEditedFiles();
        const report = getQualityReport();
        const sharedAudit = window.workspaceAudit?.auditProject?.(state.files) || { blocking: [], warnings: [] };
        const blockers = [...report.blocking, ...sharedAudit.blocking.map((item) => item.message)];
        const briefIssues = getGenerationBriefIssues();
        if (briefIssues.length) blockers.push(...briefIssues.map((message) => `Brief: ${message}`));
        const token = getDeploymentAuthToken();

        if (!token) blockers.push("Sign in before deploying this website.");

        const files = Object.fromEntries(
            Object.entries(state.files).filter(([, content]) => String(content || "").trim())
        );
        if (!Object.keys(files).length) blockers.push("Compile or import a website before deploying.");
        if (!String(files["index.html"] || "").trim()) blockers.push("The deployment must include index.html.");
        if (Object.keys(files).some((filename) => isPageFile(filename) && !/^<!doctype\s+html>/i.test(String(files[filename] || "").trim()))) {
            blockers.push("Every HTML page must begin with a complete HTML document before deploying.");
        }

        setPublishReady(blockers.length === 0);
        const status = $("deployment-preflight-status");
        if (status) {
            status.textContent = blockers.length
                ? `Preflight blocked: ${blockers.length} issue${blockers.length === 1 ? "" : "s"} must be fixed.`
                : "Preflight passed. The project is ready to publish.";
            status.style.color = blockers.length ? "#f87171" : "";
            status.setAttribute("aria-invalid", String(blockers.length > 0));
        }

        const messages = [
            blockers.length ? "DEPLOYMENT PREFLIGHT" : "DEPLOYMENT PREFLIGHT PASSED",
            ...blockers.map((message) => `BLOCKING: ${message}`),
            ...report.issues
        ];
        setDebugger(messages.join("\n"), blockers.length > 0);
        if (showToastMessage) {
            showToast(
                blockers.length
                    ? `Deployment blocked by ${blockers.length} issue${blockers.length === 1 ? "" : "s"}.`
                    : "Deployment preflight passed.",
                blockers.length ? "error" : "success"
            );
        }
        return { report, blockers, files };
    }

    function bytesToBase64(bytes) {
        let binary = "";
        const chunkSize = 0x8000;
        for (let offset = 0; offset < bytes.length; offset += chunkSize) {
            binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
        }
        return btoa(binary);
    }

    async function monitorDeployment(deploymentId, initialUrl = "") {
        if (!deploymentId) {
            if (initialUrl) return { state: "published", url: initialUrl };
            throw new Error("The hosting provider did not return a deployment ID or published URL.");
        }

        const startedAt = Date.now();
        const timeout = 90_000;
        const deploymentStatus = $("deployment-status");
        let attempt = 0;

        while (Date.now() - startedAt < timeout) {
            const delay = Math.min(3000 + attempt * 1000, 8000);
            await new Promise((resolve) => setTimeout(resolve, delay));
            attempt += 1;

            try {
                const result = await requestJson(`/api/deploy?id=${encodeURIComponent(deploymentId)}`, {
                    method: "GET",
                    headers: { Authorization: `Bearer ${getDeploymentAuthToken()}` }
                });
                const state = String(result.state || "unknown").toLowerCase();

                if (deploymentStatus) deploymentStatus.textContent = `Deployment ${state}…`;
                if (["ready", "published"].includes(state)) return result;
                if (["error", "failed", "failure"].includes(state)) {
                    throw new Error("The hosting provider reported a failed deployment.");
                }
            } catch (error) {
                if (error.status === 404 || /hosting provider reported a failed deployment/i.test(error.message || "")) {
                    throw error;
                }
                if (deploymentStatus) deploymentStatus.textContent = "Deployment status temporarily unavailable; retrying…";
                if (Date.now() - startedAt >= timeout) throw error;
            }
        }

        throw new Error("Deployment status timed out. Check Recent Deployments later.");
    }

    async function verifyPublishedDeployment(url) {
        const status = $("deployment-verification-status");
        if (!/^https:\/\//i.test(String(url || ""))) return { success: false, error: "Add a valid HTTPS published URL before verification." };
        const files = Object.keys(state.files).filter((name) => /^(?:[^/]+\.html?|style\.css|script\.js|sitemap\.xml|robots\.txt)$/i.test(name));
        if (status) status.textContent = "Verifying the published homepage, pages, and assets…";
        try {
            const revision = window.workspaceDomain?.revisionOf?.(state.files) || "";
            const result = await requestJson("/api/verify-deployment", { method: "POST", body: JSON.stringify({ url, files, revision }), timeoutMs: 30_000 });
            if (status) status.textContent = result.success ? "Published site verification passed." : `Published site verification found ${result.blocking?.length || 1} issue(s).`;
            return result;
        } catch (error) {
            if (status) status.textContent = error.message || "Published site verification failed.";
            return { success: false, error: error.message || "Verification failed." };
        }
    }

    async function publishSite(filesOverride = null, buttonOverride = null) {
        const button = buttonOverride || $("publish-site-btn");

        // The editable source is the canonical source for both preview and deployment.
        // Read it before creating the preflight snapshot so the ZIP cannot lag behind
        // the page currently visible in the editor.
        readEditedFiles();
        const publishFiles = filesOverride
            ? { ...filesOverride }
            : Object.fromEntries(Object.entries(state.files).filter(([, content]) => String(content || "").trim()));
        const preflight = filesOverride
            ? { ...runDeploymentPreflight(false), files: publishFiles, blockers: [] }
            : { ...runDeploymentPreflight(true), files: publishFiles };
        if (preflight.blockers.length) return;

        try {
            await runServerPreflight(preflight.files);
        } catch (error) {
            setDebugger(`Server preflight blocked deployment: ${error.message}`, true);
            showToast("Server preflight blocked deployment.", "error");
            return;
        }

        setButtonBusy(button, true, "Publishing…");
        setStatus("PUBLISHING");
        const deploymentStatus = $("deployment-status");
        if (deploymentStatus) deploymentStatus.textContent = "Preparing deployment…";

        try {
            const archive = createZip(preflight.files);
            if (archive.length > 8_000_000) throw new Error("The deployment ZIP is larger than the server limit.");

            const result = await requestJson("/api/deploy", {
                method: "POST",
                headers: { Authorization: `Bearer ${getDeploymentAuthToken()}` },
                body: JSON.stringify({ zip: bytesToBase64(archive) })
            });
            if (!result.success) throw new Error(result.error || "Deployment failed.");

            if (deploymentStatus) deploymentStatus.textContent = result.id
                ? `Deployment ${result.state || "submitted"}…`
                : "Deployment submitted; waiting for provider confirmation…";
            const monitored = await monitorDeployment(result.id, result.url || "");
            const url = monitored.url || result.url || "";
            const verification = await verifyPublishedDeployment(url);
            const verified = Boolean(verification?.success);
            if (deploymentStatus) deploymentStatus.textContent = verified
                ? `Deployment ${monitored.state || "published"}; published site verified.`
                : `Deployment ${monitored.state || "published"}; published-site verification needs attention.`;
            const urlContainer = $("deployment-url");
            const urlLink = $("deployment-url-link");
            if (urlContainer && urlLink && /^https?:\/\//i.test(url)) {
                urlLink.href = url;
                urlContainer.hidden = false;
            }
            recordDeployment({ id: result.id, state: monitored.state || result.state || "published", url, files: { ...preflight.files }, verification: verification ? { success: Boolean(verification.success), blocking: verification.blocking || [], revision: verification.revision || window.workspaceDomain?.revisionOf?.(preflight.files) || "", verifiedAt: verification.verifiedAt || new Date().toISOString() } : null });
            setStatus("READY");
            setDebugger(verified
                ? "Website deployment submitted and verified successfully."
                : "Website deployment submitted, but published-site verification needs attention.", !verified);
            showToast(verified ? "Website published and verified." : "Website published; verification needs attention.", verified ? "success" : "error");
        } catch (error) {
            if (deploymentStatus) deploymentStatus.textContent = error.message || "Deployment failed.";
            setStatus("ERROR", true);
            setDebugger(error.message || "Deployment failed.", true);
            showToast("Deployment failed.", "error");
            document.dispatchEvent(new CustomEvent("workspace:deployment-failed", {
                detail: { message: error.message || "Deployment failed." }
            }));
        } finally {
            setButtonBusy(button, false);
            setPublishReady(false);
        }
    }

    function updateDiagnostics() {
        const report = getQualityReport();
        renderQualityScore(report);
        const html = state.files[state.activePage] || state.files["index.html"] || "";
        const css = state.files["style.css"] || "";
        const details = [];
        const hasTitle = /<title[\s>]/i.test(html);
        const hasDescription = /<meta[^>]+name=["']description/i.test(html);
        const hasH1 = /<h1[\s>]/i.test(html);
        const hasLang = /<html[^>]+lang=["'][^"']+/i.test(html);
        const images = [...html.matchAll(/<img\b[^>]*>/gi)].map((match) => match[0]);
        const missingAlt = images.filter((image) => !/\balt=["']/i.test(image)).length;
        const missingImageSource = images.filter((image) => !/\bsrc=["'][^"']+["']/i.test(image)).length;
        const links = [...html.matchAll(/<a\b[^>]*>/gi)].map((match) => match[0]);
        const emptyLinks = links.filter((link) => {
            const href = link.match(/\bhref=["']([^"']*)["']/i)?.[1]?.trim();
            return !href || href === "#" || /^javascript:/i.test(href);
        }).length;
        const placeholderMatches = html.match(/lorem ipsum|coming soon|replace (?:this|with)|your (?:business|company) name|example\.com|awaiting data submission|TODO/gi) || [];
        const forms = [...html.matchAll(/<form\b[\s\S]*?<\/form>/gi)].map((match) => match[0]);
        const inputs = [...html.matchAll(/<(input|textarea|select)\b[^>]*>/gi)].map((match) => match[0]);
        const labelledFields = inputs.filter((field) => /\baria-label=["']|\baria-labelledby=["']|\bid=["']/i.test(field)).length;
        const hasLazyImages = images.length === 0 || images.every((image) => /loading=["']lazy/i.test(image));
        const hasViewport = /name=["']viewport/i.test(html);
        const hasInlineHandlers = /\son(click|load|error|submit)=/i.test(html);
        const structuralIssues = getStructuralQualityIssues(html, css);
        const structuralSeoIssues = structuralIssues.filter((issue) => issue.startsWith("SEO:"));
        const structuralAccessibilityIssues = structuralIssues.filter((issue) => issue.startsWith("Accessibility:"));
        const structuralPerformanceIssues = structuralIssues.filter((issue) => issue.startsWith("Performance:") || issue.startsWith("Responsive:"));

        const seo = Math.max(0, 3 - Number(!hasTitle) - Number(!hasDescription) - Number(!hasH1) - Math.min(1, structuralSeoIssues.length));
        const accessibility = Math.max(0, 3 - Number(!hasLang) - Number(missingAlt > 0) - Number(inputs.length > 0 && labelledFields < inputs.length) - Math.min(1, structuralAccessibilityIssues.length));
        const performance = Math.max(0, 3 - Number(!hasLazyImages && images.length > 0) - Number(!hasViewport) - Number(hasInlineHandlers || /<iframe|<object|<embed/i.test(html)) - Math.min(1, structuralPerformanceIssues.length));

        if (!hasTitle) details.push("SEO: Add a descriptive <title> between 30–60 characters.");
        if (!hasDescription) details.push("SEO: Add a concise meta description describing the main customer benefit.");
        if (!hasH1) details.push("SEO: Add one clear primary <h1> heading.");
        if (missingImageSource) details.push(`Content: Add a source URL to ${missingImageSource} image${missingImageSource === 1 ? "" : "s"}.`);
        if (emptyLinks) details.push(`Content: Replace ${emptyLinks} empty or placeholder link${emptyLinks === 1 ? "" : "s"}.`);
        if (placeholderMatches.length) details.push(`Content: Replace ${placeholderMatches.length} placeholder phrase${placeholderMatches.length === 1 ? "" : "s"} before publishing.`);
        if (!hasLang) details.push("Accessibility: Add a language attribute to the <html> element.");
        if (missingAlt) details.push(`Accessibility: Add meaningful alt text to ${missingAlt} image${missingAlt === 1 ? "" : "s"}.`);
        if (forms.length && labelledFields < inputs.length) details.push("Accessibility: Give every form control a visible label or an accessible name.");
        if (!hasLazyImages && images.length) details.push("Performance: Add loading=\"lazy\" to below-the-fold images.");
        if (hasInlineHandlers) details.push("Maintainability: Replace inline event handlers with addEventListener.");
        if (css.length > 50_000) details.push("Performance: Your stylesheet is large; remove unused rules before export.");
        details.push(...structuralIssues);
        if (!details.length) details.push("No immediate issues detected. Review the mobile preview and test every form before publishing.");

        if ($("seo-score")) $("seo-score").textContent = `${seo}/3`;
        if ($("accessibility-score")) $("accessibility-score").textContent = `${accessibility}/3`;
        if ($("performance-score")) $("performance-score").textContent = `${performance}/3`;
        if ($("diagnostic-details")) {
            const filter = $("diagnostic-severity-filter")?.value || "all";
            const report = getQualityReport();
            const findings = details.map((detail) => ({ detail, priority: report.blocking.some((item) => detail.includes(item)) ? "high" : detail.startsWith("SEO:") || detail.startsWith("Accessibility:") ? "medium" : "low" }));
            $("diagnostic-details").replaceChildren(...findings.filter((entry) => filter === "all" || entry.priority === filter).map(({ detail, priority }) => {
                const item = document.createElement("li");
                item.dataset.priority = priority;
                const title = document.createElement("strong");
                title.textContent = priority === "high" ? "Blocking" : priority === "medium" ? "Recommended" : "Informational";
                const message = document.createElement("span");
                message.textContent = detail;
                item.append(title, message);
                return item;
            }));
        }
    }

    function switchFile(filename, focusPanel = false) {
        document.querySelectorAll("[data-panel]").forEach((panel) => {
            const active = panel.dataset.panel === filename;
            panel.hidden = !active;
            panel.setAttribute("aria-hidden", String(!active));
            if (active) panel.tabIndex = -1;
        });

        document.querySelectorAll("[data-file]").forEach((tab) => {
            if (!tab.matches("button")) return;

            const active = tab.dataset.file === filename;
            tab.classList.toggle("active", active);
            tab.setAttribute("aria-selected", String(active));
            tab.tabIndex = active ? 0 : -1;
        });

        if (focusPanel) {
            document.querySelector(`[data-panel="${CSS.escape(filename)}"]`)?.focus();
        }
    }

    function setPreviewMode(mode) {
        if (!["desktop", "tablet", "mobile"].includes(mode)) {
            mode = "desktop";
        }

        state.previewMode = mode;

        const wrapper = $("simulationViewWrapper");
        const previewTools = window.workspacePreview;

        if (previewTools?.applyMode) previewTools.applyMode(wrapper, mode);
        else if (wrapper) wrapper.classList.add(`${mode}-mode${mode === "desktop" ? "-expanded" : ""}`);

        ["desktop", "tablet", "mobile"].forEach((value) => {
            const button = $(`toggle-${value}-view`);

            if (button) {
                const active = value === mode;
                button.classList.toggle("active", active);
                button.setAttribute("aria-pressed", String(active));
            }
        });

        scheduleLocalSave();
    }

    function escapeHtml(value) {
        return String(value || "").replace(/[&<>"']/g, (character) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        }[character]));
    }

    function createGeneratedProject() {
        const business = getBusinessPayload();
        const formSettings = getFormSettings();
        const name = business.name || "Professional Business";
        const hook = business.hook || "Quality service with a better experience.";
        const location = business.location || "";
        const phone = business.phone || "";
        const logoUrl = /^https:\/\/[^\s"']+$/i.test(business.logoUrl || "") ? business.logoUrl : "";
        const logoAlt = business.logoAlt || `${name} brand image`;
        const color = /^#[\da-f]{6}$/i.test(business.color)
            ? business.color
            : "#d4af37";
        const businessType = business.businessType || "local-service";
        const designStyle = business.designStyle || "premium";
        const typeCopy = {
            restaurant: {
                services: "Menu and experiences",
                contact: "Reserve a table",
                about: "A considered experience, from the first welcome to the final detail.",
                proof: "Thoughtful hospitality, memorable moments, and service that brings guests back."
            },
            professional: {
                services: "Expertise and services",
                contact: "Book a consultation",
                about: "Clear advice and dependable execution for decisions that matter.",
                proof: "Practical expertise, transparent communication, and outcomes you can measure."
            },
            creative: {
                services: "Selected capabilities",
                contact: "Start a project",
                about: "Strategy, craft, and a sharper point of view for brands ready to move forward.",
                proof: "Distinctive thinking and careful execution at every stage of the project."
            },
            wellness: {
                services: "Treatments and care",
                contact: "Book an appointment",
                about: "Personalized care designed to help you feel confident, restored, and understood.",
                proof: "A calm, attentive experience built around your goals and your wellbeing."
            },
            retail: {
                services: "Featured collection",
                contact: "Shop with confidence",
                about: "A thoughtfully selected collection with quality you can see and feel.",
                proof: "Useful, beautiful products chosen with a careful eye for lasting value."
            },
            "local-service": {
                services: "Services",
                contact: "Get Started",
                about: "Reliable local service with clear communication and attention to the details.",
                proof: "Professional work, straightforward pricing, and a better customer experience."
            }
        }[businessType] || {
            services: "Services",
            contact: "Get Started",
            about: "Reliable service with clear communication and attention to the details.",
            proof: "Professional work and a better customer experience from start to finish."
        };
        const styleCopy = {
            premium: { font: "Georgia, serif", surface: "#ffffff", background: "#f5f1e8" },
            modern: { font: "Inter, system-ui, sans-serif", surface: "#ffffff", background: "#f5f6f8" },
            bold: { font: "Arial, sans-serif", surface: "#fff8ef", background: "#201a2b" },
            warm: { font: "Trebuchet MS, sans-serif", surface: "#fffdf8", background: "#f7efe7" }
        }[designStyle] || { font: "system-ui, sans-serif", surface: "#ffffff", background: "#f5f6f8" };

        const services = business.services
            .split(",")
            .map((service) => service.trim())
            .filter(Boolean)
            .slice(0, 20);

        const serviceItems = services.length
            ? services
            : ["Professional service", "Reliable results", "Personal attention"];
        const serviceMarkup = serviceItems
            .map((service) => `<li><strong>${escapeHtml(service)}</strong><span>Built around your goals, with care at every step.</span></li>`)
            .join("");

        const phoneMarkup = phone
            ? `<a href="tel:${escapeHtml(
                  phone.replace(/[^\d+]/g, "")
              )}">${escapeHtml(phone)}</a>`
            : "";
        const structuredData = JSON.stringify({
            "@context": "https://schema.org",
            "@type": businessType === "restaurant" ? "Restaurant" : businessType === "professional" ? "ProfessionalService" : "LocalBusiness",
            name,
            description: hook,
            ...(location ? { areaServed: location } : {}),
            ...(phone ? { telephone: phone } : {}),
            ...(logoUrl ? { image: logoUrl, logo: logoUrl } : {}),
            ...(services.length ? { makesOffer: services.map((service) => ({ "@type": "Offer", name: service })) } : {})
        }).replace(/<\//g, "<\/");

        return {
            "index.html": `<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="${color}">
    <meta name="description" content="${escapeHtml(hook)}">
    <meta name="robots" content="index,follow">
    <link rel="canonical" href="./index.html">
    <meta property="og:type" content="website">
    <meta property="og:title" content="${escapeHtml(name)}">
    <meta property="og:description" content="${escapeHtml(hook)}">
    <meta property="og:locale" content="en_US">
    ${logoUrl ? `<meta property="og:image" content="${escapeHtml(logoUrl)}">` : ""}
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="${escapeHtml(name)}">
    <meta name="twitter:description" content="${escapeHtml(hook)}">
    ${logoUrl ? `<meta name="twitter:image" content="${escapeHtml(logoUrl)}">` : ""}
    <script type="application/ld+json">${structuredData}</script>
    <title>${escapeHtml(name)}</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <a class="skip-link" href="#main-content">Skip to content</a>
    <header class="hero">
        <div class="hero-inner">
            <nav class="site-nav" data-site-navigation aria-label="Primary navigation">
                <a class="brand" href="#top">${escapeHtml(name)}</a>
                <a class="nav-cta" href="#contact">${escapeHtml(typeCopy.contact)}</a>
            </nav>
            ${logoUrl ? `<img class="brand-asset" src="${escapeHtml(logoUrl)}" alt="${escapeHtml(logoAlt)}" width="160" height="80" loading="eager">` : ""}
            <p class="eyebrow">${escapeHtml(location)}</p>
            <h1>${escapeHtml(name)}</h1>
            <p class="lead">${escapeHtml(hook)}</p>
            <div class="hero-actions"><a class="button" href="#contact">${escapeHtml(typeCopy.contact)}</a>${phone ? `<a class="text-link" href="tel:${escapeHtml(phone.replace(/[^\d+]/g, ""))}">Call ${escapeHtml(phone)}</a>` : ""}</div>
        </div>
    </header>
    <main id="main-content">
        <section class="trust-strip" aria-label="Why customers choose us">
            <div><strong>Clear process</strong><span>Thoughtful service from start to finish.</span></div>
            <div><strong>Quality focused</strong><span>Reliable results built around your goals.</span></div>
            <div><strong>Local expertise</strong><span>Serving ${escapeHtml(location || "your community")} with care.</span></div>
        </section>
        <section class="intro-section" aria-labelledby="intro-title">
            <div><p class="section-kicker">A better way forward</p><h2 id="intro-title">${escapeHtml(typeCopy.about)}</h2></div>
            <p>${escapeHtml(typeCopy.proof)} ${escapeHtml(hook)}</p>
        </section>
        <section class="proof-section" aria-labelledby="proof-title">
            <div>
                <p class="section-kicker">Why choose us</p>
                <h2 id="proof-title">${escapeHtml(typeCopy.proof)}</h2>
            </div>
            <div class="proof-grid">
                <div><strong>01</strong><span>Clear communication</span></div>
                <div><strong>02</strong><span>Thoughtful execution</span></div>
                <div><strong>03</strong><span>Results that last</span></div>
            </div>
        </section>
        <section aria-labelledby="services-title">
            <p class="section-kicker">What we offer</p>
            <h2 id="services-title">${escapeHtml(typeCopy.services)}</h2>
            <ul class="services">${serviceMarkup}</ul>
        </section>
        <section class="about-section" aria-labelledby="about-title">
            <p class="section-kicker">The experience</p>
            <h2 id="about-title">${escapeHtml(typeCopy.about)}</h2>
            <p>Tell us what you need and we will make the next step simple.</p>
        </section>
        <section id="contact" aria-labelledby="contact-title">
            <h2 id="contact-title">Contact</h2>
            <p class="form-intro">Tell us a little about what you need. We’ll respond with a clear next step.</p>
            <form action="${escapeHtml(formSettings.endpoint)}" method="post" aria-describedby="form-status">
                <label for="contact-name">Name</label>
                <input id="contact-name" name="name" autocomplete="name" required>
                <label for="contact-email">Email</label>
                <input id="contact-email" name="email" type="email" autocomplete="email">
                <label for="contact-message">Message</label>
                <textarea id="contact-message" name="message" required></textarea>
                <input name="website" tabindex="-1" autocomplete="off" aria-hidden="true" class="honeypot">
                ${formSettings.requireConsent ? `<label class="consent-field"><input type="checkbox" name="privacyConsent" value="yes" required> <span>I agree to the privacy policy and consent to being contacted.</span></label>` : ""}
                <button class="button" type="submit">Send Message</button>
                <p id="form-status" role="status" aria-live="polite"></p>
            </form>
            <p>${phoneMarkup}</p>
        </section>
        <footer class="site-footer"><p>${escapeHtml(name)}${location ? ` · Serving ${escapeHtml(location)}` : ""}</p>${phone ? `<p><a class="text-link" href="tel:${escapeHtml(phone.replace(/[^\d+]/g, ""))}">${escapeHtml(phone)}</a></p>` : ""}</footer>
    </main>
    <script src="./script.js" defer></script>
</body>
</html>`,
            "style.css": `:root { --accent: ${color}; --ink: ${designStyle === "bold" ? "#fffaf2" : "#18202b"}; --muted: color-mix(in srgb, var(--ink) 68%, transparent); --surface: ${styleCopy.surface}; --page: ${styleCopy.background}; --font: ${styleCopy.font}; }
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body { margin: 0; color: var(--ink); background: var(--page); font: 16px/1.6 var(--font); }
.hero, main { width: min(1120px, calc(100% - 2rem)); margin: auto; }
.hero { width: 100%; padding: 1rem max(1rem, calc((100% - 1120px) / 2)) 6rem; background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 12%, var(--page)), var(--page)); }
.hero-inner { max-width: 1120px; margin: auto; }
.site-nav { display: flex; justify-content: space-between; align-items: center; gap: 1rem; min-height: 4rem; }
.brand, .nav-cta, .text-link { color: inherit; text-decoration: none; font-weight: 800; }
.brand { font-size: 1.05rem; }
.nav-cta { padding: .55rem .85rem; border: 1px solid color-mix(in srgb, var(--ink) 22%, transparent); border-radius: 999px; }
.hero { padding-top: 1rem; }
.hero h1 { max-width: 850px; margin: 2rem 0 0; font-size: clamp(2.5rem, 8vw, 6rem); line-height: 1; letter-spacing: -.04em; }
.brand-asset { display: block; max-width: 160px; height: auto; margin-top: 2rem; object-fit: contain; }
h2 { margin-top: 0; font-size: clamp(1.8rem, 4vw, 3rem); line-height: 1.1; letter-spacing: -.025em; }
.lead { max-width: 650px; margin: 1.5rem 0; font-size: clamp(1.1rem, 2vw, 1.35rem); color: var(--muted); }
.eyebrow { color: var(--accent); font-weight: 700; text-transform: uppercase; letter-spacing: .12em; }
.hero-actions { display: flex; align-items: center; flex-wrap: wrap; gap: 1rem; }
main { display: grid; gap: 2rem; padding: 2rem 0 5rem; }
section { padding: clamp(1.5rem, 4vw, 3rem); background: var(--surface); border: 1px solid color-mix(in srgb, var(--ink) 10%, transparent); border-radius: 1rem; box-shadow: 0 1rem 3rem color-mix(in srgb, var(--ink) 5%, transparent); }
.section-kicker { margin: 0 0 .65rem; color: var(--accent); font-size: .75rem; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; }
.intro-section { display: grid; gap: 2rem; }
.intro-section > p, .form-intro { color: var(--muted); max-width: 55ch; }
.proof-section { display: grid; gap: 2rem; }
.proof-section h2, .about-section h2 { max-width: 720px; }
.proof-grid { display: grid; gap: 1rem; }
.proof-grid div { display: grid; grid-template-columns: 2rem 1fr; gap: .75rem; align-items: center; padding-top: .75rem; border-top: 1px solid color-mix(in srgb, var(--ink) 18%, transparent); }
.proof-grid strong { color: var(--accent); }
.proof-grid span { font-weight: 700; }
.about-section { display: grid; gap: .75rem; }
.about-section p:last-child { max-width: 55ch; color: var(--muted); }
.trust-strip { display: grid; gap: 1rem; background: transparent; box-shadow: none; border: 0; padding: 1rem 0; }
.trust-strip div { display: grid; gap: .25rem; }
.trust-strip span { color: var(--muted); font-size: .9rem; }
.services { display: grid; gap: .75rem; padding: 0; list-style: none; }
.services li { display: grid; gap: .15rem; padding: 1rem 0; border-bottom: 1px solid color-mix(in srgb, var(--ink) 15%, transparent); }
.services li strong { font-size: 1.05rem; }
.services li span { color: var(--muted); font-size: .9rem; }
form { display: grid; gap: 1rem; max-width: 600px; }
label { display: grid; gap: .35rem; font-weight: 700; }
input, textarea { width: 100%; padding: .8rem; border: 1px solid #aeb7c2; border-radius: .5rem; font: inherit; background: var(--surface); color: var(--ink); }
input:focus, textarea:focus, a:focus-visible, button:focus-visible { outline: 3px solid color-mix(in srgb, var(--accent) 60%, #fff); outline-offset: 3px; }
textarea { min-height: 9rem; resize: vertical; }
.button { display: inline-block; width: fit-content; padding: .8rem 1.2rem; color: #111; background: var(--accent); border-radius: .5rem; text-decoration: none; font-weight: 700; border: 0; cursor: pointer; }
.button:hover, .nav-cta:hover { filter: brightness(.95); transform: translateY(-1px); }
.skip-link { position: absolute; left: 1rem; top: -5rem; z-index: 2; padding: .7rem 1rem; color: #111; background: var(--accent); }
.skip-link:focus { top: 1rem; }
.honeypot { position: absolute; left: -10000px; width: 1px; height: 1px; }
@media (min-width: 760px) { main { grid-template-columns: 1fr 1fr; } .trust-strip, .intro-section, .proof-section { grid-column: 1 / -1; } .trust-strip { grid-template-columns: repeat(3, 1fr); } .intro-section, .proof-section { grid-template-columns: 1.2fr 1fr; align-items: end; } .proof-grid { grid-template-columns: repeat(3, 1fr); } }
@media (prefers-reduced-motion: reduce) { html { scroll-behavior: auto; } *, *::before, *::after { transition-duration: .01ms !important; animation-duration: .01ms !important; } }`,
            "script.js": `document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("form[action], form[data-repair-form='true']").forEach((form) => {
        form.addEventListener("submit", async (event) => {
            event.preventDefault();
            if (!form.reportValidity() || form.dataset.submitting === "true") return;

            form.dataset.submitting = "true";
            const submit = form.querySelector("button[type='submit'], input[type='submit']");
            if (submit) submit.disabled = true;

            try {
                const response = await fetch(form.getAttribute("action") || "/api/submit-form", {
                    method: "POST",
                    body: new URLSearchParams(new FormData(form)),
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                        "X-Submission-ID": window.crypto?.randomUUID?.() || "submission-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10)
                    }
                });

                const result = await response.json().catch(() => ({}));

                if (!response.ok || !result.success) {
                    throw new Error(result.error || "Submission failed.");
                }

                const status = form.querySelector("[role='status']");
                if (status) {
                    status.textContent = result.message || ${JSON.stringify(formSettings.successMessage)};
                    status.dataset.state = "success";
                }
                form.reset();
            } catch (error) {
                const status = form.querySelector("[role='status']");
                if (status) {
                    status.textContent = ${JSON.stringify(formSettings.errorMessage)};
                    status.dataset.state = "error";
                }
            } finally {
                form.dataset.submitting = "false";
                if (submit) submit.disabled = false;
            }
        });
    });
});`,
            "netlify.toml": `[build]
  publish = "."
  functions = "netlify/functions"

[functions]
  node_bundler = "esbuild"

[[redirects]]
  from = "/api/submit-form"
  to = "/.netlify/functions/submit-form"
  status = 200
  force = true

[[headers]]
  for = "/*"

  [headers.values]
    Strict-Transport-Security = "max-age=31536000; includeSubDomains; preload"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
    Permissions-Policy = "camera=(), microphone=(), geolocation=(), payment=(), usb=()"
    Content-Security-Policy = "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; img-src 'self' https: data:; style-src 'self'; script-src 'self'; script-src-attr 'none'; connect-src 'self'; form-action 'self'"`,
            "submit-form.js": "// Use the generated Netlify submit-form function.",
            "netlify/functions/submit-form.js": createSubmitFunction()
        };
    }

    function addReleaseFiles(files = {}) {
        const next = { ...files };
        const pages = Object.keys(next).filter(isPageFile).sort((a, b) => a === "index.html" ? -1 : b === "index.html" ? 1 : a.localeCompare(b));
        const publishedUrl = getPublishedSiteUrl();
        const base = publishedUrl ? `${publishedUrl.replace(/\/$/, "")}/` : "./";
        if (pages.length) {
            next["sitemap.xml"] = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${pages.map((page) => `<url><loc>${escapeHtml(`${base}${page}`)}</loc></url>`).join("")}</urlset>`;
            next["robots.txt"] = `User-agent: *\nAllow: /\nSitemap: ${base}sitemap.xml`;
            if (!next["privacy.html"]) {
                const business = getBusinessPayload();
                const name = escapeHtml(business.name || "This business");
                const endpoint = escapeHtml(getFormSettings().endpoint);
                next["privacy.html"] = `<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<meta name="robots" content="index,follow">\n<title>Privacy — ${name}</title>\n<meta name="description" content="Privacy information for ${name}.">\n<link rel="canonical" href="${publishedUrl ? `${publishedUrl}/privacy.html` : "./privacy.html"}">\n<link rel="stylesheet" href="./style.css">\n</head>\n<body>\n<main>\n<h1>Privacy</h1>\n<p>This draft explains how ${name} may handle information submitted through this website. Review and adapt it with qualified legal advice before publishing.</p>\n<h2>Information submitted through the website</h2>\n<p>If you use the enquiry form, the information you submit is sent through <code>${endpoint}</code> for the purpose of responding to your request. Confirm the actual storage, processors, retention period, and access controls before launch.</p>\n<h2>Your choices</h2>\n<p>Contact the business using the details on the website to ask questions about information submitted through the site.</p>\n<p><a href="./index.html">Return home</a></p>\n</main>\n</body>\n</html>`;
            }
            if (!next["favicon.svg"]) {
                next["favicon.svg"] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-labelledby="title"><title>${escapeHtml(getBusinessPayload().name || "Business")}</title><circle cx="32" cy="32" r="30" fill="${escapeHtml(getBusinessPayload().color || "#c9a86a")}"/><path d="M18 43 32 14l14 29-14-8-14 8Z" fill="#17202a"/></svg>`;
            }
        }
        return next;
    }

    function annotateGeneratedComponents(files = {}) {
        const next = { ...files };
        Object.keys(next).filter(isPageFile).forEach((filename) => {
            const html = String(next[filename] || "");
            let index = 0;
            next[filename] = html.replace(/<(header|section|footer)\b([^>]*)>/gi, (match, tag, attrs) => {
                if (/\bdata-component\s*=/.test(attrs)) return match;
                const name = tag.toLowerCase() === "header" ? "hero" : tag.toLowerCase() === "footer" ? "footer" : `section-${++index}`;
                return `<${tag}${attrs} data-component="${name}">`;
            });
        });
        return next;
    }

    function getGenerationBriefIssues() {
        const business = getBusinessPayload();
        const issues = [];
        if (!business.name) issues.push("Add the public business name.");
        if (!business.hook) issues.push("Describe the customer outcome your business provides.");
        if (!business.services) issues.push("Add at least one service or product.");
        if (!business.location) issues.push("Add the primary city, region, or service area.");
        if (!business.audience) issues.push("Name the audience you most want to attract.");
        if (business.primaryGoal === "booking" && !business.booking) issues.push("Add a booking link for the booking goal, or choose a different primary action.");
        if (business.primaryGoal === "call" && !business.phone) issues.push("Add a phone number for the call goal, or choose a different primary action.");
        if (business.primaryGoal === "email" && !business.email) issues.push("Add a public email for the email goal, or choose a different primary action.");
        return issues;
    }

    function validateGeneratedProject(files = {}) {
        if (window.workspaceValidation?.validateGeneratedProject) {
            return window.workspaceValidation.validateGeneratedProject(files);
        }
        return [];
    }

    async function compileProject() {
        const button = $("compile-pipeline-btn");
        pushHistory();
        setButtonBusy(button, true, "Compiling…");
        setStatus("COMPILING");

        try {
            readEditedFiles();
            const briefIssues = getGenerationBriefIssues();
            if (briefIssues.length) {
                throw new Error(`Complete the brief before creating a high-quality website:\\n• ${briefIssues.join("\\n• ")}`);
            }
            const generator = window.workspaceGenerator || window.siteGenerator;
            if (typeof generator?.createProject !== "function") {
                throw new Error("The canonical site generator is unavailable.");
            }
            const generatedFiles = addReleaseFiles(annotateGeneratedComponents(generator.createProject()));
            const generatedIssues = validateGeneratedProject(generatedFiles);
            if (generatedIssues.length) {
                throw new Error(`The generated project failed its safety check:\\n• ${generatedIssues.join("\\n• ")}`);
            }
            state.files = generatedFiles;
            state.generationManifest = {
                version: "2.2.0",
                createdAt: new Date().toISOString(),
                inputHash: simpleHash(JSON.stringify(getWorkspaceForm())),
                files: createFileManifest(state.files),
                stages: ["brief", "structure", "content", "styles", "quality"]
            };
            state.form = getWorkspaceForm();
            state.projectName =
                $("project-name-input")?.value.trim() || state.projectName;

            renderFiles({ dirty: true });
            setDebugger("Project compiled successfully.");
            showToast("Website compiled successfully.", "success");
            setStatus("READY");
        } catch (error) {
            setDebugger(error.message || "Compilation failed.", true);
            setStatus("ERROR", true);
        } finally {
            setButtonBusy(button, false);
        }
    }

    async function repairSource(source, button, controller = null) {
        const operationToken = beginOperation();
        const requestController = controller || new AbortController();
        const ownsRequest = !controller;

        if (ownsRequest) {
            state.requestController = requestController;
            setRequestBusy(true);
        }

        setButtonBusy(button, true, "Repairing…");
        setStatus("REPAIRING");

        try {
            const result = await requestJson("/api/repair", {
                method: "POST",
                body: JSON.stringify({
                    rawSource: source,
                    business: getBusinessPayload()
                }),
                signal: requestController.signal
            });

            if (!result.success || !result.files) {
                throw new Error(result.error || "Repair returned no files.");
            }

            if (!isCurrentOperation(operationToken)) return result;
            const previousFiles = { ...state.files };
            pushHistory();
            state.files = addReleaseFiles(annotateGeneratedComponents({
                ...DEFAULT_FILES,
                ...result.files
            }));
            state.form = getWorkspaceForm();
            const changes = recordRepairChange(previousFiles, state.files, "import-repair");

            renderFiles({ dirty: true });
            setDebugger(
                [
                    `Website imported and repaired successfully. ${changes.length} file${changes.length === 1 ? "" : "s"} changed.`,
                    ...(result.warnings || [])
                ].join("\n")
            );
            setStatus("READY");
        } catch (error) {
            if (error.name === "AbortError") {
                setDebugger("Request cancelled.", true);
                setStatus("CANCELLED", true);
            } else {
                setDebugger(error.message || "Repair failed.", true);
                setStatus("ERROR", true);
            }

            throw error;
        } finally {
            if (ownsRequest) {
                setRequestBusy(false, requestController);
            }

            setButtonBusy(button, false);
        }
    }

    async function scrapeWebsite(url, button) {
        const normalized = normalizePublicUrl(url);

        if (!normalized) {
            throw new Error("Enter a valid public HTTP or HTTPS URL.");
        }

        const controller = new AbortController();
        state.requestController = controller;
        setRequestBusy(true);
        setButtonBusy(button, true, "Scraping…");
        setStatus("SCRAPING");

        try {
            var query = new URLSearchParams({
                url: normalized,
                mode: $("import-mode-selector")?.value || "conversion"
            });
            const result = await requestJson(`/api/scrape?${query}`, {
                method: "GET",
                signal: controller.signal
            });

            if (!result.contents) {
                throw new Error("The scraper returned no HTML content.");
            }

            await repairSource(result.contents, button, controller);
        } catch (error) {
            if (error.name !== "AbortError") {
                setDebugger(error.message || "Scrape failed.", true);
                setStatus("ERROR", true);
            }

            throw error;
        } finally {
            setRequestBusy(false, controller);
            setButtonBusy(button, false);
        }
    }

    function buildDiscoveryQuery() {
        const business = getBusinessPayload();

        return [business.name, business.location, business.hook]
            .filter(Boolean)
            .join(" ")
            .trim();
    }

    async function handleDiscover() {
        const button = $("discover-btn");
        var query = buildDiscoveryQuery();

        if (!query) {
            setDebugger(
                "Enter a business name, location, or marketing hook first.",
                true
            );
            return;
        }

        setButtonBusy(button, true, "Searching…");
        setStatus("SEARCHING");

        try {
            const result = await requestJson(
                `/api/search?q=${encodeURIComponent(query)}`,
                { method: "GET" }
            );

            const first = Array.isArray(result.results)
                ? result.results.find((item) => normalizePublicUrl(item?.url))
                : null;

            if (!first) {
                throw new Error("No public website was found for that search.");
            }

            const discoveredUrl = normalizePublicUrl(first.url);
            $("input-scrape-url").value = discoveredUrl;
            await scrapeWebsite(discoveredUrl, button);
        } catch (error) {
            if (error.name !== "AbortError") {
                setDebugger(error.message || "Website search failed.", true);
                setStatus("ERROR", true);
            }
        } finally {
            setButtonBusy(button, false);
            if (!state.requestBusy) setRequestBusy(false);
        }
    }

    async function redeployCurrentVersion() {
        const latest = state.deploymentHistory[0];
        const button = $("redeploy-site-btn");
        if (!latest?.files) {
            showToast("No saved deployment version is available.", "error");
            return;
        }
        if (!window.confirm("Redeploy the latest recorded version?")) return;
        const status = $("redeploy-status");
        if (status) status.textContent = "Redeploying the latest recorded version…";
        await publishSite(latest.files, button).catch(() => {});
        updateRedeployControl();
    }

    function cancelRequest() {
        beginOperation();
        if (!state.requestController) return;

        state.requestController.abort();
        setRequestBusy(false, state.requestController);
        setStatus("CANCELLED", true);
    }

    function undoWorkspace() {
        const snapshot = state.history.pop();

        if (!snapshot) {
            setDebugger("There are no workspace changes to undo.", true);
            return;
        }

        state.redoHistory.push(workspaceSnapshot());
        applySnapshot(snapshot, { dirty: true });
        updateUndoButton();
        setDebugger("The last workspace change was undone.");
        setStatus("READY");
    }

    function redoWorkspace() {
        const snapshot = state.redoHistory.pop();
        if (!snapshot) {
            setDebugger("There are no workspace changes to redo.", true);
            return;
        }
        state.history.push(workspaceSnapshot());
        applySnapshot(snapshot, { dirty: true });
        updateUndoButton();
        setDebugger("The last undone workspace change was restored.");
        setStatus("READY");
    }

    async function copyFile(targetId) {
        const source = $(targetId);

        if (!source) return;

        readEditedFiles();

        try {
            await navigator.clipboard.writeText(source.textContent || "");
            setDebugger("File copied to the clipboard.");
            showToast("File copied to the clipboard.", "success");
        } catch {
            setDebugger("Clipboard access was denied.", true);
        }
    }

    function crc32(bytes) {
        let crc = 0xffffffff;

        for (const byte of bytes) {
            crc ^= byte;

            for (let bit = 0; bit < 8; bit += 1) {
                crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
            }
        }

        return (crc ^ 0xffffffff) >>> 0;
    }

    function writeUint16(value) {
        return new Uint8Array([value & 255, (value >>> 8) & 255]);
    }

    function writeUint32(value) {
        return new Uint8Array([
            value & 255,
            (value >>> 8) & 255,
            (value >>> 16) & 255,
            (value >>> 24) & 255
        ]);
    }

    function concatBytes(parts) {
        const total = parts.reduce((sum, part) => sum + part.length, 0);
        const output = new Uint8Array(total);
        let offset = 0;

        parts.forEach((part) => {
            output.set(part, offset);
            offset += part.length;
        });

        return output;
    }

    function createZip(files) {
        const encoder = new TextEncoder();
        const localParts = [];
        const centralParts = [];
        let offset = 0;
        const entries = Object.entries(files);

        entries.forEach(([name, content]) => {
            const nameBytes = encoder.encode(name);
            const dataBytes = encoder.encode(String(content || ""));
            const checksum = crc32(dataBytes);

            const localHeader = concatBytes([
                new Uint8Array([0x50, 0x4b, 0x03, 0x04]),
                writeUint16(20),
                writeUint16(0x0800),
                writeUint16(0),
                writeUint16(0),
                writeUint16(0),
                writeUint32(checksum),
                writeUint32(dataBytes.length),
                writeUint32(dataBytes.length),
                writeUint16(nameBytes.length),
                writeUint16(0),
                nameBytes,
                dataBytes
            ]);

            localParts.push(localHeader);

            const centralHeader = concatBytes([
                new Uint8Array([0x50, 0x4b, 0x01, 0x02]),
                writeUint16(20),
                writeUint16(20),
                writeUint16(0x0800),
                writeUint16(0),
                writeUint16(0),
                writeUint16(0),
                writeUint32(checksum),
                writeUint32(dataBytes.length),
                writeUint32(dataBytes.length),
                writeUint16(nameBytes.length),
                writeUint16(0),
                writeUint16(0),
                writeUint16(0),
                writeUint16(0),
                writeUint32(0),
                writeUint32(offset),
                nameBytes
            ]);

            centralParts.push(centralHeader);
            offset += localHeader.length;
        });

        const centralDirectory = concatBytes(centralParts);
        const localDirectory = concatBytes(localParts);
        const endRecord = concatBytes([
            new Uint8Array([0x50, 0x4b, 0x05, 0x06]),
            writeUint16(0),
            writeUint16(0),
            writeUint16(entries.length),
            writeUint16(entries.length),
            writeUint32(centralDirectory.length),
            writeUint32(localDirectory.length),
            writeUint16(0)
        ]);

        return concatBytes([localDirectory, centralDirectory, endRecord]);
    }

    function exportProjectJson() {
        readEditedFiles();
        const payload = {
            format: "morrow-project",
            version: 1,
            exportedAt: new Date().toISOString(),
            screenshots: {
                include: false,
                reason: "Screenshots are temporary derived artifacts."
            },
            snapshot: workspaceSnapshot()
        };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        const name = (state.projectName || getBusinessPayload().name || "website-project").replace(/[^a-z0-9_-]+/gi, "-").toLowerCase() || "website-project";
        link.href = url;
        link.download = `${name}.morrow.json`;
        link.click();
        URL.revokeObjectURL(url);
        showToast("Project backup downloaded.", "success");
    }

    async function importProjectJson(event) {
        const file = event.target.files?.[0];
        event.target.value = "";
        if (!file) return;
        try {
            const payload = JSON.parse(await file.text());
            const snapshot = payload?.snapshot || payload;
            if (!snapshot?.files || typeof snapshot.files !== "object" || !snapshot.files["index.html"]) throw new Error("This file is not a valid project backup.");
            pushHistory();
            applySnapshot(snapshot, { replaceContext: true, dirty: true });
            showToast("Project backup restored.", "success");
        } catch (error) {
            showToast(error.message || "Project backup could not be restored.", "error");
        }
    }

    function exportProject() {
        const report = runQualityCheck(false);

        if (report.blocking.length) {
            showToast("Fix the blocking quality issues before exporting.", "error");
            return;
        }

        readEditedFiles();

        const files = Object.fromEntries(
            Object.entries(state.files).filter(([, content]) =>
                String(content || "").trim()
            )
        );

        if (!Object.keys(files).length) {
            setDebugger("Compile or import a project before exporting.", true);
            showToast("Compile or import a project before exporting.", "error");
            return;
        }

        const archive = createZip(files);
        const blob = new Blob([archive], { type: "application/zip" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        const filename =
            (
                state.projectName ||
                getBusinessPayload().name ||
                "website-project"
            )
                .replace(/[^a-z0-9_-]+/gi, "-")
                .replace(/^-+|-+$/g, "")
                .toLowerCase() || "website-project";

        link.href = url;
        link.download = `${filename}.zip`;
        document.body.append(link);
        link.click();
        link.remove();

        setTimeout(() => URL.revokeObjectURL(url), 0);
        setDebugger("Deployable ZIP exported successfully.");
        showToast("Deployable ZIP exported successfully.", "success");
    }

    function clearProjectContext(options = {}) {
        const { persist = true, announce = true } = options;

        // Invalidate every pending async operation before replacing project data.
        beginOperation();
        state.projectSessionId = getSubmissionId();
        state.requestController?.abort?.();
        state.requestController = null;
        setRequestBusy(false);
        clearTimeout(state.previewTimer);
        clearTimeout(state.localSaveTimer);
        clearTimeout(state.toastTimer);
        state.previewTimer = null;
        state.localSaveTimer = null;
        state.toastTimer = null;

        state.files = { ...DEFAULT_FILES };
        state.form = {};
        state.projectName = "";
        state.projectId = null;
        state.activePage = "index.html";
        state.previewMode = "desktop";
        state.dirty = false;
        state.lastPreviewKey = "";
        state.visualSelection = null;
        state.visualSection = null;
        state.previewZoom = 1;
        state.deploymentHistory = [];
        state.runtimeErrors = [];
        state.publishedSiteUrl = "";
        state.lastSavedSnapshot = "";
        state.generationManifest = null;
        state.repairLog = [];
        state.history = [];
        state.redoHistory = [];

        const iframe = $("previewContentIframe");
        if (iframe) {
            iframe.onload = null;
            iframe.srcdoc = "";
            iframe.src = "about:blank";
        }

        if (persist) {
            try { localStorage.removeItem("luxury-engine-workspace"); } catch {}
            window.workspaceFixes?.clearProjectId?.();
        }

        if (announce) {
            window.dispatchEvent(new CustomEvent("workspace:project-context-cleared", {
                detail: { sessionId: state.projectSessionId }
            }));
        }
    }

    function flushWorkspace(confirmRequired = true) {
        if (
            confirmRequired &&
            !window.confirm("Clear the current workspace?")
        ) {
            return;
        }

        clearProjectContext();

        state.files = { ...DEFAULT_FILES };
        state.form = {};
        state.generationManifest = null;
        state.repairLog = [];
        state.projectSessionId = getSubmissionId();
        state.projectName = "";
        state.projectId = null;
        state.publishedSiteUrl = "";
        state.activePage = "index.html";
        state.previewMode = "desktop";
        state.dirty = false;
        state.history = [];
        state.redoHistory = [];
        state.deploymentHistory = [];
        state.runtimeErrors = [];
        clearVisualSelection();

        document
            .querySelectorAll("input, textarea, select")
            .forEach((element) => {
                if (element.type === "checkbox") {
                    element.checked = false;
                } else if (element.id === "input-biz-color") {
                    element.value = "#d4af37";
                } else if (element.id === "input-biz-secondary-color") {
                    element.value = "#18202b";
                } else if (element.id === "input-business-type") {
                    element.value = "local-service";
                } else if (element.id === "input-design-style") {
                    element.value = "premium";
                } else if (element.id === "input-primary-goal") {
                    element.value = "quote";
                } else {
                    element.value = "";
                }
            });

        if ($("color-help")) $("color-help").textContent = "#d4af37";
        if ($("secondary-color-help")) $("secondary-color-help").textContent = "#18202b";
        if ($("input-form-endpoint")) $("input-form-endpoint").value = "/api/submit-form";
        if ($("input-form-success")) $("input-form-success").value = "Thanks — your request was sent.";
        if ($("input-form-error")) $("input-form-error").value = "The form could not be submitted.";
        if ($("input-form-consent")) $("input-form-consent").checked = false;
        renderDeploymentHistory();
        renderRuntimeErrors();
        updateRedeployControl();
        renderFiles();
        setDebugger("Workspace cleared.");
        setStatus("STANDBY");
    }

    function setCloudControls(enabled) {
        [
            "load-project-btn",
            "rename-project-btn",
            "delete-project-btn"
        ].forEach((id) => {
            const button = $(id);
            if (!button) return;

            button.disabled = !enabled;
            button.setAttribute("aria-disabled", String(!enabled));
        });
    }

    async function saveCloudProject() {
        const api = window.supabaseWorkspace;

        if (!api?.saveProject) {
            setDebugger("Cloud project storage is not available.", true);
            return;
        }

        const button = $("save-project-btn");
        readEditedFiles();
        setButtonBusy(button, true, "Saving…");

        try {
            const result = await api.saveProject({
                id: state.projectId || undefined,
                name: $("project-name-input")?.value.trim() || undefined
            });

            const project = result?.project;

            if (project?.id) {
                state.projectId = project.id;
                setCloudControls(true);
            }

            setDirty(false);
            setDebugger("Project saved to the cloud.");
            setStatus("READY");
        } catch (error) {
            setDebugger(error.message || "Cloud save failed.", true);
            setStatus("ERROR", true);
        } finally {
            setButtonBusy(button, false);
        }
    }

    async function refreshCloudProjects() {
        const api = window.supabaseWorkspace;

        if (!api?.loadProjects) {
            setDebugger("Cloud project storage is not available.", true);
            return;
        }

        const button = $("load-projects-btn");
        setButtonBusy(button, true, "Loading…");

        try {
            await api.loadProjects();
            setDebugger("Cloud projects refreshed.");
        } catch (error) {
            setDebugger(error.message || "Projects could not be loaded.", true);
        } finally {
            setButtonBusy(button, false);
        }
    }

    async function loadSelectedCloudProject() {
        const id = $("project-selector")?.value;

        if (!id || !window.supabaseWorkspace?.loadProject) return;

        const button = $("load-project-btn");
        setButtonBusy(button, true, "Loading…");

        try {
            const result = await window.supabaseWorkspace.loadProject(id);
            const project = result?.project;

            if (!project) throw new Error("Project data was not returned.");

            pushHistory();
            applySnapshot({
                files: project.files,
                form: project.form_data || project.formData,
                projectName: project.name,
                projectId: project.id,
                previewMode: project.preview_mode || project.previewMode
            }, { replaceContext: true, dirty: false });

            state.dirty = false;
            setCloudControls(true);
            setDebugger("Cloud project loaded.");
            setStatus("READY");
        } catch (error) {
            setDebugger(error.message || "Project could not be loaded.", true);
        } finally {
            setButtonBusy(button, false);
        }
    }

    async function renameCloudProject() {
        const id = state.projectId || $("project-selector")?.value;

        if (!id || !window.supabaseWorkspace?.renameProject) return;

        const current = $("project-name-input")?.value || "";
        const name = window.prompt("Enter a new project name:", current);

        if (name === null) return;

        try {
            await window.supabaseWorkspace.renameProject(id, name);
            state.projectName = name.trim();
            if ($("project-name-input")) {
                $("project-name-input").value = state.projectName;
            }
            setDebugger("Project renamed.");
        } catch (error) {
            setDebugger(error.message || "Project could not be renamed.", true);
        }
    }

    async function deleteCloudProject() {
        const id = state.projectId || $("project-selector")?.value;

        if (!id || !window.supabaseWorkspace?.deleteProject) return;
        if (!window.confirm("Delete this cloud project permanently?")) return;

        try {
            await window.supabaseWorkspace.deleteProject(id);
            state.projectId = null;
            setCloudControls(false);
            setDebugger("Cloud project deleted.");
        } catch (error) {
            setDebugger(error.message || "Project could not be deleted.", true);
        }
    }

    async function restoreCloudVersion() {
        if (!window.supabaseWorkspace?.restoreVersion) {
            setDebugger(
                "Version restoration is not available on the current API.",
                true
            );
            return;
        }

        try {
            await window.supabaseWorkspace.restoreVersion(
                state.projectId,
                $("project-version-selector")?.value
            );
        } catch (error) {
            setDebugger(error.message || "Version could not be restored.", true);
        }
    }

    function hostingProviderLabel(provider) {
        return provider === "github-pages" ? "GitHub Pages" : provider === "any-static-host" ? "any static host" : "Cloudflare Pages";
    }

    function hostingChecklist(provider = $("hosting-provider-select")?.value || "cloudflare-pages") {
        const label = hostingProviderLabel(provider);
        return `MORROW FREE STATIC HOSTING CHECKLIST\n\n1. Create or use your own ${label} account.\n2. Export the website files from Morrow.\n3. Upload or connect the exported files to the provider.\n4. Set the published HTTPS domain in Morrow.\n5. Verify pages, assets, and forms before sharing.\n\nImportant limits\n- Static hosting is suitable for HTML, CSS, JavaScript, and public assets.\n- Form delivery, email, databases, authentication, analytics, and AI usage require a connected provider and may have quotas or costs.\n- Morrow does not control or guarantee third-party free tiers.`;
    }

    function updateHostingOptionsStatus() {
        const provider = $("hosting-provider-select")?.value || "cloudflare-pages";
        const status = $("hosting-options-status");
        if (status) status.textContent = `${hostingProviderLabel(provider)} is a user-owned static hosting path. Export files, connect your account, then verify the live URL.`;
    }

    function bindHostingOptions() {
        $("hosting-provider-select")?.addEventListener("change", updateHostingOptionsStatus);
        $("copy-hosting-checklist-btn")?.addEventListener("click", async () => {
            try {
                await navigator.clipboard.writeText(hostingChecklist());
                $("hosting-options-status").textContent = "Hosting checklist copied.";
            } catch {
                $("hosting-options-status").textContent = "Clipboard access was unavailable. Use Download hosting guide instead.";
            }
        });
        $("download-hosting-guide-btn")?.addEventListener("click", () => {
            const blob = new Blob([hostingChecklist()], { type: "text/plain;charset=utf-8" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "morrow-static-hosting-checklist.txt";
            link.click();
            setTimeout(() => URL.revokeObjectURL(link.href), 0);
            $("hosting-options-status").textContent = "Hosting checklist downloaded.";
        });
        updateHostingOptionsStatus();
    }

    function bindEvents() {
        bindHostingOptions();
        // Onboarding is initialized by the inline controller in index.html. Keep
        // one owner for its storage key and listeners so dismiss/create/import
        // actions do not fire twice or disagree about visibility.
        $("compile-pipeline-btn")?.addEventListener(
            "click",
            compileProject
        );

        $("scrape-btn")?.addEventListener("click", () => {
            scrapeWebsite($("input-scrape-url")?.value, $("scrape-btn"))
                .catch(() => {});
        });

        $("discover-btn")?.addEventListener("click", handleDiscover);
        $("add-page-btn")?.addEventListener("click", addPage);
        $("add-template-page-btn")?.addEventListener("click", addTemplatePage);
        $("delete-page-btn")?.addEventListener("click", deletePage);
        $("visual-editor-apply-btn")?.addEventListener("click", applyVisualText);
        $("visual-editor-clear-btn")?.addEventListener("click", clearVisualSelection);
        $("preview-empty-action")?.addEventListener("click", () => $("input-biz-name")?.focus());
        $("preview-zoom-select")?.addEventListener("change", (event) => {
            state.previewZoom = Number(event.target.value) || 1;
            updatePreview();
            scheduleLocalSave();
        });
        $("toggle-preview-fullscreen-btn")?.addEventListener("click", async (event) => {
            const wrapper = $("simulationViewWrapper");
            if (!wrapper) return;
            if (!document.fullscreenElement) await wrapper.requestFullscreen?.();
            else await document.exitFullscreen?.();
            event.currentTarget.setAttribute("aria-pressed", String(Boolean(document.fullscreenElement)));
        });
        $("section-move-up-btn")?.addEventListener("click", () => updateVisualSection("up"));
        $("section-move-down-btn")?.addEventListener("click", () => updateVisualSection("down"));
        $("section-duplicate-btn")?.addEventListener("click", () => updateVisualSection("duplicate"));
        $("section-delete-btn")?.addEventListener("click", () => updateVisualSection("delete"));
        $("show-repair-plan-btn")?.addEventListener("click", () => showRepairPlan());
        $("visual-editor-text")?.addEventListener("keydown", (event) => {
            if (event.key === "Enter") applyVisualText();
        });
        $("visual-editor-clear-btn")?.addEventListener("keydown", (event) => {
            if (event.key === "Escape") clearVisualSelection();
        });
        $("cancel-generation-btn")?.addEventListener("click", cancelRequest);
        $("undo-workspace-btn")?.addEventListener("click", undoWorkspace);
        $("redo-workspace-btn")?.addEventListener("click", redoWorkspace);
        $("export-zip-btn")?.addEventListener("click", exportProject);
        $("export-project-json-btn")?.addEventListener("click", exportProjectJson);
        $("import-project-json-input")?.addEventListener("change", importProjectJson);
        $("diagnostic-severity-filter")?.addEventListener("change", updateDiagnostics);
        $("diagnostic-score-help-btn")?.addEventListener("click", (event) => {
            const help = $("diagnostic-score-help");
            if (!help) return;
            help.hidden = !help.hidden;
            event.currentTarget.setAttribute("aria-expanded", String(!help.hidden));
        });
        $("deployment-preflight-btn")?.addEventListener("click", () => runDeploymentPreflight(true));
        $("verify-deployment-btn")?.addEventListener("click", async () => {
            const url = getPublishedSiteUrl();
            const result = await verifyPublishedDeployment(url);
            setDebugger(result.success ? "Published site verification passed." : result.error || "Published site verification found issues.", !result.success);
        });
        $("publish-site-btn")?.addEventListener("click", publishSite);
        ["deployment-public-origin", "deployment-webhook-url", "deployment-webhook-hosts", "deployment-supabase-url", "deployment-supabase-anon-key", "deployment-supabase-service-key"].forEach((id) => {
            $(id)?.addEventListener("input", () => {
                const setup = $("setup-and-publish-btn");
                if (!setup) return;
                const enabled = Boolean($("deployment-public-origin")?.value.trim()) && !state.requestBusy;
                setup.disabled = !enabled;
                setup.setAttribute("aria-disabled", String(!enabled));
            });
        });
        $("rollback-site-btn")?.addEventListener("click", rollbackLatestDeployment);
        $("run-quality-check-btn")?.addEventListener("click", () => runQualityCheck(true));
        $("run-preview-smoke-btn")?.addEventListener("click", runPreviewSmokeTests);
        $("fix-quality-issues-btn")?.addEventListener("click", fixSafeQualityIssues);
        $("flush-workspace-btn")?.addEventListener("click", () =>
            flushWorkspace(true)
        );

        $("new-project-btn")?.addEventListener("click", () =>
            flushWorkspace(true)
        );
        $("save-project-btn")?.addEventListener("click", saveCloudProject);
        $("load-projects-btn")?.addEventListener(
            "click",
            refreshCloudProjects
        );
        $("load-project-btn")?.addEventListener(
            "click",
            loadSelectedCloudProject
        );
        $("rename-project-btn")?.addEventListener(
            "click",
            renameCloudProject
        );
        $("delete-project-btn")?.addEventListener(
            "click",
            deleteCloudProject
        );
        $("restore-version-btn")?.addEventListener(
            "click",
            restoreCloudVersion
        );

        $("project-selector")?.addEventListener("change", (event) => {
            const selected = Boolean(event.target.value);
            setCloudControls(selected);
        });

        document.querySelectorAll("[data-file]").forEach((tab) => {
            if (tab.matches("button")) {
                tab.addEventListener("click", () =>
                    switchFile(tab.dataset.file)
                );
                tab.addEventListener("keydown", (event) => {
                    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
                    event.preventDefault();
                    const tabs = [...document.querySelectorAll("[data-file]")].filter((item) => item.matches("button"));
                    const currentIndex = tabs.indexOf(tab);
                    const nextIndex = event.key === "Home"
                        ? 0
                        : event.key === "End"
                            ? tabs.length - 1
                            : (currentIndex + (event.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length;
                    const nextTab = tabs[nextIndex];
                    nextTab?.focus();
                    switchFile(nextTab?.dataset.file || tab.dataset.file, true);
                });
            }
        });

        document.querySelectorAll(".copy-payload-btn").forEach((button) => {
            button.addEventListener("click", () =>
                copyFile(button.dataset.copyTarget)
            );
        });

        ["desktop", "tablet", "mobile"].forEach((mode) => {
            $(`toggle-${mode}-view`)?.addEventListener("click", () => {
                setPreviewMode(mode);
            });
        });

        $("page-selector")?.addEventListener("change", (event) => {
            activatePage(event.target.value);
        });

        document.addEventListener("input", (event) => {
            if (event.target.matches("[contenteditable='true']")) {
                if (!state.dirty) pushHistory();

                readEditedFiles();
                setDirty(true);
                schedulePreviewUpdate();
            }

            if (event.target.id === "input-biz-color" && $("color-help")) {
                $("color-help").textContent = event.target.value;
            }
            if (event.target.id === "input-biz-secondary-color" && $("secondary-color-help")) {
                $("secondary-color-help").textContent = event.target.value;
            }

            if (
                event.target.matches(
                    "#project-name-input, #published-site-url-input, #input-biz-name, #input-biz-hook, #input-biz-location, #input-biz-phone, #input-biz-color, #input-biz-secondary-color, #input-biz-services, #input-biz-email, #input-biz-address, #input-biz-audience, #input-biz-social, #input-biz-differentiator, #input-biz-testimonial, #input-biz-testimonial-author, #input-biz-credentials, #input-biz-experience, #input-biz-customers, #input-biz-hours, #input-biz-booking, #input-business-type, #input-design-style, #input-content-tone, #input-layout-density, #input-scrape-url, #input-form-endpoint, #input-form-success, #input-form-error, #input-form-qualification, #input-form-consent"
                )
            ) {
                if (!state.dirty) pushHistory();

                state.form = getWorkspaceForm();
                state.projectName =
                    $("project-name-input")?.value.trim() || "";
                setDirty(true);
            }
        });

        $("cancel-generation-btn").disabled = true;
        setCloudControls(Boolean(state.projectId));

        bindGeneratedForms(document);

        document.addEventListener("keydown", (event) => {
            const modifier = event.ctrlKey || event.metaKey;

            if (!modifier) return;

            if (event.key.toLowerCase() === "s") {
                event.preventDefault();
                window.workspaceFixes?.saveToCloud?.();
            }

            if (event.key === "Enter") {
                event.preventDefault();
                compileProject();
            }

            if (event.key.toLowerCase() === "z" && !event.shiftKey) {
                event.preventDefault();
                undoWorkspace();
            }

            if (event.key.toLowerCase() === "z" && event.shiftKey) {
                event.preventDefault();
                redoWorkspace();
            }

            if (event.key.toLowerCase() === "y") {
                event.preventDefault();
                redoWorkspace();
            }

            if (event.shiftKey && event.key.toLowerCase() === "p") {
                event.preventDefault();
                $("previewContentIframe")?.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                });
            }
        });
    }

    function exposeWorkspaceApi() {
        window.workspaceAPI = {
            getState: () => ({
                files: { ...state.files },
                form: { ...state.form },
                projectName: state.projectName,
                projectId: state.projectId,
                previewMode: state.previewMode,
                revision: currentFilesRevision(),
                dirty: state.dirty,
                deploymentHistory: state.deploymentHistory.map((deployment) => ({ ...deployment })),
                generationManifest: state.generationManifest,
                repairLog: [...state.repairLog],
                formTestRevision: state.formTestRevision,
                projectSessionId: state.projectSessionId
            }),
            setProjectId: (id) => {
                state.projectId = id || null;
                saveLocal();
                setCloudControls(Boolean(state.projectId));
            },
            setProjectName: (name) => {
                state.projectName = String(name || "");

                if ($("project-name-input")) {
                    $("project-name-input").value = state.projectName;
                }

                saveLocal();
            },
            markDirty: () => setDirty(true),
            markClean: () => setDirty(false),
            setFormTestRevision: (revision) => {
                state.formTestRevision = String(revision || "");
                saveLocal();
            },
            setHostingProvider: (provider) => {
                const allowed = ["cloudflare-pages", "github-pages", "vercel", "netlify", "any-static-host"];
                const value = allowed.includes(String(provider)) ? String(provider) : "any-static-host";
                state.form = { ...(state.form || {}), hostingProvider: value };
                const field = $("hosting-provider-select");
                if (field) field.value = value;
                setDirty(true);
                window.dispatchEvent(new CustomEvent("workspace:hosting-provider-change", { detail: { provider: value } }));
            },
            applySnapshot: (snapshot = {}, options = {}) => {
                applySnapshot(snapshot, {
                    dirty: options.dirty ?? false,
                    replaceContext: Boolean(options.replaceContext)
                });
            },
            clearProjectContext: (options = {}) => {
                clearProjectContext(options);
                renderDeploymentHistory();
                renderRuntimeErrors();
                renderFiles();
                setPreviewMode("desktop");
                updateRedeployControl();
            }
        };
    }

    function initialize() {
        if (state.initialized) return;

        state.initialized = true;
        state.files = { ...DEFAULT_FILES };
        exposeWorkspaceApi();
        loadLocal();
        bindEvents();
        renderFiles();
        setPreviewMode(state.previewMode);

        window.addEventListener("error", (event) => {
            recordRuntimeError(event.error || event.message, "Uncaught error");
        });
        window.addEventListener("unhandledrejection", (event) => {
            recordRuntimeError(event.reason, "Unhandled promise rejection");
        });
        window.addEventListener("message", (event) => {
            const iframe = $("previewContentIframe");
            if (event.source !== iframe?.contentWindow) return;
            if (event.origin !== window.location.origin) return;
            if (event.data?.type !== "workspace-preview-error") return;
            recordRuntimeError(new Error(String(event.data.message || "Preview script error").slice(0, 500)), "Preview runtime error");
        });

        window.addEventListener("pagehide", () => {
            clearTimeout(state.previewTimer);
            clearTimeout(state.localSaveTimer);
            saveLocal();
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initialize, {
            once: true
        });
    } else {
        initialize();
    }
    document.addEventListener("DOMContentLoaded", () => {
        const clearHistoryButton = $("clear-deployment-history-btn");
        clearHistoryButton?.addEventListener("click", clearDeploymentHistory);
        $("run-workspace-tests-btn")?.addEventListener("click", runWorkspaceTests);
        $("run-production-check-btn")?.addEventListener("click", () => runProductionIntegrationCheck().catch((error) => {
            setDebugger(error.message || "Production integration check failed.", true);
        }));
        $("clear-workspace-errors-btn")?.addEventListener("click", clearRuntimeErrors);

        const deploymentUrl = $("deployment-url");
        const deploymentLink = $("deployment-url-link");
        if (deploymentUrl && deploymentLink) {
            const observer = new MutationObserver(() => {
                const url = deploymentLink.href;
                if (!deploymentUrl.hidden && /^https?:\/\//i.test(url)) {
                    const latest = state.deploymentHistory[0];
                    if (!latest || latest.url !== url) {
                        recordDeployment({
                            url,
                            state: $("deployment-status")?.textContent.trim() || "published"
                        });
                    }
                }
            });
            observer.observe(deploymentUrl, { attributes: true, subtree: true, childList: true });
        }
        renderDeploymentHistory();
    });
})();