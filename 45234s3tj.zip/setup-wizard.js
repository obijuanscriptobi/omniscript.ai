"use strict";

// Unified setup contract. It turns the existing editor fields into one plan that
// can feed generation, launch checks, notifications, and the future dashboard.
(() => {
    const text = (value) => String(value ?? "").trim();
    const list = (value) => (Array.isArray(value) ? value : text(value).split(/[\n,]/)).map(text).filter(Boolean);
    const clone = (value) => JSON.parse(JSON.stringify(value));
    const id = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const CHECKLIST = Object.freeze([
        ["content-review", "Review business information and page copy", "content"],
        ["form-testing", "Test the contact or lead form", "conversion"],
        ["domain-connection", "Connect the business domain", "domain"],
        ["ssl-dns", "Verify DNS and SSL", "domain"],
        ["responsive-check", "Check mobile and desktop layouts", "quality"],
        ["analytics-verification", "Verify analytics and conversion events", "measurement"],
        ["client-approval", "Approve the site before publishing", "approval"],
        ["publish", "Publish the website", "deployment"]
    ]);

    function collect(values = {}) {
        const source = values && typeof values === "object" ? values : {};
        const businessName = text(source.businessName || source.name);
        const services = list(source.services);
        const goal = text(source.primaryGoal || source.primaryAction || "quote").toLowerCase();
        return {
            businessName,
            businessType: text(source.businessType || "local-service"),
            services,
            serviceArea: list(source.serviceArea || source.location),
            contact: { phone: text(source.phone), email: text(source.email), address: text(source.address), hours: text(source.hours) },
            brand: { logoUrl: text(source.logoUrl), primaryColor: text(source.color || source.primaryColor), secondaryColor: text(source.secondaryColor), voice: text(source.brandVoice || source.contentTone) },
            goal: ["call", "booking", "form", "purchase", "visit", "quote"].includes(goal) ? goal : "quote",
            primaryCta: text(source.primaryCta || source.hook),
            existingWebsite: text(source.website || source.existingWebsite || source.scrapeUrl),
            socialLinks: list(source.socialLinks),
            appointment: { enabled: Boolean(source.booking || source.bookingUrl), url: text(source.booking || source.bookingUrl) },
            payments: { enabled: Boolean(source.paymentProvider || source.pos || source.acceptsPayments), provider: text(source.paymentProvider || source.pos) }
        };
    }

    function buildChecklist(status = {}) {
        return CHECKLIST.map(([key, label, category]) => ({ key, label, category, status: ["complete", "blocked", "in-progress"].includes(status[key]) ? status[key] : "pending" }));
    }

    function createPlan(values = {}, options = {}) {
        const details = collect(values);
        const pages = ["index.html", "about.html", "services.html", "contact.html"];
        if (details.goal === "booking") pages.push("booking.html");
        if (details.goal === "purchase") pages.push("shop.html");
        const now = new Date().toISOString();
        return {
            model: "SetupPlan",
            version: 1,
            id: text(options.id) || id("setup"),
            createdAt: now,
            updatedAt: now,
            business: details,
            profile: {
                businessName: details.businessName,
                phone: details.contact.phone,
                email: details.contact.email,
                services: details.services,
                locations: details.serviceArea,
                logoUrl: details.brand.logoUrl,
                color: details.brand.primaryColor,
                secondaryColor: details.brand.secondaryColor,
                brandVoice: details.brand.voice,
                integrations: { appointment: details.appointment, payments: details.payments }
            },
            project: { name: details.businessName || "New business website", pages, template: details.businessType, goal: details.goal },
            forms: [{ id: "primary-lead-form", type: "lead", purpose: details.goal === "call" ? "call-back request" : details.goal }],
            seo: { title: details.businessName, serviceArea: details.serviceArea, pages },
            analytics: { events: ["page_view", "lead_submitted", "phone_clicked", "booking_completed"].filter((event) => details.goal !== "purchase" || event !== "booking_completed") },
            launchChecklist: buildChecklist(options.checklist),
            nextActions: ["Complete and review the business brief", "Create the initial website draft", "Run the launch checklist"],
            providers: { pos: details.payments.provider, appointment: details.appointment.url, website: details.existingWebsite }
        };
    }

    function collectFromFields() {
        const fields = window.workspaceFields;
        return fields?.readBusiness ? fields.readBusiness() : {};
    }

    async function saveFromFields(options = {}) {
        const plan = createPlan(collectFromFields(), options);
        const state = window.workspaceAPI?.getState?.();
        if (state) {
            state.setupWizard = clone(plan);
            state.launchChecklist = clone(plan.launchChecklist);
            state.nextActions = clone(plan.nextActions);
        }
        let profileResult = null;
        if (window.profileService?.saveProfile && (plan.profile.businessName && (plan.profile.phone || plan.profile.email))) {
            try { profileResult = await window.profileService.saveProfile(plan.profile, { actor: options.actor || "setup-wizard" }); } catch (error) { profileResult = { persisted: "plan-only", error: error.message }; }
        }
        if (typeof window.dispatchEvent === "function") window.dispatchEvent(new CustomEvent("setup-wizard:created", { detail: { plan: clone(plan), profile: profileResult } }));
        return { plan, profile: profileResult };
    }

    function initialize() {
        if (window.__setupWizardInitialized) return;
        window.__setupWizardInitialized = true;
        document.getElementById("primary-create-website-btn")?.addEventListener("click", () => { saveFromFields().catch(() => {}); }, true);
    }

    window.setupWizard = Object.freeze({ CHECKLIST, collect, buildChecklist, createPlan, collectFromFields, saveFromFields, initialize });
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialize, { once: true });
    else initialize();
})();
