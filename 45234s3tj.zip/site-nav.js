"use strict";

// Single owner for the product navigation and the account control.
// Every page gets the same links in the same order, and exactly one
// profile menu, so navigation cannot drift between pages.
(() => {
    if (window.__siteNavInitialized) return;
    window.__siteNavInitialized = true;

    const PRODUCT_LINKS = Object.freeze({
        self: Object.freeze([
            ["home.html", "Home"], ["index.html", "Website maker"],
            ["ad-studio.html", "Ad studio"], ["leads.html", "Leads"],
            ["todo.html", "To Do"], ["business-profile.html", "Business profile"],
            ["audit.html", "Mobile audit"]
        ]),
        client: Object.freeze([
            ["home.html", "Home"], ["business-profile.html", "Clients"],
            ["index.html", "Website maker"], ["ad-studio.html", "Ad studio"],
            ["audit.html", "Mobile audit"], ["leads.html", "Leads"],
            ["todo.html", "To Do"], ["proposal.html", "Proposals"]
        ])
    });
    const MODE_LABELS = Object.freeze({
        self: Object.freeze({ "index.html": "My website", "ad-studio.html": "My ads", "audit.html": "My site audit", "leads.html": "My leads", "todo.html": "My tasks" }),
        client: Object.freeze({ "index.html": "Client websites", "ad-studio.html": "Client ads", "audit.html": "Client audits", "leads.html": "Client leads", "todo.html": "Client tasks", "business-profile.html": "Clients", "proposal.html": "Proposals" })
    });
    const MENU_LINKS = [
        ["account.html", "Profile and sign in"],
        ["business-profile.html", "Business profile"],
        ["index.html#advanced-workspace-tools", "Settings"]
    ];
    const PRIMARY_COUNT = 5;
    const AVATAR_KEY = "omniscript-profile-avatar";
    const PROFILE_KEY = "morrow-account-profile-v1";
    const MAX_AVATAR_BYTES = 2_000_000;

    const basename = (href) => String(href || "").split(/[?#]/)[0].split("/").pop().toLowerCase();

    const currentPage = () => {
        const file = basename(window.location.pathname);
        return file.includes(".") ? file : "home.html";
    };

    function readProfile() {
        let profile = {};
        try {
            const saved = JSON.parse(localStorage.getItem(PROFILE_KEY) || "{}");
            if (saved && typeof saved === "object" && !Array.isArray(saved)) profile = saved;
        } catch {
            // A corrupt profile must never break navigation.
        }
        let avatar = profile.avatar || "";
        if (!avatar) {
            try { avatar = localStorage.getItem(AVATAR_KEY) || ""; } catch { avatar = ""; }
        }
        const name = String(profile.displayName || profile.username || "").trim();
        return { name, avatar };
    }

    function applyIdentity(root = document) {
        const { name, avatar } = readProfile();
        const initial = (name || "Omniscript").slice(0, 1).toUpperCase();
        root.querySelectorAll(".profile-avatar").forEach((node) => {
            if (avatar) {
                const image = node.querySelector("img") || document.createElement("img");
                image.alt = "";
                image.src = avatar;
                node.replaceChildren(image);
            } else {
                node.textContent = initial;
            }
        });
        root.querySelectorAll("[data-profile-name]").forEach((node) => {
            node.textContent = name || "Account";
        });
        root.querySelectorAll(".profile-menu-toggle").forEach((toggle) => {
            toggle.setAttribute("aria-label", name ? `Account menu for ${name}` : "Account menu");
        });
    }

    function syncProductLinks(nav, page) {
        const container = nav.querySelector(".site-product-links");
        if (!container) return;

        const children = [...container.children];
        // Keep non-link controls (for example the home page language selector).
        const extras = children.filter((node) => !(node instanceof HTMLAnchorElement));
        const mode = window.operatingMode?.get?.() || document.documentElement.dataset.operatingMode || "self";
        const labels = MODE_LABELS[mode] || MODE_LABELS.self;
        const links = PRODUCT_LINKS[mode] || PRODUCT_LINKS.self;
        const showAll = window.operatingMode?.getShowAllTools?.() === true;
        const createAnchor = ([href, label]) => {
            const existing = children.find((node) => node instanceof HTMLAnchorElement && basename(node.getAttribute("href")) === href);
            const anchor = existing || document.createElement("a");
            anchor.setAttribute("href", href);
            anchor.textContent = labels[href] || label;
            if (basename(href) === page) anchor.setAttribute("aria-current", "page");
            else anchor.removeAttribute("aria-current");
            return anchor;
        };
        const primary = (showAll ? links : links.slice(0, PRIMARY_COUNT)).map(createAnchor);
        const secondary = showAll ? [] : links.slice(PRIMARY_COUNT).map(createAnchor);
        const more = document.createElement("details");
        more.className = "site-more-menu";
        if (secondary.some((link) => link.getAttribute("aria-current") === "page")) more.open = true;
        const summary = document.createElement("summary");
        summary.textContent = "More";
        summary.setAttribute("aria-label", "More tools");
        const panel = document.createElement("div");
        panel.className = "site-more-panel";
        panel.append(...secondary);
        more.append(summary, panel);
        container.replaceChildren(...extras, ...primary, ...(secondary.length ? [more] : []));

        // Account and business links live in the account menu only.
        nav.querySelectorAll(".site-utility-links").forEach((node) => node.remove());
    }

    function buildProfileMenu(nav, page) {
        nav.querySelectorAll(".profile-menu").forEach((node) => node.remove());

        const wrapper = document.createElement("div");
        wrapper.className = "profile-menu";

        const toggle = document.createElement("button");
        toggle.type = "button";
        toggle.id = "profile-menu-toggle";
        toggle.className = "profile-menu-toggle";
        toggle.setAttribute("aria-expanded", "false");
        toggle.setAttribute("aria-haspopup", "true");
        toggle.setAttribute("aria-controls", "profile-menu-panel");
        if (page === "account.html" || page === "business-profile.html") toggle.classList.add("is-current");
        toggle.innerHTML = '<span class="profile-avatar" aria-hidden="true">O</span>'
            + '<span class="profile-menu-name" data-profile-name>Account</span>'
            + '<span class="profile-menu-chevron" aria-hidden="true">▾</span>';

        const panel = document.createElement("div");
        panel.id = "profile-menu-panel";
        panel.className = "profile-menu-panel";
        panel.hidden = true;

        const heading = document.createElement("div");
        heading.className = "profile-menu-heading";
        heading.innerHTML = '<span class="profile-avatar" aria-hidden="true">O</span>'
            + '<span class="profile-menu-identity"><strong data-profile-name>Account</strong>'
            + "<small>Omniscript.ai workspace</small></span>";

        const upload = document.createElement("label");
        upload.className = "profile-upload";
        upload.setAttribute("for", "profile-picture-input");
        upload.textContent = "Change profile picture";

        const input = document.createElement("input");
        input.id = "profile-picture-input";
        input.type = "file";
        input.accept = "image/png,image/jpeg,image/webp";

        const note = document.createElement("p");
        note.className = "profile-menu-note";
        note.setAttribute("role", "status");
        note.setAttribute("aria-live", "polite");
        note.textContent = "JPG, PNG or WEBP · 2 MB max";

        panel.append(heading, upload, input, note);
        MENU_LINKS.forEach(([href, label]) => {
            const link = document.createElement("a");
            link.href = href;
            link.textContent = label;
            if (basename(href) === page) link.setAttribute("aria-current", "page");
            panel.append(link);
        });

        wrapper.append(toggle, panel);
        nav.append(wrapper);
        return { wrapper, toggle, panel, input, note };
    }

    function bindProfileMenu({ toggle, panel, input, note }) {
        const setOpen = (open) => {
            toggle.setAttribute("aria-expanded", String(open));
            panel.hidden = !open;
        };

        toggle.addEventListener("click", (event) => {
            event.stopPropagation();
            setOpen(toggle.getAttribute("aria-expanded") !== "true");
        });

        document.addEventListener("click", (event) => {
            if (!event.target.closest(".profile-menu")) setOpen(false);
        });

        document.addEventListener("keydown", (event) => {
            if (event.key !== "Escape" || panel.hidden) return;
            setOpen(false);
            toggle.focus();
        });

        input.addEventListener("change", () => {
            const file = input.files?.[0];
            input.value = "";
            if (!file) return;
            if (!["image/png", "image/jpeg", "image/webp"].includes(file.type.toLowerCase())) {
                note.textContent = "Choose a JPG, PNG, or WEBP image.";
                note.dataset.state = "error";
                return;
            }
            if (file.size > MAX_AVATAR_BYTES) {
                note.textContent = "That image is larger than 2 MB. Choose a smaller file.";
                note.dataset.state = "error";
                return;
            }
            const reader = new FileReader();
            reader.onload = () => {
                const avatar = String(reader.result || "");
                let stored = false;
                try {
                    localStorage.setItem(AVATAR_KEY, avatar);
                    const saved = JSON.parse(localStorage.getItem(PROFILE_KEY) || "{}");
                    const profile = saved && typeof saved === "object" && !Array.isArray(saved) ? saved : {};
                    localStorage.setItem(PROFILE_KEY, JSON.stringify({ ...profile, avatar }));
                    stored = true;
                } catch {
                    // Storage can be full or blocked; the picture still applies for this view.
                }
                applyIdentity();
                note.textContent = stored ? "Profile picture updated." : "Picture applied for this session only; browser storage is unavailable.";
                note.dataset.state = stored ? "" : "error";
                window.dispatchEvent(new CustomEvent("omniscript:profile-updated", { detail: { ...readProfile() } }));
            };
            reader.onerror = () => {
                note.textContent = "That image could not be read.";
                note.dataset.state = "error";
            };
            reader.readAsDataURL(file);
        });
    }

    function initialize() {
        if (!document.querySelector('link[href="styles/operating-mode.css"]')) {
            const modeStyles = document.createElement("link");
            modeStyles.rel = "stylesheet";
            modeStyles.href = "styles/operating-mode.css";
            document.head.append(modeStyles);
        }
        if (!window.operatingMode && !document.querySelector('script[src="operating-mode.js"]')) {
            const modeScript = document.createElement("script");
            modeScript.src = "operating-mode.js";
            document.head.append(modeScript);
        }
        const navs = [...document.querySelectorAll(".site-product-nav")];
        if (!navs.length) return;
        const page = currentPage();

        navs.forEach((nav, index) => {
            syncProductLinks(nav, page);
            // Only the first navigation owns the menu IDs.
            if (index > 0) {
                nav.querySelectorAll(".profile-menu").forEach((node) => node.remove());
                return;
            }
            bindProfileMenu(buildProfileMenu(nav, page));
        });

        applyIdentity();
        document.addEventListener("operating-mode:changed", () => navs.forEach((nav) => syncProductLinks(nav, page)));
        window.addEventListener("omniscript:operating-mode", () => navs.forEach((nav) => syncProductLinks(nav, page)));
        window.addEventListener("omniscript:operating-mode-ready", () => navs.forEach((nav) => syncProductLinks(nav, page)));
        window.addEventListener("omniscript:profile-updated", () => applyIdentity());
        window.addEventListener("storage", (event) => {
            if (!event.key || [AVATAR_KEY, PROFILE_KEY].includes(event.key)) applyIdentity();
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initialize, { once: true });
    } else {
        initialize();
    }
})();
