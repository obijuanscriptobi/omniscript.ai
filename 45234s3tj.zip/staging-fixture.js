"use strict";

// Runs the smallest end-to-end staging fixture. Runtime integrations are
// injected so this harness can be used with real Supabase/provider adapters or
// deterministic test doubles without silently claiming external execution.

function requireStep(name, value, predicate = (result) => result && result.success !== false) {
    if (!predicate(value)) throw new Error(`STAGING_FIXTURE_FAILED:${name}`);
    return value;
}

function method(api, name) {
    if (typeof api?.[name] !== "function") throw new Error(`STAGING_FIXTURE_MISSING_ADAPTER:${name}`);
    return api[name];
}

async function run(options = {}) {
    const api = options.api || {};
    const steps = [];
    const execute = async (name, operation, predicate) => {
        const result = requireStep(name, await operation(), predicate);
        steps.push({ name, success: true, id: result.id || result.revisionId || null });
        return result;
    };

    const lead = await execute("create-lead", () => method(api, "createLead")(options.lead), (result) => result?.success !== false && Boolean(result?.id));
    const audit = await execute("create-audit", () => method(api, "createAudit")({ lead, url: options.websiteUrl }), (result) => result?.success !== false && Boolean(result?.id));
    const context = await execute("generator-context", () => method(api, "openGenerator")({ lead, audit }), (result) => result?.success !== false && Boolean(result?.auditId || result?.audit || result?.id));
    const draft = await execute("create-draft-revision", () => method(api, "createDraftRevision")({ context }), (result) => result?.success !== false && Boolean(result?.id || result?.revisionId));
    const approval = await execute("approve-safe-change", () => method(api, "approveChange")({ revision: draft, change: options.safeChange }), (result) => result?.success !== false);
    const rejection = await execute("reject-review-change", () => method(api, "rejectChange")({ revision: draft, change: options.reviewChange }), (result) => result?.success !== false);
    const applied = await execute("apply-approved-change", () => method(api, "applyApprovedChanges")({ revision: draft, approval }), (result) => result?.success !== false && result?.validation);
    const conflict = await execute("stale-before-conflict", () => method(api, "applyApprovedChanges")({ revision: draft, approval, before: options.staleBefore, expectConflict: true }), (result) => result?.conflict === true || result?.code === "STALE_REVISION" || result?.status === 409);
    const visual = await execute("visual-audit", () => method(api, "runVisualWorkflow")({ audit, revision: applied, baselineUrl: options.baselineUrl, proposedUrl: options.proposedUrl }), (result) => result?.status === "complete" && result?.baseline && result?.proposed && result?.comparison);
    const persistedVisual = await execute("persist-visual-report", () => method(api, "persistVisualReport")({ audit, revision: applied, report: visual }), (result) => result?.websiteAudit?.visual && result?.siteRevision?.beforeScores && result?.siteRevision?.afterScores && result?.siteRevision?.screenshots);
    const deployment = await execute("deploy-revision", () => method(api, "deploy")({ revision: applied, revisionId: applied.revisionId || applied.id, projectId: options.projectId }), (result) => result?.success !== false && Boolean(result?.deploymentId || result?.id));
    const linked = await execute("verify-deployment-link", () => method(api, "verifyDeploymentLink")({ deployment, revision: applied, projectId: options.projectId }), (result) => result?.deploymentId && result?.revisionStatus === "deployed" && result?.environment?.publicUrl && result?.environment?.currentRevision);
    const conversion = await execute("conversion-event", () => method(api, "trackConversion")({
        projectId: options.projectId,
        deploymentId: linked.deploymentId,
        revisionId: applied.revisionId || applied.id,
        experimentId: options.experimentId,
        eventName: options.eventName || "booking_completed",
        anonymousId: options.anonymousId || "staging-fixture-anonymous",
        occurredAt: options.occurredAt || new Date().toISOString()
    }), (result) => result?.success !== false);
    const experiment = await execute("experiment-report", () => method(api, "experimentReport")({ projectId: options.projectId, experimentId: options.experimentId }), (result) => result?.status === "insufficient-data" && result?.winner == null);

    return {
        success: true,
        steps,
        evidence: {
            leadId: lead.id,
            auditId: audit.id,
            revisionId: applied.revisionId || applied.id,
            deploymentId: linked.deploymentId,
            conversionId: conversion.id || null,
            experimentStatus: experiment.status,
            visual: persistedVisual
        }
    };
}

module.exports = { run };
