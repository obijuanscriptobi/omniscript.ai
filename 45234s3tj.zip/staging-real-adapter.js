"use strict";

// Opt-in staging adapter. It talks to deployed HTTP adapters and Supabase only
// when explicitly configured; it never falls back to fake success responses.
const fs = require("node:fs/promises");
const path = require("node:path");
const { runWorkflow } = require("./visual-audit-workflow.js");

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const cleanId = (value, name) => {
    const result = String(value || "");
    if (!UUID.test(result)) throw new Error(`STAGING_CONFIG_INVALID:${name}`);
    return result;
};
const required = (value, name) => {
    if (!String(value || "").trim()) throw new Error(`STAGING_CONFIG_MISSING:${name}`);
    return String(value).trim().replace(/\/$/, "");
};

function createHttp(options = {}) {
    const fetchImpl = options.fetch || globalThis.fetch;
    if (typeof fetchImpl !== "function") throw new Error("STAGING_CONFIG_MISSING:fetch");
    return async (url, request = {}) => {
        const response = await fetchImpl(url, { ...request, headers: { Accept: "application/json", ...(request.headers || {}) } });
        const text = await response.text();
        let data = {};
        try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
        if (!response.ok) {
            const error = new Error(data.error || data.message || `HTTP ${response.status}`);
            error.status = response.status;
            error.data = data;
            throw error;
        }
        return data;
    };
}

function createStorage(options = {}) {
    const env = options.env || process.env;
    const supabaseUrl = required(options.supabaseUrl || env.SUPABASE_URL, "SUPABASE_URL");
    const serviceKey = required(options.serviceKey || env.SUPABASE_SERVICE_ROLE_KEY, "SUPABASE_SERVICE_ROLE_KEY");
    const bucket = required(options.bucket || env.STAGING_ARTIFACT_BUCKET, "STAGING_ARTIFACT_BUCKET");
    const http = createHttp(options);
    const base = `${supabaseUrl}/storage/v1/object/${encodeURIComponent(bucket)}`;
    const publicBase = `${supabaseUrl}/storage/v1/object/public/${encodeURIComponent(bucket)}`;
    return {
        async upload(filePath, objectPath, contentType = "application/octet-stream") {
            const body = await fs.readFile(filePath);
            await http(`${base}/${objectPath.split("/").map(encodeURIComponent).join("/")}`, {
                method: "POST",
                headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "Content-Type": contentType, "x-upsert": "true" },
                body
            });
            if (String(env.STAGING_ARTIFACT_PUBLIC || "true") === "true") return `${publicBase}/${objectPath.split("/").map(encodeURIComponent).join("/")}`;
            const signed = await http(`${supabaseUrl}/storage/v1/object/sign/${encodeURIComponent(bucket)}/${objectPath.split("/").map(encodeURIComponent).join("/")}`, {
                method: "POST", headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ expiresIn: Number(env.STAGING_ARTIFACT_TTL || 3600) })
            });
            return signed.signedURL || signed.signedUrl || `${publicBase}/${objectPath}`;
        }
    };
}

function createAdapter(options = {}) {
    const env = options.env || process.env;
    const http = createHttp(options);
    const apiBase = required(options.apiBase || env.STAGING_API_BASE, "STAGING_API_BASE");
    const token = required(options.accessToken || env.STAGING_ACCESS_TOKEN, "STAGING_ACCESS_TOKEN");
    const auth = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
    const request = (route, body, method = "POST") => http(`${apiBase}${route}`, { method, headers: auth, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const unwrap = (result, key) => result?.[key] || result;
    const storage = options.storage || createStorage(options);
    const routes = {
        lead: env.STAGING_LEAD_ROUTE || "/api/leads",
        audit: env.STAGING_AUDIT_ROUTE || "/api/audit",
        generator: env.STAGING_GENERATOR_ROUTE || "/api/generator/context",
        revision: env.STAGING_REVISION_ROUTE || "/api/revisions",
        editorApply: env.STAGING_EDITOR_APPLY_ROUTE || "/api/editor/revisions/apply",
        previewRefresh: env.STAGING_PREVIEW_REFRESH_ROUTE || "/api/preview/refresh",
        validation: env.STAGING_VALIDATION_ROUTE || "/api/editor/revisions/validate",
        visualReport: env.STAGING_VISUAL_REPORT_ROUTE || "/api/visual-reports",
        deployment: env.STAGING_DEPLOY_ROUTE || "/api/deploy",
        deploymentVerify: env.STAGING_DEPLOYMENT_VERIFY_ROUTE || "/api/deployments/verify",
        analytics: env.STAGING_ANALYTICS_ROUTE || "/api/analytics",
        experimentReport: env.STAGING_EXPERIMENT_REPORT_ROUTE || "/api/analytics/report",
        inspect: env.STAGING_INSPECT_ROUTE || "/api/staging/verify"
    };
    const stateApi = required(options.stateApi || env.STAGING_EDITOR_API, "STAGING_EDITOR_API");
    const previewApi = required(options.previewApi || env.STAGING_PREVIEW_API, "STAGING_PREVIEW_API");
    const providerApi = required(options.providerApi || env.STAGING_DEPLOY_API, "STAGING_DEPLOY_API");

    return {
        async createLead(lead = {}) { return unwrap(await request(routes.lead, { ...lead, projectId: cleanId(lead.projectId || env.STAGING_PROJECT_ID, "STAGING_PROJECT_ID") }), "lead"); },
        async createAudit({ lead, url }) { return unwrap(await request(routes.audit, { leadId: cleanId(lead?.id, "lead.id"), url, email: lead?.email || env.STAGING_AUDIT_EMAIL }), "audit"); },
        async openGenerator({ lead, audit }) { return unwrap(await request(routes.generator, { leadId: lead.id, auditId: audit.id }), "context"); },
        async createDraftRevision({ context }) { return unwrap(await request(routes.revision, { projectId: cleanId(context.projectId || env.STAGING_PROJECT_ID, "projectId"), leadId: context.leadId, auditId: context.auditId, status: "draft", changes: context.changes || [] }), "revision"); },
        async approveChange({ revision, change }) { return request(`${routes.revision}/${cleanId(revision.id || revision.revisionId, "revision.id")}/approve`, { change }); },
        async rejectChange({ revision, change }) { return request(`${routes.revision}/${cleanId(revision.id || revision.revisionId, "revision.id")}/reject`, { change }); },
        async applyApprovedChanges({ revision, approval, before, expectConflict }) {
            const result = await request(routes.editorApply, { revisionId: revision.id || revision.revisionId, approval, before, expectConflict });
            if (!expectConflict) {
                await request(routes.previewRefresh, { revisionId: revision.id || revision.revisionId }, "POST");
                await request(routes.validation, { revisionId: revision.id || revision.revisionId }, "POST");
            }
            return result;
        },
        async runVisualWorkflow(input) {
            const report = await runWorkflow({ ...input, outputDir: options.outputDir || env.STAGING_ARTIFACT_DIR, uploadArtifact: async (filePath, metadata) => storage.upload(filePath, `visual-audits/${input.audit.id}/${metadata.phase}/${path.basename(filePath)}`, "image/png") });
            return report;
        },
        async persistVisualReport({ audit, revision, report }) { return request(routes.visualReport, { auditId: audit.id, revisionId: revision.id || revision.revisionId, report }); },
        async deploy({ revisionId, revision, projectId }) { return request(routes.deployment || providerApi.replace(apiBase, ""), { projectId, revisionId: revisionId || revision?.id, revision, environment: "staging" }); },
        async verifyDeploymentLink({ deployment, revision, projectId }) { return request(routes.deploymentVerify, { deploymentId: deployment.deploymentId || deployment.id, revisionId: revision.id || revision.revisionId, projectId }); },
        async trackConversion(event) { return request(routes.analytics, { ...event, consent: true }); },
        async experimentReport({ projectId, experimentId }) { return request(routes.experimentReport, { projectId, experimentId }); },
        async inspectRecords({ projectId, auditId, revisionId, deploymentId }) {
            const query = new URLSearchParams({ projectId, auditId, revisionId, deploymentId });
            return request(`${routes.inspect}?${query}`, undefined, "GET");
        },
        editorApi: stateApi,
        previewApi,
        providerApi,
        storage
    };
}

async function run(options = {}) {
    const { run: fixture } = require("./staging-fixture.js");
    const api = options.api || createAdapter(options);
    const result = await fixture({ ...options, api });
    if (options.inspectRecords !== false && typeof api.inspectRecords === "function") result.database = await api.inspectRecords({ ...result.evidence, projectId: options.projectId, experimentId: options.experimentId });
    return result;
}

module.exports = { createHttp, createStorage, createAdapter, run };

if (require.main === module) {
    run({
        baselineUrl: process.env.STAGING_BASELINE_URL,
        proposedUrl: process.env.STAGING_PROPOSED_URL,
        projectId: process.env.STAGING_PROJECT_ID,
        experimentId: process.env.STAGING_EXPERIMENT_ID,
        lead: { projectId: process.env.STAGING_PROJECT_ID, email: process.env.STAGING_AUDIT_EMAIL, name: "Staging fixture" }
    }).then((result) => process.stdout.write(`${JSON.stringify(result, null, 2)}\n`)).catch((error) => { console.error(error.message || error); process.exitCode = 1; });
}
