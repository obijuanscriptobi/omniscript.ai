"use strict";

const crypto = require("node:crypto");

function enabled(env = process.env) {
    return String(env.CODEWISE_STAGING_WORKFLOW || "").toLowerCase() === "true";
}

function requireEnabled(env = process.env) {
    if (!enabled(env)) throw new Error("STAGING_WORKFLOW_DISABLED");
}

function assertResult(step, result) {
    if (!result || result.success === false || result.ok === false) {
        throw new Error(`STAGING_STEP_FAILED:${step}`);
    }
    return result;
}

async function run(options = {}) {
    const env = options.env || process.env;
    requireEnabled(env);
    const api = options.api || {};
    const files = options.files && typeof options.files === "object" ? options.files : {};
    const steps = [];
    const execute = async (name, operation) => {
        const result = assertResult(name, await operation());
        steps.push({ name, success: true, id: result.id || result.revision || null });
        return result;
    };

    const draft = await execute("draft", () => api.draft(files));
    const revision = await execute("persist-revision", () => api.persistRevision({ files, draft }));
    await execute("restore-and-compare", () => api.restoreAndCompare({ revision }));
    await execute("approval", () => api.approve({ revision }));
    const signature = crypto.createHash("sha256").update(JSON.stringify({ revision, files })).digest("hex");
    await execute("signed-preflight", () => api.preflight({ revision, files, signature }));
    const firstDeployment = await execute("deploy-revision-1", () => api.deploy({ revision, files }));
    await execute("poll-and-verify-1", () => api.pollAndVerify({ deployment: firstDeployment, revision }));
    const revisionTwoFiles = { ...files, "staging-workflow.txt": "revision-2" };
    const secondRevision = await execute("persist-revision-2", () => api.persistRevision({ files: revisionTwoFiles, draft }));
    const secondDeployment = await execute("deploy-revision-2", () => api.deploy({ revision: secondRevision, files: revisionTwoFiles }));
    await execute("poll-and-verify-2", () => api.pollAndVerify({ deployment: secondDeployment, revision: secondRevision }));
    await execute("rollback", () => api.rollback({ deployment: firstDeployment, revision }));
    await execute("cleanup", () => api.cleanup({ revisions: [revision, secondRevision], deployments: [firstDeployment, secondDeployment] }));

    return { success: true, steps };
}

module.exports = { enabled, requireEnabled, run };
