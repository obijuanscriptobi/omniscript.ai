"use strict";

(function () {
    const SESSION_KEY = "supabase_session";
    const CONFIG_TIMEOUT_MS = 10_000;
    const API_TIMEOUT_MS = 15_000;
    const PROJECT_NAME_MAX_LENGTH = 200;

    const state = {
        config: null,
        accessToken: null,
        refreshToken: null,
        user: null,
        currentProjectId: null,
        authGeneration: 0,
        initialized: false,
        configPromise: null
    };

    function element(tag, attributes = {}, text = "") {
        const node = document.createElement(tag);

        Object.entries(attributes).forEach(([key, value]) => {
            if (value === false || value === null || value === undefined) {
                return;
            }

            if (key === "hidden") {
                node.hidden = Boolean(value);
                return;
            }

            node.setAttribute(key, String(value));
        });

        if (text) node.textContent = text;
        return node;
    }

    function authStatus(message, error = false) {
        const status = document.getElementById("supabase-auth-status");

        if (status) {
            status.textContent = message;
            status.style.color = error ? "#f87171" : "";
            status.setAttribute("aria-invalid", String(error));
        }

        if (error) {
            const projectStatus = document.getElementById("project-status");

            if (projectStatus) {
                projectStatus.textContent = message;
                projectStatus.style.color = "#f87171";
                projectStatus.setAttribute("aria-invalid", "true");
            }
        }
    }

    function projectStatus(message, error = false) {
        const status = document.getElementById("project-status");

        if (!status) return;

        status.textContent = message;
        status.style.color = error ? "#f87171" : "";
        status.setAttribute("aria-invalid", String(error));
    }

    function removeConflictPanel() {
        document.getElementById("project-conflict-panel")?.remove();
    }

    function showProjectConflict(error) {
        const project = error?.project;
        const panel = document.getElementById("project-conflict-panel") || element("section", {
            id: "project-conflict-panel",
            class: "input-card-group",
            role: "alert",
            "aria-labelledby": "project-conflict-title"
        });

        panel.replaceChildren(
            element("h3", { id: "project-conflict-title", class: "field-label-tag" }, "Cloud changes detected"),
            element("p", { class: "field-descriptor-text" }, "This project was changed elsewhere after you opened it. Your local edits are preserved; choose how to continue."),
            element("div", { class: "sidebar-action-matrix" })
        );

        const actions = panel.lastElementChild;
        const reload = element("button", { type: "button", class: "matrix-action-btn variant-outline-row" }, "Reload cloud version");
        const overwrite = element("button", { type: "button", class: "matrix-action-btn variant-danger-text" }, "Overwrite cloud version");
        actions.append(reload, overwrite);

        reload.addEventListener("click", async () => {
            reload.disabled = true;
            overwrite.disabled = true;
            try {
                await loadProject(state.currentProjectId);
                removeConflictPanel();
                projectStatus("Reloaded the latest cloud version. Local edits were replaced.");
            } catch (nextError) {
                projectStatus(nextError.message || "The latest cloud version could not be loaded.", true);
                reload.disabled = false;
                overwrite.disabled = false;
            }
        });

        overwrite.addEventListener("click", async () => {
            overwrite.disabled = true;
            reload.disabled = true;
            try {
                await saveProject({
                    id: state.currentProjectId,
                    expectedRevision: project?.updated_at || null
                });
                removeConflictPanel();
                projectStatus("Local edits replaced the latest cloud version.");
            } catch (nextError) {
                projectStatus(nextError.message || "The cloud version could not be replaced.", true);
                reload.disabled = false;
                overwrite.disabled = false;
            }
        });

        const host = document.querySelector(".control-sidebar-node") || document.body;
        if (!panel.isConnected) host.prepend(panel);
        projectStatus("Cloud conflict detected. Choose reload or overwrite.", true);
    }

    function addAuthPanel() {
        const sidebar = document.querySelector(".control-sidebar-node");

        if (!sidebar || document.getElementById("supabase-auth-panel")) {
            return;
        }

        const panel = element("section", {
            id: "supabase-auth-panel",
            class: "input-card-group panel-accent-glow",
            "aria-labelledby": "supabase-auth-title"
        });

        panel.append(
            element(
                "h3",
                {
                    id: "supabase-auth-title",
                    class: "field-label-tag"
                },
                "Account and Cloud Projects"
            ),
            element("input", {
                id: "supabase-email",
                class: "matrix-text-field",
                type: "email",
                placeholder: "Email address",
                autocomplete: "email",
                inputmode: "email"
            }),
            element("input", {
                id: "supabase-password",
                class: "matrix-text-field",
                type: "password",
                placeholder: "Password",
                autocomplete: "current-password"
            })
        );

        const actions = element("div", {
            class: "sidebar-action-matrix"
        });

        actions.append(
            element(
                "button",
                {
                    id: "supabase-google",
                    class: "matrix-action-btn variant-outline-row",
                    type: "button"
                },
                "Continue with Google"
            ),
            element(
                "button",
                {
                    id: "supabase-apple",
                    class: "matrix-action-btn variant-outline-row",
                    type: "button"
                },
                "Continue with Apple"
            ),
            element(
                "button",
                {
                    id: "supabase-signup",
                    class: "matrix-action-btn variant-outline-row",
                    type: "button"
                },
                "Create Account"
            ),
            element(
                "button",
                {
                    id: "supabase-login",
                    class: "matrix-action-btn variant-gold-fill",
                    type: "button"
                },
                "Sign In"
            ),
            element(
                "button",
                {
                    id: "supabase-logout",
                    class: "matrix-action-btn variant-danger-text",
                    type: "button",
                    hidden: true
                },
                "Sign Out"
            )
        );

        panel.append(
            actions,
            element(
                "p",
                {
                    id: "supabase-auth-status",
                    class: "field-descriptor-text",
                    role: "status",
                    "aria-live": "polite",
                    "aria-atomic": "true"
                },
                "Cloud projects are available after signing in."
            )
        );

        sidebar.prepend(panel);

        document
            .getElementById("supabase-google")
            ?.addEventListener("click", () => signInWithProvider("google"));

        document
            .getElementById("supabase-apple")
            ?.addEventListener("click", () => signInWithProvider("apple"));

        document
            .getElementById("supabase-signup")
            ?.addEventListener("click", signUp);

        document
            .getElementById("supabase-login")
            ?.addEventListener("click", signIn);

        document
            .getElementById("supabase-logout")
            ?.addEventListener("click", signOut);

        updateAuthButtons();
    }

    function validateConfig(url, key) {
        let parsed;

        try {
            parsed = new URL(String(url).trim());
        } catch {
            throw new Error("The Supabase URL is invalid.");
        }

        const hostname = parsed.hostname.toLowerCase();

        if (
            parsed.protocol !== "https:" ||
            parsed.username ||
            parsed.password ||
            parsed.port ||
            !hostname.endsWith(".supabase.co") ||
            hostname === "supabase.co"
        ) {
            throw new Error(
                "The Supabase URL must be a valid HTTPS Supabase URL."
            );
        }

        const publishableKey = String(key || "").trim();

        if (!publishableKey || publishableKey.length > 10_000) {
            throw new Error("The Supabase publishable key is invalid.");
        }

        return {
            url: parsed.origin.replace(/\/+$/, ""),
            key: publishableKey
        };
    }

    function getRuntimeConfig() {
        const runtime = window.__SUPABASE_CONFIG__;

        if (runtime?.url && runtime?.key) {
            return validateConfig(runtime.url, runtime.key);
        }

        const metaUrl = document
            .querySelector('meta[name="supabase-url"]')
            ?.getAttribute("content");

        const metaKey = document
            .querySelector('meta[name="supabase-anon-key"]')
            ?.getAttribute("content");

        if (metaUrl && metaKey) {
            return validateConfig(metaUrl, metaKey);
        }

        return null;
    }

    async function fetchWithTimeout(url, options = {}, timeoutMs = CONFIG_TIMEOUT_MS) {
        const controller = new AbortController();
        const externalSignal = options.signal;
        const abort = () => controller.abort(externalSignal?.reason);
        if (externalSignal) {
            if (externalSignal.aborted) abort();
            else externalSignal.addEventListener("abort", abort, { once: true });
        }
        const timeout = setTimeout(
            () => controller.abort(),
            timeoutMs
        );

        try {
            return await fetch(url, {
                ...options,
                signal: controller.signal
            });
        } catch (error) {
            if (error?.name === "AbortError") {
                throw new Error(
                    `The Supabase request timed out after ${Math.round(timeoutMs / 1000)} seconds.`
                );
            }

            throw new Error(
                "The Supabase configuration endpoint could not be reached."
            );
        } finally {
            clearTimeout(timeout);
            externalSignal?.removeEventListener("abort", abort);
        }
    }

    async function loadConfig() {
        if (state.config) return state.config;
        if (state.configPromise) return state.configPromise;

        state.configPromise = (async () => {
            const runtimeConfig = getRuntimeConfig();

            if (runtimeConfig) {
                state.config = runtimeConfig;
                return state.config;
            }

            const response = await fetchWithTimeout("/api/config", {
                method: "GET",
                headers: {
                    Accept: "application/json"
                },
                cache: "no-store"
            });

            const contentType = response.headers.get("content-type") || "";
            const data = contentType.includes("json")
                ? await response.json().catch(() => ({}))
                : {};

            if (!response.ok) {
                if (response.status === 404) {
                    throw new Error(
                        "The /api/config endpoint is unavailable. Check the Netlify function deployment and redirect configuration."
                    );
                }

                throw new Error(
                    data.error ||
                        `Supabase configuration request failed with status ${response.status}.`
                );
            }

            if (!data.success || !data.url || !data.key) {
                throw new Error(
                    data.error ||
                        "Supabase configuration is incomplete. Verify SUPABASE_URL and SUPABASE_ANON_KEY in the deployed environment."
                );
            }

            state.config = validateConfig(data.url, data.key);
            return state.config;
        })();

        try {
            return await state.configPromise;
        } finally {
            state.configPromise = null;
        }
    }

    // Keep the short-lived client session in sessionStorage so a normal reload
    // can restore cloud access without keeping credentials across browser tabs.
    // The service-role key is never handled here; only the user's auth tokens
    // are stored, and the server still validates the bearer token on every API call.
    function saveSession() {
        if (!state.accessToken || !state.user) {
            clearSession();
            return;
        }

        try {
            sessionStorage.setItem(SESSION_KEY, JSON.stringify({
                access_token: state.accessToken,
                refresh_token: state.refreshToken,
                user: state.user
            }));
        } catch {
            // Cloud access remains available for the current page if storage is blocked.
        }
    }

    function clearSession() {
        try {
            sessionStorage.removeItem(SESSION_KEY);
        } catch {}
    }

    function clearAuthState() {
        state.authGeneration += 1;
        state.accessToken = null;
        state.refreshToken = null;
        state.user = null;
        state.currentProjectId = null;

        clearSession();
        window.workspaceFixes?.clearProjectId?.();
        window.workspaceAPI?.clearProjectContext?.({ persist: true, announce: true });
        window.workspaceAPI?.setProjectId(null);
        updateSelector([]);
        updateVersionSelector([]);
        updateAuthButtons();
    }

    function setSession(session) {
        if (!session?.access_token || !session?.user) {
            throw new Error("Invalid authentication session.");
        }

        state.authGeneration += 1;
        state.accessToken = String(session.access_token);
        state.refreshToken = session.refresh_token
            ? String(session.refresh_token)
            : null;
        state.user = session.user;

        // Persist only the short-lived browser session in sessionStorage so a
        // normal reload can restore cloud access. The service-role key is never
        // present here; server functions still validate the bearer token.
        saveSession();

        updateAuthButtons();

        window.dispatchEvent(
            new CustomEvent("supabase:authenticated", {
                detail: { user: state.user }
            })
        );
    }

    async function refreshSession() {
        if (!state.config || !state.refreshToken) return false;

        const refreshToken = state.refreshToken;
        const data = await authRequest(
            "token?grant_type=refresh_token",
            {
                method: "POST",
                body: JSON.stringify({
                    refresh_token: refreshToken
                })
            },
            false
        );

        setSession(data);
        return true;
    }

    function authHeaders(includeAuthorization = true) {
        if (!state.config) {
            throw new Error("Supabase configuration is unavailable.");
        }

        const headers = {
            apikey: state.config.key,
            "Content-Type": "application/json"
        };

        if (includeAuthorization) {
            headers.Authorization = `Bearer ${
                state.accessToken || state.config.key
            }`;
        }

        return headers;
    }

    async function authRequest(path, options = {}, retry = true) {
        if (!state.config) {
            throw new Error("Supabase configuration is unavailable.");
        }

        const isTokenRequest = path.startsWith("token?");
        const response = await fetchWithTimeout(
            `${state.config.url}/auth/v1/${path}`,
            {
                ...options,
                headers: {
                    ...(options.headers || {}),
                    // Keep the Supabase project key and bearer token controlled
                    // by the authenticated client state.
                    ...authHeaders(!isTokenRequest)
                }
            },
            API_TIMEOUT_MS
        );

        const data = await response.json().catch(() => ({}));

        if (
            response.status === 401 &&
            retry &&
            state.refreshToken &&
            !isTokenRequest
        ) {
            try {
                if (await refreshSession()) {
                    return authRequest(path, options, false);
                }
            } catch {
                clearAuthState();
            }
        }

        if (!response.ok) {
            throw new Error(
                data.error_description ||
                    data.msg ||
                    data.message ||
                    data.error ||
                    "Authentication request failed."
            );
        }

        return data;
    }

    function getCredentials() {
        return {
            email:
                document
                    .getElementById("supabase-email")
                    ?.value.trim() || "",
            password:
                document.getElementById("supabase-password")?.value || ""
        };
    }

    function validateCredentials(email, password) {
        if (!email || !password) {
            throw new Error("Enter an email address and password.");
        }

        if (
            !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(email)
        ) {
            throw new Error("Enter a valid email address.");
        }

        if (password.length < 6) {
            throw new Error("Password must contain at least 6 characters.");
        }
    }

    async function signInWithProvider(provider) {
        const supported = ["google", "apple", "github", "facebook"];
        if (!supported.includes(provider)) return;
        try {
            await loadConfig();
            const redirectTo = `${window.location.origin}${window.location.pathname}`;
            const url = new URL(`${state.config.url}/auth/v1/authorize`);
            url.searchParams.set("provider", provider);
            url.searchParams.set("redirect_to", redirectTo);
            window.location.assign(url.href);
        } catch (error) {
            authStatus(error.message || "Social sign-in is unavailable.", true);
        }
    }

    async function signUp() {
        const { email, password } = getCredentials();

        try {
            validateCredentials(email, password);

            const data = await authRequest("signup", {
                method: "POST",
                body: JSON.stringify({ email, password })
            });

            if (data.access_token && data.user) {
                setSession(data);
                authStatus(`Signed in as ${state.user.email}.`);
                await loadProjects();
            } else {
                authStatus("Account created. Check your email to confirm it.");
            }
        } catch (error) {
            authStatus(error.message || "Account creation failed.", true);
        }
    }

    async function signIn() {
        const { email, password } = getCredentials();

        try {
            validateCredentials(email, password);

            const data = await authRequest("token?grant_type=password", {
                method: "POST",
                body: JSON.stringify({ email, password })
            });

            setSession(data);
            authStatus(`Signed in as ${state.user.email}.`);
            await loadProjects();
        } catch (error) {
            authStatus(error.message || "Sign-in failed.", true);
        }
    }

    async function signOut() {
        try {
            if (state.accessToken) {
                await authRequest(
                    "logout",
                    { method: "POST" },
                    false
                );
            }
        } catch {}

        clearAuthState();

        window.dispatchEvent(
            new CustomEvent("supabase:unauthenticated")
        );

        authStatus("Signed out.");
    }

    function updateAuthButtons() {
        const signedIn = Boolean(state.accessToken && state.user);

        ["supabase-google", "supabase-apple", "supabase-signup", "supabase-login"]
            .forEach((id) => document.getElementById(id)?.toggleAttribute("hidden", signedIn));

        document
            .getElementById("supabase-login")
            ?.toggleAttribute("hidden", signedIn);

        document
            .getElementById("supabase-logout")
            ?.toggleAttribute("hidden", !signedIn);

        updateProjectControls();

        if (signedIn) {
            authStatus(`Signed in as ${state.user.email}.`);
        }
    }

    function requireAuth() {
        if (!state.accessToken || !state.user) {
            throw new Error("Please sign in first.");
        }
    }

    async function projectRequest(
        method,
        id = "",
        body,
        retry = true,
        extraQuery = "",
        requestOptions = {}
    ) {
        requireAuth();
        const requestGeneration = state.authGeneration;

        const activeContextId = window.workspaceContext?.current?.()?.cloudId || "";
        const contextQuery = activeContextId ? `&workContextId=${encodeURIComponent(activeContextId)}` : "";
        const query = id
            ? `?id=${encodeURIComponent(id)}${contextQuery}${extraQuery}`
            : (extraQuery ? `?${String(extraQuery).replace(/^\?/, "")}` : (activeContextId ? `?workContextId=${encodeURIComponent(activeContextId)}` : ""));
        const options = {
            method,
            headers: {
                Accept: "application/json",
                Authorization: `Bearer ${state.accessToken}`
            }
        };

        if (body !== undefined) {
            options.headers["Content-Type"] = "application/json";
            options.body = JSON.stringify(body);
        }

        let response;
        try {
            response = await fetchWithTimeout(`/api/projects${query}`, {
                ...options,
                credentials: "same-origin",
                signal: requestOptions.signal
            }, API_TIMEOUT_MS);
        } catch (error) {
            throw new Error(error?.message || "The project service could not be reached.");
        }
        const data = await response.json().catch(() => ({}));

        if (requestGeneration !== state.authGeneration) {
            throw new Error("The account changed while the project request was in progress.");
        }

        if (
            response.status === 401 &&
            retry &&
            state.refreshToken
        ) {
            try {
                if (await refreshSession()) {
                    return projectRequest(method, id, body, false, extraQuery, requestOptions);
                }
            } catch {
                clearAuthState();
            }
        }

        if (!response.ok) {
            const error = new Error(
                data.code === "PROJECT_CONFLICT"
                    ? "Cloud conflict: the project was changed elsewhere."
                    : data.error || "Project request failed."
            );

            error.status = response.status;
            error.code = data.code;
            error.project = data.project;
            throw error;
        }

        return data;
    }

    function getWorkspace() {
        return (
            window.workspaceAPI?.getState?.() || {
                files: {},
                form: {},
                previewMode: "desktop",
                projectName: "",
                projectId: null
            }
        );
    }

    function cloudPreviewMode(mode) {
        return ["desktop", "tablet", "mobile"].includes(mode)
            ? mode
            : "desktop";
    }

    function currentRevision() {
        return (
            getWorkspace().revision ||
            window.workspaceFixes?.readRevision?.() ||
            null
        );
    }

    function projectPayload(nameOverride, expectedRevisionOverride) {
        const workspace = getWorkspace();
        const expectedRevision =
            expectedRevisionOverride === undefined
                ? currentRevision()
                : expectedRevisionOverride;

        const requestedName =
            nameOverride || workspace.projectName || "Untitled project";

        const payload = {
            name: String(requestedName)
                .trim()
                .slice(0, PROJECT_NAME_MAX_LENGTH) || "Untitled project",
            files: workspace.files || {},
            formData: workspace.form || {},
            previewMode: cloudPreviewMode(workspace.previewMode),
            workContextId: window.workspaceContext?.current?.()?.cloudId || null
        };

        if (expectedRevision) {
            payload.expectedRevision = expectedRevision;
        }

        return payload;
    }

    function rememberProjectRevision(project) {
        const revision = project?.updated_at || project?.revision || null;

        if (revision) {
            window.workspaceFixes?.persistRevision?.(revision, false);
        }

        return revision;
    }

    function updateProjectControls() {
        const selector = document.getElementById("project-selector");
        const hasSelection = Boolean(state.currentProjectId && selector?.value === state.currentProjectId);
        const signedIn = Boolean(state.accessToken && state.user);

        ["load-project-btn", "rename-project-btn", "delete-project-btn"].forEach((id) => {
            const button = document.getElementById(id);
            if (!button) return;
            button.disabled = !signedIn || !hasSelection;
            button.setAttribute("aria-disabled", String(button.disabled));
        });
    }

    function persistCurrentProjectId() {
        window.workspaceFixes?.persistProjectId?.(state.currentProjectId, false);
        window.workspaceAPI?.setProjectId(state.currentProjectId);
    }

    function setCurrentProjectId(id, options = {}) {
        state.currentProjectId = id || null;
        persistCurrentProjectId();

        const selector = document.getElementById("project-selector");
        if (selector && selector.value !== (state.currentProjectId || "")) {
            selector.value = state.currentProjectId || "";
        }

        updateProjectControls();

        if (options.refreshVersions !== false) {
            refreshVersions(state.currentProjectId).catch(() => {
                updateVersionSelector([]);
            });
        }

        return state.currentProjectId;
    }

    function updateSelector(projects = []) {
        const selector = document.getElementById("project-selector");

        if (!selector) return;

        const validProjects = Array.isArray(projects)
            ? projects.filter((project) => project?.id)
            : [];
        const selectedProjectStillExists = validProjects.some(
            (project) => project.id === state.currentProjectId
        );

        if (!selectedProjectStillExists && state.currentProjectId) {
            state.currentProjectId = null;
            window.workspaceFixes?.clearProjectId?.();
            window.workspaceAPI?.clearProjectContext?.({
                persist: true,
                announce: true
            });
        }

        selector.replaceChildren(
            new Option("Select a saved project", ""),
            ...validProjects.map(
                (project) =>
                    new Option(
                        `${project.name || "Untitled project"} — ${new Date(
                            project.updated_at || Date.now()
                        ).toLocaleDateString()}`,
                        project.id
                    )
            )
        );

        selector.value = state.currentProjectId || "";
        persistCurrentProjectId();
        updateProjectControls();
    }

    function bindProjectSelectionSync() {
        const selector = document.getElementById("project-selector");
        if (!selector || selector.dataset.projectSyncBound === "true") return;

        selector.dataset.projectSyncBound = "true";
        selector.addEventListener("change", () => {
            const projectId = selector.value || null;
            setCurrentProjectId(projectId, { refreshVersions: Boolean(projectId) });

            if (!projectId) {
                updateVersionSelector([]);
                projectStatus("No cloud project selected.");
            }
        });
    }

    async function saveProject(options = {}) {
        const id = options.id || state.currentProjectId;
        const workspace = getWorkspace();
        const name = options.name || workspace.projectName;
        const expectedRevision =
            options.expectedRevision === undefined
                ? currentRevision()
                : options.expectedRevision;

        let result;

        try {
            result = await projectRequest(
                id ? "PATCH" : "POST",
                id,
                projectPayload(name, id ? expectedRevision : null)
            );
        } catch (error) {
            if (error?.code === "PROJECT_CONFLICT" && id) {
                showProjectConflict(error);
            }
            throw error;
        }

        const project = result.project;

        if (!project?.id) {
            throw new Error("The saved project did not return an ID.");
        }

        setCurrentProjectId(project.id, { refreshVersions: false });
        window.workspaceAPI?.setProjectName(project.name || name);
        rememberProjectRevision(project);
        await loadProjects();
        await refreshVersions(project.id);
        projectStatus("Cloud project saved.");

        return result;
    }

    async function loadProjects(options = {}) {
        await window.workspaceContext?.syncCloud?.();
        const result = await projectRequest("GET");

        if (options.populateSelector !== false) {
            updateSelector(result.projects || []);
        }

        return result;
    }

    function updateVersionSelector(versions = []) {
        const selector = document.getElementById("project-version-selector");
        const restoreButton = document.getElementById("restore-version-btn");

        if (!selector) return;

        const validVersions = Array.isArray(versions)
            ? versions.filter((version) => version?.id)
            : [];

        selector.replaceChildren(
            new Option(
                validVersions.length ? "Select a version to restore" : "No versions available",
                ""
            ),
            ...validVersions.map((version) => {
                const date = version.created_at
                    ? new Date(version.created_at).toLocaleString()
                    : "Unknown date";
                return new Option(`Version — ${date}`, version.id);
            })
        );

        const disabled = !state.currentProjectId || validVersions.length === 0;
        selector.disabled = disabled;
        selector.setAttribute("aria-disabled", String(disabled));

        if (restoreButton) {
            restoreButton.disabled = disabled || !selector.value;
            restoreButton.setAttribute("aria-disabled", String(restoreButton.disabled));
        }
    }

    async function refreshVersions(id = state.currentProjectId) {
        if (!id) {
            updateVersionSelector([]);
            return [];
        }

        const versions = await loadVersions(id);
        updateVersionSelector(versions);
        return versions;
    }

    function bindVersionControls() {
        const selector = document.getElementById("project-version-selector");
        const restoreButton = document.getElementById("restore-version-btn");

        if (selector && selector.dataset.versionControlsBound !== "true") {
            selector.dataset.versionControlsBound = "true";
            selector.addEventListener("change", () => {
                if (!restoreButton) return;
                restoreButton.disabled = !state.currentProjectId || !selector.value;
                restoreButton.setAttribute("aria-disabled", String(restoreButton.disabled));
            });
        }

        if (restoreButton && restoreButton.dataset.versionControlsBound !== "true") {
            restoreButton.dataset.versionControlsBound = "true";
            restoreButton.addEventListener("click", async () => {
                if (!selector?.value) return;

                restoreButton.disabled = true;
                restoreButton.setAttribute("aria-disabled", "true");

                try {
                    await restoreVersion(selector.value);
                } catch (error) {
                    projectStatus(error.message || "Version restoration failed.", true);
                } finally {
                    refreshVersions().catch(() => updateVersionSelector([]));
                }
            });
        }
    }

    async function loadProject(id) {
        if (!id) {
            throw new Error("A project ID is required.");
        }

        const result = await projectRequest("GET", id);
        const project = result.project;

        if (!project) {
            throw new Error("Project data was not returned.");
        }

        setCurrentProjectId(project.id, { refreshVersions: false });
        window.workspaceAPI?.setProjectName(project.name || "");
        rememberProjectRevision(project);

        if (window.workspaceAPI?.applySnapshot) {
            window.workspaceAPI.applySnapshot({
                files: project.files || {},
                form: project.form_data || {},
                projectName: project.name || "",
                projectId: project.id,
                previewMode: project.preview_mode || "desktop"
            }, { dirty: false, replaceContext: true });
        }

        await refreshVersions(project.id);
        projectStatus(`Loaded cloud project: ${project.name || "Untitled project"}.`);

        return result;
    }

    async function renameProject(id, name) {
        if (!id) {
            throw new Error("A project ID is required.");
        }

        const nextName = String(name || "")
            .trim()
            .slice(0, PROJECT_NAME_MAX_LENGTH);

        if (!nextName) {
            throw new Error("Project name cannot be empty.");
        }

        let result;

        try {
            result = await projectRequest(
                "PATCH",
                id,
                {
                    name: nextName,
                    ...(currentRevision() ? { expectedRevision: currentRevision() } : {})
                }
            );
        } catch (error) {
            if (error?.code === "PROJECT_CONFLICT") {
                showProjectConflict(error);
            }
            throw error;
        }

        setCurrentProjectId(result.project?.id || id, { refreshVersions: false });
        window.workspaceAPI?.setProjectName(nextName);
        rememberProjectRevision(result.project);
        await loadProjects();

        projectStatus(`Project renamed to ${nextName}.`);
        return result;
    }

    async function deleteProject(id) {
        if (!id) {
            throw new Error("A project ID is required.");
        }

        const result = await projectRequest("DELETE", id);

        if (state.currentProjectId === id) {
            window.workspaceAPI?.clearProjectContext?.({ persist: true, announce: true });
            window.workspaceFixes?.clearProjectId?.();
            setCurrentProjectId(null, { refreshVersions: false });
            updateVersionSelector([]);
        }

        await loadProjects();
        projectStatus("Cloud project deleted.");

        return result;
    }

    async function loadVersions(id = state.currentProjectId) {
        if (!id) throw new Error("A project ID is required.");
        const result = await projectRequest("GET", id);
        return Array.isArray(result.versions) ? result.versions : [];
    }

    async function restoreVersion(versionId) {
        if (!state.currentProjectId) {
            throw new Error("Select a cloud project first.");
        }
        if (!versionId) {
            throw new Error("Select a version to restore.");
        }

        const result = await projectRequest(
            "GET",
            state.currentProjectId,
            undefined,
            true,
            `&version=${encodeURIComponent(versionId)}`
        );
        const version = result.version;

        if (!version?.files || !window.workspaceAPI?.applySnapshot) {
            throw new Error("The selected version is incomplete.");
        }

        window.workspaceAPI.applySnapshot({
            files: version.files,
            form: version.form_data || {},
            projectName: getWorkspace().projectName,
            projectId: state.currentProjectId,
            previewMode: version.preview_mode || "desktop"
        }, { dirty: true });
        projectStatus("Version restored locally. Save the project to make it current in the cloud.");
        return version;
    }

    async function restoreOAuthSession() {
        const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
        const accessToken = hash.get("access_token");
        const refreshToken = hash.get("refresh_token");
        if (!accessToken) return false;
        try {
            const response = await fetch(`${state.config.url}/auth/v1/user`, { headers: { apikey: state.config.key, Authorization: `Bearer ${accessToken}` } });
            const user = await response.json();
            if (!response.ok || !user?.id) throw new Error("Social sign-in could not be completed.");
            setSession({ access_token: accessToken, refresh_token: refreshToken, user });
            history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
            await loadProjects();
            return true;
        } catch (error) {
            authStatus(error.message || "Social sign-in could not be completed.", true);
            return false;
        }
    }

    async function restoreSavedSession() {
        let saved;

        try {
            saved = JSON.parse(sessionStorage.getItem(SESSION_KEY) || "null");
        } catch {
            clearSession();
            return false;
        }

        if (!saved?.access_token || !saved?.user?.id) {
            return false;
        }

        state.accessToken = String(saved.access_token);
        state.refreshToken = saved.refresh_token ? String(saved.refresh_token) : null;
        state.user = saved.user;
        updateAuthButtons();

        try {
            await authRequest("user", { method: "GET" }, false);
            window.dispatchEvent(new CustomEvent("supabase:authenticated", {
                detail: { user: state.user }
            }));
            await loadProjects();
            return true;
        } catch {
            if (state.refreshToken) {
                try {
                    await refreshSession();
                    await loadProjects();
                    return true;
                } catch {
                    // Fall through and require a fresh sign-in.
                }
            }
            clearAuthState();
            return false;
        }
    }

    async function init() {
        if (state.initialized) return;

        state.initialized = true;
        state.currentProjectId =
            window.workspaceFixes?.readProjectId?.() ||
            window.workspaceAPI?.getState?.()?.projectId ||
            null;
        addAuthPanel();
        bindProjectSelectionSync();
        bindVersionControls();
        updateVersionSelector([]);
        updateAuthButtons();

        try {
            await loadConfig();
            if (!(await restoreOAuthSession())) await restoreSavedSession();
        } catch (error) {
            authStatus(
                error.message ||
                    "Cloud storage is unavailable. Local workspace features remain available.",
                true
            );
            updateAuthButtons();
        }
    }

    window.addEventListener("workspace:project-id-change", (event) => {
        if (event.detail?.projectId === state.currentProjectId) return;

        window.workspaceAPI?.clearProjectContext?.({ persist: false, announce: true });
        setCurrentProjectId(event.detail?.projectId || null, {
            refreshVersions: Boolean(event.detail?.projectId)
        });
    });

    async function updatePreferences(changes = {}) {
        requireAuth();
        const current = state.user?.user_metadata?.workspace_preferences || {};
        const workspacePreferences = { ...current, ...changes, updatedAt: new Date().toISOString() };
        const data = await authRequest("user", {
            method: "PUT",
            body: JSON.stringify({ data: { ...(state.user?.user_metadata || {}), workspace_preferences: workspacePreferences } })
        });
        if (data?.id) {
            state.user = data;
            saveSession();
        }
        window.dispatchEvent(new CustomEvent("supabase:preferences-updated", { detail: workspacePreferences }));
        return workspacePreferences;
    }

    function getPreferences() {
        const value = state.user?.user_metadata?.workspace_preferences;
        return value && typeof value === "object" ? { ...value } : {};
    }

    window.supabaseWorkspace = {
        saveProject,
        loadProjects,
        loadProject,
        renameProject,
        deleteProject,
        restoreVersion,
        loadVersions,
        signIn,
        signUp,
        signOut,
        signInWithProvider,
        updatePreferences,
        getPreferences,
        getAccessToken: () => state.accessToken,
        getState: () => ({
            configured: Boolean(state.config),
            authenticated: Boolean(state.accessToken && state.user),
            user: state.user,
            projectId: state.currentProjectId,
            accessToken: state.accessToken
        })
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();