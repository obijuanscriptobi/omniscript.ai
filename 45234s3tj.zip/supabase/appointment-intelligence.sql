-- Appointment-to-outcome workflow. Run after supabase/multi-tenant-milestone.sql.
alter table public.appointments
    add column if not exists client_business text not null default '',
    add column if not exists client_phone text not null default '',
    add column if not exists appointment_context text not null default 'work',
    add column if not exists appointment_type text not null default 'discovery',
    add column if not exists objective text not null default '',
    add column if not exists duration_minutes integer not null default 45,
    add column if not exists meeting_mode text not null default 'video',
    add column if not exists timezone text not null default 'UTC',
    add column if not exists preparation jsonb not null default '{}'::jsonb,
    add column if not exists outcome text not null default '',
    add column if not exists outcome_notes text not null default '',
    add column if not exists next_action text not null default '',
    add column if not exists next_action_at timestamptz,
    add column if not exists reschedule_history jsonb not null default '[]'::jsonb,
    add column if not exists reminder_plan jsonb not null default '{}'::jsonb,
    add column if not exists timeline jsonb not null default '[]'::jsonb;

alter table public.appointments drop constraint if exists appointments_type_check;
alter table public.appointments add constraint appointments_type_check check (appointment_type in ('discovery','audit_review','proposal_review','client_approval','kickoff','revision_review','launch_handoff','follow_up','personal_planning','health','family','finance','errand','social','personal_follow_up'));
alter table public.appointments drop constraint if exists appointments_context_check;
alter table public.appointments add constraint appointments_context_check check (appointment_context in ('work','personal'));
alter table public.appointments drop constraint if exists appointments_context_type_check;
alter table public.appointments add constraint appointments_context_type_check check (
    (appointment_context = 'work' and appointment_type in ('discovery','audit_review','proposal_review','client_approval','kickoff','revision_review','launch_handoff','follow_up')) or
    (appointment_context = 'personal' and appointment_type in ('personal_planning','health','family','finance','errand','social','personal_follow_up'))
);
alter table public.appointments drop constraint if exists appointments_outcome_check;
alter table public.appointments add constraint appointments_outcome_check check (outcome in ('','qualified','follow_up','proposal_requested','won','lost','no_show','rescheduled','personal_completed','personal_follow_up'));
alter table public.appointments drop constraint if exists appointments_mode_check;
alter table public.appointments add constraint appointments_mode_check check (meeting_mode in ('video','phone','in_person'));
alter table public.appointments drop constraint if exists appointments_duration_check;
alter table public.appointments add constraint appointments_duration_check check (duration_minutes between 15 and 240);
alter table public.appointments drop constraint if exists appointments_workflow_size_check;
alter table public.appointments add constraint appointments_workflow_size_check check (
    char_length(client_business) <= 200 and char_length(client_phone) <= 80 and
    char_length(objective) <= 500 and char_length(outcome_notes) <= 1200 and
    char_length(next_action) <= 300 and pg_column_size(preparation) <= 12000 and
    pg_column_size(reschedule_history) <= 40000 and pg_column_size(reminder_plan) <= 12000 and
    pg_column_size(timeline) <= 80000
);

create index if not exists appointments_project_type_outcome_idx
on public.appointments(project_id, appointment_type, outcome, meeting_at desc);
