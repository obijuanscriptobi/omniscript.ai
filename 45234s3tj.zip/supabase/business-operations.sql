create table if not exists public.business_operations (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    kind text not null check (kind in ('project','proposal','catalog','invoice','file','approval','activity','notification')),
    payload jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint business_operations_payload_size_check check (pg_column_size(payload) <= 100000)
);

create index if not exists business_operations_user_project_idx on public.business_operations(user_id, project_id, updated_at desc);
create index if not exists business_operations_kind_idx on public.business_operations(user_id, kind, updated_at desc);
alter table public.business_operations enable row level security;
drop policy if exists business_operations_owner_access on public.business_operations;
create policy business_operations_owner_access on public.business_operations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.touch_business_operations_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists business_operations_updated_at on public.business_operations;
create trigger business_operations_updated_at before update on public.business_operations for each row execute function public.touch_business_operations_updated_at();
