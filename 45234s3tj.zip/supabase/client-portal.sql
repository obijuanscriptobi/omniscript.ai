-- Explicit, revocable project sharing for the client portal.
create extension if not exists pgcrypto;

create table if not exists public.client_portal_shares (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    created_by uuid not null references auth.users(id) on delete cascade,
    token_hash text not null unique,
    label text not null default 'Client portal',
    expires_at timestamptz not null default (now() + interval '30 days'),
    revoked_at timestamptz,
    created_at timestamptz not null default now(),
    last_accessed_at timestamptz,
    constraint client_portal_share_label_check check (char_length(label) <= 120)
);

create table if not exists public.client_portal_comments (
    id uuid primary key default gen_random_uuid(),
    share_id uuid not null references public.client_portal_shares(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    author_name text not null default 'Client',
    comment text not null,
    created_at timestamptz not null default now(),
    constraint client_portal_comment_size_check check (pg_column_size(author_name) <= 500 and pg_column_size(comment) <= 4000)
);

create index if not exists client_portal_shares_project_idx on public.client_portal_shares(project_id, created_at desc);
create index if not exists client_portal_comments_share_idx on public.client_portal_comments(share_id, created_at asc);

-- Serialize inserts per share so concurrent requests cannot exceed the cap.
create or replace function public.create_client_portal_comment(
    p_share_id uuid,
    p_project_id uuid,
    p_author_name text,
    p_comment text,
    p_max_comments integer default 100
)
returns setof public.client_portal_comments
language plpgsql
security definer
set search_path = public, pg_catalog
as $$
declare
    active_share public.client_portal_shares%rowtype;
begin
    if p_max_comments < 1 or p_max_comments > 100 then
        raise exception 'PORTAL_COMMENT_LIMIT' using errcode = '22023';
    end if;
    select * into active_share
    from public.client_portal_shares
    where id = p_share_id and project_id = p_project_id
      and revoked_at is null and expires_at > now()
    for update;
    if not found or not exists (
        select 1 from public.projects p
        join public.work_contexts c on c.id = p.work_context_id and c.organization_id = p.organization_id
        where p.id = p_project_id and c.status = 'active'
    ) then raise exception 'PORTAL_UNAVAILABLE' using errcode = '42501'; end if;
    if (select count(*) from public.client_portal_comments where share_id = p_share_id) >= p_max_comments then
        raise exception 'PORTAL_COMMENT_LIMIT' using errcode = '23514';
    end if;
    return query insert into public.client_portal_comments(share_id, project_id, author_name, comment)
        values (p_share_id, p_project_id, left(coalesce(nullif(trim(p_author_name), ''), 'Client'), 500), left(p_comment, 4000))
        returning *;
end;
$$;
revoke all on function public.create_client_portal_comment(uuid,uuid,text,text,integer) from public;
grant execute on function public.create_client_portal_comment(uuid,uuid,text,text,integer) to service_role;
alter table public.client_portal_shares enable row level security;
alter table public.client_portal_comments enable row level security;

drop policy if exists client_portal_shares_owner_access on public.client_portal_shares;
drop policy if exists client_portal_comments_owner_access on public.client_portal_comments;
create policy client_portal_shares_owner_access on public.client_portal_shares for all using (auth.uid() = created_by) with check (auth.uid() = created_by);
create policy client_portal_comments_owner_access on public.client_portal_comments for select using (exists (select 1 from public.client_portal_shares s where s.id = share_id and s.created_by = auth.uid()));
