create extension if not exists pgcrypto;

create table if not exists public.project_memberships (
    project_id uuid not null references public.projects(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    role text not null check (role in ('owner','admin','sales','marketing','contributor','client_reviewer')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (project_id, user_id)
);

create table if not exists public.project_membership_invitations (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    invited_by uuid not null references auth.users(id) on delete cascade,
    email text not null,
    role text not null check (role in ('admin','sales','marketing','contributor','client_reviewer')),
    token_hash text not null unique,
    status text not null default 'pending' check (status in ('pending','accepted','revoked','expired')),
    expires_at timestamptz not null,
    created_at timestamptz not null default now()
);
create index if not exists project_membership_invitations_project_idx on public.project_membership_invitations(project_id, created_at desc);

create table if not exists public.project_file_versions (
    id uuid primary key default gen_random_uuid(), project_id uuid not null references public.projects(id) on delete cascade,
    file_id uuid not null,
    version integer not null check (version > 0),
    storage_path text not null,
    file_name text not null,
    mime_type text not null,
    byte_size bigint not null check (byte_size > 0 and byte_size <= 52428800),
    client_visible boolean not null default false,
    uploaded_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(),
    unique (file_id, version)
);
create index if not exists project_file_versions_project_idx on public.project_file_versions(project_id, created_at desc);

create table if not exists public.project_approval_history (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    approval_id uuid references public.client_approvals(id) on delete cascade,
    status text not null check (status in ('draft','sent_for_review','changes_requested','approved','published')),
    revision text not null,
    reviewer_id uuid references auth.users(id) on delete set null,
    reviewer_name text not null default '',
    comment text not null default '',
    created_at timestamptz not null default now(),
    constraint project_approval_history_status_check check (status in ('draft','sent_for_review','changes_requested','approved','published'))
);
alter table public.project_approval_history drop constraint if exists project_approval_history_status_check;
alter table public.project_approval_history add constraint project_approval_history_status_check check (status in ('draft','sent_for_review','changes_requested','approved','published'));
create index if not exists project_approval_history_project_idx on public.project_approval_history(project_id, created_at desc);

alter table public.project_memberships enable row level security;
alter table public.project_membership_invitations enable row level security;
alter table public.project_file_versions enable row level security;
alter table public.project_approval_history enable row level security;

drop policy if exists project_memberships_owner_access on public.project_memberships;
drop policy if exists project_membership_invitations_manager_access on public.project_membership_invitations;
drop policy if exists project_file_versions_member_access on public.project_file_versions;
drop policy if exists project_approval_history_member_access on public.project_approval_history;

create policy project_memberships_owner_access on public.project_memberships for all using (exists (select 1 from public.projects p where p.id = project_memberships.project_id and p.user_id = auth.uid())) with check (exists (select 1 from public.projects p where p.id = project_memberships.project_id and p.user_id = auth.uid()));
create policy project_membership_invitations_manager_access on public.project_membership_invitations for all using (exists (select 1 from public.project_memberships m where m.project_id = project_membership_invitations.project_id and m.user_id = auth.uid() and m.role in ('owner','admin'))) with check (exists (select 1 from public.project_memberships m where m.project_id = project_membership_invitations.project_id and m.user_id = auth.uid() and m.role in ('owner','admin')));
create policy project_file_versions_member_access on public.project_file_versions for select
using (exists (select 1 from public.project_memberships m where m.project_id = project_file_versions.project_id and m.user_id = auth.uid()));
create policy project_approval_history_member_access on public.project_approval_history for select
using (exists (select 1 from public.project_memberships m where m.project_id = project_approval_history.project_id and m.user_id = auth.uid()));

-- Run once after applying this migration to seed existing project owners.
insert into public.project_memberships (project_id, user_id, role)
select id, user_id, 'owner' from public.projects
on conflict (project_id, user_id) do nothing;

-- Create this private bucket in Supabase Storage if it does not already exist.
insert into storage.buckets (id, name, public)
values ('project-files', 'project-files', false)
on conflict (id) do update set public = false;

-- Storage remains private. API-issued signed URLs are the only supported file path.
drop policy if exists project_files_member_read on storage.objects;
drop policy if exists project_files_member_insert on storage.objects;
drop policy if exists project_files_member_delete on storage.objects;
create policy project_files_member_read on storage.objects for select
using (
    bucket_id = 'project-files'
    and exists (
        select 1 from public.project_memberships m
        where m.project_id::text = split_part(name, '/', 1)
          and m.user_id = auth.uid()
    )
);
create policy project_files_member_insert on storage.objects for insert
with check (
    bucket_id = 'project-files'
    and exists (
        select 1 from public.project_memberships m
        where m.project_id::text = split_part(name, '/', 1)
          and m.user_id = auth.uid()
          and m.role in ('owner', 'admin', 'contributor')
    )
);
create policy project_files_member_delete on storage.objects for delete
using (
    bucket_id = 'project-files'
    and exists (
        select 1 from public.project_memberships m
        where m.project_id::text = split_part(name, '/', 1)
          and m.user_id = auth.uid()
          and m.role in ('owner', 'admin', 'contributor')
    )
);
