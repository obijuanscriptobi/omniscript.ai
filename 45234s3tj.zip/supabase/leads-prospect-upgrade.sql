-- Apply after the original schema.sql for existing projects.
-- This keeps prospect-engine records in the existing leads table while adding
-- the complete sales pipeline used by the leads page.
alter table public.leads
drop constraint if exists leads_status_check;

alter table public.leads
add constraint leads_status_check
check (status in ('new', 'verified', 'contacted', 'replied', 'qualified', 'won', 'lost'));

create index if not exists leads_project_status_updated_idx
on public.leads(project_id, status, updated_at desc);

create index if not exists leads_project_source_idx
on public.leads(project_id, source, created_at desc);
