-- Revision-scoped lifecycle and release evidence. Apply after schema.sql.
alter table public.projects add column if not exists lifecycle text not null default 'draft';
alter table public.projects add column if not exists revision text not null default '';
alter table public.projects add column if not exists approval_revision text;
alter table public.projects add column if not exists preflight_revision text;
alter table public.projects add column if not exists published_revision text;
alter table public.projects add column if not exists verified_revision text;
alter table public.projects drop constraint if exists projects_lifecycle_check;
alter table public.projects add constraint projects_lifecycle_check check (lifecycle in ('brief','draft','reviewed','approved','preflight-passed','published','verified'));

create or replace function public.enforce_project_lifecycle()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if tg_op = 'INSERT' or new.files is distinct from old.files or new.form_data is distinct from old.form_data then
        new.revision := encode(digest(convert_to(new.files::text || '|' || new.form_data::text, 'utf8'), 'sha256'), 'hex');
        if tg_op = 'INSERT' or old.lifecycle in ('approved','preflight-passed','published','verified') then
            new.lifecycle := 'draft';
            new.approval_revision := null;
            new.preflight_revision := null;
            new.published_revision := null;
            new.verified_revision := null;
        end if;
    end if;
    if tg_op = 'UPDATE' and (new.files is distinct from old.files or new.form_data is distinct from old.form_data) and old.lifecycle in ('approved','preflight-passed','published','verified') then
        new.lifecycle := 'draft';
        new.approval_revision := null;
        new.preflight_revision := null;
        new.verified_revision := null;
    end if;
    if new.lifecycle = 'preflight-passed' and new.preflight_revision is distinct from new.revision then raise exception 'PREFLIGHT_REVISION_MISMATCH'; end if;
    if new.lifecycle = 'published' and (new.preflight_revision is distinct from new.revision or new.approval_revision is distinct from new.revision) then raise exception 'PUBLISH_GATE_BLOCKED'; end if;
    if new.lifecycle = 'verified' and new.verified_revision is distinct from new.revision then raise exception 'VERIFICATION_REVISION_MISMATCH'; end if;
    return new;
end;
$$;
drop trigger if exists projects_lifecycle_guard on public.projects;
create trigger projects_lifecycle_guard
before insert or update on public.projects
for each row
execute function public.enforce_project_lifecycle();
