-- Maturity storage additions. Run after supabase/schema.sql.
create table if not exists public.preview_snapshots (
    token_hash text primary key,
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    revision text not null default '',
    files jsonb not null default '{}'::jsonb,
    expires_at timestamptz not null,
    revoked_at timestamptz,
    created_at timestamptz not null default now(),
    constraint preview_token_hash_check check (token_hash ~ '^[a-f0-9]{64}$'),
    constraint preview_files_size_check check (pg_column_size(files) <= 5000000)
);
-- Upgrade installations that previously stored raw preview tokens. Existing
-- links remain usable after their values are irreversibly hashed.
alter table public.preview_snapshots add column if not exists token_hash text;
alter table public.preview_snapshots add column if not exists revoked_at timestamptz;
do $$
begin
    if exists (
        select 1 from information_schema.columns
        where table_schema = 'public' and table_name = 'preview_snapshots' and column_name = 'token'
    ) then
        execute 'update public.preview_snapshots set token_hash = encode(digest(token, ''sha256''), ''hex'') where token_hash is null and token is not null';
    end if;
end $$;
alter table public.preview_snapshots alter column token_hash set not null;
alter table public.preview_snapshots alter column project_id set not null;
alter table public.preview_snapshots drop constraint if exists preview_token_hash_check;
alter table public.preview_snapshots add constraint preview_token_hash_check check (token_hash ~ '^[a-f0-9]{64}$');
create unique index if not exists preview_snapshots_token_hash_idx on public.preview_snapshots(token_hash);
alter table public.preview_snapshots drop column if exists token;
create index if not exists preview_snapshots_expiry_idx on public.preview_snapshots(expires_at);
alter table public.preview_snapshots enable row level security;
drop policy if exists "Owners can manage preview snapshots" on public.preview_snapshots;
create policy "Owners can manage preview snapshots" on public.preview_snapshots for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.lead_delivery_failures (
    id uuid primary key default gen_random_uuid(),
    project_id uuid references public.projects(id) on delete set null,
    user_id uuid references auth.users(id) on delete set null,
    submission_id text not null,
    payload jsonb not null default '{}'::jsonb,
    attempts integer not null default 0,
    status text not null default 'pending',
    next_attempt_at timestamptz not null default now(),
    last_error text not null default '',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint lead_delivery_status_check check (status in ('pending','delivered','dead-letter')),
    constraint lead_delivery_payload_size_check check (pg_column_size(payload) <= 25000)
);
create unique index if not exists lead_delivery_submission_idx on public.lead_delivery_failures(submission_id);
create index if not exists lead_delivery_retry_idx on public.lead_delivery_failures(status, next_attempt_at);
create or replace function public.claim_lead_delivery_failures(batch_size integer default 25)
returns setof public.lead_delivery_failures
language sql security definer set search_path = public
as $$
    update public.lead_delivery_failures
       set attempts = attempts + 1,
           updated_at = now(),
           status = case when attempts + 1 >= 8 then 'dead-letter' else 'pending' end,
           next_attempt_at = now() + make_interval(secs => least(3600, greatest(30, (attempts + 1) * (attempts + 1) * 30)))
     where id in (
        select id from public.lead_delivery_failures
         where status = 'pending' and next_attempt_at <= now()
         order by next_attempt_at asc
         limit greatest(1, least(batch_size, 100))
         for update skip locked
     )
     returning *;
$$;
alter table public.lead_delivery_failures enable row level security;
drop policy if exists "Users can view their delivery failures" on public.lead_delivery_failures;
create policy "Users can view their delivery failures" on public.lead_delivery_failures for select using (auth.uid() = user_id);

create table if not exists public.translation_drafts (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid references public.projects(id) on delete cascade,
    source_locale text not null,
    target_locale text not null,
    source_revision text not null default '',
    content jsonb not null default '{}'::jsonb,
    status text not null default 'in-review',
    reviewer_note text not null default '',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint translation_status_check check (status in ('draft','in-review','approved','rejected')),
    constraint translation_content_size_check check (pg_column_size(content) <= 500000)
);
create index if not exists translation_drafts_project_idx on public.translation_drafts(project_id, target_locale, updated_at desc);
alter table public.translation_drafts enable row level security;
drop policy if exists "Users can manage translation drafts" on public.translation_drafts;
create policy "Users can manage translation drafts" on public.translation_drafts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
