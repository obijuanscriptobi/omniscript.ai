-- Authenticated workspace milestone. Run after supabase/schema.sql.
create table if not exists public.organizations (
    id uuid primary key default gen_random_uuid(),
    name text not null default 'My workspace',
    slug text unique,
    created_by uuid not null references auth.users(id) on delete cascade,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.organization_members (
    organization_id uuid not null references public.organizations(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    role text not null default 'owner' check (role in ('owner','admin','member','viewer')),
    created_at timestamptz not null default now(),
    primary key (organization_id, user_id)
);

alter table public.projects add column if not exists organization_id uuid references public.organizations(id) on delete cascade;
alter table public.business_profiles add column if not exists organization_id uuid references public.organizations(id) on delete cascade;
alter table public.business_profiles add column if not exists project_id uuid references public.projects(id) on delete cascade;
alter table public.leads add column if not exists organization_id uuid references public.organizations(id) on delete cascade;
alter table public.leads add column if not exists source_url text not null default '';
alter table public.leads add column if not exists landing_page text not null default '';
alter table public.leads add column if not exists campaign_params jsonb not null default '{}'::jsonb;
alter table public.leads add column if not exists assigned_to uuid references auth.users(id) on delete set null;

-- Backfill one private organization per existing owner before new records use tenant scope.
insert into public.organizations (name, created_by)
select 'My workspace', p.user_id from public.projects p
where not exists (select 1 from public.organization_members m where m.user_id = p.user_id);
insert into public.organization_members (organization_id, user_id, role)
select o.id, o.created_by, 'owner' from public.organizations o
where not exists (select 1 from public.organization_members m where m.organization_id = o.id and m.user_id = o.created_by);
update public.projects p set organization_id = m.organization_id
from public.organization_members m where m.user_id = p.user_id and p.organization_id is null;
update public.business_profiles b set organization_id = p.organization_id, project_id = p.id
from public.projects p where p.user_id = b.user_id and b.organization_id is null;
update public.leads l set organization_id = p.organization_id
from public.projects p where p.id = l.project_id and l.organization_id is null;

-- The legacy profile was one-per-user. Tenant scope makes one profile possible per project.
drop index if exists public.business_profiles_user_id_idx;
create unique index if not exists business_profiles_project_id_idx on public.business_profiles(project_id) where project_id is not null;

create table if not exists public.profile_revisions (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null references public.organizations(id) on delete cascade,
    project_id uuid references public.projects(id) on delete cascade,
    profile_id uuid not null references public.business_profiles(id) on delete cascade,
    revision bigint not null,
    profile jsonb not null default '{}'::jsonb,
    updated_by uuid not null references auth.users(id) on delete restrict,
    change_source text not null default 'profile-page',
    created_at timestamptz not null default now(),
    unique (profile_id, revision)
);

create table if not exists public.website_drafts (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null references public.organizations(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    profile_id uuid references public.business_profiles(id) on delete set null,
    profile_revision bigint,
    status text not null default 'draft' check (status in ('draft','published','archived')),
    files jsonb not null default '{}'::jsonb,
    revision bigint not null default 1,
    created_by uuid not null references auth.users(id) on delete restrict,
    updated_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.appointments (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null references public.organizations(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    lead_id uuid references public.leads(id) on delete set null,
    client_name text not null default '',
    client_email text not null default '',
    service text not null default '',
    notes text not null default '',
    status text not null default 'scheduled' check (status in ('scheduled','confirmed','completed','cancelled','no_show')),
    meeting_at timestamptz not null,
    follow_up_at timestamptz,
    created_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.activity_events (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null references public.organizations(id) on delete cascade,
    project_id uuid references public.projects(id) on delete cascade,
    actor_id uuid references auth.users(id) on delete set null,
    event_type text not null,
    entity_type text not null default 'workspace',
    entity_id uuid,
    payload jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);

create index if not exists organization_members_user_idx on public.organization_members(user_id);
create index if not exists projects_organization_idx on public.projects(organization_id);
create index if not exists profile_revisions_profile_idx on public.profile_revisions(profile_id, revision desc);
create index if not exists website_drafts_project_idx on public.website_drafts(project_id, updated_at desc);
create index if not exists appointments_project_idx on public.appointments(project_id, meeting_at);
create index if not exists activity_events_org_idx on public.activity_events(organization_id, created_at desc);

alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.profile_revisions enable row level security;
alter table public.website_drafts enable row level security;
alter table public.appointments enable row level security;
alter table public.activity_events enable row level security;

create or replace function public.is_org_member(target uuid)
returns boolean language sql stable security definer set search_path = public as $$
    select exists (select 1 from public.organization_members where organization_id = target and user_id = auth.uid());
$$;

create or replace function public.ensure_personal_workspace()
returns uuid language plpgsql security definer set search_path = public as $$
declare org uuid;
begin
    select organization_id into org from public.organization_members where user_id = auth.uid() order by created_at limit 1;
    if org is null then
        insert into public.organizations (name, created_by) values ('My workspace', auth.uid()) returning id into org;
        insert into public.organization_members (organization_id, user_id, role) values (org, auth.uid(), 'owner');
    end if;
    return org;
end;
$$;

-- Membership is the authorization boundary for new tenant-owned records.
drop policy if exists organization_member_read on public.organizations;
create policy organization_member_read on public.organizations for select using (public.is_org_member(id));
drop policy if exists organization_members_self_read on public.organization_members;
create policy organization_members_self_read on public.organization_members for select using (user_id = auth.uid() or public.is_org_member(organization_id));
drop policy if exists profile_revisions_member_access on public.profile_revisions;
create policy profile_revisions_member_access on public.profile_revisions for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
drop policy if exists website_drafts_member_access on public.website_drafts;
create policy website_drafts_member_access on public.website_drafts for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
drop policy if exists appointments_member_access on public.appointments;
create policy appointments_member_access on public.appointments for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
drop policy if exists activity_events_member_access on public.activity_events;
create policy activity_events_member_access on public.activity_events for select using (public.is_org_member(organization_id));
