-- Next steps task sync. Run after the existing Supabase schema.
create table if not exists public.next_steps (
    id uuid primary key,
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    text text not null check (char_length(text) between 1 and 240),
    category text not null default 'Setup' check (category in ('Setup','Website','Leads','Appointments','Ads','Follow-up')),
    priority text not null default 'soon' check (priority in ('now','soon','later')),
    due_date date,
    notes text not null default '' check (char_length(notes) <= 500),
    completed boolean not null default false,
    completed_at timestamptz,
    source text not null default 'user',
    href text not null default '',
    effort text not null default 'About 5 minutes',
    recurring boolean not null default false,
    recurrence text not null default '' check (recurrence in ('','weekly','monthly')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (id, user_id, project_id)
);

create index if not exists next_steps_owner_idx on public.next_steps (user_id, project_id, created_at);

alter table public.next_steps enable row level security;
drop policy if exists next_steps_owner_policy on public.next_steps;
create policy next_steps_owner_policy on public.next_steps
    for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.touch_next_steps_updated_at()
returns trigger language plpgsql as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists next_steps_updated_at on public.next_steps;
create trigger next_steps_updated_at before update on public.next_steps
for each row execute function public.touch_next_steps_updated_at();
