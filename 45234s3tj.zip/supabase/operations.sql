-- Persistent operational evidence and safe deletion primitives. Apply after schema.sql and platform.sql.
create table if not exists public.platform_audit_events (
    id uuid primary key default gen_random_uuid(),
    request_id text not null,
    actor_id uuid references auth.users(id) on delete set null,
    project_id uuid references public.projects(id) on delete cascade,
    action text not null,
    revision text,
    result text not null check (result in ('started','succeeded','failed')),
    provider_id text,
    metadata jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);
create index if not exists platform_audit_events_request_idx on public.platform_audit_events(request_id);
create index if not exists platform_audit_events_project_idx on public.platform_audit_events(project_id, created_at desc);
alter table public.platform_audit_events enable row level security;
drop policy if exists platform_audit_events_owner_read on public.platform_audit_events;
create policy platform_audit_events_owner_read on public.platform_audit_events for select using (auth.uid() = actor_id or exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));

create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public, pg_catalog as $$
begin
    if auth.uid() is null then raise exception 'UNAUTHORIZED' using errcode = '42501'; end if;
    delete from auth.users where id = auth.uid();
end;
$$;
revoke all on function public.delete_my_account() from public;
grant execute on function public.delete_my_account() to authenticated;

-- Retain operational evidence for one year unless a stricter policy is adopted.
create or replace function public.purge_old_platform_audit_events()
returns bigint language plpgsql security definer set search_path = public, pg_catalog as $$
declare removed bigint;
begin
    delete from public.platform_audit_events where created_at < now() - interval '1 year';
    get diagnostics removed = row_count;
    return removed;
end;
$$;
revoke all on function public.purge_old_platform_audit_events() from public;
