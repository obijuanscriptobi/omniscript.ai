-- Morrow platform foundation: teams, environments, providers, assets,
-- localization, approvals, experiments, templates, and production analytics.
-- Remove obsolete social tables if this migration has been run previously.
drop table if exists public.social_publishing_jobs cascade;
drop table if exists public.social_connections cascade;

create extension if not exists pgcrypto;

create table if not exists public.workspaces (
    id uuid primary key default gen_random_uuid(),
    owner_id uuid not null references auth.users(id) on delete cascade,
    name text not null default 'My workspace',
    slug text not null unique,
    settings jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
    workspace_id uuid not null references public.workspaces(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    role text not null check (role in ('owner','admin','editor','reviewer','viewer')),
    created_at timestamptz not null default now(),
    primary key (workspace_id, user_id)
);

create table if not exists public.workspace_invitations (
    id uuid primary key default gen_random_uuid(),
    workspace_id uuid not null references public.workspaces(id) on delete cascade,
    email text not null,
    role text not null check (role in ('admin','editor','reviewer','viewer')),
    invited_by uuid not null references auth.users(id) on delete cascade,
    token_hash text unique,
    status text not null default 'pending' check (status in ('pending','accepted','revoked','expired')),
    expires_at timestamptz not null default (now() + interval '7 days'),
    created_at timestamptz not null default now()
);

alter table public.workspace_invitations add column if not exists token_hash text;
create unique index if not exists workspace_invitation_token_idx on public.workspace_invitations(token_hash) where token_hash is not null;

create table if not exists public.workspace_domains (
    id uuid primary key default gen_random_uuid(),
    workspace_id uuid not null references public.workspaces(id) on delete cascade,
    hostname text not null unique,
    status text not null default 'pending' check (status in ('pending','verified','failed','removed')),
    verification_token text not null,
    provider text,
    created_at timestamptz not null default now(),
    verified_at timestamptz
);

create table if not exists public.project_workspaces (
    project_id uuid primary key references public.projects(id) on delete cascade,
    workspace_id uuid not null references public.workspaces(id) on delete cascade
);

create table if not exists public.provider_connections (
    id uuid primary key default gen_random_uuid(),
    workspace_id uuid not null references public.workspaces(id) on delete cascade,
    provider_type text not null check (provider_type in ('netlify','vercel','cloudflare-pages','static-export','plausible','umami','posthog','webhook')),
    display_name text not null,
    config jsonb not null default '{}'::jsonb,
    secret_ref text,
    enabled boolean not null default true,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.project_environments (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    environment text not null check (environment in ('draft','staging','production')),
    provider_connection_id uuid references public.provider_connections(id) on delete set null,
    public_url text,
    current_revision text,
    status text not null default 'draft' check (status in ('draft','deploying','deployed','verified','failed','stale')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (project_id, environment)
);

create table if not exists public.platform_deployments (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    environment_id uuid not null references public.project_environments(id) on delete cascade,
    revision text not null,
    provider_deployment_id text,
    status text not null default 'queued' check (status in ('queued','building','deployed','verified','failed','rolled_back')),
    url text,
    evidence jsonb not null default '{}'::jsonb,
    created_by uuid references auth.users(id) on delete set null,
    created_at timestamptz not null default now()
);

create table if not exists public.project_assets (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    storage_path text not null,
    public_url text,
    mime_type text not null,
    byte_size integer not null check (byte_size > 0 and byte_size <= 25000000),
    width integer,
    height integer,
    alt_text text not null default '',
    focal_point jsonb not null default '{}'::jsonb,
    optimization jsonb not null default '{}'::jsonb,
    created_by uuid references auth.users(id) on delete set null,
    created_at timestamptz not null default now()
);

create table if not exists public.project_locales (
    project_id uuid not null references public.projects(id) on delete cascade,
    locale text not null check (locale ~ '^[a-z]{2,3}(-[A-Z]{2})?$'),
    status text not null default 'draft' check (status in ('draft','in-review','approved','published')),
    content jsonb not null default '{}'::jsonb,
    translated_by text,
    updated_at timestamptz not null default now(),
    primary key (project_id, locale)
);

create table if not exists public.client_approvals (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    revision text not null,
    token_hash text not null unique,
    recipient_email text,
    status text not null default 'pending' check (status in ('pending','approved','changes-requested','expired','revoked')),
    comment text,
    expires_at timestamptz not null,
    approved_at timestamptz,
    created_by uuid references auth.users(id) on delete set null,
    created_at timestamptz not null default now()
);

create table if not exists public.project_experiments (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    name text not null,
    status text not null default 'draft' check (status in ('draft','running','paused','completed')),
    goal text not null,
    variants jsonb not null default '[]'::jsonb,
    allocation jsonb not null default '{}'::jsonb,
    results jsonb not null default '{}'::jsonb,
    created_by uuid references auth.users(id) on delete set null,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.marketplace_templates (
    id uuid primary key default gen_random_uuid(),
    author_id uuid references auth.users(id) on delete set null,
    slug text not null unique,
    name text not null,
    industry text not null,
    version text not null default '1.0.0',
    files jsonb not null default '{}'::jsonb,
    metadata jsonb not null default '{}'::jsonb,
    visibility text not null default 'private' check (visibility in ('private','unlisted','public')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.analytics_events (
    id bigint generated always as identity primary key,
    project_id uuid not null references public.projects(id) on delete cascade,
    deployment_id text,
    revision_id uuid references public.site_revisions(id) on delete set null,
    experiment_id uuid references public.project_experiments(id) on delete set null,
    event_name text not null check (event_name in ('page_view','cta_click','form_start','form_submit','booking_start','booking_completed','phone_click','email_click','quote_request','experiment_exposure')),
    anonymous_id text not null,
    path text not null default '/',
    locale text,
    consent boolean not null default false,
    occurred_at timestamptz not null default now(),
    metadata jsonb not null default '{}'::jsonb
);

create index if not exists analytics_project_time_idx on public.analytics_events(project_id, occurred_at desc);
create index if not exists analytics_experiment_revision_idx on public.analytics_events(experiment_id, revision_id, event_name, occurred_at desc);
create index if not exists deployments_project_time_idx on public.platform_deployments(project_id, created_at desc);
create index if not exists assets_project_idx on public.project_assets(project_id);

alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.workspace_invitations enable row level security;
alter table public.analytics_events enable row level security;
alter table public.project_workspaces enable row level security;
alter table public.provider_connections enable row level security;
alter table public.project_environments enable row level security;
alter table public.platform_deployments enable row level security;
alter table public.project_assets enable row level security;
alter table public.project_locales enable row level security;
alter table public.client_approvals enable row level security;
alter table public.project_experiments enable row level security;
alter table public.marketplace_templates enable row level security;

create or replace function public.is_workspace_member(target_workspace uuid, allowed_roles text[] default array['owner','admin','editor','reviewer','viewer'])
returns boolean language sql stable security definer set search_path = public, pg_catalog as $$
    select exists (
        select 1 from public.workspaces w
        where w.id = target_workspace
          and w.owner_id = auth.uid()
          and 'owner' = any(allowed_roles)
    )
    or exists (
        select 1 from public.workspace_members wm
        where wm.workspace_id = target_workspace
          and wm.user_id = auth.uid()
          and wm.role = any(allowed_roles)
    );
$$;

create or replace function public.project_workspace_id(target_project uuid)
returns uuid language sql stable security definer set search_path = public, pg_catalog as $$
    select workspace_id from public.project_workspaces where project_id = target_project;
$$;

-- Workspace and project policy helpers keep every platform table scoped to membership.
-- Drop named policies first so this migration can be safely re-applied.
drop policy if exists workspace_member_access on public.workspaces;
drop policy if exists workspace_members_access on public.workspace_members;
drop policy if exists invitation_access on public.workspace_invitations;
drop policy if exists analytics_access on public.analytics_events;
drop policy if exists project_workspace_access on public.project_workspaces;
drop policy if exists provider_connections_access on public.provider_connections;
drop policy if exists project_environment_access on public.project_environments;
drop policy if exists deployment_access on public.platform_deployments;
drop policy if exists asset_access on public.project_assets;
drop policy if exists locale_access on public.project_locales;
drop policy if exists approval_access on public.client_approvals;
drop policy if exists experiment_access on public.project_experiments;
drop policy if exists public_templates_read on public.marketplace_templates;
drop policy if exists template_owner_write on public.marketplace_templates;

create policy workspace_member_access on public.workspaces for all using (owner_id = auth.uid() or public.is_workspace_member(id));
create policy workspace_members_access on public.workspace_members for all using (public.is_workspace_member(workspace_id, array['owner','admin']));
create policy invitation_access on public.workspace_invitations for all using (public.is_workspace_member(workspace_id, array['owner','admin']) or invited_by = auth.uid());
create policy analytics_access on public.analytics_events for select using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy project_workspace_access on public.project_workspaces for all using (public.is_workspace_member(workspace_id));
create policy provider_connections_access on public.provider_connections for all using (public.is_workspace_member(workspace_id, array['owner','admin']));
create policy project_environment_access on public.project_environments for all using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy deployment_access on public.platform_deployments for all using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy asset_access on public.project_assets for all using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy locale_access on public.project_locales for all using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy approval_access on public.client_approvals for all using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy experiment_access on public.project_experiments for all using (public.is_workspace_member(public.project_workspace_id(project_id)));
create policy public_templates_read on public.marketplace_templates for select using (visibility = 'public' or author_id = auth.uid());
create policy template_owner_write on public.marketplace_templates for all using (author_id = auth.uid());

alter table public.analytics_events add column if not exists revision_id uuid;
alter table public.analytics_events add column if not exists experiment_id uuid references public.project_experiments(id) on delete set null;
alter table public.analytics_events alter column deployment_id type text using deployment_id::text;

-- Public analytics writes are intentionally performed by the server endpoint,
-- not by an anon client, so no anonymous insert policy is granted here.
