-- Project membership administration, invitations, and auditable changes.
create extension if not exists pgcrypto;

-- Create the parent membership table before policies reference it.
create table if not exists public.project_memberships (
    project_id uuid not null references public.projects(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    role text not null check (role in ('owner','admin','sales','marketing','contributor','client_reviewer')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (project_id, user_id)
);

create table if not exists public.project_membership_invitations (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    invited_by uuid not null references auth.users(id) on delete cascade,
    email text not null,
    role text not null check (role in ('admin','sales','marketing','contributor','client_reviewer')),
    token_hash text not null unique,
    status text not null default 'pending' check (status in ('pending','accepted','revoked','expired')),
    expires_at timestamptz not null,
    created_at timestamptz not null default now()
);
create index if not exists project_membership_invitations_project_idx on public.project_membership_invitations(project_id, created_at desc);

alter table public.project_memberships enable row level security;
alter table public.project_membership_invitations enable row level security;

drop policy if exists project_membership_invitations_manager_access on public.project_membership_invitations;
create policy project_membership_invitations_manager_access on public.project_membership_invitations for all
using (exists (select 1 from public.project_memberships m where m.project_id = project_membership_invitations.project_id and m.user_id = auth.uid() and m.role in ('owner','admin')))
with check (exists (select 1 from public.project_memberships m where m.project_id = project_membership_invitations.project_id and m.user_id = auth.uid() and m.role in ('owner','admin')));

-- Keep existing project owners represented in the membership table.
insert into public.project_memberships (project_id, user_id, role)
select id, user_id, 'owner' from public.projects
on conflict (project_id, user_id) do nothing;
