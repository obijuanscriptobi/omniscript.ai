-- Durable, project-scoped proposal and handoff lifecycle.
-- Apply after platform.sql, collaboration-security.sql, lifecycle.sql,
-- work-contexts.sql, work-context-isolation.sql, reliability.sql, and operations.sql.
create extension if not exists pgcrypto;

create table if not exists public.project_proposals (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete restrict,
    approval_id uuid not null references public.client_approvals(id) on delete restrict,
    revision text not null,
    recipient_email text not null,
    title text not null,
    scope jsonb not null default '[]'::jsonb,
    amount_cents bigint check (amount_cents is null or amount_cents >= 0),
    currency text not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
    status text not null default 'accepted' check (status in ('accepted','handed_off','cancelled')),
    created_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (project_id, approval_id)
);

create table if not exists public.project_handoffs (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete restrict,
    proposal_id uuid not null references public.project_proposals(id) on delete restrict,
    approval_id uuid not null references public.client_approvals(id) on delete restrict,
    revision text not null,
    recipient_email text not null,
    access_grant text not null check (access_grant in ('reviewer','viewer','editor')),
    reason text not null default '',
    request_id text not null,
    state text not null default 'completed' check (state in ('completed','reversed')),
    created_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(),
    reversed_at timestamptz,
    unique (project_id, proposal_id),
    unique (request_id)
);

create index if not exists project_proposals_project_status_idx on public.project_proposals(project_id, status, created_at desc);
create index if not exists project_proposals_approval_idx on public.project_proposals(approval_id, project_id);
create index if not exists project_handoffs_project_state_idx on public.project_handoffs(project_id, state, created_at desc);
create index if not exists project_handoffs_approval_idx on public.project_handoffs(approval_id, project_id);

alter table public.project_proposals enable row level security;
alter table public.project_handoffs enable row level security;

drop policy if exists project_proposals_context_access on public.project_proposals;
create policy project_proposals_context_access on public.project_proposals for select
using (public.can_access_project_context(project_id));
drop policy if exists project_handoffs_context_access on public.project_handoffs;
create policy project_handoffs_context_access on public.project_handoffs for select
using (public.can_access_project_context(project_id));

create or replace function public.create_project_proposal(
    p_actor_id uuid,
    p_project_id uuid,
    p_approval_id uuid,
    p_recipient_email text,
    p_title text,
    p_scope jsonb default '[]'::jsonb,
    p_amount_cents bigint default null,
    p_currency text default 'USD'
)
returns setof public.project_proposals
language plpgsql
security definer
set search_path = public, pg_catalog
as $$
declare
    approved public.client_approvals%rowtype;
    current_revision text;
begin
    if auth.uid() is null or auth.uid() <> p_actor_id then raise exception 'PROPOSAL_AUTHORIZATION_FAILED' using errcode='42501'; end if;
    if not exists (
        select 1 from public.project_memberships m
        where m.project_id=p_project_id and m.user_id=p_actor_id and m.role in ('owner','admin','contributor')
    ) or not public.can_access_project_context(p_project_id) then raise exception 'PROPOSAL_AUTHORIZATION_FAILED' using errcode='42501'; end if;
    if p_recipient_email !~* '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
       or char_length(p_recipient_email)>254 or char_length(trim(p_title))<1 or char_length(p_title)>200
       or jsonb_typeof(coalesce(p_scope,'null'::jsonb)) <> 'array'
       or pg_column_size(p_scope)>20000 or p_amount_cents<0 or upper(p_currency) !~ '^[A-Z]{3}$'
    then raise exception 'PROPOSAL_INPUT_INVALID' using errcode='22023'; end if;
    select * into approved from public.client_approvals
    where id=p_approval_id and project_id=p_project_id and status='approved'
    for update;
    if not found then raise exception 'APPROVED_DELIVERABLE_REQUIRED' using errcode='23514'; end if;
    select revision into current_revision from public.projects where id=p_project_id for update;
    if current_revision is distinct from approved.revision then raise exception 'PROJECT_HAS_UNSYNCED_CHANGES' using errcode='40001'; end if;
    return query insert into public.project_proposals(project_id,approval_id,revision,recipient_email,title,scope,amount_cents,currency,created_by)
    values(p_project_id,p_approval_id,approved.revision,lower(trim(p_recipient_email)),trim(p_title),p_scope,p_amount_cents,upper(p_currency),p_actor_id)
    on conflict (project_id,approval_id) do update set
        recipient_email=excluded.recipient_email,title=excluded.title,scope=excluded.scope,
        amount_cents=excluded.amount_cents,currency=excluded.currency,updated_at=now()
    where project_proposals.status='accepted' and project_proposals.revision=excluded.revision
    returning *;
end;
$$;

create or replace function public.create_project_handoff(
    p_actor_id uuid,
    p_project_id uuid,
    p_proposal_id uuid,
    p_recipient_email text,
    p_access_grant text,
    p_reason text,
    p_request_id text
)
returns setof public.project_handoffs
language plpgsql
security definer
set search_path = public, pg_catalog
as $$
declare
    selected_proposal public.project_proposals%rowtype;
    selected_approval public.client_approvals%rowtype;
    current_project public.projects%rowtype;
begin
    if auth.uid() is null or auth.uid() <> p_actor_id then raise exception 'HANDOFF_AUTHORIZATION_FAILED' using errcode='42501'; end if;
    if p_access_grant not in ('reviewer','viewer','editor') or char_length(p_reason)>1000
       or p_recipient_email !~* '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
       or char_length(p_recipient_email)>254 or p_request_id !~ '^[A-Za-z0-9._:-]{8,120}$'
    then raise exception 'HANDOFF_INPUT_INVALID' using errcode='22023'; end if;
    if not exists (
        select 1 from public.project_memberships m
        where m.project_id=p_project_id and m.user_id=p_actor_id and m.role in ('owner','admin')
    ) or not public.can_access_project_context(p_project_id) then raise exception 'HANDOFF_AUTHORIZATION_FAILED' using errcode='42501'; end if;
    select * into current_project from public.projects where id=p_project_id for update;
    if not found then raise exception 'HANDOFF_AUTHORIZATION_FAILED' using errcode='42501'; end if;
    if not exists (
        select 1 from public.work_contexts c where c.id=current_project.work_context_id
          and c.organization_id=current_project.organization_id and c.status='active'
          and c.permissions_confirmed and c.asset_rights_confirmed
    ) then raise exception 'HANDOFF_RIGHTS_REQUIRED' using errcode='23514'; end if;
    select * into selected_proposal from public.project_proposals
    where id=p_proposal_id and project_id=p_project_id and status='accepted' for update;
    if not found then raise exception 'ACCEPTED_PROPOSAL_REQUIRED' using errcode='23514'; end if;
    select * into selected_approval from public.client_approvals
    where id=selected_proposal.approval_id and project_id=p_project_id and status='approved' for update;
    if not found or selected_approval.revision is distinct from selected_proposal.revision
       or current_project.revision is distinct from selected_proposal.revision
    then raise exception 'PROJECT_HAS_UNSYNCED_CHANGES' using errcode='40001'; end if;
    if lower(trim(p_recipient_email)) is distinct from lower(selected_proposal.recipient_email)
    then raise exception 'HANDOFF_RECIPIENT_MISMATCH' using errcode='23514'; end if;
    return query insert into public.project_handoffs(project_id,proposal_id,approval_id,revision,recipient_email,access_grant,reason,request_id,created_by)
    values(p_project_id,p_proposal_id,selected_proposal.approval_id,selected_proposal.revision,lower(trim(p_recipient_email)),p_access_grant,coalesce(trim(p_reason),''),p_request_id,p_actor_id)
    on conflict (project_id,proposal_id) do nothing
    returning *;
    if not found then raise exception 'HANDOFF_ALREADY_COMPLETED' using errcode='23505'; end if;
    update public.project_proposals set status='handed_off',updated_at=now() where id=p_proposal_id and project_id=p_project_id;
    update public.client_portal_shares set revoked_at=coalesce(revoked_at,now()) where project_id=p_project_id;
    update public.client_approvals set status='revoked' where project_id=p_project_id and id<>selected_proposal.approval_id and status='pending';
    insert into public.platform_audit_events(request_id,actor_id,project_id,action,revision,result,metadata)
    values(p_request_id,p_actor_id,p_project_id,'project.handoff',selected_proposal.revision,'succeeded',
        jsonb_build_object('proposalId',p_proposal_id,'approvalId',selected_proposal.approval_id,
                           'recipient',lower(trim(p_recipient_email)),'accessGrant',p_access_grant,'reason',coalesce(trim(p_reason),'')));
end;
$$;

-- Ownership and parent bindings remain immutable even for privileged writers.
create or replace function public.enforce_proposal_handoff_scope()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if tg_op='UPDATE' and (new.project_id is distinct from old.project_id
        or new.approval_id is distinct from old.approval_id
        or new.revision is distinct from old.revision
        or (tg_table_name='project_handoffs' and new.proposal_id is distinct from old.proposal_id))
    then raise exception 'Proposal/handoff ownership cannot be reassigned' using errcode='23514'; end if;
    if tg_table_name='project_proposals' and not exists (
        select 1 from public.client_approvals a where a.id=new.approval_id and a.project_id=new.project_id
          and a.revision=new.revision and a.status='approved'
    ) then raise exception 'Proposal scope does not match an approved deliverable' using errcode='23514'; end if;
    if tg_table_name='project_handoffs' and not exists (
        select 1 from public.project_proposals p join public.client_approvals a on a.id=p.approval_id
        where p.id=new.proposal_id and p.project_id=new.project_id and p.approval_id=new.approval_id
          and p.revision=new.revision and a.project_id=new.project_id and a.revision=new.revision and a.status='approved'
    ) then raise exception 'Handoff scope does not match its proposal and approval' using errcode='23514'; end if;
    return new;
end;
$$;
drop trigger if exists project_proposals_scope_guard on public.project_proposals;
create trigger project_proposals_scope_guard before insert or update on public.project_proposals
for each row execute function public.enforce_proposal_handoff_scope();
drop trigger if exists project_handoffs_scope_guard on public.project_handoffs;
create trigger project_handoffs_scope_guard before insert or update on public.project_handoffs
for each row execute function public.enforce_proposal_handoff_scope();

create or replace function public.prevent_project_handoff_context_reassignment()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if new.work_context_id is distinct from old.work_context_id and (
        exists(select 1 from public.project_proposals p where p.project_id=old.id and p.status<>'cancelled')
        or exists(select 1 from public.project_handoffs h where h.project_id=old.id and h.state='completed')
    ) then raise exception 'Project context reassignment is blocked by an active proposal or handoff' using errcode='23514'; end if;
    return new;
end;
$$;
drop trigger if exists projects_handoff_context_guard on public.projects;
create trigger projects_handoff_context_guard before update of work_context_id on public.projects
for each row execute function public.prevent_project_handoff_context_reassignment();

revoke all on function public.enforce_proposal_handoff_scope() from public;
revoke all on function public.prevent_project_handoff_context_reassignment() from public;
revoke all on function public.create_project_proposal(uuid,uuid,uuid,text,text,jsonb,bigint,text) from public;
revoke all on function public.create_project_handoff(uuid,uuid,uuid,text,text,text,text) from public;
grant execute on function public.create_project_proposal(uuid,uuid,uuid,text,text,jsonb,bigint,text) to authenticated;
grant execute on function public.create_project_handoff(uuid,uuid,uuid,text,text,text,text) to authenticated;
