-- Persistent idempotency and reversible quota reservations.
create table if not exists public.idempotent_operations (
    actor_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid references public.projects(id) on delete cascade,
    operation text not null,
    idempotency_key text not null,
    request_hash text not null,
    state text not null default 'in_progress' check (state in ('in_progress', 'completed')),
    response_payload jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (actor_id, operation, idempotency_key)
);
alter table public.idempotent_operations enable row level security;

create or replace function public.begin_idempotent_operation(p_actor_id uuid, p_project_id uuid, p_operation text, p_idempotency_key text, p_request_hash text)
returns table(state text, response_payload jsonb)
language plpgsql security definer set search_path = public, pg_catalog as $$
declare
    existing public.idempotent_operations%rowtype;
    inserted_count integer := 0;
begin
    if auth.uid() is null or auth.uid() <> p_actor_id then raise exception 'IDEMPOTENCY_AUTHORIZATION_FAILED' using errcode = '42501'; end if;
    if p_operation !~ '^[a-z0-9._-]{1,80}$' or p_idempotency_key !~ '^[A-Za-z0-9._:-]{8,120}$' or p_request_hash !~ '^[a-f0-9]{64}$' then raise exception 'IDEMPOTENCY_INPUT_INVALID' using errcode = '22023'; end if;
    insert into public.idempotent_operations(actor_id, project_id, operation, idempotency_key, request_hash)
    values (p_actor_id, p_project_id, p_operation, p_idempotency_key, p_request_hash)
    on conflict do nothing;
    get diagnostics inserted_count = row_count;
    select * into existing from public.idempotent_operations i where i.actor_id=p_actor_id and i.operation=p_operation and i.idempotency_key=p_idempotency_key for update;
    if existing.request_hash <> p_request_hash then return query select 'conflict'::text, null::jsonb;
    elsif existing.state='completed' then return query select 'completed'::text, existing.response_payload;
    elsif inserted_count = 1 then return query select 'started'::text, null::jsonb;
    elsif existing.updated_at < now() - interval '5 minutes' then
        update public.idempotent_operations set created_at=now(), updated_at=now() where actor_id=p_actor_id and operation=p_operation and idempotency_key=p_idempotency_key;
        return query select 'started'::text, null::jsonb;
    else return query select 'in_progress'::text, null::jsonb;
    end if;
end $$;

create or replace function public.complete_idempotent_operation(p_actor_id uuid, p_project_id uuid, p_operation text, p_idempotency_key text, p_response_payload jsonb)
returns void language plpgsql security definer set search_path = public, pg_catalog as $$
begin
    if auth.uid() is null or auth.uid() <> p_actor_id then raise exception 'IDEMPOTENCY_AUTHORIZATION_FAILED' using errcode = '42501'; end if;
    update public.idempotent_operations set state='completed', response_payload=p_response_payload, updated_at=now()
    where actor_id=p_actor_id and operation=p_operation and idempotency_key=p_idempotency_key and project_id is not distinct from p_project_id;
end $$;

create or replace function public.abandon_idempotent_operation(p_actor_id uuid, p_project_id uuid, p_operation text, p_idempotency_key text)
returns void language plpgsql security definer set search_path = public, pg_catalog as $$
begin
    if auth.uid() is null or auth.uid() <> p_actor_id then raise exception 'IDEMPOTENCY_AUTHORIZATION_FAILED' using errcode = '42501'; end if;
    delete from public.idempotent_operations where actor_id=p_actor_id and operation=p_operation and idempotency_key=p_idempotency_key and project_id is not distinct from p_project_id and state='in_progress';
end $$;

revoke all on function public.begin_idempotent_operation(uuid,uuid,text,text,text) from public;
revoke all on function public.complete_idempotent_operation(uuid,uuid,text,text,jsonb) from public;
revoke all on function public.abandon_idempotent_operation(uuid,uuid,text,text) from public;
grant execute on function public.begin_idempotent_operation(uuid,uuid,text,text,text) to authenticated;
grant execute on function public.complete_idempotent_operation(uuid,uuid,text,text,jsonb) to authenticated;
grant execute on function public.abandon_idempotent_operation(uuid,uuid,text,text) to authenticated;

-- Approval decisions are made through anonymous, token-scoped links, so they
-- need a separate idempotency store that never exposes the token itself.
create table if not exists public.public_approval_decision_operations (
    token_hash text not null,
    idempotency_key text not null,
    request_hash text not null,
    state text not null default 'in_progress' check (state in ('in_progress', 'completed')),
    response_payload jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (token_hash, idempotency_key)
);
alter table public.public_approval_decision_operations enable row level security;

create or replace function public.begin_public_approval_decision(p_token_hash text, p_idempotency_key text, p_request_hash text)
returns table(state text, response_payload jsonb)
language plpgsql security definer set search_path = public, pg_catalog as $$
declare
    existing public.public_approval_decision_operations%rowtype;
    inserted_count integer := 0;
begin
    if p_token_hash !~ '^[a-f0-9]{64}$' or p_idempotency_key !~ '^[A-Za-z0-9._:-]{8,120}$' or p_request_hash !~ '^[a-f0-9]{64}$' then
        raise exception 'IDEMPOTENCY_INPUT_INVALID' using errcode = '22023';
    end if;
    if not exists (
        select 1
        from public.client_approvals a
        join public.projects p on p.id = a.project_id
        join public.work_contexts c on c.id = p.work_context_id and c.organization_id = p.organization_id
        where a.token_hash=p_token_hash and a.status='pending' and a.expires_at > now() and c.status='active'
    ) then
        raise exception 'APPROVAL_TOKEN_INVALID' using errcode = '42501';
    end if;
    insert into public.public_approval_decision_operations(token_hash, idempotency_key, request_hash)
    values (p_token_hash, p_idempotency_key, p_request_hash)
    on conflict do nothing;
    get diagnostics inserted_count = row_count;
    select * into existing from public.public_approval_decision_operations i
    where i.token_hash=p_token_hash and i.idempotency_key=p_idempotency_key for update;
    if existing.request_hash <> p_request_hash then return query select 'conflict'::text, null::jsonb;
    elsif existing.state='completed' then return query select 'completed'::text, existing.response_payload;
    elsif inserted_count = 1 then return query select 'started'::text, null::jsonb;
    elsif existing.updated_at < now() - interval '5 minutes' then
        update public.public_approval_decision_operations set created_at=now(), updated_at=now()
        where token_hash=p_token_hash and idempotency_key=p_idempotency_key;
        return query select 'started'::text, null::jsonb;
    else return query select 'in_progress'::text, null::jsonb;
    end if;
end $$;

create or replace function public.complete_public_approval_decision(p_token_hash text, p_idempotency_key text, p_response_payload jsonb)
returns void language plpgsql security definer set search_path = public, pg_catalog as $$
begin
    if not exists (select 1 from public.client_approvals where token_hash=p_token_hash) then
        raise exception 'APPROVAL_TOKEN_INVALID' using errcode = '42501';
    end if;
    update public.public_approval_decision_operations
    set state='completed', response_payload=p_response_payload, updated_at=now()
    where token_hash=p_token_hash and idempotency_key=p_idempotency_key;
end $$;

create or replace function public.abandon_public_approval_decision(p_token_hash text, p_idempotency_key text)
returns void language plpgsql security definer set search_path = public, pg_catalog as $$
begin
    delete from public.public_approval_decision_operations
    where token_hash=p_token_hash and idempotency_key=p_idempotency_key and state='in_progress';
end $$;

revoke all on function public.begin_public_approval_decision(text,text,text) from public;
revoke all on function public.complete_public_approval_decision(text,text,jsonb) from public;
revoke all on function public.abandon_public_approval_decision(text,text) from public;
grant execute on function public.begin_public_approval_decision(text,text,text) to anon, authenticated;
grant execute on function public.complete_public_approval_decision(text,text,jsonb) to anon, authenticated;
grant execute on function public.abandon_public_approval_decision(text,text) to anon, authenticated;

-- Generic token-scoped idempotency for public operations such as portal upload
-- finalization. Tokens remain hashed and are never returned by this store.
create table if not exists public.public_token_operations (
    token_hash text not null check (token_hash ~ '^[a-f0-9]{64}$'),
    operation text not null check (operation ~ '^[a-z0-9._-]{1,80}$'),
    idempotency_key text not null,
    request_hash text not null check (request_hash ~ '^[a-f0-9]{64}$'),
    state text not null default 'in_progress' check (state in ('in_progress','completed')),
    response_payload jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (token_hash, operation, idempotency_key)
);
alter table public.public_token_operations enable row level security;

create or replace function public.begin_public_token_operation(p_token_hash text, p_operation text, p_idempotency_key text, p_request_hash text)
returns table(state text, response_payload jsonb)
language plpgsql security definer set search_path = public, pg_catalog as $$
declare existing public.public_token_operations%rowtype; inserted_count integer := 0;
begin
    if p_token_hash !~ '^[a-f0-9]{64}$' or p_operation !~ '^[a-z0-9._-]{1,80}$' or p_idempotency_key !~ '^[A-Za-z0-9._:-]{8,120}$' or p_request_hash !~ '^[a-f0-9]{64}$' then raise exception 'IDEMPOTENCY_INPUT_INVALID' using errcode='22023'; end if;
    if not exists (
        select 1 from public.client_portal_shares s join public.projects p on p.id=s.project_id join public.work_contexts c on c.id=p.work_context_id and c.organization_id=p.organization_id
        where s.token_hash=p_token_hash and s.revoked_at is null and s.expires_at>now() and c.status='active'
    ) then raise exception 'PUBLIC_TOKEN_INVALID' using errcode='42501'; end if;
    insert into public.public_token_operations(token_hash,operation,idempotency_key,request_hash) values(p_token_hash,p_operation,p_idempotency_key,p_request_hash) on conflict do nothing;
    get diagnostics inserted_count = row_count;
    select * into existing from public.public_token_operations o where o.token_hash=p_token_hash and o.operation=p_operation and o.idempotency_key=p_idempotency_key for update;
    if existing.request_hash<>p_request_hash then return query select 'conflict'::text,null::jsonb;
    elsif existing.state='completed' then return query select 'completed'::text,existing.response_payload;
    elsif inserted_count=1 or existing.updated_at<now()-interval '5 minutes' then
        update public.public_token_operations set updated_at=now() where token_hash=p_token_hash and operation=p_operation and idempotency_key=p_idempotency_key;
        return query select 'started'::text,null::jsonb;
    else return query select 'in_progress'::text,null::jsonb; end if;
end $$;
create or replace function public.complete_public_token_operation(p_token_hash text,p_operation text,p_idempotency_key text,p_response_payload jsonb)
returns void language sql security definer set search_path=public,pg_catalog as $$ update public.public_token_operations set state='completed',response_payload=p_response_payload,updated_at=now() where token_hash=p_token_hash and operation=p_operation and idempotency_key=p_idempotency_key $$;
create or replace function public.abandon_public_token_operation(p_token_hash text,p_operation text,p_idempotency_key text)
returns void language sql security definer set search_path=public,pg_catalog as $$ delete from public.public_token_operations where token_hash=p_token_hash and operation=p_operation and idempotency_key=p_idempotency_key and state='in_progress' $$;
revoke all on function public.begin_public_token_operation(text,text,text,text) from public;
revoke all on function public.complete_public_token_operation(text,text,text,jsonb) from public;
revoke all on function public.abandon_public_token_operation(text,text,text) from public;
grant execute on function public.begin_public_token_operation(text,text,text,text) to anon, authenticated;
grant execute on function public.complete_public_token_operation(text,text,text,jsonb) to anon, authenticated;
grant execute on function public.abandon_public_token_operation(text,text,text) to anon, authenticated;
