create extension if not exists pgcrypto;

create table if not exists public.projects (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    name text not null default 'Untitled project',
    files jsonb not null default '{}'::jsonb,
    form_data jsonb not null default '{}'::jsonb,
    preview_mode text not null default 'desktop',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.business_profiles (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    revision bigint not null default 0,
    profile jsonb not null default '{}'::jsonb,
    audit jsonb not null default '[]'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint business_profiles_payload_size_check check (pg_column_size(profile) <= 500000 and pg_column_size(audit) <= 1000000)
);

create unique index if not exists business_profiles_user_id_idx on public.business_profiles(user_id);
create index if not exists business_profiles_updated_at_idx on public.business_profiles(user_id, updated_at desc);

alter table public.business_profiles enable row level security;
drop policy if exists "Users can view their own business profile" on public.business_profiles;
drop policy if exists "Users can create their own business profile" on public.business_profiles;
drop policy if exists "Users can update their own business profile" on public.business_profiles;
create policy "Users can view their own business profile" on public.business_profiles for select using (auth.uid() = user_id);
create policy "Users can create their own business profile" on public.business_profiles for insert with check (auth.uid() = user_id);
create policy "Users can update their own business profile" on public.business_profiles for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.business_profile_versions (
    id uuid primary key default gen_random_uuid(),
    profile_id uuid not null references public.business_profiles(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    revision bigint not null,
    profile jsonb not null default '{}'::jsonb,
    change_event jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);

create index if not exists business_profile_versions_profile_idx on public.business_profile_versions(profile_id, revision desc);
alter table public.business_profile_versions enable row level security;

-- Recreate these policies so the migration remains safe to run again.
drop policy if exists "Users can view their own profile versions" on public.business_profile_versions;
drop policy if exists "Users can create their own profile versions" on public.business_profile_versions;

create policy "Users can view their own profile versions"
on public.business_profile_versions
for select
using (auth.uid() = user_id);

create policy "Users can create their own profile versions"
on public.business_profile_versions
for insert
with check (auth.uid() = user_id);

create table if not exists public.project_versions (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    files jsonb not null default '{}'::jsonb,
    form_data jsonb not null default '{}'::jsonb,
    preview_mode text not null default 'desktop',
    created_at timestamptz not null default now()
);

-- Support all preview modes used by the application.
alter table public.projects
    drop constraint if exists projects_preview_mode_check;

alter table public.projects
    add constraint projects_preview_mode_check
    check (preview_mode in ('desktop', 'tablet', 'mobile'));

alter table public.project_versions
    drop constraint if exists project_versions_preview_mode_check;

alter table public.project_versions
    add constraint project_versions_preview_mode_check
    check (preview_mode in ('desktop', 'tablet', 'mobile'));

create index if not exists projects_user_id_idx
    on public.projects(user_id);

create index if not exists projects_user_updated_at_idx
    on public.projects(user_id, updated_at desc);

create index if not exists project_versions_project_id_idx
    on public.project_versions(project_id);

create index if not exists project_versions_user_id_created_at_idx
    on public.project_versions(user_id, created_at desc);

create table if not exists public.leads (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    name text not null default '',
    email text not null default '',
    phone text not null default '',
    message text not null default '',
    status text not null default 'new',
    source text not null default 'website',
    campaign text not null default '',
    notes text not null default '',
    reminder_at timestamptz,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint leads_status_check check (status in ('new', 'verified', 'contacted', 'replied', 'qualified', 'booked', 'won', 'lost')),
    constraint leads_payload_size_check check (
        pg_column_size(name) <= 2000 and pg_column_size(email) <= 4000 and
        pg_column_size(phone) <= 1000 and pg_column_size(message) <= 16000 and
        pg_column_size(notes) <= 16000
    )
);

create index if not exists leads_user_project_created_idx
    on public.leads(user_id, project_id, created_at desc);

alter table public.leads enable row level security;

drop policy if exists "Users can view their own leads" on public.leads;
drop policy if exists "Users can create their own leads" on public.leads;
drop policy if exists "Users can update their own leads" on public.leads;
drop policy if exists "Users can delete their own leads" on public.leads;

create policy "Users can view their own leads"
on public.leads for select using (auth.uid() = user_id);
create policy "Users can create their own leads"
on public.leads for insert with check (auth.uid() = user_id and exists (select 1 from public.projects where projects.id = leads.project_id and projects.user_id = auth.uid()));
create policy "Users can update their own leads"
on public.leads for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete their own leads"
on public.leads for delete using (auth.uid() = user_id);

create or replace function public.touch_lead_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists leads_updated_at on public.leads;
create trigger leads_updated_at before update on public.leads for each row execute function public.touch_lead_updated_at();

-- Keep browser-managed JSON payloads bounded before they reach storage.
alter table public.projects
    drop constraint if exists projects_payload_size_check;

alter table public.projects
    add constraint projects_payload_size_check
    check (pg_column_size(files) <= 5000000 and pg_column_size(form_data) <= 250000);

alter table public.project_versions
    drop constraint if exists project_versions_payload_size_check;

alter table public.project_versions
    add constraint project_versions_payload_size_check
    check (pg_column_size(files) <= 5000000 and pg_column_size(form_data) <= 250000);

alter table public.projects enable row level security;
alter table public.project_versions enable row level security;

drop policy if exists "Users can view their own projects" on public.projects;
drop policy if exists "Users can create their own projects" on public.projects;
drop policy if exists "Users can update their own projects" on public.projects;
drop policy if exists "Users can delete their own projects" on public.projects;

create policy "Users can view their own projects"
on public.projects
for select
using (auth.uid() = user_id);

create policy "Users can create their own projects"
on public.projects
for insert
with check (auth.uid() = user_id);

create policy "Users can update their own projects"
on public.projects
for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Users can delete their own projects"
on public.projects
for delete
using (auth.uid() = user_id);

drop policy if exists "Users can view their own versions"
    on public.project_versions;

drop policy if exists "Users can create their own versions"
    on public.project_versions;

drop policy if exists "Users can delete their own versions"
    on public.project_versions;

create policy "Users can view their own versions"
on public.project_versions
for select
using (
    auth.uid() = user_id
    and exists (
        select 1
        from public.projects
        where projects.id = project_versions.project_id
          and projects.user_id = auth.uid()
    )
);

create policy "Users can create their own versions"
on public.project_versions
for insert
with check (
    auth.uid() = user_id
    and exists (
        select 1
        from public.projects
        where projects.id = project_versions.project_id
          and projects.user_id = auth.uid()
    )
);

create policy "Users can delete their own versions"
on public.project_versions
for delete
using (
    auth.uid() = user_id
    and exists (
        select 1
        from public.projects
        where projects.id = project_versions.project_id
          and projects.user_id = auth.uid()
    )
);

create or replace function public.touch_project_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = public, pg_catalog
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists projects_updated_at on public.projects;

create trigger projects_updated_at
before update on public.projects
for each row
execute function public.touch_project_updated_at();

-- Connected business operations: proposals, catalog, invoices, files,
-- approvals, activity, and notifications use one bounded cloud record shape.
create table if not exists public.business_operations (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    kind text not null check (kind in ('project','proposal','catalog','invoice','file','approval','activity','notification')),
    payload jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint business_operations_payload_size_check check (pg_column_size(payload) <= 100000)
);

create index if not exists business_operations_user_project_idx on public.business_operations(user_id, project_id, updated_at desc);
create index if not exists business_operations_kind_idx on public.business_operations(user_id, kind, updated_at desc);
alter table public.business_operations enable row level security;
drop policy if exists business_operations_owner_access on public.business_operations;
create policy business_operations_owner_access on public.business_operations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.touch_business_operations_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists business_operations_updated_at on public.business_operations;
create trigger business_operations_updated_at before update on public.business_operations for each row execute function public.touch_business_operations_updated_at();

-- Secure project collaboration, private file metadata, and approval history.
create table if not exists public.project_memberships (
    project_id uuid not null references public.projects(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    role text not null check (role in ('owner','admin','sales','marketing','contributor','client_reviewer')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (project_id, user_id)
);
create table if not exists public.project_file_versions (
    id uuid primary key default gen_random_uuid(), project_id uuid not null references public.projects(id) on delete cascade,
    file_id uuid not null, version integer not null check (version > 0), storage_path text not null,
    file_name text not null, mime_type text not null, byte_size bigint not null check (byte_size > 0 and byte_size <= 52428800),
    client_visible boolean not null default false, uploaded_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(), unique (file_id, version)
);

-- Approval records must exist before approval history adds its foreign key.
create table if not exists public.client_approvals (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    revision text not null,
    token_hash text not null unique,
    recipient_email text,
    status text not null default 'pending' check (status in ('pending','approved','changes-requested','expired','revoked')),
    comment text,
    expires_at timestamptz not null,
    approved_at timestamptz,
    created_by uuid references auth.users(id) on delete set null,
    created_at timestamptz not null default now()
);

create table if not exists public.project_approval_history (
    id uuid primary key default gen_random_uuid(), project_id uuid not null references public.projects(id) on delete cascade,
    approval_id uuid references public.client_approvals(id) on delete cascade, status text not null,
    revision text not null, reviewer_id uuid references auth.users(id) on delete set null,
    reviewer_name text not null default '', comment text not null default '', created_at timestamptz not null default now(),
    constraint project_approval_history_status_check check (status in ('draft','sent_for_review','changes_requested','approved','published'))
);
create index if not exists project_file_versions_project_idx on public.project_file_versions(project_id, created_at desc);

create table if not exists public.project_membership_invitations (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    invited_by uuid not null references auth.users(id) on delete cascade,
    email text not null,
    role text not null check (role in ('admin','sales','marketing','contributor','client_reviewer')),
    token_hash text not null unique,
    status text not null default 'pending' check (status in ('pending','accepted','revoked','expired')),
    expires_at timestamptz not null,
    created_at timestamptz not null default now()
);
create index if not exists project_membership_invitations_project_idx on public.project_membership_invitations(project_id, created_at desc);
alter table public.project_membership_invitations enable row level security;
drop policy if exists project_membership_invitations_manager_access on public.project_membership_invitations;
create policy project_membership_invitations_manager_access on public.project_membership_invitations for all
using (exists (select 1 from public.project_memberships m where m.project_id = project_id and m.user_id = auth.uid() and m.role in ('owner','admin')))
with check (exists (select 1 from public.project_memberships m where m.project_id = project_id and m.user_id = auth.uid() and m.role in ('owner','admin')));

alter table public.project_approval_history drop constraint if exists project_approval_history_status_check;
alter table public.project_approval_history add constraint project_approval_history_status_check check (status in ('draft','sent_for_review','changes_requested','approved','published'));
create index if not exists project_approval_history_project_idx on public.project_approval_history(project_id, created_at desc);
alter table public.project_memberships enable row level security;
alter table public.project_file_versions enable row level security;
alter table public.project_approval_history enable row level security;
drop policy if exists project_memberships_owner_access on public.project_memberships;
drop policy if exists project_file_versions_member_access on public.project_file_versions;
drop policy if exists project_approval_history_member_access on public.project_approval_history;
create policy project_memberships_owner_access on public.project_memberships for all using (exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid())) with check (exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy project_file_versions_member_access on public.project_file_versions for select using (exists (select 1 from public.project_memberships m where m.project_id = project_id and m.user_id = auth.uid()));
create policy project_approval_history_member_access on public.project_approval_history for select using (exists (select 1 from public.project_memberships m where m.project_id = project_id and m.user_id = auth.uid()));
insert into public.project_memberships (project_id, user_id, role) select id, user_id, 'owner' from public.projects on conflict (project_id, user_id) do nothing;
insert into storage.buckets (id, name, public) values ('project-files', 'project-files', false) on conflict (id) do update set public = false;

drop policy if exists project_files_member_read on storage.objects;
drop policy if exists project_files_member_insert on storage.objects;
drop policy if exists project_files_member_delete on storage.objects;
create policy project_files_member_read on storage.objects for select using (bucket_id = 'project-files' and exists (select 1 from public.project_memberships m where m.project_id::text = split_part(name, '/', 1) and m.user_id = auth.uid()));
create policy project_files_member_insert on storage.objects for insert with check (bucket_id = 'project-files' and exists (select 1 from public.project_memberships m where m.project_id::text = split_part(name, '/', 1) and m.user_id = auth.uid() and m.role in ('owner', 'admin', 'contributor')));
create policy project_files_member_delete on storage.objects for delete using (bucket_id = 'project-files' and exists (select 1 from public.project_memberships m where m.project_id::text = split_part(name, '/', 1) and m.user_id = auth.uid() and m.role in ('owner', 'admin', 'contributor')));

-- Explicit, revocable client portal shares and client-authored comments.
create table if not exists public.client_portal_shares (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    created_by uuid not null references auth.users(id) on delete cascade,
    token_hash text not null unique,
    label text not null default 'Client portal',
    expires_at timestamptz not null default (now() + interval '30 days'),
    revoked_at timestamptz,
    created_at timestamptz not null default now(),
    last_accessed_at timestamptz,
    constraint client_portal_share_label_check check (char_length(label) <= 120)
);
create table if not exists public.client_portal_comments (
    id uuid primary key default gen_random_uuid(),
    share_id uuid not null references public.client_portal_shares(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    author_name text not null default 'Client',
    comment text not null,
    created_at timestamptz not null default now(),
    constraint client_portal_comment_size_check check (pg_column_size(author_name) <= 500 and pg_column_size(comment) <= 4000)
);
create index if not exists client_portal_shares_project_idx on public.client_portal_shares(project_id, created_at desc);
create index if not exists client_portal_comments_share_idx on public.client_portal_comments(share_id, created_at asc);
alter table public.client_portal_shares enable row level security;
alter table public.client_portal_comments enable row level security;
drop policy if exists client_portal_shares_owner_access on public.client_portal_shares;
drop policy if exists client_portal_comments_owner_access on public.client_portal_comments;
create policy client_portal_shares_owner_access on public.client_portal_shares for all using (auth.uid() = created_by) with check (auth.uid() = created_by);
create policy client_portal_comments_owner_access on public.client_portal_comments for select using (exists (select 1 from public.client_portal_shares s where s.id = share_id and s.created_by = auth.uid()));