-- Atomic account/project usage quotas. Apply after schema.sql.
create table if not exists public.usage_counters (
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid references public.projects(id) on delete cascade,
    resource text not null,
    period_start timestamptz not null,
    used bigint not null default 0 check (used >= 0),
    updated_at timestamptz not null default now(),
    scope_key text generated always as (coalesce(project_id::text, 'account')) stored,
    primary key (user_id, scope_key, resource, period_start)
);

alter table public.usage_counters enable row level security;
drop policy if exists usage_counters_owner_read on public.usage_counters;
create policy usage_counters_owner_read on public.usage_counters for select using (auth.uid() = user_id);

create or replace function public.consume_usage_quota(
    p_user_id uuid,
    p_project_id uuid,
    p_resource text,
    p_amount integer,
    p_limit bigint,
    p_period text default 'monthly'
) returns table(allowed boolean, used bigint, quota_limit bigint, period_start timestamptz)
language plpgsql security definer set search_path = public, pg_catalog as $$
declare
    v_start timestamptz;
    v_used bigint;
    v_project uuid;
    v_limit bigint;
begin
    v_limit := case p_resource
        when 'projects' then 25
        when 'versions' then 50
        when 'imports' then 100
        when 'ai_generations' then 100
        when 'deployments' then 100
        when 'form_submissions' then 1000
        when 'preview_emails' then 100
        when 'team_members' then 10
        when 'audits' then 100
        when 'storage_bytes' then 4500000
        when 'request_bytes' then 12000000
        else null
    end;
    if v_limit is null or p_limit is distinct from v_limit then
        raise exception 'QUOTA_INPUT_INVALID' using errcode = '22023';
    end if;
    if auth.uid() is null or auth.uid() <> p_user_id then
        raise exception 'QUOTA_AUTHORIZATION_FAILED' using errcode = '42501';
    end if;
    if p_amount is null or p_amount <= 0 or p_amount > 1000000 or p_limit is null or p_limit < 0 then
        raise exception 'QUOTA_INPUT_INVALID' using errcode = '22023';
    end if;
    if p_amount > v_limit then
        return query select false, 0::bigint, v_limit, date_trunc('month', now());
        return;
    end if;
    if p_project_id is not null then
        select id into v_project from public.projects where id = p_project_id and user_id = p_user_id;
        if v_project is null then raise exception 'QUOTA_PROJECT_NOT_FOUND' using errcode = '42501'; end if;
    end if;
    v_start := case when lower(coalesce(p_period, 'monthly')) = 'daily' then date_trunc('day', now()) else date_trunc('month', now()) end;
    insert into public.usage_counters(user_id, project_id, resource, period_start, used)
    values (p_user_id, p_project_id, p_resource, v_start, p_amount)
    on conflict (user_id, scope_key, resource, period_start) do update
        set used = public.usage_counters.used + excluded.used, updated_at = now()
        where public.usage_counters.used + excluded.used <= v_limit
    returning public.usage_counters.used into v_used;
    if v_used is null then
        select u.used into v_used from public.usage_counters u where u.user_id = p_user_id and u.project_id is not distinct from p_project_id and u.resource = p_resource and u.period_start = v_start;
        return query select false, coalesce(v_used, 0), v_limit, v_start;
    end if;
    return query select true, v_used, v_limit, v_start;
end;
$$;
revoke all on function public.consume_usage_quota(uuid, uuid, text, integer, bigint, text) from public;
grant execute on function public.consume_usage_quota(uuid, uuid, text, integer, bigint, text) to authenticated;

create or replace function public.release_usage_quota(p_user_id uuid, p_project_id uuid, p_resource text, p_amount integer, p_period text default 'monthly')
returns bigint language plpgsql security definer set search_path = public, pg_catalog as $$
declare v_start timestamptz; v_used bigint;
begin
    if auth.uid() is null or auth.uid() <> p_user_id then raise exception 'QUOTA_AUTHORIZATION_FAILED' using errcode = '42501'; end if;
    if p_amount is null or p_amount <= 0 then raise exception 'QUOTA_INPUT_INVALID' using errcode = '22023'; end if;
    v_start := case when lower(coalesce(p_period, 'monthly')) = 'daily' then date_trunc('day', now()) else date_trunc('month', now()) end;
    update public.usage_counters set used=greatest(0, used-p_amount), updated_at=now()
    where user_id=p_user_id and project_id is not distinct from p_project_id and resource=p_resource and period_start=v_start returning used into v_used;
    return coalesce(v_used, 0);
end $$;
revoke all on function public.release_usage_quota(uuid,uuid,text,integer,text) from public;
grant execute on function public.release_usage_quota(uuid,uuid,text,integer,text) to authenticated;

-- Reservation records make compensating releases idempotent: a failed operation
-- can release its own reservation once without decrementing another request.
create table if not exists public.usage_quota_reservations (
    id uuid primary key,
    user_id uuid not null references auth.users(id) on delete cascade,
    project_id uuid references public.projects(id) on delete cascade,
    resource text not null,
    amount integer not null check (amount > 0),
    period text not null check (period in ('daily', 'monthly')),
    period_start timestamptz not null,
    state text not null default 'reserved' check (state in ('reserved', 'committed', 'released')),
    created_at timestamptz not null default now(),
    released_at timestamptz
);
alter table public.usage_quota_reservations enable row level security;
drop policy if exists usage_quota_reservations_owner_read on public.usage_quota_reservations;
create policy usage_quota_reservations_owner_read on public.usage_quota_reservations for select using (auth.uid() = user_id);

create or replace function public.reserve_usage_quota(p_reservation_id uuid, p_user_id uuid, p_project_id uuid, p_resource text, p_amount integer, p_limit bigint, p_period text default 'monthly')
returns table(allowed boolean, used bigint, quota_limit bigint, period_start timestamptz)
language plpgsql security definer set search_path = public, pg_catalog as $$
declare result record;
begin
    if p_reservation_id is null then raise exception 'QUOTA_INPUT_INVALID' using errcode = '22023'; end if;
    select * into result from public.consume_usage_quota(p_user_id, p_project_id, p_resource, p_amount, p_limit, p_period);
    if result.allowed then
        insert into public.usage_quota_reservations(id, user_id, project_id, resource, amount, period, period_start)
        values (p_reservation_id, p_user_id, p_project_id, p_resource, p_amount, lower(coalesce(p_period, 'monthly')), result.period_start);
    end if;
    return query select result.allowed, result.used, result.quota_limit, result.period_start;
end $$;

create or replace function public.commit_usage_quota_reservation(p_reservation_id uuid, p_user_id uuid)
returns boolean language plpgsql security definer set search_path = public, pg_catalog as $$
begin
    if auth.uid() is null or auth.uid() <> p_user_id then raise exception 'QUOTA_AUTHORIZATION_FAILED' using errcode = '42501'; end if;
    update public.usage_quota_reservations set state='committed' where id=p_reservation_id and user_id=p_user_id and state='reserved';
    return found;
end $$;

create or replace function public.release_usage_quota_reservation(p_reservation_id uuid, p_user_id uuid)
returns boolean language plpgsql security definer set search_path = public, pg_catalog as $$
declare reservation public.usage_quota_reservations%rowtype;
begin
    if auth.uid() is null or auth.uid() <> p_user_id then raise exception 'QUOTA_AUTHORIZATION_FAILED' using errcode = '42501'; end if;
    select * into reservation from public.usage_quota_reservations where id=p_reservation_id and user_id=p_user_id for update;
    if reservation.id is null or reservation.state <> 'reserved' then return false; end if;
    update public.usage_counters set used=greatest(0, used-reservation.amount), updated_at=now()
    where user_id=reservation.user_id and project_id is not distinct from reservation.project_id and resource=reservation.resource and period_start=reservation.period_start;
    update public.usage_quota_reservations set state='released', released_at=now() where id=p_reservation_id;
    return true;
end $$;

revoke all on function public.reserve_usage_quota(uuid,uuid,uuid,text,integer,bigint,text) from public;
revoke all on function public.commit_usage_quota_reservation(uuid,uuid) from public;
revoke all on function public.release_usage_quota_reservation(uuid,uuid) from public;
grant execute on function public.reserve_usage_quota(uuid,uuid,uuid,text,integer,bigint,text) to authenticated;
grant execute on function public.commit_usage_quota_reservation(uuid,uuid) to authenticated;
grant execute on function public.release_usage_quota_reservation(uuid,uuid) to authenticated;

-- Public project form quota. The project owner is resolved inside the function so
-- anonymous visitors cannot bypass the owner's project-scoped submission limit.
create or replace function public.consume_public_project_quota(
    p_project_id uuid,
    p_resource text,
    p_amount integer,
    p_limit bigint,
    p_period text default 'monthly'
) returns table(allowed boolean, used bigint, quota_limit bigint, period_start timestamptz)
language plpgsql security definer set search_path = public, pg_catalog as $$
declare
    v_user_id uuid;
    v_start timestamptz;
    v_used bigint;
    v_limit bigint;
begin
    v_limit := case p_resource
        when 'form_submissions' then 1000
        when 'storage_bytes' then 4500000
        else null
    end;
    if v_limit is null or p_limit is distinct from v_limit or p_amount is null or p_amount <= 0 or p_amount > 50000000 then
        raise exception 'QUOTA_INPUT_INVALID' using errcode = '22023';
    end if;
    select user_id into v_user_id from public.projects where id = p_project_id;
    if v_user_id is null then raise exception 'QUOTA_PROJECT_NOT_FOUND' using errcode = '42501'; end if;
    v_start := case when lower(coalesce(p_period, 'monthly')) = 'daily' then date_trunc('day', now()) else date_trunc('month', now()) end;
    insert into public.usage_counters(user_id, project_id, resource, period_start, used)
    values (v_user_id, p_project_id, p_resource, v_start, p_amount)
    on conflict (user_id, scope_key, resource, period_start) do update
        set used = public.usage_counters.used + excluded.used, updated_at = now()
        where public.usage_counters.used + excluded.used <= p_limit
    returning public.usage_counters.used into v_used;
    if v_used is null then
        select used into v_used from public.usage_counters where user_id = v_user_id and project_id = p_project_id and resource = p_resource and period_start = v_start;
        return query select false, coalesce(v_used, 0), p_limit, v_start;
    end if;
    return query select true, v_used, p_limit, v_start;
end;
$$;
revoke all on function public.consume_public_project_quota(uuid, text, integer, bigint, text) from public;
grant execute on function public.consume_public_project_quota(uuid, text, integer, bigint, text) to anon, authenticated;
