-- Shared evidence records for the lead -> audit -> remediation loop.
create table if not exists public.website_audits (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    lead_id uuid references public.leads(id) on delete set null,
    user_id uuid not null references auth.users(id) on delete cascade,
    website_url text not null,
    final_url text not null default '',
    state text not null default 'not-audited' check (state in ('not-audited','audit-in-progress','audit-complete','needs-review','fix-ready')),
    requested_at timestamptz not null default now(),
    checked_at timestamptz,
    source_evidence jsonb not null default '{}'::jsonb,
    technical jsonb not null default '{}'::jsonb,
    content jsonb not null default '{}'::jsonb,
    visual jsonb not null default '{}'::jsonb,
    findings jsonb not null default '[]'::jsonb,
    remediation jsonb not null default '{"status":"not-started"}'::jsonb,
    error text not null default '',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (project_id, website_url)
);

create index if not exists website_audits_project_state_idx on public.website_audits(project_id, state, updated_at desc);
create index if not exists website_audits_lead_idx on public.website_audits(lead_id, updated_at desc);
alter table public.website_audits enable row level security;
drop policy if exists website_audits_owner_access on public.website_audits;
create policy website_audits_owner_access on public.website_audits for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.touch_website_audit_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists website_audits_updated_at on public.website_audits;
create trigger website_audits_updated_at before update on public.website_audits for each row execute function public.touch_website_audit_updated_at();

-- Findings are independently addressable so fixes can be approved and rolled back.
create table if not exists public.audit_findings (
    id uuid primary key default gen_random_uuid(),
    audit_id uuid not null references public.website_audits(id) on delete cascade,
    project_id uuid not null references public.projects(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    issue text not null default '', evidence jsonb not null default '{}'::jsonb,
    impact text not null default 'medium' check (impact in ('high','medium','low')),
    recommendation text not null default '', confidence numeric not null default 0 check (confidence >= 0 and confidence <= 1),
    remediation text not null default 'review-required' check (remediation in ('safe-auto','review-required','blocked')),
    status text not null default 'open' check (status in ('open','accepted','fixed','wont-fix')),
    created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists audit_findings_audit_idx on public.audit_findings(audit_id, impact, status);

-- Reviewable generator revisions retain a complete audit-to-deployment trail.
create table if not exists public.site_revisions (
    id uuid primary key default gen_random_uuid(),
    project_id uuid not null references public.projects(id) on delete cascade,
    lead_id uuid references public.leads(id) on delete set null,
    audit_id uuid references public.website_audits(id) on delete set null,
    user_id uuid not null references auth.users(id) on delete cascade,
    parent_revision_id uuid references public.site_revisions(id) on delete set null,
    status text not null default 'draft' check (status in ('draft','validation-failed','ready-for-review','approved','rejected','deployed','rolled-back')),
    base_version text not null default '',
    brief jsonb not null default '{}'::jsonb,
    changes jsonb not null default '[]'::jsonb,
    validation jsonb not null default '{}'::jsonb,
    approved_at timestamptz,
    approved_by uuid references auth.users(id) on delete set null,
    before_scores jsonb not null default '{}'::jsonb,
    after_scores jsonb not null default '{}'::jsonb,
    screenshots jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create index if not exists site_revisions_project_idx on public.site_revisions(project_id, created_at desc);
create index if not exists site_revisions_audit_idx on public.site_revisions(audit_id, created_at desc);
alter table public.site_revisions add column if not exists deployment_id text;
alter table public.site_revisions add column if not exists before_scores jsonb not null default '{}'::jsonb;
alter table public.site_revisions add column if not exists after_scores jsonb not null default '{}'::jsonb;
alter table public.site_revisions add column if not exists screenshots jsonb not null default '{}'::jsonb;
alter table public.site_revisions enable row level security;
drop policy if exists site_revisions_owner_access on public.site_revisions;
create policy site_revisions_owner_access on public.site_revisions for all using (exists (select 1 from public.projects p where p.id = site_revisions.project_id and p.user_id = auth.uid())) with check (exists (select 1 from public.projects p where p.id = site_revisions.project_id and p.user_id = auth.uid()));

create or replace function public.touch_site_revision_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists site_revisions_updated_at on public.site_revisions;
create trigger site_revisions_updated_at before update on public.site_revisions for each row execute function public.touch_site_revision_updated_at();
alter table public.audit_findings enable row level security;
drop policy if exists audit_findings_owner_access on public.audit_findings;
create policy audit_findings_owner_access on public.audit_findings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
