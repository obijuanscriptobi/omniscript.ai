-- Defense-in-depth tenant isolation for project-owned records.
-- Run after schema.sql, multi-tenant-milestone.sql, work-contexts.sql,
-- next-steps.sql, website-audits.sql, platform.sql, and
-- collaboration-security.sql.

-- A project is usable only when its work context belongs to an organization
-- containing the authenticated user. Child-table policies delegate to this
-- function so project ownership and context membership cannot drift apart.
-- Membership state is explicit so removing access does not require deleting
-- the audit trail. Existing memberships remain active during migration.
alter table public.organization_members
    add column if not exists status text not null default 'active';
alter table public.organization_members
    add column if not exists revoked_at timestamptz;
alter table public.organization_members
    drop constraint if exists organization_members_status_check;
alter table public.organization_members
    add constraint organization_members_status_check
    check (status in ('active', 'revoked'));
create index if not exists organization_members_active_user_idx
    on public.organization_members(user_id, organization_id)
    where status = 'active' and revoked_at is null;

create or replace function public.can_access_project_context(target_project uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_catalog
as $$
    select exists (
        select 1
        from public.projects p
        join public.work_contexts c on c.id = p.work_context_id
        join public.organization_members m on m.organization_id = c.organization_id
        where p.id = target_project
          and p.organization_id = c.organization_id
          and c.status = 'active'
          and m.user_id = auth.uid()
          and m.status = 'active'
          and m.revoked_at is null
    );
$$;

revoke all on function public.can_access_project_context(uuid) from public;
grant execute on function public.can_access_project_context(uuid) to authenticated;

-- Projects themselves require both organization membership and an active
-- context in that same organization. WITH CHECK also protects reassignment.
alter table public.projects enable row level security;
drop policy if exists projects_owner_access on public.projects;
drop policy if exists projects_context_member_access on public.projects;
create policy projects_context_member_access on public.projects
for all
using (public.can_access_project_context(id))
with check (
    work_context_id is not null
    and exists (
        select 1
        from public.work_contexts c
        join public.organization_members m on m.organization_id = c.organization_id
        where c.id = projects.work_context_id
          and c.organization_id = projects.organization_id
          and c.status = 'active'
          and m.user_id = auth.uid()
          and m.status = 'active'
          and m.revoked_at is null
    )
);

-- Tasks, CRM records, profiles, appointments, audits, findings, revisions,
-- drafts, and activity are authorized through their owning project. These
-- policies protect browser/database access even if an API regression occurs.
alter table public.next_steps enable row level security;
drop policy if exists next_steps_owner_policy on public.next_steps;
drop policy if exists next_steps_context_access on public.next_steps;
create policy next_steps_context_access on public.next_steps for all
using (public.can_access_project_context(project_id))
with check (auth.uid() = user_id and public.can_access_project_context(project_id));

alter table public.leads enable row level security;
drop policy if exists leads_owner_access on public.leads;
drop policy if exists leads_context_access on public.leads;
create policy leads_context_access on public.leads for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.business_profiles enable row level security;
drop policy if exists business_profiles_owner_access on public.business_profiles;
drop policy if exists business_profiles_context_access on public.business_profiles;
create policy business_profiles_context_access on public.business_profiles for all
using (project_id is not null and public.can_access_project_context(project_id))
with check (project_id is not null and public.can_access_project_context(project_id));

alter table public.appointments enable row level security;
drop policy if exists appointments_member_access on public.appointments;
drop policy if exists appointments_context_access on public.appointments;
create policy appointments_context_access on public.appointments for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.website_drafts enable row level security;
drop policy if exists website_drafts_member_access on public.website_drafts;
drop policy if exists website_drafts_context_access on public.website_drafts;
create policy website_drafts_context_access on public.website_drafts for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.website_audits enable row level security;
drop policy if exists website_audits_owner_access on public.website_audits;
drop policy if exists website_audits_context_access on public.website_audits;
create policy website_audits_context_access on public.website_audits for all
using (public.can_access_project_context(project_id))
with check (auth.uid() = user_id and public.can_access_project_context(project_id));

alter table public.audit_findings enable row level security;
drop policy if exists audit_findings_owner_access on public.audit_findings;
drop policy if exists audit_findings_context_access on public.audit_findings;
create policy audit_findings_context_access on public.audit_findings for all
using (public.can_access_project_context(project_id))
with check (auth.uid() = user_id and public.can_access_project_context(project_id));

alter table public.site_revisions enable row level security;
drop policy if exists site_revisions_owner_access on public.site_revisions;
drop policy if exists site_revisions_context_access on public.site_revisions;
create policy site_revisions_context_access on public.site_revisions for all
using (public.can_access_project_context(project_id))
with check (auth.uid() = user_id and public.can_access_project_context(project_id));

alter table public.activity_events enable row level security;
drop policy if exists activity_events_member_access on public.activity_events;
drop policy if exists activity_events_context_access on public.activity_events;
drop policy if exists activity_events_context_insert on public.activity_events;
create policy activity_events_context_access on public.activity_events for select
using (project_id is not null and public.can_access_project_context(project_id));
create policy activity_events_context_insert on public.activity_events for insert
with check (
    actor_id = auth.uid()
    and project_id is not null
    and public.can_access_project_context(project_id)
);

-- Approval decisions and their history remain attached to the same accessible
-- project. Public token decisions continue to flow through the server handler.
alter table public.client_approvals add column if not exists updated_at timestamptz not null default now();
create or replace function public.touch_client_approval_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end;
$$;
drop trigger if exists client_approvals_updated_at on public.client_approvals;
create trigger client_approvals_updated_at before update on public.client_approvals
for each row execute function public.touch_client_approval_updated_at();
alter table public.client_approvals enable row level security;
drop policy if exists approval_access on public.client_approvals;
drop policy if exists client_approvals_context_access on public.client_approvals;
create policy client_approvals_context_access on public.client_approvals for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.project_approval_history enable row level security;
drop policy if exists project_approval_history_member_access on public.project_approval_history;
drop policy if exists project_approval_history_context_access on public.project_approval_history;
create policy project_approval_history_context_access on public.project_approval_history for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

-- Remaining project-owned domains use the same active-context boundary.
alter table public.project_versions enable row level security;
drop policy if exists project_versions_context_access on public.project_versions;
create policy project_versions_context_access on public.project_versions for all
using (auth.uid() = user_id and public.can_access_project_context(project_id))
with check (auth.uid() = user_id and public.can_access_project_context(project_id));

alter table public.profile_revisions enable row level security;
drop policy if exists profile_revisions_member_access on public.profile_revisions;
drop policy if exists profile_revisions_context_access on public.profile_revisions;
create policy profile_revisions_context_access on public.profile_revisions for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.business_operations enable row level security;
drop policy if exists business_operations_owner_access on public.business_operations;
drop policy if exists business_operations_context_access on public.business_operations;
create policy business_operations_context_access on public.business_operations for all
using (auth.uid() = user_id and public.can_access_project_context(project_id))
with check (auth.uid() = user_id and public.can_access_project_context(project_id));

-- Upload metadata is created before bytes arrive, then moves through a
-- fail-closed verification state. Existing records are trusted only during the
-- migration backfill; every new upload starts pending.
alter table public.project_file_versions add column if not exists work_context_id uuid references public.work_contexts(id) on delete restrict;
alter table public.project_file_versions add column if not exists verification_status text not null default 'pending';
alter table public.project_file_versions add column if not exists detected_mime_type text;
alter table public.project_file_versions add column if not exists sha256 text;
alter table public.project_file_versions add column if not exists upload_expires_at timestamptz;
alter table public.project_file_versions add column if not exists verified_at timestamptz;
alter table public.project_file_versions add column if not exists verified_by uuid references auth.users(id) on delete set null;
alter table public.project_file_versions add column if not exists portal_share_id uuid references public.client_portal_shares(id) on delete set null;
alter table public.project_file_versions add column if not exists asset_rights_confirmed boolean not null default false;
alter table public.project_file_versions add column if not exists asset_rights_source text not null default '';
update public.project_file_versions f set work_context_id = p.work_context_id
from public.projects p where p.id = f.project_id and f.work_context_id is null;
-- Legacy objects cannot be assigned a checksum without reading their bytes.
-- Quarantine them rather than falsely marking uninspected content as verified.
update public.project_file_versions
set verification_status = 'quarantined', detected_mime_type = mime_type,
    verified_at = coalesce(verified_at, created_at),
    asset_rights_source = case when asset_rights_source = '' then 'legacy-unverified' else asset_rights_source end
where verification_status = 'pending' and upload_expires_at is null;
alter table public.project_file_versions alter column work_context_id set not null;
alter table public.project_file_versions drop constraint if exists project_file_versions_verification_status_check;
alter table public.project_file_versions add constraint project_file_versions_verification_status_check
check (verification_status in ('pending','verified','quarantined'));
alter table public.project_file_versions drop constraint if exists project_file_versions_sha256_check;
alter table public.project_file_versions add constraint project_file_versions_sha256_check
check (sha256 is null or sha256 ~ '^[a-f0-9]{64}$');
alter table public.project_file_versions drop constraint if exists project_file_versions_asset_rights_source_check;
alter table public.project_file_versions add constraint project_file_versions_asset_rights_source_check
check (char_length(asset_rights_source) <= 200);
create unique index if not exists project_file_versions_storage_path_idx
    on public.project_file_versions(storage_path);
alter table public.project_file_versions drop constraint if exists project_file_versions_verification_check;
alter table public.project_file_versions add constraint project_file_versions_verification_check check (
    (verification_status = 'pending' and upload_expires_at is not null and verified_at is null and sha256 is null)
    or (verification_status = 'verified' and verified_at is not null and sha256 is not null and detected_mime_type is not null and asset_rights_confirmed)
    or (verification_status = 'quarantined' and verified_at is not null)
);
create index if not exists project_file_versions_verification_idx
    on public.project_file_versions(project_id, work_context_id, verification_status, created_at desc);

alter table public.project_file_versions enable row level security;
drop policy if exists project_file_versions_member_access on public.project_file_versions;
drop policy if exists project_file_versions_context_access on public.project_file_versions;
create policy project_file_versions_context_access on public.project_file_versions for all
using (work_context_id = (select p.work_context_id from public.projects p where p.id = project_id) and public.can_access_project_context(project_id))
with check (uploaded_by = auth.uid() and work_context_id = (select p.work_context_id from public.projects p where p.id = project_id) and public.can_access_project_context(project_id));

-- Direct storage reads are allowed only after metadata verification. Pending
-- and quarantined objects remain unavailable even to authenticated members.
drop policy if exists project_files_member_read on storage.objects;
create policy project_files_member_read on storage.objects for select using (
    bucket_id = 'project-files'
    and exists (
        select 1 from public.project_file_versions f
        where f.storage_path = storage.objects.name
          and f.verification_status = 'verified'
          and f.work_context_id = (select p.work_context_id from public.projects p where p.id = f.project_id)
          and public.can_access_project_context(f.project_id)
    )
);

alter table public.project_assets enable row level security;
drop policy if exists asset_access on public.project_assets;
drop policy if exists project_assets_context_access on public.project_assets;
create policy project_assets_context_access on public.project_assets for all
using (public.can_access_project_context(project_id))
with check (created_by = auth.uid() and public.can_access_project_context(project_id));

alter table public.project_membership_invitations enable row level security;
drop policy if exists project_membership_invitations_manager_access on public.project_membership_invitations;
drop policy if exists project_membership_invitations_context_access on public.project_membership_invitations;
create policy project_membership_invitations_context_access on public.project_membership_invitations for all
using (public.can_access_project_context(project_id))
with check (invited_by = auth.uid() and public.can_access_project_context(project_id));

alter table public.client_portal_shares enable row level security;
drop policy if exists client_portal_shares_owner_access on public.client_portal_shares;
drop policy if exists client_portal_shares_context_access on public.client_portal_shares;
create policy client_portal_shares_context_access on public.client_portal_shares for all
using (created_by = auth.uid() and public.can_access_project_context(project_id))
with check (created_by = auth.uid() and public.can_access_project_context(project_id));

alter table public.client_portal_comments enable row level security;
drop policy if exists client_portal_comments_owner_access on public.client_portal_comments;
drop policy if exists client_portal_comments_context_access on public.client_portal_comments;
create policy client_portal_comments_context_access on public.client_portal_comments for select
using (public.can_access_project_context(project_id));

alter table public.project_environments enable row level security;
drop policy if exists project_environment_access on public.project_environments;
drop policy if exists project_environments_context_access on public.project_environments;
create policy project_environments_context_access on public.project_environments for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.platform_deployments enable row level security;
drop policy if exists deployment_access on public.platform_deployments;
drop policy if exists platform_deployments_context_access on public.platform_deployments;
create policy platform_deployments_context_access on public.platform_deployments for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.project_locales enable row level security;
drop policy if exists locale_access on public.project_locales;
drop policy if exists project_locales_context_access on public.project_locales;
create policy project_locales_context_access on public.project_locales for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.project_experiments enable row level security;
drop policy if exists experiment_access on public.project_experiments;
drop policy if exists project_experiments_context_access on public.project_experiments;
create policy project_experiments_context_access on public.project_experiments for all
using (public.can_access_project_context(project_id))
with check (public.can_access_project_context(project_id));

alter table public.analytics_events enable row level security;
drop policy if exists analytics_access on public.analytics_events;
drop policy if exists analytics_events_context_read on public.analytics_events;
create policy analytics_events_context_read on public.analytics_events for select
using (public.can_access_project_context(project_id));

-- Index every authorization and parent lookup used by RLS and server filters.
create index if not exists project_versions_project_user_idx on public.project_versions(project_id, user_id);
create index if not exists profile_revisions_project_idx on public.profile_revisions(project_id, profile_id);
create index if not exists business_operations_project_user_idx on public.business_operations(project_id, user_id, updated_at desc);
create index if not exists project_assets_project_creator_idx on public.project_assets(project_id, created_by);
create index if not exists client_approvals_project_token_idx on public.client_approvals(project_id, token_hash);
create index if not exists portal_shares_project_token_idx on public.client_portal_shares(project_id, token_hash);
create index if not exists audit_findings_parent_idx on public.audit_findings(audit_id, project_id);
create index if not exists site_revisions_parent_idx on public.site_revisions(parent_revision_id, project_id);
create index if not exists project_file_versions_project_file_idx on public.project_file_versions(project_id, file_id, version desc);
create index if not exists project_membership_invitations_project_token_idx on public.project_membership_invitations(project_id, token_hash);
create index if not exists client_portal_comments_parent_idx on public.client_portal_comments(share_id, project_id);
create index if not exists platform_deployments_environment_project_idx on public.platform_deployments(environment_id, project_id);
create index if not exists analytics_revision_project_idx on public.analytics_events(revision_id, project_id);
create index if not exists analytics_experiment_project_idx on public.analytics_events(experiment_id, project_id);

-- Public credentials are stored only as lowercase SHA-256 digests.
alter table public.client_approvals drop constraint if exists client_approvals_token_hash_check;
alter table public.client_approvals add constraint client_approvals_token_hash_check
check (token_hash ~ '^[a-f0-9]{64}$');
alter table public.project_membership_invitations drop constraint if exists project_membership_invitations_token_hash_check;
alter table public.project_membership_invitations add constraint project_membership_invitations_token_hash_check
check (token_hash ~ '^[a-f0-9]{64}$');
alter table public.client_portal_shares drop constraint if exists client_portal_shares_token_hash_check;
alter table public.client_portal_shares add constraint client_portal_shares_token_hash_check
check (token_hash ~ '^[a-f0-9]{64}$');

-- A client-chosen UUID cannot be moved between projects after creation.
create or replace function public.prevent_project_owned_id_reassignment()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if new.project_id is distinct from old.project_id then
        raise exception 'Project-owned record cannot be reassigned' using errcode = '23514';
    end if;
    return new;
end;
$$;
drop trigger if exists next_steps_project_guard on public.next_steps;
create trigger next_steps_project_guard before update of project_id on public.next_steps
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists project_files_project_guard on public.project_file_versions;
create trigger project_files_project_guard before update of project_id on public.project_file_versions
for each row execute function public.prevent_project_owned_id_reassignment();

create or replace function public.enforce_project_file_context()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if not exists (
        select 1 from public.projects p
        where p.id = new.project_id and p.work_context_id = new.work_context_id
    ) then raise exception 'Project file context does not match its project' using errcode = '23514'; end if;
    return new;
end;
$$;
drop trigger if exists project_files_context_guard on public.project_file_versions;
create trigger project_files_context_guard
before insert or update of project_id, work_context_id on public.project_file_versions
for each row execute function public.enforce_project_file_context();
drop trigger if exists project_assets_project_guard on public.project_assets;
create trigger project_assets_project_guard before update of project_id on public.project_assets
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists client_approvals_project_guard on public.client_approvals;
create trigger client_approvals_project_guard before update of project_id on public.client_approvals
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists business_operations_project_guard on public.business_operations;
create trigger business_operations_project_guard before update of project_id on public.business_operations
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists audit_findings_reassignment_guard on public.audit_findings;
create trigger audit_findings_reassignment_guard before update of project_id on public.audit_findings
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists site_revisions_reassignment_guard on public.site_revisions;
create trigger site_revisions_reassignment_guard before update of project_id on public.site_revisions
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists client_approvals_reassignment_guard on public.client_approvals;
create trigger client_approvals_reassignment_guard before update of project_id on public.client_approvals
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists project_membership_invitations_reassignment_guard on public.project_membership_invitations;
create trigger project_membership_invitations_reassignment_guard before update of project_id on public.project_membership_invitations
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists client_portal_shares_reassignment_guard on public.client_portal_shares;
create trigger client_portal_shares_reassignment_guard before update of project_id on public.client_portal_shares
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists approval_history_reassignment_guard on public.project_approval_history;
create trigger approval_history_reassignment_guard before update of project_id on public.project_approval_history
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists portal_comments_reassignment_guard on public.client_portal_comments;
create trigger portal_comments_reassignment_guard before update of project_id on public.client_portal_comments
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists project_environments_reassignment_guard on public.project_environments;
create trigger project_environments_reassignment_guard before update of project_id on public.project_environments
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists platform_deployments_reassignment_guard on public.platform_deployments;
create trigger platform_deployments_reassignment_guard before update of project_id on public.platform_deployments
for each row execute function public.prevent_project_owned_id_reassignment();
drop trigger if exists project_experiments_reassignment_guard on public.project_experiments;
create trigger project_experiments_reassignment_guard before update of project_id on public.project_experiments
for each row execute function public.prevent_project_owned_id_reassignment();

-- Prevent a finding from claiming an audit owned by another project.
create or replace function public.enforce_audit_finding_project()
returns trigger
language plpgsql
security invoker
set search_path = public, pg_catalog
as $$
begin
    if not exists (
        select 1 from public.website_audits a
        where a.id = new.audit_id and a.project_id = new.project_id
    ) then
        raise exception 'Audit finding project does not match its audit'
            using errcode = '23514';
    end if;
    return new;
end;
$$;

drop trigger if exists audit_findings_project_guard on public.audit_findings;
create trigger audit_findings_project_guard
before insert or update of audit_id, project_id on public.audit_findings
for each row execute function public.enforce_audit_finding_project();

-- Revisions may reference evidence only from their own project.
create or replace function public.enforce_revision_evidence_project()
returns trigger
language plpgsql
security invoker
set search_path = public, pg_catalog
as $$
begin
    if new.audit_id is not null and not exists (
        select 1 from public.website_audits a
        where a.id = new.audit_id and a.project_id = new.project_id
    ) then
        raise exception 'Revision audit does not match its project'
            using errcode = '23514';
    end if;
    if new.parent_revision_id is not null and not exists (
        select 1 from public.site_revisions r
        where r.id = new.parent_revision_id and r.project_id = new.project_id
    ) then
        raise exception 'Parent revision does not match its project'
            using errcode = '23514';
    end if;
    return new;
end;
$$;

drop trigger if exists site_revisions_evidence_guard on public.site_revisions;
create trigger site_revisions_evidence_guard
before insert or update of audit_id, parent_revision_id, project_id on public.site_revisions
for each row execute function public.enforce_revision_evidence_project();

-- Generic child/parent guards for tables that duplicate project_id for fast,
-- explicit service-role filtering.
create or replace function public.enforce_approval_history_project()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if new.approval_id is not null and not exists (
        select 1 from public.client_approvals a
        where a.id = new.approval_id and a.project_id = new.project_id
    ) then raise exception 'Approval history project does not match its approval' using errcode = '23514'; end if;
    return new;
end;
$$;
drop trigger if exists approval_history_project_guard on public.project_approval_history;
create trigger approval_history_project_guard
before insert or update of approval_id, project_id on public.project_approval_history
for each row execute function public.enforce_approval_history_project();

create or replace function public.enforce_portal_comment_project()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if not exists (
        select 1 from public.client_portal_shares s
        where s.id = new.share_id and s.project_id = new.project_id
    ) then raise exception 'Portal comment project does not match its share' using errcode = '23514'; end if;
    return new;
end;
$$;
drop trigger if exists portal_comments_project_guard on public.client_portal_comments;
create trigger portal_comments_project_guard
before insert or update of share_id, project_id on public.client_portal_comments
for each row execute function public.enforce_portal_comment_project();

create or replace function public.enforce_profile_revision_project()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if new.project_id is null or not exists (
        select 1 from public.business_profiles p
        where p.id = new.profile_id and p.project_id = new.project_id
          and p.organization_id = new.organization_id
    ) then raise exception 'Profile revision scope does not match its profile' using errcode = '23514'; end if;
    return new;
end;
$$;
drop trigger if exists profile_revisions_project_guard on public.profile_revisions;
create trigger profile_revisions_project_guard
before insert or update of profile_id, project_id, organization_id on public.profile_revisions
for each row execute function public.enforce_profile_revision_project();

create or replace function public.enforce_deployment_environment_project()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if not exists (
        select 1 from public.project_environments e
        where e.id = new.environment_id and e.project_id = new.project_id
    ) then raise exception 'Deployment project does not match its environment' using errcode = '23514'; end if;
    return new;
end;
$$;
drop trigger if exists platform_deployments_project_guard on public.platform_deployments;
create trigger platform_deployments_project_guard
before insert or update of environment_id, project_id on public.platform_deployments
for each row execute function public.enforce_deployment_environment_project();

create or replace function public.enforce_analytics_event_project()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if new.revision_id is not null and not exists (
        select 1 from public.site_revisions r
        where r.id = new.revision_id and r.project_id = new.project_id
    ) then raise exception 'Analytics revision does not match its project' using errcode = '23514'; end if;
    if new.experiment_id is not null and not exists (
        select 1 from public.project_experiments e
        where e.id = new.experiment_id and e.project_id = new.project_id
    ) then raise exception 'Analytics experiment does not match its project' using errcode = '23514'; end if;
    return new;
end;
$$;
drop trigger if exists analytics_events_project_guard on public.analytics_events;
create trigger analytics_events_project_guard
before insert or update of revision_id, experiment_id, project_id on public.analytics_events
for each row execute function public.enforce_analytics_event_project();

-- Context reassignment is a privileged lifecycle operation, not an ordinary
-- project edit. Block it while externally visible or dependent records exist.
create or replace function public.prevent_unsafe_project_context_reassignment()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin
    if new.work_context_id is distinct from old.work_context_id and (
        exists (select 1 from public.project_file_versions f where f.project_id = old.id)
        or exists (select 1 from public.project_assets a where a.project_id = old.id)
        or exists (select 1 from public.client_approvals a where a.project_id = old.id and a.status = 'pending' and a.expires_at > now())
        or exists (select 1 from public.client_portal_shares s where s.project_id = old.id and s.revoked_at is null and s.expires_at > now())
        or exists (select 1 from public.site_revisions r where r.project_id = old.id)
        or exists (select 1 from public.business_operations o where o.project_id = old.id)
        or exists (select 1 from public.project_membership_invitations i where i.project_id = old.id and i.status = 'pending' and i.expires_at > now())
        or exists (select 1 from public.project_approval_history h where h.project_id = old.id)
        or exists (select 1 from public.platform_deployments d where d.project_id = old.id)
        or exists (select 1 from public.project_experiments e where e.project_id = old.id)
        -- proposal-handoffs.sql installs an additional guard for durable proposals
        -- and completed handoffs because that migration is applied after this one.
    ) then
        raise exception 'Project context reassignment requires an audited transfer'
            using errcode = '23514';
    end if;
    return new;
end;
$$;
drop trigger if exists projects_context_reassignment_guard on public.projects;
create trigger projects_context_reassignment_guard
before update of work_context_id on public.projects
for each row execute function public.prevent_unsafe_project_context_reassignment();

-- Security-definer helpers are internal authorization primitives.
revoke all on function public.prevent_project_owned_id_reassignment() from public;
revoke all on function public.touch_client_approval_updated_at() from public;
revoke all on function public.enforce_project_file_context() from public;
revoke all on function public.enforce_audit_finding_project() from public;
revoke all on function public.enforce_revision_evidence_project() from public;
revoke all on function public.enforce_approval_history_project() from public;
revoke all on function public.enforce_portal_comment_project() from public;
revoke all on function public.enforce_profile_revision_project() from public;
revoke all on function public.enforce_deployment_environment_project() from public;
revoke all on function public.enforce_analytics_event_project() from public;
revoke all on function public.prevent_unsafe_project_context_reassignment() from public;
