-- Cloud-backed My business and client work contexts.
-- Run after supabase/schema.sql and supabase/multi-tenant-milestone.sql.
create extension if not exists pgcrypto;

create table if not exists public.work_contexts (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null references public.organizations(id) on delete cascade,
    external_key text not null,
    kind text not null check (kind in ('own','client')),
    name text not null,
    project_name text not null default '',
    approval_contact text not null default '',
    permissions_confirmed boolean not null default false,
    asset_rights_confirmed boolean not null default false,
    status text not null default 'active' check (status in ('active','archived')),
    created_by uuid not null references auth.users(id) on delete restrict,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, external_key)
);

alter table public.projects add column if not exists work_context_id uuid references public.work_contexts(id) on delete restrict;
create index if not exists work_contexts_org_status_idx on public.work_contexts(organization_id, status, updated_at desc);
create index if not exists projects_work_context_idx on public.projects(work_context_id, updated_at desc);

-- Every organization has exactly one canonical own-business context.
insert into public.work_contexts (organization_id, external_key, kind, name, project_name, permissions_confirmed, asset_rights_confirmed, created_by)
select o.id, 'own-business', 'own', 'My business', 'Business website', true, true, o.created_by
from public.organizations o
on conflict (organization_id, external_key) do nothing;

update public.projects p
set work_context_id = c.id
from public.work_contexts c
where p.organization_id = c.organization_id
  and c.external_key = 'own-business'
  and p.work_context_id is null;

alter table public.work_contexts enable row level security;
drop policy if exists work_context_member_read on public.work_contexts;
drop policy if exists work_context_manager_insert on public.work_contexts;
drop policy if exists work_context_manager_update on public.work_contexts;
drop policy if exists work_context_owner_delete on public.work_contexts;
create policy work_context_member_read on public.work_contexts for select
using (public.is_org_member(organization_id));
create policy work_context_manager_insert on public.work_contexts for insert
with check (public.is_org_member(organization_id));
create policy work_context_manager_update on public.work_contexts for update
using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy work_context_owner_delete on public.work_contexts for delete
using (exists (
    select 1 from public.organization_members m
    where m.organization_id = work_contexts.organization_id
      and m.user_id = auth.uid() and m.role in ('owner','admin')
));

create or replace function public.touch_work_context_updated_at()
returns trigger language plpgsql security invoker set search_path = public, pg_catalog as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists work_contexts_updated_at on public.work_contexts;
create trigger work_contexts_updated_at before update on public.work_contexts
for each row execute function public.touch_work_context_updated_at();
