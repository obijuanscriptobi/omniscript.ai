"use strict";

const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { spawnSync } = require("node:child_process");

const root = __dirname;
const ignoredDirectories = new Set([".git", "node_modules", "test-results", "playwright-report", "coverage"]);
const javascriptExtensions = new Set([".js", ".mjs", ".cjs"]);
const jsonExtensions = new Set([".json"]);
const cssExtensions = new Set([".css"]);
const htmlExtensions = new Set([".html", ".htm"]);
const textExtensions = new Set([
    ".css", ".csv", ".md", ".sql", ".svg", ".txt", ".toml", ".xml", ".webmanifest", ".yml", ".yaml"
]);
const failures = [];
const checked = [];

function relative(file) {
    return path.relative(root, file) || path.basename(file);
}

function addFailure(file, message) {
    failures.push(`${relative(file)}\n${message}`);
}

function readText(file) {
    const buffer = fs.readFileSync(file);
    if (buffer.includes(0)) {
        addFailure(file, "NUL byte found in a text file.");
        return null;
    }
    try {
        return new TextDecoder("utf-8", { fatal: true }).decode(buffer).replace(/^\uFEFF/, "");
    } catch (error) {
        addFailure(file, `Invalid UTF-8: ${error.message}`);
        return null;
    }
}

function lineNumber(source, index) {
    return source.slice(0, index).split("\n").length;
}

function inspectJavaScript(file) {
    const result = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
    if (result.status !== 0) addFailure(file, (result.stderr || result.stdout || "JavaScript syntax check failed.").trim());
}

function inspectJson(file, source) {
    try { JSON.parse(source); } catch (error) { addFailure(file, error.message); }
}

function inspectCss(file, source) {
    const stack = [];
    let quote = "";
    let comment = false;
    for (let index = 0; index < source.length; index += 1) {
        const character = source[index];
        const next = source[index + 1];
        if (comment) {
            if (character === "*" && next === "/") { comment = false; index += 1; }
            continue;
        }
        if (quote) {
            if (character === "\\") index += 1;
            else if (character === quote) quote = "";
            continue;
        }
        if (character === "/" && next === "*") { comment = true; index += 1; continue; }
        if (character === "\"" || character === "'") { quote = character; continue; }
        if (character === "{" || character === "(" || character === "[") stack.push([character, index]);
        if (character === "}" || character === ")" || character === "]") {
            const expected = { "}": "{", ")": "(", "]": "[" }[character];
            if (!stack.length || stack.at(-1)[0] !== expected) addFailure(file, `Unmatched '${character}' at line ${lineNumber(source, index)}.`);
            else stack.pop();
        }
    }
    if (comment) addFailure(file, "Unterminated CSS comment.");
    if (quote) addFailure(file, `Unterminated CSS string (${quote}).`);
    for (const [character, index] of stack) addFailure(file, `Unclosed '${character}' at line ${lineNumber(source, index)}.`);
}

function inspectHtml(file, source) {
    const inlineScripts = [...source.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
    for (let index = 0; index < inlineScripts.length; index += 1) {
        const script = inlineScripts[index][1].trim();
        if (!script) continue;
        try { new vm.Script(script, { filename: `${relative(file)}#inline-script-${index + 1}` }); }
        catch (error) { addFailure(file, `Inline script ${index + 1}: ${error.message}`); }
    }
    for (const match of source.matchAll(/<(?:script|link)\b[^>]+(?:src|href)=["']([^"'#?]+)["'][^>]*>/gi)) {
        const asset = match[1];
        if (/^(?:https?:|mailto:|tel:|data:|javascript:|#|\/)/i.test(asset)) continue;
        const assetPath = path.resolve(path.dirname(file), asset);
        if (!assetPath.startsWith(`${root}${path.sep}`) && assetPath !== root) continue;
        if (!fs.existsSync(assetPath)) addFailure(file, `Missing local asset '${asset}'.`);
    }
}

function inspect(file) {
    const extension = path.extname(file).toLowerCase();
    const name = relative(file);
    if (javascriptExtensions.has(extension)) {
        if (readText(file) !== null) inspectJavaScript(file);
        checked.push(name);
        return;
    }
    const source = readText(file);
    if (source === null) return;
    if (jsonExtensions.has(extension)) inspectJson(file, source);
    else if (cssExtensions.has(extension)) inspectCss(file, source);
    else if (htmlExtensions.has(extension)) inspectHtml(file, source);
    checked.push(name);
}

function walk(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
        if (entry.isDirectory()) {
            if (!ignoredDirectories.has(entry.name)) walk(path.join(directory, entry.name));
        } else if (entry.isFile()) {
            const extension = path.extname(entry.name).toLowerCase();
            if (javascriptExtensions.has(extension) || jsonExtensions.has(extension) || cssExtensions.has(extension) || htmlExtensions.has(extension) || textExtensions.has(extension)) inspect(path.join(directory, entry.name));
        }
    }
}

walk(root);
if (failures.length) {
    console.error(`Syntax audit failed with ${failures.length} finding(s) across ${checked.length} checked file(s):`);
    console.error(failures.join("\n\n"));
    process.exitCode = 1;
} else {
    console.log(`Syntax audit passed across ${checked.length} checked file(s).`);
}
