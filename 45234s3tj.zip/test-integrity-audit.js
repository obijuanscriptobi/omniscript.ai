"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = __dirname;
const testRoot = path.join(root, "test");
const findings = [];
const inventory = { files: 0, explicitSkips: [], conditionalSkips: [], environmentGates: [], broadStatusAssertions: [] };

function walk(directory) {
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => entry.isDirectory() ? walk(path.join(directory, entry.name)) : [path.join(directory, entry.name)]);
}

function record(list, file, source, pattern, label) {
    for (const match of source.matchAll(pattern)) list.push({ file, line: source.slice(0, match.index).split("\n").length, label });
}

for (const absolute of walk(testRoot).filter((file) => /\.(?:js|mjs|cjs)$/.test(file))) {
    const file = path.relative(root, absolute).replaceAll(path.sep, "/");
    const source = fs.readFileSync(absolute, "utf8");
    inventory.files += 1;
    record(inventory.explicitSkips, file, source, /\b(?:test|it|describe)\.skip\s*\(/g, "explicit skip");
    record(inventory.conditionalSkips, file, source, /\b(?:test|it)\.skip\s*\([^)]/g, "conditional or explicit skip");
    record(inventory.environmentGates, file, source, /\b(?:process\.env|Deno\.env|import\.meta\.env)\b/g, "environment-dependent test logic");
    record(inventory.broadStatusAssertions, file, source, /expect\s*\([^\n]+\.status\s*\(\s*\)[^\n]*(?:toBeLessThan|toBeTruthy|toBeGreaterThanOrEqual)/g, "broad HTTP status assertion");
    for (const match of source.matchAll(/\b(?:test|it|describe)\.only\s*\(/g)) {
        findings.push({ code: "FOCUSED_TEST", file, line: source.slice(0, match.index).split("\n").length, message: "Focused tests are forbidden in committed source." });
    }
}

const report = { ok: findings.length === 0, findings, inventory };
process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
process.exitCode = report.ok ? 0 : 1;
