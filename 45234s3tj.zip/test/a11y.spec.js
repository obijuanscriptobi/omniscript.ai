import { test, expect } from "@playwright/test";

// The generated-site URL can be supplied by CI; the local default is useful for
// a deployed preview server without hard-coding a production domain.
const baseURL = process.env.SITE_URL || "http://127.0.0.1:8888";

test.describe("WCAG 2.2 browser checks", () => {
    test("homepage exposes a usable document and keyboard path", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("html")).toHaveAttribute("lang", /.+/);
        await expect(page.locator("main")).toHaveCount(1);
        await expect(page.locator("h1")).toHaveCount(1);
        await page.keyboard.press("Tab");
        await expect(page.locator(":focus")).toBeVisible();
    });

    test("workspace controls have labels, unique IDs, and keyboard access", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        const result = await page.evaluate(() => {
            const ids = [...document.querySelectorAll("[id]")].map((node) => node.id);
            const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
            const controls = [...document.querySelectorAll("input, textarea, select, button")];
            const unnamed = controls.filter((control) => {
                if (control.tagName === "BUTTON") return !control.textContent.trim() && !control.getAttribute("aria-label");
                return !control.getAttribute("aria-label") && !control.getAttribute("aria-labelledby") && (!control.id || !document.querySelector(`label[for="${CSS.escape(control.id)}"]`));
            });
            return { duplicateIds, unnamed: unnamed.map((control) => control.id || control.tagName) };
        });
        expect(result.duplicateIds).toEqual([]);
        expect(result.unnamed).toEqual([]);
    });

    test("loader reports progress and exposes recovery on failure", async ({ page }) => {
        const progress = [];
        await page.exposeFunction("captureLoaderProgress", (detail) => progress.push(detail));
        await page.addInitScript(() => {
            window.addEventListener("workspace:loader-progress", (event) => {
                window.captureLoaderProgress(event.detail);
            });
        });
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("#status-vector")).toHaveText(/Ready to create|Loading/);
        await expect(page.locator("html")).toHaveAttribute("data-loader-state", /ready|loading/);
        await expect(page.locator("#onboarding-create-btn")).toHaveCount(1);
        expect(progress.some((entry) => entry.message === "Loading editor")).toBeTruthy();
        expect(progress.some((entry) => entry.message === "Loading quality tools")).toBeTruthy();
        expect(progress.some((entry) => entry.progress === 100)).toBeTruthy();
    });

    test("failed core module exposes a visible reload action", async ({ page }) => {
        await page.route("**/workspace-generator.js", (route) => route.abort());
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("#status-vector")).toHaveText("Workspace could not load");
        await expect(page.locator("#workspace-loader-retry")).toBeVisible();
    });

    test("loader preserves dependency order while batching quality modules", async ({ page }) => {
        const requests = [];
        page.on("request", (request) => {
            const pathname = new URL(request.url()).pathname;
            if (/\/(workspace-fields|workspace-validation|script)\.js$/.test(pathname)) requests.push(pathname.split("/").pop());
        });
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("#onboarding-create-btn")).toHaveCount(1);
        expect(requests.indexOf("workspace-fields.js")).toBeGreaterThanOrEqual(0);
        expect(requests.indexOf("script.js")).toBeGreaterThan(requests.indexOf("workspace-fields.js"));
        expect(requests.indexOf("workspace-validation.js")).toBeGreaterThan(requests.indexOf("workspace-fields.js"));
    });

    test("optional module failures are reported without blocking the editor", async ({ page }) => {
        await page.route("**/benchmark-ui.js", (route) => route.abort());
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("#onboarding-create-btn")).toHaveCount(1);
        await page.waitForTimeout(1800);
        const errors = await page.evaluate(() => window.__optionalLoaderErrors || []);
        expect(errors).toContain("benchmark-ui.js");
    });

    test("onboarding initializes once", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        const initial = await page.evaluate(() => window.__workspaceOnboardingInitCount || 0);
        await page.reload();
        const afterReload = await page.evaluate(() => window.__workspaceOnboardingInitCount || 0);
        expect(initial).toBeLessThanOrEqual(1);
        expect(afterReload).toBeLessThanOrEqual(1);
    });

    test("completed brief creates a visible preview", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.locator("#input-biz-name").fill("Northstar Studio");
        await page.locator("#input-biz-hook").fill("Help local teams launch clearer brands");
        await page.locator("#input-biz-services").fill("Brand strategy, Web design");
        await page.locator("#input-biz-location").fill("Austin, TX");
        await page.locator("#input-biz-audience").fill("Growing local businesses");
        await page.locator("#primary-create-website-btn").click();
        await expect(page.locator("#preview-frame-shell")).toBeVisible({ timeout: 10000 });
        await expect(page.locator("#previewContentIframe")).toHaveAttribute("srcdoc", /.+/);
    });

    test("interactive controls expose visible focus", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        const controls = page.locator("button, a[href], input, textarea, select");
        const count = await controls.count();
        expect(count).toBeGreaterThan(5);
        for (let index = 0; index < Math.min(count, 20); index += 1) {
            await controls.nth(index).focus();
            await expect(controls.nth(index)).toBeFocused();
        }
    });
});
