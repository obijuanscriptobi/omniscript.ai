"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const load = () => { const context = { window: {}, document: { readyState: "complete", getElementById: () => null }, Blob, setTimeout, URL }; vm.runInNewContext(read("ad-studio.js"), context); return context.window.adStudio; };

test("ad studio returns structured pattern evidence", () => {
    const profile = load().analyzePatterns({ references: "testimonial with proof before CTA, calm trust tone", industry: "local service", channel: "social", audience: "local homeowners", goal: "leads" });
    assert.equal(profile.layout.type, "testimonial"); assert.equal(profile.message.angle, "trust"); assert.ok(Array.isArray(profile.message.hierarchy)); assert.equal(profile.evidence.performance.length, 0); assert.equal(profile.evidence.observed.length, 1);
});

test("ad studio creates three strategic, original variants and platform output", () => {
    const studio = load(), profile = studio.analyzePatterns({ channel: "search" });
    const variants = studio.generateVariants({ business: { name: "Northstar", offer: "make home repairs simpler", cta: "Request an estimate" }, goal: "leads", audience: "busy homeowners", patternProfile: profile });
    assert.deepEqual(variants.map((item) => item.angle), ["outcome", "trust", "offer"]); assert.ok(variants.every((item) => studio.validateOriginality(item).valid)); assert.ok(studio.platformOutputs(variants[0], "search").headlines[0].characters > 0); assert.ok(variants.every((item) => item.strategy.promise));
});

test("ad studio scopes drafts and exports to the active work context", () => {
    const source = read("ad-studio.js");
    assert.match(source, /morrow-ad-studio-draft-v4-\$\{window\.workspaceContext/);
    assert.match(source, /workContext: \{ id: target\.id/);
    assert.match(source, /confirm client content permission/);
});

test("ad studio validates briefs, quality, claims and structured exports", () => {
    const studio = load(); assert.equal(studio.validateBrief({}).ready, false);
    const concept = studio.generateConcept({ business: { name: "Northstar", offer: "home repairs for busy families" } });
    assert.equal(concept.sourceInfluence.copiedLayout, false); assert.equal(studio.qualityScore(concept, { audience: "families" }).total, 10); assert.ok(studio.assetChecklist().imageRights);
    assert.ok(studio.validateOriginality({ ...concept, concept: { ...concept.concept, headline: "Guaranteed #1" } }).warnings.length > 0);
    assert.equal(studio.layerSchema(concept).dimensions.width, 1080);
    assert.ok(studio.layerSchema(concept).layers.some((layer) => layer.id === "headline"));
    assert.equal(studio.validateBrand(concept, { colors: ["#d4af37"], forbiddenClaims: ["repairs"] }).valid, false);
});
