"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

const capabilities = {
    owner: ["read", "write", "manage-members", "approve", "delete"],
    admin: ["read", "write", "manage-members", "approve"],
    contributor: ["read", "write", "approve"],
    editor: ["read", "write"],
    reviewer: ["read", "approve"],
    client: ["read", "approve"],
    anonymous: []
};

const protectedRoutes = [
    "projects.js", "project-files.js", "project-memberships.js", "approval.js",
    "client-portal.js", "leads.js", "appointments.js", "todos.js", "invitation.js"
];

test("the declared role capability matrix is explicit and least privilege", () => {
    assert.deepEqual(capabilities.anonymous, []);
    assert.ok(capabilities.owner.includes("delete"));
    assert.ok(!capabilities.admin.includes("delete"));
    assert.ok(!capabilities.reviewer.includes("write"));
    assert.ok(!capabilities.client.includes("manage-members"));
    assert.ok(!capabilities.editor.includes("approve"));
});

test("every protected resource authenticates before resource operations", () => {
    for (const file of protectedRoutes) {
        const source = read(`netlify/functions/${file}`);
        assert.match(source, /authenticate\(event\)/, `${file} must authenticate`);
        assert.match(source, /UNAUTHORIZED|response\(401/, `${file} must reject anonymous access`);
        assert.match(source, /project_id|projectId|workspace_id|share\.project_id/, `${file} must carry a scope boundary`);
    }
});

test("resource routes contain mutation-specific authorization or scoped access checks", () => {
    const expectations = {
        "project-files.js": /access\(user\.id, projectId, true\)|WRITE_ROLES/,
        "project-memberships.js": /owner|admin/,
        "approval.js": /owner|admin|contributor/,
        "client-portal.js": /ownerProject|share\.project_id/,
        "leads.js": /project_id=eq\./,
        "appointments.js": /project_id=eq\./,
        "todos.js": /project_id=eq\./
    };
    for (const [file, pattern] of Object.entries(expectations)) assert.match(read(`netlify/functions/${file}`), pattern, `${file} must enforce mutation scope`);
});

test("cross-project mutations are rejected by runtime staging checks", () => {
    const source = read("test/staging-smoke.spec.js");
    assert.match(source, /rejects cross-project writes/);
    assert.match(source, /rejects cross-project lead access/);
    assert.match(source, /otherProjectId/);
});
