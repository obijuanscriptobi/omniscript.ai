"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

const routes = {
    projects: "netlify/functions/projects.js",
    files: "netlify/functions/project-files.js",
    memberships: "netlify/functions/project-memberships.js",
    approvals: "netlify/functions/approval.js",
    handoffs: "netlify/functions/handoffs.js",
    portal: "netlify/functions/client-portal.js",
    leads: "netlify/functions/leads.js",
    appointments: "netlify/functions/appointments.js",
    todos: "netlify/functions/todos.js"
};

test("the protected project surface has an explicit authorization boundary", () => {
    for (const [name, file] of Object.entries(routes)) {
        const source = read(file);
        assert.match(source, /authenticate\(event\)|authenticate\(event\)/, `${name} must authenticate protected requests`);
        assert.match(source, /response\(401|UNAUTHORIZED/, `${name} must reject unauthenticated requests`);
        assert.match(source, /response\((?:403|404)|FORBIDDEN|not found/i, `${name} must reject unauthorized resource access`);
    }
});

test("project resources bind reads and writes to the requested project", () => {
    const projects = read(routes.projects);
    const files = read(routes.files);
    const leads = read(routes.leads);
    const appointments = read(routes.appointments);
    const todos = read(routes.todos);

    assert.match(projects, /id=eq\.[^`]+user_id=eq\./);
    assert.match(projects, /expectedRevision/);
    assert.match(files, /project_id=eq\./);
    assert.match(files, /await access\(user\.id, projectId, true\)/);
    assert.match(leads, /project_id=eq\./);
    assert.match(appointments, /project_id=eq\./);
    assert.match(todos, /project_id=eq\./);
});

test("role capabilities are least-privilege and owner-only project administration is explicit", () => {
    const files = read(routes.files);
    const memberships = read(routes.memberships);
    const approvals = read(routes.approvals);
    const sql = read("supabase/collaboration-security.sql");

    assert.match(files, /const WRITE_ROLES = new Set\(\["owner", "admin", "contributor"\]\)/);
    assert.match(memberships, /\["owner", "admin"\]\.includes\(member\.role\)/);
    assert.match(approvals, /\["owner", "admin", "contributor"\]\.includes\(role\)/);
    assert.match(sql, /role in \('owner','admin','sales','marketing','contributor','client_reviewer'\)/);
    assert.match(sql, /role in \('owner', 'admin', 'contributor'\)/);
});

test("cross-project file, approval, membership, and portal access cannot be inferred from a token alone", () => {
    const files = read(routes.files);
    const memberships = read(routes.memberships);
    const approvals = read(routes.approvals);
    const portal = read(routes.portal);

    assert.match(files, /share\.project_id !== projectId/);
    assert.match(memberships, /project_id=eq\.\$\{encodeURIComponent\(projectId\)\}/);
    assert.match(approvals, /approval\.project_id/);
    assert.match(portal, /share\.project_id/);
    assert.match(portal, /ownerProject\(user\.id, value\.projectId\)/);
});

test("public portal and approval mutations are constrained to scoped records", () => {
    const portal = read(routes.portal);
    const approvals = read(routes.approvals);

    assert.match(portal, /share_id: share\.id/);
    assert.match(portal, /project_id: share\.project_id/);
    assert.match(portal, /id=eq\.\$\{encodeURIComponent\(approval\.id\)\}&status=eq\.pending/);
    assert.match(approvals, /expires_at=gt\./);
    assert.match(approvals, /return=representation/);
});
