"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
    aggregateBenchmark,
    auditSite,
    createRegressionCase,
    runRegressionCase,
    scoreBenchmark,
    validateBrief
} = require("../benchmark.js");

const completeBrief = {
    businessName: "Northstar Studio",
    audience: "small hospitality businesses",
    offer: "brand and website strategy",
    outcome: "turn more visits into direct bookings",
    primaryAction: "booking",
    bookingUrl: "https://example.com/book"
};

const completeFiles = {
    "index.html": "<!doctype html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width\"><title>Northstar Studio</title><meta name=\"description\" content=\"Brand and website strategy for hospitality businesses.\"></head><body><main><h1>Turn more visits into direct bookings</h1><p>Northstar Studio helps small hospitality businesses build clearer brands and better websites with a practical strategy.</p><a href=\"https://example.com/book\">Book a strategy call</a><img src=\"hero.jpg\" alt=\"A bright hotel lobby\"></main></body></html>",
    "style.css": "main { max-width: 60rem; margin: auto; }",
    "script.js": "document.documentElement.dataset.ready = 'true';"
};

test("brief validation requires specific inputs and a usable action destination", () => {
    const result = validateBrief({ businessName: "Example", primaryAction: "booking" });
    assert.equal(result.valid, false);
    assert.ok(result.issues.some((entry) => entry.code === "BRIEF_FIELD_REQUIRED"));
    assert.ok(result.issues.some((entry) => entry.code === "ACTION_DESTINATION_REQUIRED"));

    const complete = validateBrief(completeBrief);
    assert.equal(complete.valid, true);
});

test("site audit reports structural and reference risks", () => {
    const audit = auditSite({
        "index.html": "<!doctype html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width\"></head><body><h1>Example</h1><h1>Duplicate</h1><img src=\"missing.jpg\"></body></html>"
    });
    assert.equal(audit.hasDoctype, true);
    assert.equal(audit.hasLanguage, true);
    assert.equal(audit.hasViewport, true);
    assert.equal(audit.h1Count, 2);
    assert.equal(audit.missingAlt, true);
    assert.deepEqual(audit.localReferences, ["missing.jpg"]);
});

test("benchmark scoring exposes technical scores and publish gates", () => {
    const result = scoreBenchmark({ files: completeFiles });
    assert.equal(result.publishable, true);
    assert.equal(result.gates.noBlockingQualityIssues, true);
    assert.equal(result.gates.primaryConversionPath, true);
    assert.ok(result.overall >= 50);
    assert.deepEqual(Object.keys(result.scores).sort(), ["accessibility", "content", "conversion", "performance", "reliability", "speed"]);
});

test("benchmark aggregation calculates averages and pass rate", () => {
    const good = scoreBenchmark({ files: completeFiles });
    const bad = scoreBenchmark({ files: { "index.html": "<html><body><h1>Broken</h1><img src=\"x.jpg\"></body></html>" } });
    const report = aggregateBenchmark([good, bad]);
    assert.equal(report.count, 2);
    assert.equal(typeof report.overall, "number");
    assert.equal(report.passRate, 50);
});

test("regression cases preserve expected publishability", () => {
    const fixture = createRegressionCase({
        id: "complete-basic-site",
        brief: completeBrief,
        files: completeFiles,
        expected: { publishable: true, maxBlockingIssues: 0 }
    });
    const result = runRegressionCase(fixture);
    assert.equal(result.pass, true);
    assert.equal(result.failures.length, 0);
});

test("regression cases catch accessibility regressions", () => {
    const fixture = createRegressionCase({
        id: "missing-alt-regression",
        files: { "index.html": "<!doctype html><html><head><title>Example</title></head><body><h1>Example</h1><img src=\"hero.jpg\"></body></html>" },
        expected: { publishable: false, maxBlockingIssues: 0 }
    });
    const result = runRegressionCase(fixture);
    assert.equal(result.pass, true);
});
