"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const source = fs.readFileSync(path.join(root, "business-hub.js"), "utf8");

function load() {
    const context = {
        window: {},
        document: undefined,
        localStorage: { getItem: () => null, setItem: () => {} },
        CustomEvent: function CustomEvent(type, init) { this.type = type; this.detail = init?.detail; }
    };
    vm.runInNewContext(source, context);
    return context.window.businessHub;
}

test("Business Hub normalizes profile facts and claim governance", () => {
    const hub = load();
    const profile = hub.normalize({
        name: "  Northstar  ",
        services: "Repairs,\nMaintenance",
        approvedClaims: "Licensed,\nServing the valley",
        forbiddenClaims: "guaranteed, #1",
        color: "invalid"
    });
    assert.equal(profile.name, "Northstar");
    assert.equal(profile.services, "Repairs, Maintenance");
    assert.deepEqual(profile.approvedClaims, ["Licensed", "Serving the valley"]);
    assert.deepEqual(profile.forbiddenClaims, ["guaranteed", "#1"]);
    assert.equal(profile.color, "#d4af37");
});

test("Business Hub reports readiness from required facts", () => {
    const hub = load();
    assert.equal(hub.completeness({}).ready, false);
    const result = hub.completeness({ name: "Northstar", hook: "Home repairs", location: "Phoenix", primaryCta: "Request a quote" });
    assert.equal(result.ready, true);
    assert.equal(result.score, 100);
});
