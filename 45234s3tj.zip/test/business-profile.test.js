"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "business-profile.js"), "utf8");

function profileApi() {
    const context = { window: {} };
    vm.runInNewContext(source, context);
    return context.window.businessProfile;
}

test("normalizes canonical business facts into one versioned profile", () => {
    const api = profileApi();
    const profile = api.normalizeProfile({
        businessName: "Northstar Studio",
        phone: "+1 555 0100",
        services: "Brand strategy, Web design",
        brandVoice: "Clear and confident",
        claims: "Award winning design"
    });

    assert.equal(profile.model, "BusinessProfile");
    assert.equal(profile.version, 1);
    assert.equal(profile.identity.displayName, "Northstar Studio");
    assert.deepEqual(profile.services, ["Brand strategy", "Web design"]);
    assert.equal(profile.claims[0].text, "Award winning design");
    assert.equal(profile.metadata && typeof profile.metadata, "object");
    assert.equal(profile.model, "BusinessProfile");
});

test("governance blocks required claims until they are approved and sourced", () => {
    const api = profileApi();
    const profile = api.normalizeProfile({
        businessName: "Northstar Studio",
        phone: "+1 555 0100",
        claims: [{ text: "Guaranteed results", required: true, surfaces: ["website"] }]
    });
    const blocked = api.governance(profile, "website");
    assert.equal(blocked.valid, false);
    assert.equal(blocked.blocking[0].code, "CLAIM_NOT_APPROVED");

    const approved = api.updateClaim(profile, profile.claims[0].id, {
        state: "approved",
        source: "Customer case study",
        sourceUrl: "https://example.com/case-study",
        confidence: 0.9
    });
    assert.equal(api.governance(approved, "website").valid, true);
    assert.equal(approved.revision, "1");
});

test("profile changes identify affected surfaces and create an audit event", () => {
    const api = profileApi();
    const profile = api.normalizeProfile({ businessName: "Northstar Studio", phone: "+1 555 0100" });
    const result = api.recordChange(profile, { offers: { changed: true }, brand: { changed: true } }, "user");
    assert.equal(result.profile.revision, "1");
    assert.ok(result.affectedSurfaces.includes("website"));
    assert.ok(result.affectedSurfaces.includes("ads"));
    assert.ok(result.affectedSurfaces.includes("follow-up"));
    assert.equal(result.event.type, "profile.updated");
});

test("export manifest includes schema, revision, size, and checksum metadata", () => {
    const api = profileApi();
    const profile = api.normalizeProfile({ businessName: "Northstar Studio", phone: "+1 555 0100" });
    const manifest = api.exportManifest(profile, { projects: [] });
    assert.equal(manifest.schemaVersion, 1);
    assert.equal(manifest.revision, "0");
    assert.ok(manifest.bytes > 0);
    assert.match(manifest.checksum, /^[0-9a-f]{8}$/);

    const unicodeManifest = api.exportManifest(profile, { note: "café 😀" });
    const asciiManifest = api.exportManifest(profile, { note: "cafe" });
    assert.ok(unicodeManifest.bytes > asciiManifest.bytes);
});
