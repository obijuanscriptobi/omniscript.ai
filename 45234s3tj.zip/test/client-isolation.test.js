"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const contextSource = fs.readFileSync(path.join(root, "workspace-context.js"), "utf8");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

function bootWorkspace() {
    const values = new Map();
    let mode = "own";
    const localStorage = {
        getItem: (key) => values.get(key) ?? null,
        setItem: (key, value) => values.set(key, String(value)),
        removeItem: (key) => values.delete(key)
    };
    const window = {
        operatingMode: { isClient: () => mode === "client" },
        dispatchEvent() {},
        addEventListener() {},
        location: { reload() {} },
        confirm: () => true
    };
    const sandbox = {
        window,
        localStorage,
        console,
        module: { exports: {} },
        CustomEvent: function CustomEvent(type, init) { this.type = type; this.detail = init?.detail; }
    };
    vm.runInNewContext(contextSource, sandbox, { filename: "workspace-context.js" });
    return { api: window.workspaceContext, values, setMode: (value) => { mode = value; } };
}

const DATASETS = [
    "morrow-business-profile-v1",
    "morrow-ad-studio-draft-v4",
    "morrow-website-audits-v1",
    "morrow-lead-inbox-v1",
    "morrow-appointments-v1",
    "morrow-proposals-v1",
    "morrow-next-steps-v2",
    "morrow-reporting-v1"
];

test("owner and two clients keep profiles, ads, audits, CRM, proposals, tasks, and reports isolated", () => {
    const app = bootWorkspace();
    const owner = { id: app.api.OWN_ID, mode: "own", name: "My business" };
    app.setMode("client");
    const alpha = app.api.upsert({ name: "Alpha", projectName: "Alpha site", approvalContact: "alpha@example.com", permissionsConfirmed: true, assetRightsConfirmed: true });
    const beta = app.api.upsert({ name: "Beta", projectName: "Beta site", approvalContact: "beta@example.com", permissionsConfirmed: true, assetRightsConfirmed: true });

    for (const base of DATASETS) {
        app.api.writeScoped(base, [{ owner: "owner", dataset: base }], owner);
        app.api.writeScoped(base, [{ owner: "alpha", dataset: base }], alpha);
        app.api.writeScoped(base, [{ owner: "beta", dataset: base }], beta);
    }

    for (let pass = 0; pass < 4; pass += 1) {
        for (const base of DATASETS) {
            assert.equal(app.api.readScoped(base, [], owner)[0].owner, "owner");
            assert.equal(app.api.readScoped(base, [], alpha)[0].owner, "alpha");
            assert.equal(app.api.readScoped(base, [], beta)[0].owner, "beta");
            assert.notEqual(app.api.storageKey(base, alpha), app.api.storageKey(base, beta));
        }
    }
});

test("legacy records migrate once to owner scope without deletion or client copying", () => {
    const app = bootWorkspace();
    const owner = { id: app.api.OWN_ID, mode: "own" };
    const legacy = JSON.stringify([{ id: "legacy-record" }]);
    app.values.set("morrow-next-steps-v2", legacy);

    const ownerKey = app.api.storageKey("morrow-next-steps-v2", owner);
    assert.equal(app.values.get(ownerKey), legacy);
    assert.equal(app.values.get("morrow-next-steps-v2"), legacy);

    app.setMode("client");
    const client = app.api.upsert({ name: "Isolated Client" });
    const clientKey = app.api.storageKey("morrow-next-steps-v2", client);
    assert.equal(app.values.has(clientKey), false);
    assert.deepEqual(app.api.readScoped("morrow-next-steps-v2", [], client), []);

    app.api.storageKey("morrow-next-steps-v2", owner);
    assert.equal(app.values.get(ownerKey), legacy);
    assert.equal(app.values.get("morrow-next-steps-v2"), legacy);
});

test("cloud data endpoints require a work context and bind the project to it", () => {
    for (const file of ["netlify/functions/todos.js", "netlify/functions/leads.js", "netlify/functions/appointments.js", "netlify/functions/business-profile.js", "netlify/functions/website-audits.js"]) {
        const source = read(file);
        assert.match(source, /workContextId/);
        assert.match(source, /INVALID_CONTEXT/);
        assert.match(source, /getOwnedProject\([^\n]+workContext|getOwnedProject\([^\n]+context/);
        assert.match(source, /Project not found in this work context/);
        assert.match(source, /project_id=eq\./);
    }
});

test("database RLS binds project-owned domains to an active member work context", () => {
    const sql = read("supabase/work-context-isolation.sql");
    assert.match(sql, /create or replace function public\.can_access_project_context/);
    assert.match(sql, /p\.organization_id = c\.organization_id/);
    assert.match(sql, /c\.status = 'active'/);
    assert.match(sql, /m\.user_id = auth\.uid\(\)/);
    for (const table of ["projects", "next_steps", "leads", "business_profiles", "appointments", "website_drafts", "website_audits", "audit_findings", "site_revisions", "activity_events", "client_approvals", "project_approval_history"]) {
        assert.match(sql, new RegExp(`alter table public\\.${table} enable row level security`));
    }
    assert.match(sql, /with check \(auth\.uid\(\) = user_id and public\.can_access_project_context\(project_id\)\)/);
    assert.match(sql, /create trigger audit_findings_project_guard/);
    assert.match(sql, /create trigger site_revisions_evidence_guard/);
});

test("project creation, revisions, previews, and approvals enforce active cloud context", () => {
    const projects = read("netlify/functions/projects.js");
    const revisions = read("netlify/functions/revisions.js");
    const previews = read("netlify/functions/preview.js");
    const approvals = read("netlify/functions/approval.js");
    const sharing = read("preview-sharing.js");
    assert.match(projects, /canUseWorkContext\(payload\.work_context_id, user\.id\)/);
    assert.match(projects, /work_context_id=eq\./);
    assert.match(revisions, /getOwnedProject\(inputProjectId, user\.id, inputWorkContextId\)/);
    assert.match(previews, /getOwnedProject\(projectId, user\.id, workContextId\)/);
    assert.match(previews, /ASSET_RIGHTS_REQUIRED/);
    assert.match(approvals, /getOwnedProject\(value\.projectId, user\.id, value\.workContextId\)/);
    assert.match(approvals, /APPROVAL_CONTACT_REQUIRED/);
    assert.match(sharing, /clientGate\?\.\("assets"/);
    assert.match(sharing, /workContextId: activeContext\.cloudId/);
});

test("browser cloud clients send both project and active cloud context IDs", () => {
    const todo = read("todo.js");
    const crm = read("workspace-crm.js");
    assert.match(todo, /workContextId=.*encodeURIComponent\(workContextId\)/);
    assert.match(todo, /workspaceContext\?\.current\?\.\(\)\?\.cloudId/);
    assert.match(crm, /function currentWorkContextId\(\)/);
    assert.match(crm, /workContextId=\$\{encodeURIComponent\(contextId\)\}/);
    assert.match(crm, /cloudUrl\("leads"/);
    assert.match(crm, /cloudUrl\("appointments"/);
});

const IDS = Object.freeze({
    user: "00000000-0000-4000-8000-000000000001",
    foreignUser: "00000000-0000-4000-8000-000000000002",
    ownerContext: "10000000-0000-4000-8000-000000000001",
    alphaContext: "10000000-0000-4000-8000-000000000002",
    betaContext: "10000000-0000-4000-8000-000000000003",
    foreignContext: "10000000-0000-4000-8000-000000000004",
    ownerProject: "20000000-0000-4000-8000-000000000001",
    alphaProject: "20000000-0000-4000-8000-000000000002",
    betaProject: "20000000-0000-4000-8000-000000000003",
    foreignProject: "20000000-0000-4000-8000-000000000004",
    lead: "30000000-0000-4000-8000-000000000001",
    appointment: "30000000-0000-4000-8000-000000000002",
    task: "30000000-0000-4000-8000-000000000003",
    profile: "30000000-0000-4000-8000-000000000004",
    audit: "30000000-0000-4000-8000-000000000005",
    finding: "30000000-0000-4000-8000-000000000006",
    revision: "30000000-0000-4000-8000-000000000007",
    organization: "40000000-0000-4000-8000-000000000001"
});

function parseResponse(result) {
    return { status: result.statusCode, body: JSON.parse(result.body || "{}") };
}

async function withLeadHandler(callback) {
    const projects = require("../netlify/functions/projects.js");
    const originals = {
        authenticate: projects.authenticate,
        getOwnedProject: projects.getOwnedProject,
        supabaseRequest: projects.supabaseRequest
    };
    const ownership = new Map([
        [IDS.ownerProject, { context: IDS.ownerContext, user: IDS.user }],
        [IDS.alphaProject, { context: IDS.alphaContext, user: IDS.user }],
        [IDS.betaProject, { context: IDS.betaContext, user: IDS.user }],
        [IDS.foreignProject, { context: IDS.foreignContext, user: IDS.foreignUser }]
    ]);
    const requests = [];

    projects.authenticate = async () => ({ id: IDS.user });
    projects.getOwnedProject = async (projectId, userId, workContextId) => {
        const record = ownership.get(projectId);
        return record && record.user === userId && record.context === workContextId
            ? { id: projectId, user_id: userId, work_context_id: workContextId }
            : null;
    };
    projects.supabaseRequest = async (url, options = {}) => {
        requests.push({ url, options });
        if (options.method === "POST") return [{ id: IDS.lead }];
        if (options.method === "PATCH") return [{ id: IDS.lead, status: "qualified" }];
        return [];
    };

    delete require.cache[require.resolve("../netlify/functions/leads.js")];
    const handler = require("../netlify/functions/leads.js").handler;
    try {
        await callback({ handler, requests });
    } finally {
        Object.assign(projects, originals);
        delete require.cache[require.resolve("../netlify/functions/leads.js")];
    }
}

function leadEvent(method, projectId, workContextId, extra = {}) {
    const queryStringParameters = { projectId };
    if (workContextId) queryStringParameters.workContextId = workContextId;
    if (extra.id) queryStringParameters.id = extra.id;
    return {
        httpMethod: method,
        headers: { authorization: "Bearer isolation-fixture" },
        queryStringParameters,
        body: method === "GET" ? "" : JSON.stringify({
            projectId,
            ...(workContextId ? { workContextId } : {}),
            ...(method === "POST" ? { name: "Isolated lead" } : {}),
            ...(method === "PATCH" ? { id: extra.id, status: "qualified" } : {}),
            ...(method === "DELETE" ? { id: extra.id } : {})
        })
    };
}

test("cloud lead reads allow matching owner/client contexts and reject crossed, missing, and foreign contexts", async () => {
    await withLeadHandler(async ({ handler, requests }) => {
        for (const [projectId, contextId] of [
            [IDS.ownerProject, IDS.ownerContext],
            [IDS.alphaProject, IDS.alphaContext],
            [IDS.betaProject, IDS.betaContext]
        ]) {
            const result = parseResponse(await handler(leadEvent("GET", projectId, contextId)));
            assert.equal(result.status, 200);
            assert.equal(result.body.success, true);
        }

        const databaseCallsBeforeRejections = requests.length;
        for (const [projectId, contextId, expectedStatus] of [
            [IDS.alphaProject, IDS.betaContext, 404],
            [IDS.betaProject, IDS.alphaContext, 404],
            [IDS.alphaProject, "", 400],
            [IDS.foreignProject, IDS.foreignContext, 404]
        ]) {
            const result = parseResponse(await handler(leadEvent("GET", projectId, contextId)));
            assert.equal(result.status, expectedStatus);
            assert.equal(result.body.success, false);
        }
        assert.equal(requests.length, databaseCallsBeforeRejections, "rejected contexts must not reach lead storage");
    });
});

test("cloud lead create, update, and delete never mutate through a mismatched context", async () => {
    await withLeadHandler(async ({ handler, requests }) => {
        const created = parseResponse(await handler(leadEvent("POST", IDS.alphaProject, IDS.alphaContext)));
        const updated = parseResponse(await handler(leadEvent("PATCH", IDS.alphaProject, IDS.alphaContext, { id: IDS.lead })));
        const deleted = parseResponse(await handler(leadEvent("DELETE", IDS.alphaProject, IDS.alphaContext, { id: IDS.lead })));
        assert.deepEqual([created.status, updated.status, deleted.status], [201, 200, 200]);

        const validMutationCount = requests.length;
        for (const method of ["POST", "PATCH", "DELETE"]) {
            const result = parseResponse(await handler(leadEvent(method, IDS.alphaProject, IDS.betaContext, { id: IDS.lead })));
            assert.equal(result.status, 404);
        }
        assert.equal(requests.length, validMutationCount, "cross-client mutations must stop before database access");

        const mutationUrls = requests.map(({ url }) => url);
        assert.ok(mutationUrls.some((url) => url.includes(`project_id=eq.${IDS.alphaProject}`)), "updates/deletes must include project ownership");
        assert.ok(mutationUrls.every((url) => !url.includes(IDS.betaProject) && !url.includes(IDS.foreignProject)));
    });
});

const OWNERSHIP = new Map([
    [IDS.ownerProject, { context: IDS.ownerContext, user: IDS.user }],
    [IDS.alphaProject, { context: IDS.alphaContext, user: IDS.user }],
    [IDS.betaProject, { context: IDS.betaContext, user: IDS.user }],
    [IDS.foreignProject, { context: IDS.foreignContext, user: IDS.foreignUser }]
]);

async function withScopedHandler(moduleName, request, callback) {
    const projects = require("../netlify/functions/projects.js");
    const originals = {
        authenticate: projects.authenticate,
        getOwnedProject: projects.getOwnedProject,
        supabaseRequest: projects.supabaseRequest
    };
    const requests = [];
    projects.authenticate = async () => ({ id: IDS.user });
    projects.getOwnedProject = async (projectId, userId, workContextId) => {
        const record = OWNERSHIP.get(projectId);
        return record && record.user === userId && record.context === workContextId
            ? { id: projectId, user_id: userId, work_context_id: workContextId, organization_id: IDS.organization }
            : null;
    };
    projects.supabaseRequest = async (url, options = {}) => {
        requests.push({ url, options });
        return request(url, options);
    };
    const modulePath = require.resolve(`../netlify/functions/${moduleName}.js`);
    delete require.cache[modulePath];
    const handler = require(modulePath).handler;
    try { await callback({ handler, requests }); }
    finally {
        Object.assign(projects, originals);
        delete require.cache[modulePath];
    }
}

function scopedEvent(method, projectId, workContextId, data = {}) {
    const queryStringParameters = { projectId };
    if (workContextId) queryStringParameters.workContextId = workContextId;
    if (data.id) queryStringParameters.id = data.id;
    return {
        httpMethod: method,
        headers: { authorization: "Bearer isolation-fixture" },
        queryStringParameters,
        body: method === "GET" ? "" : JSON.stringify({ projectId, ...(workContextId ? { workContextId } : {}), ...data })
    };
}

const REJECTED_CONTEXTS = [
    [IDS.alphaProject, IDS.betaContext, 404],
    [IDS.betaProject, IDS.alphaContext, 404],
    [IDS.alphaProject, "", 400],
    [IDS.foreignProject, IDS.foreignContext, 404]
];

async function assertRejectedBeforeStorage(handler, requests, eventFactory) {
    const before = requests.length;
    for (const [projectId, contextId, status] of REJECTED_CONTEXTS) {
        const result = parseResponse(await handler(eventFactory(projectId, contextId)));
        assert.equal(result.status, status);
        assert.equal(result.body.success, false);
    }
    assert.equal(requests.length, before, "invalid work contexts must stop before domain storage");
}

test("appointments enforce owner, client, missing, crossed, and foreign contexts for the full mutation lifecycle", async () => {
    const row = { id: IDS.appointment, status: "scheduled", meeting_at: "2099-01-01T10:00:00.000Z", appointment_context: "work", appointment_type: "discovery" };
    await withScopedHandler("appointments", (url, options) => {
        if (url.includes("select=id&limit=1")) return [row];
        if (options.method === "POST" || options.method === "PATCH") return [row];
        if (url.includes("appointments?")) return [row];
        return [];
    }, async ({ handler, requests }) => {
        for (const [projectId, contextId] of [[IDS.ownerProject, IDS.ownerContext], [IDS.alphaProject, IDS.alphaContext], [IDS.betaProject, IDS.betaContext]]) {
            assert.equal(parseResponse(await handler(scopedEvent("GET", projectId, contextId))).status, 200);
        }
        const create = scopedEvent("POST", IDS.alphaProject, IDS.alphaContext, { id: IDS.appointment, clientName: "Alpha", meetingAt: "2099-01-01T10:00:00.000Z" });
        const update = scopedEvent("PATCH", IDS.alphaProject, IDS.alphaContext, { id: IDS.appointment, notes: "Updated" });
        const remove = scopedEvent("DELETE", IDS.alphaProject, IDS.alphaContext, { id: IDS.appointment });
        assert.deepEqual([
            parseResponse(await handler(create)).status,
            parseResponse(await handler(update)).status,
            parseResponse(await handler(remove)).status
        ], [200, 200, 200]);
        await assertRejectedBeforeStorage(handler, requests, (projectId, contextId) => scopedEvent("DELETE", projectId, contextId, { id: IDS.appointment }));
        const mutationUrls = requests.filter(({ options }) => ["PATCH", "DELETE"].includes(options.method)).map(({ url }) => url);
        assert.ok(mutationUrls.every((url) => url.includes(`project_id=eq.${IDS.alphaProject}`)));
    });
});

test("task replacement cannot read, upsert, or delete through another work context", async () => {
    await withScopedHandler("todos", (url, options) => {
        if (options.method === "POST") return [{ id: IDS.task, project_id: IDS.alphaProject, text: "Alpha task" }];
        return [];
    }, async ({ handler, requests }) => {
        for (const [projectId, contextId] of [[IDS.ownerProject, IDS.ownerContext], [IDS.alphaProject, IDS.alphaContext], [IDS.betaProject, IDS.betaContext]]) {
            assert.equal(parseResponse(await handler(scopedEvent("GET", projectId, contextId))).status, 200);
        }
        const put = scopedEvent("PUT", IDS.alphaProject, IDS.alphaContext, { tasks: [{ id: IDS.task, text: "Alpha task" }] });
        assert.equal(parseResponse(await handler(put)).status, 200);
        await assertRejectedBeforeStorage(handler, requests, (projectId, contextId) => scopedEvent("PUT", projectId, contextId, { tasks: [] }));
        const deleteUrls = requests.filter(({ options }) => options.method === "DELETE").map(({ url }) => url);
        assert.ok(deleteUrls.length > 0);
        assert.ok(deleteUrls.every((url) => url.includes(`project_id=eq.${IDS.alphaProject}`) && url.includes(`user_id=eq.${IDS.user}`)));
    });
});

test("task upserts reject an ID already owned by another project", async () => {
    await withScopedHandler("todos", (url, options) => {
        if (url.includes("next_steps?id=in.") && !options.method) {
            return [{ id: IDS.task, project_id: IDS.betaProject, user_id: IDS.user }];
        }
        return [];
    }, async ({ handler, requests }) => {
        const result = parseResponse(await handler(scopedEvent("PUT", IDS.alphaProject, IDS.alphaContext, {
            tasks: [{ id: IDS.task, text: "Attempted reassignment" }]
        })));
        assert.equal(result.status, 409);
        assert.equal(result.body.success, false);
        assert.equal(requests.some(({ options }) => options.method === "POST"), false, "conflicting IDs must not be upserted");
        assert.equal(requests.some(({ options }) => options.method === "DELETE"), false, "conflicting IDs must not trigger cleanup");
    });
});

test("business profile create, reload, and update remain bound to project and work context", async () => {
    let existing = false;
    await withScopedHandler("business-profile", (url, options) => {
        if (url.includes("business_profiles?") && (!options.method || options.method === "GET")) {
            return existing ? [{ id: IDS.profile, revision: 1, project_id: IDS.alphaProject, profile: { name: "Alpha" } }] : [];
        }
        if (options.method === "POST" || options.method === "PATCH") {
            existing = true;
            return [{ id: IDS.profile, revision: 1, project_id: IDS.alphaProject, profile: { name: "Alpha" } }];
        }
        return [];
    }, async ({ handler, requests }) => {
        const save = scopedEvent("PUT", IDS.alphaProject, IDS.alphaContext, { profile: { revision: 1, name: "Alpha" } });
        assert.equal(parseResponse(await handler(save)).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("GET", IDS.alphaProject, IDS.alphaContext))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("PUT", IDS.alphaProject, IDS.alphaContext, { expectedRevision: 1, profile: { revision: 2, name: "Alpha updated" } }))).status, 200);
        await assertRejectedBeforeStorage(handler, requests, (projectId, contextId) => scopedEvent("PUT", projectId, contextId, { profile: { revision: 3, name: "Crossed" } }));
        const profileMutations = requests.filter(({ url, options }) => url.includes("business_profiles") && ["POST", "PATCH"].includes(options.method));
        assert.ok(profileMutations.length >= 2);
        const updateUrl = profileMutations.find(({ options }) => options.method === "PATCH")?.url || "";
        assert.match(updateUrl, new RegExp(`project_id=eq\\.${IDS.alphaProject}`));
        assert.match(updateUrl, new RegExp(`user_id=eq\\.${IDS.user}`));
    });
});

test("website audits and findings enforce context throughout create, reload, update, and delete", async () => {
    await withScopedHandler("website-audits", (url, options) => {
        if (url.includes("website_audits?id=eq.") && url.includes("select=id,project_id")) return [{ id: IDS.audit, project_id: IDS.alphaProject }];
        if (url.includes("audit_findings?id=eq.") && url.includes("select=id&limit=1")) return [{ id: IDS.finding }];
        if (url.includes("audit_findings") && ["POST", "PATCH"].includes(options.method)) return [{ id: IDS.finding, audit_id: IDS.audit, project_id: IDS.alphaProject }];
        if (url.includes("website_audits") && ["POST", "PATCH"].includes(options.method)) return [{ id: IDS.audit, project_id: IDS.alphaProject }];
        return [];
    }, async ({ handler, requests }) => {
        assert.equal(parseResponse(await handler(scopedEvent("GET", IDS.alphaProject, IDS.alphaContext))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("POST", IDS.alphaProject, IDS.alphaContext, { websiteUrl: "https://alpha.example" }))).status, 201);
        assert.equal(parseResponse(await handler(scopedEvent("PATCH", IDS.alphaProject, IDS.alphaContext, { id: IDS.audit, state: "audit-complete" }))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("POST", IDS.alphaProject, IDS.alphaContext, { resource: "finding", auditId: IDS.audit, issue: "Missing label" }))).status, 201);
        assert.equal(parseResponse(await handler(scopedEvent("PATCH", IDS.alphaProject, IDS.alphaContext, { resource: "finding", auditId: IDS.audit, id: IDS.finding, status: "fixed" }))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("DELETE", IDS.alphaProject, IDS.alphaContext, { resource: "finding", auditId: IDS.audit, id: IDS.finding }))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("DELETE", IDS.alphaProject, IDS.alphaContext, { id: IDS.audit }))).status, 200);
        await assertRejectedBeforeStorage(handler, requests, (projectId, contextId) => scopedEvent("PATCH", projectId, contextId, { id: IDS.audit, state: "needs-review" }));
        const mutations = requests.filter(({ options }) => ["PATCH", "DELETE"].includes(options.method));
        assert.ok(mutations.every(({ url }) => url.includes(`project_id=eq.${IDS.alphaProject}`) && url.includes(`user_id=eq.${IDS.user}`)));
    });
});

test("revisions require matching query/body scope and cannot mutate across contexts", async () => {
    await withScopedHandler("revisions", (url, options) => {
        if (url.includes("select=id&limit=1")) return [{ id: IDS.revision }];
        if (["POST", "PATCH"].includes(options.method)) return [{ id: IDS.revision, project_id: IDS.alphaProject }];
        return [];
    }, async ({ handler, requests }) => {
        assert.equal(parseResponse(await handler(scopedEvent("GET", IDS.alphaProject, IDS.alphaContext))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("POST", IDS.alphaProject, IDS.alphaContext, { status: "draft" }))).status, 201);
        assert.equal(parseResponse(await handler(scopedEvent("PATCH", IDS.alphaProject, IDS.alphaContext, { id: IDS.revision, status: "ready-for-review" }))).status, 200);
        assert.equal(parseResponse(await handler(scopedEvent("DELETE", IDS.alphaProject, IDS.alphaContext, { id: IDS.revision }))).status, 200);
        await assertRejectedBeforeStorage(handler, requests, (projectId, contextId) => scopedEvent("DELETE", projectId, contextId, { id: IDS.revision }));
        const mutationUrls = requests.filter(({ options }) => ["PATCH", "DELETE"].includes(options.method)).map(({ url }) => url);
        assert.ok(mutationUrls.every((url) => url.includes(`project_id=eq.${IDS.alphaProject}`) && url.includes(`user_id=eq.${IDS.user}`)));
    });
});

test("approval links enforce permission, asset-rights, contact, token, and project binding", () => {
    const source = read("netlify/functions/approval.js");
    assert.match(source, /PERMISSIONS_REQUIRED/);
    assert.match(source, /ASSET_RIGHTS_REQUIRED/);
    assert.match(source, /APPROVAL_CONTACT_REQUIRED/);
    assert.match(source, /token_hash=eq\.\$\{encodeURIComponent\(publicDecisionTokenHash\)\}/);
    assert.match(source, /project_id=eq\.\$\{encodeURIComponent\(approval\.project_id\)\}/);
    assert.match(source, /projects\?id=eq\.\$\{encodeURIComponent\(approval\.project_id\)\}/);
});
