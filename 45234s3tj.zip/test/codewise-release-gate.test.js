"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const { REQUIRED_RUNTIME_EVIDENCE, validateEvidenceManifest, run } = require("../codewise-release-gate.js");

test("codewise release gate covers the documented production boundaries", () => {
    const report = run(path.join(__dirname, ".."));
    assert.equal(report.ok, true, JSON.stringify(report.findings, null, 2));
    assert.equal(report.findings.length, 0);
    assert.equal(report.runtimeVerification.required, true);
    assert.equal(report.runtimeVerification.verified, report.runtimeVerification.attested && report.runtimeVerification.missingEvidence.length === 0);
    assert.deepEqual(report.requiredRuntimeEvidence, REQUIRED_RUNTIME_EVIDENCE);
    assert.ok(report.requiredFiles.includes("supabase/proposal-handoffs.sql"));
    assert.ok(report.requiredFiles.includes("netlify/functions/handoffs.js"));
    assert.ok(report.requiredFiles.includes("docs/STAGING-RELEASE-RECORD.md"));
});

test("enforced production release fails closed without referenced runtime evidence", () => {
    const previous = process.env.CODEWISE_ENFORCE_RUNTIME_RELEASE;
    process.env.CODEWISE_ENFORCE_RUNTIME_RELEASE = "true";
    try {
        const report = run(path.join(__dirname, ".."));
        if (!report.runtimeVerification.verified) {
            assert.equal(report.ok, false);
            assert.ok(report.findings.some((finding) => finding.code === "RUNTIME_VERIFICATION_REQUIRED"));
        }
    } finally {
        if (previous === undefined) delete process.env.CODEWISE_ENFORCE_RUNTIME_RELEASE;
        else process.env.CODEWISE_ENFORCE_RUNTIME_RELEASE = previous;
    }
});

test("runtime evidence manifest is bound to the full release commit and references", () => {
    const commit = "a".repeat(40);
    const evidence = Object.fromEntries(Object.entries(REQUIRED_RUNTIME_EVIDENCE).map(([category, variable]) => [
        category,
        { variable, verified: true, reference: `artifact:${category}@${"c".repeat(64)}` }
    ]));
    const manifest = {
        schemaVersion: 1,
        releaseCommit: commit,
        environment: { identity: "isolated-staging-a" },
        createdAt: "2026-01-01T00:00:00Z",
        approvedBy: "release-reviewer",
        ciRunId: "123456",
        evidence: Object.fromEntries(Object.keys(evidence).map((category) => [category, {
            reference: evidence[category].reference,
            result: "passed",
            observedAt: "2026-01-01T00:00:00Z",
            reviewer: "category-reviewer",
            checksum: `sha256:${"d".repeat(64)}`,
            deploymentId: "deploy-123",
            ...(category.toLowerCase().includes("migration") ? { migrationId: "migration-2026-01" } : {})
        }]))
    };

    assert.equal(validateEvidenceManifest(JSON.stringify(manifest), commit, evidence, "123456").valid, true);

    const wrongCiRun = validateEvidenceManifest(JSON.stringify(manifest), commit, evidence, "654321");
    assert.equal(wrongCiRun.valid, false);
    assert.ok(wrongCiRun.errors.some((error) => error.includes("ciRunId")));

    manifest.evidence.unexpected = { result: "passed" };
    const unknownCategory = validateEvidenceManifest(JSON.stringify(manifest), commit, evidence, "123456");
    assert.equal(unknownCategory.valid, false);
    assert.ok(unknownCategory.errors.some((error) => error.includes("unknown categories")));
    delete manifest.evidence.unexpected;

    manifest.releaseCommit = "b".repeat(40);
    const mismatch = validateEvidenceManifest(JSON.stringify(manifest), commit, evidence, "123456");
    assert.equal(mismatch.valid, false);
    assert.ok(mismatch.errors.some((error) => error.includes("does not match")));
});
