"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { handler } = require("../netlify/functions/deploy");

const request = (zip) => handler({ httpMethod: "POST", headers: { authorization: "Bearer test", "content-type": "application/json" }, body: JSON.stringify({ zip: Buffer.from(zip).toString("base64") }) });

test("deployment rejects traversal names", async () => {
    const result = await request(Buffer.from("PK\x03\x04../evil", "binary"));
    assert.equal(result.statusCode, 400);
});

test("deployment rejects incomplete local headers", async () => {
    const result = await request(Buffer.from("PK\x03\x04", "binary"));
    assert.equal(result.statusCode, 400);
});

test("deployment rejects arbitrary executable extensions in archive-like input", async () => {
    const result = await request(Buffer.from("PK\x03\x04<script.js>", "binary"));
    assert.equal(result.statusCode, 400);
});

test("deployment source applies the output contract to manifests and ZIP contents", () => {
    const fs = require("node:fs");
    const source = fs.readFileSync(require("node:path").join(__dirname, "..", "netlify/functions/deploy.js"), "utf8");
    assert.match(source, /validateOutput\(textFiles\)/);
    assert.match(source, /validateOutput\(body\.files\)/);
    assert.match(source, /outputIssues\.some\(\(issue\) => issue\.severity === "blocking"\)/);
});

test("deployment validates the archive before authentication or provider access", () => {
    const fs = require("node:fs");
    const source = fs.readFileSync(require("node:path").join(__dirname, "..", "netlify/functions/deploy.js"), "utf8");
    assert.ok(source.indexOf("inspectZipArchive(zip)") < source.indexOf("user = await authenticate(event)", source.indexOf("inspectZipArchive(zip)")));
    assert.ok(source.indexOf("user = await authenticate(event)", source.indexOf("inspectZipArchive(zip)")) < source.indexOf("provider.deploy(zip)"));
});
