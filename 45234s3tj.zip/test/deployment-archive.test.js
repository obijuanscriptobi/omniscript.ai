"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { handler } = require("../netlify/functions/deploy");

function crc32(buffer) {
    let crc = 0xffffffff;
    for (const byte of buffer) {
        crc ^= byte;
        for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
    return (crc ^ 0xffffffff) >>> 0;
}

function entry(name, content, method = 0) {
    const filename = Buffer.from(name);
    const source = Buffer.from(content);
    const compressed = method === 8 ? require("node:zlib").deflateRawSync(source) : source;
    const local = Buffer.alloc(30 + filename.length);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(method, 8);
    local.writeUInt32LE(crc32(source), 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(source.length, 22);
    local.writeUInt16LE(filename.length, 26);
    filename.copy(local, 30);

    const central = Buffer.alloc(46 + filename.length);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(method, 10);
    central.writeUInt32LE(crc32(source), 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(source.length, 24);
    central.writeUInt16LE(filename.length, 28);
    filename.copy(central, 46);
    return { local: Buffer.concat([local, compressed]), central, size: source.length, compressed: compressed.length };
}

function zip(entries) {
    const records = entries.map((item) => entry(item[0], item[1], item[2] || 0));
    let offset = 0;
    const centrals = records.map((record) => {
        record.central.writeUInt32LE(offset, 42);
        offset += record.local.length;
        return record.central;
    });
    const locals = records.map((record) => record.local);
    const centralDirectory = Buffer.concat(centrals);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(records.length, 8);
    end.writeUInt16LE(records.length, 10);
    end.writeUInt32LE(centralDirectory.length, 12);
    end.writeUInt32LE(offset, 16);
    return Buffer.concat([...locals, centralDirectory, end]);
}

function request(archive, files) {
    return handler({
        httpMethod: "POST",
        headers: { authorization: "Bearer test-token", "content-type": "application/json" },
        body: JSON.stringify({ zip: archive.toString("base64"), ...(files ? { files } : {}) })
    });
}

function contractFiles() {
    return {
        "index.html": "<!doctype html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width\"><title>Northstar</title><meta name=\"description\" content=\"A useful website.\"><link rel=\"canonical\" href=\"https://example.com/\"><meta property=\"og:title\" content=\"Northstar\"></head><body><h1>Northstar</h1></body></html>",
        "style.css": "body{color:#111}",
        "script.js": "document.documentElement.dataset.ready='true';",
        "favicon.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\"></svg>",
        "sitemap.xml": "<urlset></urlset>",
        "robots.txt": "User-agent: *\nAllow: /",
        "netlify.toml": "[build]\n  publish = '.'"
    };
}

test("deployment rejects an archive with a checksum mismatch before authentication", async () => {
    const archive = zip([["index.html", "<!doctype html>"]]);
    const contentOffset = archive.indexOf(Buffer.from("<!doctype html>"));
    archive[contentOffset] ^= 0xff;
    const result = await request(archive);
    assert.equal(result.statusCode, 400);
    assert.equal(JSON.parse(result.body).code, "UNSAFE_ARCHIVE");
});

test("deployment rejects traversal paths from the archive itself", async () => {
    const result = await request(zip([["../evil.js", "alert(1)"]]));
    assert.equal(result.statusCode, 422);
    assert.equal(JSON.parse(result.body).issues[0].code, "UNSAFE_ZIP_ENTRY");
});

test("deployment rejects archives missing required deployment files", async () => {
    const result = await request(zip([["index.html", "<!doctype html>"] ]));
    assert.equal(result.statusCode, 422);
    assert.equal(JSON.parse(result.body).code, "UNSAFE_ARCHIVE");
});

test("deployment validates deflated archive entries", async () => {
    const files = contractFiles();
    const archive = zip(Object.entries(files).map(([name, content]) => [name, content, 8]));
    const result = await request(archive, files);
    assert.notEqual(result.statusCode, 400);
    assert.notEqual(result.statusCode, 422);
});

test("deployment rejects manifest/archive filename mismatches", async () => {
    const files = contractFiles();
    const archive = zip(Object.entries(files));
    const result = await request(archive, { ...files, "extra.txt": "not in archive" });
    assert.equal(result.statusCode, 409);
    assert.equal(JSON.parse(result.body).code, "MANIFEST_ARCHIVE_MISMATCH");
});

test("deployment rejects unsafe archive content independently of the manifest", async () => {
    const files = contractFiles();
    files["index.html"] = files["index.html"].replace("</body>", "<script src=\"https://evil.example/x.js\"></script></body>");
    const archive = zip(Object.entries(files));
    const result = await request(archive);
    assert.equal(result.statusCode, 422);
    assert.equal(JSON.parse(result.body).code, "UNSAFE_ARCHIVE");
});
