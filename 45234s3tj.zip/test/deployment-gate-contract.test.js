"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const source = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("deployment surfaces retain the same validation primitives", () => {
    const deploy = source("netlify/functions/deploy.js");
    const preflight = source("netlify/functions/preflight.js");
    assert.match(deploy, /validateFiles/);
    assert.match(deploy, /validateOutput/);
    assert.match(deploy, /validateRevision/);
    assert.match(deploy, /inspectZipArchive/);
    assert.match(preflight, /validateFiles/);
    assert.match(preflight, /validateOutput/);
    assert.match(preflight, /validateRevision/);
});

test("provider access is ordered after validation in deployment", () => {
    const deploy = source("netlify/functions/deploy.js");
    const archiveValidation = deploy.indexOf("inspectZipArchive(zip)");
    const authentication = deploy.indexOf("user = await authenticate(event)", archiveValidation);
    assert.ok(archiveValidation < authentication);
    assert.ok(deploy.indexOf("validateOutput(body.files)") < authentication);
    assert.ok(deploy.indexOf("provider.deploy(zip)") > authentication);
});

test("publish verification requires authentication and validates its request boundary", () => {
    const verify = source("netlify/functions/verify-deployment.js");
    assert.match(verify, /await authenticate\(event\)/);
    assert.match(verify, /FILE_RE/);
    assert.match(verify, /safeOrigin/);
    assert.match(verify, /statusCode: 422/);
});
