"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { handler } = require("../netlify/functions/deploy");

function event(overrides = {}) {
    return {
        httpMethod: "POST",
        headers: { authorization: "Bearer test-token", "content-type": "application/json" },
        body: "{}",
        ...overrides
    };
}

test("deployment rejects unsupported methods", async () => {
    const result = await handler(event({ httpMethod: "DELETE" }));
    assert.equal(result.statusCode, 405);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment requires bearer authentication", async () => {
    const result = await handler(event({ headers: {} }));
    assert.equal(result.statusCode, 401);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment rejects invalid JSON", async () => {
    const result = await handler(event({ body: "not-json" }));
    assert.equal(result.statusCode, 400);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment rejects malformed ZIP payloads", async () => {
    const result = await handler(event({
        body: JSON.stringify({ zip: Buffer.from("not a zip").toString("base64") })
    }));
    assert.equal(result.statusCode, 400);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment rejects ZIP magic bytes without a valid directory", async () => {
    const result = await handler(event({
        body: JSON.stringify({ zip: Buffer.from([0x50, 0x4b, 0x03, 0x04]).toString("base64") })
    }));
    assert.equal(result.statusCode, 400);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment decodes platform base64-encoded JSON bodies", async () => {
    const body = JSON.stringify({
        zip: Buffer.from("not a zip").toString("base64")
    });
    const result = await handler(event({
        isBase64Encoded: true,
        body: Buffer.from(body, "utf8").toString("base64")
    }));
    assert.equal(result.statusCode, 400);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment status validates the deployment ID before contacting the provider", async () => {
    const result = await handler({
        httpMethod: "GET",
        headers: { authorization: "Bearer test-token", "content-type": "application/json" },
        queryStringParameters: { id: "../../secrets" }
    });
    assert.equal(result.statusCode, 400);
    assert.equal(JSON.parse(result.body).success, false);
});

test("deployment source includes an authenticated rollback path", () => {
    const fs = require("node:fs");
    const source = fs.readFileSync(require("node:path").join(__dirname, "..", "netlify/functions/deploy.js"), "utf8");
    assert.match(source, /queryStringParameters\?\.rollback/);
    assert.match(source, /authorizeDeployment/);
    assert.match(source, /provider\.rollback\(rollbackId\)/);
    assert.match(source, /rollback: true/);
});

test("deployment authorization denies missing membership before resource lookup", async () => {
    const calls = [];
    const supabase = {
        async request(path) {
            calls.push(path);
            return { data: [] };
        }
    };
    const deployment = await require("../netlify/functions/deploy")._test.authorizeDeployment(
        supabase,
        { headers: { authorization: "Bearer test-token" } },
        { id: "22222222-2222-4222-8222-222222222222" },
        "deploy-owned-by-another-project",
        "11111111-1111-4111-8111-111111111111"
    );
    assert.equal(deployment, null);
    assert.equal(calls.length, 1);
    assert.match(calls[0], /project_memberships/);
    assert.doesNotMatch(calls[0], /platform_deployments/);
});

test("deployment authorization requires the provider ID to belong to the authorized project", async () => {
    const calls = [];
    const supabase = {
        async request(path) {
            calls.push(path);
            return path.includes("project_memberships") ? { data: [{ role: "owner" }] } : { data: [] };
        }
    };
    const deployment = await require("../netlify/functions/deploy")._test.authorizeDeployment(
        supabase,
        { headers: { authorization: "Bearer test-token" } },
        { id: "22222222-2222-4222-8222-222222222222" },
        "foreign-deploy",
        "11111111-1111-4111-8111-111111111111"
    );
    assert.equal(deployment, null);
    assert.equal(calls.length, 2);
    assert.match(calls[1], /project_id=eq\.11111111-1111-4111-8111-111111111111/);
    assert.match(calls[1], /provider_deployment_id=eq\.foreign-deploy/);
});

test("deployment reports provider success when revision recording fails", async () => {
    const recording = await require("../netlify/functions/deploy")._test.recordDeploymentResult({
        supabase: { request: async () => { throw new Error("database unavailable"); } },
        event: { headers: {}, requestId: "recording-test" },
        userId: "22222222-2222-4222-8222-222222222222",
        projectId: "11111111-1111-4111-8111-111111111111",
        revisionId: "33333333-3333-4333-8333-333333333333",
        deploymentId: "deploy-1",
        deploymentStatus: "deployed",
        publicUrl: "https://example.test"
    });
    assert.deepEqual(recording, { success: false, retryable: true });
});

test("deployment authentication uses only the anon key and canonical origin", () => {
    const fs = require("node:fs");
    const source = fs.readFileSync(require("node:path").join(__dirname, "..", "netlify/functions/deploy.js"), "utf8");
    assert.match(source, /SUPABASE_ANON_KEY/);
    assert.doesNotMatch(source, /SUPABASE_ANON_KEY\s*\|\|\s*SUPABASE_SERVICE_ROLE_KEY/);
    assert.match(source, /endpoint: parsedUrl\.origin/);
    assert.match(source, /provider\.request\("\/auth\/v1\/user"/);
});

test("deployment failures use the adapter retry and timeout contract", () => {
    const fs = require("node:fs");
    const source = fs.readFileSync(require("node:path").join(__dirname, "..", "netlify/functions/deploy.js"), "utf8");
    assert.match(source, /createDeploymentProvider/);
    assert.match(source, /retries: 2/);
    assert.match(source, /timeoutMs: UPSTREAM_TIMEOUT_MS/);
    assert.match(source, /response\(504/);
    assert.match(source, /Retry once/);
});
