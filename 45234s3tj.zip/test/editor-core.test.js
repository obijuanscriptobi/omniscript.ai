"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("editor core provides manifests, file diffs, and broken-link detection", () => {
    const core = read("workspace-core.js");
    assert.match(core, /function manifest/);
    assert.match(core, /function diffFiles/);
    assert.match(core, /function brokenLocalReferences/);
    assert.match(core, /function auditSite/);
    assert.match(core, /workspaceCore = .*auditSite/);
    assert.match(read("index.html"), /workspace-core\.js/);
});

test("file diffs report UTF-8 byte sizes", () => {
    const source = read("workspace-core.js");
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(source, context);
    const diff = context.window.workspaceCore.diffFiles({ "index.html": "é" }, { "index.html": "😀" });
    assert.equal(diff[0].before.bytes, 2);
    assert.equal(diff[0].after.bytes, 4);
});

test("core helpers normalize root-relative and protocol-relative references", () => {
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-core.js"), context);
    const core = context.window.workspaceCore;
    const files = {
        "index.html": '<a href="/about.html">About</a><img src="//cdn.example.com/image.jpg"><img srcset="hero.webp 1x, missing.webp 2x"><a href="./missing.html?from=home">Missing</a>',
        "about.html": "<h1>About</h1>",
        "hero.webp": "image"
    };
    assert.deepEqual(core.brokenLocalReferences(files), [
        { file: "index.html", target: "missing.webp" },
        { file: "index.html", target: "./missing.html" }
    ]);
    assert.deepEqual(core.auditSite(files).localReferences, ["missing.webp", "./missing.html"]);
});

test("core helpers tolerate nullish values without collapsing them to empty text", () => {
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-core.js"), context);
    const core = context.window.workspaceCore;
    assert.notEqual(core.hash(0), core.hash(""));
    assert.equal(core.manifest(null) instanceof Object, true);
});

test("auditSite recognizes valid HTML metadata", () => {
    const source = read("workspace-core.js");
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(source, context);
    const report = context.window.workspaceCore.auditSite({
        "index.html": "<!doctype html><html lang='en'><head><meta name='viewport' content='width=device-width'><title>Example</title></head><body><h1>Welcome</h1></body></html>"
    });
    assert.equal(report.hasDoctype, true);
    assert.equal(report.hasLanguage, true);
    assert.equal(report.hasViewport, true);
    assert.equal(report.h1Count, 1);
});

test("workspace operations protect against stale async results", () => {
    const script = read("script.js");
    assert.match(script, /operationToken/);
    assert.match(script, /beginOperation/);
    assert.match(script, /isCurrentOperation\(operationToken\)/);
    assert.match(script, /state\.operationToken/);
});

test("generation and repair metadata are persisted locally", () => {
    const script = read("script.js");
    assert.match(script, /generationManifest/);
    assert.match(script, /repairLog/);
    assert.match(script, /recordRepairChange/);
    assert.match(script, /createFileManifest/);
});

test("workspace buttons use a shared non-reflowing loading contract", () => {
    const script = read("script.js");
    const styles = read("styles.css");
    assert.match(script, /function setButtonBusy\(button, busy\)/);
    assert.match(script, /button\.dataset\.loading = "true"/);
    assert.match(script, /button\.setAttribute\("aria-busy", "true"\)/);
    assert.doesNotMatch(script, /button\.textContent = busyText/);
    assert.match(script, /closest\("button\[data-loading/);
    assert.match(styles, /\.matrix-action-btn\[data-loading="true"\]::after/);
    assert.match(styles, /@keyframes button-loading-spin/);
});

test("workspace action rows protect controls at narrow widths", () => {
    const styles = read("styles.css");
    assert.match(styles, /\.matrix-action-btn,\n\.canvas-toggle-btn,\n\.copy-payload-btn \{/);
    assert.match(styles, /box-sizing: border-box/);
    assert.match(styles, /flex-shrink: 0/);
    assert.match(styles, /prefers-reduced-motion: reduce/);
});
