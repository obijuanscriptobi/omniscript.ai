import { test, expect } from "@playwright/test";

test.describe("export control contracts", () => {
    test("website export and project backup controls are present and gated", async ({ page }) => {
        await page.goto("/index.html", { waitUntil: "networkidle" });

        await expect(page.locator("#export-zip-btn")).toBeDisabled();
        await expect(page.locator("#export-project-json-btn")).toBeVisible();
        await expect(page.locator("#import-project-json-input")).toBeAttached();
    });

    test("Ad Studio exposes image, copy, metadata, and campaign exports", async ({ page }) => {
        await page.goto("/ad-studio.html", { waitUntil: "networkidle" });

        for (const selector of [
            "#export-image-btn",
            "#export-jpg-btn",
            "#export-copy-btn",
            "#export-metadata-btn",
            "#ad-studio-export-btn"
        ]) {
            await expect(page.locator(selector)).toBeVisible();
        }
    });
});
