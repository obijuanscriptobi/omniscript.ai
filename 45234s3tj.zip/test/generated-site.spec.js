import { test, expect } from "@playwright/test";

test.describe("published-site regression contract", () => {
    test("loads without console or page errors", async ({ page }) => {
        const consoleErrors = [];
        const pageErrors = [];
        page.on("console", (message) => { if (message.type() === "error") consoleErrors.push(message.text()); });
        page.on("pageerror", (error) => pageErrors.push(error.message));
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await expect(page.locator("html")).toHaveAttribute("lang", /.+/);
        expect(consoleErrors).toEqual([]);
        expect(pageErrors).toEqual([]);
    });

    test("keeps the primary layout inside the viewport", async ({ page }) => {
        await page.goto("/index.html", { waitUntil: "networkidle" });
        const overflow = await page.evaluate(() => ({
            documentWidth: document.documentElement.scrollWidth,
            viewportWidth: window.innerWidth,
            bodyWidth: document.body.scrollWidth
        }));
        expect(overflow.documentWidth).toBeLessThanOrEqual(overflow.viewportWidth + 1);
        expect(overflow.bodyWidth).toBeLessThanOrEqual(overflow.viewportWidth + 1);
    });

    test("exposes one primary heading and keyboard-visible controls", async ({ page }) => {
        await page.goto("/index.html");
        await expect(page.locator("h1")).toHaveCount(1);
        await page.keyboard.press("Tab");
        await expect(page.locator(":focus")).toBeVisible();
    });

    test("focus mode can be toggled without hiding the advanced escape hatch", async ({ page }) => {
        await page.goto("/index.html");
        const toggle = page.locator("#toggle-focus-mode-btn");
        await toggle.click();
        await expect(toggle).toHaveAttribute("aria-pressed", "true");
        await expect(page.locator("#show-advanced-tools-btn")).toBeVisible();
        await toggle.click();
        await expect(toggle).toHaveAttribute("aria-pressed", "false");
    });

    test("Business Hub persists a shared profile across reloads", async ({ page }) => {
        await page.goto("/index.html");
        await page.locator("#input-biz-name").fill("Northstar Studio");
        await page.locator("#input-biz-hook").fill("Clearer websites for local teams");
        await page.locator("#input-biz-location").fill("Austin, TX");
        await page.locator("#input-primary-cta").fill("Start a project");
        await page.waitForTimeout(350);
        await page.reload();
        await expect(page.locator("#input-biz-name")).toHaveValue("Northstar Studio");
        await expect(page.locator("#business-hub-score")).toHaveText("100% ready");
    });

    test("CRM export includes an escaped local lead", async ({ page }) => {
        await page.goto("/index.html");
        await page.evaluate(() => window.workspaceCRM.add({ name: 'A "quoted" lead', email: "lead@example.com" }));
        await page.locator("#show-advanced-tools-btn").click();
        await expect(page.locator("#lead-inbox-count")).toHaveText("1 lead");
        const csv = await page.evaluate(() => window.workspaceCRM.exportCsv());
        expect(csv).toContain('"A ""quoted"" lead"');
    });
});
