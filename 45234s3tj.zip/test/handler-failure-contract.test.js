"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const deploy = require("../netlify/functions/deploy");
const submit = require("../netlify/functions/submit-form");
const search = require("../netlify/functions/search");
const scrape = require("../netlify/functions/scrape");

function json(result) {
    return JSON.parse(result.body || "{}");
}

function withEnv(values, callback) {
    const previous = {};
    for (const [key, value] of Object.entries(values)) {
        previous[key] = process.env[key];
        if (value === undefined) delete process.env[key];
        else process.env[key] = value;
    }
    return Promise.resolve()
        .then(callback)
        .finally(() => {
            for (const [key, value] of Object.entries(previous)) {
                if (value === undefined) delete process.env[key];
                else process.env[key] = value;
            }
        });
}

test("deployment handler fails closed when distributed abuse protection is unavailable", async () => {
    await withEnv({
        UPSTASH_REDIS_REST_URL: undefined,
        UPSTASH_REDIS_REST_TOKEN: undefined
    }, async () => {
        const result = await deploy.handler({
            httpMethod: "GET",
            headers: {
                authorization: "Bearer fixture-token",
                "x-request-id": "deploy-failure-fixture"
            },
            queryStringParameters: { id: "deploy-1", projectId: "11111111-1111-4111-8111-111111111111" }
        });
        assert.equal(result.statusCode, 503);
        assert.equal(json(result).retryable, true);
        assert.equal(result.headers["X-Request-ID"], "deploy-failure-fixture");
        assert.doesNotMatch(result.body, /fixture-token|SUPABASE|NETLIFY/i);
    });
});

test("form handler returns a safe configuration failure with correlation headers", async () => {
    await withEnv({
        PUBLIC_SITE_ORIGIN: "https://example.test",
        LEADS_WEBHOOK_URL: undefined,
        SUPABASE_URL: undefined,
        SUPABASE_SERVICE_ROLE_KEY: undefined
    }, async () => {
        const result = await submit.handler({
            httpMethod: "POST",
            headers: {
                origin: "https://example.test",
                "x-request-id": "form-failure-fixture",
                "content-type": "application/json"
            },
            body: JSON.stringify({ name: "Fixture", email: "fixture@example.test" })
        });
        assert.equal(result.statusCode, 503);
        assert.equal(json(result).success, false);
        assert.equal(json(result).requestId, "form-failure-fixture");
        assert.equal(result.headers["X-Request-ID"], "form-failure-fixture");
        assert.doesNotMatch(result.body, /SUPABASE_SERVICE_ROLE_KEY|fixture-secret|Bearer/i);
    });
});

test("search and scrape handlers reject unauthenticated requests safely", async () => {
    const event = {
        httpMethod: "POST",
        headers: { "x-request-id": "provider-auth-fixture" },
        body: "{}"
    };
    const [searchResult, scrapeResult] = await Promise.all([
        search.handler(event),
        scrape.handler(event)
    ]);

    assert.equal(searchResult.statusCode, 401);
    assert.equal(scrapeResult.statusCode, 401);
    assert.equal(json(searchResult).success, false);
    assert.equal(json(scrapeResult).success, false);
    assert.doesNotMatch(searchResult.body, /SUPABASE|TOKEN|SECRET/i);
    assert.doesNotMatch(scrapeResult.body, /SUPABASE|SCRAPINGBEE|TOKEN|SECRET/i);
    assert.match(scrapeResult.headers["Content-Type"], /json/i);
    assert.equal(json(searchResult).requestId, "provider-auth-fixture");
    assert.equal(json(scrapeResult).requestId, "provider-auth-fixture");
});

test("search and scrape failure handlers use safe generic provider messages", () => {
    const fs = require("node:fs");
    const path = require("node:path");
    for (const file of ["search.js", "scrape.js"]) {
        const source = fs.readFileSync(path.join(__dirname, "..", "netlify/functions", file), "utf8");
        assert.match(source, /temporarily unavailable/);
        assert.match(source, /requestId: correlationId/);
        assert.match(source, /retryable: Boolean\(error\?\.retryable\)/);
        assert.doesNotMatch(source, /error: `(?:Search|Scrape) service failed: \$\{error/);
    }
});
