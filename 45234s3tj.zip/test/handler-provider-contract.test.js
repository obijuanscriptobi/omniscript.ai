"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

function jsonContract(source, file) {
    assert.match(source, /JSON\.stringify/ , `${file} must return JSON payloads`);
    assert.match(source, /securityHeaders|withSecurityHeaders/, `${file} must apply security headers`);
    assert.match(source, /requestId/, `${file} must propagate request IDs`);
    assert.doesNotMatch(source, /error:\s*error\.message/, `${file} must not expose raw errors`);
}

test("provider-facing handlers expose safe response contracts", () => {
    for (const file of [
        "netlify/functions/deploy.js",
        "netlify/functions/submit-form.js",
        "netlify/functions/search.js",
        "netlify/functions/scrape.js",
        "netlify/functions/analytics.js",
        "netlify/functions/verify-deployment.js",
        "netlify/functions/retry-leads.js",
        "netlify/functions/projects.js",
        "netlify/functions/project-files.js",
        "netlify/functions/project-memberships.js",
        "netlify/functions/invitation.js"
    ]) jsonContract(read(file), file);
});

test("search and scrape map provider failures to generic correlated responses", () => {
    for (const file of ["netlify/functions/search.js", "netlify/functions/scrape.js"]) {
        const source = read(file);
        assert.match(source, /statusCode: error\?\.retryable \? 502 : 500/);
        assert.match(source, /success: false/);
        assert.match(source, /requestId: correlationId/);
        assert.match(source, /temporarily unavailable/);
        assert.doesNotMatch(source, /error: `[^`]*\$\{error/);
    }
});

test("deployment handles provider success, rollback, timeout, and safe failure states", () => {
    const source = read("netlify/functions/deploy.js");
    assert.match(source, /provider\.deploy\(zip\)/);
    assert.match(source, /provider\.status\(deployId\)/);
    assert.match(source, /provider\.rollback\(rollbackId\)/);
    assert.match(source, /response\(504,\s*\{/);
    assert.match(source, /retryable: true/);
    assert.match(source, /Deployment error/);
    assert.doesNotMatch(source, /error:\s*error\.message/);
});

test("form delivery preserves duplicate, retryable, and fallback distinctions", () => {
    const source = read("netlify_functions_submit_form.js");
    assert.match(source, /duplicate/i);
    assert.match(source, /retryable/);
    assert.match(source, /lead_delivery_failures/);
    assert.match(source, /requestId/);
    assert.match(source, /Idempotency-Key/);
    assert.doesNotMatch(source, /JSON\.stringify\(\{[^}]*error:\s*error\.message/);
});

test("server provider calls use adapters while browser fetches remain client-side", () => {
    const directory = path.join(root, "netlify/functions");
    for (const file of fs.readdirSync(directory).filter((name) => name.endsWith(".js"))) {
        if (["csp-report.js", "config.js"].includes(file)) continue;
        const source = read(`netlify/functions/${file}`);
        if (/\bfetch\s*\(/.test(source)) {
            assert.match(source, /providerClient|deploymentAdapter/, `${file} bypasses the provider adapter`);
        }
    }
    for (const file of ["script.js", "supabase-client.js", "workspace-core.js", "app-loader.js"]) {
        assert.match(read(file), /fetch\s*\(/, `${file} should retain browser-side requests`);
    }
});

test("live staging checks are explicitly opt-in and cleanup is part of the workflow", () => {
    const workflow = read("staging-workflow.js");
    const smoke = read("test/staging-smoke.spec.js");
    assert.match(workflow, /CODEWISE_STAGING_WORKFLOW/);
    assert.match(workflow, /requireEnabled/);
    assert.match(workflow, /cleanup/);
    assert.match(workflow, /rollback/);
    assert.match(smoke, /CODEWISE_STAGING_PROVIDER_CHECKS/);
    assert.match(smoke, /CODEWISE_STAGING_ADVERSARIAL/);
});

test("release evidence remains a template until redacted passing evidence exists", () => {
    const record = read("docs/STAGING-RELEASE-RECORD.md");
    assert.match(record, /Do not paste credentials/);
    assert.match(record, /Evidence index/);
    assert.match(record, /Redacted/);
    assert.match(record, /Approved for controlled beta/);
});
