"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("prospect qualification requires direct reputation evidence and a usable contact", () => {
    const source = read("prospect-engine.js");
    assert.match(source, /confidence === "direct"/);
    assert.match(source, /hasUsableContact = Boolean\(prospect\.companyPhone \|\| prospect\.workEmail\)/);
    assert.doesNotMatch(source, /hasContact = Boolean\(prospect\.companyPhone \|\| prospect\.workEmail \|\| prospect\.website\)/);
});

test("prospect scans discover broadly before enrichment and preserve possible duplicates", () => {
    const source = read("prospect-engine.js");
    assert.match(source, /best \$\{subject\} in \$\{location\}/);
    assert.match(source, /\$\{subject\} \$\{location\} reviews/);
    assert.match(source, /runAuditQueue\(additions/);
    assert.match(source, /possibleDuplicateOf/);
    assert.match(source, /normalizedPhone/);
    assert.doesNotMatch(source, /signals\.rating > 0 && signals\.rating >=/);
});

test("prospect selection, shared filtering, bounded audits, freshness, and feedback are wired", () => {
    const source = read("prospect-engine.js");
    const html = read("leads.html");
    assert.match(source, /function getVisibleProspects/);
    assert.match(source, /selectedVisibleProspects/);
    assert.match(source, /Math\.min\(3, targets\.length\)/);
    assert.match(source, /Audit cancelled/);
    assert.match(source, /scoreBreakdown/);
    assert.match(source, /Recheck recommended/);
    assert.match(source, /data-save-feedback/);
    assert.match(source, /Promise\.allSettled\(queries/);
    assert.match(source, /getVisibleProspects\(\)\.filter\(\(prospect\) => prospect\.website/);
    assert.match(source, /contactCheckedAt/);
    assert.match(source, /reputationCheckedAt/);
    assert.match(source, /failed without discarding successful results/);
    assert.match(html, /id="research-industry"/);
    assert.match(html, /id="select-visible-btn"/);
    assert.match(html, /Cities, regions, or nearby place names/);
});

test("verification stores provenance and retry failures as needs-review", () => {
    const source = read("prospect-engine.js");
    assert.match(source, /verificationSourceUrl/);
    assert.match(source, /verificationCheckedAt/);
    assert.match(source, /websiteAudit.*sourceUrl/);
    assert.match(source, /websiteAudit.*checkedAt/);
    assert.match(source, /verificationStatus = "needs-review"/);
    assert.match(source, /attempt < 2/);
    assert.match(source, /error\.retryable/);
});

test("CSV export includes audit provenance and evidence", () => {
    const source = read("prospect-engine.js");
    assert.match(source, /verificationSourceUrl/);
    assert.match(source, /verificationCheckedAt/);
    assert.match(source, /auditEvidence/);
});

test("provider adapters expose safe failure responses for rate limits and timeouts", () => {
    const search = read("netlify_functions_search.js");
    const scrape = read("netlify_functions_scrape.js");
    assert.match(search, /status === 429/);
    assert.match(search, /Search timed out/);
    assert.match(scrape, /webResponse\.status === 429/);
    assert.match(scrape, /request timed out/i);
    assert.match(scrape, /SCRAPINGBEE_NOT_CONFIGURED/);
});

test("leads cloud updates can persist refreshed prospect evidence", () => {
    const engine = read("prospect-engine.js");
    const api = read("netlify/functions/leads.js");
    assert.match(engine, /JSON\.stringify\(\{ prospect \}\)/);
    assert.match(api, /hasOwnProperty\.call\(body, "message"\)/);
});

test("conversion loop connects audit context to a reviewable revision", () => {
    const contract = read("conversion-loop-contract.js");
    const index = read("index.html");
    const audit = read("audit.html");
    const migration = read("supabase/website-audits.sql");
    assert.match(contract, /projectId.*leadId.*auditId.*revisionId/);
    assert.match(contract, /buildSiteBrief/);
    assert.match(contract, /createRevision/);
    assert.match(contract, /approvalRequired: true/);
    assert.match(index, /conversion-loop-contract\.js/);
    assert.match(index, /audit-improvement/);
    assert.match(audit, /generate-improved-site-btn/);
    assert.match(migration, /create table if not exists public\.site_revisions/);
    assert.match(migration, /audit_id uuid references public\.website_audits/);
});

test("revision handoff supports approval, safe application, and server persistence", () => {
    const contract = read("conversion-loop-contract.js");
    const api = read("netlify/functions/revisions.js");
    const generator = read("workflow-revisions.js");
    assert.match(contract, /approveChange/);
    assert.match(contract, /applyApprovedChanges/);
    assert.match(contract, /persistRevision/);
    assert.match(api, /site_revisions/);
    assert.match(api, /deployment_id/);
    assert.match(generator, /workspace:revision-applied/);
});

test("deployment, analytics, and experiment contracts preserve the revision loop", () => {
    const deploy = read("netlify/functions/deploy.js");
    const analytics = read("netlify/functions/analytics.js");
    const platform = read("netlify/functions/platform.js");
    const migration = read("supabase/platform.sql");
    const revisions = read("supabase/website-audits.sql");
    assert.match(deploy, /body\.revisionId/);
    assert.match(deploy, /deployment_id/);
    assert.match(analytics, /revision_id/);
    assert.match(analytics, /experiment_id/);
    assert.match(analytics, /booking_completed/);
    assert.match(platform, /analytics-report/);
    assert.match(platform, /conversionRate/);
    assert.match(platform, /methodology/);
    assert.match(migration, /revision_id uuid/);
    assert.match(migration, /experiment_id uuid references public\.project_experiments/);
    assert.equal((revisions.match(/^\s*deployment_id\s+text,\s*$/gm) || []).length, 0);
    assert.match(revisions, /add column if not exists deployment_id/);
});

test("visual evidence is reproducible and does not claim cross-origin screenshots", () => {
    const visual = read("visual-evidence.js");
    const runner = read("visual-audit-runner.js");
    const index = read("index.html");
    assert.match(visual, /horizontalOverflowPx/);
    assert.match(visual, /ctaVisibleInFirstViewport/);
    assert.match(visual, /compare/);
    assert.match(visual, /not be rasterized|not accessible/);
    assert.match(runner, /chromium\.launch/);
    assert.match(runner, /page\.screenshot/);
    assert.match(runner, /compareVisualAudits/);
    assert.match(runner, /privateAddress/);
    assert.match(read("conversion-loop-contract.js"), /captureVisualEvidence/);
    assert.match(index, /visual-evidence\.js/);
    const workflow = read("visual-audit-workflow.js");
    assert.match(workflow, /captureVisualAudit/);
    assert.match(workflow, /compareVisualAudits/);
    assert.match(workflow, /auditPatch/);
    assert.match(workflow, /revisionPatch/);
});

test("lead import hands off to the shared website audit contract", () => {
    const leads = read("prospect-engine.js");
    const audit = read("audit.js");
    const contract = read("audit-contract.js");
    assert.match(leads, /data-import-audit/);
    assert.match(leads, /websiteAuditContract\?\.upsert/);
    assert.match(leads, /audit\.html\?/);
    assert.match(audit, /audit-in-progress/);
    assert.match(audit, /audit-complete/);
    assert.match(audit, /websiteAuditContract\?\.upsert/);
    assert.match(contract, /audit_findings|normalizeFinding/);
});
