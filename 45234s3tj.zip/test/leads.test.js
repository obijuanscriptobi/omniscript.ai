"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const leads = require("../netlify/functions/leads.js");

test("lead API rejects unauthenticated access", async () => {
    const result = await leads.handler({ httpMethod: "GET", queryStringParameters: { projectId: "00000000-0000-4000-8000-000000000000" }, headers: {} });
    assert.equal(result.statusCode, 401);
});

test("lead API rejects unsupported methods", async () => {
    const result = await leads.handler({ httpMethod: "PUT", queryStringParameters: {}, headers: {} });
    assert.equal(result.statusCode, 405);
});

test("lead API contract exposes the seven supported pipeline statuses", () => {
    const fs = require("node:fs");
    const source = fs.readFileSync(require.resolve("../netlify/functions/leads.js"), "utf8");
    for (const status of ["new", "verified", "contacted", "replied", "qualified", "won", "lost"]) assert.match(source, new RegExp(`\\"${status}\\"`));
    assert.doesNotMatch(source, /\\"booked\\"/);
});
