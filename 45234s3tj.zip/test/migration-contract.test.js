"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

const sqlFiles = [
    "supabase/schema.sql",
    "supabase/platform.sql",
    "supabase/project-memberships.sql",
    "supabase/collaboration-security.sql",
    "supabase/client-portal.sql",
    "supabase/usage-limits.sql",
    "supabase/lifecycle.sql",
    "supabase/operations.sql",
    "supabase/reliability.sql",
    "supabase/leads-prospect-upgrade.sql",
    "supabase/website-audits.sql",
    "supabase/work-context-isolation.sql",
    "supabase/proposal-handoffs.sql"
];

test("core migrations are repeatable and use guarded DDL", () => {
    for (const file of sqlFiles) {
        const sql = read(file).toLowerCase();
        assert.match(sql, /create table if not exists|alter table/, `${file} must declare tables safely`);
        assert.match(sql, /create index if not exists|create table if not exists/, `${file} must avoid unguarded index creation`);
    }
});

test("tenant-critical tables enable RLS and expose project ownership or membership policies", () => {
    const schema = read("supabase/schema.sql");
    const collaboration = read("supabase/collaboration-security.sql");
    const portal = read("supabase/client-portal.sql");

    for (const table of ["projects", "project_versions", "leads", "business_operations"]) {
        assert.match(schema, new RegExp(`alter table public\\.${table} enable row level security`, "i"), `${table} must enable RLS`);
    }
    for (const table of ["project_memberships", "project_file_versions", "project_approval_history"]) {
        assert.match(collaboration, new RegExp(`alter table public\\.${table} enable row level security`, "i"), `${table} must enable RLS`);
    }
    for (const table of ["client_portal_shares", "client_portal_comments"]) {
        assert.match(portal, new RegExp(`alter table public\\.${table} enable row level security`, "i"), `${table} must enable RLS`);
    }
    assert.match(schema, /auth\.uid\(\) = user_id/);
    assert.match(collaboration, /project_memberships.*auth\.uid\(\)/s);
    assert.match(collaboration, /split_part\(name, '\/', 1\)/);
});

test("migration contracts include integrity, bounded payloads, and timestamp triggers", () => {
    const schema = read("supabase/schema.sql");
    const limits = read("supabase/usage-limits.sql");

    assert.match(schema, /references auth\.users\(id\) on delete cascade/i);
    assert.match(schema, /check \(pg_column_size/i);
    assert.match(schema, /create trigger projects_updated_at/i);
    assert.match(schema, /create trigger leads_updated_at/i);
    assert.match(limits, /for update/i);
    assert.match(limits, /on conflict/i);
});

test("leads prospect upgrade accepts exactly the supported sales pipeline statuses", () => {
    const upgrade = read("supabase/leads-prospect-upgrade.sql");
    const expected = ["new", "verified", "contacted", "replied", "qualified", "won", "lost"];
    for (const status of expected) assert.match(upgrade, new RegExp(`'${status}'`));
    assert.doesNotMatch(upgrade, /'booked'/);
    assert.match(upgrade, /create index if not exists leads_project_status_updated_idx/i);
});

test("audit and analytics migrations expose one revision deployment field and measurable attribution", () => {
    const audit = read("supabase/website-audits.sql");
    const platform = read("supabase/platform.sql");
    assert.equal((audit.match(/^\s*deployment_id\s+text,\s*$/gim) || []).length, 1);
    assert.match(audit, /alter table public\.site_revisions add column if not exists deployment_id/i);
    assert.match(platform, /revision_id uuid references public\.site_revisions/i);
    assert.match(platform, /experiment_id uuid references public\.project_experiments/i);
    assert.match(platform, /booking_completed/);
});

test("work-context isolation guards inactive membership, parent scope, and context transfer", () => {
    const isolation = read("supabase/work-context-isolation.sql");
    assert.match(isolation, /c\.status = 'active'/);
    assert.match(isolation, /m\.status = 'active'/);
    assert.match(isolation, /m\.revoked_at is null/);
    for (const trigger of [
        "audit_findings_reassignment_guard",
        "site_revisions_reassignment_guard",
        "client_approvals_reassignment_guard",
        "project_membership_invitations_reassignment_guard",
        "client_portal_shares_reassignment_guard",
        "analytics_events_project_guard",
        "projects_context_reassignment_guard"
    ]) assert.match(isolation, new RegExp(`create trigger ${trigger}`));
    assert.match(isolation, /revoke all on function public\.enforce_analytics_event_project\(\) from public/);
    assert.match(isolation, /create trigger project_files_context_guard/);
    assert.match(isolation, /verification_status = 'verified'/);
    assert.match(isolation, /project_files_member_read[\s\S]*verification_status = 'verified'/);
    assert.match(isolation, /project_file_versions_storage_path_idx/);
    assert.match(isolation, /legacy-unverified/);
});

test("proposal and handoff persistence is project-scoped, immutable, and audited", () => {
    const handoffs = read("supabase/proposal-handoffs.sql");
    assert.match(handoffs, /references public\.client_approvals\(id\) on delete restrict/i);
    assert.match(handoffs, /references public\.project_proposals\(id\) on delete restrict/i);
    assert.match(handoffs, /public\.can_access_project_context\(project_id\)/i);
    assert.match(handoffs, /status='approved'/i);
    assert.match(handoffs, /current_project\.revision is distinct from selected_proposal\.revision/i);
    assert.match(handoffs, /permissions_confirmed and c\.asset_rights_confirmed/i);
    assert.match(handoffs, /project_handoffs_scope_guard/i);
    assert.match(handoffs, /projects_handoff_context_guard/i);
    assert.match(handoffs, /platform_audit_events/i);
    assert.match(handoffs, /unique \(project_id, proposal_id\)/i);
});

test("public token pages disable caching, indexing, archives, and referrer leakage", () => {
    const config = read("netlify.toml");
    for (const page of ["approval", "preview", "portal", "invitation", "proposal"]) {
        const section = config.match(new RegExp(`\\[\\[headers\\]\\]\\s+for = "/${page}\\.html"([\\s\\S]*?)(?=\\n\\[\\[headers\\]\\])`))?.[1] || "";
        assert.match(section, /Cache-Control = "no-store, max-age=0"/);
        assert.match(section, /X-Robots-Tag = "noindex, nofollow, noarchive"/);
        assert.match(section, /Referrer-Policy = "no-referrer"/);
    }
});

test("privileged service-role credentials remain server-side in project APIs", () => {
    const projects = read("netlify/functions/projects.js");
    const files = read("netlify/functions/project-files.js");
    assert.match(projects, /SUPABASE_SERVICE_ROLE_KEY/);
    assert.match(files, /SUPABASE_SERVICE_ROLE_KEY|config\(\)/);
    assert.match(projects, /SUPABASE_ANON_KEY/);
    assert.match(projects, /Authorization: `Bearer \$\{authorization\}`/);
});
