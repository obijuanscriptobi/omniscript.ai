"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "operating-mode.js"), "utf8");

function boot({ saved = null, legacy = null, search = "", allowOnboarding = false } = {}) {
    const values = new Map();
    if (saved !== null) values.set("omniscript-operating-mode-v1", saved);
    if (legacy !== null) values.set("morrow-creation-mode-v1", legacy);
    const listeners = new Map();
    const documentListeners = new Map();
    const mounted = [];
    const body = { setAttribute() {}, append(node) { mounted.push(node); } };
    const document = {
        readyState: "complete",
        documentElement: { dataset: {} }, body,
        querySelectorAll: () => [], querySelector: () => null, getElementById: () => null,
        addEventListener(type, callback) { documentListeners.set(type, callback); },
        dispatchEvent() {}, createElement(tag) {
            if (!allowOnboarding) throw new Error("onboarding should not mount when a record exists or a temporary mode is active");
            assert.equal(tag, "dialog");
            return {
                id: "", className: "", innerHTML: "", attributes: {},
                setAttribute(name, value) { this.attributes[name] = value; },
                addEventListener() {}, showModal() { this.open = true; }, close() {}, remove() {}
            };
        }
    };
    const window = {
        addEventListener(type, callback) { listeners.set(type, callback); }, dispatchEvent() {},
        supabaseWorkspace: null, workspaceContext: null
    };
    const context = {
        window, document, location: { search }, URLSearchParams, Date, JSON, Set, CustomEvent: class { constructor(type, init) { this.type = type; this.detail = init?.detail; } },
        localStorage: { getItem: (key) => values.get(key) ?? null, setItem: (key, value) => values.set(key, value), removeItem: (key) => values.delete(key) },
        console
    };
    vm.runInNewContext(source, context, { filename: "operating-mode.js" });
    return { api: window.operatingMode, values, listeners, document, mounted };
}

test("saved mode survives refresh and account changes persist", () => {
    const first = boot({ saved: JSON.stringify({ version: 1, mode: "self", source: "onboarding" }) });
    assert.equal(first.api.get(), "self");
    first.api.set("client", { source: "account" });
    const stored = JSON.parse(first.values.get(first.api.storageKey));
    assert.equal(stored.mode, "client");
    assert.equal(stored.source, "account");
    const refresh = boot({ saved: JSON.stringify(stored) });
    assert.equal(refresh.api.get(), "client");
});

test("query mode is temporary and does not overwrite the saved preference", () => {
    const app = boot({ saved: JSON.stringify({ version: 1, mode: "self", source: "account" }), search: "?mode=client" });
    assert.equal(app.api.get(), "client");
    assert.equal(JSON.parse(app.values.get(app.api.storageKey)).mode, "self");
});

test("a temporary query mode does not trigger or persist first-run onboarding", () => {
    const app = boot({ search: "?mode=client" });
    assert.equal(app.api.get(), "client");
    assert.equal(app.api.getRecord(), null);
    assert.equal(app.values.has(app.api.storageKey), false);
    assert.equal(app.mounted.length, 0);
});

test("first visit mounts onboarding and an explicit choice prevents it after refresh", () => {
    const first = boot({ allowOnboarding: true });
    assert.equal(first.mounted.length, 1);
    first.api.set("self", { source: "onboarding" });
    const saved = first.values.get(first.api.storageKey);
    assert.ok(saved);
    const refresh = boot({ saved });
    assert.equal(refresh.api.get(), "self");
    assert.equal(refresh.mounted.length, 0);
});

test("legacy owner and client values migrate to the central record", () => {
    const owner = boot({ legacy: JSON.stringify({ mode: "owner" }) });
    assert.equal(owner.api.get(), "self");
    assert.equal(JSON.parse(owner.values.get(owner.api.storageKey)).mode, "self");
    const client = boot({ legacy: "client" });
    assert.equal(client.api.get(), "client");
    assert.equal(JSON.parse(client.values.get(client.api.storageKey)).mode, "client");
});

test("switching mode only writes the operating-mode record", () => {
    const app = boot({ saved: JSON.stringify({ version: 1, mode: "self", source: "onboarding" }) });
    app.values.set("project-data", "keep me");
    app.values.set("morrow-next-steps-v2", "task data");
    app.values.set("morrow-appointments-v1", "appointment data");
    app.api.set("client", { source: "account" });
    assert.equal(app.values.get("project-data"), "keep me");
    assert.equal(app.values.get("morrow-next-steps-v2"), "task data");
    assert.equal(app.values.get("morrow-appointments-v1"), "appointment data");
});

test("account changes persist even when replacing a temporary query mode", () => {
    const app = boot({ saved: JSON.stringify({ version: 1, mode: "self", source: "account" }), search: "?mode=client" });
    app.api.set("client", { source: "account" });
    const stored = JSON.parse(app.values.get(app.api.storageKey));
    assert.equal(stored.mode, "client");
    assert.equal(stored.source, "account");
});

test("show-all-tools is managed by the central preference service", () => {
    const app = boot({ saved: JSON.stringify({ version: 1, mode: "self", source: "account" }) });
    assert.equal(app.api.getShowAllTools(), false);
    app.api.setShowAllTools(true, { source: "account" });
    assert.equal(app.api.getShowAllTools(), true);
    assert.equal(app.values.get("omniscript-show-all-tools-v1"), "true");
});

test("mode capabilities preserve core tools and add client operations", () => {
    const app = boot({ saved: JSON.stringify({ version: 1, mode: "self", source: "account" }) });
    assert.equal(app.api.getCapabilities().responsiveWebsites, true);
    assert.equal(app.api.getCapabilities().ads, true);
    assert.equal(app.api.getCapabilities().clientApprovals, false);
    app.api.set("client", { source: "account" });
    assert.equal(app.api.getCapabilities().responsiveWebsites, true);
    assert.equal(app.api.getCapabilities().clientApprovals, true);
    assert.equal(app.api.getCapabilities().handoff, true);
});
