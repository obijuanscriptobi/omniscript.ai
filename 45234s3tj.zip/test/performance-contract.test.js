"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("startup loader defers optional work and deduplicates script loads", () => {
    const source = read("app-loader.js");
    assert.match(source, /requestIdleCallback|setTimeout\(start/);
    assert.match(source, /const scriptLoads = new Map\(\)/);
    assert.match(source, /scriptLoads\.has\(source\)/);
    assert.match(source, /scriptLoads\.delete\(source\)/);
    assert.match(source, /loadOptional/);
});

test("startup diagnostics publish enforceable script, byte, staged, and CLS budgets", () => {
    const loader = read("app-loader.js");
    const stages = read("website-maker-stage-loader.js");
    assert.match(loader, /PERFORMANCE_BUDGETS = Object\.freeze/);
    assert.match(loader, /initialScriptCount: 64/);
    assert.match(loader, /transferredScriptBytes: 2_500_000/);
    assert.match(loader, /stagedScriptCount: 7/);
    assert.match(loader, /cumulativeLayoutShift: 0\.1/);
    assert.match(loader, /PerformanceObserver/);
    assert.match(loader, /budgetResults/);
    assert.match(loader, /scriptEntries\.length > 0/);
    assert.match(loader, /entry\.transferSize \|\| entry\.encodedBodySize/);
    assert.match(loader, /diagnosticsAvailable/);
    assert.match(loader, /transferredScriptBytes > 0/);
    assert.match(loader, /stagedScriptCount: stagedScriptCount <= PERFORMANCE_BUDGETS\.stagedScriptCount/);
    assert.match(loader, /stagedExecutionCount: stagedExecutionCount <= PERFORMANCE_BUDGETS\.stagedScriptCount/);
    assert.match(loader, /refreshWorkspaceStartupDiagnostics/);
    assert.match(stages, /loadedScriptCount/);
    assert.match(stages, /executionCounts/);
    assert.match(stages, /sources: \(name\)/);
});

test("client request timeout supports cancellation signals", () => {
    const source = read("supabase-client.js");
    assert.match(source, /options\.signal/);
    assert.match(source, /addEventListener\("abort"/);
    assert.match(source, /removeEventListener\("abort"/);
    assert.match(source, /signal: requestOptions\.signal/);
});

test("client bundles do not introduce server credentials", () => {
    for (const file of ["app-loader.js", "supabase-client.js", "workspace-core.js", "phase3-ux.js"]) {
        assert.doesNotMatch(read(file), /SUPABASE_SERVICE_ROLE_KEY|NETLIFY_AUTH_TOKEN|RESEND_API_KEY/);
    }
});

test("phase 3 provides accessible offline and recovery feedback", () => {
    const source = read("phase3-ux.js");
    assert.match(source, /addEventListener\("offline"/);
    assert.match(source, /addEventListener\("online"/);
    assert.match(source, /aria-live/);
    assert.match(source, /Local editing and browser autosave remain available/);
    assert.match(read("index.html"), /phase3-ux\.js/);
});

test("phase 4 exposes privacy-safe runtime diagnostics and accessibility defaults", () => {
    const ux = read("phase3-ux.js");
    const base = read("styles/base.css");
    const responsive = read("styles/responsive.css");
    assert.match(ux, /workspaceRuntimeIssues/);
    assert.match(ux, /unhandledrejection/);
    assert.match(ux, /longtask/);
    assert.match(ux, /slice\(-20\)/);
    assert.match(base, /prefers-contrast: more/);
    assert.match(base, /pointer: coarse/);
    assert.match(responsive, /orientation: landscape/);
    assert.doesNotMatch(ux, /fetch\(/);
});
