"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");

function source(file) {
    return fs.readFileSync(path.join(root, file), "utf8");
}

test("server-side quotas and lifecycle gates are present", () => {
    const quota = source("netlify/functions/_quota.js");
    const migration = source("supabase/usage-limits.sql");
    const lifecycle = source("workspace-lifecycle.js");
    const contract = source("workspace-output-contract.js");
    assert.match(quota, /consumeQuota/);
    assert.match(quota, /QUOTA_EXCEEDED/);
    assert.match(migration, /for update|on conflict/i);
    assert.match(migration, /consume_usage_quota/);
    assert.match(lifecycle, /PUBLISH_GATE_BLOCKED/);
    assert.match(lifecycle, /VERIFICATION_REVISION_MISMATCH/);
    assert.match(contract, /MISSING_TITLE/);
    assert.match(contract, /SOURCE_BUDGET/);
    assert.match(contract, /MISSING_FAVICON/);
    assert.match(contract, /MISSING_SITEMAP/);
    assert.match(contract, /MISSING_ROBOTS/);
    assert.match(contract, /MISSING_OG/);
});

test("project membership administration is role-restricted and auditable", () => {
    const api = source("netlify/functions/project-memberships.js");
    const migration = source("supabase/project-memberships.sql");
    const config = source("netlify.toml");

    assert.match(api, /requireManager/);
    assert.match(api, /\["owner", "admin"\]/);
    assert.match(api, /membership\.role_changed/);
    assert.match(api, /membership\.revoked/);
    assert.match(api, /token_hash/);
    assert.match(migration, /project_membership_invitations/);
    assert.match(migration, /enable row level security/);
    assert.match(config, /from = "/api/project-memberships"/);
});

test("approval history is only exposed to project members when authenticated", () => {
    const api = source("netlify/functions/approval.js");
    assert.match(api, /authenticate\(event\)/);
    assert.match(api, /project_memberships/);
    assert.match(api, /client_reviewer/);
    assert.match(api, /history/);
});

test("private collaboration migration seeds owners and denies public file access", () => {
    const migration = source("supabase/collaboration-security.sql");
    assert.match(migration, /insert into public\.project_memberships/);
    assert.match(migration, /values \('project-files', 'project-files', false\)/);
    assert.match(migration, /bucket_id = 'project-files'/);
    assert.match(migration, /m\.user_id = auth\.uid\(\)/);
});

test("production APIs use the shared security policy", () => {
    const deploy = source("netlify/functions/deploy.js");
    const projects = source("netlify/functions/projects.js");
    const submit = source("netlify/functions/submit-form.js");
    const leads = source("netlify/functions/leads.js");

    assert.match(deploy, /securityHeaders\(\)/);
    assert.match(projects, /securityHeaders\(\)/);
    assert.match(submit, /securityHeaders\(/);
});

test("configuration reports safe capability readiness without exposing server secrets", () => {
    const config = source("netlify/functions/config.js");

    assert.match(config, /capabilities/);
    assert.match(config, /optionalUnavailable/);
    assert.match(config, /SCRAPINGBEE_API_KEY/);
    assert.match(config, /NETLIFY_AUTH_TOKEN/);
    assert.match(config, /PREFLIGHT_SIGNING_SECRET/);
    assert.doesNotMatch(config, /SUPABASE_SERVICE_ROLE_KEY[\s\S]*return response/);
});

test("deployment and project payloads enforce bounded input", () => {
    const deploy = source("netlify/functions/deploy.js");
    const projects = source("netlify/functions/projects.js");

    assert.match(deploy, /MAX_BODY_BYTES\s*=\s*12_000_000/);
    assert.match(deploy, /MAX_DEPLOY_BYTES\s*=\s*8_000_000/);
    assert.match(deploy, /valid ZIP archive/);
    assert.match(deploy, /function inspectZipArchive\(zip\)/);
    assert.match(deploy, /0x06054b50/);
    assert.match(deploy, /0x02014b50/);
    assert.match(deploy, /0x04034b50/);
    assert.match(projects, /MAX_TOTAL_FILE_BYTES\s*=\s*4_500_000/);
    assert.match(projects, /expectedRevision/);
    assert.match(projects, /"sitemap\.xml"/);
    assert.match(projects, /"robots\.txt"/);
});

test("authenticated lead API and lead storage schema are present", () => {
    const api = source("netlify/functions/leads.js");
    const schema = source("supabase/schema.sql");
    assert.match(api, /authenticate\(event\)/);
    assert.match(api, /project_id=eq/);
    assert.match(api, /status/);
    assert.match(schema, /create table if not exists public\.leads/);
    assert.match(schema, /alter table public\.leads enable row level security/);
});

test("lead delivery requires an allowlisted HTTPS webhook and browser origin", () => {
    const submit = source("netlify_functions_submit_form.js");

    assert.match(submit, /webhookUrl\.protocol !== "https:"/);
    assert.match(submit, /allowedHosts\.includes\(hostname\)/);
    assert.match(submit, /Idempotency-Key/);
    assert.match(submit, /DUPLICATE_WINDOW_MS/);
    assert.match(submit, /retryable/);
    assert.match(submit, /sec-fetch-site/);
    assert.match(submit, /PUBLIC_SITE_ORIGIN/);
});

test("distributed rate limits use an atomic fixed-window increment", () => {
    const security = source("netlify/functions/_security.js");
    assert.match(security, /EVAL/);
    assert.match(security, /count==1/);
    assert.match(security, /PEXPIRE/);
});

test("CSP matches the editor's intentional inline style updates", () => {
    const config = source("netlify.toml");
    assert.match(config, /style-src-attr 'unsafe-inline'/);
    assert.match(config, /script-src-attr 'none'/);
});

test("frontend form handling prevents cross-origin submission", () => {
    const script = source("script.js");
    const index = source("index.html");

    assert.match(script, /safeGeneratedFormAction/);
    assert.match(script, /credentials:\s*["']same-origin["']/);
    assert.match(script, /url\.origin !== window\.location\.origin/);
    assert.doesNotMatch(index, /application\/disabled-javascript/);
    assert.doesNotMatch(index, /application\/legacy-onboarding/);
});

test("workspace accessibility auditing covers named interactive controls and forced colors", () => {
    const audit = source("workspace-shell-audit.js");
    const base = source("styles/base.css");

    assert.match(audit, /querySelectorAll\("button, a\[href\]"\)/);
    assert.match(audit, /has no accessible name/);
    assert.match(base, /@media \(forced-colors: active\)/);
    assert.match(base, /outline: 3px solid CanvasText/);
});

test("exported generated forms are handled by the generated submit script", () => {
    const generator = source("generated-quality.js");

    assert.match(generator, /document\.querySelectorAll\('form\[action\]'\)/);
    assert.doesNotMatch(generator, /form\[action\]:not\(\[data-site-form\]\)/);
});

test("published site URLs reject query strings and fragments", () => {
    const script = source("script.js");

    assert.match(script, /url\.search/);
    assert.match(script, /url\.hash/);
});

test("cloud requests preserve same-origin credentials and protected auth headers", () => {
    const client = source("supabase-client.js");

    assert.match(client, /credentials:\s*["']same-origin["']/);
    assert.match(client, /\.\.\.authHeaders\(!isTokenRequest\)/);
});

test("cloud authentication and project requests have bounded timeouts", () => {
    const client = source("supabase-client.js");

    assert.match(client, /const API_TIMEOUT_MS = 15_000/);
    assert.match(client, /fetchWithTimeout\(\s*`\$\{state\.config\.url\}\/auth\/v1/);
    assert.match(client, /fetchWithTimeout\(`\/api\/projects\$\{query\}/);
    assert.match(client, /API_TIMEOUT_MS/);
});

test("signing out clears the active cloud project context", () => {
    const client = source("supabase-client.js");

    assert.match(client, /clearProjectContext\?\.\(\{ persist: true, announce: true \}\)/);
    assert.match(client, /clearProjectId\?\.\(\)/);
});

test("stale cloud responses cannot cross authentication sessions", () => {
    const client = source("supabase-client.js");

    assert.match(client, /authGeneration: 0/);
    assert.match(client, /state\.authGeneration \+= 1/);
    assert.match(client, /requestGeneration !== state\.authGeneration/);
});

test("cloud conflicts offer safe reload and explicit overwrite choices", () => {
    const client = source("supabase-client.js");

    assert.match(client, /PROJECT_CONFLICT/);
    assert.match(client, /showProjectConflict/);
    assert.match(client, /Reload cloud version/);
    assert.match(client, /Overwrite cloud version/);
    assert.match(client, /expectedRevision: project\?\.updated_at \|\| null/);
});

test("project authentication never falls back to the service-role key", () => {
    const projects = source("netlify/functions/projects.js");

    assert.match(projects, /const anonKey = String\(process\.env\.SUPABASE_ANON_KEY \|\| ""\)/);
    assert.match(projects, /apikey: anonKey/);
    assert.doesNotMatch(projects, /SUPABASE_ANON_KEY\s*\|\|\s*config\.key/);
});

test("shared platform requests protect auth headers regardless of casing", () => {
    const platform = source("netlify/functions/_platform.js");

    assert.match(platform, /toLowerCase\(\)\)/);
    assert.match(platform, /\["apikey", "authorization", "content-type"\]/);
    assert.match(platform, /Authorization: `Bearer \$\{key\}`/);
});

test("undo snapshots preserve the active page", () => {
    const script = source("script.js");

    assert.match(script, /projectId: state\.projectId,[\s\S]*activePage: state\.activePage,[\s\S]*previewMode/);
});

test("project renames use a metadata-only update", () => {
    const client = source("supabase-client.js");
    const projects = source("netlify/functions/projects.js");

    assert.match(client, /projectRequest\(\s*"PATCH"[\s\S]*\{\s*name: nextName/);
    assert.match(projects, /const hasProjectData = \["files", "formData", "previewMode"\]/);
});

test("workspace reset clears deployment and editor state", () => {
    const script = source("script.js");

    assert.match(script, /state\.publishedSiteUrl = ""/);
    assert.match(script, /state\.deploymentHistory = \[\]/);
    assert.match(script, /state\.redoHistory = \[\]/);
});

test("local workspace storage detects cross-tab edits before overwriting them", () => {
    const script = source("script.js");
    const state = source("workspace-state.js");

    assert.match(script, /addEventListener\("storage"/);
    assert.match(script, /externalChangePending/);
    assert.match(script, /Another workspace tab has newer changes/);
    assert.match(script, /if \(state\.externalChangePending\)/);
    assert.match(state, /externalChangePending: false/);
});

test("local autosave bounds oversized backups and retries transient storage failures", () => {
    const script = source("script.js");
    const state = source("workspace-state.js");

    assert.match(script, /serializedWorkspace\.length > 4_000_000/);
    assert.match(script, /localSaveAttempts/);
    assert.match(script, /Math\.min\(2_000 \* \(2 \*\* \(state\.localSaveAttempts - 1\)\), 8_000\)/);
    assert.match(script, /Export your work now/);
    assert.match(state, /localSaveAttempts: 0/);
});

test("preview updates defer non-visual audits without losing the latest edit", () => {
    const script = source("script.js");
    const state = source("workspace-state.js");

    assert.match(script, /updatePreview\(\);[\s\S]*requestIdleCallback/);
    assert.match(script, /runVisualQualityCheck\(\);/);
    assert.match(script, /cancelIdleCallback/);
    assert.match(state, /previewAuditTimer: null/);
});

test("preflight validation is deployed and quality checks are shared", () => {
    const preflight = source("netlify/functions/preflight.js");
    const quality = source("workspace-quality.js");
    const config = source("netlify.toml");
    const script = source("script.js");

    assert.match(preflight, /qualityReport/);
    assert.match(quality, /MISSING_TITLE/);
    assert.match(quality, /IMAGE_MISSING_ALT/);
    assert.match(config, /from = "/api/preflight"/);
    assert.match(script, /runServerPreflight/);
    assert.match(script, /await runServerPreflight\(preflight\.files\)/);
});

test("production error responses expose correlation identifiers", () => {
    const security = source("netlify/functions/_security.js");
    const deploy = source("netlify/functions/deploy.js");
    const submit = source("netlify/functions/submit-form.js");

    assert.match(security, /requestId: payload\.requestId \|\| correlationId/);
    assert.match(deploy, /const correlationId = requestId\(event\)/);
    assert.match(deploy, /createResponse\(event, correlationId\)/);
    assert.match(submit, /requestId/);
    assert.match(submit, /X-Request-ID/);
});

test("deployment retries expose transient failure state", () => {
    const deploy = source("netlify/functions/deploy.js");
    const adapter = source("netlify/functions/provider-adapters.js");

    assert.match(deploy, /retryable/);
    assert.match(deploy, /retries: 2/);
    assert.match(deploy, /response\(504/);
    assert.match(deploy, /guidance:\s*"Retry once\. If it continues, download the files\."/);
    assert.match(adapter, /status === 429/);
    assert.match(adapter, /CIRCUIT_FAILURE_THRESHOLD/);
    assert.match(adapter, /Provider circuit is open/);
});

test("AI generation has strict input, prompt, budget, deadline, and idempotency boundaries", () => {
    const architect = source("netlify/functions/website-architect.js");
    const core = source("netlify/functions/website-architect-core.js");
    assert.match(architect, /TOTAL_DEADLINE_MS/);
    assert.match(architect, /MAX_PROMPT_CHARS/);
    assert.match(architect, /MAX_OUTPUT_TOKENS/);
    assert.match(architect, /beginIdempotent/);
    assert.match(architect, /reserveQuota/);
    assert.match(architect, /commitQuota/);
    assert.match(core, /UNTRUSTED_IMPORTED_SOURCE/);
    assert.match(core, /UNTRUSTED_SEARCH_RESULTS/);
    assert.match(core, /UNTRUSTED_VISUAL_EVIDENCE/);
});

test("deployment verification checks redirects, response types, and revisions", () => {
    const verifier = source("netlify/functions/verify-deployment.js");
    assert.match(verifier, /contentTypePass/);
    assert.match(verifier, /redirectPass/);
    assert.match(verifier, /unexpected content type/);
    assert.match(verifier, /expectedRevision/);
    assert.match(verifier, /revision: expectedRevision/);
    assert.match(verifier, /DNS answer changed during validation/);
});

test("trust boundaries distinguish technical checks from production evidence", () => {
    const release = source("workspace-release.js");
    const benchmark = source("benchmark-ui.js");
    const quality = source("workspace-quality-model.js");
    const index = source("index.html");

    assert.match(release, /production-form-delivery-confirmed/);
    assert.match(release, /real production form delivery/i);
    assert.match(benchmark, /not a conversion guarantee/);
    assert.match(benchmark, /not an external competitor comparison/);
    assert.match(quality, /does not guarantee conversion performance/);
    assert.match(quality, /full device coverage/);
    assert.match(index, /successful import confirms preparation only/i);
});

test("deployment rollback is exposed only through the protected deployment route", () => {
    const deploy = source("netlify/functions/deploy.js");
    const script = source("script.js");

    assert.match(deploy, /queryStringParameters\?\.rollback/);
    assert.match(deploy, /await authenticate\(event\)/);
    assert.match(deploy, /authorizeDeployment/);
    assert.match(deploy, /provider\.rollback\(rollbackId\)/);
    assert.match(script, /rollback-site-btn/);
    assert.match(script, /rollbackLatestDeployment/);
});

test("scraper requires ScrapingBee and validates the target URL", () => {
    const scraper = source("netlify_functions_scrape.js");

    assert.match(scraper, /if \(!scrapingBeeKey\)/);
    assert.match(scraper, /SCRAPINGBEE_NOT_CONFIGURED/);
    assert.match(scraper, /SCRAPINGBEE_KEY/);
    assert.match(scraper, /createScrapingBeeUrl\(url, scrapingBeeKey\)/);
    assert.match(scraper, /await isSafeTarget\(targetUrl\)/);
    assert.doesNotMatch(scraper, /const viaScrapingBee = Boolean\(scrapingBeeKey\);\s*const requestUrl = viaScrapingBee\s*\? createScrapingBeeUrl/);
    assert.match(scraper, /endpoint\.searchParams\.set\("timeout", String\(LIMITS\.timeoutMs\)\)/);
    assert.match(scraper, /endpoint\.searchParams\.set\("render_js", "true"\)/);
    assert.match(scraper, /endpoint\.searchParams\.set\("wait", "1000"\)/);
    assert.match(scraper, /endpoint\.searchParams\.set\("premium_proxy", "true"\)/);
    assert.match(scraper, /endpoint\.searchParams\.set\("block_resources", "false"\)/);
    assert.match(scraper, /readProviderError\(webResponse\)/);
    assert.match(scraper, /Provider response:/);
    assert.match(scraper, /const viaScrapingBee = true/);
    assert.doesNotMatch(scraper, /fetch\(currentUrl/);
});
