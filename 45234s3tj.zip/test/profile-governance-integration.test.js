"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const source = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("release review evaluates canonical website and SEO governance", () => {
    const release = source("workspace-release.js");
    assert.match(release, /current\.businessProfile/);
    assert.match(release, /\["website", "seo"\]/);
    assert.match(release, /profileValidationIssues/);
    assert.match(release, /profileBlockers/);
    assert.match(release, /Approve or update the claim before publishing/);
});

test("content review falls back to the canonical profile", () => {
    const review = source("content-review.js");
    assert.match(review, /canonicalProfile\(\)/);
    assert.match(review, /profile\.identity\?\.displayName/);
    assert.match(review, /profile\.services\?\.join/);
    assert.match(review, /window\.contentReview = Object\.freeze/);
});
