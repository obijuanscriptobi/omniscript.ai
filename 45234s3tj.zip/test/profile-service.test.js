"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const source = fs.readFileSync(path.join(root, "profile-service.js"), "utf8");
const contract = fs.readFileSync(path.join(root, "business-profile.js"), "utf8");

function load({ stored = null, cloud = null } = {}) {
    const values = new Map(stored ? [["morrow-business-profile-v1", JSON.stringify({ profile: stored })]] : []);
    const localStorage = {
        getItem: (key) => values.get(key) || null,
        setItem: (key, value) => values.set(key, value),
        removeItem: (key) => values.delete(key)
    };
    const context = {
        window: {}, localStorage, Date, Math,
        CustomEvent: function CustomEvent(type, init) { this.type = type; this.detail = init?.detail; }
    };
    context.window.dispatchEvent = () => {};
    vm.runInNewContext(contract, context);
    context.window.workspaceState = { createWorkspaceState: () => ({ businessProfile: null, profileRevision: "0", profileAudit: [], propagationPreview: null }) };
    vm.runInNewContext(source, context);
    if (cloud) context.window.profileService.configure({ cloud });
    return { service: context.window.profileService, api: context.window.businessProfile };
}

function rawProfile(api, extra = {}) {
    return api.normalizeProfile({ businessName: "Northstar Studio", phone: "+1 555 0100", ...extra });
}

test("loads a normalized profile from local persistence", async () => {
    const { service, api } = load();
    const stored = rawProfile(api);
    const loaded = load({ stored });
    const profile = await loaded.service.getProfile();
    assert.equal(profile.identity.displayName, "Northstar Studio");
});

test("saves revisions and appends an audit event", async () => {
    const { service } = load();
    const first = await service.saveProfile({ businessName: "Northstar Studio", phone: "+1 555 0100" });
    const second = await service.saveProfile({ ...first.profile, identity: { ...first.profile.identity, displayName: "Northstar Creative" } }, { actor: "business-hub" });
    assert.equal(first.revision, "1");
    assert.equal(second.revision, "2");
    assert.equal(second.profile.audit.at(-1).actor, "business-hub");
    assert.equal(second.profile.audit.at(-1).type, "profile.updated");
});

test("rejects profiles without a name or contact", async () => {
    const { service } = load();
    await assert.rejects(() => service.saveProfile({ businessName: "" }), (error) => error.code === "PROFILE_INVALID" && error.issues.length === 2);
});

test("falls back to local persistence when cloud saving fails", async () => {
    const { service } = load({ cloud: { save: async () => { throw new Error("offline"); } } });
    const result = await service.saveProfile({ businessName: "Northstar Studio", phone: "+1 555 0100" });
    assert.equal(result.persisted, "local-fallback");
    assert.equal(service.readLocal().identity.displayName, "Northstar Studio");
});

test("reports affected surfaces for profile changes", () => {
    const { service } = load();
    const preview = service.getPropagationPreview({ offers: { changed: true }, brand: { changed: true } });
    assert.ok(preview.affectedSurfaces.includes("website"));
    assert.ok(preview.affectedSurfaces.includes("ads"));
    assert.ok(preview.affectedSurfaces.includes("follow-up"));
});

test("governance blocks publishing and includes remediation", async () => {
    const { service, api } = load();
    const profile = api.normalizeProfile({ businessName: "Northstar Studio", phone: "+1 555 0100", claims: [{ text: "Guaranteed results", required: true, surfaces: ["ads"] }] });
    const result = await service.recordPublishingAttempt(profile, "ads");
    assert.equal(result.valid, false);
    assert.match(result.blocking[0].remediation, /Approve or update claim/);
    await assert.rejects(() => service.assertPublishable(profile, "ads"), /Publishing blocked/);
});
