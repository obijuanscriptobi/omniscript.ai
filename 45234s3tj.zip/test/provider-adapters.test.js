"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
    deploymentAdapter,
    providerClient,
    safeMessage,
    withRetry
} = require("../netlify/functions/provider-adapters");

function response(status, payload = {}) {
    return { status, ok: status >= 200 && status < 300, text: async () => JSON.stringify(payload) };
}

test("provider adapters inject fetch, attach a request ID, and normalize success", async () => {
    const calls = [];
    const adapter = deploymentAdapter("netlify", { NETLIFY_AUTH_TOKEN: "test-secret", NETLIFY_SITE_ID: "site" }, {
        fetch: async (url, options) => {
            calls.push({ url, options });
            return response(200, { id: "deploy-1", state: "ready" });
        },
        retries: 0,
        requestId: "fixture-request"
    });
    const result = await adapter.status("deploy-1");
    assert.equal(result.data.id, "deploy-1");
    assert.equal(result.requestId, "fixture-request");
    assert.equal(calls.length, 1);
    assert.equal(calls[0].options.headers["X-Request-ID"], "fixture-request");
});

test("provider adapters classify provider failures without exposing credentials", async () => {
    const adapter = providerClient("webhook", {
        endpoint: "https://hooks.example.test",
        fetch: async () => response(503, { message: "token=super-secret" }),
        retries: 0,
        requestId: "failure-request"
    });
    await assert.rejects(
        () => adapter.request("/leads"),
        (error) => {
            assert.equal(error.name, "ProviderError");
            assert.equal(error.status, 503);
            assert.equal(error.retryable, true);
            assert.equal(error.requestId, "failure-request");
            assert.doesNotMatch(error.message, /super-secret/);
            return true;
        }
    );
});

test("provider retry policy is bounded and retries only retryable errors", async () => {
    let attempts = 0;
    const result = await withRetry(async () => {
        attempts += 1;
        if (attempts < 3) throw Object.assign(new Error("temporary"), { retryable: true });
        return "ok";
    }, { retries: 2 });
    assert.equal(result, "ok");
    assert.equal(attempts, 3);

    attempts = 0;
    await assert.rejects(() => withRetry(async () => {
        attempts += 1;
        throw Object.assign(new Error("permanent"), { retryable: false });
    }, { retries: 5 }));
    assert.equal(attempts, 1);
});

test("timeouts become safe retryable provider errors", async () => {
    const adapter = providerClient("redis", {
        endpoint: "https://redis.example.test",
        timeoutMs: 5,
        retries: 0,
        fetch: (_url, options) => new Promise((resolve, reject) => {
            options.signal.addEventListener("abort", () => reject(Object.assign(new Error("aborted"), { name: "AbortError" })));
        })
    });
    await assert.rejects(() => adapter.request("/pipeline"), (error) => {
        assert.equal(error.name, "ProviderError");
        assert.equal(error.status, 504);
        assert.equal(error.retryable, true);
        return true;
    });
});

test("safe provider messages redact secret-like values", () => {
    assert.doesNotMatch(safeMessage(new Error("Authorization: Bearer top-secret-token")), /top-secret-token/);
    assert.doesNotMatch(safeMessage(new Error("api_key=hidden-value")), /hidden-value/);
});

test("malformed JSON responses become safe provider failures", async () => {
    const client = providerClient("supabase", {
        endpoint: "https://db.example.test",
        retries: 0,
        requestId: "malformed-request",
        fetch: async () => ({ status: 200, ok: true, text: async () => "<html>gateway error</html>" })
    });
    await assert.rejects(() => client.request("/rest/v1/projects"), (error) => {
        assert.equal(error.name, "ProviderError");
        assert.equal(error.requestId, "malformed-request");
        assert.doesNotMatch(error.message, /gateway error|html/i);
        return true;
    });
});

test("raw provider responses remain injectable and carry request IDs", async () => {
    let captured;
    const client = providerClient("scrapingbee", {
        endpoint: "https://app.scrapingbee.com",
        retries: 0,
        requestId: "raw-request",
        fetch: async (url, options) => {
            captured = { url, options };
            return response(200, { html: "<html></html>" });
        }
    });
    const result = await client.request("/api/v1/?url=https%3A%2F%2Fexample.test", { raw: true });
    assert.equal(result.status, 200);
    assert.equal(result.requestId, "raw-request");
    assert.equal(captured.options.headers["X-Request-ID"], "raw-request");
});
