"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("form delivery has bounded retries and idempotency keys", () => {
    const source = read("netlify_functions_submit_form.js");
    assert.match(source, /const MAX_RETRIES = 2/);
    assert.match(source, /Idempotency-Key/);
    assert.match(source, /reserveSubmission/);
    assert.match(source, /releaseSubmission/);
});

test("provider failures expose safe retry semantics without raw upstream details", () => {
    const source = read("netlify/functions/provider-adapters.js");
    assert.match(source, /retryable/);
    assert.match(source, /ProviderError/);
    assert.match(source, /REDACTED/);
    assert.match(source, /timeout/);
});

test("operational logs redact credentials and bound nested payloads", () => {
    const source = read("netlify/functions/_ops.js");
    assert.match(source, /SECRET_FIELD/);
    assert.match(source, /\[REDACTED\]/);
    assert.match(source, /depth > 4/);
});
