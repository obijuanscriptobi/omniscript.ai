"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const { response } = require("../netlify/functions/_platform.js");

const serverFiles = fs.readdirSync(path.join(root, "netlify/functions"))
    .filter((file) => file.endsWith(".js") && !["provider-adapters.js", "_security.js"].includes(file));
const rootProviderFiles = ["netlify_functions_search.js", "netlify_functions_scrape.js", "netlify_functions_submit_form.js"];

test("external server handlers use the provider adapter for upstream calls", () => {
    const exceptions = new Set(["csp-report.js", "config.js", "test-form-endpoint.js"]);
    for (const file of serverFiles) {
        const source = read(`netlify/functions/${file}`);
        if (/\bfetch\s*\(/.test(source) && !exceptions.has(file)) {
            assert.match(source, /providerClient|deploymentAdapter/, `${file} contains a direct upstream fetch`);
        }
    }
    for (const file of rootProviderFiles) {
        const source = read(file);
        if (/\bfetch\s*\(/.test(source)) assert.match(source, /providerClient/, `${file} contains a direct upstream fetch`);
    }
});

test("provider-facing handlers contain safe error and correlation contracts", () => {
    for (const file of ["deploy.js", "search.js", "scrape.js", "submit-form.js", "platform.js", "projects.js", "project-files.js", "analytics.js", "send-preview.js", "retry-leads.js"]) {
        const source = read(`netlify/functions/${file}`);
        assert.match(source, /securityHeaders|withSecurityHeaders|headers/, `${file} must define response headers`);
        assert.match(source, /requestId/, `${file} must support request correlation`);
        assert.doesNotMatch(source, /error:\s*error\.message/, `${file} must not expose raw upstream errors`);
    }
});

test("shared platform responses are JSON, hardened, and correlation-ready", () => {
    const result = response(409, { success: false, error: "safe" }, {}, { headers: { "x-request-id": "platform-fixture" } });
    assert.equal(result.statusCode, 409);
    assert.equal(result.isBase64Encoded, false);
    assert.equal(result.headers["X-Request-ID"], "platform-fixture");
    assert.match(result.headers["Content-Type"], /application\/json/i);
    assert.equal(JSON.parse(result.body).requestId, "platform-fixture");
});

test("server-side Supabase and storage paths do not bypass provider adapters", () => {
    for (const file of ["projects.js", "project-files.js"]) {
        const source = read(`netlify/functions/${file}`);
        assert.doesNotMatch(source, /\bfetch\s*\(/, `${file} must not make direct upstream requests`);
        assert.match(source, /providerClient/, `${file} must use the provider adapter`);
    }
});

test("project files require byte verification before private download", () => {
    const source = read("netlify/functions/project-files.js");
    assert.match(source, /action === "finalize"/);
    assert.match(source, /arrayBuffer\(\)/);
    assert.match(source, /detectedType\(bytes/);
    assert.match(source, /verification_status=eq\.verified/);
    assert.match(source, /sha256/);
    assert.match(source, /assetRightsConfirmed !== true/);
});

test("client bundles do not contain server-only credential names", () => {
    for (const file of ["script.js", "supabase-client.js", "workspace-core.js", "app-loader.js"]) {
        const source = read(file);
        assert.doesNotMatch(source, /SUPABASE_SERVICE_ROLE_KEY|NETLIFY_AUTH_TOKEN|PREFLIGHT_SIGNING_SECRET|UPSTASH_REDIS_REST_TOKEN|SCRAPINGBEE_API_KEY/);
    }
});
