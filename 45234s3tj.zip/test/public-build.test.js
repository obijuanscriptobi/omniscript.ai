"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { inspectPublicBuild } = require("../public-release-audit.js");

const root = path.join(__dirname, "..");
const output = path.join(root, "public");

function build() {
    const result = spawnSync(process.execPath, [path.join(root, "build-public.js")], { cwd: root, encoding: "utf8" });
    assert.equal(result.status, 0, result.stderr || result.stdout);
}

test("public build contains runtime entries and excludes repository internals", () => {
    build();
    ["home.html", "index.html", "404.html", "robots.txt", "site.webmanifest"].forEach((file) => {
        assert.equal(fs.existsSync(path.join(output, file)), true, `${file} must be public`);
    });
    assert.equal(fs.existsSync(path.join(root, "manifest.json")), false, "site.webmanifest must be the only web-app manifest");
    ["package.json", "package-lock.json", "netlify.toml", "manifest.json", "readiness.html", "release-readiness.js", "test", "docs", "supabase", ".github"].forEach((file) => {
        assert.equal(fs.existsSync(path.join(output, file)), false, `${file} must not be public`);
    });
});

test("public output passes reference, exposure, secret, and CSP checks", () => {
    build();
    const report = inspectPublicBuild(output);
    assert.equal(report.ok, true, JSON.stringify(report.findings, null, 2));
    assert.ok(report.inventory.files > 0);
    assert.ok(report.inventory.references > 0);
});

test("public audit rejects exposed internals, secrets, missing assets, and unsafe HTML", () => {
    const fixture = path.join(root, ".public-audit-fixture");
    fs.rmSync(fixture, { recursive: true, force: true });
    fs.mkdirSync(path.join(fixture, "test"), { recursive: true });
    fs.writeFileSync(path.join(fixture, "index.html"), `<script>alert(1)</script><img src="missing.png"><iframe src="about:blank"></iframe><a target="_blank" href="/">open</a>`);
    fs.writeFileSync(path.join(fixture, "secrets.js"), `const token = "eyJ${"a".repeat(24)}.eyJ${"b".repeat(24)}.${"c".repeat(24)}";`);
    fs.writeFileSync(path.join(fixture, "test", "internal.js"), "internal");
    try {
        const report = inspectPublicBuild(fixture);
        const codes = new Set(report.findings.map((finding) => finding.code));
        ["FORBIDDEN_PUBLIC_FILE", "PUBLIC_JWT", "MISSING_PUBLIC_REFERENCE", "CSP_INLINE_SCRIPT", "UNSANDBOXED_FRAME", "BLANK_LINK_OPENER"].forEach((code) => assert.ok(codes.has(code), `${code} must be detected`));
    } finally {
        fs.rmSync(fixture, { recursive: true, force: true });
    }
});

test("indexable public pages declare basic browser metadata", () => {
    ["home.html", "privacy.html", "terms.html", "acceptable-use.html"].forEach((file) => {
        const html = fs.readFileSync(path.join(root, file), "utf8");
        assert.match(html, /<meta name="theme-color" content="#080b12">/, `${file} must set the browser theme color`);
        assert.match(html, /<meta name="robots" content="index, follow">/, `${file} must explicitly declare public indexing`);
        assert.match(html, /<link rel="icon" href="favicon\.svg" type="image\/svg\+xml">/, `${file} must expose the shared favicon`);
    });
});

test("hosting publishes the generated boundary and routes fail safely", () => {
    const config = fs.readFileSync(path.join(root, "netlify.toml"), "utf8");
    assert.match(config, /command = "node build-public\.js"/);
    assert.match(config, /publish = "public"/);
    assert.match(config, /from = "\/"[\s\S]*?to = "\/home\.html"/);
    assert.match(config, /from = "\/api\/\*"[\s\S]*?status = 404/);
    assert.doesNotMatch(config, /from = "\/\*"[\s\S]*?status = 200/);
    assert.equal(fs.existsSync(path.join(root, "404.html")), true);
});

test("sensitive HTML routes have no-store and noindex hosting policy", () => {
    const config = fs.readFileSync(path.join(root, "netlify.toml"), "utf8");
    ["index", "account", "approval", "invitation", "preview", "portal", "proposal"].forEach((page) => {
        const block = config.match(new RegExp(`\\[\\[headers\\]\\]\\s+for = \"/${page}\\.html\"([\\s\\S]*?)(?=\\n\\[\\[headers\\]\\]|$)`))?.[1] || "";
        assert.match(block, /Cache-Control = "no-store, max-age=0"/, `${page}.html must not be cached`);
        assert.match(block, /X-Robots-Tag = "noindex, nofollow, noarchive"/, `${page}.html must not be indexed`);
    });
});

test.after(() => fs.rmSync(output, { recursive: true, force: true }));
