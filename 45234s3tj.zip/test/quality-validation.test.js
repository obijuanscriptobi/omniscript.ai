"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { validateFiles } = require("../workspace-quality.js");
const { resolveLocalReference, auditProject } = require("../workspace-audit.js");

test("file validation still inspects a late index file beyond the file limit", () => {
    const files = Object.fromEntries(Array.from({ length: 40 }, (_, index) => [`extra-${index}.txt`, "ok"]));
    files["index.html"] = "<!doctype html><html><head><title>Site</title></head><body><h1>Site</h1></body></html>";
    const result = validateFiles(files);
    assert.ok(result.issues.some((entry) => entry.code === "TOO_MANY_FILES"));
    assert.ok(Object.hasOwn(result.files, "index.html"));
});

test("shared audit resolves parent paths and CSS url references", () => {
    assert.equal(resolveLocalReference("pages/contact.html", "../style.css"), "style.css");
    const report = auditProject({ "index.html": '<!doctype html><html><head><title>Site</title></head><body><h1>Site</h1><img src="missing.svg"></body></html>', "style.css": '.hero{background:url(unknown.webp)}' });
    assert.equal(report.blocking.filter((item) => item.code === "MISSING_LOCAL_REFERENCE").length, 2);
});

test("file validation resolves parent links and srcset references", () => {
    const files = {
        "index.html": "<!doctype html><html lang=\"en\"><head><meta name=\"viewport\"><title>Site</title></head><body><h1>Site</h1><img src=\"./assets/hero.webp\" srcset=\"./assets/missing.webp 2x\"></body></html>"
    };
    const result = validateFiles(files);
    assert.ok(result.files["index.html"]);
});
