"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { qualityReport, validateFiles } = require("../workspace-quality.js");

test("quality reports missing accessibility essentials", () => {
    const report = qualityReport({
        "index.html": "<!doctype html><html><head></head><body><img src='hero.jpg'></body></html>"
    });
    assert.ok(report.blocking.some((entry) => entry.code === "MISSING_TITLE"));
    assert.ok(report.blocking.some((entry) => entry.code === "IMAGE_MISSING_ALT"));
});

test("quality accepts a complete basic project", () => {
    const report = qualityReport({
        "index.html": "<!doctype html><html><head><title>Example</title></head><body><h1>Welcome</h1><img alt='Example' src='hero.jpg'></body></html>",
        "style.css": "body { margin: 0; }",
        "script.js": "document.body.dataset.ready = 'true';"
    });
    assert.equal(report.summary.passed, true);
    assert.equal(report.blocking.length, 0);
});

test("file validation rejects unsafe paths and oversized content", () => {
    const result = validateFiles({ "../secrets.txt": "x", "index.html": "x".repeat(1_000_001) });
    assert.ok(result.issues.some((entry) => entry.code === "INVALID_FILENAME"));
    assert.ok(result.issues.some((entry) => entry.code === "FILE_TOO_LARGE"));
});

test("file validation accepts generated release metadata", () => {
    const result = validateFiles({
        "index.html": "<!doctype html><html><head><title>Example</title></head><body><h1>Example</h1></body></html>",
        "style.css": "body { margin: 0; }",
        "sitemap.xml": "<?xml version=\"1.0\"?><urlset></urlset>",
        "robots.txt": "User-agent: *\\nAllow: /"
    });
    assert.equal(result.issues.some((entry) => entry.code === "INVALID_FILENAME"), false);
});
