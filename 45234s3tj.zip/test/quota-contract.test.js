"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
test("quota migration is atomic, scoped, period-aware, and reversible", () => {
    const sql = read("supabase/usage-limits.sql");
    const quota = read("netlify/functions/_quota.js");
    assert.match(sql, /on conflict.*do update/i); assert.match(sql, /date_trunc\('month'/i); assert.match(sql, /p_project_id/); assert.match(sql, /auth\.uid\(\)/);
    assert.match(sql, /release_usage_quota/);
    assert.match(quota, /reserveQuota/);
    assert.match(quota, /releaseQuota/);
    assert.match(quota, /resetsAt/);
});

test("persistent idempotency is backed by authenticated database operations", () => {
    const sql = read("supabase/reliability.sql");
    const helper = read("netlify/functions/_idempotency.js");
    assert.match(sql, /idempotent_operations/);
    assert.match(sql, /begin_idempotent_operation/);
    assert.match(sql, /complete_idempotent_operation/);
    assert.match(sql, /auth\.uid\(\)/);
    assert.match(helper, /IDEMPOTENCY_CONFLICT/);
    assert.match(helper, /IDEMPOTENCY_IN_PROGRESS/);
});
test("release service is the single validation pipeline entry point", () => {
    const source = read("workspace-release-service.js");
    assert.match(source, /generateOrImport/); assert.match(source, /validateOutput/); assert.match(source, /auditProject/); assert.match(source, /revision/);
});
test("operational audit and deletion primitives exist", () => {
    assert.match(read("supabase/operations.sql"), /platform_audit_events/); assert.match(read("supabase/operations.sql"), /delete_my_account/); assert.match(read("netlify/functions/account-delete.js"), /authenticate/);
});
