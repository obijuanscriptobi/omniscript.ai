import { test, expect } from "@playwright/test";

async function completeBrief(page) {
    await page.locator("#input-biz-name").fill("Northstar Studio");
    await page.locator("#input-biz-hook").fill("Clearer websites for local service businesses");
    await page.locator("#input-biz-location").fill("Austin, TX");
    await page.locator("#input-biz-audience").fill("Local business owners");
    await page.locator("#input-biz-services").fill("Website strategy, Website design");
    await page.locator("#input-primary-goal").selectOption("quote");
    await page.locator("#input-primary-cta").fill("Request a quote");
}

test.describe("reliable draft review", () => {
    test.beforeEach(async ({ page }) => {
        await page.goto("/index.html", { waitUntil: "domcontentloaded" });
        await page.evaluate(() => localStorage.clear());
        await page.reload({ waitUntil: "domcontentloaded" });
    });

    test("supports an isolated improvement proposal and semantic review", async ({ page }) => {
        await completeBrief(page);
        await page.locator('[data-workflow-action="apply-defaults"]').click();
        await page.locator("#compile-pipeline-btn").click();
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);

        const before = await page.evaluate(() => window.workspaceAPI.getState().files["index.html"]);
        await page.locator('[data-improvement="clearer"]').click();
        await expect(page.locator("#workflow-diff-panel")).toBeVisible();

        const review = await page.evaluate(() => ({
            live: window.workspaceAPI.getState().files["index.html"],
            pending: window.workflowStudio?.getPendingChange?.()
        }));
        expect(review.live).toBe(before);
        expect(review.pending?.semantic?.length).toBeGreaterThan(0);
        expect(review.pending.semantic.some((item) => item.kind === "content-only")).toBe(true);

        await page.locator("[data-diff-keep]").click();
        await expect.poll(async () => page.evaluate(() => window.workspaceAPI.getState().files["index.html"])).toBe(before);
        await expect(page.locator("#workflow-diff-panel")).toBeHidden();
    });

    test("accepts and restores a proposed change without losing persistence", async ({ page }) => {
        await completeBrief(page);
        await page.locator("#compile-pipeline-btn").click();
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);
        const before = await page.evaluate(() => window.workspaceAPI.getState().files["index.html"]);

        await page.locator('[data-improvement="premium"]').click();
        await page.locator("[data-diff-accept]").click();
        const accepted = await page.evaluate(() => window.workspaceAPI.getState().files["style.css"]);
        expect(accepted).not.toBe("");
        expect(accepted).toContain("workflow-corner");

        await page.locator('[data-improvement="clearer"]').click();
        await page.locator("[data-diff-restore]").click();
        await expect.poll(async () => page.evaluate(() => window.workspaceAPI.getState().files["index.html"])).toBe(before);

        await page.reload({ waitUntil: "domcontentloaded" });
        await expect(page.locator("#input-biz-name")).toHaveValue("Northstar Studio");
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);
    });

    test("expires a proposal when the underlying draft changes", async ({ page }) => {
        await completeBrief(page);
        await page.locator("#compile-pipeline-btn").click();
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);
        const before = await page.evaluate(() => window.workspaceAPI.getState().files["index.html"]);

        await page.locator('[data-improvement="clearer"]').click();
        await page.locator("#input-biz-name").fill("Northstar Studio Updated");
        await page.locator("[data-diff-accept]").click();

        await expect(page.locator("#workflow-diff-panel")).toBeHidden();
        await expect.poll(async () => page.evaluate(() => window.workspaceAPI.getState().files["index.html"])).toBe(before);
        await expect(page.locator("#workflow-studio-toast")).toContainText("expired");
    });

    test("records revision identities in improvement evidence", async ({ page }) => {
        await completeBrief(page);
        await page.locator("#compile-pipeline-btn").click();
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);
        await page.locator('[data-improvement="premium"]').click();
        await page.locator("[data-diff-accept]").click();

        const entry = await page.evaluate(() => JSON.parse(localStorage.getItem("workflow-studio-audit") || "[]").at(-1));
        expect(entry.status).toBe("accepted");
        expect(entry.beforeRevision).toBeTruthy();
        expect(entry.afterRevision).toBeTruthy();
        expect(entry.beforeRevision).not.toBe(entry.afterRevision);
    });

    test("rejects unsafe snapshots without partially replacing the live project", async ({ page }) => {
        await completeBrief(page);
        await page.locator("#compile-pipeline-btn").click();
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);
        const result = await page.evaluate(() => {
            const before = window.workspaceAPI.getState().files["index.html"];
            let rejected = false;
            try {
                window.workspaceAPI.applySnapshot({ files: { "index.html": "<script>alert(1)</script>" } }, { dirty: true });
            } catch {
                rejected = true;
            }
            return { rejected, unchanged: window.workspaceAPI.getState().files["index.html"] === before };
        });
        expect(result.rejected).toBe(true);
        expect(result.unchanged).toBe(true);
    });

    test("exposes one blocked publish decision when release evidence is incomplete", async ({ page }) => {
        await completeBrief(page);
        await page.locator("#compile-pipeline-btn").click();
        await expect.poll(async () => page.evaluate(() => Boolean(window.workspaceAPI?.getState?.()?.files?.["index.html"]?.includes("<h1")))).toBe(true);
        const decision = await page.evaluate(() => window.workflowStudio?.getPublishDecision?.());
        expect(decision).toBeTruthy();
        expect(decision.blocked).toBe(true);
        expect(Array.isArray(decision.findings)).toBe(true);
        expect(decision.findings.some((item) => item.severity && item.source && item.affected && item.remediation && item.fixType && item.evidenceState && item.revisionState)).toBe(true);
    });
});
