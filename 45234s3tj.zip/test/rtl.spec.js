const { test, expect } = require("@playwright/test");

test("generated preview supports RTL without horizontal overflow", async ({ page }) => {
    await page.goto("/");
    await page.locator("#input-biz-name").fill("Atlas Studio");
    await page.locator("#input-biz-hook").fill("Clearer planning for growing teams");
    await page.locator("#input-biz-location").fill("Dubai");
    await page.locator("#input-biz-services").fill("Planning");
    await page.locator("#input-biz-audience").fill("Growing teams");
    await page.locator("#input-locale").selectOption("ar");
    await page.locator("#input-direction").selectOption("rtl");
    await page.locator("#compile-pipeline-btn").click();
    const frame = page.frameLocator("#previewContentIframe");
    await expect(frame.locator("html")).toHaveAttribute("dir", "rtl");
    const overflow = await page.locator("#previewContentIframe").evaluate((iframe) => iframe.contentDocument.documentElement.scrollWidth > iframe.clientWidth + 2);
    expect(overflow).toBe(false);
});
