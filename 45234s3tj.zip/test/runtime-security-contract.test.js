"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("approval and revision mutations are scoped, concurrent, idempotent, and audited", () => {
    const approval = read("netlify/functions/approval.js");
    const revisions = read("netlify/functions/revisions.js");
    for (const marker of ["beginPublicApprovalDecision", "updated_at=eq.", "status=eq.pending", "return=representation", "beforeStatus", "afterStatus"]) assert.match(approval, new RegExp(marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    for (const marker of ["workContextId", "updated_at=eq.", "return=representation", "revision.update", "revision.delete", "before:", "after:"]) assert.ok(revisions.includes(marker), `revisions missing ${marker}`);
});

test("public token clients remove credentials and do not persist remote tokens", () => {
    for (const file of ["approval.js", "invitation.js", "portal.js", "preview.html", "proposal.js"]) assert.ok(read(file).includes("history.replaceState"), `${file} leaves token in URL`);
    const preview = read("preview.html");
    assert.doesNotMatch(preview, /localStorage\.setItem\([^\n]*(?:approvalToken|DECISION_PREFIX)/);
    assert.match(preview, /Idempotency-Key/);
    assert.match(read("approval.js"), /updatedAt/);
});

test("portal establishes a cookie session and atomically caps comments", () => {
    const handler = read("netlify/functions/client-portal.js");
    const client = read("portal.js");
    const migration = read("supabase/client-portal.sql");
    assert.match(handler, /portalToken\(event\)/);
    assert.match(handler, /Set-Cookie/);
    assert.match(handler, /clearPortalCookie/);
    assert.match(handler, /create_client_portal_comment/);
    assert.match(client, /credentials: "same-origin"/);
    assert.match(client, /token = ""/);
    assert.doesNotMatch(client, /localStorage|sessionStorage/);
    assert.match(migration, /for update/);
    assert.match(migration, /PORTAL_COMMENT_LIMIT/);
    assert.match(migration, /grant execute on function public\.create_client_portal_comment[\s\S]*service_role/);
});

test("file finalization is bounded, byte-verified, idempotent, and fail closed", () => {
    const files = read("netlify/functions/project-files.js");
    for (const marker of ["MAX_FILES_PER_PROJECT", "lastIndexOf", "detectedType", "sha256", "verification_status=eq.verified", "beginPublicTokenOperation", "beginIdempotent", "quarantined"]) assert.ok(files.includes(marker), `file lifecycle missing ${marker}`);
    assert.match(read("portal.js"), /action: "finalize"/);
});

test("proposal and handoff API is authenticated, idempotent, and database mediated", () => {
    const handler = read("netlify/functions/handoffs.js");
    for (const marker of ["authenticate(event)", "userRequest", "beginIdempotent", "completeIdempotent", "create_project_proposal", "create_project_handoff", "HANDOFF_WRITE_CONFLICT"]) assert.ok(handler.includes(marker), `handoff API missing ${marker}`);
    assert.match(read("netlify.toml"), /from = "\/api\/handoffs"/);
});

test("release gate contains security and explicit runtime evidence gates", () => {
    const gate = read("codewise-release-gate.js");
    for (const marker of ["DATABASE_INTEGRITY_GAP", "IDEMPOTENCY_GAP", "FILE_SECURITY_GAP", "TOKEN_URL_LEAK_GAP", "CODEWISE_ENFORCE_RUNTIME_RELEASE", "CODEWISE_RELEASE_RUNTIME_VERIFIED"]) assert.ok(gate.includes(marker), `release gate missing ${marker}`);
});
