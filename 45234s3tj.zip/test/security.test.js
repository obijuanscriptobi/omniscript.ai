"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
    getClientKey,
    maxBodyResponse,
    requestId,
    jsonResponse,
    securityHeaders
} = require("../netlify/functions/_security");

test("client identity prefers the platform request context", () => {
    const event = {
        requestContext: { identity: { sourceIp: "203.0.113.10" } },
        headers: { "x-forwarded-for": "198.51.100.20" }
    };
    assert.equal(getClientKey(event), "203.0.113.10");
});

test("client identity normalizes IPv4-mapped IPv6 addresses", () => {
    assert.equal(
        getClientKey({ headers: { "client-ip": "::ffff:192.0.2.8" } }),
        "192.0.2.8"
    );
});

test("security headers cannot be overridden", () => {
    const headers = securityHeaders({
        "X-Frame-Options": "ALLOWALL",
        "X-Test-Header": "present"
    });
    assert.equal(headers["X-Frame-Options"], "DENY");
    assert.equal(headers["X-Test-Header"], "present");
});

test("security responses include a request correlation identifier", () => {
    const result = maxBodyResponse({ body: "1234567890" }, 5);
    const payload = JSON.parse(result.body);
    assert.match(result.headers["X-Request-ID"], /^req-/);
    assert.equal(payload.requestId, result.headers["X-Request-ID"]);
});

test("body limits reject oversized payloads", () => {
    const result = maxBodyResponse({ body: "1234567890" }, 5);
    assert.equal(result.statusCode, 413);
    assert.equal(JSON.parse(result.body).success, false);
});

test("one event reuses one cryptographically strong request ID", () => {
    const event = { headers: {} };
    const first = requestId(event);
    assert.equal(requestId(event), first);
    assert.match(first, /^req-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
});

test("one request ID is shared by logs, headers, and response bodies", () => {
    const event = { httpMethod: "POST", path: "/api/test", headers: {} };
    const messages = [];
    const original = console.info;
    console.info = (message) => messages.push(JSON.parse(message));
    try {
        const result = jsonResponse(400, { success: false }, {}, event);
        const payload = JSON.parse(result.body);
        assert.equal(payload.requestId, result.headers["X-Request-ID"]);
        assert.equal(messages[0].requestId, payload.requestId);
    } finally {
        console.info = original;
    }
});

test("invalid deployment requests are rejected before distributed limiting or quota", async () => {
    const { handler } = require("../netlify/functions/deploy");
    const previousUrl = process.env.UPSTASH_REDIS_REST_URL;
    const previousToken = process.env.UPSTASH_REDIS_REST_TOKEN;
    process.env.UPSTASH_REDIS_REST_URL = "https://rate-limit.invalid";
    process.env.UPSTASH_REDIS_REST_TOKEN = "must-not-be-used";
    let calls = 0;
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async () => {
        calls += 1;
        throw new Error("Invalid input reached an external service");
    };
    try {
        const result = await handler({ httpMethod: "POST", headers: { authorization: "Bearer token", "content-type": "application/json" }, body: "not-json" });
        assert.equal(result.statusCode, 400);
        assert.equal(JSON.parse(result.body).success, false);
        assert.equal(calls, 0);
    } finally {
        globalThis.fetch = originalFetch;
        if (previousUrl === undefined) delete process.env.UPSTASH_REDIS_REST_URL; else process.env.UPSTASH_REDIS_REST_URL = previousUrl;
        if (previousToken === undefined) delete process.env.UPSTASH_REDIS_REST_TOKEN; else process.env.UPSTASH_REDIS_REST_TOKEN = previousToken;
    }
});
