"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "setup-wizard.js"), "utf8");

function wizardApi() {
    const context = {
        window: {},
        document: { readyState: "loading", addEventListener: () => {}, getElementById: () => null },
        CustomEvent: function CustomEvent(type, init) { this.type = type; this.detail = init?.detail; },
        Date, Math
    };
    vm.runInNewContext(source, context);
    return context.window.setupWizard;
}

test("setup plan turns business details into connected launch records", () => {
    const wizard = wizardApi();
    const plan = wizard.createPlan({
        businessName: "Northstar Studio",
        businessType: "creative-agency",
        services: "Brand strategy, Web design",
        location: "Austin, TX",
        phone: "+1 555 0100",
        email: "hello@example.com",
        primaryGoal: "booking",
        booking: "https://example.com/book",
        pos: "Square"
    });

    assert.equal(plan.model, "SetupPlan");
    assert.equal(plan.business.businessName, "Northstar Studio");
    assert.deepEqual(plan.business.services, ["Brand strategy", "Web design"]);
    assert.ok(plan.project.pages.includes("booking.html"));
    assert.equal(plan.forms[0].purpose, "booking");
    assert.ok(plan.analytics.events.includes("lead_submitted"));
    assert.equal(plan.launchChecklist.length, 8);
    assert.equal(plan.launchChecklist.every((item) => item.status === "pending"), true);
    assert.equal(plan.providers.pos, "Square");
    assert.ok(plan.nextActions.length > 0);
});

test("setup plan safely defaults unknown goals and supports checklist progress", () => {
    const wizard = wizardApi();
    const plan = wizard.createPlan({ businessName: "Example", primaryGoal: "unknown" }, {
        checklist: { "content-review": "complete", publish: "blocked" }
    });
    assert.equal(plan.business.goal, "quote");
    assert.equal(plan.launchChecklist.find((item) => item.key === "content-review").status, "complete");
    assert.equal(plan.launchChecklist.find((item) => item.key === "publish").status, "blocked");
    assert.ok(plan.project.pages.includes("contact.html"));
});
