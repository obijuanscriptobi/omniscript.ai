"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { run } = require("../staging-fixture.js");

test("staging fixture verifies the complete requested sequence", async () => {
    const calls = [];
    const api = {
        createLead: async () => { calls.push("lead"); return { success: true, id: "lead-1" }; },
        createAudit: async () => { calls.push("audit"); return { success: true, id: "audit-1" }; },
        openGenerator: async () => { calls.push("generator"); return { success: true, auditId: "audit-1" }; },
        createDraftRevision: async () => { calls.push("draft"); return { success: true, id: "revision-1", revisionId: "revision-1" }; },
        approveChange: async () => { calls.push("approve"); return { success: true }; },
        rejectChange: async () => { calls.push("reject"); return { success: true, rejected: true }; },
        applyApprovedChanges: async ({ expectConflict }) => {
            calls.push(expectConflict ? "conflict" : "apply");
            return expectConflict ? { conflict: true, status: 409 } : { success: true, revisionId: "revision-1", validation: { status: "passed" } };
        },
        runVisualWorkflow: async () => {
            calls.push("visual");
            return { status: "complete", baseline: {}, proposed: {}, comparison: {} };
        },
        persistVisualReport: async () => {
            calls.push("persist-visual");
            return { websiteAudit: { visual: {} }, siteRevision: { beforeScores: {}, afterScores: {}, screenshots: {} } };
        },
        deploy: async () => { calls.push("deploy"); return { success: true, id: "provider-deploy-1", deploymentId: "provider-deploy-1" }; },
        verifyDeploymentLink: async () => {
            calls.push("link");
            return { deploymentId: "provider-deploy-1", revisionStatus: "deployed", environment: { publicUrl: "https://staging.example", currentRevision: "revision-1" } };
        },
        trackConversion: async () => { calls.push("conversion"); return { success: true, id: "event-1" }; },
        experimentReport: async () => { calls.push("report"); return { status: "insufficient-data", winner: null }; }
    };

    const result = await run({ api, projectId: "project-1", experimentId: "experiment-1", websiteUrl: "https://staging.example" });
    assert.equal(result.success, true);
    assert.equal(result.evidence.experimentStatus, "insufficient-data");
    assert.deepEqual(calls, [
        "lead", "audit", "generator", "draft", "approve", "reject", "apply", "conflict",
        "visual", "persist-visual", "deploy", "link", "conversion", "report"
    ]);
});

test("staging fixture refuses an experiment winner with insufficient data", async () => {
    const api = {
        createLead: async () => ({ id: "lead" }),
        createAudit: async () => ({ id: "audit" }),
        openGenerator: async () => ({ auditId: "audit" }),
        createDraftRevision: async () => ({ id: "revision" }),
        approveChange: async () => ({}),
        rejectChange: async () => ({}),
        applyApprovedChanges: async ({ expectConflict }) => expectConflict ? { conflict: true } : { validation: {} },
        runVisualWorkflow: async () => ({ status: "complete", baseline: {}, proposed: {}, comparison: {} }),
        persistVisualReport: async () => ({ websiteAudit: { visual: {} }, siteRevision: { beforeScores: {}, afterScores: {}, screenshots: {} } }),
        deploy: async () => ({ id: "deployment" }),
        verifyDeploymentLink: async () => ({ deploymentId: "deployment", revisionStatus: "deployed", environment: { publicUrl: "https://staging.example", currentRevision: "revision" } }),
        trackConversion: async () => ({}),
        experimentReport: async () => ({ status: "winner", winner: "variant-a" })
    };
    await assert.rejects(() => run({ api, projectId: "project" }), /STAGING_FIXTURE_FAILED:experiment-report/);
});
