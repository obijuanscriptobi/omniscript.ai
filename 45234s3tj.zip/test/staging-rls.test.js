"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");

const enabled = process.env.CODEWISE_STAGING_RLS === "true";
const required = [
    "SUPABASE_URL",
    "SUPABASE_ANON_KEY",
    "CODEWISE_STAGING_RLS_USER_A_TOKEN",
    "CODEWISE_STAGING_RLS_USER_A_ID",
    "CODEWISE_STAGING_RLS_USER_B_TOKEN",
    "CODEWISE_STAGING_RLS_USER_B_ID",
    "CODEWISE_STAGING_RLS_PROJECT_A_ID",
    "CODEWISE_STAGING_RLS_PROJECT_B_ID",
    "CODEWISE_STAGING_RLS_CONTEXT_A_ID",
    "CODEWISE_STAGING_RLS_CONTEXT_B_ID",
    "CODEWISE_STAGING_RLS_REVOKED_PROJECT_ID",
    "CODEWISE_STAGING_RLS_ARCHIVED_PROJECT_ID"
];
const ids = {
    userA: process.env.CODEWISE_STAGING_RLS_USER_A_ID || "",
    userB: process.env.CODEWISE_STAGING_RLS_USER_B_ID || "",
    projectA: process.env.CODEWISE_STAGING_RLS_PROJECT_A_ID || "",
    projectB: process.env.CODEWISE_STAGING_RLS_PROJECT_B_ID || "",
    contextA: process.env.CODEWISE_STAGING_RLS_CONTEXT_A_ID || "",
    contextB: process.env.CODEWISE_STAGING_RLS_CONTEXT_B_ID || "",
    revokedProject: process.env.CODEWISE_STAGING_RLS_REVOKED_PROJECT_ID || "",
    archivedProject: process.env.CODEWISE_STAGING_RLS_ARCHIVED_PROJECT_ID || ""
};
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function configured() {
    const missing = required.filter((name) => !String(process.env[name] || "").trim());
    assert.deepEqual(missing, [], `CODEWISE_STAGING_RLS=true but variables are missing: ${missing.join(", ")}`);
    assert.match(process.env.SUPABASE_URL, /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i);
    for (const [name, value] of Object.entries(ids)) assert.match(value, uuidPattern, `${name} must be a UUID`);
    assert.notEqual(ids.userA, ids.userB);
    assert.notEqual(ids.projectA, ids.projectB);
}

async function rest(token, path, options = {}) {
    const response = await fetch(`${process.env.SUPABASE_URL.replace(/\/$/, "")}/rest/v1/${path}`, {
        ...options,
        headers: {
            apikey: process.env.SUPABASE_ANON_KEY,
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            Prefer: "return=representation",
            ...(options.headers || {})
        }
    });
    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    return { status: response.status, ok: response.ok, data };
}
function rows(result) { return Array.isArray(result.data) ? result.data : []; }

async function assertHidden(token, table, projectId) {
    const result = await rest(token, `${table}?project_id=eq.${encodeURIComponent(projectId)}&select=project_id&limit=1`);
    assert.equal(result.status, 200, `${table} cross-context SELECT should be filtered by RLS`);
    assert.deepEqual(rows(result), [], `${table} leaked project ${projectId}`);
}
async function assertProjectHidden(token, projectId) {
    const result = await rest(token, `projects?id=eq.${encodeURIComponent(projectId)}&select=id&limit=1`);
    assert.equal(result.status, 200, "cross-context project SELECT should be filtered by RLS");
    assert.deepEqual(rows(result), [], `projects leaked ${projectId}`);
}
async function assertDeniedWrite(token, table, method, path, payload) {
    const options = { method };
    if (payload !== null && payload !== undefined) options.body = JSON.stringify(payload);
    const result = await rest(token, `${table}?${path}`, options);
    if (method === "PATCH" || method === "DELETE") {
        assert.ok(result.status === 200 || result.status === 204, `${table} denied ${method} returned ${result.status}`);
        assert.deepEqual(rows(result), [], `${table} cross-context ${method} changed a row`);
    } else {
        assert.ok([400, 401, 403, 404, 409].includes(result.status), `${table} cross-context INSERT unexpectedly returned ${result.status}`);
    }
}

const tokenA = () => process.env.CODEWISE_STAGING_RLS_USER_A_TOKEN;
const tokenB = () => process.env.CODEWISE_STAGING_RLS_USER_B_TOKEN;
const nonce = () => crypto.randomUUID();
const probeName = `RLS mutation probe ${Date.now()}`;

// This suite talks directly to PostgREST with each user's JWT. It never uses a
// service-role key or an application handler, so successful isolation is RLS evidence.
test.before(() => {
    if (!enabled) return;
    configured();
});

test("direct staging RLS exposes each active project only to its own user", { skip: !enabled }, async () => {
    const ownA = await rest(tokenA(), `projects?id=eq.${ids.projectA}&work_context_id=eq.${ids.contextA}&select=id,work_context_id`);
    const ownB = await rest(tokenB(), `projects?id=eq.${ids.projectB}&work_context_id=eq.${ids.contextB}&select=id,work_context_id`);
    assert.equal(rows(ownA).length, 1);
    assert.equal(rows(ownB).length, 1);
    await assertProjectHidden(tokenA(), ids.projectB);
    await assertProjectHidden(tokenB(), ids.projectA);
});

test("direct staging RLS hides archived contexts and revoked memberships", { skip: !enabled }, async () => {
    await assertProjectHidden(tokenA(), ids.revokedProject);
    await assertProjectHidden(tokenA(), ids.archivedProject);
    await assertDeniedWrite(tokenA(), "projects", "PATCH", `id=eq.${ids.revokedProject}&select=id`, { name: probeName });
    await assertDeniedWrite(tokenA(), "projects", "PATCH", `id=eq.${ids.archivedProject}&select=id`, { name: probeName });
});

test("direct staging RLS denies cross-context SELECT across project domains", { skip: !enabled }, async () => {
    const tables = [
        "next_steps", "leads", "business_profiles", "appointments", "website_drafts",
        "website_audits", "audit_findings", "site_revisions", "client_approvals",
        "project_approval_history", "project_file_versions", "project_assets",
        "project_membership_invitations", "client_portal_shares", "client_portal_comments",
        "project_environments", "platform_deployments", "project_locales",
        "project_experiments", "analytics_events", "project_proposals", "project_handoffs"
    ];
    for (const table of tables) {
        await assertHidden(tokenA(), table, ids.projectB);
        await assertHidden(tokenB(), table, ids.projectA);
    }
});

test("direct staging RLS blocks project context transfer and foreign parent IDs", { skip: !enabled }, async () => {
    await assertDeniedWrite(tokenA(), "projects", "PATCH", `id=eq.${ids.projectA}&select=id`, { work_context_id: ids.contextB });
    await assertDeniedWrite(tokenA(), "project_approval_history", "POST", "select=id", {
        project_id: ids.projectA,
        approval_id: crypto.randomUUID(),
        status: "approved",
        revision: "foreign-parent-probe"
    });
});

test("direct staging RLS keeps pending and quarantined storage objects unavailable", { skip: !enabled }, async () => {
    for (const state of ["pending", "quarantined"]) {
        const metadata = await rest(tokenA(), `project_file_versions?project_id=eq.${ids.projectA}&verification_status=eq.${state}&select=storage_path&limit=1`);
        for (const file of rows(metadata)) {
            const object = await fetch(`${process.env.SUPABASE_URL.replace(/\/$/, "")}/storage/v1/object/authenticated/project-files/${file.storage_path}`, {
                headers: { apikey: process.env.SUPABASE_ANON_KEY, Authorization: `Bearer ${tokenA()}` }
            });
            assert.ok([400, 401, 403, 404].includes(object.status), `${state} object was downloadable`);
        }
    }
});

test("anonymous callers cannot invoke internal authorization helpers", { skip: !enabled }, async () => {
    const result = await rest(process.env.SUPABASE_ANON_KEY, "rpc/can_access_project_context", { method: "POST", body: JSON.stringify({ target_project: ids.projectA }) });
    assert.ok([401, 403, 404].includes(result.status), `anonymous helper invocation returned ${result.status}`);
});

test("direct staging RLS denies cross-context INSERT, UPDATE, and DELETE", { skip: !enabled }, async () => {
    const taskId = nonce();
    await assertDeniedWrite(tokenA(), "next_steps", "POST", "select=id", {
        id: taskId, user_id: ids.userA, project_id: ids.projectB, text: "RLS cross-context probe"
    });
    await assertDeniedWrite(tokenA(), "projects", "PATCH", `id=eq.${ids.projectB}&select=id`, { name: probeName });
    await assertDeniedWrite(tokenA(), "projects", "DELETE", `id=eq.${ids.projectB}&select=id`, null);
    const unchanged = await rest(tokenB(), `projects?id=eq.${ids.projectB}&select=id,name`);
    assert.equal(rows(unchanged).length, 1, "cross-context DELETE removed the foreign project");
    assert.notEqual(rows(unchanged)[0]?.name, probeName, "cross-context UPDATE changed the foreign project");

    const ownTask = nonce();
    const inserted = await rest(tokenA(), "next_steps?select=id,project_id", {
        method: "POST",
        body: JSON.stringify({ id: ownTask, user_id: ids.userA, project_id: ids.projectA, text: "Disposable RLS probe" })
    });
    assert.equal(inserted.status, 201, JSON.stringify(inserted.data));
    assert.equal(rows(inserted)[0]?.project_id, ids.projectA);
    const updated = await rest(tokenA(), `next_steps?id=eq.${ownTask}&project_id=eq.${ids.projectA}&select=id,completed`, {
        method: "PATCH", body: JSON.stringify({ completed: true, completed_at: new Date().toISOString() })
    });
    assert.equal(rows(updated)[0]?.completed, true);
    const removed = await rest(tokenA(), `next_steps?id=eq.${ownTask}&project_id=eq.${ids.projectA}&select=id`, { method: "DELETE" });
    assert.equal(rows(removed)[0]?.id, ownTask);
});
