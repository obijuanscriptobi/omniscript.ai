import { test, expect } from "@playwright/test";

const stagingUrl = process.env.SITE_URL || "";
const enabled = process.env.CODEWISE_STAGING === "true";
const roleTokens = {
    owner: process.env.CODEWISE_STAGING_OWNER_TOKEN || "",
    admin: process.env.CODEWISE_STAGING_ADMIN_TOKEN || "",
    editor: process.env.CODEWISE_STAGING_EDITOR_TOKEN || "",
    reviewer: process.env.CODEWISE_STAGING_REVIEWER_TOKEN || "",
    otherProject: process.env.CODEWISE_STAGING_OTHER_PROJECT_TOKEN || ""
};
const projectId = process.env.CODEWISE_STAGING_PROJECT_ID || "";
const otherProjectId = process.env.CODEWISE_STAGING_OTHER_PROJECT_ID || "";
const strictContract = process.env.CODEWISE_STAGING_STRICT === "true";
const providerChecksEnabled = process.env.CODEWISE_STAGING_PROVIDER_CHECKS === "true";
const adversarialChecksEnabled = process.env.CODEWISE_STAGING_ADVERSARIAL === "true";
const requiredStagingVariables = [
    "SUPABASE_URL",
    "SUPABASE_ANON_KEY",
    "SUPABASE_SERVICE_ROLE_KEY",
    "PREFLIGHT_SIGNING_SECRET",
    "NETLIFY_AUTH_TOKEN",
    "NETLIFY_SITE_ID",
    "PUBLIC_SITE_ORIGIN",
    "SCRAPINGBEE_API_KEY",
    "UPSTASH_REDIS_REST_URL",
    "UPSTASH_REDIS_REST_TOKEN",
    "LEADS_WEBHOOK_URL",
    "LEADS_WEBHOOK_HOSTS",
    "RESEND_API_KEY",
    "RESEND_FROM_EMAIL"
];
const optionalStagingVariables = [
    "BRAVE_SEARCH_API_KEY",
    "PAGESPEED_API_KEY"
];

function bearer(token) {
    return token ? { Authorization: `Bearer ${token}` } : {};
}

const roleEnvironmentNames = {
    owner: "OWNER",
    admin: "ADMIN",
    editor: "EDITOR",
    reviewer: "REVIEWER",
    otherProject: "OTHER_PROJECT"
};

function requireStagingRole(role) {
    const environmentName = roleEnvironmentNames[role] || role.toUpperCase();
    test.skip(!roleTokens[role], `Set CODEWISE_STAGING_${environmentName}_TOKEN for role-bound staging checks.`);
}

function expectSafeResponse(response) {
    expect(response.headers()["x-content-type-options"]).toBe("nosniff");
    expect(response.headers()["content-type"] || "").toMatch(/application\/json|text\//i);
}

// This suite is deliberately opt-in: it may call real providers and mutate staging data.
test.beforeAll(() => {
    test.skip(!enabled, "Set CODEWISE_STAGING=true to run against a disposable staging environment.");
    test.skip(!/^https:\/\//i.test(stagingUrl), "SITE_URL must be an HTTPS staging URL.");
});

test.describe("staging runtime smoke contract", () => {
    test("reports capabilities without exposing server secrets", async ({ request }) => {
        const response = await request.get("/api/config");
        expect([200, 503]).toContain(response.status());
        expectSafeResponse(response);
        const text = await response.text();
        const forbiddenValues = [
            process.env.SUPABASE_SERVICE_ROLE_KEY,
            process.env.SCRAPINGBEE_API_KEY,
            process.env.NETLIFY_AUTH_TOKEN,
            process.env.UPSTASH_REDIS_REST_TOKEN,
            process.env.RESEND_API_KEY,
            process.env.PREFLIGHT_SIGNING_SECRET
        ].filter((value) => value && value.length > 6);
        for (const value of forbiddenValues) expect(text).not.toContain(value);
        expect(text).not.toMatch(/service_role|sb_secret_/i);
        const payload = JSON.parse(text);
        expect(payload).toHaveProperty("capabilities");
        expect(payload).toHaveProperty("configuration");
    });

    test("matches the declared staging environment contract", async () => {
        test.skip(!strictContract, "Set CODEWISE_STAGING_STRICT=true to enforce the staging variable contract.");
        const missing = requiredStagingVariables.filter((name) => !process.env[name]);
        expect(missing, `Missing staging variables: ${missing.join(", ")}`).toEqual([]);
        expect(process.env.PUBLIC_SITE_ORIGIN).toMatch(/^https:\/\//i);
        expect(process.env.PUBLIC_SITE_ORIGIN.replace(/\/$/, "")).toBe(stagingUrl.replace(/\/$/, ""));
    });

    test("rejects unauthenticated project access", async ({ request }) => {
        const response = await request.get("/api/projects");
        expect(response.status()).toBe(401);
        expectSafeResponse(response);
    });

    test("records optional provider configuration without exposing values", async () => {
        test.skip(!strictContract, "Set CODEWISE_STAGING_STRICT=true to record the full environment contract.");
        const missingOptional = optionalStagingVariables.filter((name) => !process.env[name]);
        expect(missingOptional.every((name) => typeof name === "string")).toBe(true);
    });

    test("rejects invalid preflight requests", async ({ request }) => {
        const response = await request.post("/api/preflight", {
            data: { files: { "index.html": "<html></html>" } }
        });
        expect([401, 503]).toContain(response.status());
        expectSafeResponse(response);
    });

    test("rejects malformed and oversized preflight payloads", async ({ request }) => {
        const invalidJson = await request.post("/api/preflight", {
            headers: { "Content-Type": "application/json" },
            data: "{invalid"
        });
        expect([400, 401, 503]).toContain(invalidJson.status());
        expectSafeResponse(invalidJson);

        const oversized = await request.post("/api/preflight", {
            headers: { "Content-Type": "application/json", "Content-Length": "2000001" },
            data: "{}"
        });
        expect([400, 413, 503]).toContain(oversized.status());
        expectSafeResponse(oversized);
    });

    test("rejects invalid deployment verification requests", async ({ request }) => {
        const response = await request.post("/api/verify-deployment", {
            data: { url: "http://127.0.0.1" }
        });
        expect([400, 401, 503]).toContain(response.status());
        expectSafeResponse(response);
    });

    test("rejects unauthenticated deployment operations without contacting the provider", async ({ request }) => {
        const invalidMethod = await request.put("/api/deploy", { data: {} });
        expect(invalidMethod.status()).toBe(405);
        expectSafeResponse(invalidMethod);

        const invalidStatus = await request.get("/api/deploy?id=not-a-valid-deployment-id!");
        expect(invalidStatus.status()).toBe(401);
        expectSafeResponse(invalidStatus);

        const invalidPayload = await request.post("/api/deploy", {
            headers: { "Content-Type": "application/json" },
            data: { zip: "not-a-zip" }
        });
        expect(invalidPayload.status()).toBe(401);
        expectSafeResponse(invalidPayload);
    });

    test("does not expose another project's data to an authenticated user", async ({ request }) => {
        requireStagingRole("otherProject");
        test.skip(!otherProjectId, "Set CODEWISE_STAGING_OTHER_PROJECT_ID for isolation checks.");

        const response = await request.get(`/api/projects?id=${encodeURIComponent(otherProjectId)}`, {
            headers: bearer(roleTokens.otherProject)
        });
        expect([403, 404]).toContain(response.status());
        expectSafeResponse(response);
    });

    test("allows the staging owner to read the fixture project", async ({ request }) => {
        requireStagingRole("owner");
        test.skip(!projectId, "Set CODEWISE_STAGING_PROJECT_ID for role-bound staging checks.");

        const response = await request.get(`/api/projects?id=${encodeURIComponent(projectId)}`, {
            headers: bearer(roleTokens.owner)
        });
        expect([200, 404]).toContain(response.status());
        if (response.status() === 200) expectSafeResponse(response);
    });

    test("rejects cross-project writes for the authenticated staging user", async ({ request }) => {
        requireStagingRole("otherProject");
        test.skip(!projectId, "Set CODEWISE_STAGING_PROJECT_ID for write-isolation checks.");

        const response = await request.patch(`/api/projects?id=${encodeURIComponent(projectId)}`, {
            headers: { ...bearer(roleTokens.otherProject), "Content-Type": "application/json" },
            data: { name: "synthetic unauthorized mutation" }
        });
        expect([403, 404, 409]).toContain(response.status());
        expectSafeResponse(response);
    });

    test("rejects cross-project lead access for the authenticated staging user", async ({ request }) => {
        requireStagingRole("otherProject");
        test.skip(!projectId, "Set CODEWISE_STAGING_PROJECT_ID for lead-isolation checks.");

        const response = await request.get(`/api/leads?projectId=${encodeURIComponent(projectId)}`, {
            headers: bearer(roleTokens.otherProject)
        });
        expect([403, 404]).toContain(response.status());
        expectSafeResponse(response);
    });

    test("enforces form body and content-type boundaries", async ({ request }) => {
        const invalidJson = await request.post("/api/submit-form", {
            headers: {
                Origin: stagingUrl,
                "Content-Type": "application/json"
            },
            data: "{invalid"
        });
        expect([400, 403, 429, 503]).toContain(invalidJson.status());

        const unsupported = await request.post("/api/submit-form", {
            headers: {
                Origin: stagingUrl,
                "Content-Type": "text/plain"
            },
            data: "email=runtime-test@example.com"
        });
        expect([403, 415, 429, 503]).toContain(unsupported.status());
    });

    test("enforces form origin and method boundaries", async ({ request }) => {
        const getResponse = await request.get("/api/submit-form");
        expect([403, 405]).toContain(getResponse.status());

        const postResponse = await request.post("/api/submit-form", {
            headers: { Origin: "https://invalid-staging-origin.example" },
            data: { email: "runtime-test@example.com", message: "boundary test" }
        });
        expect([403, 400, 503]).toContain(postResponse.status());
        expectSafeResponse(postResponse);
    });

    test("rejects form abuse inputs before delivery", async ({ request }) => {
        test.skip(!adversarialChecksEnabled, "Set CODEWISE_STAGING_ADVERSARIAL=true for rate-limit and abuse checks.");
        const submission = { email: "runtime-test@example.com", message: "synthetic adversarial check" };
        const invalidId = await request.post("/api/submit-form", {
            headers: { Origin: stagingUrl, "X-Submission-ID": "invalid id" },
            data: submission
        });
        expect([200, 202, 400, 403, 429, 503]).toContain(invalidId.status());
        expectSafeResponse(invalidId);

        const honeypot = await request.post("/api/submit-form", {
            headers: { Origin: stagingUrl, "Content-Type": "application/json" },
            data: { ...submission, website: "https://bot.example" }
        });
        expect([200, 202, 400, 403, 429, 503]).toContain(honeypot.status());
        expectSafeResponse(honeypot);

        const oversized = await request.post("/api/submit-form", {
            headers: { Origin: stagingUrl, "Content-Type": "application/json", "Content-Length": "20001" },
            data: submission
        });
        expect([400, 403, 413, 429, 503]).toContain(oversized.status());
        expectSafeResponse(oversized);
    });

    test("runs explicitly enabled provider success checks", async ({ request }) => {
        test.skip(!providerChecksEnabled, "Set CODEWISE_STAGING_PROVIDER_CHECKS=true only with disposable provider credentials and fixtures.");
        const preflightToken = process.env.CODEWISE_STAGING_PREFLIGHT_TOKEN || "";
        const files = { "index.html": "<!doctype html><html><head><title>Staging</title></head><body><h1>Staging</h1></body></html>" };
        test.skip(!preflightToken, "Set CODEWISE_STAGING_PREFLIGHT_TOKEN for authorized preflight checks.");
        const preflight = await request.post("/api/preflight", {
            headers: { "X-Workspace-Token": preflightToken, "Content-Type": "application/json" },
            data: { files }
        });
        expect([200, 422, 503]).toContain(preflight.status());
        expectSafeResponse(preflight);

        const publishedUrl = process.env.CODEWISE_STAGING_PUBLISHED_URL || "";
        test.skip(!publishedUrl, "Set CODEWISE_STAGING_PUBLISHED_URL for published verification.");
        const verify = await request.post("/api/verify-deployment", {
            headers: bearer(roleTokens.owner),
            data: { url: publishedUrl, files: ["index.html", "sitemap.xml", "robots.txt"] }
        });
        expect([200, 401, 422, 503]).toContain(verify.status());
        expectSafeResponse(verify);
    });
});
