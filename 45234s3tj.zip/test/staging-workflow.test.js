"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { enabled, run } = require("../staging-workflow.js");

test("staging workflow is disabled by default", () => {
    assert.equal(enabled({}), false);
    assert.rejects(() => run({ env: {}, api: {} }), /STAGING_WORKFLOW_DISABLED/);
});

test("opt-in staging workflow executes and cleans up every deployment step", async () => {
    const calls = [];
    const api = {};
    for (const name of ["draft", "persistRevision", "restoreAndCompare", "approve", "preflight", "deploy", "pollAndVerify", "rollback", "cleanup"]) {
        api[name] = async (value) => {
            calls.push(name);
            return { success: true, id: `${name}-fixture`, ...value };
        };
    }
    const result = await run({ env: { CODEWISE_STAGING_WORKFLOW: "true" }, api, files: { "index.html": "<h1>Fixture</h1>" } });
    assert.equal(result.success, true);
    assert.deepEqual(calls, [
        "draft", "persistRevision", "restoreAndCompare", "approve", "preflight",
        "deploy", "pollAndVerify", "persistRevision", "deploy", "pollAndVerify",
        "rollback", "cleanup"
    ]);
});

test("staging workflow stops on a failed step", async () => {
    const calls = [];
    const api = {
        draft: async () => { calls.push("draft"); return { success: true }; },
        persistRevision: async () => { calls.push("persistRevision"); return { success: false }; }
    };
    await assert.rejects(() => run({ env: { CODEWISE_STAGING_WORKFLOW: "true" }, api, files: {} }), /STAGING_STEP_FAILED:persist-revision/);
    assert.deepEqual(calls, ["draft", "persistRevision"]);
});
