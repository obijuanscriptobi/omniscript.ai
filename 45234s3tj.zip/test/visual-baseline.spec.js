import { test, expect } from "@playwright/test";

// Visual baselines are intentionally limited to Chromium desktop/mobile so the
// first baseline set stays reviewable. The existing cross-browser suites still
// cover accessibility and functional behavior.
test.describe("workspace visual baselines", () => {
    test.beforeEach(async ({ page }) => {
        await page.addInitScript(() => {
            try {
                window.localStorage.clear();
                window.sessionStorage.clear();
            } catch {
                // Storage may be unavailable in a restricted browser context.
            }
        });
        await page.addStyleTag({ content: `
            *, *::before, *::after {
                animation-duration: 0s !important;
                animation-delay: 0s !important;
                transition-duration: 0s !important;
                caret-color: transparent !important;
            }
        `).catch(() => {});
    });

    test("main workspace empty state", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await expect(page).toHaveScreenshot("workspace-empty-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("Business Hub populated state", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await page.locator("#input-biz-name").fill("Northstar Studio");
        await page.locator("#input-biz-hook").fill("Clearer websites for local teams");
        await page.locator("#input-biz-location").fill("Austin, TX");
        await page.locator("#input-primary-cta").fill("Start a project");
        await page.waitForTimeout(400);
        await expect(page).toHaveScreenshot("business-hub-populated-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("CRM lead inbox populated state", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await page.evaluate(() => window.workspaceCRM?.add({
            name: "Jordan Lee",
            email: "jordan@example.com",
            source: "website",
            campaign: "spring-launch",
            notes: "Follow up this week"
        }));
        const advanced = page.locator("#show-advanced-tools-btn");
        if (await advanced.isVisible()) await advanced.click();
        await expect(page).toHaveScreenshot("crm-lead-inbox-populated-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("Ad Studio workspace", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.goto("/ad-studio.html", { waitUntil: "networkidle" });
        await expect(page).toHaveScreenshot("ad-studio-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("focus mode", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.goto("/index.html", { waitUntil: "networkidle" });
        const toggle = page.locator("#toggle-focus-mode-btn");
        await expect(toggle).toBeVisible();
        await toggle.click();
        await expect(toggle).toHaveAttribute("aria-pressed", "true");
        await expect(page).toHaveScreenshot("workspace-focus-mode-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("mobile workspace layout", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-mobile");
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await expect(page).toHaveScreenshot("workspace-empty-mobile.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("loading state", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.route("**/workspace-generator.js", async (route) => {
            await new Promise((resolve) => setTimeout(resolve, 700));
            await route.continue();
        });
        await page.goto("/index.html", { waitUntil: "domcontentloaded" });
        await expect(page.locator("html")).toHaveAttribute("data-loader-state", /loading|ready/);
        await expect(page).toHaveScreenshot("workspace-loading-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("error state", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.route("**/workspace-generator.js", (route) => route.abort());
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await expect(page.locator("#status-vector")).toHaveText("Workspace could not load");
        await expect(page).toHaveScreenshot("workspace-error-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });

    test("completed website populated state", async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "chromium-desktop");
        await page.goto("/index.html", { waitUntil: "networkidle" });
        await page.locator("#input-biz-name").fill("Northstar Studio");
        await page.locator("#input-biz-hook").fill("Help local teams launch clearer brands");
        await page.locator("#input-biz-services").fill("Brand strategy, Web design");
        await page.locator("#input-biz-location").fill("Austin, TX");
        await page.locator("#input-biz-audience").fill("Growing local businesses");
        await page.locator("#primary-create-website-btn").click();
        await expect(page.locator("#previewContentIframe")).toHaveAttribute("srcdoc", /.+/, { timeout: 10_000 });
        await expect(page).toHaveScreenshot("workspace-populated-desktop.png", {
            fullPage: true,
            animations: "disabled"
        });
    });
});
