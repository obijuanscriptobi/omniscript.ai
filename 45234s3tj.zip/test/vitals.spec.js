import { test, expect } from "@playwright/test";

const baseURL = process.env.SITE_URL || "http://127.0.0.1:8888";

test("homepage has no obvious layout shift sources", async ({ page }) => {
    await page.goto(`${baseURL}/index.html`, { waitUntil: "networkidle" });
    const result = await page.evaluate(() => {
        const images = [...document.images];
        const unstated = images.filter((image) => !image.width || !image.height).length;
        const inlineHandlers = document.querySelectorAll("[onclick], [onload], [onsubmit]").length;
        return { unstated, inlineHandlers };
    });
    expect(result.unstated).toBe(0);
    expect(result.inlineHandlers).toBe(0);
});

test("homepage stays within executable asset and third-party budgets", async ({ page }) => {
    await page.goto(`${baseURL}/index.html`, { waitUntil: "networkidle" });
    const result = await page.evaluate(() => {
        const resources = performance.getEntriesByType("resource");
        const thirdParty = resources.filter((entry) => {
            try { return new URL(entry.name).origin !== location.origin; } catch { return false; }
        });
        const transferBytes = resources.reduce((total, entry) => total + (Number(entry.transferSize) || 0), 0);
        const javascriptBytes = resources.filter((entry) => /\\.m?js(?:[?#]|$)/i.test(entry.name)).reduce((total, entry) => total + (Number(entry.transferSize) || 0), 0);
        const cssBytes = resources.filter((entry) => /\\.css(?:[?#]|$)/i.test(entry.name)).reduce((total, entry) => total + (Number(entry.transferSize) || 0), 0);
        return { thirdParty: thirdParty.length, transferBytes, javascriptBytes, cssBytes };
    });
    expect(result.thirdParty).toBeLessThanOrEqual(8);
    expect(result.transferBytes).toBeLessThanOrEqual(5_000_000);
    expect(result.javascriptBytes).toBeLessThanOrEqual(1_000_000);
    expect(result.cssBytes).toBeLessThanOrEqual(1_000_000);
});

test("homepage reports layout shift and long-task budgets when the browser supports them", async ({ page }) => {
    await page.goto(`${baseURL}/index.html`, { waitUntil: "networkidle" });
    const metrics = await page.evaluate(async () => {
        await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const cls = await new Promise((resolve) => {
            if (!PerformanceObserver.supportedEntryTypes?.includes("layout-shift")) return resolve(null);
            let value = 0;
            new PerformanceObserver((list) => list.getEntries().forEach((entry) => { if (!entry.hadRecentInput) value += entry.value; })).observe({ type: "layout-shift", buffered: true });
            setTimeout(() => resolve(value), 50);
        });
        const longTasks = PerformanceObserver.supportedEntryTypes?.includes("longtask")
            ? performance.getEntriesByType("longtask").filter((entry) => entry.duration >= 50).length
            : 0;
        return { cls, longTasks };
    });
    if (metrics.cls !== null) expect(metrics.cls).toBeLessThanOrEqual(0.1);
    expect(metrics.longTasks).toBeLessThanOrEqual(10);
});
