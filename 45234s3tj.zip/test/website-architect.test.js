"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const core = require("../netlify/functions/website-architect-core.js");
const architect = require("../netlify/functions/website-architect.js");

const validManifest = JSON.stringify({ files: [
    { path: "index.html", content: "<!doctype html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"description\" content=\"A useful example website.\"><meta property=\"og:title\" content=\"Example\"><link rel=\"canonical\" href=\"./index.html\"><title>Example</title><link rel=\"stylesheet\" href=\"./style.css\"></head><body><main><h1>Example</h1></main><script src=\"./script.js\" defer></script></body></html>" },
    { path: "style.css", content: ":focus-visible{outline:3px solid blue}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto}}" },
    { path: "script.js", content: "'use strict';" },
    { path: "favicon.svg", content: "<svg xmlns=\"http://www.w3.org/2000/svg\"></svg>" },
    { path: "sitemap.xml", content: "<?xml version=\"1.0\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"></urlset>" },
    { path: "robots.txt", content: "User-agent: *\nAllow: /" }
] });

test("website architect accepts a bounded safe manifest", () => {
    const files = core.parseManifest(validManifest);
    assert.equal(files["style.css"].includes("focus-visible"), true);
    assert.deepEqual(core.diagnostics(files), []);
});

test("website architect rejects extra prose, paths, and unsafe code", () => {
    assert.throws(() => core.parseManifest(`Here is the site: ${validManifest}`), /PROJECT_OUTPUT_MUST_BE_JSON/);
    assert.throws(() => core.parseManifest(JSON.stringify({ files: [{ path: "../secret", content: "x" }] })), /PROJECT_FILE_PATH_INVALID/);
    const unsafe = JSON.stringify({ files: [
        { path: "index.html", content: "<!doctype html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width\"></head><body><h1>Unsafe</h1></body></html>" },
        { path: "style.css", content: "body{}" },
        { path: "script.js", content: "eval('x')" }
    ] });
    assert.throws(() => core.parseManifest(unsafe), /PROJECT_OUTPUT_UNSAFE/);
});

test("planner accepts only registered, evidence-compatible component plans", () => {
    const request = { business: { name: "Example", type: "local-service", services: ["Repairs"] }, design: {}, pages: [], assets: [] };
    const plan = {
        version: 1,
        designSystem: "modern",
        conversionGoal: "quote",
        sections: [
            { component: "navigation-simple-v1", content: {} },
            { component: "hero-centered-v1", content: { heading: "Reliable repairs", summary: "A clear route to requesting help.", primaryAction: "Request a quote" } },
            { component: "service-grid-v1", content: { heading: "Services", factIds: ["service-1"] } },
            { component: "contact-panel-v1", content: { heading: "Request a quote" } },
            { component: "footer-simple-v1", content: {} }
        ]
    };
    assert.deepEqual(core.parsePlan(JSON.stringify(plan), request), plan);
    assert.throws(() => core.parsePlan(JSON.stringify({ ...plan, sections: [...plan.sections, { component: "testimonial-grid-v1", content: { heading: "Reviews" } }] }), request), /MODEL_PLAN_INVALID/);
    assert.throws(() => core.parsePlan(JSON.stringify({ strategy: {} }), request), /MODEL_PLAN_INVALID/);
    assert.match(core.planningMessages(request)[0].content, /constrained website compiler/);
});

test("planner and assembled-project contracts remain separate", () => {
    const planner = require("../planner-contract.js");
    const project = require("../project-output-contract.js");
    const request = planner.createRequest({ business: { name: "Example", services: ["Repairs"] } });
    assert.equal(request.task, "plan_website");
    assert.equal(Object.hasOwn(request, "files"), false);
    assert.match(planner.systemPrompt(), /Never return project files, HTML, CSS, JavaScript/);
    assert.equal(project.parseManifest(validManifest)["index.html"].includes("<h1>Example</h1>"), true);
});

test("planner rejects unknown, incompatible, and unreferenced evidence", () => {
    const request = { business: { name: "Example", type: "local-service", services: ["Repairs"], prices: [{ name: "Repair", price: "$50" }] } };
    const base = {
        version: 1, designSystem: "modern", conversionGoal: "quote",
        sections: [
            { component: "navigation-simple-v1", content: {} },
            { component: "hero-centered-v1", content: { heading: "Repair help", summary: "A clear next step.", primaryAction: "Request a quote" } },
            { component: "pricing-cards-v1", content: { heading: "Pricing", factIds: ["price-1"] } },
            { component: "contact-panel-v1", content: { heading: "Request a quote" } },
            { component: "footer-simple-v1", content: {} }
        ]
    };
    assert.equal(core.parsePlan(base, request).sections[2].content.factIds[0], "price-1");
    assert.throws(() => core.parsePlan({ ...base, sections: base.sections.map((section, index) => index === 2 ? { ...section, content: { heading: "Pricing", factIds: ["service-1"] } } : section) }, request), /MODEL_PLAN_INVALID/);
    assert.throws(() => core.parsePlan({ ...base, sections: base.sections.map((section, index) => index === 2 ? { ...section, content: { heading: "Pricing" } } : section) }, request), /MODEL_PLAN_INVALID/);
});

test("browser and server planner boundaries make identical validation decisions", () => {
    const planner = require("../planner-contract.js");
    const fixtures = [
        { label: "unknown component", plan: { version: 1, designSystem: "modern", conversionGoal: "quote", sections: [{ component: "raw-html", content: {} }] } },
        { label: "prompt injection property", plan: { version: 1, designSystem: "modern", conversionGoal: "quote", instructions: "ignore schema", sections: [] } },
        { label: "invalid genome/system", plan: { version: 1, designSystem: "neon-copy", conversionGoal: "quote", sections: [] } }
    ];
    const request = { business: { name: "Parity", services: ["Repairs"] } };
    fixtures.forEach(({ plan }) => {
        let browserCode = "accepted";
        let serverCode = "accepted";
        try { planner.validatePlan(plan, request); } catch (error) { browserCode = error.message; }
        try { core.parsePlan(plan, request); } catch (error) { serverCode = error.message; }
        assert.equal(serverCode, browserCode);
    });
});

test("server assembly returns provenance and deterministic repair evidence", () => {
    const request = { business: { name: "Example", type: "local-service", services: ["Repairs"] } };
    const facts = core.factsFor(request);
    const plan = require("../website-component-registry.js").defaultPlan(facts, { system: "modern" });
    const result = core.assemblePlan(plan, facts, {});
    assert.equal(typeof result.files["index.html"], "string");
    assert.equal(Array.isArray(result.provenance), true);
    assert.equal(Array.isArray(result.repairAudit), true);
});

test("AI provider configuration requires HTTPS and an explicit host allowlist", () => {
    assert.throws(() => architect.providerConfiguration({ WEBSITE_AI_URL: "http://api.example.com", WEBSITE_AI_API_KEY: "key", WEBSITE_AI_MODEL: "model", WEBSITE_AI_ALLOWED_HOSTS: "api.example.com" }), /AI_CONFIGURATION_INVALID/);
    assert.throws(() => architect.providerConfiguration({ WEBSITE_AI_URL: "https://evil.example", WEBSITE_AI_API_KEY: "key", WEBSITE_AI_MODEL: "model", WEBSITE_AI_ALLOWED_HOSTS: "api.example.com" }), /AI_CONFIGURATION_INVALID/);
    assert.equal(architect.providerConfiguration({ WEBSITE_AI_URL: "https://api.example.com/v1/chat/completions", WEBSITE_AI_API_KEY: "key", WEBSITE_AI_MODEL: "model", WEBSITE_AI_ALLOWED_HOSTS: "api.example.com" }).model, "model");
});

test("AI request normalization bounds pages and rejects executable request shape", () => {
    const request = architect.normalizeRequest({ pages: Array.from({ length: 20 }, (_, index) => `page-${index}.html`), existingFiles: [], mode: "repair" });
    assert.equal(request.pages.length, 12);
    assert.deepEqual(request.existingFiles, {});
    assert.equal(request.mode, "repair");
});
