import { test, expect } from "@playwright/test";

const baseURL = process.env.SITE_URL || "http://127.0.0.1:8888";

async function basicAccessibilityIssues(page) {
    return page.evaluate(() => {
        const issues = [];
        const ids = [...document.querySelectorAll("[id]")].map((node) => node.id);
        if (new Set(ids).size !== ids.length) issues.push("duplicate ids");
        document.querySelectorAll("button, a[href], input, select, textarea").forEach((node) => {
            const name = node.getAttribute("aria-label") || node.getAttribute("aria-labelledby") || node.textContent?.trim() || node.getAttribute("title") || (node.id && document.querySelector(`label[for=\"${CSS.escape(node.id)}\"]`)?.textContent.trim());
            if (!name) issues.push(`unnamed ${node.tagName.toLowerCase()}`);
        });
        document.querySelectorAll("img").forEach((image) => { if (!image.hasAttribute("alt")) issues.push("image without alt"); });
        return issues;
    });
}

test.describe("website maker accessibility and staged UI", () => {
    test("preview remains origin-isolated and progress is accessible", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("#previewContentIframe")).toHaveAttribute("sandbox", "allow-scripts");
        const progress = page.locator(".publish-confidence-progress");
        await expect(progress).toHaveAttribute("role", "progressbar");
        await expect(progress).toHaveAttribute("aria-valuemin", "0");
        await expect(progress).toHaveAttribute("aria-valuenow", /\d+/);
    });

    test("sequential brief supports keyboard movement and truthful progress", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await expect(page.locator("#publish-confidence-score")).toHaveText("0/6");
        await page.locator("#outcome-name-input").fill("Northstar Studio");
        await page.locator("#outcome-name-input").press("Enter");
        await expect(page.locator("#outcome-offer-input")).toBeFocused();
        await expect(page.locator("#outcome-brief-status")).toHaveText("2 of 6");
    });

    test("advanced panel restores focus and respects reduced motion", async ({ page }) => {
        await page.emulateMedia({ reducedMotion: "reduce" });
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.body.dataset.draftReady = "true";
            document.querySelector(".advanced-tools-control").style.display = "block";
        });
        const toggle = page.locator("#show-advanced-tools-btn");
        await expect(page.locator("#input-biz-address")).toHaveCount(0);
        await toggle.click();
        await expect(page.locator("#advanced-workspace-tools")).toBeVisible();
        await expect(page.locator("#input-biz-address")).toHaveCount(1);
        await page.locator("#input-biz-address").focus();
        await toggle.click({ force: true });
        await expect(toggle).toBeFocused();
        await expect(toggle).toHaveAttribute("aria-expanded", "false");
    });

    test("context changes close Advanced tools and restore toggle focus", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.body.dataset.draftReady = "true";
            document.querySelector(".advanced-tools-control").style.display = "block";
        });
        const toggle = page.locator("#show-advanced-tools-btn");
        await toggle.click();
        await expect(page.locator("#input-biz-address")).toHaveCount(1);
        await page.locator("#input-biz-address").focus();
        await page.evaluate(() => document.dispatchEvent(new CustomEvent("workspace:project-changed")));
        await expect(page.locator("#advanced-workspace-tools")).toBeHidden();
        await expect(toggle).toBeFocused();
        await expect(toggle).toHaveAttribute("aria-expanded", "false");
    });

    test("context switching while Advanced loads closes it and restores focus", async ({ page }) => {
        let releaseRequest;
        const release = new Promise((resolve) => { releaseRequest = resolve; });
        let requestStarted;
        const started = new Promise((resolve) => { requestStarted = resolve; });
        await page.route("**/workspace-schema.js", async (route) => {
            requestStarted();
            await release;
            await route.continue();
        });
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.body.dataset.draftReady = "true";
            document.querySelector(".advanced-tools-control").style.display = "block";
        });
        const toggle = page.locator("#show-advanced-tools-btn");
        await toggle.click();
        await started;
        await page.evaluate(() => document.dispatchEvent(new CustomEvent("workspace:project-changed")));
        await expect(page.locator("#advanced-workspace-tools")).toBeHidden();
        await expect(toggle).toBeFocused();
        releaseRequest();
        await expect.poll(() => page.evaluate(() => window.websiteMakerStageLoader.pending("advanced"))).toBe(false);
        await expect(toggle).toHaveAttribute("aria-expanded", "false");
    });

    test("Advanced failure uses one live status and an accessible focused retry", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.body.dataset.draftReady = "true";
            document.querySelector(".advanced-tools-control").style.display = "block";
            document.getElementById("show-advanced-tools-btn").click();
            document.dispatchEvent(new CustomEvent("website-maker:stage-error", { detail: { stage: "advanced", error: new Error("Advanced unavailable") } }));
        });
        const retry = page.locator("[data-retry-advanced]");
        await expect(retry).toHaveCount(1);
        await expect(retry).toBeFocused();
        await expect(page.locator("#advanced-tools-status")).toHaveText("Advanced unavailable");
        const matchingLiveRegions = await page.locator('[role="status"]').evaluateAll((nodes) => nodes.filter((node) => node.textContent === "Advanced unavailable").length);
        expect(matchingLiveRegions).toBe(1);
    });

    test("generation errors are text-only and receive focus", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.dispatchEvent(new CustomEvent("workspace:generation-error", {
                detail: { message: '<img src=x onerror="window.__injected=true"> stopped' }
            }));
        });
        const status = page.locator("#publish-confidence-status");
        await expect(status).toContainText("<img src=x");
        await expect(status.locator("img")).toHaveCount(0);
        await expect(status).toBeFocused();
        expect(await page.evaluate(() => window.__injected)).toBeUndefined();
        expect(await basicAccessibilityIssues(page)).toEqual([]);
    });

    test("review creation and approval move focus to one meaningful status", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.body.dataset.draftReady = "true";
            document.body.dataset.creationMode = "client";
            window.workspaceAPI.applySnapshot({
                ...window.workspaceAPI.getState(),
                files: { "index.html": "<!doctype html><html lang=\"en\"><head><title>Review</title></head><body><h1>Review</h1></body></html>", "style.css": "", "script.js": "" }
            }, { dirty: true });
            window.websiteMakerStageLoader.loadStage("draft");
        });
        await expect.poll(() => page.evaluate(() => window.websiteMakerStageLoader.loaded("draft"))).toBe(true);
        await page.locator("#client-review-share-btn").click();
        await expect(page.locator("#client-review-status")).toBeFocused();
        await expect(page.locator("#client-review-status")).toContainText(/review link ready/i);
        await page.locator("#client-review-approve-btn").click();
        await expect(page.locator("#client-review-status")).toBeFocused();
        await expect(page.locator("#client-review-status")).toContainText(/approved/i);
        const duplicate = await page.locator('[role="status"], [role="alert"]').evaluateAll((nodes) => {
            const active = nodes.map((node) => node.textContent.trim()).filter((text) => /approved/i.test(text));
            return active.length;
        });
        expect(duplicate).toBe(1);
    });

    test("publishing outcomes move focus to the go-live status", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => window.websiteMakerStageLoader.loadStage("draft"));
        await expect.poll(() => page.evaluate(() => window.websiteMakerStageLoader.loaded("draft"))).toBe(true);
        await page.evaluate(() => {
            const current = window.workspaceAPI.getState();
            window.workspaceAPI.applySnapshot({
                ...current,
                files: { "index.html": "<!doctype html><html lang=\"en\"><head><title>Published</title></head><body><h1>Published</h1></body></html>", "style.css": "", "script.js": "" }
            }, { dirty: false });
            window.websiteMakerProfileStore.update({ identity: { phoneDisplay: "+1 555 123 4567", email: "owner@example.com" }, availability: "By appointment" }, { source: "publish-focus-test" });
            window.websiteMakerWorkflow.transition("draft", { source: "workspace" });
            document.dispatchEvent(new CustomEvent("workspace:deployment-complete", { detail: { url: "https://example.com/", revision: window.workspaceAPI.getState().revision } }));
        });
        await expect(page.locator("#go-live-status")).toBeFocused();
        await expect(page.locator("#go-live-status")).toContainText(/live|Publishing started/i);
        await page.evaluate(() => document.dispatchEvent(new CustomEvent("workspace:deployment-failed", { detail: { message: "Publishing failed safely." } })));
        await expect(page.locator("#go-live-status")).toBeFocused();
        await expect(page.locator("#go-live-status")).toHaveText("Publishing failed safely.");
    });

    test("Advanced supports repeated keyboard failure, retry, and close cycles", async ({ page }) => {
        await page.goto(`${baseURL}/index.html`);
        await page.evaluate(() => {
            document.body.dataset.draftReady = "true";
            document.querySelector(".advanced-tools-control").style.display = "block";
        });
        const toggle = page.locator("#show-advanced-tools-btn");
        for (let cycle = 0; cycle < 2; cycle += 1) {
            await toggle.focus();
            await toggle.press("Enter");
            await page.evaluate(() => document.dispatchEvent(new CustomEvent("website-maker:stage-error", { detail: { stage: "advanced", error: new Error("Temporary failure") } })));
            await expect(page.locator("[data-retry-advanced]")).toBeFocused();
            await page.evaluate(() => document.dispatchEvent(new CustomEvent("website-maker:stage-ready", { detail: { stage: "advanced" } })));
            await expect(page.locator("#input-biz-address")).toBeFocused();
            await toggle.click({ force: true });
            await expect(toggle).toBeFocused();
        }
    });
});
