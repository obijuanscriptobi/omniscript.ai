"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

function workflowContext({ stored = null, html = "", scope = "own:own-business", revision = "r1" } = {}) {
    const listeners = new Map();
    const body = { dataset: {} };
    const document = {
        body,
        addEventListener(name, fn) { listeners.set(name, fn); },
        dispatchEvent(event) { listeners.get(event.type)?.(event); },
        getElementById() { return null; }
    };
    const scopedKey = `omniscript-maker-workflow-v2::${scope}`;
    const session = new Map(stored ? [[scopedKey, JSON.stringify(stored)]] : []);
    const context = {
        window: {
            workspaceAPI: { getState: () => ({ files: { "index.html": html }, revision }) },
            workspaceContext: { ready: true, storageKey: (base) => `${base}::${scope}`, current: () => ({ id: scope.split(":")[1], mode: scope.split(":")[0] }) },
            websiteMakerProfileStore: { getState: () => ({ identity: { phoneDial: "+15551234567", email: "owner@example.com" }, availability: "By appointment" }) },
            addEventListener() {}
        }, document,
        sessionStorage: { getItem: (key) => session.get(key) || null, setItem: (key, value) => session.set(key, value) },
        CustomEvent: class { constructor(type, options = {}) { this.type = type; this.detail = options.detail; } },
        console, Date, Set, JSON
    };
    context.window.document = document;
    vm.runInNewContext(read("website-maker-workflow.js"), context);
    return context;
}

test("website maker removes legacy and unrelated page payloads", () => {
    const html = read("index.html");
    assert.doesNotMatch(html, /data-legacy-(?:styles|controller|audit-handoff)/);
    assert.doesNotMatch(html, /business-command-center|business-operations-panel|ad-studio-title/);
    assert.doesNotMatch(html, /allow-same-origin/);
    assert.match(html, /sandbox="allow-scripts"/);
});

test("workflow rejects invalid transitions without changing rendered state", () => {
    const context = workflowContext();
    assert.equal(context.window.websiteMakerWorkflow.transition("published", { source: "test" }), false);
    assert.equal(context.document.body.dataset.workflowState, "brief");
    assert.equal(context.document.body.dataset.draftReady, "false");
});

test("workflow recovers interrupted generation and reconciles missing drafts", () => {
    const interrupted = workflowContext({ stored: { state: "generating", projectType: "owner", reviewStatus: "draft" } });
    assert.equal(interrupted.window.websiteMakerWorkflow.getState().state, "brief");
    assert.equal(interrupted.window.websiteMakerWorkflow.consumeRecovery().from, "generating");
    const stale = workflowContext({ stored: { state: "approved", projectType: "client", reviewStatus: "approved" } });
    assert.equal(stale.window.websiteMakerWorkflow.reconcile().state, "brief");
    assert.equal(stale.document.body.dataset.reviewApproved, "false");
});

test("profile store covers advanced profile domains and flushes on pagehide", () => {
    const source = read("website-maker-profile-store.js");
    for (const id of ["input-biz-address", "input-biz-booking", "input-biz-pricing", "input-biz-credentials", "input-biz-testimonial", "input-biz-color", "input-biz-logo", "input-biz-approved-claims", "input-primary-cta", "input-privacy-analytics", "input-form-endpoint"]) assert.match(source, new RegExp(id));
    assert.match(source, /SCHEMA_VERSION = 2/);
    assert.match(source, /Math\.max\(revision, Number\(latest\?\.revision \|\| 0\)\)/);
    assert.match(source, /addEventListener\("pagehide", \(\) => flush\(activeKey\)\)/);
    assert.match(source, /phoneDisplay/);
    assert.match(source, /phoneDial/);
    assert.match(source, /phoneExtension/);
    assert.match(source, /workspaceContext\?\.storageKey/);
    assert.match(source, /const reconcile = \(record/);
    assert.match(source, /website-maker:advanced-mounted/);
    assert.match(source, /website-maker:profile-record/);
});

test("generation consumes the canonical profile rather than DOM controls", () => {
    const generator = read("workspace-generator.js");
    assert.match(generator, /websiteMakerProfileStore\?\.getState/);
    assert.match(generator, /deepFreeze\(clone\(source\)\)/);
    assert.match(generator, /businessFromProfile/);
    assert.doesNotMatch(generator, /getElementById|querySelector/);
});

test("advanced controls are inert until requested and staged loading is idempotent", () => {
    const html = read("index.html");
    assert.doesNotMatch(html, /advanced-workspace-tools-template|input-biz-address/);
    assert.match(html, /<div id="advanced-workspace-tools" class="advanced-workspace-tools" hidden><\/div>/);
    const template = read("website-maker-advanced-template.js");
    assert.match(template, /template\.id = "advanced-workspace-tools-template"/);
    assert.match(template, /input-biz-address/);
    const loader = read("website-maker-stage-loader.js");
    assert.match(loader, /advanced: \["website-maker-advanced-template\.js", "workspace-schema\.js", "platform-ui\.js"\]/);
    assert.match(loader, /loadedStages\.has\(name\)/);
    assert.match(loader, /pending\.has\(src\)/);
    assert.match(loader, /website-maker:advanced-requested/);
    const shell = read("website-maker-shell.js");
    assert.match(shell, /tools\.contains\(document\.activeElement\)/);
    assert.match(shell, /template\.content\.cloneNode\(true\)/);
    assert.match(shell, /website-maker:advanced-mounted/);
    assert.match(shell, /prefers-reduced-motion/);
});

test("contextual next action covers creation, review, publishing, and download", () => {
    const source = read("website-maker-next-action.js");
    for (const label of ["Continue your brief", "Add contact details", "Share for client review", "Awaiting client approval", "Publish website", "Download website files", "Open live website"]) assert.match(source, new RegExp(label));
    assert.doesNotMatch(source, /innerHTML/);
});

test("preview messaging uses frame identity and one strict protocol", () => {
    const source = read("enquiry-loop.js");
    const protocol = read("preview-protocol.js");
    assert.match(source, /event\.source !== iframe\?\.contentWindow/);
    assert.match(source, /websiteMakerPreviewProtocol\?\.parse/);
    assert.match(protocol, /website-maker-preview-v1/);
    assert.match(protocol, /Object\.keys\(payload\).*allowedKeys/);
    assert.match(protocol, /payload\.message\.length > LIMITS\.error \* 2/);
});

test("project type changes invalidate approval and publishing requires evidence", () => {
    const source = read("website-maker-workflow.js");
    assert.match(source, /reviewStatus: "draft", state: nextState/);
    assert.match(source, /missing-deployment-evidence/);
    assert.match(source, /approvedRevision/);
    assert.match(read("website-maker-publishing.js"), /deploymentVerified: true/);
});

test("staged loading excludes removed diagnostics and reports failures", () => {
    const source = read("website-maker-stage-loader.js");
    const html = read("index.html");
    assert.doesNotMatch(source, /workspace-phase3|maturity-controls|preview-sharing|trust-review/);
    for (const deferred of ["website-maker-contact.js", "website-maker-publishing.js", "enquiry-loop.js", "review-handoff.js", "workspace-schema.js"]) {
        assert.doesNotMatch(html, new RegExp(`<script[^>]+src=["']${deferred.replace(".", "\\.")}["']`));
    }
    assert.match(source, /stagePromises\.has\(name\)/);
    assert.match(source, /existing && \(existing\.dataset\.loaded === "true" \|\| !existing\.async\)/);
    assert.match(source, /website-maker:stage-error/);
    assert.match(source, /workspace:project-changed/);
});

test("awaiting approval is a disabled contextual state", () => {
    const source = read("website-maker-next-action.js");
    assert.match(source, /label: "Awaiting approval", disabled: true/);
});

test("client approval is invalidated when project type changes", () => {
    const context = workflowContext({ html: "<!doctype html><title>Draft</title>" });
    const workflow = context.window.websiteMakerWorkflow;
    workflow.setProjectType("client");
    assert.equal(workflow.transition("draft", { source: "workspace" }), true);
    assert.equal(workflow.transition("approved", { source: "client-review", approvedRevision: "r1" }), true);
    assert.equal(context.document.body.dataset.reviewApproved, "true");
    workflow.setProjectType("owner");
    assert.equal(workflow.getState().state, "draft");
    assert.equal(workflow.getState().reviewStatus, "draft");
});

test("workflow state is isolated by work-context scope", () => {
    const approved = workflowContext({ scope: "client:alpha", html: "<!doctype html><title>Alpha</title>", stored: { state: "approved", projectType: "client", reviewStatus: "approved", approvedRevision: "r1" } });
    const fresh = workflowContext({ scope: "client:beta", html: "" });
    assert.equal(approved.window.websiteMakerWorkflow.getState().reviewStatus, "approved");
    assert.equal(fresh.window.websiteMakerWorkflow.getState().reviewStatus, "draft");
    assert.equal(fresh.window.websiteMakerWorkflow.getState().state, "brief");
});

test("workspace file notifications carry the canonical revision", () => {
    const source = read("script.js");
    assert.match(source, /function currentFilesRevision\(\)/);
    assert.match(source, /CustomEvent\("workspace:files-rendered", \{\s*detail: \{ revision: currentFilesRevision\(\)/);
    assert.match(source, /revision: currentFilesRevision\(\)/);
});

test("approval and deployment evidence must match the current revision", () => {
    const context = workflowContext({ html: "<!doctype html><title>Draft</title>", revision: "r2" });
    const workflow = context.window.websiteMakerWorkflow;
    workflow.setProjectType("client");
    assert.equal(workflow.transition("draft", { source: "workspace" }), true);
    assert.equal(workflow.transition("approved", { source: "client-review", approvedRevision: "r1" }), false);
    assert.equal(workflow.transition("approved", { source: "client-review", approvedRevision: "r2" }), true);
    assert.equal(workflow.transition("published", { source: "deployment", deploymentVerified: true, deploymentRevision: "r1", deploymentUrl: "https://example.com" }), false);
    assert.equal(workflow.transition("published", { source: "deployment", deploymentVerified: true, deploymentRevision: "r2", deploymentUrl: "https://example.com" }), true);
});

test("verified deployment evidence restores only for the current revision", () => {
    const valid = workflowContext({
        html: "<!doctype html><title>Draft</title>",
        revision: "r2",
        stored: { state: "published", projectType: "client", reviewStatus: "approved", approvedRevision: "r2", deploymentVerified: true, deploymentRevision: "r2", deploymentUrl: "https://example.com" }
    });
    assert.equal(valid.window.websiteMakerWorkflow.reconcile().state, "published");

    for (const patch of [
        { deploymentVerified: false },
        { deploymentRevision: "r1" },
        { deploymentUrl: "http://example.com" },
        { deploymentUrl: "" }
    ]) {
        const context = workflowContext({
            html: "<!doctype html><title>Draft</title>",
            revision: "r2",
            stored: { state: "published", projectType: "client", reviewStatus: "approved", approvedRevision: "r2", deploymentVerified: true, deploymentRevision: "r2", deploymentUrl: "https://example.com", ...patch }
        });
        assert.equal(context.window.websiteMakerWorkflow.reconcile().state, "approved");
        assert.equal(context.window.websiteMakerWorkflow.getState().reason, "missing-deployment-evidence");
    }
});

test("stale approval evidence downgrades a restored publication to draft", () => {
    const context = workflowContext({
        html: "<!doctype html><title>Regenerated</title>",
        revision: "r3",
        stored: { state: "published", projectType: "client", reviewStatus: "approved", approvedRevision: "r2", deploymentVerified: true, deploymentRevision: "r2", deploymentUrl: "https://example.com" }
    });
    const state = context.window.websiteMakerWorkflow.reconcile();
    assert.equal(state.state, "draft");
    assert.equal(state.reviewStatus, "draft");
    assert.equal(state.reason, "revision-changed");
});

test("startup waits for canonical context and stale profile timers are scope-bound", () => {
    const profile = read("website-maker-profile-store.js");
    const workflow = read("website-maker-workflow.js");
    const context = read("workspace-context.js");
    assert.match(profile, /workspace:context-ready/);
    assert.match(profile, /expectedKey !== activeKey/);
    assert.match(profile, /incomingProjectId/);
    assert.match(profile, /requestedKey !== activeKey/);
    assert.match(profile, /method: "PUT"/);
    assert.match(profile, /expectedRevision: remoteRevision/);
    assert.match(workflow, /workspaceContext\?\.ready === true/);
    assert.match(context, /workspace:context-ready/);
});

test("preview sandbox blocks external form navigation before capturing enquiries", () => {
    const source = read("workspace-preview-controller.js");
    assert.match(source, /event\.preventDefault\(\)/);
    assert.match(source, /event\.stopImmediatePropagation\(\)/);
    assert.match(source, /form\.removeAttribute\("action"\)/);
    assert.match(source, /iframe\.removeAttribute\("src"\)/);
});

test("client import requires an explicit authorization confirmation", () => {
    const html = read("index.html");
    const intake = read("client-intake.js");
    assert.match(html, /id="client-source-authorized"[^>]*type="checkbox"[^>]*required/);
    assert.match(html, /Imports create an editable rebuild; they do not transfer ownership/);
    assert.match(intake, /if \(!authorization\?\.checked\)/);
    assert.match(intake, /Confirm client authorization before importing/);
});

test("startup diagnostics record script weight and staged state", () => {
    const source = read("app-loader.js");
    assert.match(source, /initialScriptCount/);
    assert.match(source, /transferredScriptBytes/);
    assert.match(source, /websiteMakerStageLoader\?\.loaded/);
});

test("preview protocol rejects unknown and oversized messages", () => {
    const context = { window: {}, Set, Object, String };
    vm.runInNewContext(read("preview-protocol.js"), context);
    const parse = context.window.websiteMakerPreviewProtocol.parse;
    assert.equal(parse({ channel: "website-maker-preview-v1", type: "enquiry", payload: { email: "a@example.com", admin: true } }), null);
    assert.equal(parse({ channel: "website-maker-preview-v1", type: "error", payload: { message: "x".repeat(1001) } }), null);
    assert.equal(parse({ channel: "website-maker-preview-v1", type: "enquiry", payload: { message: "x".repeat(4001) } }), null);
    assert.equal(parse({ channel: "website-maker-preview-v1", type: "unknown", payload: { email: "a@example.com" } }), null);
    assert.equal(parse({ channel: "wrong", type: "enquiry", payload: { email: "a@example.com" } }), null);
    assert.equal(parse({ channel: "website-maker-preview-v1", type: "enquiry", payload: { email: "a@example.com" } }).payload.email, "a@example.com");
});
