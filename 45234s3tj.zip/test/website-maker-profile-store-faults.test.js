"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "website-maker-profile-store.js"), "utf8");

function boot({ stored, getThrows = false, setThrows = false, fetchImpl, contextId = "alpha", projectId = "project-alpha" } = {}) {
    const key = `morrow-business-profile-v1::client:${contextId}`;
    const values = new Map(stored === undefined ? [] : [[key, stored]]);
    const documentListeners = new Map();
    const windowListeners = new Map();
    const timers = [];
    const document = {
        readyState: "complete",
        getElementById: () => null,
        querySelector: () => null,
        addEventListener(name, fn) { documentListeners.set(name, fn); },
        dispatchEvent(event) { documentListeners.get(event.type)?.(event); return true; }
    };
    const localStorage = {
        getItem(name) { if (getThrows) throw new Error("read denied"); return values.get(name) ?? null; },
        setItem(name, value) { if (setThrows) throw new Error("quota"); values.set(name, String(value)); }
    };
    const current = { id: contextId, cloudId: `cloud-${contextId}`, mode: "client" };
    const window = {
        document,
        workspaceContext: { ready: true, storageKey: (base) => `${base}::client:${current.id}`, current: () => ({ ...current }) },
        workspaceAPI: { getState: () => ({ projectId }) },
        supabaseWorkspace: { getAccessToken: () => "token" },
        addEventListener(name, fn) { windowListeners.set(name, fn); },
        setTimeout(fn) { timers.push(fn); return timers.length; },
        clearTimeout() {}
    };
    const sandbox = {
        window, document, localStorage,
        fetch: fetchImpl || (async () => ({ ok: true, status: 200, json: async () => ({}) })),
        CustomEvent: class { constructor(type, init = {}) { this.type = type; this.detail = init.detail; } },
        structuredClone: global.structuredClone,
        console, JSON, Date, Set, Object, Array, String, Number, Boolean
    };
    vm.runInNewContext(source, sandbox, { filename: "website-maker-profile-store.js" });
    return {
        store: window.websiteMakerProfileStore,
        values,
        key,
        current,
        async drain() {
            for (let pass = 0; pass < 8; pass += 1) {
                while (timers.length) await timers.shift()();
                await Promise.resolve();
                await Promise.resolve();
                if (!timers.length) await new Promise((resolve) => setImmediate(resolve));
                if (!timers.length) break;
            }
        },
        dispatch(name, detail) { document.dispatchEvent(new sandbox.CustomEvent(name, { detail })); }
    };
}

const record = (name, revision = 1, savedAt = "2026-01-01T00:00:00.000Z") => JSON.stringify({
    version: 2, revision, savedAt, profile: { identity: { displayName: name } }
});

test("profile store survives malformed records and storage read/write failures", async () => {
    for (const options of [{ stored: "{truncated" }, { getThrows: true }, { setThrows: true }]) {
        const app = boot(options);
        assert.equal(app.store.getState().identity.displayName, "");
        app.store.update({ identity: { displayName: "In memory" } });
        await app.drain();
        assert.equal(app.store.getState().identity.displayName, "In memory");
    }
});

test("profile reconciliation rejects ties, older records, and crossed project/context records", () => {
    const app = boot({ stored: record("Local", 4, "2026-02-01T00:00:00.000Z") });
    const candidates = [
        { version: 2, revision: 4, savedAt: "2026-02-01T00:00:00.000Z", profile: { identity: { displayName: "Tie" } } },
        { version: 2, revision: 3, savedAt: "2027-01-01T00:00:00.000Z", profile: { identity: { displayName: "Older" } } },
        { version: 2, revision: 9, projectId: "project-beta", profile: { identity: { displayName: "Wrong project" } } },
        { version: 2, revision: 9, workContextId: "cloud-beta", profile: { identity: { displayName: "Wrong context" } } }
    ];
    candidates.forEach((candidate) => app.store.reconcile(candidate));
    assert.equal(app.store.getState().identity.displayName, "Local");
    app.store.reconcile({ version: 2, revision: 5, savedAt: "2026-03-01T00:00:00.000Z", workContextId: "cloud-alpha", projectId: "project-alpha", profile: { identity: { displayName: "Newer" } } });
    assert.equal(app.store.getState().identity.displayName, "Newer");
});

test("newer stored data is rebased with pending local edits instead of discarding them", async () => {
    const app = boot({ stored: record("Initial", 2) });
    app.store.update({ identity: { displayName: "Pending local" } });
    app.values.set(app.key, JSON.stringify({
        version: 2,
        revision: 8,
        savedAt: "2026-04-01T00:00:00.000Z",
        profile: { identity: { displayName: "Newer tab" }, audience: "Remote audience" }
    }));
    await app.drain();
    assert.equal(app.store.getState().identity.displayName, "Pending local");
    assert.equal(app.store.getState().audience, "Remote audience");
    assert.equal(JSON.parse(app.values.get(app.key)).revision, 9);
});

test("newer stored data wins when there are no pending local edits", () => {
    const app = boot({ stored: record("Initial", 2) });
    app.values.set(app.key, record("Newer tab", 8, "2026-04-01T00:00:00.000Z"));
    app.store.flush();
    assert.equal(app.store.getState().identity.displayName, "Newer tab");
    assert.equal(JSON.parse(app.values.get(app.key)).revision, 8);
});

test("failed remote save keeps local state and a later edit retries successfully", async () => {
    let puts = 0;
    const app = boot({
        stored: record("Initial"),
        fetchImpl: async (_url, options = {}) => {
            if (options.method === "PUT") {
                puts += 1;
                if (puts === 1) throw new Error("offline");
                return { ok: true, status: 200, json: async () => ({ profile: { revision: 3 } }) };
            }
            return { ok: true, status: 200, json: async () => ({}) };
        }
    });
    app.store.update({ identity: { displayName: "First edit" } });
    await app.drain();
    assert.equal(app.store.getState().identity.displayName, "First edit");
    app.store.update({ identity: { displayName: "Second edit" } });
    await app.drain();
    assert.equal(puts, 2);
    assert.equal(app.store.getState().identity.displayName, "Second edit");
});

test("a remote response arriving after a scope switch is ignored", async () => {
    let resolveRemote;
    const remote = new Promise((resolve) => { resolveRemote = resolve; });
    const app = boot({
        stored: record("Alpha"),
        fetchImpl: async () => remote
    });
    app.current.id = "beta";
    app.current.cloudId = "cloud-beta";
    app.values.set("morrow-business-profile-v1::client:beta", record("Beta", 2));
    app.store.hydrate("switch");
    resolveRemote({ ok: true, status: 200, json: async () => ({ profile: { version: 2, revision: 99, workContextId: "cloud-alpha", profile: { identity: { displayName: "Stale Alpha" } } } }) });
    await Promise.resolve();
    await Promise.resolve();
    assert.equal(app.store.getState().identity.displayName, "Beta");
});

test("unsupported schemas and equal-revision older timestamps cannot replace local state", () => {
    const app = boot({ stored: record("Local", 7, "2026-06-01T00:00:00.000Z") });
    app.store.reconcile({ version: 99, revision: 100, savedAt: "2030-01-01T00:00:00.000Z", profile: { identity: { displayName: "Future" } } });
    app.store.reconcile({ version: 2, revision: 7, savedAt: "2026-05-01T00:00:00.000Z", profile: { identity: { displayName: "Older timestamp" } } });
    assert.equal(app.store.getState().identity.displayName, "Local");

    app.store.reconcile({ version: 2, revision: 7, savedAt: "2026-07-01T00:00:00.000Z", profile: { identity: { displayName: "Newer timestamp" } } });
    assert.equal(app.store.getState().identity.displayName, "Newer timestamp");
});

test("HTTP 409 reloads the remote revision and retries without discarding pending edits", async () => {
    let puts = 0;
    let gets = 0;
    const app = boot({
        stored: record("Local", 2),
        fetchImpl: async (_url, options = {}) => {
            if (options.method === "PUT") {
                puts += 1;
                if (puts === 1) return { ok: false, status: 409, json: async () => ({ error: "conflict" }) };
                return { ok: true, status: 200, json: async () => ({ profile: { revision: 10 } }) };
            }
            gets += 1;
            return { ok: true, status: 200, json: async () => ({ profile: {
                version: 2, revision: 9, savedAt: "2026-08-01T00:00:00.000Z",
                projectId: "project-alpha", workContextId: "cloud-alpha",
                profile: { identity: { displayName: "Cloud" }, audience: "Cloud audience" }
            } }) };
        }
    });

    app.store.update({ identity: { displayName: "Pending local" } });
    await app.drain();
    await Promise.resolve();
    await app.drain();

    assert.ok(gets >= 1);
    assert.equal(puts, 2);
    assert.equal(app.store.getState().identity.displayName, "Pending local");
    assert.equal(app.store.getState().audience, "Cloud audience");
});

test("failed conflict reload retains the pending local profile for a later edit", async () => {
    let puts = 0;
    const app = boot({
        stored: record("Local", 2),
        fetchImpl: async (_url, options = {}) => {
            if (options.method === "PUT") {
                puts += 1;
                return puts === 1
                    ? { ok: false, status: 409, json: async () => ({}) }
                    : { ok: true, status: 200, json: async () => ({ profile: { revision: 5 } }) };
            }
            throw new Error("reload offline");
        }
    });
    app.store.update({ identity: { displayName: "Pending survives" } });
    await app.drain();
    assert.equal(app.store.getState().identity.displayName, "Pending survives");

    app.store.update({ audience: "Later edit" });
    await app.drain();
    assert.equal(puts, 2);
    assert.equal(app.store.getState().identity.displayName, "Pending survives");
    assert.equal(app.store.getState().audience, "Later edit");
});
