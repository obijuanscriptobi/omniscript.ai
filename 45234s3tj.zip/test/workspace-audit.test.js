"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { auditProject, resolveLocalReference } = require("../workspace-audit.js");

test("shared audit resolves nested and query-bearing references", () => {
    assert.equal(resolveLocalReference("pages/contact.html", "../style.css?v=2"), "style.css");
    assert.equal(resolveLocalReference("index.html", "/assets/logo.svg#mark"), "assets/logo.svg");
});

test("shared audit reports each missing local target once", () => {
    const report = auditProject({
        "index.html": "<!doctype html><html lang=\"en\"><head><title>Home</title></head><body><h1>Home</h1><img alt=\"Logo\" src=\"missing.svg\"><a href=\"missing.svg\">More</a></body></html>"
    });
    const matches = report.blocking.filter((issue) => issue.code === "MISSING_LOCAL_REFERENCE");
    assert.equal(matches.length, 1);
    assert.equal(matches[0].target, "missing.svg");
});

test("shared audit catches duplicate ids, unnamed controls, and invalid JSON-LD", () => {
    const report = auditProject({
        "index.html": "<!doctype html><html lang=\"en\"><head><title>Home</title><meta name=\"description\" content=\"A page\"><script type=\"application/ld+json\">{bad}</script></head><body><h1>Home</h1><input id=\"same\"><input id=\"same\"></body></html>"
    });
    const codes = report.blocking.map((issue) => issue.code);
    assert.ok(codes.includes("DUPLICATE_ID"));
    assert.ok(codes.includes("FORM_CONTROL_UNNAMED"));
    assert.ok(codes.includes("INVALID_STRUCTURED_DATA"));
});

test("shared audit accepts nested labels and hidden honeypots", () => {
    const report = auditProject({
        "index.html": "<!doctype html><html lang=\"en\"><head><title>Home</title><meta name=\"description\" content=\"A page\"></head><body><h1>Home</h1><label>Consent <input id=\"consent\" type=\"checkbox\"></label><input name=\"website\" aria-hidden=\"true\"></body></html>"
    });
    assert.doesNotMatch(report.blocking.map((issue) => issue.code).join("\\n"), /FORM_CONTROL_UNNAMED/);
});

test("audit findings include actionable canonical fields", () => {
    const report = auditProject({
        "index.html": "<!doctype html><html><head><title>x</title></head><body><h1>x</h1><img src=\"missing.png\"></body></html>"
    });
    const finding = report.issues.find((item) => item.code === "MISSING_LOCAL_REFERENCE");
    assert.ok(finding);
    assert.equal(typeof finding.location.line, "number");
    assert.equal(finding.fix.type, "open-file");
});
