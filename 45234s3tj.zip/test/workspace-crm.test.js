"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "workspace-crm.js"), "utf8");

test("CRM normalizes lead status and attribution", () => {
    const context = { window: {}, localStorage: { getItem: () => "[]", setItem: () => {} }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.normalizeLead({ name: " Sam ", status: "unknown", source: "campaign-a" });
    assert.equal(lead.name, "Sam");
    assert.equal(lead.status, "new");
    assert.equal(lead.source, "campaign-a");
});

test("CRM export escapes CSV values", () => {
    let saved = "[]";
    const context = { window: {}, localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    context.window.workspaceCRM.add({ name: 'A "quoted" lead', email: "a@example.com" });
    assert.match(context.window.workspaceCRM.exportCsv(), /"A ""quoted"" lead"/);
});

test("CRM builds a plain-English sales report from audit findings", () => {
    const context = { window: {}, localStorage: { getItem: () => "[]", setItem: () => {} }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const report = context.window.workspaceCRM.buildSalesReport({ company: "Northstar", audit: { mobileScore: 61, issues: ["the call button is hard to find", "the first screen loads slowly"] } });
    assert.equal(report.score, 61);
    assert.equal(report.findings[0].priority, "high");
    assert.match(report.findings[0].impact, /Northstar/);
    assert.ok(report.findings[0].recommendation);
});

test("CRM builds fixed-scope offers and saves them to the proposal", () => {
    let saved = "[]";
    const context = { window: {}, localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "offer-lead", company: "Northstar" })[0];
    const offer = context.window.workspaceCRM.buildOffer(lead, "quick_fix", ["hosting_maintenance"]);
    assert.equal(offer.packageName, "Quick Fix");
    assert.equal(offer.price, 750);
    assert.equal(offer.recurringTotal, 150);
    const updated = context.window.workspaceCRM.saveOffer(lead.id, "quick_fix", ["hosting_maintenance"]).find((item) => item.id === lead.id);
    assert.equal(updated.proposal.total, 750);
    assert.equal(updated.offer.packageKey, "quick_fix");
    assert.match(updated.opportunity.priceRange, /750/);
});

test("CRM previews can be shared, tracked, and revoked without a second lead record", () => {
    let saved = "[]";
    const context = { window: {}, localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "preview-lead", company: "Northstar", opportunity: { recommendations: ["Move the call button into the mobile header"] } })[0];
    const preview = context.window.workspaceCRM.createPreview(lead.id, { url: "https://preview.example.com/northstar" });
    assert.equal(preview.status, "shared");
    assert.equal(preview.url, "https://preview.example.com/northstar");
    assert.ok(preview.token);
    assert.equal(preview.offerName, "Mobile conversion improvement package");
    assert.match(preview.impact, /easier/);
    context.window.workspaceCRM.trackPreview(lead.id, "viewed");
    assert.equal(context.window.workspaceCRM.read()[0].preview.status, "viewed");
    context.window.workspaceCRM.trackPreview(lead.id, "cta-proposal");
    assert.equal(context.window.workspaceCRM.read()[0].status, "proposal");
    context.window.workspaceCRM.revokePreview(lead.id);
    assert.equal(context.window.workspaceCRM.read()[0].preview.status, "revoked");
});

test("CRM cloud updates expose pending and retryable failure states", async () => {
    let saved = "[]";
    const events = [];
    const context = {
        window: {
            workspaceAPI: { getState: () => ({ projectId: "project-1" }) },
            supabaseWorkspace: { getState: () => ({ authenticated: true }) },
            workspaceContext: { current: () => ({ cloudId: "00000000-0000-4000-8000-000000000010" }) },
            dispatchEvent: (event) => events.push(event.detail)
        },
        localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } },
        fetch: async () => ({ ok: false, status: 503, json: async () => ({ error: "Temporarily unavailable." }) }),
        CustomEvent: function (name, init) { this.type = name; this.detail = init.detail; }
    };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "lead-1", name: "Sam" })[0];
    context.window.workspaceCRM.updateWithCloud(lead.id, { status: "contacted" });
    await new Promise((resolve) => setTimeout(resolve, 0));
    assert.deepEqual(events.map((event) => event.state), ["pending", "failed"]);
    assert.equal(events[1].retryable, true);
    assert.equal(context.window.workspaceCRM.read()[0].status, "contacted");
});

test("CRM retry reuses the locally saved lead", async () => {
    let saved = "[]";
    const events = [];
    const context = {
        window: {
            workspaceAPI: { getState: () => ({ projectId: "project-1" }) },
            supabaseWorkspace: { getState: () => ({ authenticated: true }) },
            workspaceContext: { current: () => ({ cloudId: "00000000-0000-4000-8000-000000000010" }) },
            dispatchEvent: (event) => events.push(event.detail)
        },
        localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } },
        fetch: async (_, options) => ({ ok: options.method === "PATCH", status: 200, json: async () => ({}) }),
        CustomEvent: function (name, init) { this.type = name; this.detail = init.detail; }
    };
    vm.runInNewContext(source, context);
    context.window.workspaceCRM.add({ id: "lead-2", name: "Taylor", status: "contacted", notes: "Call tomorrow" });
    context.window.workspaceCRM.retryWithCloud("lead-2");
    await new Promise((resolve) => setTimeout(resolve, 0));
    assert.deepEqual(events.map((event) => event.state), ["pending", "synced"]);
});

test("discovery booking is durable, qualified, and protected from duplicates", () => {
    let saved = "[]";
    const context = { window: {}, localStorage: { getItem: (key) => key === "morrow-lead-inbox-v1" ? saved : context.appointments || "[]", setItem: (key, value) => { if (key === "morrow-lead-inbox-v1") saved = value; else context.appointments = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "lead-book", email: "a@example.com", websiteUrl: "https://example.com", audit: { mobileScore: 82 } })[0];
    const time = new Date(Date.now() + 86400000).toISOString();
    const appointment = context.window.workspaceCRM.bookDiscovery(lead.id, { email: lead.email, scheduledAt: time });
    assert.equal(appointment.leadId, lead.id);
    assert.equal(context.window.workspaceCRM.read()[0].meeting.status, "booked");
    assert.equal(context.window.workspaceCRM.read()[0].meeting.externalId, appointment.id);
    assert.equal(context.window.workspaceCRM.read()[0].status, "discovery");
    assert.equal(context.window.workspaceCRM.bookDiscovery(lead.id, { email: lead.email, scheduledAt: time }), null);
});

test("failed cloud appointment creation is durable and retries idempotently", async () => {
    let leads = "[]";
    let appointments = "[]";
    let calls = 0;
    const context = {
        window: {
            workspaceAPI: { getState: () => ({ projectId: "00000000-0000-4000-8000-000000000000" }) },
            supabaseWorkspace: { getState: () => ({ authenticated: true }), getAccessToken: () => "token" },
            workspaceContext: { current: () => ({ cloudId: "00000000-0000-4000-8000-000000000010" }) },
            dispatchEvent: () => {}
        },
        localStorage: { getItem: (key) => key === "morrow-lead-inbox-v1" ? leads : appointments, setItem: (key, value) => { if (key === "morrow-lead-inbox-v1") leads = value; else appointments = value; } },
        fetch: async (_, options) => {
            calls += 1;
            if (calls === 1) return { ok: false, status: 503, json: async () => ({ error: "offline" }) };
            return { ok: true, status: 200, json: async () => ({ appointment: { id: "00000000-0000-4000-8000-000000000001", status: "scheduled", meeting_at: new Date(Date.now() + 86400000).toISOString() } }) };
        },
        CustomEvent: function (_, init) { this.detail = init?.detail; }
    };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "local-lead", cloudId: "00000000-0000-4000-8000-000000000002", email: "sync@example.com" })[0];
    const appointment = await context.window.workspaceCRM.bookDiscoveryWithCloud(lead.id, { email: lead.email, scheduledAt: new Date(Date.now() + 86400000).toISOString() });
    assert.equal(appointment.syncStatus, "pending");
    assert.equal(context.window.workspaceCRM.readAppointments()[0].syncStatus, "pending");
    await context.window.workspaceCRM.retryPendingAppointments();
    const synced = context.window.workspaceCRM.readAppointments()[0];
    assert.equal(synced.syncStatus, "synced");
    assert.equal(synced.id, "00000000-0000-4000-8000-000000000001");
    assert.equal(calls, 2);
    await context.window.workspaceCRM.retryPendingAppointments();
    assert.equal(calls, 2);
});

test("meeting changes update CRM state and terminal appointments stay terminal", () => {
    let saved = "[]";
    const context = { window: {}, appointments: "[]", localStorage: { getItem: (key) => key === "morrow-lead-inbox-v1" ? saved : context.appointments, setItem: (key, value) => { if (key === "morrow-lead-inbox-v1") saved = value; else context.appointments = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "lead-state", email: "b@example.com" })[0];
    const time = new Date(Date.now() + 86400000).toISOString();
    const appointment = context.window.workspaceCRM.bookDiscovery(lead.id, { email: lead.email, scheduledAt: time });
    const rescheduledAt = new Date(Date.now() + 172800000).toISOString();
    context.window.workspaceCRM.updateAppointment(appointment.id, { meetingAt: rescheduledAt });
    assert.equal(context.window.workspaceCRM.read()[0].meeting.scheduledAt, rescheduledAt);
    context.window.workspaceCRM.updateAppointment(appointment.id, { status: "cancelled" });
    assert.equal(context.window.workspaceCRM.read()[0].meeting.status, "cancelled");
    assert.equal(context.window.workspaceCRM.bookDiscovery(lead.id, { email: lead.email, scheduledAt: time }), null);
});

test("proposal delivery creates an approval link and acceptance starts handoff", () => {
    let saved = "[]";
    const context = { window: { location: { origin: "https://app.example.com" } }, localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.add({ id: "proposal-lead", company: "Northstar", proposal: { total: 1800, status: "draft" } })[0];
    const delivered = context.window.workspaceCRM.deliverProposal(lead.id);
    assert.equal(delivered.status, "sent");
    assert.ok(delivered.approvalToken);
    assert.match(delivered.approvalUrl, /proposal.html\\?token=/);
    const viewed = context.window.workspaceCRM.updateProposalResponse(lead.id, "viewed");
    assert.equal(viewed.status, "viewed");
    const accepted = context.window.workspaceCRM.updateProposalResponse(lead.id, "accepted");
    assert.equal(accepted.status, "accepted");
    const updated = context.window.workspaceCRM.read()[0];
    assert.equal(updated.status, "won");
    assert.ok(updated.handoffAt);
    assert.equal(updated.nextAction.title, "Start project handoff");
});

test("queued audits remain explicitly queued and proposal delivery timestamps are tracked", () => {
    let saved = "[]";
    const context = { window: {}, localStorage: { getItem: () => saved, setItem: (_, value) => { saved = value; } }, CustomEvent: function () {} };
    vm.runInNewContext(source, context);
    const lead = context.window.workspaceCRM.addAuditLead({ email: "queued@example.com", websiteUrl: "https://example.com", audit: { queued: true, mobileScore: null } })[0];
    assert.equal(lead.audit.queued, true);
    assert.match(lead.notes, /queued/i);
    context.window.workspaceCRM.saveProposal(lead.id, { status: "draft", version: 1 });
    context.window.workspaceCRM.saveProposal(lead.id, { status: "sent" });
    const updated = context.window.workspaceCRM.saveProposal(lead.id, { status: "viewed" }).find((item) => item.id === lead.id);
    assert.ok(updated.proposal.sentAt);
    assert.ok(updated.proposal.viewedAt);
    assert.ok(updated.proposal.revisionHistory.length >= 3);
});
