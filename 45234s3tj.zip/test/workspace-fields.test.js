"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const source = fs.readFileSync(path.join(__dirname, "..", "workspace-fields.js"), "utf8");
const script = fs.readFileSync(path.join(__dirname, "..", "script.js"), "utf8");
const loader = fs.readFileSync(path.join(__dirname, "..", "app-loader.js"), "utf8");

test("shared workspace field module owns restore mappings", () => {
    assert.match(source, /window\.workspaceFields/);
    assert.match(source, /input-biz-name/);
    assert.match(source, /input-privacy-retention/);
    assert.match(source, /function apply\(snapshot = \{\}\)/);
});

test("script delegates field restoration to the shared model without a duplicate fallback", () => {
    assert.match(script, /window\.workspaceFields\.getValues/);
    assert.match(script, /window\.workspaceFields\.apply/);
    assert.doesNotMatch(script, /const FORM_FIELD_IDS/);
    assert.doesNotMatch(script, /const businessKeys/);
    assert.doesNotMatch(script, /workspaceFields\?\.getValues/);
    assert.doesNotMatch(script, /workspaceFields\?\.apply/);
});

test("the loader loads the shared field model before script.js", () => {
    const fieldsIndex = loader.indexOf('"workspace-fields.js"');
    const scriptIndex = loader.indexOf('"script.js"');
    assert.ok(fieldsIndex >= 0 && scriptIndex >= 0 && fieldsIndex < scriptIndex);
    assert.match(loader, /for \(const source of sources\)/);
    assert.match(loader, /loadParallelList/);
    assert.match(loader, /Promise\.all\(sources\.map\(\(source\) => load\(source\)\)\)/);
});

test("loader recovery remains visible without a specific status wrapper", () => {
    assert.match(loader, /document\.querySelector\("\\.system-pulse-wrapper"\)/);
    assert.match(loader, /document\.body/);
});

test("shared field schema also owns live business and form reads", () => {
    assert.match(source, /function readBusiness\(normalizeUrl/);
    assert.match(source, /function readFormSettings\(\)/);
    assert.match(source, /readBusiness, readFormSettings/);
    assert.match(script, /window\.workspaceFields\.readBusiness/);
    assert.match(script, /window\.workspaceFields\.readFormSettings/);
});

test("loader documents and implements safe dependency batches", () => {
    assert.match(loader, /Dependency policy/);
    assert.match(loader, /loadParallelList/);
    assert.match(loader, /Promise\.all\(sources\.map\(\(source\) => load\(source\)\)\)/);
    assert.match(loader, /loadList\(foundation/);
    assert.match(loader, /loadParallelList\(quality/);
});
