"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("generator facade delegates to the canonical generator", () => {
    const context = {
        window: {
            siteGenerator: {
                createProject: (options) => ({ "index.html": options?.marker || "generated" })
            }
        }
    };
    vm.runInNewContext(read("workspace-generator.js"), context);
    const generator = context.window.workspaceGenerator;
    assert.equal(generator.isAvailable(), true);
    assert.deepEqual(generator.createProject({ marker: "ok" }), { "index.html": "ok" });
});

test("generation uses an immutable canonical profile without mounted form controls", () => {
    let received;
    const profile = {
        identity: { displayName: "Profile Only", phoneDisplay: "+1 (555) 123-4567 ext 9", phoneDial: "+15551234567", phoneExtension: "9", email: "hello@example.com" },
        services: ["Design", "Strategy"], locations: [{ city: "Austin", address: "1 Main St" }], audience: "Owners", primaryGoal: "quote", differentiator: "Senior team", availability: "By appointment",
        messaging: { hook: "Clear outcomes", cta: "Request a quote", responseTime: "One day", voice: "Direct" },
        proof: {}, links: {}, brand: {}, claimGuidance: {}, design: {}, privacy: {}, form: {}
    };
    const context = { window: {
        websiteMakerProfileStore: { getState: () => JSON.parse(JSON.stringify(profile)) },
        siteGenerator: { createProject: (business) => { received = business; return { "index.html": "generated" }; } }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    const files = context.window.workspaceGenerator.createProject();
    assert.equal(files["index.html"], "generated");
    assert.equal(received.name, "Profile Only");
    assert.equal(received.services, "Design, Strategy");
    assert.equal(received.phoneDial, "+15551234567");
    assert.equal(received.address, "1 Main St");
    assert.equal(typeof context.document, "undefined");
});

test("AI generation also receives an immutable canonical profile", async () => {
    let received;
    const profile = { identity: { displayName: "Canonical" }, services: [], locations: [{}] };
    const context = { window: {
        websiteMakerProfileStore: { getState: () => profile },
        workspaceAI: { generate: async (options) => { received = options; return { success: true, files: {} }; } }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    await context.window.workspaceGenerator.createAIProject();
    assert.equal(received.business.name, "Canonical");
    assert.equal(Object.isFrozen(received.profile), true);
});

test("AI repair receives an immutable canonical profile without DOM controls", async () => {
    let received;
    const context = { window: {
        websiteMakerProfileStore: { getState: () => ({ identity: { displayName: "Repair Profile" }, services: ["Repair"], locations: [{}] }) },
        workspaceAI: { repair: async (...args) => { received = args; return { success: true, files: args[0] }; } }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    await context.window.workspaceGenerator.repairAIProject({ "index.html": "draft" }, ["issue"]);
    assert.equal(received[2].business.name, "Repair Profile");
    assert.equal(Object.isFrozen(received[2].profile), true);
    assert.equal(typeof context.document, "undefined");
});

test("AI repair falls back deterministically and preserves caller-owned files", async () => {
    const files = { "index.html": "draft" };
    const context = { window: {
        websiteMakerProfileStore: { getState: () => ({ identity: { displayName: "Fallback Repair" }, services: [], locations: [{}] }) },
        workspaceAI: { repair: async (input) => { input["index.html"] = "AI mutation"; throw new Error("AI offline"); } },
        workspaceDeterministicRepair: { repair: (input) => ({ files: { ...input, "index.html": "deterministically repaired" }, audit: [{ code: "SAFE_FIX" }] }) }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    const result = await context.window.workspaceGenerator.repairAIProject(files, ["issue"]);
    assert.equal(result.provider, "deterministic");
    assert.equal(result.files["index.html"], "deterministically repaired");
    assert.equal(files["index.html"], "draft");
    assert.equal(result.fallbackReason, "AI offline");
});

test("caller options cannot override canonical profile facts and nested profile data is frozen", async () => {
    let received;
    const profile = {
        identity: { displayName: "Canonical Name" },
        services: ["Canonical Service"], locations: [{ city: "Canonical City" }],
        brand: { gallery: ["https://example.com/image.jpg"] }
    };
    const context = { window: {
        websiteMakerProfileStore: { getState: () => profile },
        workspaceAI: { generate: async (options) => { received = options; return { success: true, files: {} }; } }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    await context.window.workspaceGenerator.createAIProject({ business: { name: "Injected Name", services: "Injected Service" } });
    assert.equal(received.business.name, "Canonical Name");
    assert.equal(received.business.services, "Canonical Service");
    assert.equal(Object.isFrozen(received.profile.identity), true);
    assert.equal(Object.isFrozen(received.profile.services), true);
    assert.equal(Object.isFrozen(received.profile.locations[0]), true);
    assert.equal(Object.isFrozen(received.profile.brand.gallery), true);
});

test("focused regeneration uses a cloned profile and cannot mutate store state", () => {
    const profile = { identity: { displayName: "Regeneration Profile" }, services: ["Design"], locations: [{}] };
    let received;
    const context = { window: {
        websiteMakerProfileStore: { getState: () => profile },
        workspaceRegeneration: { normalizeControls: (value) => Object.freeze({ ...value }) },
        siteGenerator: { createProject: (business) => { received = business; business.name = "Attempted mutation"; return { "index.html": "generated" }; } }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    const files = context.window.workspaceGenerator.regenerateProject({}, { mode: "design" });
    assert.equal(files["index.html"], "generated");
    assert.equal(received.name, "Attempted mutation");
    assert.equal(profile.identity.displayName, "Regeneration Profile");
    assert.equal(typeof context.document, "undefined");
});

test("AI orchestration falls back through the deterministic canonical boundary", async () => {
    let fallbackInput;
    const context = {
        window: {
            setTimeout: () => 1,
            clearTimeout() {},
            addEventListener() {},
            dispatchEvent() {},
            workspaceGenerator: {
                createModelRequest: (value) => value,
                createProject: (value) => { fallbackInput = value; return { "index.html": "fallback" }; }
            }
        },
        fetch: async () => ({ ok: false, status: 503, json: async () => ({ error: "offline" }) }),
        AbortController, CustomEvent: class { constructor(type, init = {}) { this.type = type; this.detail = init.detail; } },
        console
    };
    vm.runInNewContext(read("workspace-ai.js"), context);
    const result = await context.window.workspaceAI.generate({ profile: Object.freeze({ identity: Object.freeze({ displayName: "Fallback" }) }) });
    assert.equal(result.provider, "deterministic");
    assert.equal(result.files["index.html"], "fallback");
    assert.equal(fallbackInput.profile.identity.displayName, "Fallback");
});

test("curated catalog selects stable systems and component recipes", () => {
    const context = { window: {} };
    vm.runInNewContext(read("design-system-catalog.js"), context);
    const catalog = context.window.workspaceDesignSystems;
    const selected = catalog.select({ business: { type: "wellness" }, design: {} });
    assert.equal(selected.id, "warm");
    assert.equal(selected.recipe.includes("contact-form"), true);
    const prepared = catalog.prepareBrief({ business: { type: "professional", name: "Example" }, design: { density: "airy" } });
    assert.equal(prepared.business.style, "premium");
    assert.equal(prepared.design.system, "premium");
    assert.equal(prepared.design.foundationRules.some((rule) => /exactly one h1/i.test(rule)), true);
});

test("design genome is reproducible, varied, and similarity-aware", () => {
    const genome = require("../design-genome.js");
    const first = genome.create({ projectId: "alpha", variationId: "one", business: { type: "retail" } });
    const replay = genome.create({ projectId: "alpha", variationId: "one", business: { type: "retail" } });
    const second = genome.create({ projectId: "alpha", variationId: "two", business: { type: "retail" } });
    assert.deepEqual(first, replay);
    assert.equal(first.fingerprint, replay.fingerprint);
    assert.notEqual(first.fingerprint, second.fingerprint);
    assert.equal(genome.similarity(first, replay), 1);
});

test("originality gate compares structure, style, and rendered visual features", () => {
    const genome = require("../design-genome.js");
    const originality = require("../originality-gate.js");
    const components = require("../website-component-registry.js");
    const facts = components.normalizeFacts({ business: { name: "Original", services: ["Design"] } });
    const design = { system: "modern", profile: "swiss-grid", genome: genome.create({ projectId: "p", variationId: "v" }).genome };
    const plan = components.defaultPlan(facts, design);
    const pixels = { width: 2, height: 2, data: new Uint8ClampedArray([0, 0, 0, 255, 255, 255, 255, 255, 20, 20, 20, 255, 240, 240, 240, 255]) };
    const visual = originality.visualFingerprint(pixels);
    const fingerprint = originality.fingerprint(plan, design, visual, components);
    const comparison = originality.compare(fingerprint, fingerprint);
    assert.equal(comparison.overall, 1);
    assert.equal(comparison.visual, 1);
    assert.equal(fingerprint.structural.heroFamily.startsWith("hero-"), true);
});

test("originality selection caps retries and reports rejected similarities", () => {
    const genome = require("../design-genome.js");
    const originality = require("../originality-gate.js");
    const components = require("../website-component-registry.js");
    const facts = components.normalizeFacts({ business: { name: "Repeat", services: ["Design"] } });
    const input = { projectId: "repeat", variationId: "fixed", business: { name: "Repeat" }, design: {} };
    const first = originality.select(input, (design) => components.defaultPlan(facts, design), { genomeEngine: genome, components, recent: [] });
    const second = originality.select(input, (design) => components.defaultPlan(facts, design), { genomeEngine: genome, components, recent: [{ variationId: first.variationId, fingerprint: first.fingerprint }], threshold: .5, maxAttempts: 2 });
    assert.ok(second.attempts <= 2);
    assert.equal(Array.isArray(second.reselections), true);
});

test("focused regeneration preserves copy and supports checkpoints", () => {
    const regeneration = require("../workspace-regeneration.js");
    const components = require("../website-component-registry.js");
    const facts = components.normalizeFacts({ business: { name: "Example", services: ["Repairs"] } });
    const previous = components.defaultPlan(facts, { system: "modern", genome: { hero: "centered-statement" } });
    const next = components.defaultPlan(facts, { system: "bold", genome: { hero: "stacked-poster" } });
    const controls = regeneration.normalizeControls({ mode: "design", preserveCopy: true, lockClaims: true });
    const merged = regeneration.mergePlan(previous, next, controls, components);
    assert.equal(merged.sections[1].content.heading, previous.sections[1].content.heading);
    assert.notEqual(merged.sections[1].component, previous.sections[1].component);
    const request = regeneration.request({ variationId: "v1", plan: previous, design: {}, factIds: ["service-1"] }, controls);
    assert.equal(request.immutable.factIds[0], "service-1");
    assert.match(request.instruction, /Never return HTML/);
});

test("principle library retrieves abstract conversion guidance", () => {
    const library = require("../design-principles-library.js");
    const selected = library.select({ goal: "booking", categories: ["mobile"] }, 3);
    assert.equal(selected.length, 3);
    assert.equal(selected.some((item) => item.id === "booking-progressive-commitment"), true);
    assert.equal(JSON.stringify(selected).includes("<html"), false);
});

test("component registry normalizes evidence and assembles validated plans", () => {
    const components = require("../website-component-registry.js");
    const facts = components.normalizeFacts({ business: { name: "Example", type: "professional", services: ["Advisory"] } });
    const plan = components.defaultPlan(facts, { system: "premium" });
    assert.equal(components.validatePlan(plan, { facts }).valid, true);
    const files = components.assembleProject(plan, facts);
    assert.match(files["index.html"], /<h1>/);
    assert.match(files["index.html"], /action="\/api\/submit-form"/);
    assert.equal(files["index.html"].includes("testimonial-grid-v1"), false);
    assert.throws(() => components.sanitizePlan({ ...plan, sections: [...plan.sections, { component: "testimonial-grid-v1", content: { heading: "Claims" } }] }, { facts }), /MODEL_PAGE_PLAN_INVALID/);
});

test("deterministic repairs are mechanical and auditable", () => {
    const repair = require("../deterministic-repair.js");
    const result = repair.repair({
        "index.html": '<!doctype html><html><body><div id="same"></div><div id="same"></div><a href="https://example.com">External</a><img src="photo.jpg"><form action="https://evil.example"></form></body></html>',
        "style.css": "body{margin:0}"
    });
    assert.match(result.files["index.html"], /id="same-2"/);
    assert.match(result.files["index.html"], /noopener noreferrer/);
    assert.match(result.files["index.html"], /width="800" height="600" loading="lazy"/);
    assert.match(result.files["index.html"], /action="\/api\/submit-form"/);
    assert.match(result.files["style.css"], /prefers-reduced-motion/);
    assert.equal(result.audit.every((entry) => entry.code && entry.file && entry.before !== entry.after), true);
});

test("component registry exposes metadata, compatibility, and claim provenance", () => {
    const components = require("../website-component-registry.js");
    const facts = components.normalizeFacts({ business: { name: "Example", services: ["Repairs"], statistics: [{ name: "Projects", value: "20" }] } });
    const definition = components.COMPONENTS["navigation-simple-v1"];
    assert.equal(Array.isArray(definition.accessibilityChecks), true);
    assert.equal(Number.isFinite(definition.performanceCost), true);
    const plan = components.defaultPlan(facts, { system: "modern" });
    const provenance = components.claimProvenance(plan, facts);
    assert.equal(provenance.some((entry) => entry.factId === "service-1" && entry.fact?.source === "business-facts"), true);
});

test("generator validation returns a revisioned compiler result", () => {
    const context = { window: {
        workspaceDomain: {
            compile: (files) => ({ valid: true, revision: "abcd1234", manifest: { "index.html": { bytes: String(files["index.html"]).length, hash: "hash" } } })
        },
        workspaceAudit: { auditProject: () => ({ blocking: [], warnings: [], issues: [] }) }
    } };
    vm.runInNewContext(read("workspace-generator.js"), context);
    const result = context.window.workspaceGenerator.validateProject({ "index.html": "<!doctype html>" });
    assert.equal(result.valid, true);
    assert.equal(result.revision, "abcd1234");
    assert.deepEqual(result.limitations, ["Static source validation is not rendered browser coverage."]);
});

test("generator facade reports unavailable generators clearly", () => {
    const context = { window: {} };
    vm.runInNewContext(read("workspace-generator.js"), context);
    assert.equal(context.window.workspaceGenerator.isAvailable(), false);
    assert.throws(() => context.window.workspaceGenerator.createProject(), /canonical site generator is unavailable/i);
});

test("generator facade loads after the canonical generator and before the editor runtime", () => {
    const loader = read("app-loader.js");
    assert.ok(loader.indexOf('"generated-quality.js"') < loader.indexOf('"workspace-generator.js"'));
    assert.ok(loader.indexOf('"workspace-generator.js"') < loader.indexOf('"script.js"'));
});

test("generated form messages cannot break the exported script tag", () => {
    const generator = read("generated-quality.js");
    assert.match(generator, /const scriptString = \(value\) => JSON\.stringify/);
    assert.match(generator, /scriptString\(business\.success\)/);
    assert.match(generator, /scriptString\(business\.error\)/);
});

test("canonical generator source parses as JavaScript", () => {
    const source = read("generated-quality.js");
    assert.doesNotThrow(() => new vm.Script(source), "generated-quality.js must remain parseable");
});

test("generated project templates contain balanced document and deployment boundaries", () => {
    const source = read("generated-quality.js");
    assert.equal((source.match(/`/g) || []).length % 2, 0, "template literal delimiters must be balanced");
    assert.match(source, /function generatedNetlifyConfig\(business\)/);
    assert.match(source, /function createProject\(\)/);
    assert.match(source, /\"netlify\/functions\/submit-form\.js\": generatedSubmitFunction\(\)/);
});

test("domain model validates unsupported import fidelity values", () => {
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-domain-model.js"), context);
    const model = context.window.workspaceDomain;
    const report = model.importReport({ sourceUrl: "https://example.com", fidelity: "pixel-perfect" });
    assert.equal(report.fidelity, "not-verified");
    assert.equal(model.validate("ImportReport", { ...report, fidelity: "pixel-perfect" }).valid, false);
});
