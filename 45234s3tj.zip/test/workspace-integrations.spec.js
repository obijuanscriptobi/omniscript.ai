import { test, expect } from "@playwright/test";

async function clearWorkspace(page) {
    await page.addInitScript(() => {
        try {
            localStorage.clear();
            sessionStorage.clear();
        } catch {
            // Restricted storage should not prevent the page from loading.
        }
    });
}

test.describe("workspace integration contracts", () => {
    test("Business Hub persists normalized facts and claims locally", async ({ page }) => {
        await clearWorkspace(page);
        await page.goto("/index.html", { waitUntil: "networkidle" });

        await page.locator("#input-biz-name").fill("Northstar Studio");
        await page.locator("#input-biz-hook").fill("Clearer websites for local teams");
        await page.locator("#input-biz-location").fill("Austin, TX");
        await page.locator("#input-primary-cta").fill("Start a project");
        await page.locator("#input-biz-approved-claims").fill("Licensed\nServing Austin since 2012");
        await page.waitForTimeout(350);

        await expect(page.locator("#business-hub-score")).toHaveText("100% ready");
        await expect(page.locator("#business-hub-claims li")).toHaveCount(2);

        const saved = await page.evaluate(() => JSON.parse(localStorage.getItem("morrow-business-hub-v1")));
        expect(saved.profile.name).toBe("Northstar Studio");
        expect(saved.profile.approvedClaims).toEqual(["Licensed", "Serving Austin since 2012"]);
    });

    test("CRM keeps local leads available without authenticated cloud state", async ({ page }) => {
        await clearWorkspace(page);
        await page.goto("/index.html", { waitUntil: "networkidle" });

        await page.evaluate(() => window.workspaceCRM.add({
            name: "Jordan Lee",
            email: "jordan@example.com",
            source: "website",
            campaign: "spring-launch",
            notes: "Follow up this week"
        }));

        const lead = await page.evaluate(() => window.workspaceCRM.read()[0]);
        expect(lead.name).toBe("Jordan Lee");
        expect(lead.status).toBe("new");
        expect(lead.campaign).toBe("spring-launch");
        expect(await page.evaluate(() => window.workspaceCRM.exportCsv())).toContain("spring-launch");
        expect(await page.evaluate(() => window.workspaceCRM.syncToCloud(window.workspaceCRM.read()[0]))).toBe(false);
    });

    test("website export and publish controls remain gated before a verified draft", async ({ page }) => {
        await clearWorkspace(page);
        await page.goto("/index.html", { waitUntil: "networkidle" });

        await expect(page.locator("#export-zip-btn")).toBeDisabled();
        await expect(page.locator("#publish-site-btn")).toBeDisabled();
        await expect(page.locator("#redeploy-site-btn")).toBeDisabled();
        await expect(page.locator("#rollback-site-btn")).toBeDisabled();
        await expect(page.locator("#deployment-preflight-status")).toContainText("has not run");
    });

    test("Ad Studio generates a concept and keeps campaign export behind approval", async ({ page }) => {
        await clearWorkspace(page);
        await page.goto("/ad-studio.html", { waitUntil: "networkidle" });

        await page.locator("#example-brief-btn").click();
        await page.locator("#ad-studio-generate-btn").click();
        await expect(page.locator("#variant-list .variant-card")).toHaveCount(3);

        const campaignExport = page.locator("#ad-studio-export-btn");
        const before = await page.locator("#approval-status").textContent();
        await campaignExport.click();
        await expect(page.locator("#approval-status")).not.toHaveText(before || "");

        await page.locator("#approve-btn").click();
        await expect(page.locator("#approval-status")).toContainText("Approved for export");
        const download = page.waitForEvent("download");
        await campaignExport.click();
        expect((await download).suggestedFilename()).toBe("morrow-ad-campaign.json");
    });

    test("Ad Studio copy and metadata exports produce downloads after generation", async ({ page }) => {
        await clearWorkspace(page);
        await page.goto("/ad-studio.html", { waitUntil: "networkidle" });

        await page.locator("#example-brief-btn").click();
        await page.locator("#ad-studio-generate-btn").click();

        const copyDownload = page.waitForEvent("download");
        await page.locator("#export-copy-btn").click();
        expect((await copyDownload).suggestedFilename()).toBe("morrow-ad-copy.json");

        const metadataDownload = page.waitForEvent("download");
        await page.locator("#export-metadata-btn").click();
        expect((await metadataDownload).suggestedFilename()).toBe("morrow-ad-metadata.json");
    });
});
