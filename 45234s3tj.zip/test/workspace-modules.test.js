"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("page helpers sort pages and rebuild shared navigation", () => {
    const context = { window: {} };
    vm.runInNewContext(read("workspace-pages.js"), context);
    const pages = context.window.workspacePages;
    assert.deepEqual(pages.sortPageFiles(["contact.html", "index.html", "about.html"]), ["index.html", "about.html", "contact.html"]);
    const files = pages.syncNavigation({
        "index.html": '<nav data-site-navigation aria-label="Primary navigation"><a href="#">Old</a></nav>',
        "about.html": '<nav data-site-navigation aria-label="Primary navigation"><a href="#">Old</a></nav>',
        "contact.html": "<main></main>"
    });
    assert.match(files["index.html"], /href="\.\/contact\.html"/);
    assert.match(files["about.html"], /Get in touch/);
});

test("preview helpers normalize modes and build a self-contained document", () => {
    const context = { window: {} };
    vm.runInNewContext(read("workspace-preview.js"), context);
    const preview = context.window.workspacePreview;
    assert.equal(preview.normalizeMode("unknown"), "desktop");
    assert.equal(preview.normalizeMode("mobile"), "mobile");
    const document = preview.buildDocument({
        html: '<!doctype html><html><head><link href="./style.css"></head><body><h1>Hello</h1><script src="./script.js"></script></body></html>',
        css: "h1 { color: red; }",
        script: "console.log('ok');"
    });
    assert.doesNotMatch(document, /href="\.\/style\.css"/);
    assert.doesNotMatch(document, /src="\.\/script\.js"/);
    assert.doesNotMatch(document, /href="\.\/style\.css"/);
    assert.match(document, /h1 \{ color: red; \}/);
    assert.match(document, /console\.log/);
});

test("canonical domain model validates revisions and readiness transitions", () => {
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-domain-model.js"), context);
    const model = context.window.workspaceDomain;
    const coreContext = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-core.js"), coreContext);
    const core = coreContext.window.workspaceCore;
    assert.equal(core.resolvePath("pages/contact.html", "../style.css"), "style.css");
    assert.equal(core.isExternalReference("https://example.com"), true);
    assert.equal(core.isExternalReference("./style.css"), false);
    const compiled = model.compile({ "index.html": "<html></html>", "style.css": "body{}" });
    assert.equal(compiled.valid, true);
    assert.equal(model.compile({ "index.html": { invalid: true } }).valid, false);
    assert.equal(model.compile({ " index.html": "<html></html>" }).valid, false);
    assert.equal(model.compile({ "../secret.js": "alert(1)" }).valid, false);
    assert.equal(model.validate("Project", model.project({ files: compiled.files, revision: compiled.revision })).valid, true);
    const transition = model.transition("deployment-verified", "stale-after-change", { revision: compiled.revision, source: "source-edit", actor: "user" });
    assert.equal(transition.state, "stale-after-change");
    assert.equal(transition.event.invalidates.includes("production-ready"), true);
    const finding = model.finding({ code: "MISSING_LOCAL_REFERENCE", file: "index.html", severity: "error", category: "reliability", message: "Missing file." });
    assert.equal(model.validate("AuditFinding", finding).valid, true);
});

test("shared server validation loads in the browser without Node-only dependencies", () => {
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-server-validation.js"), context);
    const browserValidation = context.window.workspaceServerValidation;
    const files = { "index.html": "<h1>Home</h1>", "netlify.toml": "[build]" };
    const serverValidation = require("../workspace-server-validation.js");
    const domainContext = { window: {}, TextEncoder };
    vm.runInNewContext(read("workspace-domain-model.js"), domainContext);
    assert.equal(browserValidation.revision(files), serverValidation.revision(files));
    assert.equal(browserValidation.revision(files), domainContext.window.workspaceDomain.revisionOf(files));
    assert.equal(browserValidation.validateFiles(files, { requireDeploymentConfig: true }).length, 0);
    assert.ok(browserValidation.validateFiles({ "../evil.js": "alert(1)" }).some((issue) => issue.code === "UNSAFE_FILE_PATH"));
});

test("planner validation has browser and server parity", () => {
    const context = { window: {}, TextEncoder };
    vm.runInNewContext(read("website-component-registry.js"), context);
    vm.runInNewContext(read("planner-contract.js"), context);
    const server = require("../planner-contract.js");
    const data = { business: { name: "Example", services: ["Repairs"] } };
    const facts = server.factsFor(data);
    const plan = require("../website-component-registry.js").defaultPlan(facts, { system: "modern" });
    assert.equal(JSON.stringify(context.window.workspacePlannerContract.validatePlan(plan, data)), JSON.stringify(server.validatePlan(plan, data)));
    const malicious = { ...plan, sections: [...plan.sections, { component: "pricing-cards-v1", content: { heading: "Guaranteed savings" } }] };
    assert.throws(() => context.window.workspacePlannerContract.validatePlan(malicious, data), /MODEL_PLAN_INVALID/);
    assert.throws(() => server.validatePlan(malicious, data), /MODEL_PLAN_INVALID/);
});

test("work context is loaded before profile and workspace state consumers", () => {
    const loader = read("app-loader.js");
    assert.ok(loader.indexOf('"operating-mode.js"') < loader.indexOf('"workspace-context.js"'));
    assert.ok(loader.indexOf('"workspace-context.js"') < loader.indexOf('"profile-service.js"'));
    assert.match(read("ad-studio.js"), /workspaceContext\?\.namespace/);
    assert.match(read("project-context.js"), /workContextId/);
    assert.match(read("workspace-crm.js"), /workspaceContext\?\.storageKey/);
    assert.match(read("todo.js"), /workspaceContext\?\.storageKey/);
    assert.match(read("leads.js"), /workspaceContext\?\.storageKey/);
});

test("loader keeps foundation, quality, startup, and optional stages explicit", () => {
    const loader = read("app-loader.js");
    assert.ok(loader.indexOf('"workspace-pages.js"') < loader.indexOf('const quality = ['));
    assert.ok(loader.indexOf('"generated-quality.js"') < loader.indexOf('const optional = ['));
    assert.match(loader, /const startup = \[/);
    assert.match(loader, /loadList\(foundation/);
    assert.match(loader, /loadParallelList\(quality/);
    assert.match(loader, /loadList\(startup/);
    assert.match(loader, /Loading \$\{source\} timed out/);
    assert.match(loader, /Some optional tools could not load/);
    assert.match(loader, /workspace:loader-error/);
    assert.match(loader, /window\.workspaceLoader/);
    assert.ok(loader.indexOf('"workspace-preview-controller.js"') < loader.indexOf('"script.js"'));
    assert.equal(loader.includes("workspace-screenshots.js"), false);
});
