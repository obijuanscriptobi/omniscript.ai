"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "workspace-preview-controller.js"), "utf8");

test("preview controller owns iframe rendering and delegates load handling", () => {
    const iframe = { srcdoc: "", title: "", style: { setProperty() {} }, removeAttribute() {} };
    const elements = {
        previewContentIframe: iframe,
        "preview-empty-state": { hidden: false },
        "preview-frame-shell": { hidden: true }
    };
    const context = {
        window: {
            addEventListener() {},
            workspacePreview: {
                previewKey: (...values) => values.join("|"),
                buildDocument: ({ html, css, script, runtime }) => `${html}${css}${script}${runtime}`
            }
        }
    };
    vm.runInNewContext(source, context);
    let loaded = 0;
    const state = {
        files: { "index.html": "<html><body><h1>Hi</h1></body></html>", "style.css": "h1{}", "script.js": "" },
        activePage: "index.html",
        previewMode: "desktop",
        previewZoom: 1,
        lastPreviewKey: ""
    };
    const controller = context.window.workspacePreviewController.create({ state, get: (id) => elements[id], onLoad: () => { loaded += 1; } });
    controller.update();
    assert.match(iframe.srcdoc, /<h1>Hi<\/h1>/);
    assert.equal(elements["preview-empty-state"].hidden, true);
    assert.equal(elements["preview-frame-shell"].hidden, false);
    iframe.onload();
    assert.equal(loaded, 1);
});
