"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

function loadQuality() {
    const context = { window: {} };
    vm.runInNewContext(read("workspace-quality-runtime.js"), context);
    return context.window.workspaceQuality;
}

test("runtime quality checks identify structural and accessibility issues", () => {
    const quality = loadQuality();
    const issues = quality.getStructuralQualityIssues(
        "<html><body><h2>Heading</h2><form><input id=\"email\"></form><button></button></body></html>",
        "body { color: #fff; background: #f5f5f5; }"
    );
    assert.ok(issues.some((issue) => /doctype/i.test(issue)));
    assert.ok(issues.some((issue) => /viewport/i.test(issue)));
    assert.ok(issues.some((issue) => /h1/i.test(issue)));
    assert.ok(issues.some((issue) => /form controls/i.test(issue)));
    assert.ok(issues.some((issue) => /accessible name/i.test(issue)));
});

test("runtime quality checks accept a complete document", () => {
    const quality = loadQuality();
    const issues = quality.getStructuralQualityIssues(
        '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><link rel="canonical" href="./index.html"><meta property="og:title" content="Home"><meta property="og:description" content="Welcome"><script type="application/ld+json">{}</script></head><body><h1>Welcome</h1><label for="email">Email</label><input id="email" aria-label="Email"></body></html>',
        "body { color: #18202b; background: #fff; }"
    );
    assert.deepEqual(issues, []);
});

test("index loads the runtime quality module before the editor", () => {
    const html = read("index.html");
    assert.ok(html.indexOf("workspace-quality-runtime.js") < html.indexOf('script.js" defer'));
});
