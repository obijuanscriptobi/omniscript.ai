"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.json"), "utf8"));

function hasId(id) {
    return new RegExp(`\\bid=["']${id}["']`).test(html);
}

test("website maker contains the focused generation and launch controls", () => {
    for (const id of [
        "apply-outcome-brief-btn",
        "compile-pipeline-btn",
        "previewContentIframe",
        "update-contact-draft-btn",
        "go-live-download-btn",
        "go-live-publish-btn",
        "export-zip-btn",
        "publish-site-btn",
        "website-maker-next-action"
    ]) {
        assert.equal(hasId(id), true, `missing website-maker control: ${id}`);
    }
});

test("advanced diagnostics are not embedded in the initial document", () => {
    for (const id of ["diagnostic-severity-filter", "diagnostic-score-help-btn", "export-project-json-btn", "import-project-json-input"]) {
        assert.equal(hasId(id), false, `stale advanced control remains embedded: ${id}`);
    }
    assert.match(html, /<template id="advanced-workspace-tools-template">/);
    assert.match(html, /<div id="advanced-workspace-tools" class="advanced-workspace-tools" hidden><\/div>/);
    const loader = fs.readFileSync(path.join(root, "app-loader.js"), "utf8");
    assert.match(loader, /Loading editor/);
    assert.match(loader, /workspace-fields\.js/);
    assert.match(loader, /preview-protocol\.js/);
    assert.match(loader, /workspace-loader-retry/);
});

test("the page keeps one canonical onboarding implementation", () => {
    const loader = fs.readFileSync(path.join(root, "app-loader.js"), "utf8");
    assert.doesNotMatch(html, /application\\/legacy-onboarding/);
    assert.match(loader, /["']onboarding\.js["']/);
});

test("preview is sandboxed and has an accessible title", () => {
    const iframe = html.match(/<iframe[\\s\\S]*?id=["']previewContentIframe["'][\\s\\S]*?>/i)?.[0] || "";
    assert.match(iframe, /sandbox=["'][^"']*allow-scripts/);
    assert.match(iframe, /title=["']Generated website preview["']/);
});

test("source-file tabs are excluded from the focused initial document", () => {
    assert.equal((html.match(/role=["']tab["']/g) || []).length, 0);
    assert.equal((html.match(/role=["']tabpanel["']/g) || []).length, 0);
    assert.match(html, /id="advanced-canvas-tools"[^>]*hidden/);
});

test("shared audit module resolves nested local references", () => {
    const audit = require("../workspace-audit.js");
    assert.equal(audit.resolveLocalReference("pages/contact.html", "../style.css"), "style.css");
    const report = audit.auditProject({ "index.html": "<!doctype html><html><head><title>x</title></head><body><h1>x</h1><img src=\"missing.svg\"></body></html>" });
    assert.ok(report.blocking.some((item) => item.code === "MISSING_LOCAL_REFERENCE"));
});

test("manifest has installable app identity and matching theme colors", () => {
    assert.equal(typeof manifest.name, "string");
    assert.equal(typeof manifest.short_name, "string");
    assert.equal(manifest.display, "standalone");
    assert.equal(manifest.theme_color, manifest.background_color);
});
