"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const source = fs.readFileSync(path.join(root, "workspace-state.js"), "utf8");

test("workspace state factory returns isolated runtime collections", () => {
    const context = { window: {} };
    vm.runInNewContext(source, context);

    const factory = context.window.workspaceState.createWorkspaceState;
    const first = factory();
    const second = factory();

    first.files["index.html"] = "changed";
    first.history.push({ files: {} });
    first.deploymentHistory.push({ id: "one" });

    assert.equal(second.files["index.html"], undefined);
    assert.equal(second.history.length, 0);
    assert.equal(second.deploymentHistory.length, 0);
    assert.equal(first.activePage, "index.html");
    assert.equal(first.historyLimit, 20);
    assert.equal(first.generationCheckpointCursor, -1);
    assert.deepEqual(first.generationCheckpoints, []);
});

test("workspace state accepts safe overrides without sharing arrays", () => {
    const context = { window: {} };
    vm.runInNewContext(source, context);

    const history = [{ id: 1 }];
    const state = context.window.workspaceState.createWorkspaceState({
        activePage: "about.html",
        history,
        files: { "about.html": "<main></main>" }
    });

    history.push({ id: 2 });
    assert.equal(state.activePage, "about.html");
    assert.equal(state.history.length, 1);
    assert.equal(state.files["about.html"], "<main></main>");
});

test("workspace state isolates readiness evidence and operation history", () => {
    const context = { window: {} };
    vm.runInNewContext(source, context);
    const evidence = [{ revision: "one" }];
    const operations = [{ type: "generation" }];
    const state = context.window.workspaceState.createWorkspaceState({ evidenceLedger: evidence, operationHistory: operations });
    evidence.push({ revision: "two" });
    operations.push({ type: "import" });
    assert.equal(state.evidenceLedger.length, 1);
    assert.equal(state.operationHistory.length, 1);
});
