"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

function loadValidation(options = {}) {
    const context = {
        window: {},
        ...(options.Function ? { Function: options.Function } : {}),
        DOMParser: class {
            parseFromString() {
                return { querySelector: () => null };
            }
        }
    };
    vm.runInNewContext(read("workspace-validation.js"), context);
    return context.window.workspaceValidation;
}

test("generated-project validation accepts a complete project", () => {
    const validation = loadValidation();
    const issues = validation.validateGeneratedProject({
        "index.html": '<!doctype html><html lang="en"><head><title>Welcome home</title><meta name="viewport" content="width=device-width"><script type="application/ld+json">{"@type":"LocalBusiness"}</script></head><body><h1>Welcome</h1><form action="/api/submit-form"></form></body></html>',
        "script.js": "document.body.dataset.ready = 'true';"
    });
    assert.deepEqual(issues, []);
});

test("generated-project validation reports required structure", () => {
    const validation = loadValidation();
    const issues = validation.validateGeneratedProject({ "index.html": "<html><body><h1>One</h1><h1>Two</h1></body></html>" });
    assert.ok(issues.some((issue) => /doctype/i.test(issue)));
    assert.ok(issues.some((issue) => /language/i.test(issue)));
    assert.ok(issues.some((issue) => /exactly one primary heading/i.test(issue)));
    assert.ok(issues.some((issue) => /form action/i.test(issue)));
    assert.ok(issues.some((issue) => /viewport/i.test(issue)));
});

test("generated-project validation catches script syntax errors", () => {
    const validation = loadValidation();
    const issues = validation.validateGeneratedProject({
        "index.html": '<!doctype html><html lang="en"><head><meta name="viewport" content="width=device-width"></head><body><h1>Welcome</h1><form action="/api/submit-form"></form></body></html>',
        "script.js": "if ("
    });
    assert.ok(issues.some((issue) => /script\.js has a syntax error/i.test(issue)));
});

test("generated-project validation checks secondary pages and local links", () => {
    const validation = loadValidation();
    const issues = validation.validateGeneratedProject({
        "index.html": '<!doctype html><html lang="en"><head><title>Home</title><meta name="viewport" content="width=device-width"></head><body><h1>Home</h1><a href="./about.html">About</a><a href="./missing.html">Missing</a><form action="/api/submit-form"></form></body></html>',
        "about.html": '<!doctype html><html lang="en"><head><title>About</title><meta name="viewport" content="width=device-width"></head><body><h1>About</h1><img src="about.jpg"></body></html>'
    });
    assert.ok(issues.some((issue) => /missing\.html/i.test(issue)));
    assert.ok(issues.some((issue) => /without alternative text/i.test(issue)));
});

test("generated-project validation ignores external asset URLs", () => {
    const validation = loadValidation();
    const issues = validation.validateGeneratedProject({
        "index.html": '<!doctype html><html lang="en"><head><title>Home</title><meta name="viewport" content="width=device-width"><link rel="stylesheet" href="https://cdn.example.com/site.css"></head><body><h1>Home</h1><img src="https://cdn.example.com/hero.jpg" alt="Hero"><script src="https://cdn.example.com/site.js"></script><form action="/api/submit-form"></form></body></html>'
    });
    assert.doesNotMatch(issues.join("\\n"), /cdn\.example\.com|missing.*site\.(?:css|js)/i);
});

test("generated-project validation checks every JavaScript file", () => {
    const validation = loadValidation();
    const issues = validation.validateGeneratedProject({
        "index.html": '<!doctype html><html lang="en"><head><title>Home</title><meta name="viewport" content="width=device-width"></head><body><h1>Home</h1><form action="/api/submit-form"></form></body></html>',
        "script.js": "document.body.dataset.ready = 'true';",
        "netlify/functions/submit-form.js": "if ("
    });
    assert.ok(issues.some((issue) => /submit-form\.js has a syntax error/i.test(issue)));
});

test("validation does not treat CSP-blocked dynamic compilation as a project syntax error", () => {
    const blockedFunction = function blockedByPolicy() {
        const error = new Error("Refused to evaluate a string because the site's Content Security Policy disallows unsafe-eval.");
        error.name = "EvalError";
        throw error;
    };
    const validation = loadValidation({ Function: blockedFunction });
    const issues = validation.validateGeneratedProject({
        "index.html": '<!doctype html><html lang="en"><head><title>Home</title><meta name="viewport" content="width=device-width"></head><body><h1>Home</h1><form action="/api/submit-form"></form></body></html>',
        "script.js": "document.body.dataset.ready = 'true';"
    });
    assert.doesNotMatch(issues.join("\\n"), /script\.js has a syntax error/i);
});

test("index loads validation before the editor runtime", () => {
    const html = read("index.html");
    assert.ok(html.indexOf("workspace-validation.js") < html.indexOf('script.js" defer'));
});
