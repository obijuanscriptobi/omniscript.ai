"use strict";
(() => {
    const BASE_KEY = "morrow-next-steps-v2";
    const KEY = window.workspaceContext?.storageKey?.(BASE_KEY) || BASE_KEY;
    const appointmentKey = () => window.workspaceContext?.storageKey?.("morrow-appointments-v1") || "morrow-appointments-v1";
    const CHANNEL = `morrow-next-steps-sync-v1-${window.workspaceContext?.namespace?.() || "default"}`;
    const $ = (id) => document.getElementById(id);
    const now = () => new Date().toISOString();
    const uid = () => globalThis.crypto?.randomUUID?.() || `00000000-0000-4000-8000-${Math.random().toString(16).slice(2, 14).padEnd(12, "0")}`;
    const clean = (value, max = 240) => String(value ?? "").replace(/[<>]/g, "").trim().slice(0, max);
    const categories = ["Setup", "Personal", "Website", "Leads", "Appointments", "Ads", "Follow-up"];
    const priorities = ["now", "soon", "later"];
    const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const validDateKey = (value) => {
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
        if (!match) return false;
        const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
        return date.getFullYear() === Number(match[1]) && date.getMonth() === Number(match[2]) - 1 && date.getDate() === Number(match[3]);
    };
    let tasks = load();
    let currentIndex = 0;
    let calendarMonth = new Date();
    calendarMonth.setDate(1);
    let undoTask = null;
    let cloudTimer = null;
    let cloudState = "local";
    let activeFilter = "all";
    let channel = null;
    try { channel = new BroadcastChannel(CHANNEL); } catch (_) {}

    function safeHref(value) {
        const href = String(value || "").trim().slice(0, 500);
        if (!href) return "";
        try {
            const url = new URL(href, window.location.href);
            return url.origin === window.location.origin && ["http:", "https:"].includes(url.protocol) ? href : "";
        } catch (_) { return ""; }
    }

    function safePublicHref(value) {
        const href = String(value || "").trim().slice(0, 1000);
        if (!href) return "";
        try { const url = new URL(href, window.location.href); return ["http:", "https:"].includes(url.protocol) ? url.href : ""; } catch (_) { return ""; }
    }

    function normalize(task = {}) {
        const text = clean(task.text);
        const validTimestamp = (value, fallback = "") => value && !Number.isNaN(Date.parse(value)) ? new Date(value).toISOString() : fallback;
        const createdAt = validTimestamp(task.createdAt, now());
        return {
            id: clean(task.id) || uid(), text, category: categories.includes(task.category) ? task.category : "Setup",
            priority: priorities.includes(task.priority) ? task.priority : "soon", dueDate: validDateKey(task.dueDate) ? task.dueDate : "",
            notes: clean(task.notes, 500), completed: task.completed === true, createdAt, completedAt: validTimestamp(task.completedAt),
            source: clean(task.source, 80) || "user", href: safeHref(task.href), effort: clean(task.effort, 80) || "About 5 minutes",
            updatedAt: validTimestamp(task.updatedAt, createdAt), recurring: task.recurring === true, recurrence: ["weekly", "monthly"].includes(task.recurrence) ? task.recurrence : ""
        };
    }

    function load() {
        try {
            const parsed = JSON.parse(localStorage.getItem(KEY) || "[]");
            return Array.isArray(parsed) ? parsed.map(normalize).filter((task) => task.text) : [];
        } catch (_) { return []; }
    }

    function save({ broadcast = true, cloud = true } = {}) {
        try { localStorage.setItem(KEY, JSON.stringify(tasks)); } catch (_) { setStatus("Browser storage is unavailable. Your changes may not survive a reload.", true); }
        if (broadcast) try { channel?.postMessage({ tasks, at: now() }); } catch (_) {}
        if (cloud) scheduleCloudSave();
    }

    function setStatus(message, error = false) {
        const status = $("todo-status");
        if (status) { status.textContent = message; status.dataset.state = error ? "error" : "ok"; }
        const sync = $("todo-sync-status");
        if (sync) { sync.textContent = cloudState === "syncing" ? "Syncing…" : cloudState === "cloud" ? "Saved across devices" : "Saved on this device"; sync.dataset.state = cloudState; }
    }

    function setCloudState(state, message) { cloudState = state; setStatus(message || (state === "syncing" ? "Syncing your next steps…" : state === "cloud" ? "Saved across devices." : "Saved on this device."), state === "error"); }

    function currentTask() {
        const open = tasks.filter((task) => !task.completed);
        if (!open.length) return null;
        currentIndex = Math.min(currentIndex, open.length - 1);
        return open[currentIndex];
    }

    function render() {
        const current = $("todo-current"), count = $("todo-count"), done = $("todo-done-btn"), skip = $("todo-skip-btn"), empty = $("todo-empty-actions");
        if (!current || !count || !done || !skip) return;
        const open = tasks.filter((task) => !task.completed), task = currentTask();
        count.textContent = `${open.length} ${open.length === 1 ? "step" : "steps"} waiting`;
        current.replaceChildren();
        done.hidden = skip.hidden = !task;
        if (!task) {
            const heading = document.createElement("strong"); heading.textContent = tasks.length ? "You’re clear for now." : "Nothing is waiting for you right now.";
            const text = document.createElement("p"); text.textContent = "Add another action or review your business setup when you’re ready.";
            current.append(heading, text); if (empty) empty.hidden = false; renderAll(); setStatus("You’re clear for now. No backlog to manage."); return;
        }
        if (empty) empty.hidden = true;
        const number = document.createElement("span"); number.className = "todo-step-number"; number.textContent = `Next step · ${currentIndex + 1} of ${open.length}`;
        const heading = document.createElement("strong"); heading.textContent = task.text;
        const reason = document.createElement("p"); reason.textContent = task.notes || reasonFor(task);
        const meta = document.createElement("div"); meta.className = "todo-task-meta";
        [task.category, labelPriority(task.priority), task.effort, task.dueDate ? `Due ${formatDate(task.dueDate)}` : "", task.recurrence ? `Repeats ${task.recurrence}` : ""].filter(Boolean).forEach((item) => { const span = document.createElement("span"); span.textContent = item; meta.append(span); });
        const action = task.href ? document.createElement("a") : null;
        if (action) { action.href = task.href; action.className = "todo-task-link"; action.textContent = task.source === "workflow" ? "Open this step" : "Open link"; }
        current.append(number, heading, reason, meta); if (action) current.append(action);
        renderAll(); setStatus("Only this step is on your plate right now.");
    }

    function reasonFor(task) { return task.source === "workflow" ? "A small improvement here keeps your business setup moving." : "A clear next step is enough for today."; }
    function labelPriority(value) { return value === "now" ? "Now" : value === "later" ? "Later" : "Soon"; }
    function formatDate(value) { try { return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(`${value}T12:00:00`)); } catch (_) { return value; } }

    function readAppointments() {
        try {
            const value = JSON.parse(localStorage.getItem(appointmentKey()) || "[]");
            const items = Array.isArray(value) ? value.filter((item) => item && typeof item === "object" && item.meetingAt && !Number.isNaN(new Date(item.meetingAt).getTime())) : [];
            return window.appointmentIntelligence ? items.map(window.appointmentIntelligence.normalize) : items;
        } catch (_) { return []; }
    }

    function renderCalendar() {
        const root = $("todo-month-calendar"), title = $("todo-calendar-month");
        if (!root || !title) return;
        root.replaceChildren();
        title.textContent = new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(calendarMonth);
        const first = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1);
        const daysInMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 0).getDate();
        const leading = first.getDay();
        const appointments = readAppointments().filter((item) => item.meetingAt && !["cancelled"].includes(item.status));
        const byDay = new Map();
        appointments.forEach((item) => {
            const date = new Date(item.meetingAt);
            if (date.getFullYear() === calendarMonth.getFullYear() && date.getMonth() === calendarMonth.getMonth()) {
                const key = date.getDate();
                if (!byDay.has(key)) byDay.set(key, []);
                byDay.get(key).push({ type: "appointment", time: date, label: item.clientName || "Appointment" });
            }
        });
        tasks.filter((task) => !task.completed && task.dueDate).forEach((task) => {
            const [year, month, day] = task.dueDate.split("-").map(Number);
            if (year === calendarMonth.getFullYear() && month === calendarMonth.getMonth() + 1) {
                if (!byDay.has(day)) byDay.set(day, []);
                byDay.get(day).push({ type: "task", label: task.text });
            }
        });
        ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].forEach((day) => {
            const heading = document.createElement("span");
            heading.className = "todo-calendar-weekday";
            heading.textContent = day;
            heading.setAttribute("role", "columnheader");
            root.append(heading);
        });
        for (let index = 0; index < leading + daysInMonth; index += 1) {
            const dayNumber = index - leading + 1;
            const cell = document.createElement("div");
            cell.className = "todo-calendar-day";
            cell.setAttribute("role", "gridcell");
            if (dayNumber < 1 || dayNumber > daysInMonth) { cell.classList.add("is-empty"); root.append(cell); continue; }
            const date = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), dayNumber);
            cell.dataset.calendarDate = dateKey(date);
            cell.tabIndex = 0;
            cell.setAttribute("aria-label", `Add a task for ${date.toLocaleDateString()}`);
            cell.title = "Select to add a task for this date";
            if (date.toDateString() === new Date().toDateString()) cell.classList.add("is-today");
            const number = document.createElement("strong"); number.textContent = dayNumber; cell.append(number);
            (byDay.get(dayNumber) || []).slice(0, 4).forEach((event) => {
                const item = document.createElement("span");
                item.className = `todo-calendar-event ${event.type}`;
                item.textContent = event.type === "appointment" ? `${event.time.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} · ${event.label}` : event.label;
                item.title = item.textContent;
                cell.append(item);
            });
            const more = (byDay.get(dayNumber) || []).length - 4;
            if (more > 0) { const item = document.createElement("span"); item.className = "todo-calendar-more"; item.textContent = `+${more} more`; cell.append(item); }
            root.append(cell);
        }
    }

    function renderAppointmentCommand(items) {
        const root = $("todo-appointment-command");
        if (!root || !window.appointmentIntelligence) return;
        root.replaceChildren();
        const upcoming = items.filter((item) => new Date(item.meetingAt) > new Date() && !["cancelled", "completed"].includes(item.status)).sort((a, b) => new Date(a.meetingAt) - new Date(b.meetingAt));
        const appointment = upcoming[0];
        if (!appointment) { root.innerHTML = '<p class="todo-empty">No upcoming appointment needs preparation.</p>'; return; }
        const intel = window.appointmentIntelligence;
        const info = intel.brief(appointment); const checks = intel.checklist(appointment); const done = checks.filter((item) => item.done).length; const warnings = intel.risks(appointment, items); const type = intel.typeFor(appointment.type);
        const title = document.createElement("h3"); title.textContent = `${type.label} · ${info.business}`;
        const meta = document.createElement("p"); meta.className = "appointment-command-meta"; meta.textContent = `${appointment.clientName || "Client not named"} · ${new Date(appointment.meetingAt).toLocaleString()} · ${intel.relativeTime(appointment.meetingAt)} · ${Number.isFinite(info.score) ? `${info.score}/100 opportunity` : `${info.stage} stage`}`;
        const objective = document.createElement("p"); objective.innerHTML = `<strong>Objective:</strong> ${clean(appointment.objective || "Set an objective before the meeting", 500)}`;
        const prep = document.createElement("p"); prep.innerHTML = `<strong>Prepare:</strong> ${clean(type.before, 500)} · ${done}/${checks.length} complete`;
        const next = document.createElement("p"); next.innerHTML = `<strong>Afterward:</strong> ${clean(appointment.nextAction || type.followUp, 500)}`;
        const warning = document.createElement("p"); warning.className = "appointment-risk"; warning.textContent = warnings.length ? `Needs attention: ${warnings.slice(0, 2).join(" and ")}.` : "Ready: no immediate scheduling risk found.";
        const reminder = document.createElement("p"); reminder.className = "appointment-reminder"; const ladder = intel.reminderLadder?.(appointment) || []; const dueReminder = ladder.find((item) => item.due); reminder.textContent = dueReminder ? `${dueReminder.label} · ${dueReminder.delivery}` : `Next reminder: ${ladder[0]?.label || "none scheduled"} · ${ladder[0]?.delivery || "Local reminders only"}`;
        const workLinks = document.createElement("div"); workLinks.className = "appointment-work-links";
        [[info.lead?.opportunity?.auditUrl || info.lead?.websiteUrl, "Open audit"], [info.lead?.preview?.url || info.lead?.opportunity?.previewUrl, "Open revision"], [info.lead?.proposal?.approvalUrl, "Open proposal"]].forEach(([href, label]) => { const safe = safePublicHref(href); if (!safe) return; const link = document.createElement("a"); link.href = safe; link.textContent = label; link.target = "_blank"; link.rel = "noopener noreferrer"; workLinks.append(link); });
        const details = document.createElement("details"); const summary = document.createElement("summary"); summary.textContent = "Open evidence-aware preparation brief"; const body = document.createElement("div"); body.className = "appointment-brief";
        const verified = document.createElement("p"); verified.innerHTML = `<strong>Verified public details:</strong> ${info.publicDetails.length ? info.publicDetails.map((value) => clean(value, 300)).join(" · ") : "None linked yet"}`;
        const findings = document.createElement("p"); findings.innerHTML = `<strong>Website findings:</strong> ${info.findings.length ? info.findings.map((value) => clean(value, 300)).join(" · ") : "No verified findings linked"}`;
        const notes = document.createElement("p"); notes.innerHTML = `<strong>Previous notes:</strong> ${clean(info.previousNotes || "No notes recorded", 1000)}`;
        const offer = document.createElement("p"); offer.innerHTML = `<strong>Suggested offer:</strong> ${clean(info.offer, 300)} <small>(suggestion—confirm during the meeting)</small>`;
        const questions = document.createElement("ul"); info.questions.forEach((question) => { const li = document.createElement("li"); li.textContent = question; questions.append(li); });
        const claims = document.createElement("p"); claims.className = "appointment-risk"; claims.textContent = info.claimsToVerify.length ? `Verify before claiming: ${info.claimsToVerify.join("; ")}.` : "Public contact and audit evidence are present; confirm they remain current.";
        const checklist = document.createElement("div"); checklist.className = "appointment-checklist"; checks.forEach((check) => { const label = document.createElement("label"); const input = document.createElement("input"); input.type = "checkbox"; input.checked = check.done; input.disabled = ["websiteReviewed", "contactVerified", "objectiveSet"].includes(check.key); input.dataset.prepAppointment = appointment.id; input.dataset.prepKey = check.key; label.append(input, document.createTextNode(` ${check.label}`)); checklist.append(label); });
        body.append(verified, findings, notes, offer, questions, claims, checklist); details.append(summary, body); root.append(title, meta, objective, prep, next, warning, reminder); if (workLinks.childElementCount) root.append(workLinks); root.append(details);
    }

    function renderAppointmentHealth(items) {
        const root = $("appointment-health"); if (!root || !window.appointmentIntelligence) return;
        const metrics = window.appointmentIntelligence.metrics(items); root.replaceChildren();
        [["Attendance", metrics.attendance], ["No-show rate", metrics.noShow], ["Discovery → qualified", metrics.discoveryQualified], ["Qualified → proposal", metrics.qualifiedProposal], ["Average follow-up delay", metrics.averageFollowUp], ["Missing next actions", metrics.withoutNextAction], ["Most effective type", metrics.effectiveType], ["Meeting time per won client", metrics.wonHours]].forEach(([label, value]) => { const card = document.createElement("div"); const strong = document.createElement("strong"); strong.textContent = value; const span = document.createElement("span"); span.textContent = label; card.append(strong, span); root.append(card); });
    }

    function renderSchedule() {
        renderCalendar();
        const availability = $("todo-availability"), appointments = $("todo-appointments");
        if (!availability || !appointments) return;
        availability.replaceChildren(); appointments.replaceChildren();
        const booked = new Set();
        const allAppointments = readAppointments();
        let meetings = allAppointments.filter((item) => item.meetingAt && !["cancelled", "completed"].includes(item.status));
        meetings.sort((a, b) => new Date(a.meetingAt) - new Date(b.meetingAt)).forEach((item) => booked.add(new Date(item.meetingAt).toISOString().slice(0, 13)));
        renderAppointmentCommand(allAppointments); renderAppointmentHealth(allAppointments);
        const slots = window.appointmentIntelligence?.recommendedSlots(allAppointments) || [];
        slots.forEach((entry, index) => { const slot = new Date(entry.at); const card = document.createElement("div"); card.className = "todo-time-card"; const title = document.createElement("strong"); title.textContent = index === 0 ? `Best slot · ${slot.toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}` : slot.toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }); const reason = document.createElement("span"); reason.textContent = entry.reason; const button = document.createElement("button"); button.type = "button"; button.className = "todo-time-button"; button.textContent = "Plan this time"; button.dataset.openSlot = entry.at; card.append(title, reason, button); availability.append(card); });
        if (!meetings.length) { appointments.innerHTML = "<p class=\"todo-status\">No upcoming appointments. Add one from Leads.</p>"; return; }
        meetings.slice(0, 8).forEach((item) => { const card = document.createElement("div"); card.className = "todo-appointment-card"; const title = document.createElement("strong"); title.textContent = item.clientName || "Unnamed appointment"; const details = document.createElement("small"); details.textContent = `${new Date(item.meetingAt).toLocaleString()}${item.service ? ` · ${item.service}` : ""}`; card.append(title, details); appointments.append(card); });
    }

    function dateKey(date = new Date()) {
        const value = date instanceof Date ? date : new Date(date);
        if (Number.isNaN(value.getTime())) return "";
        const year = value.getFullYear();
        const month = String(value.getMonth() + 1).padStart(2, "0");
        const day = String(value.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }
    function isOverdue(task) { return !task.completed && task.dueDate && task.dueDate < dateKey(); }
    function renderToday() {
        const today = dateKey(), todayTasks = tasks.filter((task) => !task.completed && task.dueDate === today);
        const appointments = readAppointments().filter((item) => item.meetingAt && !["cancelled", "completed"].includes(item.status) && dateKey(new Date(item.meetingAt)) === today).sort((a, b) => new Date(a.meetingAt) - new Date(b.meetingAt));
        const overdue = tasks.filter(isOverdue).sort((a, b) => String(a.dueDate).localeCompare(String(b.dueDate)));
        const focus = $("todo-focus"), summary = $("todo-focus-summary"), taskRoot = $("todo-today-tasks"), appointmentRoot = $("todo-today-appointments");
        if (!focus || !summary || !taskRoot || !appointmentRoot) return;
        summary.textContent = `${todayTasks.length} task${todayTasks.length === 1 ? "" : "s"} · ${appointments.length} appointment${appointments.length === 1 ? "" : "s"}`;
        focus.replaceChildren();
        const next = appointments[0] || todayTasks[0] || overdue[0];
        const focusText = document.createElement("strong"); focusText.textContent = next ? `Next up: ${appointments[0] ? `${appointments[0].clientName || "Appointment"} at ${new Date(appointments[0].meetingAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : next.text}` : "Your day is clear.";
        const focusNote = document.createElement("span"); focusNote.textContent = next ? "One useful thing at a time." : "Add a task or schedule an appointment when you’re ready.";
        focus.append(focusText, focusNote);
        renderTodayList(taskRoot, overdue.concat(todayTasks), "No tasks today. Your day is clear.");
        renderTodayList(appointmentRoot, appointments, "No appointments scheduled.");
    }
    function renderTodayList(root, items, emptyText) {
        root.replaceChildren();
        if (!items.length) { const empty = document.createElement("p"); empty.className = "todo-empty"; empty.textContent = emptyText; root.append(empty); return; }
        items.slice(0, 6).forEach((item) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = `todo-today-item ${item.meetingAt ? "appointment" : isOverdue(item) ? "overdue" : "task"}`;
            button.dataset[item.meetingAt ? "appointmentId" : "taskId"] = item.id || "";
            const icon = document.createElement("span");
            icon.className = "todo-item-icon";
            icon.setAttribute("aria-hidden", "true");
            icon.textContent = item.meetingAt ? "◆" : isOverdue(item) ? "!" : "✓";
            const copy = document.createElement("span");
            const title = document.createElement("strong");
            title.textContent = item.meetingAt ? (item.clientName || "Appointment") : item.text;
            const detail = document.createElement("small");
            detail.textContent = item.meetingAt ? new Date(item.meetingAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : isOverdue(item) ? `Overdue · ${formatDate(item.dueDate)}` : "Today";
            copy.append(title, detail);
            button.append(icon, copy);
            root.append(button);
        });
    }

    function renderAll() {
        renderToday();
        renderSchedule();
        const list = $("todo-all-list"); if (!list) return; list.replaceChildren();
        const visible = tasks.filter((task) => activeFilter === "completed" ? task.completed : activeFilter === "overdue" ? isOverdue(task) : activeFilter === "tasks" ? !task.completed : activeFilter === "appointments" ? task.category === "Appointments" && !task.completed : !task.completed);
        visible.forEach((task) => {
            const row = document.createElement("article"); row.className = "todo-list-row";
            const details = document.createElement("div"); const text = document.createElement("strong"); text.textContent = task.text;
            const meta = document.createElement("small"); meta.textContent = `${task.category} · ${labelPriority(task.priority)}${task.dueDate ? ` · due ${formatDate(task.dueDate)}` : ""}${task.recurrence ? ` · repeats ${task.recurrence}` : ""}`; details.append(text, meta);
            const actions = document.createElement("div"); actions.className = "todo-row-actions";
            [["Edit", "edit-task"], ["Remove", "remove-task"]].forEach(([label, action]) => { const button = document.createElement("button"); button.type = "button"; button.textContent = label; button.setAttribute(`data-${action}`, task.id); actions.append(button); });
            row.append(details, actions); list.append(row);
        });
    }

    function addTask(task) {
        const gate = window.workspaceContext?.clientGate?.("context");
        if (gate && !gate.allowed) { setStatus(gate.message, true); return false; }
        const next = normalize(task); if (!UUID.test(next.id)) next.id = uid(); if (!next.text || tasks.some((item) => !item.completed && item.text.toLowerCase() === next.text.toLowerCase())) { setStatus("That action is already on your list.", true); return false; }
        tasks.push(next); currentIndex = tasks.filter((item) => !item.completed).length - 1; save(); render(); return true;
    }

    function completeCurrent() {
        const task = currentTask(); if (!task) return;
        const index = tasks.indexOf(task);
        const previousTask = { ...task };
        let recurringTaskId = "";
        task.completed = true; task.completedAt = now(); task.updatedAt = now();
        if (task.recurring && task.recurrence) {
            const recurringTask = normalize({ ...task, id: uid(), completed: false, completedAt: "", createdAt: now(), dueDate: nextDueDate(task.dueDate, task.recurrence), updatedAt: now() });
            recurringTaskId = recurringTask.id;
            tasks.push(recurringTask);
        }
        undoTask = { task: previousTask, index, recurringTaskId };
        save(); render(); setStatus(`Action completed — ${currentTask() ? `next: ${currentTask().text}` : "you’re clear for now."}`); showUndo();
    }

    function nextDueDate(value, recurrence) {
        const date = value ? new Date(`${value}T12:00:00`) : new Date();
        if (Number.isNaN(date.getTime())) return "";
        if (recurrence === "monthly") {
            const originalDay = date.getDate();
            date.setDate(1);
            date.setMonth(date.getMonth() + 1);
            const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
            date.setDate(Math.min(originalDay, lastDay));
        } else {
            date.setDate(date.getDate() + 7);
        }
        return dateKey(date);
    }

    function showUndo() {
        const button = $("todo-undo-btn"); if (!button) return; button.hidden = false; clearTimeout(showUndo.timer); showUndo.timer = setTimeout(() => { button.hidden = true; undoTask = null; }, 7000);
    }

    let editingTaskId = "";
    function editTask(task) {
        const dialog = $("todo-edit-dialog"); if (!dialog) return;
        editingTaskId = task.id;
        $("todo-edit-input").value = task.text;
        $("todo-edit-category").value = task.category;
        $("todo-edit-priority").value = task.priority;
        $("todo-edit-due").value = task.dueDate;
        $("todo-edit-notes").value = task.notes;
        $("todo-edit-recurrence").value = task.recurrence;
        if (typeof dialog.showModal === "function") dialog.showModal(); else dialog.setAttribute("open", "");
        setTimeout(() => $("todo-edit-input")?.focus(), 0);
    }

    $("todo-edit-form")?.addEventListener("submit", (event) => {
        if (event.submitter?.value !== "save") return;
        event.preventDefault();
        const task = tasks.find((item) => item.id === editingTaskId); if (!task) return;
        const text = clean($("todo-edit-input")?.value); if (!text) return;
        Object.assign(task, { text, category: categories.includes($("todo-edit-category")?.value) ? $("todo-edit-category").value : "Setup", priority: priorities.includes($("todo-edit-priority")?.value) ? $("todo-edit-priority").value : "soon", dueDate: validDateKey($("todo-edit-due")?.value) ? $("todo-edit-due").value : "", notes: clean($("todo-edit-notes")?.value, 500), recurrence: ["weekly", "monthly"].includes($("todo-edit-recurrence")?.value) ? $("todo-edit-recurrence").value : "", recurring: Boolean($("todo-edit-recurrence")?.value), updatedAt: now() });
        save(); render(); $("todo-edit-dialog")?.close?.(); setStatus("Action updated.");
    });

    function workflowSuggestions() {
        const profile = window.profileService?.readLocal?.() || {};
        const identity = profile.identity || {}, brand = profile.brand || {}, location = profile.locations?.[0] || {};
        const suggestions = [];
        const add = (text, category, href, effort, notes) => { if (!tasks.some((task) => task.text.toLowerCase() === text.toLowerCase())) suggestions.push({ text, category, priority: "now", href, effort, notes, source: "workflow" }); };
        if (!identity.displayName) add("Complete your Business Profile", "Setup", "business-profile.html", "About 5 minutes", "Add the basic facts customers should see so the rest of Morrow can stay consistent.");
        if (!(profile.services || []).length) add("Add your first service", "Setup", "business-profile.html", "About 3 minutes", "A service gives your website, ads, and follow-up a clear focus.");
        if (!brand.logoUrl) add("Add a logo", "Setup", "business-profile.html", "About 2 minutes", "A recognizable mark helps your website feel like yours.");
        if (!location.city && !identity.phone && !identity.email) add("Add a contact detail and location", "Setup", "business-profile.html", "About 3 minutes", "Visitors need a clear way to reach you and know where you serve.");
        let ad = null; try { const adKey = `morrow-ad-studio-draft-v4-${window.workspaceContext?.namespace?.() || "own:own-business"}`; ad = JSON.parse(localStorage.getItem(adKey) || "null"); } catch (_) {}
        if (!ad?.concepts?.length) add("Create your first ad", "Ads", "ad-studio.html", "About 8 minutes", "Start with a short brief; you can polish one direction later."); else if (!ad.approved) add("Review and approve your ad", "Ads", "ad-studio.html?step=export", "About 4 minutes", "Check claims, asset rights, destination, and accessibility before export.");
        const hasWebsite = Object.keys(localStorage).some((key) => /workspace|website|project/i.test(key));
        if (!hasWebsite) add("Start your website", "Website", "index.html", "About 10 minutes", "A simple destination gives your future leads somewhere useful to go.");
        else {
            if (!identity.website && !profile.website) add("Publish your website", "Website", "index.html", "About 5 minutes", "Publishing gives customers a clear place to learn more and contact you.");
            if (!identity.booking && !profile.booking) add("Connect a booking destination", "Appointments", "business-profile.html", "About 3 minutes", "A direct booking link removes friction when someone is ready to talk.");
        }
        let leads = []; try { const leadKey = window.workspaceContext?.storageKey?.("morrow-lead-inbox-v1") || "morrow-lead-inbox-v1"; leads = JSON.parse(localStorage.getItem(leadKey) || "[]"); } catch (_) {}
        if (leads.some((lead) => lead && !["closed", "converted"].includes(lead.status))) add("Follow up with a new lead", "Follow-up", "leads.html", "About 3 minutes", "A prompt, personal reply is often the most useful next step.");
        if (leads.some((lead) => lead && lead.status === "converted")) add("Schedule an appointment", "Appointments", "leads.html", "About 4 minutes", "Turn a promising conversation into a clear time to continue it.");
        return suggestions;
    }

    function seedSuggestions() { const suggestions = workflowSuggestions(); if (!suggestions.length) { render(); return; } tasks = [...suggestions.map(normalize), ...tasks]; currentIndex = 0; save(); render(); setStatus("A few gentle suggestions are ready. You can ignore or remove any of them."); }

    async function cloudRequest(method, body = {}) {
        const state = window.supabaseWorkspace?.getState?.() || {}; const token = window.supabaseWorkspace?.getAccessToken?.(); const projectId = state.projectId;
        const workContextId = window.workspaceContext?.current?.()?.cloudId;
        if (!state.authenticated || !token || !projectId || !workContextId) throw new Error("Sign in and select a cloud project in the active workspace to sync across devices.");
        const response = await fetch(`/api/todos?projectId=${encodeURIComponent(projectId)}&workContextId=${encodeURIComponent(workContextId)}`, { method, headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" }, body: method === "GET" ? undefined : JSON.stringify({ projectId, workContextId, tasks }) });
        const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || "Task sync is unavailable."); return data;
    }

    async function syncCloud(mode = "merge") {
        if (!window.supabaseWorkspace?.getState?.()?.authenticated) { setCloudState("local", "Saved on this device. Sign in later to sync across devices."); return; }
        setCloudState("syncing");
        try {
            if (mode === "push") {
                await cloudRequest("PUT");
                setCloudState("cloud", "Saved across devices.");
                return;
            }
            const data = await cloudRequest("GET");
            if (Array.isArray(data.tasks)) {
                const merged = new Map();
                [...tasks, ...data.tasks.map(normalize)].forEach((task) => {
                    const existing = merged.get(task.id);
                    if (!existing || Date.parse(task.updatedAt) >= Date.parse(existing.updatedAt)) merged.set(task.id, task);
                });
                tasks = [...merged.values()].sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)));
                save({ broadcast: false, cloud: false }); render();
            }
            await cloudRequest("PUT"); setCloudState("cloud", "Saved across devices.");
        } catch (error) { setCloudState("error", `${error.message} Local changes are safe on this device.`); }
    }
    function scheduleCloudSave() { clearTimeout(cloudTimer); cloudTimer = setTimeout(() => { if (window.supabaseWorkspace?.getState?.()?.authenticated) syncCloud("push"); }, 500); }

    function populateAvailabilitySettings() {
        if (!window.appointmentIntelligence) return;
        const value = window.appointmentIntelligence.settings();
        [["availability-start", value.startHour], ["availability-end", value.endHour], ["availability-notice", value.minimumNoticeHours], ["availability-buffer", value.bufferMinutes], ["availability-limit", value.dailyLimit], ["availability-travel", value.travelBufferMinutes], ["availability-timezone", value.timezone]].forEach(([id, fieldValue]) => { if ($(id)) $(id).value = fieldValue; });
        if ($("availability-focus-blocks")) $("availability-focus-blocks").value = (value.focusBlocks || []).map((block) => `${block.start} | ${block.end}`).join("\n");
    }
    $("todo-availability-form")?.addEventListener("submit", (event) => {
        event.preventDefault();
        if (!window.appointmentIntelligence) return;
        const startHour = Number($("availability-start")?.value); const endHour = Number($("availability-end")?.value);
        if (endHour <= startHour) { setStatus("Working hours must end after they start.", true); return; }
        const focusBlocks = String($("availability-focus-blocks")?.value || "").split("\n").map((line) => line.split("|").map((part) => part.trim())).filter(([start, end]) => start && end && !Number.isNaN(Date.parse(start)) && !Number.isNaN(Date.parse(end)) && new Date(end) > new Date(start)).map(([start, end]) => ({ start: new Date(start).toISOString(), end: new Date(end).toISOString() }));
        window.appointmentIntelligence.saveSettings({ startHour, endHour, minimumNoticeHours: Number($("availability-notice")?.value), bufferMinutes: Number($("availability-buffer")?.value), dailyLimit: Number($("availability-limit")?.value), travelBufferMinutes: Number($("availability-travel")?.value), timezone: clean($("availability-timezone")?.value, 100) || Intl.DateTimeFormat().resolvedOptions().timeZone, focusBlocks });
        renderSchedule(); setStatus("Availability rules saved on this device.");
    });
    $("todo-appointment-command")?.addEventListener("change", (event) => {
        const input = event.target.closest("[data-prep-appointment]"); if (!input || input.disabled) return;
        const items = readAppointments(); const appointment = items.find((item) => item.id === input.dataset.prepAppointment); if (!appointment) return;
        appointment.preparation = { ...(appointment.preparation || {}), [input.dataset.prepKey]: input.checked };
        appointment.timeline = [...(appointment.timeline || []), { type: "preparation", label: `${input.checked ? "Completed" : "Reopened"}: ${input.parentElement?.textContent.trim() || input.dataset.prepKey}`, at: now() }];
        try { localStorage.setItem(appointmentKey(), JSON.stringify(items)); } catch (_) {}
        const state = window.supabaseWorkspace?.getState?.() || {}; const token = window.supabaseWorkspace?.getAccessToken?.();
        if (state.authenticated && state.projectId && token && appointment.id) fetch(`/api/appointments?projectId=${encodeURIComponent(state.projectId)}&id=${encodeURIComponent(appointment.cloudId || appointment.id)}`, { method: "PATCH", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ projectId: state.projectId, preparation: appointment.preparation, timeline: appointment.timeline }) }).then((response) => { if (!response.ok) throw new Error(); setStatus("Appointment preparation saved across devices."); }).catch(() => setStatus("Preparation is saved locally; cloud sync is pending.", true));
        renderSchedule(); setStatus("Appointment preparation updated.");
    });
    $("todo-refresh-schedule")?.addEventListener("click", () => { renderSchedule(); setStatus("Schedule refreshed."); });
    $("todo-calendar-previous")?.addEventListener("click", () => { calendarMonth.setMonth(calendarMonth.getMonth() - 1); renderCalendar(); });
    $("todo-calendar-next")?.addEventListener("click", () => { calendarMonth.setMonth(calendarMonth.getMonth() + 1); renderCalendar(); });
    $("todo-calendar-today")?.addEventListener("click", () => { calendarMonth = new Date(); calendarMonth.setDate(1); renderCalendar(); });
    function selectCalendarDate(cell) {
        if (!cell) return;
        const input = $("todo-input");
        const due = $("todo-due");
        if (due) due.value = cell.dataset.calendarDate;
        input?.focus();
        setStatus(`Ready to add a task for ${formatDate(cell.dataset.calendarDate)}.`);
    }
    $("todo-month-calendar")?.addEventListener("click", (event) => selectCalendarDate(event.target.closest("[data-calendar-date]")));
    $("todo-month-calendar")?.addEventListener("keydown", (event) => {
        if (!["Enter", " "].includes(event.key)) return;
        const cell = event.target.closest("[data-calendar-date]");
        if (!cell) return;
        event.preventDefault();
        selectCalendarDate(cell);
    });
    document.querySelectorAll("[data-todo-filter]").forEach((button) => button.addEventListener("click", () => { activeFilter = button.dataset.todoFilter || "all"; document.querySelectorAll("[data-todo-filter]").forEach((item) => item.classList.toggle("is-active", item === button)); renderAll(); }));
    $("todo-today-tasks")?.addEventListener("click", (event) => { const task = tasks.find((item) => item.id === event.target.closest("[data-task-id]")?.dataset.taskId); if (task) editTask(task); });
    $("todo-today-appointments")?.addEventListener("click", (event) => { const item = readAppointments().find((appointment) => appointment.id === event.target.closest("[data-appointment-id]")?.dataset.appointmentId); if (item) setStatus(`${item.clientName || "Appointment"} is scheduled for ${new Date(item.meetingAt).toLocaleString()}. Manage it from Leads.`); });
    window.addEventListener("storage", (event) => { if (event.key === appointmentKey() || event.key === KEY) renderSchedule(); });
    window.addEventListener("appointments:updated", () => renderSchedule());

    $("todo-form")?.addEventListener("submit", (event) => { event.preventDefault(); const input = $("todo-input"); if (addTask({ text: input?.value, category: $("todo-category")?.value, priority: $("todo-priority")?.value, dueDate: $("todo-due")?.value, notes: $("todo-notes")?.value, recurrence: $("todo-recurrence")?.value, recurring: Boolean($("todo-recurrence")?.value) })) { event.currentTarget.reset(); input?.focus(); } });
    $("todo-availability")?.addEventListener("click", (event) => { const button = event.target.closest("[data-open-slot]"); if (!button) return; const slot = button.dataset.openSlot; addTask({ text: `Prepare for an appointment on ${formatDate(slot.slice(0, 10))} at ${new Date(slot).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`, category: "Appointments", priority: "soon", dueDate: slot.slice(0, 10), notes: "Use this open time to plan or offer an appointment.", source: "schedule", effort: "About 5 minutes" }); setStatus("Scheduling task added for that open time."); });
    $("todo-done-btn")?.addEventListener("click", completeCurrent);
    $("todo-skip-btn")?.addEventListener("click", () => { const open = tasks.filter((task) => !task.completed); if (open.length > 1) currentIndex = (currentIndex + 1) % open.length; render(); setStatus("Skipped for now. Another manageable step is here."); });
    $("todo-undo-btn")?.addEventListener("click", () => {
        if (!undoTask) return;
        if (undoTask.recurringTaskId) tasks = tasks.filter((task) => task.id !== undoTask.recurringTaskId);
        tasks[undoTask.index] = undoTask.task;
        undoTask = null;
        save(); render(); $("todo-undo-btn").hidden = true; setStatus("Action restored.");
    });
    $("todo-seed-btn")?.addEventListener("click", seedSuggestions);
    $("todo-show-all-btn")?.addEventListener("click", (event) => { const list = $("todo-all-list"); if (!list) return; list.hidden = !list.hidden; event.currentTarget.setAttribute("aria-expanded", String(!list.hidden)); event.currentTarget.textContent = list.hidden ? "See saved actions" : "Hide saved actions"; });
    $("todo-all-list")?.addEventListener("click", (event) => { const edit = event.target.closest("[data-edit-task]"), remove = event.target.closest("[data-remove-task]"); const task = tasks.find((item) => item.id === (edit?.dataset.editTask || remove?.dataset.removeTask)); if (!task) return; if (edit) editTask(task); if (remove) { tasks = tasks.filter((item) => item !== task); currentIndex = 0; save(); render(); setStatus("Action removed."); } });
    channel?.addEventListener("message", (event) => { if (event.data?.tasks) { tasks = event.data.tasks.map(normalize); save({ broadcast: false }); render(); setStatus("Updated from another open tab."); } });
    window.addEventListener("storage", (event) => { if (event.key === KEY && event.newValue) { tasks = load(); render(); } });
    window.addEventListener("supabase:authenticated", syncCloud); window.addEventListener("workspace:project-id-change", syncCloud);
    populateAvailabilitySettings();
    if (!tasks.length) seedSuggestions();
    else { render(); syncCloud(); }
})();
