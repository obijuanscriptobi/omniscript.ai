"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    function extract(html) {
        const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
        const nodes = [...doc.querySelectorAll("title,h1,h2,h3,p,a,button,label,summary")].filter((node) => node.textContent.trim());
        return Object.fromEntries(nodes.map((node, index) => [`text-${index}`, { selector: node.tagName.toLowerCase(), text: node.textContent.trim() }]));
    }
    function renderDiff(source, translated, target) {
        const panel = get("translation-review-diff");
        if (!panel) return;
        const rows = Object.keys(source || {}).map((key) => {
            const before = String(source[key]?.text || source[key] || "");
            const after = String(translated?.[key]?.text || translated?.[key] || "");
            const row = document.createElement("li");
            row.dataset.changed = String(before !== after);
            const label = document.createElement("strong");
            const original = document.createElement("span");
            const proposed = document.createElement("span");
            label.textContent = key;
            original.textContent = before;
            proposed.textContent = after || "Translation missing";
            row.append(label, original, proposed);
            return row;
        });
        panel.replaceChildren(...rows);
        panel.hidden = false;
        panel.setAttribute("aria-label", `Translation differences for ${target}`);
    }
    async function request(targetLocale) {
        const state = window.workspaceAPI?.getState?.();
        const source = get("input-locale")?.value || "en-US";
        if (!state?.files?.["index.html"] || source === targetLocale) return;
        const response = await fetch("/api/translation", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify({ sourceLocale: source, targetLocale, content: extract(state.files["index.html"]) }) });
        const result = await response.json().catch(() => ({}));
        const target = get("translation-review-status");
        if (target) target.textContent = response.ok && result.success ? `Translation draft ready for human review (${targetLocale}). It has not changed the website.` : result.error || "Translation draft unavailable.";
        if (response.ok && result.success) renderDiff(extract(state.files["index.html"]), result.content, targetLocale);
    }
    function bind() {
        const panel = document.querySelector("[aria-labelledby='localization-settings-title']");
        if (!panel || get("translation-review-status")) return;
        const button = document.createElement("button"); button.id = "request-translation-review-btn"; button.type = "button"; button.className = "matrix-action-btn variant-outline-row"; button.textContent = "Prepare translation review";
        const status = document.createElement("p"); status.id = "translation-review-status"; status.className = "field-descriptor-text"; status.setAttribute("role", "status"); status.textContent = "Translations are drafts only until a human approves them.";
        const diff = document.createElement("ul"); diff.id = "translation-review-diff"; diff.className = "translation-review-diff"; diff.hidden = true;
        button.addEventListener("click", () => request(get("input-supported-locales")?.value.split(",")[1]?.trim() || "es-US").catch((error) => { status.textContent = error.message; }));
        panel.append(button, status, diff);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
