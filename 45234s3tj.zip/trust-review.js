"use strict";
(() => {
    const $ = (id) => document.getElementById(id);
    const profileKey = "morrow-business-profile-v1";
    const workspaceKey = "luxury-engine-workspace";
    const checklistKey = "morrow-launch-checklist-v1";
    const read = (key, fallback = null) => { try { return JSON.parse(localStorage.getItem(key) || "null") ?? fallback; } catch (_) { return fallback; } };
    const profile = () => read(profileKey, {})?.profile || {};
    const escape = (value) => String(value || "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));

    function getFiles() {
        const liveFiles = window.workspaceAPI?.getState?.()?.files;
        return liveFiles && typeof liveFiles === "object" ? liveFiles : (read(workspaceKey, {})?.files || {});
    }
    function checks() {
        const item = profile();
        const launch = item.metadata?.launchBrief || {};
        const identity = item.identity || {};
        const location = item.locations?.[0] || {};
        const files = getFiles();
        const html = files["index.html"] || "";
        const hasForm = /<form\b/i.test(html);
        const formAction = !hasForm || /action\s*=\s*["'][^"']+["']/i.test(html);
        const hasContact = Boolean(identity.email || identity.phone);
        const hasCta = Boolean(launch.goal || item.metadata?.primaryAction) && /<button\b|<a\b/i.test(html);
        const issues = [
            ["Business facts", Boolean(identity.displayName && identity.description && launch.audience && (location.city || location.serviceArea?.length)), "Add name, offer, audience, and operating area to the Business profile.", "business-profile.html"],
            ["Contact details", hasContact, "Add a public email or phone number so customers can reach you.", "business-profile.html"],
            ["Primary action", hasCta, "Choose one clear visitor action and regenerate the draft.", "index.html#conversion-goal-title"],
            ["Claims confirmation", (item.claims || []).filter((claim) => claim.state === "draft").length === 0, "Confirm or remove draft claims before publishing.", "business-profile.html"],
            ["Testimonials and statistics", !/(testimonial|\b\d+%|\b\d+\+|#1|guaranteed|award-winning)/i.test(html) || (item.claims || []).some((claim) => claim.state === "approved"), "Review testimonials, statistics, and superlatives so every claim is supported.", "index.html#proof-content-title"],
            ["Accessibility basics", /lang\s*=\s*["'][^"']+["']/i.test(html) && /<h1\b/i.test(html) && !/<img\b(?![^>]*\balt\s*=)/i.test(html), "Add a page language, one main heading, and alt text for meaningful images.", "index.html#business-details"],
            ["Mobile layout", Boolean(html) && /viewport/i.test(html) && !/width\s*:\s*\d{4,}px/i.test(html), "Review the mobile preview and remove fixed-width layout risks.", "index.html#previewContentIframe"],
            ["SEO basics", /<title\b/i.test(html) && /name\s*=\s*["']description["']/i.test(html), "Add a page title and meta description before publishing.", "index.html#previewContentIframe"],
            ["Business consistency", !identity.displayName || (html.match(new RegExp(identity.displayName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi")) || []).length > 0, "Make the generated business name match the saved profile.", "business-profile.html"],
            ["Forms and links", (!hasForm || formAction) && !/href\s*=\s*["'](?:#|javascript:)[^"']*["']/i.test(html), "Check form destinations and replace placeholder links.", "index.html#form-settings-title"]
        ];
        return issues;
    }

    function render() {
        const root = $("trust-review-panel"); if (!root) return;
        const list = $("trust-review-list"); const summary = $("trust-review-summary");
        const results = checks(); const passed = results.filter((item) => item[1]).length;
        summary.textContent = passed === results.length ? `Ready to publish — ${passed} of ${results.length} checks passed` : `${passed} of ${results.length} checks passed. Fix these items first.`;
        root.dataset.state = passed === results.length ? "ready" : "needs-attention";
        list.replaceChildren(...results.map(([label, pass, detail, target]) => {
            const li = document.createElement("li"); li.dataset.state = pass ? "pass" : "fix";
            li.innerHTML = `<div><strong>${escape(label)}</strong><small>${escape(pass ? "Passed" : detail)}</small></div>${pass ? "" : `<a href="${escape(target)}" data-fix-review>Fix now</a>`}`;
            return li;
        }));
        const publish = $("publish-anyway-btn"); if (publish) publish.disabled = false;
    }

    function mount() {
        if ($("trust-review-panel")) return;
        const anchor = document.querySelector(".launch-plan-panel") || document.querySelector(".publish-confidence-card");
        if (!anchor) return;
        const panel = document.createElement("section"); panel.id = "trust-review-panel"; panel.className = "trust-review-panel"; panel.innerHTML = `<div><p class="eyebrow-label">After generation</p><h3>Trust and accuracy review</h3><p id="trust-review-summary" role="status" aria-live="polite">Generate a draft to review it.</p></div><ol id="trust-review-list" class="trust-review-list"></ol><div class="trust-review-actions"><a class="matrix-action-btn variant-outline-row" href="business-profile.html">Edit Business profile</a><button id="publish-anyway-btn" class="matrix-action-btn variant-danger-text" type="button">Publish anyway</button></div>`; anchor.insertAdjacentElement("afterend", panel); render();
    }

    function syncChecklist() {
        const root = $("launch-checklist"); if (!root) return;
        const saved = read(checklistKey, {}) || {};
        const workspace = read(workspaceKey, {}) || {};
        if (workspace.deploymentHistory?.length) saved.publish = true;
        if (read("morrow-appointments-v1", []).length) saved.availability = true;
        root.querySelectorAll("input[data-check]").forEach((input) => { if (saved[input.dataset.check] === true) input.checked = true; });
        try { localStorage.setItem(checklistKey, JSON.stringify(saved)); } catch (_) {}
        const done = [...root.querySelectorAll("input[data-check]")].filter((input) => input.checked).length;
        if ($("launch-checklist-status")) $("launch-checklist-status").textContent = `${done} of 7 launch steps complete.`;
    }

    function bind() {
        mount(); syncChecklist();
        window.addEventListener("workspace:files-rendered", () => { mount(); render(); syncChecklist(); });
        window.addEventListener("workspace:deployment-complete", syncChecklist);
        window.addEventListener("storage", () => { render(); syncChecklist(); });
        document.addEventListener("click", (event) => {
            const fix = event.target.closest("[data-fix-review]");
            if (fix) { const target = fix.getAttribute("href"); if (target?.startsWith("index.html#")) { event.preventDefault(); document.querySelector(target.slice("index.html".length))?.scrollIntoView({ behavior: "smooth" }); } }
            if (event.target.closest("#publish-anyway-btn")) {
                if (!window.confirm("Some trust or accuracy checks are unresolved. Publish anyway only if you have reviewed the risks. Continue?")) return;
                const button = $("publish-site-btn"); if (button && !button.disabled) button.click(); else alert("Publishing is not available until the website has a valid deployment configuration.");
            }
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();