/**
 * Ambient types for the globals the workspace modules publish on `window`.
 *
 * Why this file exists: the editor loads plain scripts (no imports), so every
 * module talks to the others through `window`. Without these declarations a
 * type checker reports "property does not exist on type Window" for every
 * cross-module call, which buries real mistakes in noise.
 *
 * Accuracy policy: entries below are typed from the module that actually
 * defines them. Modules that have not been audited yet are declared loosely and
 * marked TODO rather than guessed at — a wrong signature is worse than a vague
 * one, because it makes correct code look broken.
 */

/** A generated or imported project: file path to file contents. */
type WorkspaceFiles = Record<string, string>;

/** One finding produced by a validation or audit pass. */
interface WorkspaceIssue {
    code: string;
    message: string;
    file?: string;
    target?: string;
    severity?: "blocking" | "warning" | "recommendation" | "error";
    category?: string;
}

/** Defined in workspace-content-safety.js */
interface WorkspaceContentSafety {
    /** True when `name` is a safe, relative project path. */
    validPath(name: unknown): boolean;
    /** Boundary check for generated or imported files. Never executes content. */
    validateFiles(
        files?: Record<string, unknown>,
        options?: { imported?: boolean }
    ): WorkspaceIssue[];
    /** Strips scripts, embeds, event handlers and unsafe URLs from imported HTML. */
    sanitizeImportedFiles(files?: Record<string, unknown>): WorkspaceFiles;
}

/** Defined in workspace-core.js */
interface WorkspaceCore {
    hash(value: unknown): string;
    manifest(files?: Record<string, unknown>): Record<string, { bytes: number; hash: string }>;
    diffFiles(before?: Record<string, unknown>, after?: Record<string, unknown>): Array<{
        name: string;
        before: { bytes: number; hash: string };
        after: { bytes: number; hash: string };
    }>;
    normalizePath(target: unknown): string;
    resolvePath(file: string, target: unknown): string;
    isExternalReference(target: unknown): boolean;
    brokenLocalReferences(files?: Record<string, unknown>): Array<{ file: string; target: string }>;
    validateBrief(input?: Record<string, unknown>): { valid: boolean; issues: Array<{ code: string; field: string }> };
    auditSite(files?: Record<string, unknown>): Record<string, unknown>;
    benchmarkFiles(files?: Record<string, unknown>): {
        scores: Record<string, number>;
        overall: number;
        publishable: boolean;
    };
}

/** Defined in workspace-audit.js (also exported for the server preflight). */
interface WorkspaceAudit {
    normalizePath(value: unknown): string;
    resolveLocalReference(sourceFile: string, value: unknown): string;
    referencesIn(sourceFile: string, content: unknown): Array<{
        source: string;
        target: string;
        raw: string;
        kind: string;
    }>;
    auditProject(files?: Record<string, unknown>): {
        issues: WorkspaceIssue[];
        references: Array<{ source: string; target: string }>;
        blocking: WorkspaceIssue[];
        warnings: WorkspaceIssue[];
        passed: boolean;
    };
    contrastRatio(foreground: unknown, background: unknown): number | null;
    auditRenderedDocument(documentNode: Document | null): {
        issues: WorkspaceIssue[];
        images: Array<Record<string, unknown>>;
        contrast: WorkspaceIssue[];
    };
}

/** Defined in script.js (exposeWorkspaceApi). */
interface WorkspaceApi {
    getState(): {
        files: WorkspaceFiles;
        form: Record<string, unknown>;
        projectName: string;
        projectId: string | null;
        previewMode: "desktop" | "tablet" | "mobile";
        dirty: boolean;
        deploymentHistory: Array<Record<string, unknown>>;
        generationManifest: Record<string, unknown> | null;
        repairLog: Array<Record<string, unknown>>;
        formTestRevision: string;
        projectSessionId: string;
        [key: string]: unknown;
    };
    setProjectId(id: string | null): void;
    setProjectName(name: string): void;
    markDirty(): void;
    markClean(): void;
    setFormTestRevision(revision: string): void;
    setHostingProvider(provider: string): void;
    applySnapshot(snapshot?: Record<string, unknown>, options?: { dirty?: boolean; replaceContext?: boolean }): void;
    clearProjectContext(options?: { persist?: boolean; announce?: boolean }): void;
}

/** Defined in app-loader.js */
interface WorkspaceLoader {
    groups: { foundation: string[]; quality: string[]; startup: string[]; optional: string[] };
    load(source: string, options?: { attempts?: number; timeoutMs?: number }): Promise<HTMLScriptElement>;
    loadList(sources: string[], label: string): Promise<HTMLScriptElement[]>;
    loadParallelList(sources: string[], label: string): Promise<HTMLScriptElement[]>;
    yieldToBrowser(delay?: number): Promise<void>;
}

interface Window {
    workspaceContentSafety?: WorkspaceContentSafety;
    workspaceCore?: WorkspaceCore;
    workspaceAudit?: WorkspaceAudit;
    workspaceAPI?: WorkspaceApi;
    workspaceLoader?: WorkspaceLoader;

    /**
     * TODO: type these from their defining modules as each one is audited.
     * Left permissive on purpose so unaudited call sites are not reported as
     * errors on the strength of a guess.
     */
    workspaceCRM?: any;
    workspaceRelease?: any;
    workspaceDomain?: any;
    workspaceDialog?: any;
    workspaceGenerator?: any;
    workspaceOriginality?: {
        visualFingerprint(imageData: ImageData | { width: number; height: number; data: Uint8ClampedArray }): Record<string, unknown> | null;
        fingerprint(plan: Record<string, unknown>, design: Record<string, unknown>, visual?: Record<string, unknown> | null, components?: Record<string, unknown>): Record<string, unknown>;
        compare(left: Record<string, unknown>, right: Record<string, unknown>): { overall: number; structural: number; stylistic: number; visual: number; similarDimensions: string[] };
        readHistory(projectId?: string): Array<Record<string, unknown>>;
    };
    workspaceRegeneration?: {
        normalizeControls(value?: Record<string, unknown>): Record<string, unknown>;
        request(current?: Record<string, unknown>, controls?: Record<string, unknown>): Record<string, unknown>;
        read(projectId?: string): { cursor: number; checkpoints: Array<Record<string, unknown>> };
        undo(projectId?: string): Record<string, unknown> | null;
        redo(projectId?: string): Record<string, unknown> | null;
        compare(projectId?: string, ids?: string[]): Array<Record<string, unknown>>;
    };
    workspaceAI?: {
        generate(data?: Record<string, unknown>, options?: { fallback?: boolean; timeoutMs?: number }): Promise<{ success: boolean; files: WorkspaceFiles; provider: string; repairPasses: number; diagnostics: WorkspaceIssue[]; fallbackReason?: string }>;
        repair(files: WorkspaceFiles, diagnostics?: WorkspaceIssue[], data?: Record<string, unknown>, options?: { timeoutMs?: number }): Promise<{ success: boolean; files: WorkspaceFiles; provider: string; repairPasses: number; diagnostics: WorkspaceIssue[] }>;
        cancel(): void;
        isPending(): boolean;
    };
    workspaceFields?: any;
    workspaceConfig?: any;
    workspacePages?: any;
    workspacePreview?: any;
    workspacePreviewController?: any;
    workspaceFormatter?: any;
    workspaceResponsive?: any;
    workspaceShellAudit?: any;
    workspaceQuality?: any;
    workspaceQualityModel?: any;
    workspaceValidation?: any;
    workspaceState?: any;
    workspaceSchema?: any;
    workspaceFixes?: any;
    siteGenerator?: any;
    profileService?: any;
    businessProfile?: any;
    businessHub?: any;
    projectHealth?: any;
    supabaseWorkspace?: any;
    conversionLoop?: any;
    websiteAuditContract?: any;
    adStudio?: any;
}
