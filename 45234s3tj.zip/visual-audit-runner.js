"use strict";

// Server/local visual evidence runner. It uses the installed Playwright runtime
// and never treats a screenshot as proof of conversion performance.
const fs = require("node:fs/promises");
const path = require("node:path");
const dns = require("node:dns").promises;
const net = require("node:net");
const { chromium } = require("@playwright/test");

const DEFAULT_VIEWPORTS = Object.freeze([
    { name: "mobile-320", width: 320, height: 720, deviceScaleFactor: 1 },
    { name: "mobile-360", width: 360, height: 800, deviceScaleFactor: 1 },
    { name: "tablet", width: 768, height: 1024, deviceScaleFactor: 1 },
    { name: "laptop", width: 1024, height: 768, deviceScaleFactor: 1 },
    { name: "desktop", width: 1440, height: 900, deviceScaleFactor: 1 }
]);
function privateAddress(address) {
    const value = String(address || "").toLowerCase();
    const mapped = value.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/);
    if (mapped) return privateAddress(mapped[1]);
    if (net.isIP(value) === 4) {
        const [a, b] = value.split(".").map(Number);
        return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a >= 224;
    }
    return value === "::" || value === "::1" || value.startsWith("fc") || value.startsWith("fd") || /^fe[89ab]/.test(value) || value.startsWith("ff");
}

async function safeUrl(input) {
    const url = new URL(String(input || "").trim());
    if (!/^https?:$/.test(url.protocol) || url.username || url.password || url.port || url.hash) throw new Error("Only public HTTP(S) URLs are supported.");
    const host = url.hostname.toLowerCase();
    if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal") || host === "metadata.google.internal") throw new Error("Private hosts are not allowed.");
    const addresses = await dns.lookup(host, { all: true });
    if (!addresses.length || addresses.some((entry) => privateAddress(entry.address))) throw new Error("Private network addresses are not allowed.");
    url.hostname = host;
    return url.href;
}

async function collectMetrics(page, viewport) {
    return page.evaluate(({ width, height }) => {
        const nodes = [...document.querySelectorAll("a,button,input[type=submit],input[type=button]")];
        const ctas = nodes.filter((node) => /book|booking|quote|contact|call|enquir|start|get|schedule|buy|shop/i.test(`${node.textContent || ""} ${node.getAttribute("aria-label") || ""}`));
        const visible = (node) => { const rect = node.getBoundingClientRect(); return rect.width > 0 && rect.height > 0 && rect.top < height && rect.bottom > 0; };
        const colors = [...document.querySelectorAll("body *")].slice(0, 500).map((node) => getComputedStyle(node)).filter((style) => style.color && style.backgroundColor).slice(0, 150);
        const lowContrastSignals = colors.filter((style) => style.color === style.backgroundColor).length;
        const visibleElements = [...document.body.querySelectorAll("*")].filter((node) => {
            const rect = node.getBoundingClientRect();
            const style = getComputedStyle(node);
            return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
        });
        const issue = (code, node, detail = {}) => ({ code, selector: node?.id ? `#${node.id}` : node?.classList?.length ? `${node.tagName.toLowerCase()}.${[...node.classList].slice(0, 2).join(".")}` : node?.tagName?.toLowerCase() || "document", ...detail });
        const issues = [];
        if (document.documentElement.scrollWidth > width + 4) issues.push(issue("HORIZONTAL_OVERFLOW", document.documentElement, { overflowPx: document.documentElement.scrollWidth - width }));
        nodes.forEach((node) => { const rect = node.getBoundingClientRect(); if (rect.width > 0 && rect.height > 0 && (rect.width < 44 || rect.height < 44)) issues.push(issue("TAP_TARGET_TOO_SMALL", node, { size: `${Math.round(rect.width)}x${Math.round(rect.height)}` })); });
        [...document.querySelectorAll("h1,h2,h3")].forEach((node) => { const rect = node.getBoundingClientRect(); const lineHeight = parseFloat(getComputedStyle(node).lineHeight) || 1; const lines = Math.round(rect.height / lineHeight); if (lines > 5) issues.push(issue("HEADING_EXCESSIVE_LINES", node, { lines })); });
        [...document.images].forEach((node) => { const rect = node.getBoundingClientRect(); if (node.naturalWidth && Math.abs((rect.width / rect.height) - (node.naturalWidth / node.naturalHeight)) > .12) issues.push(issue("IMAGE_DISTORTED", node)); });
        const sticky = visibleElements.filter((node) => ["fixed", "sticky"].includes(getComputedStyle(node).position));
        sticky.forEach((node) => { const rect = node.getBoundingClientRect(); if (rect.top <= 0 && rect.bottom > height * .25) issues.push(issue("STICKY_OBSTRUCTION", node, { coveredPx: Math.round(rect.height) })); });
        const nav = document.querySelector("nav");
        if (nav && nav.scrollWidth > nav.clientWidth + 2) issues.push(issue("NAV_OVERFLOW", nav, { overflowPx: nav.scrollWidth - nav.clientWidth }));
        return {
            viewport: { width, height },
            issues: issues.slice(0, 100),
            title: document.title || "",
            metaDescription: document.querySelector('meta[name="description"]')?.content || "",
            headingCount: document.querySelectorAll("h1,h2,h3").length,
            h1Count: document.querySelectorAll("h1").length,
            ctaCount: ctas.length,
            ctaVisibleInFirstViewport: ctas.some(visible),
            formCount: document.querySelectorAll("form").length,
            linkCount: document.querySelectorAll("a[href]").length,
            imageCount: document.images.length,
            unlabeledImageCount: [...document.images].filter((image) => !image.alt).length,
            horizontalOverflowPx: Math.max(0, document.documentElement.scrollWidth - width),
            lowContrastSignals,
            bodyTextLength: (document.body?.innerText || "").trim().length
        };
    }, viewport);
}

function score(metrics = {}) {
    let value = 45;
    value += Math.min(15, Number(metrics.headingCount || 0) * 3);
    value += Math.min(20, Number(metrics.ctaCount || 0) * 7);
    value += metrics.ctaVisibleInFirstViewport ? 10 : 0;
    value += metrics.formCount > 0 ? 5 : 0;
    value += metrics.metaDescription ? 5 : 0;
    value -= metrics.horizontalOverflowPx > 4 ? 20 : 0;
    value -= metrics.unlabeledImageCount > 0 ? Math.min(10, metrics.unlabeledImageCount * 2) : 0;
    value -= metrics.lowContrastSignals > 0 ? Math.min(10, metrics.lowContrastSignals) : 0;
    return Math.max(0, Math.min(100, Math.round(value)));
}

async function captureVisualAudit(input, options = {}) {
    const url = await safeUrl(input);
    const outputDir = path.resolve(options.outputDir || path.join(process.cwd(), "artifacts", "visual-audits"));
    const viewports = Array.isArray(options.viewports) && options.viewports.length ? options.viewports : DEFAULT_VIEWPORTS;
    await fs.mkdir(outputDir, { recursive: true });
    const browser = await chromium.launch({ headless: true });
    const evidence = [];
    try {
        for (const viewport of viewports) {
            const context = await browser.newContext({ viewport: { width: viewport.width, height: viewport.height }, deviceScaleFactor: viewport.deviceScaleFactor || 1, reducedMotion: "reduce" });
            const page = await context.newPage();
            const startedAt = Date.now();
            let response;
            try {
                response = await page.goto(url, { waitUntil: "networkidle", timeout: Number(options.timeoutMs || 30_000) });
                await page.evaluate(() => document.fonts?.ready);
                const metrics = await collectMetrics(page, viewport);
                const filename = `${viewport.name}-${Date.now()}.png`;
                const screenshotPath = path.join(outputDir, filename);
                await page.screenshot({ path: screenshotPath, fullPage: true, animations: "disabled" });
                evidence.push({ viewport: viewport.name, url: page.url(), httpStatus: response?.status() || null, loadMs: Date.now() - startedAt, metrics, score: score(metrics), screenshotPath, capturedAt: new Date().toISOString() });
            } catch (error) {
                evidence.push({ viewport: viewport.name, url, error: String(error?.message || error), capturedAt: new Date().toISOString() });
            } finally { await context.close(); }
        }
    } finally { await browser.close(); }
    const report = { provider: "playwright", status: evidence.some((item) => item.metrics) ? "complete" : "failed", sourceUrl: url, evidence, capturedAt: new Date().toISOString() };
    await fs.writeFile(path.join(outputDir, "report.json"), JSON.stringify(report, null, 2));
    return report;
}

function compareVisualAudits(before = {}, after = {}) {
    const byViewport = new Map((after.evidence || []).map((item) => [item.viewport, item]));
    return (before.evidence || []).map((oldItem) => {
        const newItem = byViewport.get(oldItem.viewport) || {};
        const oldMetrics = oldItem.metrics || {};
        const newMetrics = newItem.metrics || {};
        return {
            viewport: oldItem.viewport,
            scoreDelta: Number(newItem.score || 0) - Number(oldItem.score || 0),
            overflowDeltaPx: Number(newMetrics.horizontalOverflowPx || 0) - Number(oldMetrics.horizontalOverflowPx || 0),
            ctaVisibilityImproved: Boolean(newMetrics.ctaVisibleInFirstViewport) && !Boolean(oldMetrics.ctaVisibleInFirstViewport),
            unlabeledImagesDelta: Number(newMetrics.unlabeledImageCount || 0) - Number(oldMetrics.unlabeledImageCount || 0),
            before: oldItem,
            after: newItem
        };
    });
}

module.exports = { DEFAULT_VIEWPORTS, safeUrl, collectMetrics, score, captureVisualAudit, compareVisualAudits };

if (require.main === module) {
    const [target, outputDir] = process.argv.slice(2);
    if (!target) {
        console.error("A public website URL is required.");
        process.exitCode = 2;
    } else {
        captureVisualAudit(target, { outputDir }).then((report) => {
            process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
            if (report.status !== "complete") process.exitCode = 1;
        }).catch((error) => { console.error(error.message || error); process.exitCode = 1; });
    }
}
