"use strict";

// Runs the same Playwright audit against an original and proposed site, then
// writes evidence that can be attached to a website_audits record and revision.
const fs = require("node:fs/promises");
const path = require("node:path");
const { captureVisualAudit, compareVisualAudits } = require("./visual-audit-runner.js");

function option(name, fallback = "") {
    const index = process.argv.indexOf(`--${name}`);
    return index >= 0 ? String(process.argv[index + 1] || fallback) : fallback;
}

function required(name) {
    const value = option(name);
    if (!value) throw new Error(`Missing --${name}.`);
    return value;
}

async function runWorkflow(options = {}) {
    const baselineUrl = options.baselineUrl || required("baseline");
    const proposedUrl = options.proposedUrl || required("proposed");
    const outputDir = path.resolve(options.outputDir || option("output", path.join(process.cwd(), "artifacts", "visual-audits")));
    const baseline = await captureVisualAudit(baselineUrl, { outputDir: path.join(outputDir, "baseline") });
    const proposed = await captureVisualAudit(proposedUrl, { outputDir: path.join(outputDir, "proposed") });
    const comparison = compareVisualAudits(baseline, proposed);
    const uploadedArtifacts = new Map();
    const artifactUrl = async (filePath, phase, viewport) => {
        if (!filePath) return filePath;
        if (typeof options.uploadArtifact === "function") {
            const uploaded = await options.uploadArtifact(filePath, { phase, viewport });
            if (uploaded) {
                uploadedArtifacts.set(filePath, uploaded);
                return uploaded;
            }
        }
        if (!options.artifactBaseUrl) return filePath;
        const relative = path.relative(outputDir, filePath).split(path.sep).join("/");
        return `${String(options.artifactBaseUrl).replace(/\/$/, "")}/${relative}`;
    };
    const screenshotReferences = async (evidence, phase) => Promise.all((evidence || []).map(async ({ viewport, screenshotPath }) => ({
        viewport,
        screenshotPath: await artifactUrl(screenshotPath, phase, viewport)
    })));
    const result = {
        provider: "playwright", 
        status: baseline.status === "complete" && proposed.status === "complete" ? "complete" : "needs-review",
        baseline,
        proposed,
        comparison,
        auditPatch: {
            visual: { baseline, proposed, comparison },
            checkedAt: new Date().toISOString(),
            state: baseline.status === "complete" && proposed.status === "complete" ? "audit-complete" : "needs-review"
        },
        revisionPatch: {
            beforeScores: Object.fromEntries((baseline.evidence || []).map((item) => [item.viewport, item.score ?? null])),
            afterScores: Object.fromEntries((proposed.evidence || []).map((item) => [item.viewport, item.score ?? null])),
            screenshots: {
                before: await screenshotReferences(baseline.evidence, "baseline"),
                after: await screenshotReferences(proposed.evidence, "proposed")
            },
            validation: {
                visual: comparison,
                visualEvidence: "complete"
            }
        },
        generatedAt: new Date().toISOString()
    };
    await fs.mkdir(outputDir, { recursive: true });
    await fs.writeFile(path.join(outputDir, "conversion-report.json"), JSON.stringify(result, null, 2));
    return result;
}

module.exports = { runWorkflow };

if (require.main === module) {
    runWorkflow().then((result) => {
        process.stdout.write(`${JSON.stringify({ status: result.status, report: path.resolve(option("output", path.join(process.cwd(), "artifacts", "visual-audits")), "conversion-report.json") }, null, 2)}\n`);
        if (result.status !== "complete") process.exitCode = 1;
    }).catch((error) => {
        console.error(error.message || error);
        process.exitCode = 2;
    });
}
