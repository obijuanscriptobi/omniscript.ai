"use strict";

// Browser-safe visual evidence. Cross-origin iframes cannot be rasterized here;
// this records reproducible viewport/DOM evidence instead of inventing pixels.
(() => {
    function score(documentRef = document, viewport = {}) {
        const width = Number(viewport.width || window.innerWidth || 1280);
        const height = Number(viewport.height || window.innerHeight || 800);
        const body = documentRef.body;
        const headings = documentRef.querySelectorAll("h1,h2,h3").length;
        const links = [...documentRef.querySelectorAll("a,button")];
        const ctas = links.filter((node) => /book|quote|contact|call|enquir|start|get/i.test(node.textContent || node.getAttribute("aria-label") || ""));
        const forms = [...documentRef.querySelectorAll("form")];
        const overflow = body ? Math.max(0, body.scrollWidth - width) : 0;
        const scoreValue = Math.max(0, Math.min(100, 35 + Math.min(headings, 6) * 5 + Math.min(ctas.length, 3) * 10 + (forms.length ? 10 : 0) - (overflow > 4 ? 25 : 0)));
        return {
            viewport: { width, height },
            headingCount: headings,
            ctaCount: ctas.length,
            formCount: forms.length,
            horizontalOverflowPx: overflow,
            ctaVisibleInFirstViewport: ctas.some((node) => { const rect = node.getBoundingClientRect(); return rect.top >= 0 && rect.top <= height; }),
            score: Math.round(scoreValue),
            capturedAt: new Date().toISOString()
        };
    }
    function compare(before = {}, after = {}) {
        const delta = (key) => Number(after[key] || 0) - Number(before[key] || 0);
        return { scoreDelta: delta("score"), ctaDelta: delta("ctaCount"), overflowDelta: delta("horizontalOverflowPx"), ctaVisibilityImproved: Boolean(after.ctaVisibleInFirstViewport) && !Boolean(before.ctaVisibleInFirstViewport) };
    }
    window.visualEvidence = Object.freeze({ score, compare });
})();
