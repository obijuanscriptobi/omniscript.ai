"use strict";

// Schema-driven website planning and deterministic assembly. The model may
// choose registered components and write bounded editorial copy, but it cannot
// emit executable website code or invent evidence-backed claims.
(() => {
    const SYSTEMS = new Set(["premium", "modern", "bold", "warm"]);
    const GOALS = new Set(["quote", "call", "consultation", "reservation", "purchase", "enquiry", "booking"]);
    const SECTION_LIMIT = 14;

    const component = (definition) => Object.freeze({
        compatibleGoals: [...GOALS],
        requiredFacts: [],
        interactions: [],
        accessibilityChecks: ["semantic-structure", "keyboard-focus"],
        performanceCost: 1,
        geometry: "flow",
        ...definition
    });

    const COMPONENTS = Object.freeze(Object.fromEntries(Object.entries({
        "navigation-simple-v1": component({ kind: "navigation", required: [], interactions: ["mobile-navigation"], accessibilityChecks: ["navigation-label", "keyboard-focus", "expanded-state"], geometry: "navigation" }),
        "navigation-offset-v1": component({ kind: "navigation", required: [], interactions: ["mobile-navigation"], accessibilityChecks: ["navigation-label", "keyboard-focus", "expanded-state"], geometry: "navigation" }),
        "hero-split-v2": { kind: "hero", required: ["heading", "summary", "primaryAction"], allowedFactTypes: ["description", "audience", "service", "product", "credential", "statistic", "guarantee", "location"] },
        "hero-centered-v1": { kind: "hero", required: ["heading", "summary", "primaryAction"], allowedFactTypes: ["description", "audience", "service", "product", "credential", "statistic", "guarantee", "location"] },
        "hero-poster-v1": { kind: "hero", required: ["heading", "summary", "primaryAction"], allowedFactTypes: ["description", "audience", "service", "product", "credential", "statistic", "guarantee", "location"] },
        "hero-editorial-v1": { kind: "hero", required: ["heading", "summary", "primaryAction"], allowedFactTypes: ["description", "audience", "service", "product", "credential", "statistic", "guarantee", "location"] },
        "service-grid-v1": { kind: "services", required: ["heading"], allowedFactTypes: ["service"] },
        "service-list-v1": { kind: "services", required: ["heading"], allowedFactTypes: ["service"] },
        "product-grid-v1": { kind: "products", required: ["heading"], allowedFactTypes: ["product"] },
        "product-feature-v1": { kind: "products", required: ["heading"], allowedFactTypes: ["product"] },
        "testimonial-grid-v1": { kind: "testimonials", required: ["heading"], evidence: "testimonials", allowedFactTypes: ["testimonial"] },
        "pricing-cards-v1": { kind: "pricing", required: ["heading"], evidence: "prices", allowedFactTypes: ["price"] },
        "faq-disclosure-v1": { kind: "faq", required: ["heading", "items"] },
        "gallery-grid-v1": { kind: "gallery", required: ["heading"], evidence: "assets", allowedFactTypes: ["asset"] },
        "process-steps-v1": { kind: "process", required: ["heading", "items"] },
        "team-grid-v1": { kind: "team", required: ["heading"], evidence: "team", allowedFactTypes: ["team"] },
        "contact-panel-v1": { kind: "contact", required: ["heading"] },
        "booking-panel-v1": { kind: "contact", required: ["heading"] },
        "reservation-panel-v1": { kind: "contact", required: ["heading"] },
        "sales-enquiry-v1": { kind: "contact", required: ["heading"] },
        "footer-simple-v1": { kind: "footer", required: [] },
        "footer-editorial-v1": { kind: "footer", required: [] }
    }).map(([id, definition]) => [id, Object.isFrozen(definition) ? definition : component(definition)])));

    const PATTERNS = Object.freeze({
        "local-service": { goal: "quote", order: ["navigation", "hero", "services", "process", "faq", "contact", "footer"], proofAfter: "hero", mobileAction: true },
        professional: { goal: "consultation", order: ["navigation", "hero", "services", "process", "testimonials", "faq", "contact", "footer"], proofAfter: "services", mobileAction: true },
        restaurant: { goal: "reservation", order: ["navigation", "hero", "products", "gallery", "faq", "contact", "footer"], proofAfter: "hero", mobileAction: true },
        retail: { goal: "purchase", order: ["navigation", "hero", "products", "gallery", "faq", "contact", "footer"], proofAfter: "products", mobileAction: false },
        creative: { goal: "enquiry", order: ["navigation", "hero", "gallery", "services", "process", "contact", "footer"], proofAfter: "gallery", mobileAction: true },
        wellness: { goal: "booking", order: ["navigation", "hero", "services", "process", "testimonials", "faq", "contact", "footer"], proofAfter: "services", mobileAction: true }
    });

    const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[character]));
    const plain = (value, maximum = 240) => String(value ?? "").replace(/[<>\u0000-\u001f]/g, " ").replace(/\s+/g, " ").trim().slice(0, maximum);
    const list = (value, maximum = 12) => Array.isArray(value) ? value.slice(0, maximum) : [];
    const slug = (value, fallback = "item") => plain(value, 80).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || fallback;
    const object = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};

    function entries(value, prefix, fields = {}) {
        return list(value).map((item, index) => {
            const source = typeof item === "string" ? { name: item } : object(item);
            const name = plain(source.name || source.title || source.label, 100);
            const result = { id: `${prefix}-${index + 1}`, type: prefix, name };
            Object.entries(fields).forEach(([key, limit]) => { result[key] = plain(source[key], limit); });
            return result;
        }).filter((item) => item.name);
    }

    function normalizeFacts(input = {}) {
        const source = object(input.business || input);
        const assets = list(input.assets || source.assets, 40).map((asset, index) => {
            const item = object(asset);
            const url = plain(item.url || item.src, 500);
            return /^https:\/\//i.test(url) ? { id: `asset-${index + 1}`, type: "asset", assetType: plain(item.type, 40), url, alt: plain(item.alt || item.description, 160) } : null;
        }).filter(Boolean);
        const contact = object(source.contact);
        const facts = {
            businessName: plain(source.name || source.businessName, 100) || "Your business",
            businessType: Object.hasOwn(PATTERNS, source.type) ? source.type : "local-service",
            description: plain(source.description || source.offer || source.summary, 360),
            audience: plain(source.audience, 180),
            services: entries(source.services || source.offerings, "service", { description: 240 }),
            products: entries(source.products || source.menu, "product", { description: 240, price: 40 }),
            prices: entries(source.prices || source.pricing, "price", { description: 180, price: 40 }),
            credentials: entries(source.credentials, "credential", { description: 180 }),
            statistics: entries(source.statistics || source.results, "statistic", { description: 180, value: 80 }),
            guarantees: entries(source.guarantees, "guarantee", { description: 180 }),
            testimonials: entries(source.testimonials, "testimonial", { quote: 320, role: 100 }),
            team: entries(source.team, "team", { role: 100, bio: 240 }),
            locations: entries(source.locations || (source.location ? [source.location] : []), "location", { address: 180 }),
            openingHours: entries(source.openingHours || source.hours, "hours", { value: 100 }),
            contact: {
                email: plain(contact.email || source.email, 120),
                phone: plain(contact.phone || source.phone, 60),
                address: plain(contact.address || source.address, 180)
            },
            assets
        };
        const missing = [];
        ["description", "audience"].forEach((key) => { if (!facts[key]) missing.push(key); });
        ["services", "products", "credentials", "statistics", "guarantees", "testimonials", "prices", "team", "locations", "openingHours", "assets"].forEach((key) => { if (!facts[key].length) missing.push(key); });
        if (!facts.contact.email && !facts.contact.phone) missing.push("contact method");
        const records = [
            ...(facts.description ? [{ id: "description-1", type: "description", value: facts.description }] : []),
            ...(facts.audience ? [{ id: "audience-1", type: "audience", value: facts.audience }] : []),
            ...facts.services, ...facts.products, ...facts.prices, ...facts.credentials, ...facts.statistics, ...facts.guarantees, ...facts.testimonials,
            ...facts.team, ...facts.locations, ...facts.openingHours, ...facts.assets
        ].map((item) => Object.freeze({ ...item, evidenceLevel: "confirmed", source: "business-facts" }));
        return Object.freeze({
            ...facts,
            missing: Object.freeze(missing),
            factIds: Object.freeze(records.map((item) => item.id)),
            factIndex: Object.freeze(Object.fromEntries(records.map((item) => [item.id, Object.freeze({ ...item })])))
        });
    }

    function defaultPlan(facts, design = {}) {
        const pattern = PATTERNS[facts.businessType] || PATTERNS["local-service"];
        const goal = GOALS.has(design.conversionGoal) ? design.conversionGoal : pattern.goal;
        const action = plain(design.primaryAction, 50) || ({ quote: "Request a quote", call: "Call us", consultation: "Book a consultation", reservation: "Make a reservation", purchase: "Explore products", enquiry: "Start an enquiry", booking: "Book an appointment" }[goal]);
        const genome = object(design.genome);
        const available = {
            navigation: genome.navigation === "offset-minimal" ? "navigation-offset-v1" : "navigation-simple-v1",
            hero: ({ "centered-statement": "hero-centered-v1", "stacked-poster": "hero-poster-v1", "asymmetric-editorial": "hero-editorial-v1" }[genome.hero]) || "hero-split-v2",
            services: genome.grid === "compact" ? "service-list-v1" : "service-grid-v1",
            products: genome.grid === "featured-first" ? "product-feature-v1" : "product-grid-v1",
            testimonials: facts.testimonials.length ? "testimonial-grid-v1" : "",
            pricing: facts.prices.length ? "pricing-cards-v1" : "", gallery: facts.assets.length ? "gallery-grid-v1" : "",
            process: "process-steps-v1", faq: "faq-disclosure-v1", team: facts.team.length ? "team-grid-v1" : "",
            contact: goal === "booking" ? "booking-panel-v1" : goal === "reservation" ? "reservation-panel-v1" : goal === "purchase" ? "sales-enquiry-v1" : "contact-panel-v1",
            footer: genome.rhythm === "chaptered" ? "footer-editorial-v1" : "footer-simple-v1"
        };
        const evidenceIds = (kind) => ({
            hero: [facts.description && "description-1", facts.audience && "audience-1"].filter(Boolean),
            services: facts.services.map((item) => item.id), products: facts.products.map((item) => item.id),
            testimonials: facts.testimonials.map((item) => item.id), pricing: facts.prices.map((item) => item.id),
            gallery: facts.assets.map((item) => item.id), team: facts.team.map((item) => item.id)
        }[kind] || []);
        const section = (kind) => ({
            component: available[kind],
            content: kind === "hero" ? { heading: facts.description || `${facts.businessName}, focused on what matters`, summary: facts.audience ? `A clear path for ${facts.audience}.` : "Explore the offer and choose the next step that works for you.", primaryAction: action, factIds: evidenceIds(kind) }
                : kind === "process" ? { heading: "A clear way forward", items: [{ title: "Tell us what you need", text: "Share the essentials through the enquiry form." }, { title: "Review the next step", text: "We will use the details you provide to respond." }, { title: "Move forward with clarity", text: "Choose whether the proposed next step suits you." }] }
                    : kind === "faq" ? { heading: "Common questions", items: [{ title: "How do I get started?", text: `Use the ${action.toLowerCase()} form and provide the details relevant to your request.` }, { title: "What happens after I enquire?", text: "The team can review your submitted information and respond using the contact details you provide." }] }
                        : ["navigation", "footer"].includes(kind) ? {}
                            : { heading: ({ services: "What we offer", products: "Explore the range", testimonials: "What clients shared", pricing: "Pricing", gallery: "Selected highlights", team: "Meet the team", contact: action }[kind] || "Learn more"), factIds: evidenceIds(kind) }
        });
        const sections = pattern.order.map(section).filter((item) => item.component);
        return { version: 1, designSystem: SYSTEMS.has(design.system) ? design.system : "premium", conversionGoal: goal, sections };
    }

    function validatePlan(raw, context = {}) {
        const facts = context.facts || normalizeFacts(context);
        const factIndex = facts.factIndex || Object.fromEntries([
            ...(facts.services || []), ...(facts.products || []), ...(facts.prices || []), ...(facts.credentials || []), ...(facts.statistics || []), ...(facts.guarantees || []),
            ...(facts.testimonials || []), ...(facts.team || []), ...(facts.locations || []), ...(facts.openingHours || []), ...(facts.assets || [])
        ].map((item) => [item.id, item]));
        const errors = [];
        const plan = object(raw);
        const allowedTop = ["version", "designSystem", "conversionGoal", "sections"];
        if (Object.keys(plan).some((key) => !allowedTop.includes(key))) errors.push("PLAN_UNKNOWN_PROPERTY");
        if (plan.version !== 1) errors.push("PLAN_VERSION_INVALID");
        if (!SYSTEMS.has(plan.designSystem)) errors.push("PLAN_DESIGN_SYSTEM_INVALID");
        if (!GOALS.has(plan.conversionGoal)) errors.push("PLAN_CONVERSION_GOAL_INVALID");
        if (!Array.isArray(plan.sections) || plan.sections.length < 4 || plan.sections.length > SECTION_LIMIT) errors.push("PLAN_SECTION_COUNT_INVALID");
        const kinds = [];
        list(plan.sections, SECTION_LIMIT + 1).forEach((section, index) => {
            const item = object(section);
            if (Object.keys(item).some((key) => !["component", "content"].includes(key))) errors.push(`SECTION_${index}_UNKNOWN_PROPERTY`);
            const definition = COMPONENTS[item.component];
            if (!definition) { errors.push(`SECTION_${index}_COMPONENT_INVALID`); return; }
            kinds.push(definition.kind);
            const content = object(item.content);
            if (Object.keys(content).some((key) => !["heading", "summary", "primaryAction", "factIds", "items"].includes(key))) errors.push(`SECTION_${index}_CONTENT_INVALID`);
            const sectionFactIds = Array.isArray(content.factIds) ? content.factIds : [];
            if (content.factIds !== undefined && (!Array.isArray(content.factIds) || content.factIds.length > 20)) errors.push(`SECTION_${index}_FACT_IDS_INVALID`);
            sectionFactIds.forEach((factId) => {
                const fact = factIndex[factId];
                if (!fact) errors.push(`SECTION_${index}_FACT_UNKNOWN`);
                else if (definition.allowedFactTypes && !definition.allowedFactTypes.includes(fact.type)) errors.push(`SECTION_${index}_FACT_INCOMPATIBLE`);
            });
            if (definition.evidence && !sectionFactIds.length) errors.push(`SECTION_${index}_FACT_REFERENCE_REQUIRED`);
            definition.required.forEach((key) => {
                if (key === "items" ? !Array.isArray(content.items) || !content.items.length : !plain(content[key], key === "summary" ? 360 : 100)) errors.push(`SECTION_${index}_${key.toUpperCase()}_REQUIRED`);
            });
            if (plain(content.heading, 100) !== String(content.heading || "").trim()) errors.push(`SECTION_${index}_HEADING_TOO_LONG`);
            if (plain(content.summary, 360) !== String(content.summary || "").trim()) errors.push(`SECTION_${index}_SUMMARY_TOO_LONG`);
            const claimText = `${content.heading || ""} ${content.summary || ""}`;
            const sensitiveClaim = /\b(?:best|leading|guaranteed|award(?:-winning)?|certified|licensed|insured|\d+\s*(?:years|customers|projects)|\$\d+|cure|treat|diagnos|legal advice|financial return|risk-free|safe for everyone)\b/i;
            if (sensitiveClaim.test(claimText) && !sectionFactIds.length) errors.push(`SECTION_${index}_SENSITIVE_CLAIM_UNREFERENCED`);
            if (/\b(?:cure|treat|diagnos|legal advice|financial return|risk-free|safe for everyone)\b/i.test(claimText) && !sectionFactIds.some((id) => ["credential", "statistic", "guarantee"].includes(factIndex[id]?.type) && factIndex[id]?.evidenceLevel === "confirmed")) errors.push(`SECTION_${index}_REGULATED_CLAIM_EVIDENCE_REQUIRED`);
            if (content.items !== undefined) {
                if (!Array.isArray(content.items) || content.items.length > 8) errors.push(`SECTION_${index}_ITEMS_INVALID`);
                list(content.items, 9).forEach((entry) => {
                    const row = object(entry);
                    if (Object.keys(row).some((key) => !["factId", "title", "text"].includes(key)) || !plain(row.title, 100) || !plain(row.text, 320)) errors.push(`SECTION_${index}_ITEM_INVALID`);
                    if (row.factId) {
                        const fact = factIndex[row.factId];
                        if (!fact) errors.push(`SECTION_${index}_ITEM_FACT_UNKNOWN`);
                        else if (definition.allowedFactTypes && !definition.allowedFactTypes.includes(fact.type)) errors.push(`SECTION_${index}_ITEM_FACT_INCOMPATIBLE`);
                    }
                    if (/\b(?:best|leading|guaranteed|award(?:-winning)?|certified|licensed|insured|\d+\s*(?:years|customers|projects)|\$\d+)\b/i.test(`${row.title || ""} ${row.text || ""}`) && !row.factId) errors.push(`SECTION_${index}_SENSITIVE_CLAIM_UNREFERENCED`);
                });
            }
            if (definition.evidence && !facts[definition.evidence]?.length) errors.push(`SECTION_${index}_EVIDENCE_MISSING`);
        });
        if (kinds.filter((kind) => kind === "hero").length !== 1) errors.push("PLAN_HERO_COUNT_INVALID");
        if (kinds.filter((kind) => kind === "navigation").length !== 1 || kinds.filter((kind) => kind === "footer").length !== 1) errors.push("PLAN_SHELL_INVALID");
        if (!kinds.includes("contact")) errors.push("PLAN_PRIMARY_CONVERSION_MISSING");
        if (kinds[0] !== "navigation" || kinds[1] !== "hero" || kinds.at(-1) !== "footer") errors.push("PLAN_SECTION_ORDER_INVALID");
        const expectedContact = { booking: "booking-panel-v1", reservation: "reservation-panel-v1", purchase: "sales-enquiry-v1" }[plan.conversionGoal];
        const contactComponents = list(plan.sections).filter((section) => COMPONENTS[section.component]?.kind === "contact").map((section) => section.component);
        if (contactComponents.length !== 1 || (expectedContact && contactComponents[0] !== expectedContact)) errors.push("PLAN_CONVERSION_ROUTE_INCOMPATIBLE");
        if (kinds.filter((kind) => ["services", "products", "pricing", "testimonials", "team"].includes(kind)).some((kind, index, rows) => rows[index - 1] === kind)) errors.push("PLAN_REPEATED_GEOMETRY");
        const primaryActions = new Set(list(plan.sections).map((section) => plain(section?.content?.primaryAction, 50)).filter(Boolean).map((value) => value.toLowerCase()));
        if (primaryActions.size > 1) errors.push("PLAN_COMPETING_PRIMARY_ACTIONS");
        const performanceCost = list(plan.sections).reduce((total, section) => total + Number(COMPONENTS[section.component]?.performanceCost || 1), 0);
        if (performanceCost > 24) errors.push("PLAN_PERFORMANCE_BUDGET_EXCEEDED");
        return { valid: errors.length === 0, errors: [...new Set(errors)], performanceCost };
    }

    function claimProvenance(plan, factsInput) {
        const facts = factsInput?.factIndex ? factsInput : normalizeFacts(factsInput);
        return list(plan?.sections, SECTION_LIMIT).flatMap((section, sectionIndex) => {
            const content = object(section.content);
            const sectionClaims = list(content.factIds, 20).map((factId) => ({ sectionIndex, component: section.component, field: "section", factId, fact: facts.factIndex[factId] || null }));
            const itemClaims = list(content.items, 8).filter((item) => item?.factId).map((item, itemIndex) => ({ sectionIndex, itemIndex, component: section.component, field: "item", factId: item.factId, fact: facts.factIndex[item.factId] || null }));
            return [...sectionClaims, ...itemClaims];
        });
    }

    function sanitizePlan(raw, context = {}) {
        const facts = context.facts || normalizeFacts(context);
        const candidate = typeof raw === "string" ? JSON.parse(raw) : raw;
        const result = validatePlan(candidate, { ...context, facts });
        if (!result.valid) { const error = new Error("MODEL_PAGE_PLAN_INVALID"); error.diagnostics = result.errors; throw error; }
        return {
            version: 1,
            designSystem: candidate.designSystem,
            conversionGoal: candidate.conversionGoal,
            sections: candidate.sections.map((section) => ({ component: section.component, content: {
                ...(section.content?.heading !== undefined ? { heading: plain(section.content.heading, 100) } : {}),
                ...(section.content?.summary !== undefined ? { summary: plain(section.content.summary, 360) } : {}),
                ...(section.content?.primaryAction !== undefined ? { primaryAction: plain(section.content.primaryAction, 50) } : {}),
                ...(Array.isArray(section.content?.factIds) ? { factIds: section.content.factIds.slice(0, 20).map((id) => plain(id, 80)) } : {}),
                ...(Array.isArray(section.content?.items) ? { items: section.content.items.slice(0, 8).map((item) => ({ ...(item.factId ? { factId: plain(item.factId, 80) } : {}), title: plain(item.title, 100), text: plain(item.text, 320) })) } : {})
            } }))
        };
    }

    const renderCards = (items, extra = "") => items.map((item) => `<article class="card"><h3>${escapeHtml(item.name)}</h3>${item.description ? `<p>${escapeHtml(item.description)}</p>` : ""}${item.price ? `<p class="price">${escapeHtml(item.price)}</p>` : ""}${extra}</article>`).join("");

    function renderSection(section, facts) {
        const definition = COMPONENTS[section.component];
        const content = section.content || {};
        const heading = escapeHtml(content.heading);
        const id = slug(definition.kind);
        if (definition.kind === "navigation") return `<header class="site-header ${section.component === "navigation-offset-v1" ? "navigation-offset" : ""}"><a class="brand" href="#top">${escapeHtml(facts.businessName)}</a><nav aria-label="Primary navigation"><a href="#services">Offer</a><a href="#contact">Contact</a></nav></header>`;
        if (definition.kind === "hero") return `<section class="hero ${{ "hero-centered-v1": "hero-centered", "hero-poster-v1": "hero-poster", "hero-editorial-v1": "hero-editorial" }[section.component] || "hero-split"}" id="top"><div><p class="eyebrow">${escapeHtml(facts.businessType.replace("-", " "))}</p><h1>${heading}</h1><p class="lede">${escapeHtml(content.summary)}</p><a class="button" href="#contact">${escapeHtml(content.primaryAction)}</a></div><div class="hero-art" aria-hidden="true"><span></span><span></span></div></section>`;
        if (definition.kind === "services") return `<section id="services"><h2>${heading}</h2><div class="grid ${section.component === "service-list-v1" ? "grid-list" : ""}">${renderCards(facts.services.length ? facts.services : [{ name: "A focused service", description: facts.description || "Contact the team for details relevant to your needs." }])}</div></section>`;
        if (definition.kind === "products") return `<section id="products"><h2>${heading}</h2><div class="grid ${section.component === "product-feature-v1" ? "grid-featured" : ""}">${renderCards(facts.products.length ? facts.products : facts.services.length ? facts.services : [{ name: "Explore the offer", description: facts.description || "Ask the team for current details." }])}</div></section>`;
        if (definition.kind === "testimonials") return `<section id="testimonials"><h2>${heading}</h2><div class="grid">${facts.testimonials.map((item) => `<figure class="card"><blockquote>“${escapeHtml(item.quote || item.name)}”</blockquote><figcaption>${escapeHtml(item.name)}${item.role ? ` · ${escapeHtml(item.role)}` : ""}</figcaption></figure>`).join("")}</div></section>`;
        if (definition.kind === "pricing") return `<section id="pricing"><h2>${heading}</h2><div class="grid">${renderCards(facts.prices)}</div></section>`;
        if (definition.kind === "gallery") return `<section id="gallery"><h2>${heading}</h2><div class="gallery">${facts.assets.map((asset) => `<img src="${escapeHtml(asset.url)}" alt="${escapeHtml(asset.alt || `${facts.businessName} gallery image`)}" width="800" height="600" loading="lazy">`).join("")}</div></section>`;
        if (definition.kind === "team") return `<section id="team"><h2>${heading}</h2><div class="grid">${facts.team.map((item) => `<article class="card"><h3>${escapeHtml(item.name)}</h3>${item.role ? `<p class="eyebrow">${escapeHtml(item.role)}</p>` : ""}${item.bio ? `<p>${escapeHtml(item.bio)}</p>` : ""}</article>`).join("")}</div></section>`;
        if (definition.kind === "process") return `<section id="process"><h2>${heading}</h2><ol class="steps">${content.items.map((item) => `<li><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.text)}</p></li>`).join("")}</ol></section>`;
        if (definition.kind === "faq") return `<section id="faq"><h2>${heading}</h2><div class="faq">${content.items.map((item) => `<details><summary>${escapeHtml(item.title)}</summary><p>${escapeHtml(item.text)}</p></details>`).join("")}</div></section>`;
        if (definition.kind === "contact") {
            const intentField = section.component === "booking-panel-v1"
                ? `<label for="preference">Preferred date or time</label><input id="preference" name="preference" autocomplete="off"><p class="form-note">This is a preference, not confirmed availability.</p>`
                : section.component === "reservation-panel-v1"
                    ? `<label for="party-size">Party size</label><input id="party-size" name="partySize" type="number" min="1" max="50" inputmode="numeric"><label for="preference">Preferred date or time</label><input id="preference" name="preference" autocomplete="off"><p class="form-note">Your reservation is confirmed only after the team responds.</p>`
                    : section.component === "sales-enquiry-v1"
                        ? `<label for="product">Product or range</label><input id="product" name="product" autocomplete="off"><p class="form-note">Ask for current product, delivery, and returns details.</p>` : "";
            return `<section class="contact" id="contact"><div><h2>${heading}</h2><p>Share what you need and how the team can reach you.</p>${facts.contact.phone ? `<p><a href="tel:${escapeHtml(facts.contact.phone.replace(/[^+\d]/g, ""))}">${escapeHtml(facts.contact.phone)}</a></p>` : ""}${facts.contact.email ? `<p><a href="mailto:${escapeHtml(facts.contact.email)}">${escapeHtml(facts.contact.email)}</a></p>` : ""}</div><form action="/api/submit-form" method="post"><label for="name">Name</label><input id="name" name="name" autocomplete="name" required><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" required>${intentField}<label for="message">How can we help?</label><textarea id="message" name="message" rows="5" required></textarea><button type="submit">${escapeHtml(content.heading || "Send enquiry")}</button><p class="form-note" aria-live="polite">The team will review your request and respond using the details provided.</p></form></section>`;
        }
        if (definition.kind === "footer") return `<footer><p>© <span data-year></span> ${escapeHtml(facts.businessName)}</p><a href="#top">Back to top</a></footer>`;
        return `<section id="${id}"><h2>${heading}</h2></section>`;
    }

    function assembleProject(planInput, factsInput, design = {}) {
        const facts = factsInput?.factIds ? factsInput : normalizeFacts(factsInput);
        const plan = sanitizePlan(planInput, { facts });
        const title = `${facts.businessName} | ${plain(plan.sections.find((item) => COMPONENTS[item.component]?.kind === "hero")?.content.heading, 70)}`;
        const description = facts.description || plain(plan.sections.find((item) => COMPONENTS[item.component]?.kind === "hero")?.content.summary, 155) || `Learn more about ${facts.businessName}.`;
        const body = plan.sections.map((section) => renderSection(section, facts)).join("\n");
        const system = plan.designSystem;
        const genome = object(design.genome);
        const safeGenome = Object.entries(genome).map(([key, value]) => `${slug(key)}-${slug(value)}`).join(" ");
        const themes = {
            premium: ["#f5f1e8", "#17202a", "#fffdf8", "#8b5e3c", "2px", "Georgia,serif"], modern: ["#eef5f7", "#102331", "#fff", "#0d6878", "14px", "system-ui,sans-serif"],
            bold: ["#fff3e3", "#241515", "#fffaf3", "#9b2c36", "22px", "Arial,sans-serif"], warm: ["#f8f0df", "#2e2a22", "#fffaf0", "#536044", "10px", "Trebuchet MS,sans-serif"]
        };
        const [paper, ink, surface, accent, radius, font] = themes[system];
        const html = `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="${escapeHtml(description.slice(0, 155))}"><meta property="og:title" content="${escapeHtml(title)}"><meta property="og:description" content="${escapeHtml(description.slice(0, 155))}"><link rel="canonical" href="./index.html"><link rel="icon" href="./favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="./style.css"><title>${escapeHtml(title)}</title></head><body class="${escapeHtml(safeGenome)}" data-design-fingerprint="${escapeHtml(plain(design.designFingerprint, 80))}">${body}<script src="./script.js" defer></script></body></html>`;
        const css = `:root{--paper:${paper};--ink:${ink};--surface:${surface};--accent:${accent};--radius:${radius};--font:${font};color-scheme:light}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:clamp(1rem,.96rem + .2vw,1.1rem)/1.65 var(--font);overflow-wrap:anywhere}a{color:inherit}img{display:block;max-width:100%;height:auto;border-radius:var(--radius)}.site-header,section,footer{width:min(1120px,calc(100% - 2rem));margin-inline:auto}.site-header{min-height:72px;display:flex;align-items:center;justify-content:space-between;gap:1rem}.brand{font-weight:800;text-decoration:none}.site-header nav{display:flex;gap:1rem}.site-header nav a{padding:.6rem}.hero{min-height:620px;display:grid;grid-template-columns:minmax(0,1.15fr) minmax(260px,.85fr);gap:clamp(2rem,6vw,6rem);align-items:center}.hero-centered{grid-template-columns:1fr;text-align:center;max-width:850px}.hero-centered .hero-art{display:none}.hero-poster{grid-template-columns:1fr;min-height:720px;align-content:end}.hero-poster>div:first-child{max-width:900px;position:relative;z-index:1}.hero-poster .hero-art{position:absolute;inset:90px max(1rem,5vw) auto 42%;height:520px;opacity:.28}.hero-editorial{grid-template-columns:minmax(0,.7fr) minmax(300px,1.3fr)}.navigation-offset{padding-inline:clamp(0rem,5vw,4rem)}.grid-list{grid-template-columns:1fr}.grid-list .card{display:grid;grid-template-columns:minmax(180px,.5fr) 1fr;gap:2rem}.grid-featured .card:first-child{grid-column:span 2}.form-note{font-size:.85rem;color:color-mix(in srgb,var(--ink) 72%,transparent)}.rhythm-alternating section:nth-of-type(even){background:color-mix(in srgb,var(--surface) 55%,transparent);border-radius:var(--radius)}.cards-borderless-numbered .card{border:0;background:transparent;border-top:2px solid var(--ink)}.cards-soft-elevated .card{box-shadow:0 18px 50px #00000012}.motif-color-block .hero-art{background:linear-gradient(135deg,var(--accent) 0 55%,var(--ink) 55%)}h1,h2,h3{line-height:1.08;text-wrap:balance}h1{font-size:clamp(2.7rem,8vw,6.5rem);margin:.25em 0}h2{font-size:clamp(2rem,5vw,3.8rem);margin:0 0 1.5rem}.lede{font-size:clamp(1.1rem,2vw,1.35rem);max-width:62ch}.eyebrow{text-transform:uppercase;letter-spacing:.13em;font-size:.78rem;font-weight:800}.button,button{display:inline-flex;border:0;border-radius:var(--radius);padding:.9rem 1.2rem;background:var(--accent);color:#fff;font:700 1rem var(--font);text-decoration:none;cursor:pointer}.hero-art{aspect-ratio:4/5;background:linear-gradient(145deg,var(--accent),var(--ink));border-radius:var(--radius);position:relative;overflow:hidden}.hero-art span{position:absolute;width:55%;aspect-ratio:1;border:1px solid #ffffff99;border-radius:50%;left:15%;top:12%}.hero-art span+span{left:42%;top:45%}section{padding-block:clamp(4rem,9vw,8rem)}.grid,.gallery{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem}.card,details,form{background:var(--surface);padding:clamp(1.2rem,3vw,2rem);border:1px solid color-mix(in srgb,var(--ink) 15%,transparent);border-radius:var(--radius)}.price{font-size:1.35rem;font-weight:800}.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;padding:0;list-style-position:inside}.faq{display:grid;gap:.75rem}summary{font-weight:750;cursor:pointer}.contact{display:grid;grid-template-columns:1fr 1fr;gap:clamp(2rem,7vw,7rem);align-items:start}.contact form{display:grid;gap:.6rem}input,textarea{width:100%;border:1px solid #777;border-radius:calc(var(--radius)/2);padding:.85rem;font:inherit;background:#fff;color:#111}footer{padding:2rem 0 6rem;display:flex;justify-content:space-between}:focus-visible{outline:3px solid var(--accent);outline-offset:4px}@media(max-width:720px){.site-header nav{display:none}.hero{min-height:auto;grid-template-columns:1fr;padding-top:4rem}.hero-art{aspect-ratio:16/10}.grid,.gallery,.steps,.contact,.grid-list .card{grid-template-columns:1fr}.grid-featured .card:first-child{grid-column:auto}.hero-poster .hero-art{position:relative;inset:auto;height:auto}.hero-editorial{grid-template-columns:1fr}section{padding-block:4rem}h1{font-size:clamp(2.6rem,15vw,4.5rem)}}@media(prefers-reduced-motion:reduce){*,*::before,*::after{scroll-behavior:auto!important;animation:none!important;transition:none!important}}`;
        const script = `"use strict";document.querySelectorAll("[data-year]").forEach((node)=>{node.textContent=String(new Date().getFullYear());});`;
        const initial = escapeHtml(facts.businessName.slice(0, 1).toUpperCase() || "W");
        return {
            "index.html": html, "style.css": css, "script.js": script,
            "favicon.svg": `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="${accent}"/><text x="32" y="43" text-anchor="middle" font-size="34" fill="white" font-family="Arial">${initial}</text></svg>`,
            "sitemap.xml": `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>./index.html</loc></url></urlset>`,
            "robots.txt": "User-agent: *\nAllow: /\nSitemap: ./sitemap.xml\n"
        };
    }

    const api = Object.freeze({ COMPONENTS, PATTERNS, SYSTEMS, GOALS, SECTION_LIMIT, normalizeFacts, defaultPlan, validatePlan, sanitizePlan, claimProvenance, assembleProject });
    if (typeof window !== "undefined") window.workspaceComponents = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
