"use strict";

// Defines Advanced markup only when the Advanced stage is requested.
(() => {
    if (document.getElementById("advanced-workspace-tools-template")) return;

    const template = document.createElement("template");
    template.id = "advanced-workspace-tools-template";
    template.innerHTML = `
        <section class="input-card-group" aria-labelledby="advanced-profile-title">
            <h2 id="advanced-profile-title">Business and brand details</h2>
            <label for="input-biz-name">Business name</label><input id="input-biz-name" class="matrix-text-field">
            <label for="input-biz-hook">Customer outcome</label><input id="input-biz-hook" class="matrix-text-field">
            <label for="input-biz-services">Services</label><textarea id="input-biz-services" class="matrix-text-area-field"></textarea>
            <label for="input-biz-audience">Audience</label><input id="input-biz-audience" class="matrix-text-field">
            <label for="input-biz-location">Location</label><input id="input-biz-location" class="matrix-text-field">
            <label for="input-biz-address">Address</label><input id="input-biz-address" class="matrix-text-field">
            <label for="input-biz-phone">Phone</label><input id="input-biz-phone" class="matrix-text-field" type="tel">
            <label for="input-biz-email">Email</label><input id="input-biz-email" class="matrix-text-field" type="email">
            <label for="input-biz-hours">Availability</label><input id="input-biz-hours" class="matrix-text-field">
            <label for="input-primary-goal">Primary action</label><select id="input-primary-goal" class="matrix-text-field"><option value="">Choose</option><option value="quote">Quote</option><option value="booking">Booking</option><option value="call">Call</option><option value="email">Email</option><option value="shop">Shop</option></select>
            <label for="input-primary-cta">Call-to-action text</label><input id="input-primary-cta" class="matrix-text-field">
            <label for="input-response-time">Response time</label><input id="input-response-time" class="matrix-text-field">
            <label for="input-biz-differentiator">Differentiator</label><textarea id="input-biz-differentiator" class="matrix-text-area-field"></textarea>
            <label for="input-biz-testimonial">Testimonial</label><textarea id="input-biz-testimonial" class="matrix-text-area-field"></textarea>
            <label for="input-biz-testimonial-author">Testimonial attribution</label><input id="input-biz-testimonial-author" class="matrix-text-field">
            <label for="input-biz-credentials">Credentials</label><input id="input-biz-credentials" class="matrix-text-field">
            <label for="input-biz-experience">Experience</label><input id="input-biz-experience" class="matrix-text-field">
            <label for="input-biz-customers">Customer results</label><input id="input-biz-customers" class="matrix-text-field">
            <label for="input-biz-pricing">Pricing guidance</label><input id="input-biz-pricing" class="matrix-text-field">
            <label for="input-biz-booking">Booking link</label><input id="input-biz-booking" class="matrix-text-field" type="url">
            <label for="input-biz-brand-voice">Brand voice</label><input id="input-biz-brand-voice" class="matrix-text-field">
            <label for="input-biz-color">Brand color</label><input id="input-biz-color" type="color" value="#d4af37">
            <label for="input-biz-secondary-color">Secondary color</label><input id="input-biz-secondary-color" type="color" value="#18202b">
            <label for="input-biz-logo">Logo URL</label><input id="input-biz-logo" class="matrix-text-field" type="url">
            <label for="input-biz-logo-alt">Logo description</label><input id="input-biz-logo-alt" class="matrix-text-field">
            <label for="input-biz-hero-image">Hero image URL</label><input id="input-biz-hero-image" class="matrix-text-field" type="url">
            <label for="input-biz-hero-alt">Hero image description</label><input id="input-biz-hero-alt" class="matrix-text-field">
            <label><input id="input-biz-hero-decorative" type="checkbox"> Hero image is decorative</label>
            <label for="input-biz-gallery">Gallery URLs</label><textarea id="input-biz-gallery" class="matrix-text-area-field"></textarea>
            <label for="input-biz-gallery-alt">Gallery descriptions</label><textarea id="input-biz-gallery-alt" class="matrix-text-area-field"></textarea>
            <label for="input-biz-approved-claims">Approved claims</label><textarea id="input-biz-approved-claims" class="matrix-text-area-field"></textarea>
            <label for="input-biz-forbidden-claims">Claims to avoid</label><textarea id="input-biz-forbidden-claims" class="matrix-text-area-field"></textarea>
        </section>
        <section class="input-card-group" aria-labelledby="advanced-site-title">
            <h2 id="advanced-site-title">Site, privacy, and form settings</h2>
            <label for="input-business-type">Business type</label><select id="input-business-type" class="matrix-text-field"><option value="local-service">Local service</option><option value="restaurant">Restaurant</option><option value="professional">Professional service</option><option value="creative">Creative studio</option><option value="wellness">Wellness</option><option value="retail">Retail</option></select>
            <label for="input-design-style">Design style</label><select id="input-design-style" class="matrix-text-field"><option value="premium">Premium</option><option value="modern">Modern</option><option value="bold">Bold</option><option value="warm">Warm</option></select>
            <label for="input-content-tone">Content tone</label><select id="input-content-tone" class="matrix-text-field"><option value="clear">Clear</option><option value="warm">Warm</option><option value="editorial">Editorial</option><option value="bold">Bold</option></select>
            <label for="input-layout-density">Layout density</label><select id="input-layout-density" class="matrix-text-field"><option value="airy">Airy</option><option value="balanced">Balanced</option><option value="compact">Compact</option></select>
            <label for="input-privacy-analytics">Analytics</label><select id="input-privacy-analytics" class="matrix-text-field"><option value="essential">Essential only</option><option value="anonymous">Anonymous after consent</option></select>
            <label for="input-privacy-retention">Retention note</label><input id="input-privacy-retention" class="matrix-text-field">
            <label for="input-privacy-processors">Service providers</label><input id="input-privacy-processors" class="matrix-text-field">
            <label for="input-privacy-rights">Privacy contact</label><input id="input-privacy-rights" class="matrix-text-field">
            <label for="input-privacy-effective">Policy date</label><input id="input-privacy-effective" class="matrix-text-field" type="date">
            <label for="input-form-endpoint">Form endpoint</label><input id="input-form-endpoint" class="matrix-text-field" value="/api/submit-form">
            <label for="input-form-success">Success message</label><input id="input-form-success" class="matrix-text-field" value="Thanks — your request was sent.">
            <label for="input-form-error">Error message</label><input id="input-form-error" class="matrix-text-field" value="The form could not be submitted.">
            <label for="input-form-qualification">Qualification question</label><input id="input-form-qualification" class="matrix-text-field">
            <label><input id="input-form-consent" type="checkbox"> Require privacy consent</label>
            <label for="published-site-url-input">Published URL</label><input id="published-site-url-input" class="matrix-text-field" type="url">
        </section>`;

    document.body.append(template);
    document.dispatchEvent(new CustomEvent("website-maker:advanced-template-ready"));
})();
