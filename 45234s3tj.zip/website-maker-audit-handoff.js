"use strict";

(() => {
    document.addEventListener("DOMContentLoaded", () => {
        const params = new URLSearchParams(location.search);
        const context = window.conversionLoop?.readContext?.();
        if (!(params.get("auditId") || context?.auditId) || !window.conversionLoop) return;
        const data = context || {
            projectId: params.get("projectId"), leadId: params.get("leadId"), auditId: params.get("auditId"),
            mode: params.get("mode") || "audit-improvement"
        };
        document.body.dataset.generatorMode = data.mode || "audit-improvement";
        document.body.dataset.auditId = data.auditId || "";
        const saveStatus = document.getElementById("launch-brief-save-status");
        if (saveStatus) saveStatus.textContent = "Improvement mode: verified business facts and audit findings constrain this draft. Review-required changes are not published automatically.";
        if (data.mode !== "audit-improvement") return;

        const title = document.getElementById("configuration-title");
        if (title) title.textContent = "Improve the audited website";
        const revision = data.revisionId
            ? window.conversionLoop.listRevisions().find((item) => item.id === data.revisionId)
            : window.conversionLoop.createRevision(data, (data.auditFindings || []).map((finding) => ({
                findingId: finding.id || "", type: finding.remediation === "safe-auto" ? "safe-auto" : "review-required",
                files: [], summary: finding.recommendation || finding.issue || "Review audit finding",
                approval: finding.remediation === "blocked" ? "blocked" : "pending", evidence: finding.evidence || {}
            })));
        if (revision && !data.revisionId) {
            data.revisionId = revision.id;
            window.conversionLoop.saveContext(data);
        }

        const panel = document.createElement("section");
        panel.className = "audit-handoff-panel";
        const eyebrow = document.createElement("p");
        eyebrow.className = "eyebrow-label";
        eyebrow.textContent = "Audit-to-revision handoff";
        const heading = document.createElement("h3");
        heading.textContent = "Evidence-backed improvements";
        const description = document.createElement("p");
        description.className = "field-descriptor-text";
        description.textContent = `This draft is linked to audit ${String(data.auditId || "—").slice(0, 120)}. Review-required changes remain pending until approved.`;
        const list = document.createElement("ul");
        const findings = data.auditFindings?.length ? data.auditFindings : [{ issue: "No structured findings returned", recommendation: "Run the audit before generating an improvement revision." }];
        findings.forEach((finding) => {
            const item = document.createElement("li");
            item.textContent = `${finding.impact ? `${finding.impact.toUpperCase()} · ` : ""}${finding.issue || "Finding"} — ${finding.recommendation || "Review evidence"}`;
            list.append(item);
        });
        panel.append(eyebrow, heading, description, list);
        document.querySelector(".launch-brief-panel")?.before(panel);
    }, { once: true });
})();
