"use strict";

(() => {
    document.addEventListener("DOMContentLoaded", () => {
        const brief = document.querySelector("[data-sequential-brief]");
        const fields = [...document.querySelectorAll("[data-brief-steps] > label")];
        const next = document.getElementById("apply-outcome-brief-btn");
        const back = document.getElementById("brief-back-btn");
        const preview = document.getElementById("simulationViewWrapper");
        const iframe = document.getElementById("previewContentIframe");
        const ui = window.websiteMakerUI;
        let step = 0;

        const updateStep = (focus = true) => {
            fields.forEach((field, index) => { field.hidden = index !== step; });
            const status = document.getElementById("outcome-brief-status");
            if (status) status.textContent = `${step + 1} of ${fields.length}`;
            if (back) back.hidden = step === 0;
            if (next) {
                const last = step === fields.length - 1;
                next.textContent = last ? "Create my website" : "Continue";
                next.setAttribute("aria-label", last ? "Submit brief and create my website" : `Continue to question ${step + 2} of ${fields.length}`);
            }
            if (focus) fields[step]?.querySelector("input, select")?.focus();
        };

        const validStep = () => {
            const control = fields[step]?.querySelector("input, select");
            if (!control) return true;
            control.setCustomValidity(control.value.trim() ? "" : "Please fill this in to continue.");
            if (control.checkValidity()) return true;
            control.reportValidity();
            return false;
        };

        const hasPreview = () => {
            const html = String(window.workspaceAPI?.getState?.().files?.["index.html"] || "").trim();
            if (html && !html.startsWith("<!-- Awaiting")) return true;
            if (iframe?.srcdoc?.trim()) return true;
            const src = iframe?.getAttribute("src") || "";
            return Boolean(src) && !/about:blank$/i.test(src);
        };

        const setDraftReady = (ready) => {
            const workflow = window.websiteMakerWorkflow;
            const current = workflow?.getState?.().state;
            const stable = ["draft", "review", "approved", "published"];
            const target = ready ? (stable.includes(current) ? current : "draft") : "brief";
            if (!workflow?.transition?.(target, { source: "workspace" })) return;
            preview?.setAttribute("aria-busy", String(!ready));
            document.getElementById("preview-frame-shell")?.toggleAttribute("aria-hidden", !ready);
            const title = document.getElementById("publish-confidence-title");
            const summary = document.getElementById("publish-confidence-summary");
            if (title) title.textContent = ready ? "Draft ready" : "Launch checklist";
            if (summary) summary.textContent = ready ? "Review the draft, add contact details, then share or publish." : "Complete the essentials, then create your draft.";
            if (ready) ui?.focusStatus?.(document.getElementById("sandbox-title"));
            else if (next) { next.disabled = false; next.removeAttribute("aria-busy"); updateStep(false); }
            ui?.updateConfidence?.();
        };

        if (brief && fields.length && next) {
            next.addEventListener("click", (event) => {
                if (!validStep()) { event.preventDefault(); event.stopImmediatePropagation(); return; }
                if (step < fields.length - 1) {
                    event.preventDefault(); event.stopImmediatePropagation(); step += 1; updateStep(); return;
                }
                document.body.dataset.briefSubmitted = "true";
                window.websiteMakerWorkflow?.transition?.("generating", { source: "brief-submit" });
                window.websiteMakerProfileStore?.render?.();
                next.disabled = true;
                next.setAttribute("aria-busy", "true");
                next.textContent = "Creating your website…";
                preview?.setAttribute("aria-busy", "true");
                ui?.setStatus?.(document.getElementById("publish-confidence-status"), "Creating your website…", "Your brief is saved. The preview will appear when the draft is ready.");
                document.getElementById("compile-pipeline-btn")?.click();
            }, true);
            back?.addEventListener("click", () => { if (step > 0) { step -= 1; updateStep(); } });
            brief.addEventListener("keydown", (event) => {
                if (event.key === "Enter" && !(event.target instanceof HTMLSelectElement) && !(event.target instanceof HTMLButtonElement)) {
                    event.preventDefault(); next.click();
                }
            });
            updateStep(false);
        }

        const restore = window.websiteMakerWorkflow?.consumeRecovery?.();
        if (restore) ui?.setStatus?.(document.getElementById("publish-confidence-status"), "Draft creation was interrupted by a refresh.", "Your brief is saved. Create the website again when you are ready.");
        document.addEventListener("workspace:generation-complete", () => setDraftReady(true));
        document.addEventListener("workspace:draft-created", () => setDraftReady(true));
        document.addEventListener("workspace:files-rendered", () => { if (hasPreview()) setDraftReady(true); });
        document.addEventListener("workspace:core-ready", () => { window.websiteMakerProfileStore?.render?.(); if (hasPreview()) setDraftReady(true); });
        document.addEventListener("workspace:generation-error", (event) => {
            setDraftReady(false);
            const reason = String(event.detail?.message || event.detail?.error?.message || "The draft could not be created.").slice(0, 180);
            const status = document.getElementById("publish-confidence-status");
            ui?.setStatus?.(status, "Draft creation stopped.", `${reason} Your brief is still saved.`);
            ui?.focusStatus?.(status);
        });
        iframe?.addEventListener("load", () => { if (hasPreview()) setDraftReady(true); });
        if (hasPreview()) setDraftReady(true);
    }, { once: true });
})();
