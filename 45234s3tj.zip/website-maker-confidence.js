"use strict";

(() => {
    const briefInputs = [
        { id: "outcome-name-input", hint: "hint-outcome-name-input", label: "Business name", ok: "Visitors will recognize and search for this name.", missing: "Visitors need to know who they're dealing with." },
        { id: "outcome-offer-input", hint: "hint-outcome-offer-input", label: "Offer", ok: "Clear offer — your draft will lead with this.", missing: "Name the core service or product." },
        { id: "outcome-audience-input", hint: "hint-outcome-audience-input", label: "Audience", ok: "Your headlines will speak directly to this group.", missing: "A specific audience creates stronger headlines." },
        { id: "outcome-location-input", hint: "hint-outcome-location-input", label: "Location", ok: "Local visitors will know you serve their area.", missing: "Add your city or service area." },
        { id: "outcome-goal-select", hint: "hint-outcome-goal-select", label: "Primary action", ok: "This action drives your entire site layout.", missing: "Choose what visitors should do." },
        { id: "outcome-proof-input", hint: "hint-outcome-proof-input", label: "Trust signal", ok: "Great — this builds confidence on your site.", missing: "A testimonial, credential, or measurable result builds trust." }
    ];
    const contactInputs = [
        { id: "outcome-phone-input", hint: "hint-outcome-phone-input", label: "Phone", ok: "Visitors can tap to call.", missing: "Add a phone number so visitors can call you directly." },
        { id: "outcome-email-input", hint: "hint-outcome-email-input", label: "Email", ok: "Enquiries have a real inbox.", missing: "Enquiries need a real inbox, not just a form that looks finished." },
        { id: "outcome-hours-input", hint: "hint-outcome-hours-input", label: "Hours", ok: "People will know when you are available.", missing: "Tell people when you are available." }
    ];

    const setStatus = (element, headline, detail = "") => {
        if (!element) return;
        const strong = document.createElement("strong");
        strong.textContent = headline;
        element.replaceChildren(strong);
        if (detail) element.append(document.createTextNode(` ${detail}`));
    };

    const focusStatus = (element) => {
        if (!element) return;
        element.tabIndex = -1;
        element.focus({ preventScroll: true });
    };

    const isContactValid = (control) => {
        if (!control?.value.trim()) return false;
        if (control.id === "outcome-phone-input") {
            const digits = (control.value.match(/\d/g) || []).length;
            if (digits < 7 || digits > 15) return false;
        }
        return control.validity?.typeMismatch !== true;
    };

    const validateContact = (control) => {
        if (!control) return false;
        let message = "";
        if (!control.value.trim()) message = "Please fill this in before publishing.";
        else if (control.id === "outcome-phone-input") {
            const digits = (control.value.match(/\d/g) || []).length;
            if (digits < 7 || digits > 15) message = "Enter a phone number with 7 to 15 digits.";
        } else if (control.validity?.typeMismatch) message = "Enter a valid email address.";
        control.setCustomValidity(message);
        return !message;
    };

    const contactComplete = () => {
        const profile = window.websiteMakerProfileStore?.getState?.();
        if (profile) {
            const digits = String(profile.identity?.phoneDial || profile.identity?.phoneDisplay || "").match(/\d/g) || [];
            return digits.length >= 7 && digits.length <= 15 && /\S+@\S+\.\S+/.test(String(profile.identity?.email || "")) && Boolean(String(profile.availability || "").trim());
        }
        return contactInputs.every(({ id }) => isContactValid(document.getElementById(id)));
    };
    const firstInvalidContact = () => contactInputs.map(({ id }) => document.getElementById(id)).find((field) => !validateContact(field));
    const getPublishedUrl = () => {
        const field = document.getElementById("published-site-url-input")?.value.trim() || "";
        const href = document.getElementById("go-live-url-link")?.getAttribute("href")?.trim() || "";
        const candidate = field || (href === "#" ? "" : href);
        try {
            const url = new URL(candidate);
            return url.protocol === "https:" ? url.href : "";
        } catch (_) { return ""; }
    };

    const update = () => {
        const draft = document.body.dataset.draftReady === "true";
        const profile = window.websiteMakerProfileStore?.getState?.();
        const briefComplete = profile
            ? Boolean(profile.identity?.displayName && profile.services?.length && profile.audience && profile.locations?.[0]?.city && profile.primaryGoal && profile.differentiator)
            : briefInputs.every(({ id }) => document.getElementById(id)?.value.trim());
        const items = draft ? [
            { label: "Launch brief", pass: briefComplete },
            { label: "Phone, email, and hours", pass: contactComplete() },
            { label: "First draft", pass: true },
            { label: document.body.dataset.creationMode === "client" ? "Client review" : "Ready to share", pass: document.body.dataset.creationMode !== "client" || document.body.dataset.reviewApproved === "true" },
            { label: "Enquiry inbox", pass: document.body.dataset.enquiryReady === "true" || Boolean(document.getElementById("outcome-email-input")?.value.trim()) },
            { label: "Live URL", pass: Boolean(getPublishedUrl()) }
        ] : briefInputs.map(({ id, label }) => ({ label, pass: Boolean(document.getElementById(id)?.value.trim()) }));
        const count = items.filter(({ pass }) => pass).length;
        const total = items.length;
        const status = document.getElementById("publish-confidence-status");
        const score = document.getElementById("publish-confidence-score");
        const bar = document.getElementById("publish-confidence-bar");
        const progress = document.querySelector(".publish-confidence-progress");
        if (score) score.textContent = `${count}/${total}`;
        if (bar) bar.style.width = `${Math.round(count / total * 100)}%`;
        progress?.setAttribute("aria-valuenow", String(count));
        progress?.setAttribute("aria-valuemax", String(total));
        progress?.setAttribute("aria-valuetext", `${count} of ${total} complete`);
        if (!draft) {
            const next = items.find(({ pass }) => !pass);
            if (!count) setStatus(status, "Start with your business name.", "Each answer shapes a clearer first draft.");
            else if (count < total) setStatus(status, `${count} of ${total} essentials set.`, `${next?.label || "Keep going"} is next.`);
            else setStatus(status, "All essentials are in place.", "Create your first draft.");
        } else if (!contactComplete()) setStatus(status, "Draft ready.", "Add phone, email, and hours so visitors can reach you.");
        else if (document.body.dataset.creationMode === "client" && document.body.dataset.reviewApproved !== "true") setStatus(status, "Share this revision.", "Publishing waits for client approval.");
        else if (!getPublishedUrl()) setStatus(status, "Ready to go live.", "Publish a URL you can send, or download the files.");
        else setStatus(status, "This site is live.", "New enquiries appear in Leads with a follow-up task.");

        const list = document.getElementById("publish-confidence-list");
        if (list) {
            list.replaceChildren(...items.map((item) => {
                const li = document.createElement("li");
                li.dataset.passed = String(item.pass);
                li.textContent = `${item.label}${item.pass ? " — set" : " — add this"}`;
                return li;
            }));
        }
        [...briefInputs, ...contactInputs].forEach((item) => {
            const field = document.getElementById(item.id);
            const hint = document.getElementById(item.hint);
            if (!field || !hint) return;
            const filled = Boolean(field.value.trim());
            hint.dataset.hint = filled ? "ok" : "missing";
            hint.textContent = filled ? item.ok : item.missing;
        });
    };

    window.websiteMakerUI = Object.freeze({ briefInputs, contactInputs, setStatus, focusStatus, isContactValid, validateContact, contactComplete, firstInvalidContact, getPublishedUrl, updateConfidence: update });

    document.addEventListener("DOMContentLoaded", () => {
        [...briefInputs, ...contactInputs].forEach(({ id }) => {
            const field = document.getElementById(id);
            field?.addEventListener("input", () => { field.setCustomValidity(""); update(); });
            field?.addEventListener("change", update);
        });
        document.addEventListener("website-maker:profile-changed", update);
        update();
    }, { once: true });
})();
