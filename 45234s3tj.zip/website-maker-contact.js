"use strict";

(() => {
    const bind = () => {
        const ui = window.websiteMakerUI;
        const store = window.websiteMakerProfileStore;
        const syncWorkspaceFields = () => {
            store?.render?.();
            const offer = document.getElementById("outcome-offer-input")?.value.trim();
            const hook = document.getElementById("input-biz-hook");
            if (hook && !hook.value.trim() && offer) {
                hook.value = offer;
                hook.dispatchEvent(new Event("input", { bubbles: true }));
            }
        };

        document.getElementById("update-contact-draft-btn")?.addEventListener("click", () => {
            if (!ui?.contactComplete()) {
                const invalid = ui?.firstInvalidContact();
                invalid?.focus();
                invalid?.reportValidity();
                const status = document.getElementById("launch-contact-status");
                if (status) status.textContent = "Add valid phone, email, and hours, then update the draft.";
                return;
            }
            syncWorkspaceFields();
            document.getElementById("compile-pipeline-btn")?.click();
            const status = document.getElementById("launch-contact-status");
            if (status) status.textContent = "Updating the draft with click-to-call, email, and hours…";
        });

        document.getElementById("outcome-phone-input")?.addEventListener("change", (event) => {
            store?.update?.({ identity: { phoneDisplay: event.currentTarget.value } }, { source: "phone-change" });
        });
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
