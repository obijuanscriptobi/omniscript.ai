"use strict";

(() => {
    document.addEventListener("DOMContentLoaded", () => {
        const projectType = document.getElementById("project-type-select");
        const control = document.getElementById("project-type-control");
        const status = document.getElementById("creation-mode-status");
        const render = () => {
            const clientAccount = Boolean(window.operatingMode?.isClient?.());
            const savedType = window.websiteMakerWorkflow?.getState?.().projectType;
            if (control) control.hidden = !clientAccount;
            if (projectType && !clientAccount) projectType.value = "owner";
            else if (projectType && savedType) projectType.value = savedType;
            const selected = clientAccount ? (projectType?.value || savedType || "client") : "owner";
            window.websiteMakerWorkflow?.setProjectType?.(selected);
            document.querySelector(".client-intake-panel")?.toggleAttribute("hidden", selected !== "client");
            document.querySelector(".launch-brief-panel")?.toggleAttribute("hidden", selected === "client");
            if (status) status.textContent = selected === "client"
                ? "Client project: import a public website, prepare an editable rebuild, then use review and approval before publishing."
                : "Answer six short questions, review the draft, then publish or download it.";
            window.websiteMakerUI?.updateConfidence?.();
        };
        projectType?.addEventListener("change", render);
        document.addEventListener("operating-mode:changed", () => {
            if (window.operatingMode?.isClient?.() && projectType) projectType.value = "client";
            render();
        });
        document.addEventListener("workspace:review-updated", (event) => {
            const review = event.detail?.review?.status;
            window.websiteMakerWorkflow?.setReviewStatus?.(review || "draft");
            if (review === "approved") window.websiteMakerWorkflow?.transition?.("approved", { source: "client-review", approvedRevision: window.workspaceAPI?.getState?.().revision || "draft" });
            else if (review === "shared") window.websiteMakerWorkflow?.transition?.("review", { source: "client-review" });
            else if (review === "changes-requested") window.websiteMakerWorkflow?.transition?.("draft", { source: "client-review" });
            window.websiteMakerUI?.updateConfidence?.();
        });
        document.addEventListener("workspace:enquiry-captured", (event) => {
            document.body.dataset.enquiryReady = "true";
            const name = String(event.detail?.lead?.name || "A visitor").slice(0, 120);
            window.websiteMakerUI?.setStatus?.(document.getElementById("publish-confidence-status"), "Enquiry captured.", `${name} is in Leads with a follow-up for tomorrow.`);
        });
        render();
    }, { once: true });
})();
