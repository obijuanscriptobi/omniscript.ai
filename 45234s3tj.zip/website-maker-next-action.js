"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    const workflow = () => window.websiteMakerWorkflow?.getState?.() || { state: "brief", projectType: "owner", reviewStatus: "draft" };
    const deployable = () => { const button = get("publish-site-btn"); return Boolean(button && !button.disabled && button.getAttribute("aria-disabled") !== "true"); };
    const contactReady = () => Boolean(window.websiteMakerUI?.contactComplete?.());
    const liveUrl = () => window.websiteMakerUI?.getPublishedUrl?.() || "";

    const model = () => {
        const state = workflow();
        if (state.state === "brief") return { title: "Continue your brief", detail: "Complete the current question.", label: "Continue", target: "apply-outcome-brief-btn" };
        if (state.state === "generating") return { title: "Creating your website", detail: "Keep this page open while the draft is prepared.", label: "Creating…", disabled: true };
        if (!contactReady()) return { title: "Add contact details", detail: "Add phone, email, and availability, then update the draft.", label: "Add contact details", target: "outcome-phone-input" };
        if (state.projectType === "client" && state.reviewStatus === "draft") return { title: "Share for client review", detail: "Create a private link for this revision.", label: "Create review link", target: "client-review-share-btn" };
        if (state.projectType === "client" && state.reviewStatus === "shared") return { title: "Awaiting client approval", detail: "Publishing remains locked for this revision.", label: "Awaiting approval", disabled: true };
        if (state.state === "published" && liveUrl()) return { title: "Website is live", detail: "Open the published website.", label: "Open live website", href: liveUrl() };
        if (deployable()) return { title: "Ready to publish", detail: "Contact details and review requirements are complete.", label: "Publish website", target: "go-live-publish-btn" };
        return { title: "Website files are ready", detail: "Direct publishing is unavailable, so download the files for your host.", label: "Download website files", target: "go-live-download-btn" };
    };

    const render = () => {
        const action = model(); const button = get("website-maker-next-action");
        if (!button) return;
        get("next-action-title").textContent = action.title;
        get("next-action-detail").textContent = action.detail;
        button.textContent = action.label; button.disabled = Boolean(action.disabled);
        button.setAttribute("aria-disabled", String(Boolean(action.disabled)));
        button.dataset.target = action.target || ""; button.dataset.href = action.href || "";
    };
    const activate = () => {
        const button = get("website-maker-next-action");
        if (button?.dataset.href) { location.href = button.dataset.href; return; }
        const target = get(button?.dataset.target);
        if (!target) return;
        if (target.matches("button")) target.click(); else { target.focus({ preventScroll: true }); target.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" }); }
    };
    document.addEventListener("DOMContentLoaded", () => { get("website-maker-next-action")?.addEventListener("click", activate); render(); }, { once: true });
    ["website-maker:state-changed", "website-maker:profile-changed", "workspace:review-updated", "workspace:deployment-complete", "website-maker:stage-ready"].forEach((name) => document.addEventListener(name, render));
    window.websiteMakerNextAction = Object.freeze({ model, render });
})();
