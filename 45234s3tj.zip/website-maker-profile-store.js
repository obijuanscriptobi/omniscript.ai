"use strict";

// Versioned canonical business profile. DOM controls are adapters only.
(() => {
    const STORAGE_KEY = "morrow-business-profile-v1";
    const SCHEMA_VERSION = 2;
    const storageKey = () => window.workspaceContext?.ready === true
        ? window.workspaceContext.storageKey(STORAGE_KEY)
        : "";
    const listeners = new Set();
    const bindings = Object.freeze({
        "outcome-name-input": ["identity", "displayName"], "input-biz-name": ["identity", "displayName"],
        "outcome-phone-input": ["identity", "phoneDisplay"], "input-biz-phone": ["identity", "phoneDisplay"],
        "outcome-email-input": ["identity", "email"], "input-biz-email": ["identity", "email"],
        "outcome-offer-input": ["services"], "input-biz-services": ["services"],
        "outcome-audience-input": ["audience"], "input-biz-audience": ["audience"],
        "outcome-location-input": ["locations", 0, "city"], "input-biz-location": ["locations", 0, "city"],
        "input-biz-address": ["locations", 0, "address"],
        "outcome-goal-select": ["primaryGoal"], "input-primary-goal": ["primaryGoal"],
        "outcome-proof-input": ["differentiator"], "input-biz-differentiator": ["differentiator"],
        "outcome-hours-input": ["availability"], "input-biz-hours": ["availability"],
        "input-biz-hook": ["messaging", "hook"], "input-primary-cta": ["messaging", "cta"],
        "input-response-time": ["messaging", "responseTime"], "input-biz-brand-voice": ["messaging", "voice"],
        "input-biz-testimonial": ["proof", "testimonial"], "input-biz-testimonial-author": ["proof", "testimonialAuthor"],
        "input-biz-credentials": ["proof", "credentials"], "input-biz-experience": ["proof", "experience"],
        "input-biz-customers": ["proof", "customers"], "input-biz-pricing": ["proof", "pricing"],
        "input-biz-booking": ["links", "booking"],
        "input-biz-color": ["brand", "primaryColor"], "input-biz-secondary-color": ["brand", "secondaryColor"],
        "input-biz-logo": ["brand", "logoUrl"], "input-biz-logo-alt": ["brand", "logoAlt"],
        "input-biz-hero-image": ["brand", "heroImageUrl"], "input-biz-hero-alt": ["brand", "heroAlt"],
        "input-biz-hero-decorative": ["brand", "heroDecorative"], "input-biz-gallery": ["brand", "gallery"],
        "input-biz-gallery-alt": ["brand", "galleryAlt"], "input-biz-approved-claims": ["claimGuidance", "approved"],
        "input-biz-forbidden-claims": ["claimGuidance", "forbidden"], "input-business-type": ["design", "businessType"],
        "input-design-style": ["design", "style"], "input-content-tone": ["design", "tone"],
        "input-layout-density": ["design", "density"], "input-privacy-analytics": ["privacy", "analytics"],
        "input-privacy-retention": ["privacy", "retention"], "input-privacy-processors": ["privacy", "processors"],
        "input-privacy-rights": ["privacy", "rightsContact"], "input-privacy-effective": ["privacy", "effectiveDate"],
        "input-form-endpoint": ["form", "endpoint"], "input-form-success": ["form", "successMessage"],
        "input-form-error": ["form", "errorMessage"], "input-form-qualification": ["form", "qualification"],
        "input-form-consent": ["form", "requireConsent"], "published-site-url-input": ["publishing", "url"]
    });
    const listPaths = new Set(["services", "brand.gallery", "brand.galleryAlt", "claimGuidance.approved", "claimGuidance.forbidden"]);

    const defaults = () => ({
        identity: { displayName: "", phone: "", phoneDisplay: "", phoneDial: "", phoneExtension: "", email: "" },
        services: [], locations: [{ city: "", address: "" }], audience: "", primaryGoal: "", differentiator: "", availability: "",
        messaging: { hook: "", cta: "", responseTime: "", voice: "" },
        proof: { testimonial: "", testimonialAuthor: "", credentials: "", experience: "", customers: "", pricing: "" },
        links: { booking: "" },
        brand: { primaryColor: "#d4af37", secondaryColor: "#18202b", logoUrl: "", logoAlt: "", heroImageUrl: "", heroAlt: "", heroDecorative: false, gallery: [], galleryAlt: [] },
        claims: [], claimGuidance: { approved: [], forbidden: [] },
        design: { businessType: "local-service", style: "premium", tone: "clear", density: "airy" },
        privacy: { analytics: "essential", retention: "", processors: "", rightsContact: "", effectiveDate: "" },
        form: { endpoint: "/api/submit-form", successMessage: "Thanks — your request was sent.", errorMessage: "The form could not be submitted.", qualification: "", requireConsent: false },
        publishing: { url: "" }
    });
    const clone = (value) => { try { return structuredClone(value); } catch (_) { return JSON.parse(JSON.stringify(value)); } };
    const list = (value) => Array.isArray(value) ? value.map(String).map((item) => item.trim()).filter(Boolean) : String(value || "").split(/[\n,]/).map((item) => item.trim()).filter(Boolean);
    const phoneParts = (value) => {
        const display = String(value || "").trim();
        const extension = display.match(/(?:ext\.?|extension|x)\s*(\d+)\s*$/i)?.[1] || "";
        const base = extension ? display.replace(/(?:ext\.?|extension|x)\s*\d+\s*$/i, "").trim() : display;
        const digits = base.replace(/\D/g, "");
        return { phoneDisplay: display, phoneDial: `${base.startsWith("+") ? "+" : ""}${digits}`, phoneExtension: extension };
    };
    const merge = (base, patch) => Object.keys(patch || {}).reduce((result, key) => {
        const value = patch[key];
        result[key] = value && typeof value === "object" && !Array.isArray(value) ? merge(result[key] || {}, value) : value;
        return result;
    }, clone(base));
    const normalize = (raw = {}) => {
        const migrated = { ...raw, availability: raw.availability ?? raw.hours ?? "" };
        const legacyPhone = raw.identity?.phoneDisplay ?? raw.identity?.phone ?? "";
        const value = merge(defaults(), migrated);
        value.identity = { ...value.identity, ...phoneParts(legacyPhone), phone: String(legacyPhone).trim(), email: String(value.identity.email || "").trim() };
        value.services = list(value.services);
        value.locations = [{ ...defaults().locations[0], ...(value.locations?.[0] || {}) }];
        value.brand.gallery = list(value.brand.gallery); value.brand.galleryAlt = list(value.brand.galleryAlt);
        value.claims = Array.isArray(value.claims) ? value.claims : [];
        const approvedLegacy = value.claims.filter((item) => item?.state === "approved").map((item) => item.value || item.text).filter(Boolean);
        value.claimGuidance = value.claimGuidance && !Array.isArray(value.claimGuidance) ? value.claimGuidance : { approved: approvedLegacy, forbidden: [] };
        value.claimGuidance.approved = list(value.claimGuidance.approved); value.claimGuidance.forbidden = list(value.claimGuidance.forbidden);
        return value;
    };
    const emptyRecord = () => ({ version: SCHEMA_VERSION, profile: defaults(), revision: 0, savedAt: "" });
    const readRecord = () => {
        const key = storageKey();
        if (!key) return emptyRecord();
        try {
            const raw = localStorage.getItem(key);
            const legacy = key.includes("::own:") ? localStorage.getItem(STORAGE_KEY) : null;
            const record = JSON.parse(raw || legacy || "null");
            if (!record) return emptyRecord();
            const version = Number(record.version || 1);
            if (!Number.isSafeInteger(version) || version > SCHEMA_VERSION) return emptyRecord();
            return { version, profile: normalize(record.profile || record), revision: Math.max(0, Number(record.revision || 0)), savedAt: String(record.savedAt || "") };
        } catch (_) {
            return emptyRecord();
        }
    };
    let state = defaults(); let revision = 0; let savedAt = ""; let timer = 0; let rendering = false; let activeKey = ""; let hydrated = false;
    let pendingPatch = {}; let changeToken = 0;
    const at = (source, path) => path.reduce((value, key) => value?.[key], source);
    const setAt = (source, path, value) => { let target = source; path.slice(0, -1).forEach((key, index) => { if (!target[key] || typeof target[key] !== "object") target[key] = typeof path[index + 1] === "number" ? [] : {}; target = target[key]; }); target[path.at(-1)] = value; };
    const pathName = (path) => path.join(".");
    const compareRecords = (left = {}, right = {}) => {
        const leftVersion = Number(left.version || 1); const rightVersion = Number(right.version || 1);
        if (leftVersion !== rightVersion) return leftVersion - rightVersion;
        const revisionDifference = Number(left.revision || 0) - Number(right.revision || 0);
        return revisionDifference || String(left.savedAt || "").localeCompare(String(right.savedAt || ""));
    };
    let remoteRevision = 0;
    async function saveRemote(expectedKey) {
        const context = window.workspaceContext?.current?.();
        const projectId = window.workspaceAPI?.getState?.().projectId;
        if (expectedKey !== activeKey || !projectId || !context?.cloudId || !window.supabaseWorkspace?.getAccessToken?.()) return;
        // Capture the submitted snapshot. A conflict reload may replace live
        // state, so this is the only safe source for reapplying unsaved edits.
        const pendingProfile = clone(state);
        const submittedPatch = clone(pendingPatch);
        const submittedToken = changeToken;
        const pendingRevision = revision;
        try {
            const response = await fetch("/api/business-profile", {
                method: "PUT", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json" },
                body: JSON.stringify({ projectId, workContextId: context.cloudId, expectedRevision: remoteRevision, changeSource: "website-maker", profile: { ...pendingProfile, version: SCHEMA_VERSION, revision: pendingRevision } })
            });
            const result = await response.json().catch(() => ({}));
            if (expectedKey !== activeKey) return;
            if (response.status === 409) {
                const loaded = await loadRemote();
                if (!loaded || expectedKey !== activeKey) return;
                // Preserve the user's pending snapshot after adopting the cloud
                // revision, then queue a new compare-and-swap write.
                state = normalize(merge(state, submittedPatch));
                revision = Math.max(revision, remoteRevision, pendingRevision);
                savedAt = new Date().toISOString();
                render();
                notify("conflict-rebased");
                persist();
                return;
            }
            if (response.ok && result.profile) {
                remoteRevision = Number(result.profile.revision || pendingRevision);
                if (submittedToken === changeToken) pendingPatch = {};
            }
        } catch (_) { /* The local record remains queued for a later edit. */ }
    }
    const flush = (expectedKey = activeKey) => {
        clearTimeout(timer); timer = 0;
        if (!hydrated || !expectedKey || expectedKey !== activeKey || expectedKey !== storageKey()) return false;
        try {
            const latest = JSON.parse(localStorage.getItem(expectedKey) || "null");
            const local = { version: SCHEMA_VERSION, revision, profile: state, savedAt };
            if (latest && compareRecords(latest, local) > 0) {
                const hasPendingEdits = Object.keys(pendingPatch).length > 0;
                state = normalize(hasPendingEdits
                    ? merge(latest.profile || latest, pendingPatch)
                    : (latest.profile || latest));
                revision = Number(latest.revision || 0);
                savedAt = String(latest.savedAt || "");
                render();
                notify(hasPendingEdits ? "newer-record-rebased" : "newer-record-restored");
                if (!hasPendingEdits) return false;
            }
            revision = Math.max(revision, Number(latest?.revision || 0)) + 1;
            savedAt = new Date().toISOString();
            localStorage.setItem(expectedKey, JSON.stringify({ version: SCHEMA_VERSION, revision, profile: state, savedAt }));
            saveRemote(expectedKey);
            return true;
        } catch (_) { return false; }
    };
    const persist = () => {
        clearTimeout(timer);
        const expectedKey = activeKey;
        if (!hydrated || !expectedKey) return;
        timer = window.setTimeout(() => flush(expectedKey), 120);
    };
    const render = () => {
        rendering = true;
        Object.entries(bindings).forEach(([id, path]) => {
            const field = document.getElementById(id); if (!field) return;
            const stored = at(state, path); const name = pathName(path);
            const value = listPaths.has(name) ? list(stored).join(name === "services" || name === "brand.gallery" ? ", " : "\n") : stored;
            if (field.type === "checkbox") field.checked = Boolean(value); else if (field.value !== String(value ?? "")) field.value = String(value ?? "");
        });
        rendering = false;
    };
    const notify = (source) => { const snapshot = clone(state); listeners.forEach((fn) => fn(snapshot, { source, revision })); document.dispatchEvent(new CustomEvent("website-maker:profile-changed", { detail: { profile: snapshot, source, revision } })); };
    const update = (patch, options = {}) => {
        if (!hydrated) return clone(state);
        const nextPatch = typeof patch === "function" ? patch(clone(state)) : patch || {};
        state = normalize(typeof patch === "function" ? nextPatch : merge(state, nextPatch));
        if (options.persist !== false) {
            pendingPatch = merge(pendingPatch, nextPatch);
            changeToken += 1;
        }
        if (options.render !== false) render();
        if (options.persist !== false) persist();
        notify(options.source || "api");
        return clone(state);
    };
    const reconcile = (record, options = {}) => {
        if (!hydrated || !record || typeof record !== "object") return clone(state);
        const incomingProjectId = record.projectId || record.project_id || "";
        const activeProjectId = window.workspaceAPI?.getState?.().projectId || "";
        if (incomingProjectId && activeProjectId && String(incomingProjectId) !== String(activeProjectId)) return clone(state);
        const incomingContextId = record.workContextId || record.work_context_id || "";
        const activeContext = window.workspaceContext?.current?.();
        if (incomingContextId && ![activeContext?.id, activeContext?.cloudId].includes(incomingContextId)) return clone(state);
        const incoming = {
            version: Number(record.version || record.schemaVersion || 1),
            revision: Number(record.revision || record.profile?.revision || 0),
            savedAt: String(record.savedAt || record.updated_at || record.updatedAt || ""),
            profile: record.profile || record
        };
        const local = { version: SCHEMA_VERSION, revision, savedAt, profile: state };
        if (!Number.isSafeInteger(incoming.version) || incoming.version > SCHEMA_VERSION || compareRecords(incoming, local) <= 0) return clone(state);
        state = normalize(incoming.profile);
        revision = incoming.revision;
        savedAt = incoming.savedAt;
        render();
        if (options.persist !== false && activeKey) {
            try { localStorage.setItem(activeKey, JSON.stringify({ version: SCHEMA_VERSION, revision, profile: state, savedAt })); } catch (_) {}
        }
        notify(options.source || "remote-reconcile");
        return clone(state);
    };
    const fromField = (field) => {
        const path = bindings[field.id]; if (!path || rendering) return;
        const next = clone(state); let value = field.type === "checkbox" ? field.checked : field.value.trim();
        if (listPaths.has(pathName(path))) value = list(value);
        setAt(next, path, value);
        if (pathName(path) === "identity.phoneDisplay") next.identity = { ...next.identity, ...phoneParts(value), phone: String(value) };
        update(next, { source: field.id, render: false });
    };
    const subscribe = (fn) => { if (typeof fn !== "function") return () => {}; listeners.add(fn); return () => listeners.delete(fn); };
    const bind = (root = document) => {
        Object.keys(bindings).forEach((id) => {
            const field = root.getElementById?.(id) || root.querySelector?.(`#${id}`);
            if (!field || field.dataset.profileBound === "true") return;
            field.dataset.profileBound = "true";
            field.addEventListener("input", () => fromField(field));
            field.addEventListener("change", () => fromField(field));
        });
        render();
    };

    const hydrateScope = (source = "hydrate") => {
        const nextKey = storageKey();
        if (!nextKey) return false;
        clearTimeout(timer); timer = 0;
        // Finish the old scope's pending local write using its captured key;
        // never let it follow the newly selected context.
        if (hydrated && activeKey && activeKey !== nextKey) {
            try {
                const latest = JSON.parse(localStorage.getItem(activeKey) || "null");
                const oldRevision = Math.max(revision, Number(latest?.revision || 0)) + 1;
                localStorage.setItem(activeKey, JSON.stringify({ version: SCHEMA_VERSION, revision: oldRevision, profile: state, savedAt: new Date().toISOString() }));
            } catch (_) {}
        }
        activeKey = nextKey;
        pendingPatch = {};
        changeToken = 0;
        const scoped = readRecord();
        state = scoped.profile;
        revision = scoped.revision;
        savedAt = scoped.savedAt;
        remoteRevision = 0;
        hydrated = true;
        bind();
        notify(source);
        return true;
    };
    const loadRemote = async () => {
        const context = window.workspaceContext?.current?.();
        const projectId = window.workspaceAPI?.getState?.().projectId;
        const requestedKey = activeKey;
        if (!hydrated || !projectId || !context?.cloudId || !window.supabaseWorkspace?.getAccessToken?.()) return false;
        try {
            const response = await fetch(`/api/business-profile?projectId=${encodeURIComponent(projectId)}&workContextId=${encodeURIComponent(context.cloudId)}`, { credentials: "same-origin", headers: { Accept: "application/json" } });
            const result = await response.json().catch(() => ({}));
            if (requestedKey !== activeKey || requestedKey !== storageKey()) return false;
            if (response.ok && result.profile) {
                remoteRevision = Number(result.profile.revision || 0);
                reconcile(result.profile, { source: "cloud-profile" });
                return true;
            }
        } catch (_) { /* Local profile remains authoritative while offline. */ }
        return false;
    };

    window.websiteMakerProfileStore = Object.freeze({ getState: () => clone(state), update, reconcile, subscribe, render, bind, flush, storageKey, hydrate: hydrateScope, normalizePhone: (value) => phoneParts(value).phoneDial });
    const start = () => {
        if (hydrateScope("hydrate")) loadRemote();
        else window.addEventListener("workspace:context-ready", () => { hydrateScope("context-ready"); loadRemote(); }, { once: true });
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
    document.addEventListener("website-maker:advanced-mounted", (event) => bind(event.detail?.root || document));
    document.addEventListener("website-maker:profile-record", (event) => reconcile(event.detail?.record, { source: event.detail?.source || "remote-reconcile" }));
    const restoreScope = () => { hydrateScope("project-changed"); loadRemote(); };
    document.addEventListener("workspace:project-changed", restoreScope);
    window.addEventListener("morrow:work-context", restoreScope);
    window.addEventListener("pagehide", () => flush(activeKey));
})();
