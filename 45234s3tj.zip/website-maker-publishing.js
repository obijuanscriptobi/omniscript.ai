"use strict";

(() => {
    const bind = () => {
        const ui = window.websiteMakerUI;
        const status = () => document.getElementById("go-live-status");
        const primary = () => document.getElementById("go-live-publish-btn");
        const deploy = () => document.getElementById("publish-site-btn");
        const download = () => document.getElementById("export-zip-btn");

        const canDeploy = () => Boolean(deploy() && !deploy().disabled && deploy().getAttribute("aria-disabled") !== "true");
        const syncPrimaryAction = () => {
            const button = primary();
            if (!button || document.body.dataset.draftReady !== "true") return;
            const approved = document.body.dataset.creationMode !== "client" || document.body.dataset.reviewApproved === "true";
            if (ui?.contactComplete?.() && approved && !canDeploy()) {
                button.textContent = "Download website files";
                button.dataset.action = "download";
            } else {
                button.textContent = "Publish website";
                button.dataset.action = "publish";
            }
        };

        primary()?.addEventListener("click", () => {
            if (!ui?.contactComplete()) {
                const invalid = ui?.firstInvalidContact();
                invalid?.focus();
                invalid?.reportValidity();
                if (status()) status().textContent = "Add valid phone, email, and availability before publishing. Visitors need a way to reach you.";
                return;
            }
            if (document.body.dataset.creationMode === "client" && document.body.dataset.reviewApproved !== "true") {
                document.getElementById("client-review-share-btn")?.focus();
                if (status()) status().textContent = "Wait for the client to approve this revision, then publish.";
                return;
            }
            if (primary()?.dataset.action === "download" || !canDeploy()) {
                if (!download() || download().disabled) {
                    if (status()) status().textContent = "Website files are still being prepared. Wait for the draft to finish, then download again.";
                    return;
                }
                download().click();
                if (status()) {
                    status().textContent = "Website files are ready for your hosting provider.";
                    status().tabIndex = -1;
                    status().focus({ preventScroll: true });
                }
                return;
            }
            deploy().click();
        });

        document.getElementById("go-live-download-btn")?.addEventListener("click", () => {
            if (!download() || download().disabled) {
                if (status()) status().textContent = "Website files are still being prepared. Wait for the draft to finish, then download again.";
                return;
            }
            download().click();
            if (status()) {
                status().textContent = "Website files are ready for your hosting provider.";
                status().tabIndex = -1;
                status().focus({ preventScroll: true });
            }
        });
        document.getElementById("go-live-copy-url-btn")?.addEventListener("click", async () => {
            const url = ui?.getPublishedUrl?.();
            if (!url) {
                if (status()) status().textContent = "Publish the website before copying its live URL.";
                return;
            }
            try {
                await navigator.clipboard.writeText(url);
                if (status()) status().textContent = "Live URL copied. Send it to a customer or client.";
            } catch (_) {
                if (status()) status().textContent = "Copy the live URL from the field above.";
            }
        });

        document.addEventListener("workspace:deployment-complete", (event) => {
            const url = event.detail?.url || document.getElementById("deployment-url-link")?.href || "";
            const deploymentRevision = String(event.detail?.revision || window.workspaceAPI?.getState?.().revision || "");
            if (!window.websiteMakerWorkflow?.transition?.("published", { source: "deployment", deploymentVerified: true, deploymentUrl: url, deploymentRevision })) return;
            const link = document.getElementById("go-live-url-link");
            if (url && link) {
                link.href = url;
                link.textContent = url.replace(/^https:\/\//, "");
                document.getElementById("go-live-url")?.removeAttribute("hidden");
                link.focus({ preventScroll: true });
            }
            if (status()) {
                status().textContent = url ? "It's live. Send this URL, then test the form once." : "Publishing started. The live URL will appear here.";
                status().tabIndex = -1;
                status().focus({ preventScroll: true });
            }
            ui?.updateConfidence?.();
            syncPrimaryAction();
        });
        document.addEventListener("workspace:deployment-failed", (event) => {
            const message = event.detail?.message || "Publishing failed. Your draft is still available.";
            if (status()) {
                status().textContent = message;
                status().tabIndex = -1;
                status().focus({ preventScroll: true });
            }
            syncPrimaryAction();
        });
        document.addEventListener("website-maker:state-changed", syncPrimaryAction);
        document.addEventListener("website-maker:profile-changed", syncPrimaryAction);
        document.addEventListener("workspace:review-updated", syncPrimaryAction);
        window.setTimeout(() => {
            syncPrimaryAction();
            const workflow = window.websiteMakerWorkflow?.getState?.();
            const url = ui?.getPublishedUrl?.();
            const link = document.getElementById("go-live-url-link");
            if (workflow?.state === "published" && url && link) {
                link.href = url;
                link.textContent = url.replace(/^https:\/\//, "");
                document.getElementById("go-live-url")?.removeAttribute("hidden");
            }
        }, 0);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
