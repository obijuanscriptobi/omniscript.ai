"use strict";

(() => {
    document.addEventListener("DOMContentLoaded", () => {
        const tools = document.getElementById("advanced-workspace-tools");
        const toggle = document.getElementById("show-advanced-tools-btn");
        const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");

        const mountAdvanced = () => {
            if (!tools || tools.dataset.mounted === "true") return false;
            const template = document.getElementById("advanced-workspace-tools-template");
            if (!template?.content) return false;
            tools.append(template.content.cloneNode(true));
            tools.dataset.mounted = "true";
            document.dispatchEvent(new CustomEvent("website-maker:advanced-mounted", { detail: { root: tools } }));
            return true;
        };

        const showStageError = (event) => {
            if (event.detail?.stage !== "advanced" || !tools || !toggle) return;
            const status = document.getElementById("advanced-tools-status");
            const message = event.detail?.error?.message || "Advanced tools could not load.";
            if (status && status.textContent !== message) status.textContent = message;
            let retry = tools.querySelector("[data-retry-advanced]");
            if (!retry) {
                retry = document.createElement("button");
                retry.type = "button";
                retry.className = "matrix-action-btn variant-outline-row";
                retry.dataset.retryAdvanced = "true";
                retry.textContent = "Retry advanced tools";
                retry.addEventListener("click", () => document.dispatchEvent(new CustomEvent("website-maker:advanced-requested")));
                tools.append(retry);
            }
            retry.focus({ preventScroll: true });
        };

        const setOpen = (open, moveFocus = false) => {
            if (!tools || !toggle) return;
            if (!open && tools.contains(document.activeElement)) toggle.focus({ preventScroll: true });
            tools.hidden = !open;
            document.getElementById("advanced-canvas-tools")?.toggleAttribute("hidden", !open);
            document.body.classList.toggle("advanced-tools-open", open);
            if (open) document.dispatchEvent(new CustomEvent("website-maker:advanced-requested"));
            toggle.setAttribute("aria-expanded", String(open));
            toggle.textContent = open ? "Hide advanced tools" : "Advanced tools";
            if (open && moveFocus) tools.scrollIntoView({ behavior: reducedMotion.matches ? "auto" : "smooth", block: "start" });
        };

        toggle?.addEventListener("click", () => setOpen(toggle.getAttribute("aria-expanded") !== "true", true));
        document.addEventListener("website-maker:stage-error", showStageError);
        document.addEventListener("website-maker:advanced-template-ready", mountAdvanced);
        document.addEventListener("website-maker:stage-ready", (event) => {
            if (event.detail?.stage !== "advanced") return;
            const retryHadFocus = tools?.querySelector("[data-retry-advanced]") === document.activeElement;
            tools?.querySelector("[data-retry-advanced]")?.remove();
            mountAdvanced();
            if (retryHadFocus) {
                const firstControl = tools?.querySelector("input, select, textarea, button, a[href]");
                firstControl?.focus({ preventScroll: true });
            }
        });
        document.addEventListener("workspace:project-changed", () => setOpen(false));
        document.addEventListener("click", (event) => {
            const link = event.target.closest('a[href$="#advanced-workspace-tools"]');
            if (!link) return;
            event.preventDefault();
            setOpen(true, true);
        });
        setOpen(false);
    }, { once: true });
})();
