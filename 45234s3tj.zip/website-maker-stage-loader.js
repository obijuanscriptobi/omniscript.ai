"use strict";

// Loads post-draft and advanced behavior once, only when the workflow needs it.
(() => {
    const stages = Object.freeze({
        draft: ["website-maker-contact.js", "website-maker-publishing.js", "enquiry-loop.js", "review-handoff.js"],
        advanced: ["website-maker-advanced-template.js", "workspace-schema.js", "platform-ui.js"]
    });
    const pending = new Map();
    const stagePromises = new Map();
    const loadedStages = new Set();
    const executionCounts = new Map();
    let projectEpoch = 0;

    const loadScript = (src) => {
        if (pending.has(src)) return pending.get(src);
        const existing = [...document.scripts].find((script) => {
            try { return new URL(script.src || "", document.baseURI).pathname.endsWith(`/${src}`); } catch (_) { return false; }
        });
        // A parser/defer script that appears before this module has already run,
        // even though it was not annotated by this loader.
        if (existing && (existing.dataset.loaded === "true" || !existing.async)) return Promise.resolve(existing);
        const promise = new Promise((resolve, reject) => {
            const script = existing?.dataset.loadFailed === "true" ? document.createElement("script") : (existing || document.createElement("script"));
            const done = () => {
                delete script.dataset.loadFailed;
                script.dataset.loaded = "true";
                executionCounts.set(src, (executionCounts.get(src) || 0) + 1);
                resolve(script);
            };
            script.addEventListener("load", done, { once: true });
            script.addEventListener("error", () => {
                script.dataset.loadFailed = "true";
                script.remove();
                reject(new Error(`Unable to load ${src}.`));
            }, { once: true });
            if (!script.isConnected) { script.src = src; script.async = false; document.head.append(script); }
        });
        pending.set(src, promise);
        promise.catch(() => pending.delete(src));
        return promise;
    };

    const loadStage = (name) => {
        if (loadedStages.has(name)) return Promise.resolve();
        if (stagePromises.has(name)) return stagePromises.get(name);
        const epoch = projectEpoch;
        const status = document.getElementById(name === "advanced" ? "advanced-tools-status" : "optional-tools-status");
        if (status) { status.hidden = false; status.textContent = `Loading ${name} tools…`; status.dataset.state = "loading"; }
        const promise = (async () => {
            try {
                for (const source of stages[name] || []) {
                    if (epoch !== projectEpoch) throw new DOMException("Project changed while tools were loading.", "AbortError");
                    await loadScript(source);
                }
                if (epoch !== projectEpoch) throw new DOMException("Project changed while tools were loading.", "AbortError");
                loadedStages.add(name);
                if (status) { status.textContent = `${name === "advanced" ? "Advanced" : "Draft"} tools ready.`; status.dataset.state = "ready"; }
                window.refreshWorkspaceStartupDiagnostics?.(`${name}-ready`);
                document.dispatchEvent(new CustomEvent("website-maker:stage-ready", { detail: { stage: name } }));
            } catch (error) {
                if (status) { status.textContent = error.name === "AbortError" ? "Tool loading stopped because the active project changed." : error.message || `The ${name} tools could not load.`; status.dataset.state = error.name === "AbortError" ? "idle" : "error"; }
                document.dispatchEvent(new CustomEvent("website-maker:stage-error", { detail: { stage: name, error } }));
                throw error;
            } finally {
                stagePromises.delete(name);
            }
        })();
        stagePromises.set(name, promise);
        return promise;
    };

    const sync = () => {
        const state = window.websiteMakerWorkflow?.getState?.().state;
        if (["draft", "review", "approved", "published"].includes(state)) loadStage("draft").catch(() => {});
    };
    document.addEventListener("website-maker:state-changed", sync);
    document.addEventListener("website-maker:advanced-requested", () => loadStage("advanced").catch(() => {}));
    document.addEventListener("workspace:project-changed", () => {
        projectEpoch += 1;
        loadedStages.clear();
        document.querySelectorAll("[data-stage-mounted]").forEach((node) => node.removeAttribute("data-stage-mounted"));
        sync();
    });
    document.addEventListener("DOMContentLoaded", sync, { once: true });
    window.websiteMakerStageLoader = Object.freeze({
        loadStage,
        loaded: (name) => loadedStages.has(name),
        pending: (name) => stagePromises.has(name),
        sources: (name) => [...(stages[name] || [])],
        executionCounts: () => Object.fromEntries(executionCounts),
        loadedScriptCount: () => [...document.scripts].filter((script) => Object.values(stages).flat().some((src) => {
            try { return new URL(script.src || "", document.baseURI).pathname.endsWith(`/${src}`); } catch (_) { return false; }
        })).length
    });
})();
