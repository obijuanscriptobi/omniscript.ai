"use strict";

// Canonical lifecycle and project-type state for the website maker. Body data
// attributes are compatibility render targets, never independent state.
(() => {
    const STORAGE_KEY = "omniscript-maker-workflow-v2";
    const LEGACY_KEY = "omniscript-maker-workflow-v1";
    const STATES = Object.freeze(["brief", "generating", "draft", "review", "approved", "published"]);
    const READY_STATES = new Set(["draft", "review", "approved", "published"]);
    const TRANSITIONS = Object.freeze({
        brief: ["generating", "draft"],
        generating: ["brief", "draft"],
        draft: ["brief", "generating", "review", "approved", "published"],
        review: ["draft", "generating", "approved"],
        approved: ["draft", "generating", "review", "published"],
        published: ["draft", "generating", "review", "approved"]
    });

    const storageKey = () => window.workspaceContext?.ready === true ? window.workspaceContext.storageKey(STORAGE_KEY) : "";
    let activeStorageKey = storageKey();
    const read = () => {
        try {
            const key = storageKey();
            if (!key) return null;
            const legacy = /::own:/.test(key) ? sessionStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(LEGACY_KEY) : null;
            const value = JSON.parse(sessionStorage.getItem(key) || legacy || "null");
            if (!value || !STATES.includes(value.state)) return null;
            return {
                ...value,
                projectType: value.projectType === "client" ? "client" : "owner",
                reviewStatus: ["draft", "shared", "changes-requested", "approved"].includes(value.reviewStatus) ? value.reviewStatus : "draft"
            };
        } catch (_) { return null; }
    };
    const persist = () => {
        const key = storageKey();
        if (!key || key !== activeStorageKey) return false;
        try { sessionStorage.setItem(key, JSON.stringify(record)); return true; } catch (_) { return false; }
    };
    const hasDraft = () => {
        const html = String(window.workspaceAPI?.getState?.().files?.["index.html"] || "").trim();
        return Boolean(html) && !html.startsWith("<!-- Awaiting");
    };
    const hasContact = () => {
        const profile = window.websiteMakerProfileStore?.getState?.();
        if (profile) {
            const digits = String(profile.identity?.phoneDial || profile.identity?.phoneDisplay || "").match(/\d/g) || [];
            return digits.length >= 7 && /\S+@\S+\.\S+/.test(String(profile.identity?.email || "")) && Boolean(String(profile.availability || "").trim());
        }
        const ids = ["outcome-phone-input", "outcome-email-input", "outcome-hours-input"];
        return ids.every((id) => {
            const field = document.getElementById(id);
            if (!field?.value.trim()) return false;
            if (id === "outcome-phone-input") return (field.value.match(/\d/g) || []).length >= 7;
            return field.validity?.valid !== false;
        });
    };
    const currentRevision = () => String(window.workspaceAPI?.getState?.().revision || window.workspaceDomain?.compile?.(window.workspaceAPI?.getState?.().files || {})?.revision || "");

    let record = read() || {
        state: "brief",
        projectType: "owner",
        reviewStatus: "draft",
        updatedAt: new Date().toISOString()
    };
    let recovery = null;

    if (record.state === "generating") {
        recovery = { from: "generating", interruptedAt: record.updatedAt };
        record = { ...record, reason: "generation-interrupted", state: "brief", updatedAt: new Date().toISOString() };
        persist();
    }

    const applyToDocument = () => {
        if (!document.body) return;
        const approved = record.projectType !== "client" || record.reviewStatus === "approved" || ["approved", "published"].includes(record.state);
        document.body.dataset.workflowState = record.state;
        document.body.dataset.draftReady = String(READY_STATES.has(record.state));
        document.body.dataset.reviewApproved = String(approved);
        document.body.dataset.creationMode = record.projectType;
    };

    const guard = (next, detail) => {
        if (READY_STATES.has(next) && next !== "draft" && !hasDraft()) return "Create or restore a valid draft first.";
        if (next === "approved") {
            const revision = currentRevision();
            if (!revision || detail.approvedRevision !== revision) return "Approval must match the current generated revision.";
        }
        if (next === "published") {
            if (!hasDraft()) return "A website draft is required before publishing.";
            if (!hasContact()) return "Phone, email, and availability are required before publishing.";
            if (record.projectType === "client" && record.reviewStatus !== "approved" && record.state !== "approved") return "Client approval is required before publishing.";
            if (detail.source !== "deployment" || !detail.deploymentVerified) return "A verified deployment event is required to mark the website published.";
            const revision = currentRevision();
            if (!revision || detail.deploymentRevision !== revision) return "Deployment evidence must match the current generated revision.";
            if (!/^https:\/\//i.test(String(detail.deploymentUrl || ""))) return "A verified HTTPS deployment URL is required.";
        }
        return "";
    };

    const transition = (next, detail = {}) => {
        if (!STATES.includes(next)) return false;
        const current = record.state;
        if (next !== current && !TRANSITIONS[current]?.includes(next)) {
            console.warn(`Ignored invalid website workflow transition: ${current} → ${next}`);
            return false;
        }
        const blocked = guard(next, detail);
        if (blocked) {
            document.dispatchEvent(new CustomEvent("website-maker:transition-blocked", { detail: { current, next, reason: blocked } }));
            return false;
        }
        record = { ...record, ...detail, state: next, updatedAt: new Date().toISOString() };
        if (next === "approved") {
            record.reviewStatus = "approved";
            record.approvedRevision = detail.approvedRevision;
        }
        if (next === "review" && record.reviewStatus !== "approved") record.reviewStatus = "shared";
        if (next === "draft" && detail.source === "client-review") record.reviewStatus = "changes-requested";
        persist();
        applyToDocument();
        document.dispatchEvent(new CustomEvent("website-maker:state-changed", { detail: { ...record, previous: current } }));
        return true;
    };

    const setProjectType = (value) => {
        const projectType = value === "client" ? "client" : "owner";
        if (record.projectType === projectType) return true;
        // Approval is revision- and project-type-specific; never carry it across.
        const nextState = ["approved", "review"].includes(record.state) ? "draft" : record.state;
        record = { ...record, projectType, reviewStatus: "draft", state: nextState, updatedAt: new Date().toISOString() };
        persist();
        applyToDocument();
        document.dispatchEvent(new CustomEvent("website-maker:project-type-changed", { detail: { projectType } }));
        return true;
    };

    const setReviewStatus = (status, detail = {}) => {
        if (!["draft", "shared", "changes-requested", "approved"].includes(status)) return false;
        if (status === "approved") {
            const approvedRevision = detail.approvedRevision || currentRevision();
            if (!approvedRevision || approvedRevision !== currentRevision()) return false;
            if (record.state === "published") {
                record = { ...record, reviewStatus: "approved", approvedRevision, updatedAt: new Date().toISOString() };
                persist(); applyToDocument(); return true;
            }
            return transition("approved", { ...detail, source: detail.source || "client-review", approvedRevision });
        }
        const nextState = status === "changes-requested" && READY_STATES.has(record.state) ? "draft" : record.state;
        record = { ...record, state: nextState, reviewStatus: status, approvedRevision: "", updatedAt: new Date().toISOString() };
        persist();
        applyToDocument();
        return true;
    };

    const reconcile = () => {
        let changed = false;
        if (READY_STATES.has(record.state) && !hasDraft()) {
            record = { ...record, state: "brief", reviewStatus: "draft", reason: "missing-draft", updatedAt: new Date().toISOString() };
            changed = true;
        } else {
            const revision = currentRevision();
            if (record.approvedRevision && revision && record.approvedRevision !== revision) {
                record = { ...record, state: "draft", reviewStatus: "draft", approvedRevision: "", reason: "revision-changed", updatedAt: new Date().toISOString() };
                changed = true;
            } else if (record.state === "published") {
                const deploymentUrl = String(record.deploymentUrl || "");
                if (!record.deploymentVerified || !/^https:\/\//i.test(deploymentUrl) || !record.deploymentRevision || record.deploymentRevision !== currentRevision()) {
                    record = { ...record, state: record.reviewStatus === "approved" && record.approvedRevision === currentRevision() ? "approved" : "draft", reason: "missing-deployment-evidence", updatedAt: new Date().toISOString() };
                    changed = true;
                }
            }
        }
        if (changed) persist();
        applyToDocument();
        return { ...record };
    };

    const consumeRecovery = () => {
        const value = recovery;
        recovery = null;
        return value;
    };

    window.websiteMakerWorkflow = Object.freeze({
        states: STATES,
        getState: () => ({ ...record }),
        transition,
        setProjectType,
        setReviewStatus,
        reconcile,
        consumeRecovery
    });

    if (document.body) applyToDocument();
    else document.addEventListener("DOMContentLoaded", applyToDocument, { once: true });
    document.addEventListener("workspace:core-ready", () => {
        const nextStorageKey = storageKey();
        if (nextStorageKey !== activeStorageKey) {
            activeStorageKey = nextStorageKey;
            record = read() || { state: "brief", projectType: "owner", reviewStatus: "draft", updatedAt: new Date().toISOString() };
        }
        reconcile();
    });
    const restoreProjectState = () => {
        activeStorageKey = storageKey();
        record = read() || { state: "brief", projectType: "owner", reviewStatus: "draft", updatedAt: new Date().toISOString() };
        reconcile();
        document.dispatchEvent(new CustomEvent("website-maker:state-changed", { detail: { ...record, previous: null, source: "project-changed" } }));
    };
    document.addEventListener("workspace:project-changed", restoreProjectState);
    window.addEventListener?.("morrow:work-context", restoreProjectState);
    document.addEventListener("workspace:files-rendered", (event) => {
        const revision = String(event.detail?.revision || window.workspaceAPI?.getState?.().revision || "");
        if (!revision || !record.approvedRevision || revision === record.approvedRevision) return;
        if (record.reviewStatus === "approved" || record.state === "approved") {
            record = { ...record, state: "draft", reviewStatus: "draft", approvedRevision: "", reason: "revision-changed", updatedAt: new Date().toISOString() };
            persist();
            applyToDocument();
            document.dispatchEvent(new CustomEvent("website-maker:state-changed", { detail: { ...record, previous: "approved" } }));
        }
    });
})();
