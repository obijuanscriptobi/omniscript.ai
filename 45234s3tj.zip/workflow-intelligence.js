"use strict";

// Fast, dependency-free workflow intelligence. This module keeps interaction
// local and immediate while leaving generation and publishing to the existing
// editor contracts.
(() => {
    const CACHE_LIMIT = 12;
    const DEFAULTS = Object.freeze({
        quote: { cta: "Request a quote", type: "local-service", style: "modern", sections: ["hero", "services", "proof", "contact"] },
        booking: { cta: "Book an appointment", type: "wellness", style: "warm", sections: ["hero", "services", "proof", "booking"] },
        call: { cta: "Call now", type: "local-service", style: "warm", sections: ["hero", "services", "location", "contact"] },
        email: { cta: "Send an enquiry", type: "professional", style: "premium", sections: ["hero", "services", "proof", "contact"] },
        shop: { cta: "Explore products", type: "retail", style: "modern", sections: ["hero", "products", "proof", "contact"] }
    });
    const cache = new Map();
    let updateTimer = null;
    let updateRevision = 0;

    const text = (id) => String(document.getElementById(id)?.value || "").trim();
    const goal = () => text("input-primary-goal") || "quote";
    const hash = (value) => {
        let result = 2166136261;
        for (const character of String(value || "")) {
            result ^= character.charCodeAt(0);
            result = Math.imul(result, 16777619);
        }
        return (result >>> 0).toString(16);
    };

    function briefKey() {
        return hash(JSON.stringify({
            name: text("input-biz-name"), hook: text("input-biz-hook"), location: text("input-biz-location"),
            audience: text("input-biz-audience"), offer: text("input-biz-services"), goal: goal(),
            style: text("input-design-style"), density: text("input-layout-density")
        }));
    }

    function inferDecision(inputGoal = goal()) {
        const fallback = DEFAULTS[inputGoal] || DEFAULTS.quote;
        const type = text("input-business-type") || fallback.type;
        const audience = text("input-biz-audience");
        const location = text("input-biz-location");
        const hasOffer = Boolean(text("input-biz-hook") || text("input-biz-services"));
        const intent = { quote: "lead generation", booking: "appointment booking", call: "local calls", email: "qualified enquiries", shop: "product discovery" }[inputGoal] || "lead generation";
        const urgency = ["call", "quote"].includes(inputGoal) ? "high" : inputGoal === "booking" ? "medium" : "considered";
        const local = Boolean(location) || ["local-service", "restaurant", "wellness"].includes(type);
        const trust = ["professional", "wellness", "local-service"].includes(type) ? "proof, credentials, and clear contact details" : "specific products, work examples, or customer evidence";
        const assets = type === "retail" ? ["product imagery", "pricing or product details"] : type === "creative" ? ["work examples", "client or project proof"] : ["approved hero image", "service or team imagery"];
        const reason = inputGoal === "quote"
            ? `This draft uses a quote-first ${local ? "local service" : "service"} layout because visitors need to understand the offer, trust the provider, and request an estimate.`
            : `This draft prioritizes ${intent} because visitors need a clear next step, relevant proof, and low-friction access to the business.`;
        return { category: type, intent, urgency, locationRelevance: local ? "high" : "standard", conversion: inputGoal, trustRequirements: trust, requiredAssets: assets, rationale: reason, confidence: hasOffer && (audience || location) ? "high" : "medium" };
    }

    function inferDefaults(inputGoal = goal()) {
        return { ...(DEFAULTS[inputGoal] || DEFAULTS.quote), goal: inputGoal, decision: inferDecision(inputGoal) };
    }

    function applyDefaults(options = {}) {
        const defaults = inferDefaults(options.goal);
        const setIfEmpty = (id, value) => {
            const field = document.getElementById(id);
            if (field && !String(field.value || "").trim() && value) field.value = value;
        };
        setIfEmpty("input-primary-cta", defaults.cta);
        setIfEmpty("input-business-type", defaults.type);
        setIfEmpty("input-design-style", defaults.style);
        const summary = document.getElementById("guided-wizard-summary");
        if (summary) summary.textContent = defaults.decision.rationale;
        renderDecision(defaults.decision);
        document.dispatchEvent(new CustomEvent("workspace:smart-defaults-applied", { detail: defaults }));
        return defaults;
    }

    function renderDecision(decision = inferDecision()) {
        const panel = document.getElementById("workflow-decision-panel");
        if (!panel) return decision;
        panel.hidden = false;
        const rationale = panel.querySelector("[data-decision-rationale]");
        if (rationale) rationale.textContent = decision.rationale;
        const list = panel.querySelector("[data-decision-list]");
        if (list) list.replaceChildren(...[
            ["Business category", decision.category], ["Customer intent", decision.intent], ["Buying urgency", decision.urgency],
            ["Location relevance", decision.locationRelevance], ["Trust needed", decision.trustRequirements], ["Assets to consider", decision.requiredAssets.join(", ")]
        ].map(([label, value]) => { const li = document.createElement("li"); li.textContent = `${label}: ${value}`; return li; }));
        return decision;
    }

    function getReadiness() {
        const findings = [];
        const add = (id, category, message, action, impact = 3) => findings.push({ id, category, message, action, impact });
        if (!text("input-biz-name")) add("name", "content", "Add your business name so visitors know who they are dealing with.", "Add business name", 5);
        if (!text("input-biz-hook")) add("offer", "conversion", "Explain the result you provide in one clear sentence.", "Clarify your offer", 5);
        if (!text("input-biz-location") && ["quote", "call", "booking"].includes(goal())) add("location", "content", "Adding your service area could make this page more useful for local visitors.", "Add service area", 4);
        if (!text("input-primary-cta")) add("cta", "conversion", `Choose the words visitors should see for your ${goal()} action.`, "Set primary CTA", 5);
        if (!text("input-biz-services")) add("services", "content", "Add your main services so visitors can quickly understand what you offer.", "Add services", 4);
        if (!text("input-biz-phone") && goal() === "call") add("phone", "conversion", "Add a phone number so the call action can work on mobile.", "Add phone number", 5);
        if (!text("input-biz-booking") && goal() === "booking") add("booking", "conversion", "Add a booking link or use the enquiry form as your appointment path.", "Add booking link", 5);
        if (!text("input-biz-testimonial") && !text("input-biz-credentials") && !text("input-biz-differentiator")) add("trust", "content", "Add one verified difference, credential, or customer quote to strengthen trust.", "Add trust signal", 3);
        if (!text("input-biz-hero-image")) add("hero-asset", "content", "A hero image is optional; a CSS composition will be used until you add an approved image.", "Review hero asset", 2);
        if (!text("input-biz-email") && goal() === "email") add("email", "conversion", "Add an email address so enquiries have a clear destination.", "Add email", 5);
        const blocking = findings.some((item) => item.impact >= 5 && ["name", "offer", "cta"].includes(item.id));
        return {
            state: blocking ? "blocked" : findings.length ? "needs-attention" : "ready",
            score: Math.max(0, Math.min(100, 100 - findings.reduce((sum, item) => sum + item.impact * 3, 0))),
            findings: findings.sort((a, b) => b.impact - a.impact),
            checkedAt: new Date().toISOString()
        };
    }

    function scheduleUpdate(callback, delay = 280) {
        if (updateTimer) window.clearTimeout(updateTimer);
        const revision = ++updateRevision;
        updateTimer = window.setTimeout(() => {
            updateTimer = null;
            if (revision !== updateRevision) return;
            callback?.({ revision, key: briefKey(), readiness: getReadiness() });
        }, Math.max(100, delay));
        return revision;
    }

    function cacheResult(key, value) {
        if (!key) return value;
        cache.delete(key);
        cache.set(key, value);
        while (cache.size > CACHE_LIMIT) cache.delete(cache.keys().next().value);
        return value;
    }

    function getCached(key = briefKey()) {
        return cache.get(key) || null;
    }

    function snapshot(label = "Draft") {
        const business = window.workspaceFields?.readBusiness?.((value) => value) || {};
        const formSettings = window.workspaceFields?.readFormSettings?.() || {};
        return Object.freeze({ id: `${Date.now()}-${hash(label)}`, label, createdAt: new Date().toISOString(), key: briefKey(), business: JSON.parse(JSON.stringify(business)), formSettings: JSON.parse(JSON.stringify(formSettings)) });
    }

    function saveSnapshot(label = "Draft") {
        const item = snapshot(label);
        const snapshots = Array.isArray(window.workspaceWorkflowHistory) ? window.workspaceWorkflowHistory : [];
        window.workspaceWorkflowHistory = [...snapshots, item].slice(-20);
        document.dispatchEvent(new CustomEvent("workspace:workflow-snapshot", { detail: item }));
        return item;
    }

    function restoreSnapshot(item) {
        if (!item?.business || !window.workspaceFields?.apply) return false;
        window.workspaceFields.apply({ form: { business: item.business, formSettings: item.formSettings || {} } });
        document.dispatchEvent(new CustomEvent("workspace:workflow-snapshot-restored", { detail: item }));
        return true;
    }

    function renderReadiness(readiness = getReadiness()) {
        const target = document.getElementById("workspace-readiness-panel");
        if (!target) return readiness;
        target.dataset.state = readiness.state;
        const title = target.querySelector("[data-readiness-title]");
        const score = target.querySelector("[data-readiness-score]");
        const list = target.querySelector("[data-readiness-list]");
        if (title) title.textContent = readiness.state === "ready" ? "Ready to publish" : readiness.state === "blocked" ? "Needs a few essentials" : "Almost ready";
        if (score) score.textContent = `${readiness.score}% ready`;
        if (list) {
            list.replaceChildren(...readiness.findings.slice(0, 4).map((item) => {
                const li = document.createElement("li");
                li.textContent = item.message;
                li.dataset.category = item.category;
                return li;
            }));
        }
        return readiness;
    }

    function bind() {
        document.addEventListener("input", (event) => {
            if (!event.target.matches("input, textarea, select")) return;
            scheduleUpdate(({ key, readiness }) => {
                cacheResult(key, { key, readiness, updatedAt: new Date().toISOString() });
                renderReadiness(readiness);
                document.dispatchEvent(new CustomEvent("workspace:incremental-update", { detail: { key, readiness } }));
            });
        });
        document.addEventListener("change", (event) => {
            if (event.target.id === "input-primary-goal") applyDefaults({ goal: event.target.value });
        });
        document.addEventListener("click", (event) => {
            const action = event.target.closest("[data-workflow-action]");
            if (!action) return;
            const command = action.dataset.workflowAction;
            if (command === "save-version") saveSnapshot(action.dataset.label || "Manual edit");
            if (command === "apply-defaults") applyDefaults();
            if (command === "refresh-readiness") renderReadiness();
        });
        window.addEventListener("workspace:core-ready", () => {
            applyDefaults();
            renderReadiness();
        }, { once: true });
    }

    window.workspaceWorkflow = Object.freeze({ inferDefaults, inferDecision, applyDefaults, getReadiness, scheduleUpdate, cacheResult, getCached, snapshot, saveSnapshot, restoreSnapshot, renderReadiness, renderDecision });
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
