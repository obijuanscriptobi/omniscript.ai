"use strict";
(() => {
    const context = () => window.conversionLoop?.readContext?.();
    const state = () => window.workspaceAPI?.getState?.() || window.workspaceState?.getState?.() || {};
    function applyRevision(revision) {
        const current = state();
        const result = window.conversionLoop?.applyApprovedChanges?.(current.files || {}, revision);
        if (!result) return result;
        if (result.conflicted) {
            window.conversionLoop?.updateRevision?.(revision.id, { status: "validation-failed", conflicts: result.conflicts });
            document.dispatchEvent(new CustomEvent("workspace:revision-conflict", { detail: { revision, ...result } }));
            return result;
        }
        if (!result.applied?.length) return result;
        const replace = window.workspaceAPI?.replaceFiles || window.workspaceCore?.replaceFiles;
        if (typeof replace === "function") replace(result.files, { reason: "approved-audit-revision", revisionId: revision.id });
        window.workspacePreviewController?.create?.({ state: current, get: (id) => document.getElementById(id) })?.update?.();
        window.conversionLoop?.captureVisualEvidence?.(revision, "after");
        window.conversionLoop?.updateRevision?.(revision.id, { status: "ready-for-review", appliedChanges: result.applied, conflicts: [] });
        document.dispatchEvent(new CustomEvent("workspace:revision-applied", { detail: { revision, ...result } }));
        return result;
    }
    function load() { const current = context(); if (!current?.revisionId) return null; return window.conversionLoop?.listRevisions?.().find((item) => item.id === current.revisionId) || null; }
    window.workflowRevisions = Object.freeze({ context, load, applyRevision });
    document.addEventListener("DOMContentLoaded", () => { const revision = load(); if (revision) document.body.dataset.auditRevisionId = revision.id; });
})();
