"use strict";

// Visible workflow layer for the website-making path. It coordinates existing
// field, preview, generator, and readiness contracts without replacing them.
(() => {
    if (window.__workflowStudioBound) return;
    window.__workflowStudioBound = true;
    window.workflowStudio = window.workflowStudio || {};

    const STEPS = [
        { label: "Business basics", target: "#business-details", required: ["input-biz-name", "input-biz-hook", "input-biz-location", "input-biz-audience"] },
        { label: "Primary goal", target: "#conversion-goal-title", required: ["input-primary-goal"] },
        { label: "Brand direction", target: "#creative-direction-title", required: ["input-business-type", "input-design-style"] },
        { label: "Content and assets", target: "#asset-management-title", required: [] },
        { label: "Generate", target: "#primary-create-website-btn", required: [] }
    ];
    const SECTIONS = ["Hero", "Navigation", "Services", "Products", "Portfolio", "Testimonials", "FAQ", "Contact", "Footer", "Mobile layout"];
    const IMPROVEMENTS = [
        ["clearer", "Make this clearer", "content"], ["premium", "Make it feel more premium", "design"],
        ["booking", "Increase booking focus", "conversion"], ["cta", "Strengthen the CTA", "conversion"],
        ["trust", "Add trust", "trust"], ["mobile", "Improve mobile layout", "mobile"],
        ["shorter", "Shorten the copy", "content"], ["warmer", "Make it warmer", "tone"],
        ["local", "Add local relevance", "local"]
    ];
    let step = 0;
    let history = [];
    let auditEntries = [];
    let sectionVersions = new Map();
    let lastFormKey = "";
    let activeOperation = null;
    let workflowStatus = "idle";

    const $ = (selector, root = document) => root.querySelector(selector);
    const field = (id) => document.getElementById(id);
    const value = (id) => String(field(id)?.value || "").trim();
    const state = () => window.workspaceAPI?.getState?.() || null;
    const key = () => {
        const fields = window.workspaceFields?.readBusiness?.((v) => v) || {};
        return window.workspaceCore?.hash?.(JSON.stringify(fields)) || JSON.stringify(fields);
    };
    const toast = (message, kind = "success") => {
        let node = $("#workflow-studio-toast");
        if (!node) {
            node = document.createElement("div"); node.id = "workflow-studio-toast"; node.className = "workflow-studio-toast";
            node.setAttribute("role", "status"); node.setAttribute("aria-live", "polite"); document.body.append(node);
        }
        node.dataset.state = kind; node.textContent = message; node.hidden = false;
        clearTimeout(node._timer); node._timer = setTimeout(() => { node.hidden = true; }, 3200);
    };
    const scrollTo = (target) => document.querySelector(target)?.scrollIntoView({ behavior: "smooth", block: "center" });

    function readHistory() {
        try { const saved = JSON.parse(localStorage.getItem("workflow-studio-history") || "[]"); return Array.isArray(saved) ? saved.slice(-12) : []; } catch { return []; }
    }
    function readAuditEntries() {
        try { const saved = JSON.parse(localStorage.getItem("workflow-studio-audit") || "[]"); return Array.isArray(saved) ? saved.slice(-24) : []; } catch { return []; }
    }
    function persist() {
        try {
            localStorage.setItem("workflow-studio-history", JSON.stringify(history.slice(-12)));
            localStorage.setItem("workflow-studio-audit", JSON.stringify(auditEntries.slice(-24)));
        } catch {}
    }
    function addAuditEntry(label, category, status, before, after, scope = "") {
        const changedFiles = window.workspaceCore?.diffFiles?.(before?.files || {}, after?.files || {}) || [];
        const entry = {
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            label, category, status, scope,
            createdAt: new Date().toISOString(),
            beforeRevision: snapshotRevision(before),
            afterRevision: snapshotRevision(after),
            flaws: describeFlaws(category, before),
            fixes: describeFixes(category, after),
            files: changedFiles.map((change) => change.name)
        };
        auditEntries = [...auditEntries, entry].slice(-24);
        persist();
        renderAuditTrail();
        return entry;
    }
    function describeFlaws(category, snapshot) {
        const html = String(snapshot?.files?.["index.html"] || "");
        const flaws = {
            content: "The draft message was not as clear or concise as it could be.",
            conversion: "The primary customer action was not prominent or consistently connected.",
            design: "The visual treatment needed stronger hierarchy, polish, or consistency.",
            mobile: "The layout needed better small-screen spacing, sizing, or touch targets.",
            trust: "The draft was missing a visible, approved trust signal.",
            local: "The service area was not clearly represented in the draft.",
            tone: "The copy tone did not yet match the intended customer experience."
        };
        if (/awaiting data submission/i.test(html)) return "The original project had not yet produced a usable draft.";
        return flaws[category] || "The original draft had an opportunity for improvement in this area.";
    }
    function describeFixes(category, snapshot) {
        const html = String(snapshot?.files?.["index.html"] || "");
        const css = String(snapshot?.files?.["style.css"] || "");
        const fixes = {
            content: "Copy was revised while preserving the existing page structure.",
            conversion: "The primary action was aligned with the selected customer goal.",
            design: "Design-only styles were added without rewriting the page copy.",
            mobile: "Responsive rules were added to improve spacing, type scale, and touch targets.",
            trust: "Approved business proof was added to a dedicated trust section.",
            local: "The supplied service area was added to the visible page content.",
            tone: "The proposed copy direction was adjusted without changing the business facts."
        };
        return `${fixes[category] || "A scoped improvement was prepared."} ${html && css ? "The updated draft remains available for review." : "Review the generated result before publishing."}`;
    }
    function makeSnapshot(label, section = "") {
        const current = state();
        return {
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            label, section, createdAt: new Date().toISOString(), key: key(),
            business: window.workspaceFields?.readBusiness?.((v) => v) || {},
            formSettings: window.workspaceFields?.readFormSettings?.() || {},
            files: current?.files ? { ...current.files } : null
        };
    }
    function saveVersion(label, section = "") {
        setWorkflowStatus("saving", "Saving checkpoint…");
        const snapshot = makeSnapshot(label, section);
        history = [...history, snapshot].slice(-12);
        try {
            persist();
            setWorkflowStatus("saved", "Checkpoint saved locally");
        } catch {
            setWorkflowStatus("failed", "Checkpoint save failed");
        }
        renderHistory();
        window.workspaceWorkflow?.saveSnapshot?.(label);
        document.dispatchEvent(new CustomEvent("workspace:version-saved", { detail: snapshot }));
        return snapshot;
    }
    function restoreVersion(snapshot) {
        if (!snapshot) return;
        if (snapshot.files && window.workspaceAPI?.applySnapshot) {
            window.workspaceAPI.applySnapshot({ ...snapshot, form: { business: snapshot.business, formSettings: snapshot.formSettings || {} } }, { dirty: true });
        } else if (window.workspaceFields?.apply) {
            window.workspaceFields.apply({ form: { business: snapshot.business, formSettings: snapshot.formSettings || {} } });
        }
        document.dispatchEvent(new CustomEvent("workspace:version-restored", { detail: snapshot }));
        renderAll(); toast(`Restored “${snapshot.label}”. Your current draft was kept in history.`);
    }

    function readiness() {
        const report = window.workspaceWorkflow?.getReadiness?.() || { state: "needs-attention", score: 0, findings: [] };
        const groups = { content: [], conversion: [], accessibility: [], mobile: [], performance: [], security: [] };
        report.findings.forEach((item) => (groups[item.category] || groups.content).push(item));
        return { ...report, groups };
    }
    function renderReadinessGate() {
        const panel = $("#workflow-publish-gate"); if (!panel) return;
        const gate = publishGateReport();
        const report = gate.workflow;
        const release = gate.release;
        panel.dataset.state = gate.blocked ? (report.state === "blocked" || release?.blocking ? "blocked" : "needs-attention") : "ready";
        $("[data-gate-title]", panel).textContent = gate.blocked ? (release?.blocking ? "Blocked by release checks" : report.state === "blocked" ? "Blocked until essentials are added" : "Needs attention before publishing") : "Ready to publish";
        $("[data-gate-score]", panel).textContent = `${release ? Math.min(report.score, release.score) : report.score}% ready`;
        const list = $("[data-gate-findings]", panel); list.replaceChildren();
        Object.entries(report.groups).forEach(([category, items]) => {
            if (!items.length) return;
            const group = document.createElement("li"); group.className = "workflow-gate-group";
            const heading = document.createElement("strong"); heading.textContent = category[0].toUpperCase() + category.slice(1); group.append(heading);
            const detail = document.createElement("span"); detail.textContent = items[0].message; group.append(detail);
            const button = document.createElement("button"); button.type = "button"; button.className = "matrix-action-btn variant-outline-row"; button.textContent = items[0].action || "Review";
            button.addEventListener("click", () => focusFinding(items[0])); group.append(button); list.append(group);
        });
        if (release?.blocking) {
            const group = document.createElement("li");
            group.className = "workflow-gate-group";
            const heading = document.createElement("strong");
            heading.textContent = "Release checks";
            const detail = document.createElement("span");
            const first = release.results?.find((item) => !item.pass);
            detail.textContent = first
                ? `${first.message} · ${first.affected || "generated project"} · ${first.evidenceState || "missing"} evidence · ${first.revisionState || "current"} revision`
                : `${release.blocking} release blocker${release.blocking === 1 ? "" : "s"} require attention.`;
            const remediation = document.createElement("small");
            remediation.textContent = first ? `Fix: ${first.remediation || "Review release findings."} · ${first.fixType || "manual"}` : "Review release findings.";
            group.append(heading, detail, remediation);
            const button = document.createElement("button");
            button.type = "button";
            button.className = "matrix-action-btn variant-outline-row";
            button.textContent = "Open release review";
            button.addEventListener("click", () => { document.getElementById("run-release-review-btn")?.click(); scrollTo("#release-review-title"); });
            group.append(button);
            list.append(group);
        }
    }
    function focusFinding(item) {
        const ids = { name: "input-biz-name", offer: "input-biz-hook", location: "input-biz-location", cta: "input-primary-cta", services: "input-biz-services", phone: "input-biz-phone", booking: "input-biz-booking", email: "input-biz-email", trust: "input-biz-differentiator", "hero-asset": "input-biz-hero-image" };
        const target = ids[item.id]; if (target) { field(target)?.focus(); field(target)?.scrollIntoView({ behavior: "smooth", block: "center" }); } else scrollTo("#business-details");
    }

    function renderAuditTrail() {
        const list = $("#workflow-audit-list");
        if (!list) return;
        list.replaceChildren(...auditEntries.slice().reverse().map((entry) => {
            const li = document.createElement("li");
            li.className = "workflow-audit-item";
            li.dataset.status = entry.status;
            const heading = document.createElement("strong");
            heading.textContent = `${entry.label} · ${entry.status === "accepted" ? "Improved" : entry.status === "kept" ? "Original kept" : entry.status}`;
            const flaw = document.createElement("span");
            flaw.textContent = `Original flaw: ${entry.flaws}`;
            const fix = document.createElement("span");
            fix.textContent = `Improved/fixed: ${entry.fixes}`;
            const meta = document.createElement("small");
            meta.textContent = `${entry.scope || entry.category} · ${entry.files.length ? entry.files.join(", ") : "No file change"} · ${new Date(entry.createdAt).toLocaleString()}`;
            li.append(heading, flaw, fix, meta);
            return li;
        }));
        if (!auditEntries.length) {
            const empty = document.createElement("li");
            empty.className = "workflow-history-empty";
            empty.textContent = "Original flaws and applied fixes will appear here after a review.";
            list.append(empty);
        }
    }

    function renderHistory() {
        const list = $("#workflow-history-list"); if (!list) return;
        list.replaceChildren(...history.slice().reverse().map((item) => {
            const li = document.createElement("li"); li.className = "workflow-history-item";
            const info = document.createElement("span"); info.innerHTML = `<strong></strong><small></small>`; $("strong", info).textContent = item.label; $("small", info).textContent = new Date(item.createdAt).toLocaleString();
            const restore = document.createElement("button"); restore.type = "button"; restore.className = "matrix-action-btn variant-outline-row"; restore.textContent = "Restore"; restore.addEventListener("click", () => restoreVersion(item));
            li.append(info, restore); return li;
        }));
        if (!history.length) { const empty = document.createElement("li"); empty.className = "workflow-history-empty"; empty.textContent = "Your first draft and safe checkpoints will appear here."; list.append(empty); }
    }

    function applyStep(next) {
        const proposed = Math.max(0, Math.min(STEPS.length - 1, next));
        const current = STEPS[step];
        if (proposed > step) {
            const missing = current.required.find((id) => !value(id));
            if (missing) { field(missing)?.focus(); field(missing)?.scrollIntoView({ behavior: "smooth", block: "center" }); toast("Complete the highlighted essentials before continuing.", "warning"); return; }
        }
        step = proposed; renderStepper(); scrollTo(STEPS[step].target);
        try { localStorage.setItem("workflow-studio-step", String(step)); } catch {}
    }
    function renderStepper() {
        const root = $("#workflow-studio-stepper"); if (!root) return;
        root.querySelectorAll("[data-step-index]").forEach((node) => { const index = Number(node.dataset.stepIndex); node.classList.toggle("is-active", index === step); node.classList.toggle("is-complete", index < step); node.setAttribute("aria-current", index === step ? "step" : "false"); });
        $("[data-step-progress]", root).style.width = `${(step / (STEPS.length - 1)) * 100}%`;
        $("[data-step-label]", root).textContent = STEPS[step].label;
        $("[data-step-back]", root).disabled = step === 0;
        $("[data-step-next]", root).textContent = step === STEPS.length - 1 ? "Create first draft" : "Continue";
    }

    let pendingChange = null;

    function projectSnapshot() {
        const current = state();
        return current ? {
            ...current,
            files: { ...(current.files || {}) },
            form: JSON.parse(JSON.stringify(current.form || {})),
            workflowStep: step,
            workflowRevision: Number(current.workflowRevision || 0),
            revision: String(current.revision || "")
        } : null;
    }

    function snapshotRevision(snapshot) {
        if (!snapshot) return "";
        const domainRevision = String(window.workspaceDomain?.revisionOf?.(snapshot.files || {}) || "").trim();
        if (domainRevision) return domainRevision;
        return window.workspaceCore?.hash?.(JSON.stringify({ files: snapshot.files || {}, form: snapshot.form || {} })) || JSON.stringify({ files: snapshot.files || {}, form: snapshot.form || {} });
    }

    function markEvidenceStale() {
        const current = state();
        if (!current) return;
        if (typeof window.workspaceAPI?.updateState === "function") {
            window.workspaceAPI.updateState({ readiness: "stale-after-change", evidenceLedger: [] });
        }
        document.dispatchEvent(new CustomEvent("workspace:evidence-stale", { detail: { revision: snapshotRevision(current) } }));
    }

    function setWorkflowStatus(status, message = "") {
        workflowStatus = status;
        document.documentElement.dataset.workflowStatus = status;
        const node = $("[data-workflow-status]");
        if (node) node.textContent = message || ({ idle: "Ready", saving: "Saving…", saved: "Saved locally", failed: "Save failed", proposing: "Reviewing a proposal" }[status] || status);
    }

    function applyProject(snapshot) {
        if (!snapshot || !window.workspaceAPI?.applySnapshot) return false;
        const startedAt = performance.now?.() || Date.now();
        performance.mark?.("workflow-scoped-update-start");
        window.workspaceAPI.applySnapshot(snapshot, { dirty: true });
        markEvidenceStale();
        setWorkflowStatus("saved", "Draft updated locally");
        const elapsed = Math.round((performance.now?.() || Date.now()) - startedAt);
        performance.mark?.("workflow-scoped-update-end");
        performance.measure?.("workflow-scoped-update", "workflow-scoped-update-start", "workflow-scoped-update-end");
        document.documentElement.dataset.workflowUpdateMs = String(elapsed);
        document.dispatchEvent(new CustomEvent("workspace:scoped-change-applied", { detail: snapshot }));
        renderAll();
        return true;
    }

    function textChange(html, pattern, replacement) {
        return String(html || "").replace(pattern, replacement);
    }

    function scopedFiles(id, category, source) {
        const files = { ...(source.files || {}) };
        let html = String(files["index.html"] || "");
        let css = String(files["style.css"] || "");
        const goalLabel = value("input-primary-cta") || "Get started";
        if (category === "content") {
            const sectionCopy = {
                hero: "<p data-workflow-variation=\"hero\">A focused introduction that makes the next step easy to understand.</p>",
                services: "<section data-workflow-variation=\"services\"><h2>Services designed around your needs</h2><p>Explore the practical ways we can help.</p></section>",
                products: "<section data-workflow-variation=\"products\"><h2>Explore our products</h2><p>See the options available for your next step.</p></section>",
                portfolio: "<section data-workflow-variation=\"portfolio\"><h2>Recent work</h2><p>See how thoughtful work can support your goals.</p></section>",
                testimonials: "<section data-workflow-variation=\"testimonials\"><h2>Customer perspective</h2><p>Review approved customer feedback here.</p></section>",
                faq: "<section data-workflow-variation=\"faq\"><h2>Frequently asked questions</h2><details><summary>How do I get started?</summary><p>Contact us and we will recommend the right next step.</p></details></section>",
                contact: "<section data-workflow-variation=\"contact\"><h2>Ready to take the next step?</h2><p>Use the primary action below to get in touch.</p></section>",
                footer: "<footer data-workflow-variation=\"footer\"><p>Questions? We are here to help.</p></footer>"
            };
            const addition = sectionCopy[id];
            if (addition && !html.includes(`data-workflow-variation=\"${id}\"`)) html = html.replace(/<\/main>/i, `${addition}</main>`);
            if (id === "clearer") html = textChange(html, /(<h1\b[^>]*>)([\s\S]*?)(<\/h1>)/i, "$1A clearer next step for your business$3");
            if (id === "shorter") html = textChange(html, /(<p\b[^>]*>)([\s\S]{180,}?)(<\/p>)/i, "$1Learn how we can help and take the next step with confidence.$3");
        }
        if (category === "conversion") {
            html = html.replace(/(>)(Request a quote|Book an appointment|Call now|Send an enquiry|Get started|Learn more)(<)/gi, `$1${goalLabel}$3`);
            if (id === "booking") html = html.replace(/(<body\b[^>]*>)/i, `$1<!-- Booking-focused layout: keep the primary appointment path prominent. -->`);
        }
        if (category === "trust") {
            const proof = value("input-biz-differentiator") || value("input-biz-credentials");
            if (proof && !html.includes(proof)) html = html.replace(/(<main\b[^>]*>)/i, `$1<section data-workflow-section="trust"><h2>Why customers choose us</h2><p>${proof.replace(/[<>&]/g, (character) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[character]))}</p></section>`);
        }
        if (category === "local") {
            const location = value("input-biz-location");
            if (location && !html.includes(location)) html = html.replace(/(<h1\b[^>]*>[\s\S]*?<\/h1>)/i, `$1<p data-workflow-local>Serving ${escapeText(location)}</p>`);
        }
        if (category === "design") css += "\\n/* Scoped workflow improvement: premium direction. */\\n:root{--workflow-corner:14px;--workflow-shadow:0 18px 45px rgba(0,0,0,.16)} section,article,.card{border-radius:var(--workflow-corner);box-shadow:var(--workflow-shadow)}\\n";
        if (category === "mobile") css += "\\n/* Scoped workflow improvement: mobile hierarchy. */\\n@media (max-width:700px){main{padding-inline:1rem}h1{font-size:clamp(2rem,10vw,3.4rem);line-height:1.05}button,.button,a[role=button]{min-height:44px}}\\n";
        files["index.html"] = html;
        files["style.css"] = css;
        return files;
    }

    function escapeText(value) {
        return String(value || "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character]));
    }

    function semanticChanges(before = "", after = "", filename = "") {
        const oldText = String(before || "");
        const newText = String(after || "");
        if (oldText === newText) return [];
        const oldLines = oldText.split(/\r?\n/);
        const newLines = newText.split(/\r?\n/);
        const changes = [];
        const max = Math.max(oldLines.length, newLines.length);
        for (let index = 0; index < max; index += 1) {
            const removed = oldLines[index] ?? "";
            const added = newLines[index] ?? "";
            if (removed === added) continue;
            if (removed && added) changes.push({ type: "changed", removed, added });
            else if (added) changes.push({ type: "added", added });
            else changes.push({ type: "removed", removed });
        }
        const isDesign = /\.css$/i.test(filename) || changes.every((item) => /(--[\w-]+|color|font|spacing|padding|margin|radius|shadow|media|transition|animation)/i.test(`${item.added || ""} ${item.removed || ""}`));
        return changes.slice(0, 12).map((item) => ({ ...item, kind: isDesign ? "design-only" : "content-only" }));
    }

    function showDiff(before, after, label, scope = "") {
        const fileChanges = window.workspaceCore?.diffFiles?.(before.files || {}, after.files || {}) || [];
        const baseRevision = snapshotRevision(before);
        pendingChange = null;
        setWorkflowStatus("proposing", "Proposal ready for review");
        const semantic = fileChanges.flatMap((change) => semanticChanges(before.files?.[change.name], after.files?.[change.name], change.name).map((item) => ({ ...item, filename: change.name })));
        pendingChange = { before, after, label, scope, changes: fileChanges, semantic, baseRevision, createdAt: Date.now(), category: scope === "design tokens" ? "design" : scope === "mobile layout" ? "mobile" : "content" };
        const panel = $("#workflow-diff-panel");
        if (!panel) return;
        panel.hidden = false;
        $("[data-diff-title]", panel).textContent = label;
        $("[data-diff-summary]", panel).textContent = fileChanges.length
            ? `${fileChanges.length} file${fileChanges.length === 1 ? "" : "s"} changed · ${semantic.filter((item) => item.kind === "content-only").length} content · ${semantic.filter((item) => item.kind === "design-only").length} design · scoped to ${scope || "the current draft"}`
            : "No generated files changed.";
        const list = $("[data-diff-list]", panel);
        list.replaceChildren(...(semantic.length ? semantic : fileChanges.map((change) => ({ filename: change.name, type: "changed", removed: `${change.before.bytes} bytes`, added: `${change.after.bytes} bytes`, kind: scope === "design tokens" ? "design-only" : "content-only" })).slice(0, 12)).map((change) => {
            const li = document.createElement("li");
            const prefix = change.type === "added" ? "ADDED" : change.type === "removed" ? "REMOVED" : "CHANGED";
            li.innerHTML = `<strong>${prefix} · ${escapeText(change.kind)} · ${escapeText(change.filename)}</strong>${change.removed ? `<del>${escapeText(change.removed.slice(0, 240))}</del>` : ""}${change.added ? `<ins>${escapeText(change.added.slice(0, 240))}</ins>` : ""}`;
            return li;
        }));
        panel.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }

    function pendingIsCurrent(change = pendingChange) {
        return Boolean(change && snapshotRevision(projectSnapshot()) === change.baseRevision);
    }

    function discardPending(reason = "Proposal discarded.") {
        pendingChange = null;
        setWorkflowStatus("saved", reason);
        $("#workflow-diff-panel")?.setAttribute("hidden", "");
    }

    function runImprovement(id, label, category) {
        const before = projectSnapshot();
        if (!before) return toast("Create a draft before applying improvements.", "warning");
        saveVersion(`Before: ${label}`);
        const after = { ...before, files: scopedFiles(id, category, before) };
        showDiff(before, after, label, category === "design" ? "design tokens" : category === "mobile" ? "mobile layout" : "content and conversion");
        const target = category === "design" ? "#creative-direction-title" : category === "conversion" ? "#conversion-goal-title" : category === "mobile" ? "#previewContentIframe" : "#business-details";
        scrollTo(target); toast(`${label} applied to the relevant area. Review the diff or restore the previous version.`);
        document.dispatchEvent(new CustomEvent("workspace:improvement-requested", { detail: { id, label, category, scoped: true, key: key() } }));
    }
    function runSection(section) {
        const before = projectSnapshot();
        if (!before) return toast("Create a draft before trying a section variation.", "warning");
        const current = sectionVersions.get(section) || 0; const next = current + 1; sectionVersions.set(section, next);
        saveVersion(`${section} — before variation ${next}`, section);
        const id = section.toLowerCase().replace(/\s+/g, "-");
        const after = { ...before, files: scopedFiles(id, section === "Mobile layout" ? "mobile" : "content", before) };
        showDiff(before, after, `${section} — variation ${next}`, section);
        renderSectionStatus(section, next);
        document.dispatchEvent(new CustomEvent("workspace:section-regeneration-requested", { detail: { section, variation: next, scoped: true, key: key() } }));
        toast(`${section} variation ${next} applied. Use the diff actions to keep or restore it.`);
    }
    function renderSectionStatus(section, version) {
        const item = document.querySelector(`[data-section-name="${CSS.escape(section)}"]`); if (!item) return;
        const status = $("[data-section-status]", item); if (status) status.textContent = `Variation ${version} saved`;
    }

    function buildUI() {
        const anchor = $("#workspace-readiness-panel") || $(".guided-wizard"); if (!anchor || $("#workflow-studio-panel")) return;
        const panel = document.createElement("section"); panel.id = "workflow-studio-panel"; panel.className = "workflow-studio-panel";
        panel.innerHTML = `<div id="workflow-diff-panel" class="workflow-studio-block workflow-diff-panel" hidden><div class="workflow-block-heading"><div><p class="eyebrow-label">Safe change review</p><h3 data-diff-title>Proposed change</h3><p class="field-descriptor-text" data-diff-summary></p></div><span class="field-descriptor-text">Nothing is permanent until you accept it</span></div><ul class="workflow-diff-list" data-diff-list></ul><div class="workflow-stepper-actions"><button type="button" class="matrix-action-btn variant-outline-row" data-diff-keep>Keep current</button><button type="button" class="matrix-action-btn variant-gold-fill" data-diff-accept>Accept change</button><button type="button" class="matrix-action-btn variant-outline-row" data-diff-restore>Restore previous</button></div></div><div id="workflow-decision-panel" class="workflow-studio-block workflow-decision-panel" hidden><div class="workflow-block-heading"><div><p class="eyebrow-label">Design decision</p><h3>Why this draft is structured this way</h3></div><span class="field-descriptor-text">Generated from your brief</span></div><p class="field-descriptor-text" data-decision-rationale></p><ul class="workflow-decision-list" data-decision-list></ul></div><div id="workflow-studio-stepper" class="workflow-stepper" aria-label="Website creation progress"><p class="workflow-stepper-current" data-workflow-status role="status" aria-live="polite">Ready</p><div class="workflow-stepper-track"><span data-step-progress></span></div><div class="workflow-stepper-items">${STEPS.map((item, i) => `<button type="button" data-step-index="${i}"><span>${i + 1}</span><strong>${item.label}</strong></button>`).join("")}</div><p class="workflow-stepper-current">Step: <strong data-step-label></strong></p><div class="workflow-stepper-actions"><button type="button" class="matrix-action-btn variant-outline-row" data-step-back>Back</button><button type="button" class="matrix-action-btn variant-gold-fill" data-step-next>Continue</button></div></div><div class="workflow-studio-block"><div class="workflow-block-heading"><div><p class="eyebrow-label">Quick improvements</p><h3>Improve without starting over</h3></div><button type="button" class="matrix-action-btn variant-outline-row" data-save-studio-version>Save checkpoint</button></div><div class="workflow-improvement-grid">${IMPROVEMENTS.map(([id, label, category]) => `<button type="button" class="matrix-action-btn variant-outline-row" data-improvement="${id}" data-category="${category}">${label}</button>`).join("")}</div></div><div class="workflow-studio-block"><div class="workflow-block-heading"><div><p class="eyebrow-label">Safe experiments</p><h3>Try one section at a time</h3></div><span class="field-descriptor-text">Keep current · Try another · Compare · Restore</span></div><div class="workflow-section-grid">${SECTIONS.map((name) => `<article data-section-name="${name}"><strong>${name}</strong><span data-section-status>Current draft</span><button type="button" class="matrix-action-btn variant-outline-row" data-section-action="${name}">Try another</button></article>`).join("")}</div></div><div id="workflow-publish-gate" class="workflow-publish-gate" data-state="needs-attention"><div class="workflow-block-heading"><div><p class="eyebrow-label">Publish confidence</p><h3 data-gate-title>Needs attention before publishing</h3></div><strong data-gate-score>0% ready</strong></div><ul data-gate-findings></ul></div><div class="workflow-studio-block"><div class="workflow-block-heading"><div><p class="eyebrow-label">Safe recovery</p><h3>Version history</h3></div><span class="field-descriptor-text">Restore without losing the current draft</span></div><ul id="workflow-history-list" class="workflow-history-list"></ul></div><div class="workflow-studio-block workflow-audit-panel"><div class="workflow-block-heading"><div><p class="eyebrow-label">Improvement evidence</p><h3>What was wrong—and what changed</h3><p class="field-descriptor-text">A running audit trail of flaws found in the original draft and the scoped improvements applied or rejected.</p></div><span class="field-descriptor-text">Traceable review</span></div><ul id="workflow-audit-list" class="workflow-audit-list" aria-live="polite"></ul></div>`;
        anchor.insertAdjacentElement("afterend", panel);
        panel.addEventListener("click", (event) => {
            const stepButton = event.target.closest("[data-step-index]"); if (stepButton) return applyStep(Number(stepButton.dataset.stepIndex));
            if (event.target.closest("[data-step-back]")) return applyStep(step - 1);
            if (event.target.closest("[data-step-next]")) { if (step === STEPS.length - 1) { field("primary-create-website-btn")?.click(); } else applyStep(step + 1); return; }
            const improvement = event.target.closest("[data-improvement]"); if (improvement) return runImprovement(improvement.dataset.improvement, improvement.textContent, improvement.dataset.category);
            const section = event.target.closest("[data-section-action]"); if (section) return runSection(section.dataset.sectionAction);
            if (event.target.closest("[data-save-studio-version]")) { saveVersion("Manual checkpoint"); toast("Checkpoint saved."); }
            if (event.target.closest("[data-diff-keep]")) {
                const change = pendingChange;
                if (change && pendingIsCurrent(change)) addAuditEntry(change.label, change.category, "kept", change.before, change.after, change.scope);
                discardPending("Current version kept; proposal discarded.");
                toast("Current version kept.");
            }
            if (event.target.closest("[data-diff-accept]")) {
                const change = pendingChange;
                if (!change) return;
                if (!pendingIsCurrent(change)) {
                    discardPending("This proposal was discarded because the draft changed while it was open.");
                    toast("Proposal expired because the draft changed.", "warning");
                    return;
                }
                applyProject(change.after);
                saveVersion(`Accepted: ${change.label}`, change.scope);
                addAuditEntry(change.label, change.category, "accepted", change.before, change.after, change.scope);
                discardPending("Change accepted and saved locally.");
                toast("Change accepted and saved locally.");
            }
            if (event.target.closest("[data-diff-restore]")) {
                const change = pendingChange;
                if (change && pendingIsCurrent(change)) {
                    applyProject(change.before);
                    saveVersion(`Restored: ${change.label}`, change.scope);
                    addAuditEntry(change.label, change.category, "restored", change.before, change.after, change.scope);
                    discardPending("Previous version restored.");
                    toast("Previous version restored.");
                } else if (change) {
                    discardPending("Restore cancelled because the draft changed while the proposal was open.");
                    toast("Proposal expired before it could be restored.", "warning");
                }
            }
        });
    }
    function renderAll() { renderStepper(); renderHistory(); renderReadinessGate(); }

    function getPublishDecision() {
        const workflow = readiness();
        const release = window.workspaceRelease?.releaseReview?.() || null;
        const findings = [...workflow.findings].map((item) => ({
            ...item,
            source: item.source || "workspace-workflow",
            severity: item.severity || (Number(item.impact) >= 5 ? "blocking" : "warning"),
            affected: item.affected || item.section || "workflow brief",
            section: item.section || item.category || "Workflow",
            remediation: item.remediation || item.action || "Review this finding before publishing.",
            fixType: item.fixType || "manual",
            evidenceState: item.evidenceState || "missing",
            revisionState: item.revisionState || "current"
        }));
        if (release?.results) {
            release.results.filter((item) => !item.pass).forEach((item) => findings.push({
                ...item,
                id: item.key || "release-check",
                category: item.category || "release",
                action: "Open release review",
                impact: item.priority === "high" ? 5 : 3
            }));
        }
        const blockers = findings.filter((item) => item.severity === "blocking" || Number(item.impact) >= 5);
        return { workflow, release, findings, blockers, blocked: blockers.length > 0 };
    }

    function publishGateReport() {
        return getPublishDecision();
    }

    function publishGateAllows() {
        return !publishGateReport().blocked;
    }

    function bindPublishGate() {
        const publish = field("publish-site-btn");
        if (!publish || publish.dataset.workflowGateBound) return;
        publish.dataset.workflowGateBound = "true";
        publish.addEventListener("click", (event) => {
            if (publishGateAllows()) return;
            event.preventDefault();
            event.stopImmediatePropagation();
            renderReadinessGate();
            toast("Publishing is blocked until the critical readiness findings are resolved.", "warning");
            scrollTo("#workflow-publish-gate");
        }, true);
    }
    function bind() {
        buildUI(); history = readHistory(); auditEntries = readAuditEntries(); bindPublishGate();
        document.addEventListener("workspace:smart-defaults-applied", (event) => window.workspaceWorkflow?.renderDecision?.(event.detail?.decision || window.workspaceWorkflow?.inferDecision?.()), { passive: true });
        try { step = Math.max(0, Math.min(STEPS.length - 1, Number(localStorage.getItem("workflow-studio-step")) || 0)); } catch {}
        renderAll();
        renderAuditTrail();
        document.addEventListener("input", () => { const next = key(); if (next === lastFormKey) return; lastFormKey = next; renderReadinessGate(); }, { passive: true });
        document.addEventListener("change", renderAll, { passive: true });
        document.addEventListener("workspace:incremental-update", renderReadinessGate);
        window.addEventListener("workspace:generation-complete", () => { saveVersion("Initial generation"); renderAll(); });
        document.addEventListener("workspace:version-saved", renderHistory);
        window.addEventListener("beforeunload", () => { try { localStorage.setItem("workflow-studio-step", String(step)); } catch {} });
    }
    window.workflowStudio.getPublishDecision = getPublishDecision;
    window.workflowStudio.getPendingChange = () => pendingChange ? { label: pendingChange.label, scope: pendingChange.scope, changes: pendingChange.changes, semantic: pendingChange.semantic } : null;
    window.workflowStudio.acceptPendingChange = () => {
        if (!pendingChange) return false;
        applyProject(pendingChange.after);
        saveVersion(`Accepted: ${pendingChange.label}`, pendingChange.scope);
        pendingChange = null;
        $("#workflow-diff-panel")?.setAttribute("hidden", "");
        return true;
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
})();
