"use strict";

// Browser-side orchestration for the optional server AI. Credentials never
// enter the browser; validated files still pass through the normal workspace
// safety, formatter, compiler, and audit boundaries.
(() => {
    let activeController = null;

    async function authorizationHeader() {
        const session = await window.supabaseWorkspace?.getSession?.();
        const token = session?.access_token || session?.data?.session?.access_token || "";
        return token ? { Authorization: `Bearer ${token}` } : {};
    }

    function validateAndFormat(files) {
        if (!files || typeof files !== "object" || Array.isArray(files)) throw new Error("AI generation returned no project files.");
        window.workspaceProjectContract?.validateFiles?.(files);
        const safety = window.workspaceContentSafety?.validateFiles?.(files) || [];
        if (safety.length) throw new Error(`AI generation failed content safety: ${safety[0].message}`);
        const validation = window.workspaceGenerator?.validateProject?.(files);
        if (validation && !validation.valid) {
            const error = new Error(validation.issues?.[0]?.message || validation.issues?.[0] || "AI generation failed project validation.");
            error.files = files;
            error.diagnostics = (validation.issues || []).slice(0, 50);
            throw error;
        }
        return window.workspaceFormatter?.formatProjectFiles ? window.workspaceFormatter.formatProjectFiles(files) : files;
    }

    async function request(payload = {}, options = {}) {
        if (activeController) activeController.abort();
        activeController = new AbortController();
        const timeout = window.setTimeout(() => activeController?.abort(), Math.max(10_000, Number(options.timeoutMs) || 90_000));
        try {
            const headers = { "Content-Type": "application/json", Accept: "application/json", ...(await authorizationHeader()) };
            const response = await fetch("/api/website-architect", { method: "POST", credentials: "same-origin", headers, body: JSON.stringify(payload), signal: activeController.signal });
            const result = await response.json().catch(() => ({}));
            if (!response.ok || !result.success) {
                const error = new Error(result.error || "AI website generation failed.");
                error.status = response.status;
                error.fallback = result.fallback;
                error.diagnostics = result.diagnostics || [];
                throw error;
            }
            window.workspaceRepairAudit = Array.isArray(result.repairAudit) ? result.repairAudit : [];
            window.workspaceClaimProvenance = Array.isArray(result.provenance) ? result.provenance : [];
            if (typeof window.dispatchEvent === "function" && typeof CustomEvent === "function") {
                window.dispatchEvent(new CustomEvent("workspace:generation-evidence", { detail: { repairAudit: window.workspaceRepairAudit, provenance: window.workspaceClaimProvenance } }));
            }
            return { ...result, files: validateAndFormat(result.files) };
        } finally {
            window.clearTimeout(timeout);
            activeController = null;
        }
    }

    async function generate(data = {}, options = {}) {
        const prepared = window.workspaceDesignSystems?.prepareBrief?.(data) || data;
        const contractRequest = window.workspaceGenerator?.createModelRequest?.(prepared) || prepared;
        try {
            return await request({ ...contractRequest, mode: "generate" }, options);
        } catch (error) {
            if (options.fallback === false || error.name === "AbortError") throw error;
            const files = window.workspaceGenerator?.createProject?.(prepared);
            return { success: true, files, provider: "deterministic", fallbackReason: error.message, repairPasses: 0, diagnostics: [] };
        }
    }

    async function repair() {
        throw new Error("Model-authored source repair is disabled. Use deterministic repairs or request a revised structured plan.");
    }

    async function critique(files, visualEvidence = {}, data = {}, options = {}) {
        return request({ ...data, mode: "critique", existingFiles: files, visualEvidence }, options);
    }

    function cancel() {
        activeController?.abort();
        activeController = null;
    }

    window.workspaceAI = Object.freeze({ generate, repair, critique, cancel, isPending: () => Boolean(activeController) });
})();
