"use strict";

// Shared, dependency-free project audit used by browser diagnostics and server preflight.
(() => {
    const EXTERNAL = /^(?:[a-z][a-z\d+.-]*:|\/\/)/i;
    const FILE_REFERENCE = /\.(?:html?|css|js|json|xml|txt|webp|png|jpe?g|gif|svg|avif|ico|woff2?|ttf|otf)(?:[?#].*)?$/i;

    function normalizePath(value) {
        const path = String(value || "").replace(/\\/g, "/");
        return path.replace(/^\/+/, "");
    }

    function resolveLocalReference(sourceFile, value) {
        const target = String(value || "").trim().split(/[?#]/)[0];
        if (!target || target === "/" || target.startsWith("#") || EXTERNAL.test(target)) return "";
        try {
            return decodeURIComponent(new URL(target, `https://workspace.invalid/${normalizePath(sourceFile)}`).pathname).replace(/^\/+/, "");
        } catch {
            return normalizePath(target).replace(/^\.\//, "");
        }
    }

    function referencesIn(sourceFile, content) {
        const source = String(content || "");
        const references = [];
        const add = (value, kind = "reference") => {
            const raw = String(value || "").trim();
            const target = resolveLocalReference(sourceFile, raw);
            if (target && FILE_REFERENCE.test(target)) references.push({ source: sourceFile, target, raw, kind });
        };
        if (/\.html?$/i.test(sourceFile)) {
            for (const match of source.matchAll(/\b(?:href|src)=(["'])(.*?)\1/gi)) add(match[2], "html");
            for (const match of source.matchAll(/\bsrcset=(["'])(.*?)\1/gi)) match[2].split(",").forEach((item) => add(item.trim().split(/\s+/)[0], "srcset"));
        }
        if (/\.css$/i.test(sourceFile)) {
            for (const match of source.matchAll(/url\(\s*(["']?)(.*?)\1\s*\)/gi)) add(match[2], "css");
        }
        return references;
    }

    function auditProject(files = {}) {
        const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
        const known = new Set(Object.keys(sourceFiles).map(normalizePath));
        const issues = [];
        const lineLocation = (file, target = "") => {
            const source = String(sourceFiles[file] || "");
            const index = target ? source.indexOf(target) : -1;
            const before = index < 0 ? "" : source.slice(0, index);
            return { line: (before.match(/\n/g) || []).length + 1, column: index < 0 ? 1 : index - before.lastIndexOf("\n") };
        };
        const addIssue = (entry) => {
            const enriched = {
                severity: entry.severity || "warning",
                category: entry.category || "quality",
                location: entry.location || lineLocation(entry.file, entry.target),
                fix: entry.fix || (entry.file ? { type: "open-file", file: entry.file } : { type: "review" }),
                ...entry
            };
            const key = `${enriched.code}:${enriched.file || ""}:${enriched.target || ""}`;
            if (!issues.some((item) => `${item.code}:${item.file || ""}:${item.target || ""}` === key)) issues.push(enriched);
        };
        const references = Object.entries(sourceFiles).flatMap(([name, content]) => referencesIn(name, content));
        const seen = new Set();
        references.forEach((reference) => {
            const key = `${reference.source}\u0000${reference.target}`;
            if (seen.has(key)) return;
            seen.add(key);
            if (!known.has(reference.target)) addIssue({ code: "MISSING_LOCAL_REFERENCE", severity: "blocking", category: "links", file: reference.source, target: reference.target, message: `${reference.source} references missing ${reference.target}.` });
        });
        Object.entries(sourceFiles).filter(([name]) => /\.html?$/i.test(name)).forEach(([name, html]) => {
            const source = String(html || "");
            if (!/^\s*<!doctype\s+html>/i.test(source)) addIssue({ code: "MISSING_DOCTYPE", severity: "warning", category: "structure", file: name, message: `${name} is missing a standards doctype.` });
            if (!/<html\b[^>]*\blang=["'][^"']+["']/i.test(source)) addIssue({ code: "MISSING_LANGUAGE", severity: "warning", category: "accessibility", file: name, message: `${name} should declare the document language.` });
            if (!/<title\b[^>]*>\s*[^<]+/i.test(source)) addIssue({ code: "MISSING_TITLE", severity: "blocking", category: "seo", file: name, message: `${name} needs a descriptive title.` });
            if (!/<meta\b[^>]+name=["']description["'][^>]+content=["'][^"']+[^>]*>/i.test(source)) addIssue({ code: "MISSING_DESCRIPTION", severity: "warning", category: "seo", file: name, message: `${name} should include a non-empty meta description.` });
            if ((source.match(/<h1[\s>]/gi) || []).length !== 1) addIssue({ code: "INVALID_H1_COUNT", severity: "blocking", category: "accessibility", file: name, message: `${name} should contain exactly one primary heading.` });
            if (/<img\b(?![^>]*\balt\s*=)[^>]*>/i.test(source)) addIssue({ code: "IMAGE_MISSING_ALT", severity: "blocking", category: "accessibility", file: name, message: `${name} contains an image without alt text.` });
            if (/<img\b[^>]*\balt=["']\s*["'][^>]*>/i.test(source) && !/<img\b[^>]*\bclass=["'][^"']*hero-image[^"']*["'][^>]*\balt=["']\s*["']/i.test(source)) addIssue({ code: "IMAGE_EMPTY_ALT", severity: "warning", category: "accessibility", file: name, message: `${name} contains an empty alt attribute; confirm the image is decorative.` });
            const ids = [...source.matchAll(/\bid=["']([^"']+)["']/gi)].map((match) => match[1]);
            const duplicateIds = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
            if (duplicateIds.length) addIssue({ code: "DUPLICATE_ID", severity: "blocking", category: "accessibility", file: name, target: duplicateIds[0], message: `${name} repeats the id${duplicateIds.length > 1 ? "s" : ""} ${duplicateIds.join(", ")}.` });
            const controls = [...source.matchAll(/<(input|textarea|select)\b([^>]*)>/gi)]
                .map((match) => match[2])
                .filter((attrs) => !/\btype=["']hidden["']/i.test(attrs) && !/\baria-hidden=["']true["']/i.test(attrs));
            const labels = new Set([...source.matchAll(/<label\b[^>]*for=["']([^"']+)["']/gi)].map((match) => match[1]));
            const nestedLabelIds = new Set([...source.matchAll(/<label\b[^>]*>[\s\S]*?\bid=["']([^"']+)["'][\s\S]*?<\/label>/gi)].map((match) => match[1]));
            if (controls.some((attrs) => {
                const id = attrs.match(/\bid=["']([^"']+)["']/i)?.[1];
                return !id || (!labels.has(id) && !nestedLabelIds.has(id) && !/\baria-label(?:ledby)?=["']/i.test(attrs));
            })) addIssue({ code: "FORM_CONTROL_UNNAMED", severity: "blocking", category: "accessibility", file: name, message: `${name} contains a form control without a reliable accessible name.` });
            if (/<script\b[^>]+type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/i.test(source)) {
                const json = source.match(/<script\b[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/i)?.[1]?.trim();
                try { JSON.parse(json || ""); } catch { addIssue({ code: "INVALID_STRUCTURED_DATA", severity: "blocking", category: "seo", file: name, message: `${name} contains invalid JSON-LD structured data.` }); }
            }
            if (!/<link\b[^>]+rel=["'][^"']*canonical/i.test(source)) addIssue({ code: "MISSING_CANONICAL", severity: "warning", category: "seo", file: name, message: `${name} should include a canonical URL.` });
            if (name === "index.html" && !/<link\b[^>]+rel=["'][^"']*manifest/i.test(source)) addIssue({ code: "MISSING_MANIFEST_LINK", severity: "warning", category: "seo", file: name, message: `${name} should link a web manifest.` });
            if (name === "index.html" && !/<meta\b[^>]+name=["']theme-color["']/i.test(source)) addIssue({ code: "MISSING_THEME_COLOR", severity: "warning", category: "seo", file: name, message: `${name} should declare a browser theme color.` });
            if (name === "index.html" && !/<meta\b[^>]+property=["']og:description["']/i.test(source)) addIssue({ code: "MISSING_OG_DESCRIPTION", severity: "warning", category: "seo", file: name, message: `${name} should include an Open Graph description.` });
            for (const match of source.matchAll(/<a\b([^>]*\btarget=["']_blank["'][^>]*)>/gi)) {
                if (!/\brel=["'][^"']*\b(?:noopener|noreferrer)\b/i.test(match[1])) addIssue({ code: "EXTERNAL_LINK_UNSAFE", severity: "warning", category: "security", file: name, message: `${name} has a new-tab link without noopener or noreferrer.` });
            }
        });
        return { issues, references, blocking: issues.filter((item) => item.severity === "blocking"), warnings: issues.filter((item) => item.severity === "warning"), passed: issues.every((item) => item.severity !== "blocking") };
    }

    function contrastRatio(foreground, background) {
        const parse = (value) => {
            const match = String(value || "").match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i) || String(value || "").match(/^#([0-9a-f]{6})$/i);
            if (!match) return null;
            if (match.length === 4) return [Number(match[1]), Number(match[2]), Number(match[3])];
            const hex = match[1];
            return [parseInt(hex.slice(0, 2), 16), parseInt(hex.slice(2, 4), 16), parseInt(hex.slice(4, 6), 16)];
        };
        const luminance = (rgb) => rgb.map((channel) => channel / 255).map((channel) => channel <= .03928 ? channel / 12.92 : ((channel + .055) / 1.055) ** 2.4).reduce((sum, channel, index) => sum + channel * [0.2126, 0.7152, 0.0722][index], 0);
        const fg = parse(foreground); const bg = parse(background);
        if (!fg || !bg) return null;
        const light = Math.max(luminance(fg), luminance(bg));
        const dark = Math.min(luminance(fg), luminance(bg));
        return (light + .05) / (dark + .05);
    }

    function auditRenderedDocument(documentNode) {
        if (!documentNode) return { issues: [], images: [], contrast: [] };
        const issues = [];
        const images = [...documentNode.images].map((image) => ({
            src: image.currentSrc || image.getAttribute("src") || "",
            alt: image.getAttribute("alt") || "",
            complete: image.complete,
            naturalWidth: image.naturalWidth || 0,
            naturalHeight: image.naturalHeight || 0,
            lowResolution: image.complete && image.naturalWidth > 0 && image.naturalWidth < 640
        }));
        images.forEach((image) => {
            if (!image.complete || !image.naturalWidth) issues.push({ code: "IMAGE_FAILED", severity: "warning", message: `Image failed to load: ${image.src || "unnamed image"}.` });
            else if (image.lowResolution) issues.push({ code: "IMAGE_LOW_RESOLUTION", severity: "warning", message: `Image is only ${image.naturalWidth}px wide; consider a larger source.` });
        });
        [...documentNode.querySelectorAll("h1,h2,h3,p,a,button,label")].forEach((element) => {
            const style = documentNode.defaultView?.getComputedStyle(element);
            if (!style || !element.textContent.trim()) return;
            const ratio = contrastRatio(style.color, style.backgroundColor);
            if (ratio !== null && ratio < 4.5) issues.push({ code: "LOW_CONTRAST", severity: "warning", message: `Text contrast is approximately ${ratio.toFixed(1)}:1 in <${element.tagName.toLowerCase()}>.` });
        });
        return { issues, images, contrast: issues.filter((item) => item.code === "LOW_CONTRAST") };
    }

    const api = Object.freeze({ normalizePath, resolveLocalReference, referencesIn, auditProject, contrastRatio, auditRenderedDocument });
    if (typeof window !== "undefined") window.workspaceAudit = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
