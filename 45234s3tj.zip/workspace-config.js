"use strict";

// Shared editor configuration. Feature modules can consume this without
// duplicating file mappings or placeholder content.
(() => {
    const FILE_IDS = Object.freeze({
        "index.html": "outputContainerHtml",
        "style.css": "outputContainerStyle",
        "script.js": "outputContainerScript",
        "netlify.toml": "outputContainerToml",
        "submit-form.js": "outputContainerFunction"
    });

    const DEFAULT_FILES = Object.freeze({
        "index.html": "<!-- Awaiting Data Submission -->",
        "style.css": "/* Awaiting Data Submission */",
        "script.js": "// Awaiting Data Submission",
        "netlify.toml": "# Awaiting Data Submission",
        "submit-form.js": "// Awaiting Data Submission"
    });

    window.workspaceConfig = Object.freeze({ FILE_IDS, DEFAULT_FILES });
})();
