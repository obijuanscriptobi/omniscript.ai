// @ts-check
"use strict";

// Boundary checks for generated and imported project files. This module never
// executes project content; it only validates strings and, for imports, removes
// unsafe markup before it can enter the editor state.
(() => {
    const SAFE_PROTOCOLS = /^(?:https?:|mailto:|tel:|\/|#)/i;
    const UNSAFE_PROTOCOLS = /^(?:javascript:|vbscript:|data:text\/html|data:application\/javascript)/i;
    const RESERVED = new Set(["", ".", ".."]);

    /**
     * A project path must be relative, contain no traversal segments, and stay
     * out of sensitive locations. Anything else is rejected rather than repaired.
     *
     * @param {unknown} name
     * @returns {boolean}
     */
    function validPath(name) {
        const value = String(name || "").trim();
        if (!value || value.length > 240 || value.startsWith("/") || value.includes("\\") || value.split("/").some((part) => RESERVED.has(part))) return false;
        return /^[a-z0-9][a-z0-9._/-]*$/i.test(value) && !/^\.env(?:\.|$)|(?:^|\/)node_modules(?:\/|$)/i.test(value);
    }

    /**
     * Detects executable content that must never reach the preview or an export:
     * script-like URL protocols, inline event handlers, remote script sources,
     * and plugin embeds.
     *
     * @param {string} source
     * @returns {boolean}
     */
    function unsafeSource(source) {
        return /(?:^|[\s"'(=])(?:javascript:|vbscript:|data:text\/html|data:application\/javascript)/i.test(source)
            || /\bon(?:abort|afterprint|beforeunload|error|load|message|offline|online|pageshow|popstate|resize|submit|unload|click)\s*=/i.test(source)
            || /<script\b[^>]*src=["'](?:https?:|\/\/)/i.test(source)
            || /<(?:object|embed)\b/i.test(source);
    }

    /**
     * Validates a whole project without executing any of it. Findings are
     * de-duplicated per code and file so one bad file cannot flood the report.
     *
     * @param {Record<string, unknown>} [files]
     * @param {{ imported?: boolean }} [options] Set `imported` to apply the
     *   stricter rules that untrusted third-party markup requires.
     * @returns {WorkspaceIssue[]}
     */
    function validateFiles(files = {}, options = {}) {
        /** @type {WorkspaceIssue[]} */
        const issues = [];
        const entries = files && typeof files === "object" && !Array.isArray(files) ? Object.entries(files) : [];
        entries.forEach(([name, content]) => {
            if (!validPath(name)) issues.push({ code: "UNSAFE_FILE_PATH", file: name, message: `${name || "Unnamed file"} is not a safe project path.` });
            const source = String(content ?? "");
            if (source.length > 2_000_000) issues.push({ code: "FILE_TOO_LARGE", file: name, message: `${name} exceeds the per-file safety limit.` });
            if (unsafeSource(source)) issues.push({ code: "UNSAFE_CONTENT", file: name, message: `${name} contains an unsafe protocol, event handler, external executable script, or embedded object.` });
            if (options.imported && /<(?:iframe|frame)\b/i.test(source)) issues.push({ code: "UNTRUSTED_EMBED", file: name, message: `${name} contains an embedded frame that requires manual review.` });
        });
        return [...new Map(issues.map((item) => /** @type {[string, WorkspaceIssue]} */ ([`${item.code}:${item.file}`, item]))).values()];
    }

    /**
     * Parses imported HTML with DOMParser, which builds an inert document: no
     * script runs and no resource is fetched during parsing. Executable nodes
     * and attributes are removed before the markup is serialized back out.
     *
     * @param {unknown} html
     * @returns {string}
     */
    function cleanImportedHtml(html) {
        if (typeof DOMParser !== "function") return String(html || "");
        const document = new DOMParser().parseFromString(String(html || ""), "text/html");
        document.querySelectorAll("script:not([type='application/ld+json']), object, embed, frame, iframe").forEach((node) => node.remove());
        document.querySelectorAll("*").forEach((node) => {
            [...node.attributes].forEach((attribute) => {
                const name = attribute.name.toLowerCase();
                const value = attribute.value.trim();
                if (name.startsWith("on") || (name === "style" && /expression\s*\(|url\s*\(\s*["']?javascript:/i.test(value))) node.removeAttribute(attribute.name);
                if (["href", "src", "action", "formaction"].includes(name) && UNSAFE_PROTOCOLS.test(value)) node.removeAttribute(attribute.name);
                if (name === "target" && value === "_blank") node.setAttribute("rel", `${node.getAttribute("rel") || ""} noopener noreferrer`.trim());
            });
        });
        return `<!doctype html>\n${document.documentElement.outerHTML}`;
    }

    /**
     * @param {Record<string, unknown>} [files]
     * @returns {WorkspaceFiles}
     */
    function sanitizeImportedFiles(files = {}) {
        return Object.fromEntries(Object.entries(files || {}).map(([name, content]) => [
            name,
            /\.html?$/i.test(name) ? cleanImportedHtml(content) : String(content ?? "")
        ]));
    }

    window.workspaceContentSafety = Object.freeze({ validPath, validateFiles, sanitizeImportedFiles });
})();
