"use strict";

// Shared work target for the website maker and campaign tools. Operating mode
// answers "mine or a client"; this module identifies the exact isolated record.
(() => {
    const REGISTRY_KEY = "morrow-work-contexts-v1";
    const ACTIVE_KEY = "morrow-active-work-context-v1";
    const WEBSITE_KEY = "luxury-engine-workspace";
    const OWN_ID = "own-business";
    const clean = (value, max = 180) => String(value ?? "").replace(/[<>\u0000-\u001f]/g, "").trim().slice(0, max);
    const esc = (value) => clean(value, 240).replace(/[&\"']/g, (character) => ({ "&": "&amp;", "\"": "&quot;", "'": "&#39;" }[character]));
    const slug = (value) => clean(value).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
    const clone = (value) => JSON.parse(JSON.stringify(value));
    const mode = () => window.operatingMode?.isClient?.() ? "client" : "own";
    let cloudSyncPromise = null;
    let cloudOwnContext = null;

    function cloudHeaders() {
        const token = window.supabaseWorkspace?.getAccessToken?.();
        return token ? { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${token}` } : null;
    }
    function fromCloud(item) {
        return {
            id: item.external_key,
            cloudId: item.id,
            mode: item.kind === "own" ? "own" : "client",
            name: item.name,
            projectName: item.project_name || "",
            approvalContact: item.approval_contact || "",
            permissionsConfirmed: item.permissions_confirmed === true,
            assetRightsConfirmed: item.asset_rights_confirmed === true,
            status: item.status || "active",
            createdAt: item.created_at,
            updatedAt: item.updated_at
        };
    }
    async function cloudRequest(method = "GET", id = "", value) {
        const headers = cloudHeaders();
        if (!headers) return null;
        const response = await fetch(`/api/work-contexts${id ? `?id=${encodeURIComponent(id)}` : ""}`, {
            method, headers, credentials: "same-origin", ...(value ? { body: JSON.stringify(value) } : {})
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || "Cloud workspace synchronization failed.");
        return data;
    }
    async function syncContext(item) {
        if (!item || item.mode !== "client" || !cloudHeaders()) return item;
        const payload = { externalKey: item.id, kind: "client", name: item.name, projectName: item.projectName, approvalContact: item.approvalContact, permissionsConfirmed: item.permissionsConfirmed, assetRightsConfirmed: item.assetRightsConfirmed, status: item.status || "active" };
        const result = await cloudRequest(item.cloudId ? "PATCH" : "POST", item.cloudId || "", payload);
        const synced = result?.context ? fromCloud(result.context) : item;
        const next = contexts().filter((entry) => entry.id !== synced.id);
        next.push(synced);
        localStorage.setItem(REGISTRY_KEY, JSON.stringify(next));
        return clone(synced);
    }
    async function syncCloud() {
        if (cloudSyncPromise) return cloudSyncPromise;
        cloudSyncPromise = (async () => {
            const initial = await cloudRequest();
            if (!initial) return contexts();
            const ownRecord = (initial.contexts || []).find((item) => item.kind === "own");
            if (ownRecord) cloudOwnContext = fromCloud(ownRecord);
            const cloudClients = (initial.contexts || []).filter((item) => item.kind === "client").map(fromCloud);
            const cloudKeys = new Set(cloudClients.map((item) => item.id));
            for (const local of contexts().filter((item) => !cloudKeys.has(item.id))) await syncContext(local);
            const refreshed = await cloudRequest();
            const clients = (refreshed?.contexts || []).filter((item) => item.kind === "client").map(fromCloud);
            localStorage.setItem(REGISTRY_KEY, JSON.stringify(clients));
            window.dispatchEvent(new CustomEvent("morrow:work-contexts-synced", { detail: { contexts: clone(clients) } }));
            return clients;
        })().finally(() => { cloudSyncPromise = null; });
        return cloudSyncPromise;
    }

    function readJson(key, fallback) {
        try { const value = JSON.parse(localStorage.getItem(key) || "null"); return value ?? fallback; } catch (_) { return fallback; }
    }
    function contexts() {
        const saved = readJson(REGISTRY_KEY, []);
        return Array.isArray(saved) ? saved.filter((item) => item?.id && item.mode === "client") : [];
    }
    function activeId(targetMode = mode()) {
        if (targetMode === "own") return OWN_ID;
        const active = readJson(ACTIVE_KEY, {});
        const available = contexts();
        return available.some((item) => item.id === active.client) ? active.client : (available[0]?.id || "");
    }
    function current() {
        if (mode() === "own") return cloudOwnContext || { id: OWN_ID, mode: "own", name: "My business", projectName: "Business website", permissionsConfirmed: true, assetRightsConfirmed: true };
        return contexts().find((item) => item.id === activeId("client")) || null;
    }
    const namespace = (target = current()) => `${target?.mode || mode()}:${target?.id || "unselected"}`;
    function storageKey(base, target = current()) {
        const key = `${base}::${namespace(target)}`;
        // Preserve pre-context owner data without ever copying it into a client.
        // The legacy record remains untouched so migration is non-destructive.
        if (target?.mode === "own") {
            try {
                if (localStorage.getItem(key) === null) {
                    const legacy = localStorage.getItem(base);
                    if (legacy !== null) localStorage.setItem(key, legacy);
                }
            } catch (_) {}
        }
        return key;
    }
    function readScoped(base, fallback = null, target = current()) {
        try {
            const value = JSON.parse(localStorage.getItem(storageKey(base, target)) || "null");
            return value ?? fallback;
        } catch (_) { return fallback; }
    }
    function writeScoped(base, value, target = current()) {
        if (!target || target.mode === "client" && !target.id) throw new Error("Choose a client workspace before saving client data.");
        localStorage.setItem(storageKey(base, target), JSON.stringify(value));
        return value;
    }
    function clientGate(requirement = "context", target = current()) {
        if (mode() !== "client") return { allowed: true, target };
        if (!target) return { allowed: false, code: "CLIENT_REQUIRED", message: "Choose or create a client workspace first." };
        if (requirement === "content" && !target.permissionsConfirmed) return { allowed: false, code: "CONTENT_PERMISSION_REQUIRED", message: "Confirm permission to use this client’s content first." };
        if (requirement === "assets" && !target.assetRightsConfirmed) return { allowed: false, code: "ASSET_RIGHTS_REQUIRED", message: "Confirm ownership or licences for this client’s assets first." };
        if (requirement === "approval" && !target.approvalContact) return { allowed: false, code: "APPROVAL_CONTACT_REQUIRED", message: "Add the client approval contact first." };
        return { allowed: true, target };
    }
    function assertClientReady(requirement = "context", target = current()) {
        const result = clientGate(requirement, target);
        if (!result.allowed) {
            const error = new Error(result.message);
            error.code = result.code;
            throw error;
        }
        return target;
    }

    function hasUnsavedWork() {
        const state = window.workspaceAPI?.getState?.();
        return Boolean(state?.dirty || window.adStudio?.isDirty?.());
    }
    function confirmSwitch(message = "Switch workspaces? Unsaved changes may be lost.") {
        return !hasUnsavedWork() || typeof window.confirm !== "function" || window.confirm(message);
    }
    function saveWebsiteSnapshot(target = current()) {
        if (!target) return;
        try {
            const liveState = window.workspaceAPI?.getState?.();
            const serialized = liveState ? JSON.stringify(liveState) : localStorage.getItem(WEBSITE_KEY);
            if (serialized) localStorage.setItem(storageKey(WEBSITE_KEY, target), serialized);
        } catch (_) {}
    }
    function restoreWebsiteSnapshot(target) {
        try {
            const scoped = localStorage.getItem(storageKey(WEBSITE_KEY, target));
            if (scoped) localStorage.setItem(WEBSITE_KEY, scoped);
            else localStorage.removeItem(WEBSITE_KEY);
        } catch (_) {}
    }
    function prepareModeSwitch(nextMode) {
        if (!confirmSwitch("Switch between My business and Client work? Unsaved edits in the current workspace may be lost.")) return false;
        saveWebsiteSnapshot();
        const next = nextMode === "client" ? contexts().find((item) => item.id === activeId("client")) : { id: OWN_ID, mode: "own" };
        restoreWebsiteSnapshot(next || { id: "unselected", mode: "client" });
        return true;
    }
    function select(id) {
        const next = contexts().find((item) => item.id === id);
        if (!next || next.id === current()?.id) return Boolean(next);
        if (!confirmSwitch("Switch client projects? Unsaved edits in the current project may be lost.")) return false;
        saveWebsiteSnapshot();
        try { localStorage.setItem(ACTIVE_KEY, JSON.stringify({ ...readJson(ACTIVE_KEY, {}), client: next.id })); } catch (_) {}
        restoreWebsiteSnapshot(next);
        window.dispatchEvent(new CustomEvent("morrow:work-context", { detail: clone(next) }));
        window.location.reload();
        return true;
    }
    function upsert(input = {}) {
        const name = clean(input.name);
        if (!name) throw new Error("Client name is required.");
        const existing = input.id ? contexts().find((item) => item.id === input.id) : null;
        const item = {
            id: existing?.id || `client-${slug(name) || "project"}-${Date.now().toString(36)}`,
            mode: "client",
            name,
            projectName: clean(input.projectName) || `${name} website`,
            approvalContact: clean(input.approvalContact, 240),
            permissionsConfirmed: input.permissionsConfirmed === true,
            assetRightsConfirmed: input.assetRightsConfirmed === true,
            createdAt: existing?.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        const next = contexts().filter((entry) => entry.id !== item.id);
        next.push(item);
        try {
            localStorage.setItem(REGISTRY_KEY, JSON.stringify(next));
            localStorage.setItem(ACTIVE_KEY, JSON.stringify({ ...readJson(ACTIVE_KEY, {}), client: item.id }));
        } catch (_) {}
        syncContext(item).catch((error) => window.dispatchEvent(new CustomEvent("morrow:work-context-error", { detail: { message: error.message } })));
        return clone(item);
    }
    function remove(id) {
        const existing = contexts().find((item) => item.id === id);
        const next = contexts().filter((item) => item.id !== id);
        try {
            localStorage.setItem(REGISTRY_KEY, JSON.stringify(next));
            const active = readJson(ACTIVE_KEY, {});
            if (active.client === id) localStorage.setItem(ACTIVE_KEY, JSON.stringify({ ...active, client: next[0]?.id || "" }));
        } catch (_) {}
        if (existing?.cloudId) cloudRequest("DELETE", existing.cloudId).catch((error) => window.dispatchEvent(new CustomEvent("morrow:work-context-error", { detail: { message: error.message } })));
    }

    function applyExperience() {
        const target = current();
        document.documentElement.dataset.workContext = target?.id || "unselected";
        document.body?.setAttribute("data-work-context", target?.id || "unselected");
        const state = window.workspaceAPI?.getState?.();
        if (state) { state.operatingMode = mode(); state.workspaceContext = target ? clone(target) : null; }
        const commandTitle = document.getElementById("business-command-title");
        if (commandTitle) commandTitle.textContent = mode() === "client" ? "Client delivery command center" : "My business growth command center";
        const intro = document.querySelector("#brief-stage .stage-intro");
        if (intro && mode() === "client") intro.textContent = target ? `Create a campaign for ${target.name}. Keep their brief, assets, approvals, and exports isolated from every other client.` : "Create a client first so its brief, assets, approvals, and exports stay isolated.";
        const makerName = document.getElementById("project-name-input");
        if (makerName && target?.projectName && !makerName.value) makerName.value = target.projectName;
        const clientMissing = mode() === "client" && !target;
        ["generate-btn", "generate-site-btn", "ad-studio-generate-btn", "new-lead-btn"].forEach((id) => {
            const button = document.getElementById(id);
            if (!button) return;
            button.disabled = clientMissing;
            if (clientMissing) button.title = "Create or choose a client project first.";
            else if (button.title === "Create or choose a client project first.") button.removeAttribute("title");
        });

        const auditButton = document.querySelector('#audit-form button[type="submit"]');
        if (auditButton) {
            auditButton.disabled = clientMissing;
            auditButton.textContent = mode() === "client" ? "Run client audit" : "Run my free audit";
            if (clientMissing) auditButton.title = "Create or choose a client project first.";
            else auditButton.removeAttribute("title");
        }
        const auditEmailLabel = document.querySelector('label[for="audit-email"]');
        if (auditEmailLabel) auditEmailLabel.textContent = mode() === "client" ? "Client or report email address" : "Report email address";
        const todoTitle = document.getElementById("todo-add-title");
        if (todoTitle) todoTitle.textContent = mode() === "client" ? "Add a client action" : "Add an action";
        const todoInput = document.getElementById("todo-input");
        if (todoInput) {
            todoInput.disabled = clientMissing;
            todoInput.placeholder = mode() === "client" ? "e.g. Send the homepage revision for approval" : "e.g. Finish my business profile";
        }
        const todoSubmit = document.querySelector('#todo-form button[type="submit"]');
        if (todoSubmit) {
            todoSubmit.disabled = clientMissing;
            if (clientMissing) todoSubmit.title = "Create or choose a client project first.";
            else todoSubmit.removeAttribute("title");
        }
        const leadsListTitle = document.querySelector(".appointments-list h2");
        if (leadsListTitle) leadsListTitle.textContent = mode() === "client" ? "Appointments for this client" : "All appointments";

        const leadsCloudStatus = document.getElementById("leads-cloud-status");
        if (leadsCloudStatus && clientMissing) {
            leadsCloudStatus.textContent = "No client selected. Create or choose a client before adding appointments, leads, or proposals.";
            leadsCloudStatus.dataset.state = "warning";
        }
        const adBusinessLabel = document.querySelector('label[for="ad-studio-name"]');
        if (adBusinessLabel) adBusinessLabel.textContent = mode() === "client" ? "Client business or product" : "My business or product";
        const auditResultsHeading = document.querySelector(".audit-results-heading h2");
        if (auditResultsHeading) auditResultsHeading.textContent = mode() === "client" ? "Client mobile audit snapshot" : "My mobile audit snapshot";
        const auditGenerate = document.getElementById("generate-improved-site-btn");
        if (auditGenerate) auditGenerate.textContent = mode() === "client" ? "Create client revision" : "Improve my website";
        const todoSync = document.getElementById("todo-sync-status");
        if (todoSync && clientMissing) {
            todoSync.textContent = "No client selected · no client data is open";
            todoSync.dataset.state = "warning";
        }
        document.querySelectorAll("[data-work-context-name]").forEach((node) => {
            node.textContent = target?.name || (mode() === "client" ? "No client selected" : "My business");
        });
    }

    function mount() {
        if (document.getElementById("work-context-switcher")) return applyExperience();
        const anchor = document.getElementById("operating-mode-switcher") || document.querySelector("body > header");
        if (!anchor) return applyExperience();
        const section = document.createElement("section");
        section.id = "work-context-switcher";
        section.className = "work-context-switcher";
        section.setAttribute("aria-label", "Active business or client project");
        anchor.insertAdjacentElement("afterend", section);

        const render = () => {
            const clientMode = mode() === "client";
            const items = contexts();
            const active = current();
            const account = window.supabaseWorkspace?.getState?.() || {};
            const connection = navigator.onLine === false ? "Offline · local changes remain available" : account.authenticated ? "Cloud connected" : "Local-only workspace";
            section.dataset.connection = navigator.onLine === false ? "offline" : account.authenticated ? "cloud" : "local";
            section.innerHTML = clientMode
                ? `<div class="work-context-copy"><strong>Active client project</strong><small>${active ? `Work is isolated for ${esc(active.name)}.` : "No clients yet. Add one to isolate its websites, ads, leads, and approvals."}</small><span class="work-context-connection">${connection}</span></div><div class="work-context-controls"><select id="work-context-select" aria-label="Choose client project"><option value="">Choose a client</option>${items.map((item) => `<option value="${esc(item.id)}" ${item.id === active?.id ? "selected" : ""}>${esc(item.name)} — ${esc(item.projectName)}</option>`).join("")}</select><button type="button" id="new-work-context">New client</button></div><form id="work-context-form" class="work-context-form" hidden><label>Client name<input name="name" maxlength="180" required></label><label>Project name<input name="projectName" maxlength="180"></label><label>Approval contact<input name="approvalContact" type="email" maxlength="240" placeholder="owner@example.com"></label><label><input name="permissionsConfirmed" type="checkbox"> Permission to use client content confirmed</label><label><input name="assetRightsConfirmed" type="checkbox"> Asset ownership or licences confirmed</label><div><button type="submit">Save client</button><button type="button" data-cancel-context>Cancel</button></div></form>`
                : `<div class="work-context-copy"><strong>Active workspace: My business</strong><small>Your profile, website, assets, claims, and campaigns are reused only for your business.</small><span class="work-context-connection">${connection}</span></div>`;
            section.querySelector("#work-context-select")?.addEventListener("change", (event) => { if (event.target.value) select(event.target.value); });
            section.querySelector("#new-work-context")?.addEventListener("click", () => { section.querySelector("#work-context-form").hidden = false; section.querySelector("[name=name]")?.focus(); });
            section.querySelector("[data-cancel-context]")?.addEventListener("click", () => { section.querySelector("#work-context-form").hidden = true; });
            section.querySelector("#work-context-form")?.addEventListener("submit", (event) => {
                event.preventDefault();
                if (!confirmSwitch("Create and open this client workspace? Unsaved edits may be lost.")) return;
                saveWebsiteSnapshot();
                const data = new FormData(event.currentTarget);
                const item = upsert({ name: data.get("name"), projectName: data.get("projectName"), approvalContact: data.get("approvalContact"), permissionsConfirmed: data.get("permissionsConfirmed") === "on", assetRightsConfirmed: data.get("assetRightsConfirmed") === "on" });
                restoreWebsiteSnapshot(item);
                window.location.reload();
            });
            applyExperience();
        };
        render();
        window.addEventListener("omniscript:operating-mode", render);
        window.addEventListener("workspace:core-ready", applyExperience);
        window.addEventListener("supabase:authenticated", () => syncCloud().then(render).catch((error) => window.dispatchEvent(new CustomEvent("morrow:work-context-error", { detail: { message: error.message } }))));
        window.addEventListener("supabase:unauthenticated", render);
        window.addEventListener("online", render);
        window.addEventListener("offline", render);
        window.addEventListener("morrow:work-contexts-synced", render);
        if (window.supabaseWorkspace?.getState?.().authenticated) syncCloud().then(render).catch(() => {});
    }

    function bootstrapWebsiteSnapshot() {
        const target = current();
        try {
            const scopedKey = storageKey(WEBSITE_KEY, target || { id: "unselected", mode: "client" });
            const scoped = localStorage.getItem(scopedKey);
            const legacy = localStorage.getItem(WEBSITE_KEY);
            if (scoped) localStorage.setItem(WEBSITE_KEY, scoped);
            else if (target?.mode === "own" && legacy) localStorage.setItem(scopedKey, legacy);
            else if (target?.mode === "client") localStorage.removeItem(WEBSITE_KEY);
        } catch (_) {}
    }

    const api = Object.freeze({ REGISTRY_KEY, ACTIVE_KEY, OWN_ID, ready: true, contexts, current, activeId, namespace, storageKey, readScoped, writeScoped, clientGate, assertClientReady, upsert, remove, select, syncCloud, syncContext, hasUnsavedWork, confirmSwitch, prepareModeSwitch, saveWebsiteSnapshot, restoreWebsiteSnapshot });
    window.workspaceContext = api;
    bootstrapWebsiteSnapshot();
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    if (typeof document !== "undefined") {
        const announceReady = () => window.dispatchEvent(new CustomEvent("workspace:context-ready", { detail: { context: current() ? clone(current()) : null } }));
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { mount(); announceReady(); }, { once: true });
        else { mount(); queueMicrotask(announceReady); }
    }
})();
