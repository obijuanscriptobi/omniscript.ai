"use strict";

// Dependency-free primitives shared by the editor and benchmark workflow.
(() => {
    const encoder = new TextEncoder();
    const bytes = (value) => encoder.encode(String(value ?? "")).byteLength;

    function hash(value) {
        let result = 2166136261;
        const text = String(value ?? "");
        for (let index = 0; index < text.length; index += 1) {
            result ^= text.charCodeAt(index);
            result = Math.imul(result, 16777619);
        }
        return (result >>> 0).toString(16).padStart(8, "0");
    }

    const normalizePath = (target) => String(target ?? "").replace(/^\/+/, "");
    const isExternalReference = (target) => /^(?:https?:|mailto:|tel:|data:|javascript:|\/\/)/i.test(String(target ?? ""));

    function resolvePath(file, target) {
        try {
            return decodeURIComponent(new URL(String(target), `https://workspace.invalid/${normalizePath(file)}`).pathname).replace(/^\/+/, "");
        } catch {
            return normalizePath(target);
        }
    }

    function knownPaths(files) {
        return new Set(Object.keys(files || {}).map(normalizePath));
    }

    function manifest(files = {}) {
        const entries = files && typeof files === "object" ? Object.entries(files) : [];
        return Object.fromEntries(entries.map(([name, content]) => {
            const text = String(content ?? "");
            return [name, { bytes: bytes(text), hash: hash(text) }];
        }));
    }

    function diffFiles(before = {}, after = {}) {
        const previousFiles = before && typeof before === "object" ? before : {};
        const nextFiles = after && typeof after === "object" ? after : {};
        return [...new Set([...Object.keys(previousFiles), ...Object.keys(nextFiles)])]
            .map((name) => {
                const previous = String(previousFiles[name] ?? "");
                const next = String(nextFiles[name] ?? "");
                return previous === next ? null : {
                    name,
                    before: { bytes: bytes(previous), hash: hash(previous) },
                    after: { bytes: bytes(next), hash: hash(next) }
                };
            })
            .filter(Boolean);
    }

    function brokenLocalReferences(files = {}) {
        const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
        const known = knownPaths(sourceFiles);
        const results = [];
        const addReference = (file, target) => {
            const value = String(target || "").trim();
            if (!value || value === "/" || value.startsWith("#") || isExternalReference(value)) return;
            const resolvedTarget = resolvePath(file, value);
            if (resolvedTarget && !known.has(resolvedTarget)) results.push({ file, target: value });
        };
        for (const [file, content] of Object.entries(sourceFiles)) {
            if (!/\.html?$/i.test(file)) continue;
            const html = String(content ?? "");
            for (const match of html.matchAll(/\b(?:href|src)=["']([^"']+)["']/gi)) addReference(file, match[1].split(/[?#]/)[0]);
            for (const match of html.matchAll(/\bsrcset=["']([^"']+)["']/gi)) {
                match[1].split(",").forEach((candidate) => addReference(file, candidate.trim().split(/\s+/)[0]));
            }
        }
        return [...new Map(results.map((item) => [`${item.file}\u0000${item.target}`, item])).values()];
    }

    function validateBrief(input = {}) {
        const brief = input && typeof input === "object" && !Array.isArray(input) ? input : {};
        const required = ["businessName", "audience", "offer", "outcome", "primaryAction"];
        const issues = required.filter((field) => !String(brief[field] ?? "").trim()).map((field) => ({ code: "BRIEF_FIELD_REQUIRED", field }));
        const destinations = {
            booking: ["bookingUrl", "formAction"],
            call: ["phone"],
            enquiry: ["email", "formAction"],
            quote: ["formAction", "email", "phone"],
            purchase: ["shopUrl"]
        };
        const action = String(brief.primaryAction ?? "").trim().toLowerCase();
        if (!action) {
            // Keep the required-field error above authoritative; do not turn a
            // missing action into an implicit default destination.
        } else if (!destinations[action]) {
            issues.push({ code: "UNKNOWN_PRIMARY_ACTION", field: "primaryAction" });
        } else if (!destinations[action].some((field) => String(brief[field] ?? "").trim())) {
            issues.push({ code: "ACTION_DESTINATION_REQUIRED", field: "primaryAction" });
        }
        for (const field of ["bookingUrl", "formAction", "shopUrl"]) {
            const value = String(brief[field] ?? "").trim();
            if (!value) continue;
            try {
                const url = new URL(value);
                if (!["http:", "https:"].includes(url.protocol) || !url.hostname || url.username || url.password || url.hash) throw new Error("invalid destination");
            } catch {
                issues.push({ code: "INVALID_DESTINATION", field });
            }
        }
        return { valid: issues.length === 0, issues };
    }

    function auditSite(files = {}) {
        const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
        const html = String(sourceFiles["index.html"] ?? "");
        const known = knownPaths(sourceFiles);
        const localReferences = [];
        for (const match of html.matchAll(/\b(?:href|src)=["']([^"'#?]+)["']/gi)) {
            const target = match[1];
            const resolvedTarget = resolvePath("index.html", target);
            if (!isExternalReference(target) && !known.has(resolvedTarget) && !target.startsWith("#")) localReferences.push(target);
        }
        return {
            hasDoctype: /^\s*<!doctype\s+html>/i.test(html),
            hasLanguage: /<html\b[^>]*\blang=["'][^"']+["']/i.test(html),
            hasViewport: /<meta\b[^>]*\bname\s*=\s*["']viewport["'][^>]*>/i.test(html),
            h1Count: (html.match(/<h1\b/gi) || []).length,
            missingAlt: /<img\b(?![^>]*\balt\s*=\s*["'][^"']*["'])[^>]*>/i.test(html),
            hasStructuredData: /<script\b[^>]+type=["']application\/ld\+json["']/i.test(html),
            hasSocialMetadata: /<meta\b[^>]+property=["']og:title["']/i.test(html) && /<meta\b[^>]+property=["']og:description["']/i.test(html),
            localReferences
        };
    }

    function benchmarkFiles(files = {}) {
        const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
        const html = String(sourceFiles["index.html"] ?? "");
        const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
        const audit = typeof window !== "undefined" ? window.workspaceAudit?.auditProject?.(sourceFiles) : null;
        const blocking = audit?.blocking || [];
        const hasPath = /<form\b[^>]*action=["'][^"']+|href=["'](?:tel:|mailto:|https?:\/\/|#[^"']+)["']/i.test(html);
        const missingAlt = /<img\b(?![^>]*\balt\s*=)/i.test(html);
        const scores = {
            conversion: hasPath ? 100 : 0,
            content: /<h1\b[^>]*>\s*[^<]+/i.test(html) && text.length >= 240 ? 100 : 50,
            accessibility: Math.max(0, 100 - blocking.filter((item) => item.category === "accessibility").length * 35),
            performance: /<script\b[^>]+src=["']https?:/i.test(html) ? 70 : 100,
            reliability: html && !/\b(?:eval|new\s+Function)\s*\(/.test(Object.values(sourceFiles).join("\n")) && !blocking.some((item) => item.code === "MISSING_LOCAL_REFERENCE") ? 100 : 0,
            speed: Math.max(0, 100 - Math.round(Object.values(sourceFiles).reduce((sum, value) => sum + String(value ?? "").length, 0) / 100000))
        };
        const overall = Math.round(Object.values(scores).reduce((sum, value) => sum + value, 0) / 6);
        return { scores, overall, publishable: Boolean(html) && hasPath && !missingAlt && blocking.length === 0 };
    }

    window.workspaceCore = {
        hash,
        manifest,
        diffFiles,
        normalizePath,
        resolvePath,
        isExternalReference,
        brokenLocalReferences,
        validateBrief,
        auditSite,
        benchmarkFiles
    };
})();
