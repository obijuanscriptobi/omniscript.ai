"use strict";

// Local-first lead inbox contract. Production lead persistence and notifications
// should be added behind an authenticated server endpoint in the next phase.
(() => {
    const STORAGE_KEY = "morrow-lead-inbox-v1";
    const storageKey = (base = STORAGE_KEY) => window.workspaceContext?.storageKey?.(base) || base;
    const STATUSES = Object.freeze(["new", "qualified", "discovery", "demo", "proposal", "negotiation", "won", "lost"]);
    const STATUS_MIGRATIONS = Object.freeze({ contacted: "qualified", booked: "demo" });
    const STAGE_ORDER = Object.freeze(["new", "qualified", "discovery", "demo", "proposal", "negotiation", "won", "lost"]);
    const CALL_OUTCOMES = Object.freeze({
        no_answer: { label: "No answer", status: "new", next: "Try calling again", days: 2 },
        voicemail: { label: "Left voicemail", status: "qualified", next: "Follow up after voicemail", days: 2 },
        callback: { label: "Call back later", status: "qualified", next: "Call back prospect", days: 3 },
        interested: { label: "Interested", status: "qualified", next: "Send mobile improvement preview", days: 1 },
        demo_sent: { label: "Send preview", status: "demo", next: "Follow up on preview", days: 3 },
        proposal_sent: { label: "Send proposal", status: "proposal", next: "Follow up on proposal", days: 3 },
        won: { label: "Won", status: "won", next: "Start project handoff", days: 1 },
        lost: { label: "Lost", status: "lost", next: "Record why this was lost", days: 0 },
        not_interested: { label: "Not interested", status: "lost", next: "Record why this was lost", days: 0 }
    });
    const clean = (value, max = 500) => String(value ?? "").replace(/[\u0000-\u001F\u007F]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
    const iso = (value, fallback = new Date().toISOString()) => { const date = new Date(value); return Number.isFinite(date.getTime()) ? date.toISOString() : fallback; };
    const stageName = (value) => STATUS_MIGRATIONS[value] || (STATUSES.includes(value) ? value : "new");

    function normalizeQualification(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        const budget = ["unknown", "unconfirmed", "confirmed", "not-fit"].includes(source.budget) ? source.budget : "unknown";
        const authority = ["unknown", "influencer", "decision-maker", "committee"].includes(source.authority) ? source.authority : "unknown";
        const need = ["unknown", "exploring", "active", "urgent"].includes(source.need) ? source.need : "unknown";
        const timeline = ["unknown", "90-plus-days", "30-90-days", "under-30-days"].includes(source.timeline) ? source.timeline : "unknown";
        return { budget, authority, need, timeline, score: Math.max(0, Math.min(100, Number(source.score) || 0)) };
    }

    function normalizeDiscovery(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        return { painPoints: Array.isArray(source.painPoints) ? source.painPoints.map((item) => clean(item, 240)).filter(Boolean).slice(0, 12) : [], notes: clean(source.notes, 2000), nextMeeting: clean(source.nextMeeting, 40), stakeholders: Array.isArray(source.stakeholders) ? source.stakeholders.map((item) => ({ name: clean(item?.name, 160), role: clean(item?.role, 160), email: clean(item?.email, 240) })).filter((item) => item.name || item.email).slice(0, 20) : [] };
    }

    function normalizeProposal(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        const services = Array.isArray(source.services) ? source.services.map((item) => clean(item, 240)).filter(Boolean).slice(0, 20) : [];
        const revisions = Array.isArray(source.revisionHistory) ? source.revisionHistory.slice(0, 30).map((item) => ({
            version: Math.max(1, Number(item?.version) || 1), status: clean(item?.status, 40), at: iso(item?.at), note: clean(item?.note, 500)
        })) : [];
        return {
            status: ["none", "draft", "sent", "viewed", "negotiating", "accepted", "declined"].includes(source.status) ? source.status : "none",
            total: Math.max(0, Number(source.total) || 0), version: Math.max(0, Number(source.version) || 0),
            validityDate: clean(source.validityDate, 40), services,
            pricingNotes: clean(source.pricingNotes, 1200), discoveryNotes: clean(source.discoveryNotes, 2000),
            objections: Array.isArray(source.objections) ? source.objections.map((item) => clean(item, 300)).filter(Boolean).slice(0, 20) : [],
            contractNotes: clean(source.contractNotes, 2000), revisionHistory: revisions, sentAt: clean(source.sentAt, 40), viewedAt: clean(source.viewedAt, 40),
            approvalToken: clean(source.approvalToken, 160), approvalUrl: clean(source.approvalUrl, 1000), approvedAt: clean(source.approvedAt, 40), declinedAt: clean(source.declinedAt, 40), paymentStatus: ["not-requested", "pending", "paid", "failed"].includes(source.paymentStatus) ? source.paymentStatus : "not-requested"
        };
    }

    const OFFER_PACKAGES = Object.freeze({
        quick_fix: { name: "Quick Fix", price: 750, timeline: "3–5 business days", revisions: 1, services: ["Mobile layout corrections", "Primary CTA placement", "Contact button improvements", "Basic speed cleanup"] },
        conversion_upgrade: { name: "Conversion Upgrade", price: 1800, timeline: "5–8 business days", revisions: 2, services: ["New mobile homepage", "Stronger messaging", "Lead form improvements", "Trust section", "Analytics and tracking"] },
        full_refresh: { name: "Full Website Refresh", price: 3500, timeline: "10–15 business days", revisions: 3, services: ["Multi-page redesign", "Copy and visual improvements", "SEO foundations", "Deployment", "Ongoing optimization"] }
    });
    const RECURRING_SERVICES = Object.freeze({
        monthly_optimization: { name: "Monthly optimization", price: 300 },
        hosting_maintenance: { name: "Hosting and maintenance", price: 150 },
        analytics_reporting: { name: "Analytics reporting", price: 200 },
        lead_follow_up: { name: "Lead follow-up automation", price: 400 },
        landing_pages: { name: "New landing pages", price: 500 },
        seasonal_campaigns: { name: "Seasonal campaign updates", price: 350 }
    });

    function normalizeOffer(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        const packageKey = Object.prototype.hasOwnProperty.call(OFFER_PACKAGES, source.packageKey) ? source.packageKey : "";
        const recurring = Array.isArray(source.recurring) ? source.recurring.filter((key) => Object.prototype.hasOwnProperty.call(RECURRING_SERVICES, key)).slice(0, 6) : [];
        return { packageKey, packageName: clean(source.packageName, 120), price: Math.max(0, Number(source.price) || 0), timeline: clean(source.timeline, 120), revisions: Math.max(0, Number(source.revisions) || 0), services: Array.isArray(source.services) ? source.services.map((item) => clean(item, 240)).filter(Boolean).slice(0, 20) : [], recurring, recurringTotal: Math.max(0, Number(source.recurringTotal) || 0), notes: clean(source.notes, 1200) };
    }

    function buildOffer(lead = {}, packageKey = "conversion_upgrade", recurring = []) {
        const selected = OFFER_PACKAGES[packageKey] || OFFER_PACKAGES.conversion_upgrade;
        const recurringKeys = Array.isArray(recurring) ? recurring.filter((key) => RECURRING_SERVICES[key]) : [];
        const recurringTotal = recurringKeys.reduce((total, key) => total + RECURRING_SERVICES[key].price, 0);
        return normalizeOffer({ packageKey, packageName: selected.name, price: selected.price, timeline: selected.timeline, revisions: selected.revisions, services: selected.services, recurring: recurringKeys, recurringTotal, notes: `Fixed-scope ${selected.name} based on the mobile audit for ${lead.company || lead.name || "this business"}.` });
    }

    function saveOffer(leadId, packageKey, recurring = []) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead || !OFFER_PACKAGES[packageKey]) return read();
        const offer = buildOffer(lead, packageKey, recurring);
        return update(leadId, { offer, opportunity: { ...lead.opportunity, suggestedOffer: offer.packageName, priceRange: `$${offer.price.toLocaleString()}${offer.recurringTotal ? ` + $${offer.recurringTotal.toLocaleString()}/mo` : ""}`, estimatedValue: offer.price }, proposal: { ...lead.proposal, total: offer.price, services: offer.services, pricingNotes: offer.notes }, activity: [{ type: "offer", label: `${offer.packageName} offer selected`, at: new Date().toISOString() }] });
    }

    function normalizePreview(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        const events = Array.isArray(source.events) ? source.events.slice(0, 100).map((item) => ({
            type: clean(item?.type, 40), at: iso(item?.at), detail: clean(item?.detail, 240)
        })) : [];
        return {
            url: clean(source.url, 1000), token: clean(source.token, 160),
            status: ["draft", "shared", "viewed", "approved", "revoked", "expired"].includes(source.status) ? source.status : "draft",
            expiresAt: clean(source.expiresAt, 40), sharedAt: clean(source.sharedAt, 40), viewedAt: clean(source.viewedAt, 40), approvedAt: clean(source.approvedAt, 40), revokedAt: clean(source.revokedAt, 40),
            beforeLabel: clean(source.beforeLabel, 160) || "Current website", afterLabel: clean(source.afterLabel, 160) || "Mobile improvement concept",
            headline: clean(source.headline, 300), impact: clean(source.impact, 600), offerName: clean(source.offerName, 180), price: Math.max(0, Number(source.price) || 0), timeline: clean(source.timeline, 120), ctaLabel: clean(source.ctaLabel, 100) || "Discuss this improvement", ctaUrl: clean(source.ctaUrl, 1000), clientNotes: clean(source.clientNotes, 1200),
            changes: Array.isArray(source.changes) ? source.changes.map((item) => clean(item, 300)).filter(Boolean).slice(0, 12) : [],
            events
        };
    }

    function previewToken() {
        return `preview-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
    }

    function createPreview(leadId, details = {}) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return null;
        const current = normalizePreview(lead.preview);
        const preview = normalizePreview({
            ...current, ...details, token: current.token || previewToken(),
            status: "shared", sharedAt: current.sharedAt || new Date().toISOString(),
            expiresAt: details.expiresAt || current.expiresAt || new Date(Date.now() + 7 * 86400000).toISOString(),
            changes: details.changes || current.changes || lead.opportunity?.recommendations || [],
            headline: details.headline || current.headline || lead.opportunity?.report?.headline || `A clearer mobile experience for ${lead.company || lead.name || "your business"}`,
            impact: details.impact || current.impact || lead.opportunity?.consequences?.[0] || "Make it easier for mobile visitors to understand the offer and take action.",
            offerName: details.offerName || current.offerName || lead.offer?.packageName || lead.opportunity?.suggestedOffer || "Mobile conversion improvement package",
            price: details.price ?? current.price ?? lead.offer?.price ?? lead.proposal?.total ?? 0,
            timeline: details.timeline || current.timeline || lead.offer?.timeline || lead.opportunity?.report?.timeline || "3–5 business days",
            ctaLabel: details.ctaLabel || current.ctaLabel || "Discuss this improvement",
            ctaUrl: details.ctaUrl || current.ctaUrl || "",
            clientNotes: details.clientNotes || current.clientNotes || "",
            events: [{ type: "created", detail: "Private preview created", at: new Date().toISOString() }, ...current.events]
        });
        const url = preview.url || lead.opportunity?.previewUrl || "";
        const saved = update(leadId, { preview, opportunity: { ...lead.opportunity, previewUrl: url }, status: lead.status === "new" ? "demo" : lead.status, nextAction: { title: "Follow up on private preview", dueDate: new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10), owner: lead.assignedTo || "sales" }, activity: [{ type: "preview", label: "Private preview created", at: new Date().toISOString() }] });
        return saved.find((item) => item.id === leadId)?.preview || preview;
    }

    function trackPreview(leadId, eventType, detail = "") {
        const lead = read().find((item) => item.id === leadId);
        if (!lead || !["viewed", "cta-call", "cta-proposal", "approved"].includes(eventType)) return null;
        const now = new Date().toISOString();
        const preview = normalizePreview(lead.preview);
        const next = normalizePreview({ ...preview, status: eventType === "approved" ? "approved" : (preview.status === "shared" ? "viewed" : preview.status), viewedAt: eventType === "viewed" ? (preview.viewedAt || now) : preview.viewedAt, approvedAt: eventType === "approved" ? now : preview.approvedAt, events: [{ type: eventType, detail: clean(detail, 240), at: now }, ...preview.events] });
        const status = eventType === "approved" ? "won" : (eventType === "cta-proposal" ? "proposal" : lead.status);
        return update(leadId, { preview: next, status, activity: [{ type: "preview", label: `Preview ${eventType.replace("cta-", "")}`, at: now }] }).find((item) => item.id === leadId)?.preview || next;
    }

    function revokePreview(leadId) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return null;
        const preview = normalizePreview(lead.preview);
        const next = normalizePreview({ ...preview, status: "revoked", revokedAt: new Date().toISOString(), events: [{ type: "revoked", detail: "Private preview revoked", at: new Date().toISOString() }, ...preview.events] });
        return update(leadId, { preview: next, activity: [{ type: "preview", label: "Private preview revoked", at: new Date().toISOString() }] }).find((item) => item.id === leadId)?.preview || next;
    }

    function normalizeNextAction(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        return { title: clean(source.title, 240), dueDate: clean(source.dueDate, 40), owner: clean(source.owner, 160) };
    }

    function normalizeOpportunity(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        const list = (items, max = 8) => Array.isArray(items) ? items.map((item) => clean(item, 500)).filter(Boolean).slice(0, max) : [];
        const reportSource = source.report && typeof source.report === "object" ? source.report : {};
        const findings = Array.isArray(reportSource.findings) ? reportSource.findings.map((finding) => ({
            problem: clean(finding?.problem, 300), impact: clean(finding?.impact, 400), recommendation: clean(finding?.recommendation, 400),
            priority: ["high", "medium", "low"].includes(finding?.priority) ? finding.priority : "medium", effort: clean(finding?.effort, 80)
        })).filter((finding) => finding.problem || finding.impact || finding.recommendation).slice(0, 12) : [];
        return {
            industry: clean(source.industry, 120), location: clean(source.location, 240), decisionMaker: clean(source.decisionMaker, 180),
            summary: clean(source.summary, 500), problems: list(source.problems), consequences: list(source.consequences),
            recommendations: list(source.recommendations), discoveryQuestions: list(source.discoveryQuestions, 10), objections: list(source.objections, 10),
            openingLine: clean(source.openingLine, 800), suggestedOffer: clean(source.suggestedOffer, 300), priceRange: clean(source.priceRange, 120),
            estimatedValue: Math.max(0, Number(source.estimatedValue) || 0), auditUrl: clean(source.auditUrl, 500), previewUrl: clean(source.previewUrl, 500), proposalId: clean(source.proposalId, 120), projectId: clean(source.projectId, 120),
            report: { headline: clean(reportSource.headline, 300), score: Number.isFinite(Number(reportSource.score)) ? Math.max(0, Math.min(100, Number(reportSource.score))) : null, findings, offer: clean(reportSource.offer, 300), timeline: clean(reportSource.timeline, 120), technicalDetails: list(reportSource.technicalDetails, 12) }
        };
    }

    function buildSalesReport(lead = {}) {
        const audit = lead.audit || {};
        const issues = Array.isArray(audit.issues) ? audit.issues.filter(Boolean).slice(0, 12) : [];
        const businessName = lead.company || lead.name || "this business";
        const recommendations = ["Clarify the first mobile screen", "Make the primary contact action easy to find", "Reduce friction in the contact path"];
        const findings = issues.map((problem, index) => ({
            problem: clean(problem, 300), priority: index < 2 ? "high" : "medium", effort: index < 2 ? "1–2 hours" : "Half day",
            impact: `Mobile visitors may leave before contacting ${businessName} when ${clean(problem, 220).toLowerCase()}.`,
            recommendation: recommendations[index % recommendations.length]
        }));
        return { headline: findings.length ? `Mobile conversion opportunities for ${businessName}` : `A mobile-first improvement opportunity for ${businessName}.`, score: audit.mobileScore ?? null, findings, offer: lead.opportunity?.suggestedOffer || "Mobile conversion improvement package", timeline: "Typically delivered in 3–5 business days", technicalDetails: Object.entries(audit.performanceMetrics || {}).slice(0, 12).map(([key, value]) => `${key}: ${value}`) };
    }

    function buildCallBrief(lead = {}) {
        const audit = lead.audit || {};
        const report = lead.opportunity?.report?.findings?.length ? lead.opportunity.report : buildSalesReport(lead);
        const problems = (lead.opportunity?.problems?.length ? lead.opportunity.problems : report.findings.map((finding) => finding.problem)).slice(0, 3);
        const businessName = lead.company || lead.name || "your business";
        return normalizeOpportunity({
            ...lead.opportunity,
            summary: lead.opportunity?.summary || `A mobile-first improvement opportunity for ${businessName}.`,
            problems: lead.opportunity?.problems?.length ? lead.opportunity.problems : problems,
            consequences: lead.opportunity?.consequences?.length ? lead.opportunity.consequences : problems.map((problem) => `Visitors may leave before contacting ${businessName}: ${problem}`),
            recommendations: lead.opportunity?.recommendations?.length ? lead.opportunity.recommendations : ["Clarify the first mobile screen", "Make the primary contact action easy to find", "Reduce friction in the contact path"],
            openingLine: lead.opportunity?.openingLine || `I noticed a few mobile improvements that could make it easier for people to contact ${businessName}. I can show you a quick before-and-after preview.`,
            suggestedOffer: lead.opportunity?.suggestedOffer || "Mobile conversion improvement package",
            priceRange: lead.opportunity?.priceRange || "To be scoped after discovery",
            report
        });
    }

    function saveSalesReport(leadId, report = {}) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return read();
        const current = buildCallBrief(lead);
        const nextReport = normalizeOpportunity({ report: { ...current.report, ...report } }).report;
        return update(leadId, {
            opportunity: { ...lead.opportunity, report: nextReport, problems: nextReport.findings.map((finding) => finding.problem).filter(Boolean), consequences: nextReport.findings.map((finding) => finding.impact).filter(Boolean), recommendations: nextReport.findings.map((finding) => finding.recommendation).filter(Boolean) },
            activity: [{ type: "audit-report", label: "Sales-ready audit report updated", at: new Date().toISOString() }, ...(lead.activity || [])]
        });
    }

    function normalizeMeeting(value = {}) {
        const source = value && typeof value === "object" ? value : {};
        return { provider: clean(source.provider, 40), externalId: clean(source.externalId, 120), scheduledAt: clean(source.scheduledAt, 40), status: ["booked", "cancelled", "completed"].includes(source.status) ? source.status : "" };
    }

    function addAuditLead(payload = {}) {
        const audit = payload.audit || {};
        const lead = add({
            name: payload.name || payload.email || "Mobile audit prospect",
            email: payload.email || "",
            websiteUrl: payload.websiteUrl || payload.url || "",
            source: payload.source || "mobile-audit",
            campaign: payload.campaign || "",
            message: `Requested a mobile website audit for ${payload.websiteUrl || payload.url || "their website"}.`,
            audit,
            opportunity: {
                industry: payload.industry || "",
                location: payload.location || "",
                decisionMaker: payload.decisionMaker || "",
                problems: audit.issues || [],
                auditUrl: payload.auditUrl || payload.websiteUrl || payload.url || "",
                suggestedOffer: payload.suggestedOffer || "Mobile conversion improvement package",
                priceRange: payload.priceRange || "To be scoped after discovery"
            },
            status: audit.mobileScore !== null && Number(audit.mobileScore) < 70 ? "qualified" : "new",
            nextAction: { title: "Review mobile audit and offer discovery call", dueDate: new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10), owner: "sales" },
            notes: audit.issues?.length
                ? `Audit findings: ${audit.issues.join("; ")}`
                : (audit.queued ? "Mobile audit queued; review the report when the provider completes it." : "Mobile audit completed; review the report before outreach.")
        });
        return lead;
    }

    function normalizeLead(raw = {}) {
        const lead = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        return {
            id: clean(lead.id, 80) || `lead-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            workContextId: clean(lead.workContextId, 100) || window.workspaceContext?.current?.()?.id || "own-business",
            cloudId: clean(lead.cloudId, 80),
            name: clean(lead.name, 160), email: clean(lead.email, 240), phone: clean(lead.phone, 80),
            message: clean(lead.message, 2000), company: clean(lead.company, 180), websiteUrl: clean(lead.websiteUrl, 500),
            audit: lead.audit && typeof lead.audit === "object" ? {
                provider: clean(lead.audit.provider, 80), requestedAt: iso(lead.audit.requestedAt, ""), queued: lead.audit.queued === true, mobileScore: Number.isFinite(Number(lead.audit.mobileScore)) ? Math.max(0, Math.min(100, Number(lead.audit.mobileScore))) : null,
                performanceMetrics: lead.audit.performanceMetrics && typeof lead.audit.performanceMetrics === "object" ? lead.audit.performanceMetrics : {}, issues: Array.isArray(lead.audit.issues) ? lead.audit.issues.map((item) => clean(item, 180)).filter(Boolean).slice(0, 12) : []
            } : null,
                        status: stageName(lead.status), source: clean(lead.source, 180) || "website", campaign: clean(lead.campaign, 180),
            utmSource: clean(lead.utmSource, 180), utmMedium: clean(lead.utmMedium, 180), utmCampaign: clean(lead.utmCampaign, 180),
            assignedTo: clean(lead.assignedTo, 160), role: clean(lead.role, 160),
            tags: Array.isArray(lead.tags) ? lead.tags.map((tag) => clean(tag, 50)).filter(Boolean).slice(0, 12) : [],
            qualification: normalizeQualification(lead.qualification), discovery: normalizeDiscovery(lead.discovery), opportunity: normalizeOpportunity(lead.opportunity), offer: normalizeOffer(lead.offer), preview: normalizePreview(lead.preview),
            meeting: normalizeMeeting(lead.meeting), proposal: normalizeProposal(lead.proposal), nextAction: normalizeNextAction(lead.nextAction),
            demo: { notes: clean(lead.demo?.notes, 2000), objections: Array.isArray(lead.demo?.objections) ? lead.demo.objections.map((item) => clean(item, 300)).filter(Boolean).slice(0, 20) : [] },
            closeReason: clean(lead.closeReason, 500), handoffAt: clean(lead.handoffAt, 40),
            unread: lead.unread !== false, notes: clean(lead.notes, 2000), reminderAt: clean(lead.reminderAt, 40),
            activity: Array.isArray(lead.activity) ? lead.activity.slice(0, 100).map((item) => ({ ...item, at: iso(item.at) })) : [{ type: "created", label: "Lead created", at: iso(lead.createdAt) }],
            createdAt: iso(lead.createdAt), updatedAt: iso(lead.updatedAt)
        };
    }

    function read() {
        try { const value = JSON.parse(localStorage.getItem(storageKey()) || "[]"); return Array.isArray(value) ? value.map(normalizeLead) : []; } catch (_) { return []; }
    }

    function write(leads) {
        const next = leads.map(normalizeLead).slice(0, 500);
        try { localStorage.setItem(storageKey(), JSON.stringify(next)); } catch (_) {}
        if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("crm:updated", { detail: { count: next.length } }));
        return next;
    }

    function canonicalProfile() {
        const service = window.profileService;
        const raw = window.workspaceAPI?.getState?.()?.businessProfile || service?.readLocal?.();
        return raw && service?.normalize ? service.normalize(raw) : null;
    }

    function consentAllowsContact() {
        return canonicalProfile()?.consent?.contactPermissionRequired !== false;
    }

    function captureWebsiteEnquiry(payload = {}) {
        const due = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
        const created = addWithCloud({
            name: payload.name,
            email: payload.email,
            phone: payload.phone,
            message: payload.message,
            company: payload.company,
            source: payload.source || "website",
            nextAction: { title: "Reply within one business day", dueDate: due, owner: "owner" }
        });
        return created || (Array.isArray(read()) ? read()[0] : null);
    }

    function add(lead) {
        const normalized = normalizeLead(lead);
        if (!consentAllowsContact() && normalized.email) normalized.email = "";
        const existing = read().find((item) => item.email && normalized.email && item.email.toLowerCase() === normalized.email.toLowerCase() && item.websiteUrl === normalized.websiteUrl && item.source === normalized.source);
        if (existing) {
            update(existing.id, { audit: normalized.audit || existing.audit, message: normalized.message || existing.message, notes: normalized.notes || existing.notes, unread: true });
            return read();
        }
        return write([normalized, ...read()]);
    }
    function update(id, changes = {}) {
        return write(read().map((lead) => {
            if (lead.id !== id) return lead;
            const activity = [...(lead.activity || [])];
            if (changes.status && changes.status !== lead.status) activity.unshift({ type: "status", label: `Status changed to ${changes.status}`, at: new Date().toISOString() });
            if (typeof changes.notes === "string" && changes.notes !== lead.notes) activity.unshift({ type: "note", label: "Note added", at: new Date().toISOString() });
            return normalizeLead({ ...lead, ...changes, unread: changes.unread ?? lead.unread, activity: [...(Array.isArray(changes.activity) ? changes.activity : []), ...activity] });
        }));
    }
    function recordCallOutcome(leadId, outcome, note = "") {
        const action = CALL_OUTCOMES[outcome];
        const lead = read().find((item) => item.id === leadId);
        if (!action || !lead) return read();
        const now = new Date();
        const dueDate = action.days ? new Date(now.getTime() + action.days * 86400000).toISOString().slice(0, 10) : "";
        const callNote = clean(note, 1000);
        return update(leadId, {
            status: action.status,
            notes: callNote || lead.notes,
            reminderAt: dueDate ? `${dueDate}T09:00:00.000Z` : "",
            nextAction: { title: action.next, dueDate, owner: lead.assignedTo || "sales" },
            activity: [{ type: "call", outcome, label: `Call outcome: ${action.label}`, note: callNote, at: now.toISOString() }, ...(lead.activity || [])],
            ...(action.status === "won" ? { handoffAt: now.toISOString() } : {})
        });
    }
    function bookDiscovery(leadId, booking = {}) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return null;
        if (lead.meeting?.status && ["booked", "completed"].includes(lead.meeting.status) && lead.meeting.scheduledAt) return null;
        try {
            const existingAppointments = JSON.parse(localStorage.getItem(storageKey("morrow-appointments-v1")) || "[]");
            if (Array.isArray(existingAppointments) && existingAppointments.some((item) => item.leadId === leadId && ["scheduled", "confirmed"].includes(item.status))) return null;
        } catch (_) { return null; }
        const meetingAt = iso(booking.scheduledAt, "");
        if (!meetingAt || new Date(meetingAt) <= new Date() || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(booking.email))) return null;
        const appointment = { 
            id: globalThis.crypto?.randomUUID?.() || `appointment-${Date.now()}`,
            clientName: clean(booking.name || lead.name || lead.email, 160), clientEmail: clean(booking.email, 320),
            clientBusiness: clean(booking.websiteUrl || lead.websiteUrl, 180), service: "Discovery call — mobile audit",
            notes: clean(booking.notes || "Review the mobile audit and identify the highest-impact improvements.", 1200),
            leadId, status: "scheduled", meetingAt, followUpAt: meetingAt,
            type: "discovery", durationMinutes: 45, objective: "Review the verified website opportunity and agree the next step", mode: "video", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            preparation: {}, outcome: "", outcomeNotes: "", nextAction: "Create and send a proposal", nextActionAt: "", rescheduleHistory: [], reminderPlan: { preparation: true, attendance: true, startingSoon: true, outcome: true, followUp: true, delivery: "local" }, timeline: [{ type: "booking", label: "Discovery call booked", at: new Date().toISOString() }],
            syncStatus: "local", syncAttemptAt: "", syncError: "", cloudId: "", cloudLeadId: ""
        };
        try {
            const appointments = JSON.parse(localStorage.getItem(storageKey("morrow-appointments-v1")) || "[]");
            localStorage.setItem(storageKey("morrow-appointments-v1"), JSON.stringify([appointment, ...(Array.isArray(appointments) ? appointments : [])]));
        } catch (_) { return null; }
        update(leadId, {
            status: "discovery", assignedTo: lead.assignedTo || "sales", meeting: { provider: "native", externalId: appointment.id, scheduledAt: meetingAt, status: "booked" },
            nextAction: { title: "Prepare for discovery call", dueDate: meetingAt.slice(0, 10), owner: lead.assignedTo || "sales" },
            qualification: { ...lead.qualification, score: Math.max(lead.qualification.score, 75) },
            activity: [{ type: "meeting", label: "Discovery call booked", at: new Date().toISOString() }, ...(lead.activity || [])]
        });
        return appointment;
    }
    async function bookDiscoveryWithCloud(leadId, booking = {}) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return null;
        let cloudLeadId = lead.cloudId;
        const state = window.supabaseWorkspace?.getState?.() || {};
        const projectId = currentProjectId();
        const token = window.supabaseWorkspace?.getAccessToken?.();

        if (state.authenticated && projectId && token && !cloudLeadId) {
            const result = await createInCloudResult(lead);
            if (result.ok) cloudLeadId = read().find((item) => item.id === leadId)?.cloudId || "";
            if (!cloudLeadId) cloudLeadId = lead.cloudId;
        }

        const appointment = bookDiscovery(leadId, booking);
        if (!appointment) return null;
        if (!state.authenticated || !projectId || !token) return appointment;
        if (!cloudLeadId) {
            saveAppointmentSyncState(appointment.id, { syncStatus: "pending", syncAttemptAt: new Date().toISOString(), syncError: "Cloud lead is not available yet." });
            return { ...appointment, syncStatus: "pending", syncError: "Cloud lead is not available yet." };
        }

        try {
            const url = cloudUrl("appointments", projectId);
            if (!url) throw new Error("The active workspace is not linked to the cloud project.");
            const response = await fetch(url, {
                method: "POST", credentials: "same-origin",
                headers: { Authorization: `Bearer ${token}`, Accept: "application/json", "Content-Type": "application/json" },
                body: JSON.stringify({
                    id: appointment.id,
                    leadId: cloudLeadId,
                    clientName: appointment.clientName,
                    clientEmail: appointment.clientEmail,
                    service: appointment.service,
                    notes: appointment.notes,
                    meetingAt: appointment.meetingAt,
                    followUpAt: appointment.followUpAt,
                    status: "scheduled",
                    appointmentType: appointment.type || "discovery",
                    objective: appointment.objective || "Review the verified website opportunity and agree the next step",
                    durationMinutes: appointment.durationMinutes || 45,
                    meetingMode: appointment.mode || "video",
                    timezone: appointment.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
                    preparation: appointment.preparation || {},
                    reminderPlan: appointment.reminderPlan || { preparation: true, attendance: true, startingSoon: true, outcome: true, followUp: true, delivery: "local" },
                    rescheduleHistory: appointment.rescheduleHistory || [],
                    timeline: appointment.timeline || [{ type: "booking", label: "Discovery call booked", at: new Date().toISOString() }]
                })
            });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || !payload.appointment?.id) throw new Error(payload.error || "Cloud appointment creation failed.");
            const cloudAppointment = payload.appointment;
            const cloudMeetingAt = cloudAppointment.meeting_at || appointment.meetingAt;
            saveAppointmentSyncState(appointment.id, {
                id: cloudAppointment.id, cloudId: cloudAppointment.id, cloudLeadId,
                leadId, status: cloudAppointment.status || appointment.status,
                meetingAt: cloudMeetingAt, syncStatus: "synced", syncAttemptAt: new Date().toISOString(), syncError: ""
            });
            update(leadId, { meeting: { provider: "native", externalId: cloudAppointment.id, scheduledAt: cloudMeetingAt, status: "booked" } });
            return { ...appointment, id: cloudAppointment.id, cloudId: cloudAppointment.id, cloudLeadId, meetingAt: cloudMeetingAt, syncStatus: "synced" };
        } catch (error) {
            saveAppointmentSyncState(appointment.id, { cloudLeadId, syncStatus: "pending", syncAttemptAt: new Date().toISOString(), syncError: error?.message || "Cloud appointment creation failed." });
            notifySync({ id: leadId, appointmentId: appointment.id, state: "failed", retryable: true, error: error?.message || "Cloud appointment creation failed." });
            return { ...appointment, syncStatus: "pending", syncError: error?.message || "Cloud appointment creation failed." };
        }
    }

    function readAppointments() {
        try {
            const value = JSON.parse(localStorage.getItem(storageKey("morrow-appointments-v1")) || "[]");
            return Array.isArray(value) ? value : [];
        } catch (_) { return []; }
    }

    function writeAppointments(value) {
        try { localStorage.setItem(storageKey("morrow-appointments-v1"), JSON.stringify(Array.isArray(value) ? value : [])); } catch (_) {}
    }

    function saveAppointmentSyncState(appointmentId, changes = {}) {
        const next = readAppointments().map((item) => item.id === appointmentId || item.cloudId === appointmentId ? { ...item, ...changes } : item);
        writeAppointments(next);
        return next.find((item) => item.id === appointmentId || item.cloudId === appointmentId) || null;
    }

    async function syncAppointmentWithCloud(appointment) {
        const state = window.supabaseWorkspace?.getState?.() || {};
        const projectId = currentProjectId();
        const token = window.supabaseWorkspace?.getAccessToken?.();
        if (!appointment || !state.authenticated || !projectId || !token || !appointment.cloudLeadId) return { ok: false, retryable: false, error: "Cloud project is unavailable." };
        const localId = appointment.id;
        saveAppointmentSyncState(localId, { syncStatus: "pending", syncAttemptAt: new Date().toISOString(), syncError: "" });
        try {
            const url = cloudUrl("appointments", projectId);
            if (!url) throw new Error("The active workspace is not linked to the cloud project.");
            const response = await fetch(url, {
                method: "POST", credentials: "same-origin",
                headers: { Authorization: `Bearer ${token}`, Accept: "application/json", "Content-Type": "application/json" },
                body: JSON.stringify({ id: appointment.cloudId || localId, leadId: appointment.cloudLeadId, clientName: appointment.clientName, clientBusiness: appointment.clientBusiness, clientEmail: appointment.clientEmail, clientPhone: appointment.phone, service: appointment.service, notes: appointment.notes, meetingAt: appointment.meetingAt, followUpAt: appointment.followUpAt, status: appointment.status, appointmentType: appointment.type || "discovery", objective: appointment.objective || "", durationMinutes: appointment.durationMinutes || 45, meetingMode: appointment.mode || "video", timezone: appointment.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone, preparation: appointment.preparation || {}, outcome: appointment.outcome || "", outcomeNotes: appointment.outcomeNotes || "", nextAction: appointment.nextAction || "", nextActionAt: appointment.nextActionAt || null, rescheduleHistory: appointment.rescheduleHistory || [], reminderPlan: appointment.reminderPlan || {}, timeline: appointment.timeline || [] })
            });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || !payload.appointment?.id) throw new Error(payload.error || "Cloud appointment creation failed.");
            const cloud = payload.appointment;
            saveAppointmentSyncState(localId, { id: cloud.id, cloudId: cloud.id, syncStatus: "synced", syncAttemptAt: new Date().toISOString(), syncError: "", meetingAt: cloud.meeting_at || appointment.meetingAt });
            update(appointment.leadId, { meeting: { provider: "native", externalId: cloud.id, scheduledAt: cloud.meeting_at || appointment.meetingAt, status: appointment.status === "scheduled" ? "booked" : appointment.status } });
            return { ok: true, appointment: cloud };
        } catch (error) {
            saveAppointmentSyncState(localId, { syncStatus: "pending", syncAttemptAt: new Date().toISOString(), syncError: error?.message || "Cloud appointment sync failed." });
            return { ok: false, retryable: true, error: error?.message || "Cloud appointment sync failed." };
        }
    }

    async function retryPendingAppointments() {
        const pending = readAppointments().filter((item) => item.syncStatus === "pending" && !["cancelled", "completed"].includes(item.status));
        for (const appointment of pending) {
            let current = appointment;
            if (!current.cloudLeadId && current.leadId) {
                const lead = read().find((item) => item.id === current.leadId);
                if (lead) {
                    const leadResult = lead.cloudId ? { ok: true } : await createInCloudResult(lead);
                    const cloudLeadId = read().find((item) => item.id === lead.id)?.cloudId || lead.cloudId;
                    if (leadResult.ok && cloudLeadId) current = saveAppointmentSyncState(current.id, { cloudLeadId }) || { ...current, cloudLeadId };
                }
            }
            if (current.cloudLeadId) await syncAppointmentWithCloud(current);
        }
        return readAppointments();
    }

    function updateMeetingStatus(leadId, status, scheduledAt = "") {
        const allowed = ["booked", "cancelled", "completed"];
        const lead = read().find((item) => item.id === leadId);
        if (!lead || !allowed.includes(status)) return read();
        if (status === "booked" && ["cancelled", "completed"].includes(lead.meeting?.status)) return read();
        const meeting = { ...lead.meeting, provider: lead.meeting.provider || "native", status, scheduledAt: scheduledAt ? iso(scheduledAt, lead.meeting.scheduledAt) : lead.meeting.scheduledAt };
        return update(leadId, {
            meeting,
            activity: [{ type: "meeting", label: `Discovery call ${status}`, at: new Date().toISOString() }, ...(lead.activity || [])],
            nextAction: status === "completed" ? { title: "Draft proposal from discovery notes", dueDate: new Date().toISOString().slice(0, 10), owner: lead.assignedTo || "sales" } : lead.nextAction
        });
    }

    function proposalToken() {
        return `proposal-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
    }

    function saveProposal(leadId, proposal = {}) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return read();
        const current = normalizeProposal(lead.proposal);
        const next = normalizeProposal({ ...current, ...proposal, version: Math.max(1, Number(proposal.version || current.version || 1)) });
        if (next.status === "sent" && current.status !== "sent") next.sentAt = new Date().toISOString();
        if (next.status === "viewed" && current.status !== "viewed") next.viewedAt = new Date().toISOString();
        if (next.status === "sent" && !next.approvalToken) next.approvalToken = proposalToken();
        const changed = JSON.stringify(current) !== JSON.stringify(next);
        if (changed) next.revisionHistory = [{ version: next.version, status: next.status, at: new Date().toISOString(), note: clean(proposal.revisionNote || `Proposal ${next.status}`, 500) }, ...(current.revisionHistory || [])].slice(0, 30);
        return update(leadId, { status: ["accepted", "declined"].includes(next.status) ? lead.status : "proposal", proposal: next, activity: changed ? [{ type: "proposal", label: `Proposal ${next.status}`, at: new Date().toISOString() }, ...(lead.activity || [])] : lead.activity });
    }

    function deliverProposal(leadId, details = {}) {
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return null;
        const current = normalizeProposal(lead.proposal);
        const token = current.approvalToken || proposalToken();
        const approvalUrl = details.approvalUrl || current.approvalUrl || `${window.location?.origin || ""}/proposal.html?token=${encodeURIComponent(token)}`;
        const updated = saveProposal(leadId, { ...details, status: "sent", approvalToken: token, approvalUrl, revisionNote: "Proposal delivered for client review" });
        return updated.find((item) => item.id === leadId)?.proposal || null;
    }

    function updateProposalResponse(leadId, status, details = {}) {
        if (!["viewed", "accepted", "declined"].includes(status)) return null;
        const lead = read().find((item) => item.id === leadId);
        if (!lead) return null;
        const now = new Date().toISOString();
        const proposal = { ...normalizeProposal(lead.proposal), ...details, status, ...(status === "viewed" ? { viewedAt: lead.proposal?.viewedAt || now } : {}), ...(status === "accepted" ? { approvedAt: now } : {}), ...(status === "declined" ? { declinedAt: now } : {}) };
        const nextStatus = status === "accepted" ? "won" : status === "declined" ? "negotiation" : "proposal";
        const updated = update(leadId, { status: nextStatus, proposal, handoffAt: status === "accepted" ? (lead.handoffAt || now) : lead.handoffAt, nextAction: status === "accepted" ? { title: "Start project handoff", dueDate: now.slice(0, 10), owner: lead.assignedTo || "sales" } : lead.nextAction, activity: [{ type: "proposal", label: `Proposal ${status}`, at: now }] });
        if (status === "accepted" && typeof window !== "undefined" && typeof window.dispatchEvent === "function") window.dispatchEvent(new CustomEvent("crm:proposal-approved", { detail: { leadId } }));
        return updated.find((item) => item.id === leadId)?.proposal || proposal;
    }

    function updateAppointment(appointmentId, changes = {}) {
        const key = storageKey("morrow-appointments-v1");
        try {
            const appointments = JSON.parse(localStorage.getItem(key) || "[]");
            const next = appointments.map((item) => item.id === appointmentId ? { ...item, ...changes } : item);
            localStorage.setItem(key, JSON.stringify(next));
            const appointment = next.find((item) => item.id === appointmentId);
            if (appointment?.leadId) {
                if (changes.status) updateMeetingStatus(appointment.leadId, changes.status === "scheduled" || changes.status === "confirmed" ? "booked" : changes.status, changes.meetingAt);
                else if (changes.meetingAt) updateMeetingStatus(appointment.leadId, "booked", changes.meetingAt);
            }
            return appointment || null;
        } catch (_) { return null; }
    }

    function remove(id) { return write(read().filter((lead) => lead.id !== id)); }
    function exportCsv() {
        const headers = ["id", "name", "email", "phone", "status", "source", "campaign", "message", "notes", "reminderAt", "createdAt"];
        const quote = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
        return [headers, ...read().map((lead) => headers.map((key) => lead[key]))].map((row) => row.map(quote).join(",")).join("\n");
    }

    function currentProjectId() {
        return window.workspaceAPI?.getState?.()?.projectId || window.morrowProjectContext?.read?.()?.projectId || "";
    }

    function currentWorkContextId() {
        return window.workspaceContext?.current?.()?.cloudId || "";
    }

    function cloudUrl(resource, projectId, suffix = "") {
        const contextId = currentWorkContextId();
        if (!contextId) return "";
        return `/api/${resource}?projectId=${encodeURIComponent(projectId)}&workContextId=${encodeURIComponent(contextId)}${suffix}`;
    }

    function notifySync(detail) {
        if (typeof window === "undefined" || typeof window.dispatchEvent !== "function") return;
        window.dispatchEvent(new CustomEvent("crm:sync", { detail }));
    }

    async function syncToCloudResult(lead) {
        const projectId = currentProjectId();
        if (!projectId || !window.supabaseWorkspace?.getState?.().authenticated) {
            return { ok: false, retryable: false, reason: "offline", error: "Sign in and select a cloud project to sync this lead." };
        }
        try {
            const cloudId = lead.cloudId || lead.id;
            const url = cloudUrl("leads", projectId, `&id=${encodeURIComponent(cloudId)}`);
            if (!url) return { ok: false, retryable: false, reason: "context", error: "The active workspace is not linked to the cloud project." };
            const token = window.supabaseWorkspace?.getAccessToken?.();
            const response = await fetch(url, {
                method: "PATCH", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
                body: JSON.stringify({ status: lead.status, notes: lead.notes, reminderAt: lead.reminderAt || null })
            });
            let payload = null;
            try { payload = await response.json(); } catch (_) {}
            return {
                ok: response.ok,
                retryable: response.status === 408 || response.status === 429 || response.status >= 500,
                status: response.status,
                error: payload?.error || "Cloud update failed."
            };
        } catch (error) {
            return { ok: false, retryable: true, reason: "network", error: error?.message || "Network error." };
        }
    }

    async function createInCloudResult(lead) {
        const projectId = currentProjectId();
        if (!projectId || !window.supabaseWorkspace?.getState?.().authenticated) {
            return { ok: false, retryable: false, reason: "offline", error: "Sign in and select a cloud project to sync this lead." };
        }
        try {
            const url = cloudUrl("leads", projectId);
            if (!url) return { ok: false, retryable: false, reason: "context", error: "The active workspace is not linked to the cloud project." };
            const token = window.supabaseWorkspace?.getAccessToken?.();
            const response = await fetch(url, {
                method: "POST", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
                body: JSON.stringify({
                    name: lead.name,
                    email: lead.email,
                    phone: lead.phone,
                    message: lead.message,
                    status: lead.status,
                    source: lead.source,
                    campaign: lead.campaign,
                    notes: lead.notes,
                    reminderAt: lead.reminderAt || null
                })
            });
            let payload = null;
            try { payload = await response.json(); } catch (_) {}
            if (response.ok && payload?.lead?.id) {
                const localLead = read().find((item) => item.id === lead.id);
                if (localLead) update(lead.id, { cloudId: payload.lead.id });
            }
            return {
                ok: response.ok,
                retryable: response.status === 408 || response.status === 429 || response.status >= 500,
                status: response.status,
                error: payload?.error || "Cloud lead creation failed."
            };
        } catch (error) {
            return { ok: false, retryable: true, reason: "network", error: error?.message || "Network error." };
        }
    }

    async function syncToCloud(lead) {
        const result = await syncToCloudResult(lead);
        return result.ok;
    }

    function completeSync(id, promise) {
        notifySync({ id, state: "pending" });
        promise.then((result) => {
            notifySync({ id, state: result.ok ? "synced" : "failed", retryable: result.retryable, error: result.error, status: result.status });
        }).catch((error) => {
            notifySync({ id, state: "failed", retryable: true, error: error?.message || "Cloud sync failed." });
        });
    }

    function updateWithCloud(id, changes = {}) {
        const next = update(id, changes);
        const updatedLead = next.find((item) => item.id === id);
        if (!updatedLead) return next;
        completeSync(id, syncToCloudResult(updatedLead));
        return next;
    }

    async function addAuditLeadWithCloud(payload = {}) {
        const next = addAuditLead(payload);
        const lead = Array.isArray(next) ? next.find((item) => item.email === payload.email && item.websiteUrl === (payload.websiteUrl || payload.url)) : next;
        if (!lead) return null;
        const result = await createInCloudResult(lead);
        return read().find((item) => item.id === lead.id) || lead;
    }

    function addWithCloud(lead = {}) {
        const next = add(lead);
        const createdLead = next[0];
        if (createdLead) completeSync(createdLead.id, createInCloudResult(createdLead));
        return createdLead;
    }

    function retryWithCloud(id) {
        const lead = read().find((item) => item.id === id);
        if (!lead) return read();
        completeSync(id, lead.cloudId ? syncToCloudResult(lead) : createInCloudResult(lead));
        return read();
    }

    function migrate() {
        const before = localStorage.getItem(storageKey());
        const current = read();
        const after = JSON.stringify(current);
        if (before !== after) { try { localStorage.setItem(storageKey(), after); } catch (_) {} }
        return { migrated: before !== after, count: current.length, leads: current };
    }

    window.workspaceCRM = Object.freeze({ STORAGE_KEY, STATUSES, STAGE_ORDER, CALL_OUTCOMES, OFFER_PACKAGES, RECURRING_SERVICES, normalizeLead, normalizeOpportunity, normalizeOffer, normalizePreview, buildOffer, buildCallBrief, buildSalesReport, saveSalesReport, saveOffer, createPreview, trackPreview, revokePreview, captureWebsiteEnquiry, read, migrate, add, addAuditLead, addAuditLeadWithCloud, bookDiscovery, bookDiscoveryWithCloud, recordCallOutcome, updateMeetingStatus, saveProposal, deliverProposal, updateProposalResponse, updateAppointment, addWithCloud, update, updateWithCloud, retryWithCloud, retryPendingAppointments, syncAppointmentWithCloud, readAppointments, remove, exportCsv, syncToCloud });
})();
