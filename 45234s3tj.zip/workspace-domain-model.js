"use strict";

// Canonical versioned records shared by generation, audits, release review,
// imports, benchmarks, deployments, and the operation history.
(() => {
    const MODEL_VERSION = 1;
    const READINESS_STATES = Object.freeze([
        "draft", "technical-review", "technical-blocked", "technically-passed",
        "deployed", "deployment-verified", "form-route-tested",
        "real-delivery-confirmed", "production-ready", "stale-after-change"
    ]);
    const EVIDENCE_KINDS = Object.freeze(["static", "rendered", "provider-confirmed", "user-confirmed"]);
    const ACTORS = Object.freeze(["system", "user", "import", "generator", "repair", "deployment", "test"]);

    const object = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const text = (value, fallback = "") => String(value ?? fallback).trim();
    const now = () => new Date().toISOString();
    const clone = (value) => JSON.parse(JSON.stringify(value));
    const byteLength = (value) => {
        const content = String(value ?? "");
        if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(content).byteLength;
        return unescape(encodeURIComponent(content)).length;
    };
    const id = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    function hash(value) {
        let result = 2166136261;
        for (const character of String(value ?? "")) {
            result ^= character.charCodeAt(0);
            result = Math.imul(result, 16777619);
        }
        return (result >>> 0).toString(16).padStart(8, "0");
    }

    function revisionOf(files = {}) {
        return hash(Object.keys(object(files)).sort().map((name) => `${name}\u0000${String(files[name] ?? "")}`).join("\u0001"));
    }

    function record(type, fields = {}) {
        return { model: type, version: MODEL_VERSION, ...fields };
    }

    function project(fields = {}) { return record("Project", { id: text(fields.id, id("project")), name: text(fields.name, "Untitled project"), revision: text(fields.revision), files: object(fields.files), pages: Array.isArray(fields.pages) ? fields.pages : [], brief: object(fields.brief), readiness: text(fields.readiness, "draft"), localization: object(fields.localization), providers: object(fields.providers), evidence: Array.isArray(fields.evidence) ? fields.evidence : [], operations: Array.isArray(fields.operations) ? fields.operations : [], updatedAt: text(fields.updatedAt, now()) }); }
    function page(fields = {}) { return record("Page", { path: text(fields.path, "index.html"), title: text(fields.title), template: text(fields.template, "custom"), revision: text(fields.revision), status: text(fields.status, "draft") }); }
    function file(fields = {}) { return record("File", { path: text(fields.path), content: text(fields.content), hash: text(fields.hash, hash(fields.content)), bytes: byteLength(fields.content), generatedBy: text(fields.generatedBy, "generator") }); }
    function brief(fields = {}) { return record("Brief", { businessName: text(fields.businessName), audience: text(fields.audience), offer: text(fields.offer), outcome: text(fields.outcome), primaryAction: text(fields.primaryAction), version: MODEL_VERSION }); }
    function finding(fields = {}) { return record("AuditFinding", { code: text(fields.code, "UNKNOWN"), severity: text(fields.severity, "warning"), category: text(fields.category, "quality"), file: text(fields.file), location: object(fields.location), message: text(fields.message, "Review this item."), evidence: text(fields.evidence), fix: object(fields.fix), revision: text(fields.revision) }); }
    function deployment(fields = {}) { return record("Deployment", { id: text(fields.id, id("deployment")), url: text(fields.url), revision: text(fields.revision), provider: text(fields.provider), status: text(fields.status, "unknown"), verifiedAt: text(fields.verifiedAt), createdAt: text(fields.createdAt, now()) }); }
    function formEvidence(fields = {}) { return record("FormDeliveryEvidence", { id: text(fields.id, id("form")), revision: text(fields.revision), route: text(fields.route), state: text(fields.state, "not-tested"), kind: text(fields.kind, "static"), submissionId: text(fields.submissionId), deploymentId: text(fields.deploymentId), confirmedAt: text(fields.confirmedAt), note: text(fields.note) }); }
    function importReport(fields = {}) { return record("ImportReport", { id: text(fields.id, id("import")), revision: text(fields.revision), sourceUrl: text(fields.sourceUrl), pages: Array.isArray(fields.pages) ? fields.pages : [], preserved: Array.isArray(fields.preserved) ? fields.preserved : [], rebuilt: Array.isArray(fields.rebuilt) ? fields.rebuilt : [], dropped: Array.isArray(fields.dropped) ? fields.dropped : [], missingAssets: Array.isArray(fields.missingAssets) ? fields.missingAssets : [], unsupported: Array.isArray(fields.unsupported) ? fields.unsupported : [], confidence: object(fields.confidence), fidelity: ["not-verified", "partial", "verified"].includes(fields.fidelity) ? fields.fidelity : "not-verified", createdAt: text(fields.createdAt, now()) }); }
    function benchmarkRun(fields = {}) { return record("BenchmarkRun", { id: text(fields.id, id("benchmark")), revision: text(fields.revision), fixtureVersion: text(fields.fixtureVersion, "1"), generatorVersion: text(fields.generatorVersion), testedFiles: Array.isArray(fields.testedFiles) ? fields.testedFiles : [], viewports: Array.isArray(fields.viewports) ? fields.viewports : [], scores: object(fields.scores), limitations: Array.isArray(fields.limitations) ? fields.limitations : [], createdAt: text(fields.createdAt, now()) }); }
    function operation(fields = {}) { return record("Operation", { id: text(fields.id, id("operation")), type: text(fields.type, "unknown"), actor: ACTORS.includes(fields.actor) ? fields.actor : "system", revisionBefore: text(fields.revisionBefore), revisionAfter: text(fields.revisionAfter), files: Array.isArray(fields.files) ? fields.files : [], invalidates: Array.isArray(fields.invalidates) ? fields.invalidates : [], createdAt: text(fields.createdAt, now()) }); }
    function evidence(fields = {}) { return record("Evidence", { id: text(fields.id, id("evidence")), revision: text(fields.revision), kind: EVIDENCE_KINDS.includes(fields.kind) ? fields.kind : "static", source: text(fields.source), scope: text(fields.scope), testedFiles: Array.isArray(fields.testedFiles) ? fields.testedFiles : [], viewports: Array.isArray(fields.viewports) ? fields.viewports : [], deploymentId: text(fields.deploymentId), deploymentRevision: text(fields.deploymentRevision), limitations: Array.isArray(fields.limitations) ? fields.limitations : [], createdAt: text(fields.createdAt, now()) }); }

    const required = {
        Project: ["id", "name", "files", "readiness"], Page: ["path", "status"], File: ["path", "content", "hash"],
        Brief: ["businessName", "audience", "offer", "outcome", "primaryAction"], AuditFinding: ["code", "severity", "category", "message"],
        Deployment: ["id", "url", "revision", "status"], FormDeliveryEvidence: ["id", "revision", "state", "kind"],
        ImportReport: ["id", "sourceUrl", "fidelity"], BenchmarkRun: ["id", "revision", "fixtureVersion"], Operation: ["id", "type", "actor", "createdAt"], Evidence: ["id", "revision", "kind"]
    };
    function validate(type, value) {
        const item = object(value); const errors = [];
        if (item.model && item.model !== type) errors.push({ code: "MODEL_TYPE", field: "model", message: `Expected ${type}.` });
        if (item.version !== MODEL_VERSION) errors.push({ code: "MODEL_VERSION", field: "version", message: `Expected model version ${MODEL_VERSION}.` });
        (required[type] || []).forEach((field) => { if (item[field] === undefined || item[field] === null || (typeof item[field] === "string" && !item[field].trim())) errors.push({ code: "REQUIRED_FIELD", field, message: `${field} is required.` }); });
        if (type === "Project" && !READINESS_STATES.includes(item.readiness)) errors.push({ code: "READINESS_STATE", field: "readiness", message: "Unknown readiness state." });
        if (type === "Finding" || type === "AuditFinding") { if (!/^(error|warning|info|blocking)$/.test(item.severity)) errors.push({ code: "SEVERITY", field: "severity", message: "Unknown finding severity." }); }
        if ((type === "Evidence" || type === "FormDeliveryEvidence") && !EVIDENCE_KINDS.includes(item.kind)) errors.push({ code: "EVIDENCE_KIND", field: "kind", message: "Unknown evidence kind." });
        if (type === "ImportReport" && !["not-verified", "partial", "verified"].includes(item.fidelity)) errors.push({ code: "FIDELITY", field: "fidelity", message: "Unknown import fidelity state." });
        return { valid: errors.length === 0, errors };
    }

    function migrate(raw) {
        const item = object(raw); const version = Number(item.version || 0);
        if (version === MODEL_VERSION) return clone(item);
        if (version === 1) return { ...clone(item), version: MODEL_VERSION, localization: object(item.localization), providers: object(item.providers) };
        if (version === 0) return { ...clone(item), version: MODEL_VERSION, model: item.model || "Project", localization: { locale: "en-US", direction: "ltr", supportedLocales: ["en-US"] }, providers: {} };
        throw new Error(`Unsupported workspace model version ${version}.`);
    }

    function transition(current, next, fields = {}) {
        if (!READINESS_STATES.includes(next)) throw new Error(`Unknown readiness state: ${next}`);
        const previous = READINESS_STATES.includes(current) ? current : "draft";
        const event = { from: previous, to: next, at: text(fields.at, now()), revision: text(fields.revision), source: text(fields.source, "workspace"), actor: ACTORS.includes(fields.actor) ? fields.actor : "system", scope: text(fields.scope), invalidates: Array.isArray(fields.invalidates) ? fields.invalidates : [] };
        return { state: next, event };
    }

    function invalidateReadiness(current, revision, operationType) {
        if (["source-edit", "visual-edit", "generation", "import", "deployment"].includes(operationType) && current !== "draft") return transition(current, "stale-after-change", { revision, source: operationType, actor: operationType === "import" ? "import" : operationType === "generation" ? "generator" : "user", invalidates: ["deployment-verification", "form-delivery", "production-ready"] });
        return { state: current || "draft", event: null };
    }

    function compile(files = {}) {
        const source = object(files);
        const entries = Object.entries(source);
        const records = entries.map(([path, content]) => file({ path, content }));
        const safePath = (path) => /^(?:[a-z0-9][a-z0-9._-]{0,119}\.(?:html?|css|js|json|toml|txt|xml)|netlify\/functions\/[a-z0-9][a-z0-9._-]{0,119}\.js)$/i.test(path);
        const validInput = entries.every(([path, content]) => (
            typeof path === "string" &&
            path === path.trim() &&
            path.trim() &&
            !path.includes("\0") &&
            safePath(path) &&
            typeof content === "string"
        ));
        const uniquePaths = new Set(entries.map(([path]) => path));
        return {
            files: source,
            manifest: Object.fromEntries(records.map((item) => [item.path, { bytes: item.bytes, hash: item.hash }])),
            revision: revisionOf(source),
            valid: validInput && uniquePaths.size === entries.length && records.every((item) => validate("File", item).valid)
        };
    }

    const api = Object.freeze({ MODEL_VERSION, READINESS_STATES, EVIDENCE_KINDS, ACTORS, hash, revisionOf, project, page, file, brief, finding, deployment, formEvidence, importReport, benchmarkRun, operation, evidence, validate, migrate, transition, invalidateReadiness, compile });
    if (typeof window !== "undefined") window.workspaceDomain = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
