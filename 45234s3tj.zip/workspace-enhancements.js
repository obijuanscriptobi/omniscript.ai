"use strict";

(() => {
    const $ = (id) => document.getElementById(id);
    let lastReport = null;

    function previewHtml() {
        const frame = $("previewContentIframe");
        return frame?.contentDocument?.documentElement?.outerHTML
            || $("outputContainerHtml")?.textContent
            || "";
    }

    function addIssue(list, priority, title, detail) {
        list.push({ priority, title, detail });
    }

    function inspectWebsite() {
        const html = previewHtml();
        const issues = [];
        if (!html || /Awaiting Data Submission/i.test(html)) {
            addIssue(issues, "high", "Create a website first", "Compile or import a website before running the expanded launch review.");
            return issues;
        }

        const parser = new DOMParser();
        const documentNode = parser.parseFromString(html, "text/html");
        const bodyText = documentNode.body?.textContent?.replace(/\s+/g, " ").trim() || "";
        const headings = [...documentNode.querySelectorAll("h1, h2, h3, h4, h5, h6")];
        const h1s = documentNode.querySelectorAll("h1");
        const links = [...documentNode.querySelectorAll("a[href]")];
        const ids = new Set();
        const duplicateIds = new Set();

        documentNode.querySelectorAll("[id]").forEach((element) => {
            const id = element.id;
            if (ids.has(id)) duplicateIds.add(id);
            ids.add(id);
        });

        if (!documentNode.querySelector("meta[name='description']")?.content?.trim()) {
            addIssue(issues, "high", "Add a meta description", "Search engines and social previews need a concise description of the page.");
        }
        const canonical = documentNode.querySelector("link[rel='canonical']")?.getAttribute("href") || "";
        if (!canonical) {
            addIssue(issues, "medium", "Add a canonical URL", "A canonical URL helps prevent duplicate-page indexing after publishing.");
        } else if (!/^(?:https?:\/\/|\.\/|\/)/i.test(canonical)) {
            addIssue(issues, "medium", "Review the canonical URL", "The canonical link should be an absolute HTTPS URL or a valid site-relative path.");
        }
        if (!documentNode.querySelector("meta[property='og:title']") || !documentNode.querySelector("meta[property='og:description']")) {
            addIssue(issues, "low", "Complete social sharing metadata", "Open Graph title and description improve how the page appears when shared.");
        }
        if (!documentNode.querySelector("link[rel='icon'], link[rel='shortcut icon']")) {
            addIssue(issues, "low", "Add a favicon", "A favicon improves recognition in browser tabs and saved bookmarks.");
        }
        const projectFiles = Object.keys(window.workspaceAPI?.getState?.()?.files || {});
        if (!projectFiles.includes("sitemap.xml")) {
            addIssue(issues, "low", "Add a sitemap", "A sitemap helps search engines discover all published pages, especially after adding more than one page.");
        } else {
            const sitemap = window.workspaceAPI?.getState?.()?.files?.["sitemap.xml"] || "";
            if (!/https:\/\/[^<\s]+/i.test(sitemap)) {
                addIssue(issues, "medium", "Set the published website URL", "Enter the final HTTPS website URL in Project settings so sitemap locations, canonical URLs, and structured data use the real published domain.");
            }
        }
        if (documentNode.title.trim().length < 10 || documentNode.title.trim().length > 60) {
            addIssue(issues, "medium", "Review the page title", "Keep the title descriptive and generally between 10 and 60 characters.");
        }
        if (h1s.length !== 1) {
            addIssue(issues, "high", "Use one primary heading", `The page currently has ${h1s.length} H1 headings. Use exactly one clear customer-outcome heading.`);
        }
        headings.slice(1).some((heading, index) => {
            const previous = headings[index]?.tagName?.slice(1) || "1";
            const current = heading.tagName.slice(1);
            if (Number(current) - Number(previous) > 1) {
                addIssue(issues, "medium", "Fix heading order", `Heading levels jump from H${previous} to H${current}. Keep the outline sequential for screen readers.`);
                return true;
            }
            return false;
        });
        if (duplicateIds.size) {
            addIssue(issues, "high", "Remove duplicate IDs", `Duplicate IDs found: ${[...duplicateIds].slice(0, 3).join(", ")}. Duplicate IDs can break labels, anchors, and scripts.`);
        }

        const missingAlt = [...documentNode.images].filter((image) => !image.hasAttribute("alt")).length;
        if (missingAlt) {
            addIssue(issues, "high", "Describe every image", `${missingAlt} image${missingAlt === 1 ? " is" : "s are"} missing alt text.`);
        }
        const emptyLinks = links.filter((link) => !link.textContent.trim() && !link.getAttribute("aria-label")).length;
        if (emptyLinks) {
            addIssue(issues, "high", "Name every link", `${emptyLinks} link${emptyLinks === 1 ? " has" : "s have"} no accessible name.`);
        }
        const localLinks = links.filter((link) => /^(?:\.\/|\.\.\/|[^:/?#]+\.html(?:[?#].*)?$)/i.test(link.getAttribute("href") || ""));
        const pageFiles = new Set(Object.keys(window.workspaceAPI?.getState?.()?.files || {}));
        const missingLocal = localLinks.filter((link) => {
            const href = link.getAttribute("href")?.split(/[?#]/)[0] || "";
            return href && !href.startsWith("#") && pageFiles.size && !pageFiles.has(href.replace(/^\.\//, ""));
        });
        if (missingLocal.length) {
            addIssue(issues, "high", "Fix broken local links", `${missingLocal.length} local link${missingLocal.length === 1 ? " points" : "s point"} to a page that is not in the project.`);
        }
        if (bodyText.length < 180) {
            addIssue(issues, "medium", "Add more useful page content", "The page has very little visible copy. Explain the offer, audience, process, and next step.");
        }
        if (!documentNode.documentElement.getAttribute("lang")?.trim()) {
            addIssue(issues, "high", "Declare the page language", "Add a lang attribute to <html> so screen readers can pronounce content correctly.");
        }
        if (!documentNode.querySelector("meta[name='viewport']")) {
            addIssue(issues, "medium", "Add a responsive viewport", "A viewport declaration prevents mobile browsers from rendering the page at a desktop width.");
        }
        if (!documentNode.querySelector("main")) {
            addIssue(issues, "medium", "Add a main landmark", "A main landmark gives keyboard and assistive-technology users a reliable content starting point.");
        }
        const unlabeledFields = [...documentNode.querySelectorAll("input:not([type='hidden']), textarea, select")].filter((field) => {
            if (field.hasAttribute("aria-label") || field.hasAttribute("aria-labelledby")) return false;
            const id = field.getAttribute("id");
            return !id || !documentNode.querySelector(`label[for="${CSS.escape(id)}"]`);
        });
        if (unlabeledFields.length) {
            addIssue(issues, "high", "Label every form field", `${unlabeledFields.length} form field${unlabeledFields.length === 1 ? " is" : "s are"} missing a connected label or accessible name.`);
        }
        if (!documentNode.querySelector("form") && !documentNode.querySelector("a[href^='tel:'], a[href^='mailto:']")) {
            addIssue(issues, "high", "Connect the visitor to an action", "Add a form, phone link, email link, booking link, or product path.");
        }
        return issues;
    }

    function renderReport() {
        const list = $("diagnostic-details");
        if (!list) return;
        const issues = inspectWebsite();
        lastReport = issues;
        if (!issues.length) {
            list.replaceChildren(Object.assign(document.createElement("li"), {
                textContent: "Expanded review passed: metadata, structure, accessibility basics, links, and conversion paths look ready for the next check."
            }));
            return;
        }
        list.replaceChildren(...issues.slice(0, 12).map((issue) => {
            const item = document.createElement("li");
            item.dataset.priority = issue.priority;
            item.innerHTML = `<strong>${escapeText(issue.title)}</strong><span>${escapeText(issue.detail)}</span>`;
            return item;
        }));
    }

    function escapeText(value) {
        const node = document.createElement("span");
        node.textContent = value;
        return node.innerHTML;
    }

    function showShortcutHelp() {
        const toast = $("workspace-toast");
        if (!toast) return;
        toast.textContent = "Shortcuts: Ctrl/Cmd+S saves, Ctrl/Cmd+Enter creates the website, Ctrl/Cmd+Shift+P previews, ? shows this help.";
        toast.dataset.state = "info";
        toast.hidden = false;
        clearTimeout(showShortcutHelp.timer);
        showShortcutHelp.timer = setTimeout(() => { toast.hidden = true; }, 6000);
    }

    function bind() {
        $("run-quality-check-btn")?.addEventListener("click", () => setTimeout(renderReport, 100));
        $("deployment-preflight-btn")?.addEventListener("click", () => setTimeout(renderReport, 100));
        $("show-shortcuts-btn")?.addEventListener("click", showShortcutHelp);
        $("previewContentIframe")?.addEventListener("load", () => setTimeout(renderReport, 100));
        document.addEventListener("input", () => setTimeout(renderReport, 250), true);
        document.addEventListener("keydown", (event) => {
            if (event.key === "?" && !/input|textarea|select/i.test(event.target?.tagName || "")) {
                event.preventDefault();
                showShortcutHelp();
            }
        });
        window.addEventListener("workspace:deployment-complete", renderReport);
        renderReport();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();

    window.workspaceEnhancements = { inspectWebsite, renderReport, getLastReport: () => lastReport };
})();
