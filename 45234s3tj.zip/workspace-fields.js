"use strict";

// Compatibility adapter for legacy workspace controls and snapshots. New
// website-maker features must read canonical facts from websiteMakerProfileStore;
// keep this module limited to translating existing DOM fields at the boundary.
(() => {
    const FIELD_IDS = Object.freeze([
        "input-biz-name", "input-biz-hook", "input-biz-location", "input-biz-phone", "input-biz-color", "input-biz-secondary-color",
        "input-biz-logo", "input-biz-hero-image", "input-biz-hero-alt", "input-biz-hero-decorative", "input-biz-gallery", "input-biz-gallery-alt", "input-biz-logo-alt", "input-biz-services", "input-biz-email",
        "input-biz-address", "input-biz-audience", "input-biz-approved-claims", "input-biz-forbidden-claims", "input-biz-brand-voice", "input-biz-differentiator", "input-biz-testimonial",
        "input-biz-testimonial-author", "input-biz-credentials", "input-biz-experience", "input-biz-customers", "input-biz-hours",
        "input-biz-pricing", "input-biz-booking", "input-primary-goal", "input-primary-cta", "input-response-time",
        "input-business-type", "input-design-style", "input-content-tone", "input-layout-density", "input-scrape-url",
        "input-form-endpoint", "input-form-success", "input-form-error", "input-form-qualification", "input-form-consent", "input-manual-translations", "input-privacy-retention", "input-privacy-processors", "input-privacy-rights", "input-privacy-analytics", "input-privacy-effective", "input-locale", "input-direction", "input-supported-locales", "input-hosting-provider"
    ]);

    const BUSINESS_KEYS = Object.freeze({
        "input-biz-name": "name", "input-biz-hook": "hook", "input-biz-location": "location", "input-biz-phone": "phone",
        "input-biz-color": "color", "input-biz-secondary-color": "secondaryColor", "input-biz-logo": "logoUrl", "input-biz-hero-image": "heroImageUrl", "input-biz-hero-alt": "heroAlt", "input-biz-hero-decorative": "heroDecorative",
        "input-biz-gallery": "gallery", "input-biz-gallery-alt": "galleryAlt", "input-biz-logo-alt": "logoAlt", "input-biz-services": "services", "input-biz-email": "email",
        "input-biz-address": "address", "input-biz-audience": "audience", "input-biz-approved-claims": "approvedClaims", "input-biz-forbidden-claims": "forbiddenClaims", "input-biz-brand-voice": "brandVoice", "input-biz-differentiator": "differentiator",
        "input-biz-testimonial": "testimonial", "input-biz-testimonial-author": "testimonialAuthor", "input-biz-credentials": "credentials",
        "input-biz-experience": "experience", "input-biz-customers": "customers", "input-biz-hours": "hours", "input-biz-pricing": "pricing",
        "input-biz-booking": "booking", "input-primary-goal": "primaryGoal", "input-primary-cta": "primaryCta", "input-response-time": "responseTime",
        "input-business-type": "businessType", "input-design-style": "designStyle", "input-content-tone": "contentTone", "input-layout-density": "layoutDensity"
    });

    const get = (id) => document.getElementById(id);

    const BUSINESS_DEFAULTS = Object.freeze({
        locale: "en-US",
        direction: "ltr",
        supportedLocales: "en-US",
        color: "#d4af37",
        secondaryColor: "#18202b",
        primaryGoal: "quote",
        businessType: "local-service",
        designStyle: "premium",
        contentTone: "clear",
        layoutDensity: "airy"
    });

    const readText = (id, fallback = "") => get(id)?.value?.trim?.() || fallback;

    function readBusiness(normalizeUrl = (value) => value) {
        const profile = window.websiteMakerProfileStore?.getState?.();
        if (profile) {
            return {
                name: profile.identity.displayName,
                hook: profile.messaging.hook || profile.services[0] || "",
                location: profile.locations[0]?.city || "",
                address: profile.locations[0]?.address || "",
                phone: profile.identity.phoneDisplay,
                phoneDial: profile.identity.phoneDial,
                phoneExtension: profile.identity.phoneExtension,
                email: profile.identity.email,
                services: profile.services.join(", "),
                audience: profile.audience,
                primaryGoal: profile.primaryGoal || BUSINESS_DEFAULTS.primaryGoal,
                primaryCta: profile.messaging.cta,
                responseTime: profile.messaging.responseTime,
                differentiator: profile.differentiator,
                testimonial: profile.proof.testimonial,
                testimonialAuthor: profile.proof.testimonialAuthor,
                credentials: profile.proof.credentials,
                experience: profile.proof.experience,
                customers: profile.proof.customers,
                hours: profile.availability,
                pricing: profile.proof.pricing,
                booking: normalizeUrl(profile.links.booking),
                brandVoice: profile.messaging.voice,
                color: profile.brand.primaryColor,
                secondaryColor: profile.brand.secondaryColor,
                logoUrl: normalizeUrl(profile.brand.logoUrl),
                logoAlt: profile.brand.logoAlt,
                heroImageUrl: normalizeUrl(profile.brand.heroImageUrl),
                heroAlt: profile.brand.heroAlt,
                heroDecorative: profile.brand.heroDecorative,
                gallery: profile.brand.gallery.join(", "),
                galleryAlt: profile.brand.galleryAlt,
                approvedClaims: profile.claimGuidance.approved,
                forbiddenClaims: profile.claimGuidance.forbidden,
                businessType: profile.design.businessType,
                designStyle: profile.design.style,
                contentTone: profile.design.tone,
                layoutDensity: profile.design.density,
                privacy: profile.privacy,
                localization: readLocalizationSettings(),
                hostingProvider: readText("input-hosting-provider", "static-export")
            };
        }
        const business = {};
        Object.entries(BUSINESS_KEYS).forEach(([id, key]) => {
            const field = get(id);
            const value = field?.type === "checkbox" ? field.checked : field?.value;
            business[key] = ["logoUrl", "heroImageUrl", "booking"].includes(key)
                ? normalizeUrl(value || "")
                : String(value || "").trim();
        });
        Object.entries(BUSINESS_DEFAULTS).forEach(([key, fallback]) => {
            if (!business[key]) business[key] = get(`input-${key === "primaryGoal" ? "primary-goal" : `biz-${key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)}`}`)?.value || fallback;
        });
        business.privacy = readPrivacySettings();
        business.localization = readLocalizationSettings();
        business.hostingProvider = readText("input-hosting-provider", "static-export");
        return business;
    }

    function readFormSettings() {
        const profile = window.websiteMakerProfileStore?.getState?.();
        const configured = profile?.form || {};
        const endpoint = String(configured.endpoint || readText("input-form-endpoint", "/api/submit-form")).trim();
        return {
            endpoint: /^\/(?!\/)[^\s<>"']{1,280}$/.test(endpoint) ? endpoint : "/api/submit-form",
            successMessage: configured.successMessage || readText("input-form-success", "Thanks — your request was sent."),
            errorMessage: configured.errorMessage || readText("input-form-error", "The form could not be submitted."),
            qualificationQuestion: configured.qualification || readText("input-form-qualification"),
            requireConsent: configured.requireConsent === true || Boolean(get("input-form-consent")?.checked),
            privacy: profile?.privacy || readPrivacySettings()
        };
    }

    function readLocalizationSettings() {
        const normalizeLocale = (value) => {
            const candidate = String(value || "").trim().replace(/_/g, "-");
            return /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/.test(candidate) ? candidate : "";
        };
        const locale = normalizeLocale(readText("input-locale", "en-US")) || "en-US";
        const direction = ["ltr", "rtl"].includes(readText("input-direction", "ltr")) ? readText("input-direction", "ltr") : "ltr";
        const supportedLocales = [...new Set(readText("input-supported-locales", locale).split(",").map(normalizeLocale).filter(Boolean))].slice(0, 24);
        let manualTranslations = {};
        try {
            const parsed = JSON.parse(readText("input-manual-translations"));
            if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) manualTranslations = parsed;
        } catch {
            manualTranslations = {};
        }
        return { locale, direction, supportedLocales: supportedLocales.length ? supportedLocales : [locale], manualTranslations };
    }

    function readPrivacySettings() {
        const privacy = window.websiteMakerProfileStore?.getState?.().privacy;
        if (privacy) return {
            analytics: ["essential", "anonymous"].includes(privacy.analytics) ? privacy.analytics : "essential",
            retention: privacy.retention || "",
            processors: privacy.processors || "",
            rights: privacy.rightsContact || "",
            effective: privacy.effectiveDate || ""
        };
        return {
            analytics: ["essential", "anonymous"].includes(readText("input-privacy-analytics", "essential")) ? readText("input-privacy-analytics", "essential") : "essential",
            retention: readText("input-privacy-retention", "", 240),
            processors: readText("input-privacy-processors", "", 300),
            rights: readText("input-privacy-rights", "", 240),
            effective: readText("input-privacy-effective", "", 20)
        };
    }

    function getValues(snapshot = {}) {
        const business = snapshot.form?.business || {};
        const settings = snapshot.form?.formSettings || {};
        const privacy = snapshot.form?.privacy || {};
        const localization = snapshot.form?.business?.localization || snapshot.form?.localization || {};
        const values = {
            "input-locale": localization.locale || "en-US",
            "input-direction": localization.direction || "ltr",
            "input-supported-locales": Array.isArray(localization.supportedLocales) ? localization.supportedLocales.join(", ") : localization.supportedLocales || "en-US",
            "input-manual-translations": typeof localization.manualTranslations === "string" ? localization.manualTranslations : JSON.stringify(localization.manualTranslations || {}, null, 2),
            "input-hosting-provider": snapshot.form?.hostingProvider || "static-export",
            "input-scrape-url": snapshot.form?.scrapeUrl || "",
            "input-form-endpoint": settings.endpoint || "/api/submit-form",
            "input-form-success": settings.successMessage || "Thanks — your request was sent.",
            "input-form-error": settings.errorMessage || "The form could not be submitted.",
            "input-form-qualification": settings.qualificationQuestion || "",
            "input-form-consent": Boolean(settings.requireConsent),
            "input-privacy-analytics": privacy.analytics || "essential",
            "input-privacy-retention": privacy.retention || "",
            "input-privacy-processors": privacy.processors || "",
            "input-privacy-rights": privacy.rights || "",
            "input-privacy-effective": privacy.effective || "",
            "input-biz-approved-claims": Array.isArray(business.approvedClaims) ? business.approvedClaims.join("\n") : business.approvedClaims || "",
            "input-biz-forbidden-claims": Array.isArray(business.forbiddenClaims) ? business.forbiddenClaims.join("\n") : business.forbiddenClaims || "",
            "input-biz-hero-alt": business.heroAlt || "",
            "input-biz-hero-decorative": Boolean(business.heroDecorative),
            "input-biz-gallery-alt": Array.isArray(business.galleryAlt) ? business.galleryAlt.join("\n") : business.galleryAlt || "",
            "input-biz-brand-voice": business.brandVoice || ""
        };
        Object.entries(BUSINESS_KEYS).forEach(([id, key]) => { values[id] = business[key] || ""; });
        Object.assign(values, {
            "input-biz-color": business.color || "#d4af37",
            "input-biz-secondary-color": business.secondaryColor || "#18202b",
            "input-primary-goal": business.primaryGoal || "quote",
            "input-business-type": business.businessType || "local-service",
            "input-design-style": business.designStyle || "premium",
            "input-content-tone": business.contentTone || "clear",
            "input-layout-density": business.layoutDensity || "airy",
            "input-biz-approved-claims": Array.isArray(business.approvedClaims) ? business.approvedClaims.join("\n") : business.approvedClaims || "",
            "input-biz-forbidden-claims": Array.isArray(business.forbiddenClaims) ? business.forbiddenClaims.join("\n") : business.forbiddenClaims || "",
            "input-biz-hero-alt": business.heroAlt || "",
            "input-biz-hero-decorative": Boolean(business.heroDecorative),
            "input-biz-gallery-alt": Array.isArray(business.galleryAlt) ? business.galleryAlt.join("\n") : business.galleryAlt || "",
            "input-biz-brand-voice": business.brandVoice || ""
        });
        return values;
    }

    function apply(snapshot = {}) {
        const values = getValues(snapshot);
        FIELD_IDS.forEach((id) => {
            const field = get(id);
            if (!field || values[id] === undefined) return;
            if (id === "input-form-consent" || id === "input-biz-hero-decorative") field.checked = Boolean(values[id]);
            else field.value = values[id];
        });
        const consent = get("input-form-consent");
        if (consent) {
            consent.checked = Boolean(snapshot.form?.formSettings?.requireConsent);
            consent.dispatchEvent(new Event("change", { bubbles: true }));
        }
        const color = get("input-biz-color");
        const secondary = get("input-biz-secondary-color");
        if (get("color-help") && color) get("color-help").textContent = color.value;
        if (get("secondary-color-help") && secondary) get("secondary-color-help").textContent = secondary.value;
        if (get("input-locale") && !get("input-locale").value) get("input-locale").value = "en-US";
        if (get("input-direction") && !get("input-direction").value) get("input-direction").value = "ltr";
    }

    window.workspaceFields = Object.freeze({ FIELD_IDS, BUSINESS_KEYS, getValues, apply, readBusiness, readFormSettings, readPrivacySettings, readLocalizationSettings });
})();
