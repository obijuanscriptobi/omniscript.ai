"use strict";

(() => {
    const PROJECT_ID_KEY = "lux_gen_current_project_id";
    const PROJECT_REVISION_KEY = "lux_gen_current_project_revision";
    const SYNC_CHANNEL = "lux-gen-workspace-sync";
    const AUTOSAVE_DELAY = 1_200;
    const MAX_RETRIES = 3;
    const RETRY_BASE_DELAY = 500;
    const CLIENT_WAIT_MS = 10_000;

    let syncChannel = null;
    let autosaveTimer = null;
    let autosaveInFlight = false;
    let autosaveQueued = false;
    let initialized = false;

    function getWorkspace() {
        return window.workspaceAPI?.getState?.() || null;
    }

    function readStorage(key) {
        try {
            return localStorage.getItem(key) || null;
        } catch {
            return null;
        }
    }

    function writeStorage(key, value) {
        try {
            if (value === null || value === undefined || value === "") {
                localStorage.removeItem(key);
            } else {
                localStorage.setItem(key, String(value));
            }
        } catch {}
    }

    function getWorkspaceProjectId() {
        return getWorkspace()?.projectId || null;
    }

    function readProjectId() {
        return getWorkspaceProjectId() || readStorage(PROJECT_ID_KEY);
    }

    function readRevision() {
        return (
            getWorkspace()?.revision ||
            readStorage(PROJECT_REVISION_KEY) ||
            null
        );
    }

    function setSaveStatus(message, error = false) {
        const element = document.getElementById("workspace-save-status");

        if (!element) return;

        element.textContent = message;
        element.style.color = error ? "#ff8b8b" : "";
        element.setAttribute("aria-invalid", String(error));
    }

    function setProjectStatus(message, error = false) {
        const element = document.getElementById("project-status");

        if (!element) return;

        element.textContent = message;
        element.style.color = error ? "#ff8b8b" : "";
        element.setAttribute("aria-invalid", String(error));
    }

    function setWorkspaceDirty(value) {
        const dirty = Boolean(value);
        document.body.classList.toggle("workspace-dirty", dirty);

        const apply = document.getElementById("apply-source-btn");

        if (apply) {
            apply.disabled = !dirty;
            apply.setAttribute("aria-disabled", String(!dirty));
        }

        if (!dirty) {
            window.workspaceAPI?.markClean?.();
            setSaveStatus("Changes saved to the cloud.");
        }
    }

    function workspaceSignature(workspace = getWorkspace()) {
        if (!workspace) return "";

        return JSON.stringify({
            files: workspace.files || {},
            form: workspace.form || {},
            previewMode: workspace.previewMode || "desktop",
            projectName: workspace.projectName || ""
        });
    }

    function persistProjectId(id, announce = true) {
        const projectId = id || null;

        writeStorage(PROJECT_ID_KEY, projectId);
        window.workspaceAPI?.setProjectId?.(projectId);

        if (announce) {
            broadcast({ type: "project-id", projectId });
        }

        return projectId;
    }

    function persistRevision(revision, announce = true) {
        const value = revision || null;
        writeStorage(PROJECT_REVISION_KEY, value);

        if (announce) {
            broadcast({ type: "revision", revision: value });
        }

        return value;
    }

    function syncProjectId() {
        const projectId = readStorage(PROJECT_ID_KEY);

        if (
            projectId &&
            typeof window.workspaceAPI?.setProjectId === "function" &&
            getWorkspaceProjectId() !== projectId
        ) {
            window.workspaceAPI.setProjectId(projectId);
        }

        return projectId || getWorkspaceProjectId();
    }

    function broadcast(message) {
        try {
            syncChannel?.postMessage({
                ...message,
                source: "workspace-fixes",
                timestamp: Date.now()
            });
        } catch {}
    }

    function handleRemoteMessage(message) {
        if (!message || message.source !== "workspace-fixes") return;

        if (message.type === "project-id") {
            const remoteId = message.projectId || null;

            if (remoteId !== getWorkspaceProjectId()) {
                writeStorage(PROJECT_ID_KEY, remoteId);
                window.workspaceAPI?.clearProjectContext?.({ persist: false, announce: true });
                window.workspaceAPI?.setProjectId?.(remoteId);

                window.dispatchEvent(
                    new CustomEvent("workspace:project-id-change", {
                        detail: { projectId: remoteId }
                    })
                );
            }
        }

        if (message.type === "revision") {
            const remoteRevision = message.revision || null;

            if (remoteRevision !== readRevision()) {
                writeStorage(PROJECT_REVISION_KEY, remoteRevision);

                window.dispatchEvent(
                    new CustomEvent("workspace:remote-update", {
                        detail: { revision: remoteRevision }
                    })
                );
            }
        }
    }

    function setupCrossTabSync() {
        if ("BroadcastChannel" in window && !syncChannel) {
            syncChannel = new BroadcastChannel(SYNC_CHANNEL);
            syncChannel.addEventListener("message", (event) => {
                handleRemoteMessage(event.data);
            });
        }

        window.addEventListener("storage", (event) => {
            if (event.key === PROJECT_ID_KEY) {
                handleRemoteMessage({
                    type: "project-id",
                    projectId: event.newValue || null,
                    source: "workspace-fixes"
                });
            }

            if (event.key === PROJECT_REVISION_KEY) {
                handleRemoteMessage({
                    type: "revision",
                    revision: event.newValue || null,
                    source: "workspace-fixes"
                });
            }
        });
    }

    function wait(milliseconds) {
        return new Promise((resolve) => setTimeout(resolve, milliseconds));
    }

    function isAuthenticated() {
        // Prefer the in-memory auth state. Tokens are intentionally not read
        // from Web Storage because that would expose them to XSS payloads.
        if (window.supabaseWorkspace?.getState?.().authenticated) return true;
        return false;
    }

    async function waitForCloudClient() {
        const startedAt = Date.now();

        while (
            !window.supabaseWorkspace?.saveProject &&
            Date.now() - startedAt < CLIENT_WAIT_MS
        ) {
            await wait(250);
        }

        return window.supabaseWorkspace?.saveProject
            ? window.supabaseWorkspace
            : null;
    }

    function isConflict(error) {
        return (
            error?.code === "PROJECT_CONFLICT" ||
            error?.status === 409 ||
            String(error?.message || "")
                .toLowerCase()
                .includes("conflict")
        );
    }

    function isRetryable(error) {
        if (isConflict(error)) return false;

        const message = String(error?.message || "").toLowerCase();

        return ![
            "sign in",
            "permission",
            "unauthorized",
            "forbidden",
            "invalid",
            "authentication",
            "project not found"
        ].some((term) => message.includes(term));
    }

    async function retry(task, retries = MAX_RETRIES) {
        let lastError;

        for (let attempt = 0; attempt <= retries; attempt += 1) {
            try {
                return await task(attempt);
            } catch (error) {
                lastError = error;

                if (attempt === retries || !isRetryable(error)) {
                    throw error;
                }

                await wait(RETRY_BASE_DELAY * 2 ** attempt);
            }
        }

        throw lastError;
    }

    function extractSaveResult(result, fallbackId) {
        const project = result?.project || result?.data?.project || {};

        return {
            id: project.id || result?.projectId || fallbackId || null,
            revision:
                project.updated_at ||
                project.revision ||
                result?.revision ||
                result?.updated_at ||
                null
        };
    }

    function getProjectName(workspace) {
        return (
            workspace?.projectName ||
            document.getElementById("project-name-input")?.value ||
            document.getElementById("input-biz-name")?.value ||
            "Untitled project"
        )
            .toString()
            .trim()
            .slice(0, 200);
    }

    function showConflictDialog(error) {
        const cloudProject = error?.project;

        if (!cloudProject) {
            setSaveStatus(
                "Cloud conflict detected. Keep your local changes and reload before saving again.",
                true
            );
            return;
        }

        const useCloud = window.confirm(
            "This project was changed elsewhere.\n\n" +
                "Choose OK to load the cloud version, or Cancel to keep your local changes."
        );

        if (useCloud) {
            window.workspaceAPI?.applySnapshot?.({
                files: cloudProject.files || {},
                form: cloudProject.form_data || cloudProject.formData || {},
                previewMode:
                    cloudProject.preview_mode ||
                    cloudProject.previewMode ||
                    "desktop",
                projectName: cloudProject.name || "",
                projectId: cloudProject.id || null
            });

            persistProjectId(cloudProject.id || null);
            persistRevision(
                cloudProject.updated_at || cloudProject.revision || null
            );
            setWorkspaceDirty(false);
            setProjectStatus("Cloud version loaded.");
            setSaveStatus("Cloud version loaded.");
            return;
        }

        setWorkspaceDirty(true);
        setSaveStatus(
            "Conflict detected. Your local changes were preserved.",
            true
        );
        setProjectStatus(
            "Cloud conflict: local changes were preserved.",
            true
        );
    }

    async function saveToCloud() {
        if (autosaveInFlight) {
            autosaveQueued = true;
            return { success: false, queued: true };
        }

        if (!isAuthenticated()) {
            return {
                success: false,
                skipped: true,
                error: "Cloud autosave requires sign-in."
            };
        }

        const api = await waitForCloudClient();
        const workspace = getWorkspace();

        if (!api || !workspace) {
            setSaveStatus(
                "Local changes saved. Cloud storage is unavailable.",
                true
            );

            return {
                success: false,
                skipped: true,
                error: "Cloud autosave is unavailable."
            };
        }

        autosaveInFlight = true;
        const projectId = syncProjectId();
        const saveSignature = workspaceSignature(workspace);

        setSaveStatus("Saving changes to the cloud…");
        setProjectStatus("Autosaving project to the cloud…");

        try {
            const result = await retry(() =>
                api.saveProject({
                    id: projectId || undefined,
                    name: getProjectName(workspace)
                })
            );

            const saved = extractSaveResult(result, projectId);

            if (saved.id) persistProjectId(saved.id);
            if (saved.revision) persistRevision(saved.revision);

            const hasNewerEdits =
                workspaceSignature(getWorkspace()) !== saveSignature;

            if (hasNewerEdits) {
                setSaveStatus("Newer edits are waiting to be saved.");
                scheduleCloudSave();
            } else {
                setWorkspaceDirty(false);
                setSaveStatus("Changes saved to the cloud.");
                setProjectStatus("Project autosaved to the cloud.");
            }

            window.dispatchEvent(
                new CustomEvent("workspace:cloud-save", {
                    detail: {
                        projectId: saved.id,
                        revision: saved.revision,
                        hasNewerEdits
                    }
                })
            );

            return {
                success: true,
                projectId: saved.id,
                revision: saved.revision,
                hasNewerEdits,
                result
            };
        } catch (error) {
            const message = error?.message || "Cloud autosave failed.";

            if (isConflict(error)) {
                showConflictDialog(error);
            } else {
                setSaveStatus(
                    "Cloud save failed. Your local copy is preserved.",
                    true
                );
                setProjectStatus(message, true);
            }

            window.dispatchEvent(
                new CustomEvent("workspace:cloud-save-error", {
                    detail: {
                        projectId,
                        code: error?.code || null,
                        error: message
                    }
                })
            );

            return {
                success: false,
                projectId,
                code: error?.code || null,
                error: message
            };
        } finally {
            autosaveInFlight = false;

            if (autosaveQueued) {
                autosaveQueued = false;
                scheduleCloudSave();
            }
        }
    }

    function scheduleCloudSave() {
        clearTimeout(autosaveTimer);

        if (!isAuthenticated()) return;

        autosaveTimer = setTimeout(() => {
            autosaveTimer = null;
            void saveToCloud();
        }, AUTOSAVE_DELAY);
    }

    function isWorkspaceInput(target) {
        if (!target?.matches) return false;

        // Keep autosave aligned with every editor control, including fields added
        // to the advanced tools, without treating generated file previews as form input.
        return target.matches([
            "textarea[data-file]",
            "[contenteditable='true'][data-file]",
            "#project-name-input",
            "#published-site-url-input",
            "#input-scrape-url",
            "#input-biz-name",
            "#input-biz-hook",
            "#input-biz-location",
            "#input-biz-phone",
            "#input-biz-color",
            "#input-biz-secondary-color",
            "#input-biz-services",
            "[id^='input-']",
            "#project-selector",
            "#project-version-selector",
            "#page-selector",
            "#page-template-selector"
        ].join(","));
    }

    function setupAutosaveListeners() {
        document.addEventListener(
            "input",
            (event) => {
                if (isWorkspaceInput(event.target)) {
                    scheduleCloudSave();
                }
            },
            true
        );

        document.addEventListener(
            "change",
            (event) => {
                if (isWorkspaceInput(event.target)) {
                    scheduleCloudSave();
                }
            },
            true
        );

        document.addEventListener(
            "click",
            (event) => {
                const button = event.target.closest?.("button");

                if (!button) return;

                if (
                    [
                        "compile-pipeline-btn",
                        "apply-source-btn",
                        "toggle-desktop-view",
                        "toggle-tablet-view",
                        "toggle-mobile-view"
                    ].includes(button.id)
                ) {
                    scheduleCloudSave();
                }
            },
            true
        );
    }

    function markWorkspaceChanged() {
        window.workspaceAPI?.markDirty?.();
        scheduleCloudSave();
        return getWorkspace();
    }

    function saveLocalBackup() {
        return getWorkspace();
    }

    function clearProjectId() {
        clearTimeout(autosaveTimer);
        autosaveTimer = null;
        autosaveQueued = false;
        persistProjectId(null);
        persistRevision(null);
    }

    function initialize() {
        if (initialized) return;

        initialized = true;
        syncProjectId();
        setupCrossTabSync();
        setupAutosaveListeners();

        window.addEventListener("supabase:authenticated", scheduleCloudSave);
        window.addEventListener("supabase:unauthenticated", () => {
            clearTimeout(autosaveTimer);
            autosaveTimer = null;
        });
    }

    initialize();

    window.workspaceFixes = {
        getWorkspace,
        saveLocalBackup,
        saveToCloud,
        scheduleCloudSave,
        markWorkspaceChanged,
        readProjectId,
        persistProjectId,
        syncProjectId,
        readRevision,
        persistRevision,
        clearProjectId
    };

    window.addEventListener("pagehide", () => {
        clearTimeout(autosaveTimer);
        autosaveTimer = null;
        syncChannel?.close();
        syncChannel = null;
    });
})();