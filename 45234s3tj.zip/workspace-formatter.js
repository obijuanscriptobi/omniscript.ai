"use strict";

// Deterministic, dependency-free formatting for generated project files.
// It deliberately avoids semantic rewrites: formatting must never change behavior.
(() => {
    const indentUnit = "    ";
    const unique = (items) => [...new Set(items)];

    function normalizeNewlines(value) {
        return String(value ?? "")
            .replace(/\r\n?/g, "\n")
            .replace(/[ \t]+\n/g, "\n")
            .trim();
    }

    function formatHtml(source) {
        let html = normalizeNewlines(source);
        if (!html) return "";

        const protectedParts = [];
        html = html.replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi, (block) => {
            const token = `___WORKSPACE_BLOCK_${protectedParts.length}___`;
            protectedParts.push(block);
            return token;
        });

        html = html
            .replace(/>\s*</g, "><")
            .replace(/<!--[\s\S]*?-->/g, (comment) => `\n${comment}\n`)
            .replace(/></g, ">\n<");

        const lines = [];
        let depth = 0;
        const voidTags = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)\b/i;
        const closing = /^<\//;
        const opening = /^<([a-z][\w:-]*)\b/i;
        const inlineOnly = /^(a|abbr|b|cite|code|em|i|label|small|span|strong|sub|sup|time)\b/i;

        html.split("\n").map((line) => line.trim()).filter(Boolean).forEach((line) => {
            if (closing.test(line)) depth = Math.max(0, depth - 1);
            lines.push(`${indentUnit.repeat(depth)}${line}`);
            const match = line.match(opening);
            if (match && !closing.test(line) && !line.startsWith("<!") && !line.startsWith("<?") && !voidTags.test(match[1]) && !/\/\s*>$/.test(line)) {
                // Keep short inline elements readable without creating noisy one-line gaps.
                if (!inlineOnly.test(match[1]) || /<\/[a-z][\w:-]*>$/i.test(line)) depth += 1;
            }
        });

        html = lines.join("\n");
        protectedParts.forEach((block, index) => {
            const token = `___WORKSPACE_BLOCK_${index}___`;
            const formatted = /^<style\b/i.test(block)
                ? formatCssBlock(block)
                : formatScriptBlock(block);
            html = html.replace(new RegExp(`\\s*${token}\\s*`), `\n${formatted}\n`);
        });
        return html.replace(/\n{3,}/g, "\n\n").trim() + "\n";
    }

    function splitCssDeclarations(body) {
        const declarations = [];
        let current = "";
        let quote = "";
        let parens = 0;
        for (const char of body) {
            if (quote) {
                current += char;
                if (char === quote && current.at(-2) !== "\\") quote = "";
            } else if (char === '"' || char === "'") {
                quote = char;
                current += char;
            } else if (char === "(") {
                parens += 1;
                current += char;
            } else if (char === ")") {
                parens = Math.max(0, parens - 1);
                current += char;
            } else if (char === ";" && parens === 0) {
                if (current.trim()) declarations.push(current.trim());
                current = "";
            } else {
                current += char;
            }
        }
        if (current.trim()) declarations.push(current.trim());
        return declarations;
    }

    function formatCssBlock(block) {
        const match = block.match(/^(<style\b[^>]*>)([\s\S]*?)(<\/style>)$/i);
        if (!match) return formatCss(block);
        return `${match[1]}\n${formatCss(match[2]).replace(/^/gm, indentUnit)}${match[3]}`;
    }

    function formatCss(source) {
        const css = normalizeNewlines(source);
        if (!css) return "";

        const output = [];
        let token = "";
        let depth = 0;
        let quote = "";
        let comment = false;
        let parens = 0;
        const emit = (value) => {
            const clean = value.replace(/\s+/g, " ").trim();
            if (clean) output.push(`${indentUnit.repeat(depth)}${clean}`);
        };

        for (let index = 0; index < css.length; index += 1) {
            const char = css[index];
            const next = css[index + 1];
            if (comment) {
                token += char;
                if (char === "*" && next === "/") {
                    token += "/";
                    index += 1;
                    comment = false;
                }
                continue;
            }
            if (!quote && char === "/" && next === "*") {
                if (token.trim()) { emit(token); token = ""; }
                token = "/*";
                index += 1;
                comment = true;
                continue;
            }
            if (quote) {
                token += char;
                if (char === quote && css[index - 1] !== "\\") quote = "";
                continue;
            }
            if (char === '"' || char === "'") {
                quote = char;
                token += char;
            } else if (char === "(") {
                parens += 1;
                token += char;
            } else if (char === ")") {
                parens = Math.max(0, parens - 1);
                token += char;
            } else if (parens === 0 && char === "{") {
                emit(`${token} {`);
                token = "";
                depth += 1;
            } else if (parens === 0 && char === "}") {
                emit(token);
                token = "";
                depth = Math.max(0, depth - 1);
                output.push(`${indentUnit.repeat(depth)}}`);
            } else if (parens === 0 && char === ";") {
                emit(`${token};`);
                token = "";
            } else if (char === "\n" && !token.trim()) {
                continue;
            } else {
                token += char;
            }
        }
        emit(token);

        // Remove exact duplicate declarations within a single formatted block,
        // while preserving later overrides with different values.
        const expanded = [];
        output.forEach((line) => {
            const declarations = line.trim().includes(":") && line.includes(";")
                ? splitCssDeclarations(line.trim()).map((declaration) => `${declaration};`)
                : [line];
            declarations.forEach((declaration) => {
                const value = declaration.trim();
                if (!value) return;
                expanded.push(`${line.slice(0, line.length - line.trimStart().length)}${value}`);
            });
        });
        const deduped = [];
        for (const line of expanded) {
            if (line.endsWith(";") && deduped.at(-1) === line) continue;
            deduped.push(line);
        }
        return deduped.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
    }

    function formatScriptBlock(block) {
        const match = block.match(/^(<script\b[^>]*>)([\s\S]*?)(<\/script>)$/i);
        if (!match) return formatJavaScript(block);
        return `${match[1]}\n${formatJavaScript(match[2]).replace(/^/gm, indentUnit)}${match[3]}`;
    }

    function formatJavaScript(source) {
        const input = normalizeNewlines(source);
        if (!input) return "";
        // Indent only structural braces outside quoted strings and comments.
        // This is intentionally conservative and does not re-tokenize JavaScript.
        const lines = [];
        let line = "";
        let depth = 0;
        let quote = "";
        let comment = false;
        for (let index = 0; index < input.length; index += 1) {
            const char = input[index];
            const next = input[index + 1];
            if (comment) {
                line += char;
                if (char === "\n") {
                    lines.push(`${indentUnit.repeat(depth)}${line.trim()}`);
                    line = "";
                    comment = false;
                }
                continue;
            }
            if (!quote && char === "/" && next === "/") {
                comment = true;
                line += char;
                continue;
            }
            if (quote) {
                line += char;
                if (char === quote && input[index - 1] !== "\\") quote = "";
                continue;
            }
            if (char === '"' || char === "'" || char === "`") {
                quote = char;
                line += char;
            } else if (char === "{") {
                line = line.trimEnd();
                lines.push(`${indentUnit.repeat(depth)}${line} {`);
                line = "";
                depth += 1;
            } else if (char === "}") {
                if (line.trim()) lines.push(`${indentUnit.repeat(depth)}${line.trim()}`);
                line = "";
                depth = Math.max(0, depth - 1);
                lines.push(`${indentUnit.repeat(depth)}}`);
            } else if (char === ";") {
                line += char;
                lines.push(`${indentUnit.repeat(depth)}${line.trim()}`);
                line = "";
            } else if (char === "\n") {
                if (line.trim()) lines.push(`${indentUnit.repeat(depth)}${line.trim()}`);
                line = "";
            } else {
                line += char;
            }
        }
        if (line.trim()) lines.push(`${indentUnit.repeat(depth)}${line.trim()}`);
        return lines.join("\n").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
    }

    function formatToml(source) {
        return `${normalizeNewlines(source).split("\n").map((line) => line.trimEnd()).filter((line, index, all) => line || all[index - 1]).join("\n").trim()}\n`;
    }

    function formatXml(source) {
        return `${normalizeNewlines(source).replace(/>\s*</g, "><").replace(/></g, ">\n<").split("\n").map((line) => line.trim()).filter(Boolean).join("\n")}\n`;
    }

    function formatFile(filename, content) {
        const value = String(content ?? "");
        if (/\.html?$/i.test(filename)) return formatHtml(value);
        if (/\.css$/i.test(filename)) return formatCss(value);
        if (/\.js$/i.test(filename)) return formatJavaScript(value);
        if (/\.toml$/i.test(filename)) return formatToml(value);
        if (/\.xml$/i.test(filename)) return formatXml(value);
        return normalizeNewlines(value) + (value.trim() ? "\n" : "");
    }

    function formatProjectFiles(files = {}) {
        return Object.fromEntries(Object.entries(files || {}).map(([filename, content]) => [filename, formatFile(filename, content)]));
    }

    window.workspaceFormatter = Object.freeze({ formatFile, formatProjectFiles, formatHtml, formatCss, formatJavaScript, formatToml });
})();
