"use strict";

// Stable generator boundary. generated-quality.js owns the canonical project
// generator; this facade gives the editor a small, testable API without exposing
// generator implementation details to the coordinator.
(() => {
    const clone = (value) => {
        if (typeof structuredClone === "function") return structuredClone(value);
        return JSON.parse(JSON.stringify(value));
    };

    const deepFreeze = (value) => {
        if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
        Object.values(value).forEach(deepFreeze);
        return Object.freeze(value);
    };

    function businessFromProfile(profile) {
        if (!profile) return null;
        return {
            name: profile.identity?.displayName || "",
            hook: profile.messaging?.hook || profile.services?.[0] || "",
            location: profile.locations?.[0]?.city || "",
            address: profile.locations?.[0]?.address || "",
            phone: profile.identity?.phoneDisplay || "",
            phoneDial: profile.identity?.phoneDial || "",
            phoneExtension: profile.identity?.phoneExtension || "",
            email: profile.identity?.email || "",
            services: (profile.services || []).join(", "),
            audience: profile.audience || "",
            primaryGoal: profile.primaryGoal || "quote",
            primaryCta: profile.messaging?.cta || "",
            responseTime: profile.messaging?.responseTime || "",
            differentiator: profile.differentiator || "",
            testimonial: profile.proof?.testimonial || "",
            testimonialAuthor: profile.proof?.testimonialAuthor || "",
            credentials: profile.proof?.credentials || "",
            experience: profile.proof?.experience || "",
            customers: profile.proof?.customers || "",
            hours: profile.availability || "",
            pricing: profile.proof?.pricing || "",
            booking: profile.links?.booking || "",
            brandVoice: profile.messaging?.voice || "",
            color: profile.brand?.primaryColor || "#d4af37",
            secondaryColor: profile.brand?.secondaryColor || "#18202b",
            logoUrl: profile.brand?.logoUrl || "",
            logoAlt: profile.brand?.logoAlt || "",
            heroImageUrl: profile.brand?.heroImageUrl || "",
            heroAlt: profile.brand?.heroAlt || "",
            heroDecorative: Boolean(profile.brand?.heroDecorative),
            gallery: (profile.brand?.gallery || []).join(", "),
            galleryAlt: profile.brand?.galleryAlt || [],
            approvedClaims: profile.claimGuidance?.approved || [],
            forbiddenClaims: profile.claimGuidance?.forbidden || [],
            businessType: profile.design?.businessType || "local-service",
            designStyle: profile.design?.style || "premium",
            contentTone: profile.design?.tone || "clear",
            layoutDensity: profile.design?.density || "airy",
            privacy: clone(profile.privacy || {}),
            form: clone(profile.form || {})
        };
    }

    function canonicalOptions(options = {}) {
        const source = options.profile || window.websiteMakerProfileStore?.getState?.();
        if (!source) return options;
        const profile = deepFreeze(clone(source));
        return { ...options, profile, business: businessFromProfile(profile) };
    }

    function assertPublishable(files = null) {
        const source = files || window.workspaceAPI?.getState?.()?.files || {};
        return Promise.resolve(validateProject(source));
    }

    function createProject(options = {}) {
        const generator = window.siteGenerator;
        if (!generator || typeof generator.createProject !== "function") {
            throw new Error("The canonical site generator is unavailable.");
        }
        const canonical = canonicalOptions(options);
        const preparedBase = window.workspaceDesignSystems?.prepareBrief?.(canonical) || canonical;
        const startedAt = typeof performance !== "undefined" && performance.now ? performance.now() : Date.now();
        const components = window.workspaceComponents;
        const facts = components?.normalizeFacts?.(preparedBase);
        const projectId = preparedBase.projectId || preparedBase.business?.id || preparedBase.business?.name || "project";
        const controls = window.workspaceRegeneration?.normalizeControls?.(options.regeneration || {}) || null;
        const originality = components && window.workspaceOriginality?.select && window.workspaceDesignGenome
            ? window.workspaceOriginality.select(preparedBase, (design) => components.defaultPlan(facts, design), {
                components,
                recent: Array.isArray(options.recentFingerprints) ? options.recentFingerprints : undefined,
                threshold: options.originalityThreshold,
                maxAttempts: options.maxOriginalityAttempts,
                lockDimensions: controls ? window.workspaceRegeneration.lockDimensions(controls) : []
            })
            : null;
        if (originality && !originality.accepted) {
            const error = new Error("No sufficiently distinct design was found within the safe retry limit.");
            error.code = "ORIGINALITY_THRESHOLD_NOT_MET";
            error.diagnostics = { threshold: originality.threshold, attempts: originality.attempts, nearest: originality.nearest, reselections: originality.reselections };
            throw error;
        }
        const prepared = originality ? { ...preparedBase, variationId: originality.variationId, design: originality.design } : preparedBase;
        let plan = originality?.plan || components?.defaultPlan?.(facts, prepared.design || {});
        if (controls && options.previousPlan && plan) plan = window.workspaceRegeneration.mergePlan(options.previousPlan, plan, controls, components);
        if (plan && components?.sanitizePlan) plan = components.sanitizePlan(plan, { facts });
        const assembledFiles = components?.assembleProject && plan
            ? components.assembleProject(plan, facts, prepared.design || {})
            : generator.createProject(prepared.business || prepared);
        const repaired = window.workspaceDeterministicRepair?.repair?.(assembledFiles) || { files: assembledFiles, audit: [] };
        const files = repaired.files;
        window.workspaceRepairAudit = repaired.audit;
        window.workspaceClaimProvenance = components?.claimProvenance?.(plan, facts) || [];
        window.workspaceOriginalityReport = originality ? {
            variationId: originality.variationId,
            fingerprint: originality.fingerprint,
            nearest: originality.nearest,
            attempts: originality.attempts,
            accepted: originality.accepted,
            capped: originality.capped,
            reselections: originality.reselections
        } : null;
        if (originality) window.workspaceOriginality?.record?.(projectId, { variationId: originality.variationId, fingerprint: originality.fingerprint });
        const checkpoint = plan && window.workspaceRegeneration?.checkpoint?.(projectId, {
            variationId: prepared.variationId,
            label: controls ? `Regenerated ${controls.mode}` : "Generated variant",
            plan,
            design: prepared.design,
            files,
            diagnostics: { originality: window.workspaceOriginalityReport, repairs: repaired.audit.length }
        });
        if (typeof window.dispatchEvent === "function" && typeof CustomEvent === "function") {
            window.dispatchEvent(new CustomEvent("workspace:generation-evidence", { detail: {
                repairAudit: window.workspaceRepairAudit,
                provenance: window.workspaceClaimProvenance,
                missingFacts: facts?.missing || [],
                originality: window.workspaceOriginalityReport,
                checkpoint
            } }));
        }
        window.workspaceProjectContract?.validateFiles?.(files);
        const safetyIssues = window.workspaceContentSafety?.validateFiles?.(files) || [];
        if (safetyIssues.length) throw new Error(`Generated project failed content safety validation: ${safetyIssues[0].message}`);
        const finishedAt = typeof performance !== "undefined" && performance.now ? performance.now() : Date.now();
        const compiled = window.workspaceDomain?.compile?.(files);
        if (compiled && !compiled.valid) throw new Error("Generated project failed canonical file validation.");
        const validationIssues = window.workspaceValidation?.validateGeneratedProject?.(files, { strict: true }) || [];
        if (validationIssues.length) throw new Error(`Generated project failed strict quality validation: ${validationIssues[0]}`);
        const audit = window.workspaceAudit?.auditProject?.(files) || null;
        if (audit?.blocking?.length) {
            const first = audit.blocking[0];
            throw new Error(`Generated project failed compiler audit: ${first.code} — ${first.message}`);
        }
        window.workspaceBenchmarkTiming = {
            generationMs: Math.max(0, Math.round(finishedAt - startedAt)),
            recordedAt: new Date().toISOString(),
            revision: compiled?.revision || "",
            manifest: compiled?.manifest || {},
            variationId: prepared.variationId || "",
            designFingerprint: originality?.fingerprint?.hash || prepared.design?.designFingerprint || "",
            originality: window.workspaceOriginalityReport
        };
        if (typeof window.dispatchEvent === "function" && typeof CustomEvent === "function") {
            window.dispatchEvent(new CustomEvent("workspace:generation-complete", { detail: window.workspaceBenchmarkTiming }));
        }
        return window.workspaceFormatter?.formatProjectFiles
            ? window.workspaceFormatter.formatProjectFiles(files)
            : files;
    }

    function validateProject(files = {}) {
        const safetyIssues = window.workspaceContentSafety?.validateFiles?.(files) || [];
        const compiled = window.workspaceDomain?.compile?.(files);
        const strictIssues = window.workspaceValidation?.validateGeneratedProject?.(files, { strict: true }) || [];
        const audit = window.workspaceAudit?.auditProject?.(files) || { blocking: [], warnings: [], issues: [] };
        return {
            valid: Boolean(!safetyIssues.length && compiled?.valid === true && audit.blocking.length === 0 && strictIssues.length === 0),
            revision: compiled?.revision || "",
            manifest: compiled?.manifest || {},
            issues: [
                ...safetyIssues.map((item) => item.message),
                ...(audit.issues || [])
            ],
            limitations: ["Static source validation is not rendered browser coverage."]
        };
    }

    async function createAIProject(options = {}, requestOptions = {}) {
        const canonical = canonicalOptions(options);
        if (!window.workspaceAI?.generate) {
            if (requestOptions.fallback === false) throw new Error("AI website generation is unavailable.");
            return { success: true, provider: "deterministic", files: createProject(canonical), repairPasses: 0, diagnostics: [] };
        }
        return window.workspaceAI.generate(canonical, requestOptions);
    }

    async function repairAIProject(files = {}, diagnostics = [], options = {}, requestOptions = {}) {
        const canonical = canonicalOptions(options);
        const fallback = (error = null) => {
            if (requestOptions.fallback === false) throw error || new Error("AI website repair is unavailable.");
            const repaired = window.workspaceDeterministicRepair?.repair?.(clone(files));
            if (!repaired?.files) throw error || new Error("No website repair service is available.");
            return {
                success: true,
                provider: "deterministic",
                files: repaired.files,
                repairPasses: 1,
                diagnostics: repaired.audit || [],
                fallbackReason: error?.message || "AI website repair is unavailable."
            };
        };
        if (!window.workspaceAI?.repair) return fallback();
        try {
            return await window.workspaceAI.repair(clone(files), clone(diagnostics), canonical, requestOptions);
        } catch (error) {
            return fallback(error);
        }
    }

    function regenerateProject(options = {}, controls = {}) {
        const normalized = window.workspaceRegeneration?.normalizeControls?.(controls);
        if (!normalized) throw new Error("Focused regeneration is unavailable.");
        return createProject({
            ...options,
            previousPlan: options.previousPlan,
            regeneration: normalized,
            variationId: undefined
        });
    }

    function generationHistory(projectId) {
        return window.workspaceRegeneration?.read?.(projectId) || { cursor: -1, checkpoints: [] };
    }

    function undoGeneration(projectId) { return window.workspaceRegeneration?.undo?.(projectId) || null; }
    function redoGeneration(projectId) { return window.workspaceRegeneration?.redo?.(projectId) || null; }
    function compareGenerations(projectId, ids = []) { return window.workspaceRegeneration?.compare?.(projectId, ids) || []; }
    function recordVisualFingerprint(projectId, variationId, imageData, threshold) { return window.workspaceOriginality?.assessRendered?.(projectId, variationId, imageData, threshold) || null; }

    async function critiqueAIProject(files = {}, visualEvidence = {}, options = {}, requestOptions = {}) {
        if (!window.workspaceAI?.critique) throw new Error("AI visual critique is unavailable.");
        return window.workspaceAI.critique(files, visualEvidence, options, requestOptions);
    }

    function designAudit(options = {}) {
        const generator = window.siteGenerator;
        if (!generator || typeof generator.designAudit !== "function") {
            throw new Error("The design intelligence audit is unavailable.");
        }
        return generator.designAudit(options);
    }

    function isAvailable() {
        return Boolean(window.siteGenerator && typeof window.siteGenerator.createProject === "function");
    }

    // Plans and assembled output cross separate validation boundaries.
    function validateModelManifest(raw, options = {}) {
        const contract = window.workspaceProjectContract;
        if (!contract?.parseManifest) throw new Error("The project output contract is unavailable.");
        const files = contract.parseManifest(raw, options);
        return { files: Object.entries(files).map(([path, content]) => ({ path, content })) };
    }

    function createModelRequest(data = {}) {
        const contract = window.workspacePlannerContract;
        if (!contract?.createRequest) throw new Error("The planner contract is unavailable.");
        return contract.createRequest(data);
    }

    function manifestToFiles(raw, options = {}) {
        const manifest = validateModelManifest(raw, options);
        const files = Object.fromEntries(manifest.files.map(({ path, content }) => [path, content]));
        const safetyIssues = window.workspaceContentSafety?.validateFiles?.(files, { imported: Boolean(options.imported) }) || [];
        if (safetyIssues.length) throw new Error(`Project manifest failed content safety validation: ${safetyIssues[0].message}`);
        return window.workspaceFormatter?.formatProjectFiles
            ? window.workspaceFormatter.formatProjectFiles(files)
            : files;
    }

    window.workspaceGenerator = Object.freeze({
        createProject,
        createAIProject,
        repairAIProject,
        regenerateProject,
        generationHistory,
        undoGeneration,
        redoGeneration,
        compareGenerations,
        recordVisualFingerprint,
        critiqueAIProject,
        designAudit,
        assertPublishable,
        validateProject,
        businessFromProfile,
        isAvailable,
        validateModelManifest,
        createModelRequest,
        manifestToFiles
    });
})();
