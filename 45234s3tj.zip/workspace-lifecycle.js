"use strict";

const STATES = Object.freeze(["brief", "draft", "reviewed", "approved", "preflight-passed", "published", "verified"]);
const EDITING_INVALIDATES = new Set(["approved", "preflight-passed", "published", "verified"]);

function normalizeLifecycle(value) {
    return STATES.includes(value) ? value : "draft";
}

function transition(current, next, context = {}) {
    const from = normalizeLifecycle(current);
    const to = normalizeLifecycle(next);
    if (from === to) return { ok: true, state: from };
    const allowed = STATES.indexOf(to) <= STATES.indexOf(from) + 1 || (to === "draft" && EDITING_INVALIDATES.has(from));
    if (!allowed) return { ok: false, code: "INVALID_LIFECYCLE_TRANSITION", state: from, error: `Cannot move a project directly from ${from} to ${to}.` };
    if (to === "preflight-passed" && context.preflightRevision !== context.revision) return { ok: false, code: "PREFLIGHT_REVISION_MISMATCH", state: from, error: "Preflight must pass for the current revision." };
    if (to === "published" && (context.approvalRequired !== false && context.approvedRevision !== context.revision || context.preflightRevision !== context.revision)) return { ok: false, code: "PUBLISH_GATE_BLOCKED", state: from, error: "Publishing requires current approval and current-revision preflight." };
    if (to === "verified" && context.verifiedRevision !== context.revision) return { ok: false, code: "VERIFICATION_REVISION_MISMATCH", state: from, error: "Verification must match the published revision." };
    return { ok: true, state: to };
}

function afterEdit(project = {}) {
    const state = normalizeLifecycle(project.lifecycle || project.status);
    return { ...project, lifecycle: EDITING_INVALIDATES.has(state) ? "draft" : state, approvalRevision: EDITING_INVALIDATES.has(state) ? null : project.approvalRevision, preflightRevision: EDITING_INVALIDATES.has(state) ? null : project.preflightRevision, verifiedRevision: null };
}

function releasePipeline(input = {}, adapters = {}) {
    const steps = ["generateOrImport", "normalize", "validate", "audit", "preview", "preflight", "publish"];
    let value = input;
    for (const step of steps) {
        if (typeof adapters[step] !== "function") continue;
        value = adapters[step](value);
        if (value && value.ok === false) return { ok: false, failedAt: step, ...value };
    }
    return { ok: true, value };
}

module.exports = { STATES, normalizeLifecycle, transition, afterEdit, releasePipeline };
