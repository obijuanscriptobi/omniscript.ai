# Workspace module contract

The editor coordinator (`script.js`) owns the mutable workspace state and coordinates feature modules.

## Preview boundary

`workspace-preview-controller.js` owns iframe preview invalidation and document construction.

- Input: `state.files`, `state.activePage`, `state.previewMode`, and `state.previewZoom`.
- Output: updates the preview iframe and empty state only.
- Callback: `onLoad()` lets the coordinator bind visual editing and run preview checks.
- It does not persist data, change generated files, or own deployment state.

## Planned extraction order

1. Preview rendering, then visual editor interactions.
2. Project import/export and persistence.
3. Deployment and verification.
4. Runtime initialization and event binding.

Each extraction should keep `script.js` as coordinator until browser regression coverage confirms the boundary.

## Ad studio boundary

`ad-studio.js` generates original campaign concepts from broad observations supplied by the user or an authorized source. It does not scrape restricted ad libraries or copy source text, assets, branding, targeting data, or distinctive layouts.

```js
window.adStudio = {
    analyzePatterns({ references, industry, channel }) {},
    generateConcept({ business, goal, audience, patternProfile }) {},
    validateOriginality({ concept, references }) {},
    exportConcept({ format }) {}
};
```

Ad concepts are temporary editor outputs and are exported separately as JSON. They are not website source files, deployment files, or proof of likely campaign performance.
