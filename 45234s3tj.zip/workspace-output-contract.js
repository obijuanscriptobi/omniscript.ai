"use strict";

const LIMITS = Object.freeze({ total: 5_000_000, html: 150_000, css: 100_000, javascript: 150_000 });
const bytes = (value) => Buffer.byteLength(String(value || ""), "utf8");

function validateOutput(files = {}) {
    const entries = Object.entries(files || {});
    const html = entries.filter(([name]) => /\.html?$/i.test(name));
    const css = entries.filter(([name]) => /\.css$/i.test(name));
    const js = entries.filter(([name]) => /\.js$/i.test(name));
    const issues = [];
    const source = entries.map(([, value]) => String(value || "")).join("\n");
    if (!files["index.html"]) issues.push({ code: "MISSING_INDEX", severity: "blocking", message: "index.html is required." });
    if (!files["favicon.svg"]) issues.push({ code: "MISSING_FAVICON", severity: "blocking", message: "favicon.svg is required." });
    if (!files["sitemap.xml"]) issues.push({ code: "MISSING_SITEMAP", severity: "blocking", message: "sitemap.xml is required." });
    if (!files["robots.txt"]) issues.push({ code: "MISSING_ROBOTS", severity: "blocking", message: "robots.txt is required." });
    if (!files["site.webmanifest"]) issues.push({ code: "MISSING_MANIFEST", severity: "warning", message: "site.webmanifest is recommended for an installable, official web presence." });
    if (!files["404.html"]) issues.push({ code: "MISSING_404", severity: "warning", message: "404.html is recommended for a polished missing-page experience." });
    if (files["index.html"] && /<link\b[^>]+rel=["'][^"']*canonical[^"']*[^>]+href=["']https:\/\//i.test(String(files["index.html"])) && !files["security.txt"] && !files[".well-known/security.txt"]) issues.push({ code: "MISSING_SECURITY_CONTACT", severity: "warning", message: "A security contact file is recommended for responsible vulnerability reporting." });
    if (files["sitemap.xml"] && !/<urlset\b/i.test(String(files["sitemap.xml"]))) issues.push({ code: "INVALID_SITEMAP", severity: "blocking", message: "sitemap.xml must contain a urlset." });
    if (files["robots.txt"] && !/User-agent:/i.test(String(files["robots.txt"]))) issues.push({ code: "INVALID_ROBOTS", severity: "blocking", message: "robots.txt must contain User-agent rules." });
    if (!css.length) issues.push({ code: "MISSING_CSS", severity: "blocking", message: "style.css is required." });
    if (!js.length) issues.push({ code: "MISSING_JS", severity: "blocking", message: "script.js is required." });
    for (const [name, content] of html) {
        const page = String(content);
        if (!/^<!doctype html>/i.test(page.trim()) || !/<html\b[^>]*\blang=/i.test(page) || !/<meta\b[^>]+name=["']viewport/i.test(page)) issues.push({ code: "INVALID_DOCUMENT", severity: "blocking", file: name, message: `${name} must be a complete localized responsive document.` });
        if ((page.match(/<h1[\s>]/gi) || []).length !== 1) issues.push({ code: "H1_COUNT", severity: "blocking", file: name, message: `${name} must contain exactly one h1.` });
        if (!/<title\b[^>]*>\s*[^<]+/i.test(page)) issues.push({ code: "MISSING_TITLE", severity: "blocking", file: name, message: `${name} needs a descriptive title.` });
        if (!/<meta\b[^>]+name=["']description["'][^>]+content=["'][^"']+/i.test(page)) issues.push({ code: "MISSING_DESCRIPTION", severity: "blocking", file: name, message: `${name} needs a meta description.` });
        if (!/<link\b[^>]+rel=["'][^"']*canonical/i.test(page)) issues.push({ code: "MISSING_CANONICAL", severity: "blocking", file: name, message: `${name} needs a canonical URL.` });
        if (!/<meta\b[^>]+property=["']og:title["']/i.test(page)) issues.push({ code: "MISSING_OG", severity: "blocking", file: name, message: `${name} needs Open Graph metadata.` });
        for (const image of page.matchAll(/<img\b([^>]*)>/gi)) {
            if (!/\balt=["'][^"']{2,}["']/i.test(image[1])) issues.push({ code: "IMAGE_ALT", severity: "blocking", file: name, message: `${name} contains an image without meaningful alt text.` });
        }
        if (/\b(?:lorem ipsum|placeholder text|coming soon|your company name)\b/i.test(page)) issues.push({ code: "PLACEHOLDER_COPY", severity: "blocking", file: name, message: `${name} contains placeholder copy.` });
        if (/<form\b/i.test(page) && /<form\b(?![^>]*\baction=)/i.test(page)) issues.push({ code: "FORM_ACTION", severity: "blocking", file: name, message: `${name} contains a form without an action.` });
        if (/(?:javascript:|data:text\/html|\bon\w+\s*=)/i.test(page)) issues.push({ code: "UNSAFE_MARKUP", severity: "blocking", file: name, message: `${name} contains unsafe markup.` });
    }
    if (/\b(?:eval|Function)\s*\(|document\.write\s*\(/.test(source)) issues.push({ code: "DYNAMIC_CODE", severity: "blocking", message: "Generated output cannot use dynamic-code APIs." });
    const total = entries.reduce((sum, [, value]) => sum + bytes(value), 0);
    const sizes = { total, html: html.reduce((sum, [, value]) => sum + bytes(value), 0), css: css.reduce((sum, [, value]) => sum + bytes(value), 0), javascript: js.reduce((sum, [, value]) => sum + bytes(value), 0) };
    if (sizes.total > LIMITS.total || sizes.html > LIMITS.html || sizes.css > LIMITS.css || sizes.javascript > LIMITS.javascript) issues.push({ code: "SOURCE_BUDGET", severity: "blocking", message: "Generated output exceeds the source-size budget." });
    return { ok: !issues.some((issue) => issue.severity === "blocking"), issues, sizes, limits: LIMITS };
}

module.exports = { LIMITS, validateOutput };
