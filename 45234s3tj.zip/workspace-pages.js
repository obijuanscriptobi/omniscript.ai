"use strict";

// Pure page-management helpers. DOM and editor state remain owned by script.js.
(() => {
    function isPageFile(filename) {
        return /^([a-z0-9-]+)\.html$/i.test(filename || "");
    }

    function sortPageFiles(files = []) {
        return [...files].filter(isPageFile).sort((a, b) =>
            a === "index.html" ? -1 : b === "index.html" ? 1 : a.localeCompare(b)
        );
    }

    function pageLabel(filename) {
        if (filename === "index.html") return "Home";
        return String(filename || "")
            .replace(/\.html$/i, "")
            .replace(/-/g, " ")
            .replace(/\b\w/g, (letter) => letter.toUpperCase());
    }

    function navigationMarkup(files = [], mobile = false) {
        const pages = sortPageFiles(files);
        const links = pages
            .map((filename) => `<a href="./${escapeHtml(filename)}" data-preview-page="${escapeHtml(filename)}">${escapeHtml(pageLabel(filename))}</a>`)
            .join("");
        const cta = pages.includes("contact.html")
            ? `<a class="nav-cta" href="./contact.html" data-preview-page="contact.html">Get in touch</a>`
            : "";
        const label = mobile ? "Mobile navigation" : "Primary navigation";
        const id = mobile ? ` id="mobile-navigation"` : "";
        return `<nav${id} class="nav-links" data-site-navigation aria-label="${label}">${links}${cta}</nav>`;
    }

    function syncNavigation(files = {}) {
        const pages = sortPageFiles(Object.keys(files));
        const navigation = navigationMarkup(pages);
        const mobileNavigation = navigationMarkup(pages, true);
        const next = { ...files };
        pages.forEach((filename) => {
            const html = String(next[filename] || "");
            if (!/<nav\b[^>]*data-site-navigation[^>]*>/i.test(html)) return;
            next[filename] = html.replace(
                /<nav\b([^>]*)data-site-navigation([^>]*)>[\s\S]*?<\/nav>/gi,
                (match, before, after) => /aria-label=["']Mobile navigation["']/i.test(match)
                    ? mobileNavigation
                    : navigation
            );
        });
        return next;
    }

    function escapeHtml(value) {
        return String(value || "").replace(/[&<>"']/g, (character) => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
        }[character]));
    }

    window.workspacePages = Object.freeze({
        isPageFile,
        sortPageFiles,
        pageLabel,
        navigationMarkup,
        syncNavigation
    });
})();
