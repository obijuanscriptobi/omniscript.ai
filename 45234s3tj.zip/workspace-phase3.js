"use strict";

// Phase 3 workspace enhancements. Sharing is deliberately explicit: this creates
// a review link for the current editor context, not a public deployment.
(() => {
    const get = (id) => document.getElementById(id);

    function state() {
        return window.workspaceAPI?.getState?.() || {};
    }

    async function copyReviewLink() {
        if (typeof window.reviewHandoff?.createShareableLink !== "function") {
            setStatus("Create a draft and wait for review sharing to finish loading.", "warn");
            return;
        }
        const value = await window.reviewHandoff.createShareableLink();
        if (!value) return;
        try {
            await navigator.clipboard.writeText(value);
            setStatus("Private review link copied. It identifies the current revision and does not publish the site.");
        } catch {
            setStatus("The review link is ready, but clipboard access was blocked. Copy it from the review field.", "warn");
        }
    }

    function setStatus(message, stateName = "pass") {
        const status = get("preview-share-status");
        if (!status) return;
        status.textContent = message;
        status.dataset.state = stateName;
    }

    function bind() {
        get("copy-preview-link-btn")?.addEventListener("click", copyReviewLink);
        get("inspect-remote-assets-btn")?.addEventListener("click", async () => {
            const current = state();
            const html = Object.values(current.files || {}).join("\n");
            const urls = [...new Set([...html.matchAll(/(?:src|href)=["'](https:\/\/[^"']+)["']/gi)].map((match) => match[1]).filter((url) => /\.(?:avif|gif|jpe?g|png|svg|webp)(?:[?#]|$)/i.test(url)))].slice(0, 20);
            if (!urls.length) { setStatus("No remote image assets were found to inspect.", "warn"); return; }
            setStatus(`Inspecting ${urls.length} remote asset${urls.length === 1 ? "" : "s"}…`, "working");
            const results = await Promise.all(urls.map(async (url) => {
                try {
                    const response = await fetch("/api/asset", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify({ action: "inspect-url", url }) });
                    return await response.json();
                } catch (error) { return { success: false, error: error.message || "Inspection failed." }; }
            }));
            const oversized = results.filter((result) => Number(result.asset?.bytes || 0) > 2_000_000).length;
            setStatus(`${results.length - oversized}/${results.length} remote assets passed the initial byte/type check${oversized ? `; ${oversized} need optimization review` : ""}.`, oversized ? "warn" : "pass");
        });
        const provider = get("hosting-provider-select");
        provider?.addEventListener("change", () => {
            window.workspaceAPI?.setHostingProvider?.(provider.value);
            const status = get("hosting-options-status");
            if (status) status.textContent = `${provider.options[provider.selectedIndex]?.textContent || provider.value} selected. Provider credentials and deployment access are still required.`;
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
    else bind();
})();
