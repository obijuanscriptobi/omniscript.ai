"use strict";

// Preview boundary: owns iframe document construction and preview invalidation.
// The editor coordinator supplies state and callbacks; this module does not
// mutate project data or own persistence.
(() => {
    function create(config = {}) {
        const state = config.state;
        const get = config.get;
        const onLoad = config.onLoad || (() => {});

        window.addEventListener("message", (event) => {
            const iframe = get("previewContentIframe");
            if (event.source !== iframe?.contentWindow) return;
            const message = window.websiteMakerPreviewProtocol?.parse?.(event.data);
            if (message?.type !== "error") return;
            document.dispatchEvent(new CustomEvent("workspace:preview-error", {
                detail: { message: message.payload.message }
            }));
        });

        function update() {
            const iframe = get("previewContentIframe");
            const emptyState = get("preview-empty-state");
            const frameShell = get("preview-frame-shell");
            const html = state.files[state.activePage] || state.files["index.html"] || "";
            const awaiting = !html || html.startsWith("<!-- Awaiting");
            if (emptyState) emptyState.hidden = !awaiting;
            if (frameShell) frameShell.hidden = awaiting;
            if (iframe) iframe.style.setProperty("--preview-zoom", String(state.previewZoom || 1));

            if (!iframe || awaiting) {
                state.lastPreviewKey = "";
                if (iframe && iframe.srcdoc) iframe.srcdoc = "";
                return;
            }

            const css = state.files["style.css"] || "";
            const clientScript = state.files["script.js"] || "";
            const previewTools = window.workspacePreview;
            const previewKey = previewTools?.previewKey
                ? previewTools.previewKey(state.activePage, html, css, clientScript)
                : `${state.activePage}\u0000${html}\u0000${css}\u0000${clientScript}`;

            if (previewKey === state.lastPreviewKey) return;
            state.lastPreviewKey = previewKey;

            // A srcdoc document without allow-same-origin has an opaque origin,
            // so messages intentionally target the parent with "*". The parent
            // validates event.source and a narrow payload schema.
            const previewRuntime = `
                (function () {
                    function send(type, payload) {
                        window.parent.postMessage({ channel: "website-maker-preview-v1", type: type, payload: payload || {} }, "*");
                    }
                    window.addEventListener("error", function (event) {
                        send("error", { message: String(event.message || "Preview script error").slice(0, 500) });
                    });
                    window.addEventListener("unhandledrejection", function (event) {
                        var reason = event.reason && event.reason.message ? event.reason.message : String(event.reason || "Unhandled promise rejection");
                        send("error", { message: reason.slice(0, 500) });
                    });
                    document.addEventListener("submit", function (event) {
                        var form = event.target;
                        if (!(form instanceof HTMLFormElement)) return;
                        event.preventDefault();
                        event.stopImmediatePropagation();
                        form.removeAttribute("action");
                        var data = new FormData(form);
                        send("enquiry", {
                            name: String(data.get("name") || data.get("full_name") || data.get("fullName") || "").slice(0, 160),
                            email: String(data.get("email") || "").slice(0, 240),
                            phone: String(data.get("phone") || data.get("tel") || "").slice(0, 80),
                            message: String(data.get("message") || data.get("details") || data.get("qualification") || "").slice(0, 2000),
                            company: String(data.get("company") || "").slice(0, 180),
                            source: String(form.dataset.goal || "website").slice(0, 80)
                        });
                        var status = form.querySelector(".form-status, [data-form-status], output");
                        if (status) status.textContent = "Thanks — your enquiry was received.";
                    }, true);
                }());
            `;
            const preview = previewTools?.buildDocument
                ? previewTools.buildDocument({ html, css, script: clientScript, runtime: previewRuntime })
                : html;
            iframe.removeAttribute("src");
            iframe.srcdoc = preview;
            iframe.title = `Generated website preview (${state.previewMode})`;
            iframe.onload = () => onLoad();
        }

        return Object.freeze({ update });
    }

    window.workspacePreviewController = Object.freeze({ create });
})();
