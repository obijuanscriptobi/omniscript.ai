"use strict";

// Preview helpers are intentionally pure so viewport behavior can be tested
// without loading the complete editor runtime.
(() => {
    const MODES = Object.freeze({
        desktop: "desktop-mode-expanded",
        tablet: "tablet-mode",
        mobile: "mobile-mode"
    });

    function normalizeMode(mode) {
        return Object.prototype.hasOwnProperty.call(MODES, mode) ? mode : "desktop";
    }

    function previewKey(page, html, css, script) {
        return `${page}\u0000${html}\u0000${css}\u0000${script}`;
    }

    function stripExternalAssets(html) {
        return String(html || "")
            .replace(/<link\b[^>]*href=["'][^"']*style\.css[^"']*["'][^>]*>/gi, "")
            .replace(/<script\b[^>]*src=["'][^"']*script\.js[^"']*["'][^>]*>\s*<\/script>/gi, "");
    }

    const previewUrls = new Set();

    function releasePreviewUrls() {
        if (typeof URL !== "undefined" && typeof URL.revokeObjectURL === "function") {
            previewUrls.forEach((url) => URL.revokeObjectURL(url));
        }
        previewUrls.clear();
    }

    function createAssetUrl(source, type) {
        if (typeof URL !== "undefined" && typeof URL.createObjectURL === "function" && typeof Blob !== "undefined") {
            const url = URL.createObjectURL(new Blob([source], { type }));
            previewUrls.add(url);
            return url;
        }
        return `data:${type};charset=utf-8,${encodeURIComponent(source)}`;
    }

    function buildDocument({ html = "", css = "", script = "", runtime = "" } = {}) {
        // Keep the previous preview assets alive until the new document has had
        // time to start loading. Revoking them synchronously can interrupt an
        // iframe that is still parsing the previous preview.
        const previousUrls = [...previewUrls];
        let preview = stripExternalAssets(html);
        const cssUrl = createAssetUrl(String(css), "text/css");
        const scriptUrl = createAssetUrl(`${runtime}${String(script)}`, "text/javascript");
        const defer = typeof setTimeout === "function"
            ? setTimeout
            : typeof window !== "undefined" && typeof window.setTimeout === "function"
                ? window.setTimeout.bind(window)
                : null;
        if (defer) defer(() => {
            previousUrls.forEach((url) => {
                if (previewUrls.delete(url) && typeof URL !== "undefined" && typeof URL.revokeObjectURL === "function") {
                    URL.revokeObjectURL(url);
                }
            });
        }, 1000);
        const styleLink = `<link rel="stylesheet" href="${cssUrl}">`;
        const scriptTag = `<script src="${scriptUrl}" defer></script>`;
        preview = /<\/head>/i.test(preview)
            ? preview.replace(/<\/head>/i, `${styleLink}</head>`)
            : `${styleLink}${preview}`;
        return /<\/body>/i.test(preview)
            ? preview.replace(/<\/body>/i, `${scriptTag}</body>`)
            : `${preview}${scriptTag}`;
    }

    function applyMode(wrapper, mode) {
        const normalized = normalizeMode(mode);
        if (!wrapper) return normalized;
        wrapper.classList.remove(...Object.values(MODES));
        wrapper.classList.add(MODES[normalized]);
        return normalized;
    }

    window.workspacePreview = Object.freeze({
        MODES,
        normalizeMode,
        previewKey,
        stripExternalAssets,
        buildDocument,
        releasePreviewUrls,
        applyMode
    });
})();
