"use strict";

// One small, explainable quality model shared by the workspace surfaces.
(() => {
    const categories = ["content", "conversion", "accessibility", "seo", "performance", "deployment"];
    const CATEGORY_ALIASES = Object.freeze({ quality: "content", structure: "content", security: "deployment", forms: "conversion" });

    function issueText(item) {
        return typeof item === "string" ? item : item?.message || String(item || "");
    }

    function evaluate(report = {}, files = {}, context = {}) {
        const blocking = Array.isArray(report.blocking) ? report.blocking : [];
        const issues = Array.isArray(report.issues) ? report.issues : [];
        const normalizeFinding = (item) => {
            if (typeof item === "string") return { message: item, code: "LEGACY_FINDING", category: "content", severity: "warning", impact: 1 };
            const severity = String(item?.severity || "warning").toLowerCase();
            const impact = Number.isFinite(Number(item?.impact)) ? Math.max(1, Math.min(5, Number(item.impact))) : severity === "blocking" || severity === "error" ? 5 : severity === "warning" ? 3 : 1;
            const rawCategory = String(item?.category || "content").toLowerCase();
            return { ...item, message: issueText(item), category: CATEGORY_ALIASES[rawCategory] || (categories.includes(rawCategory) ? rawCategory : "content"), severity, impact };
        };
        const findings = [...blocking, ...issues].map(normalizeFinding).filter((item) => item.message);
        const uniqueFindings = [...new Map(findings.map((item) => [`${item.code || item.category}:${item.file || ""}:${item.message}`, item])).values()];
        const blockerKeys = new Set(blocking.map((item) => `${item.code || ""}:${item.file || ""}:${issueText(item)}`));
        const severityWeight = { blocking: 6, error: 5, warning: 3, info: 1 };
        const count = (category) => uniqueFindings.filter((item) => {
            return item.category === category;
        }).reduce((sum, item) => sum + (Number(item.impact) || 1) * (severityWeight[item.severity] || 1), 0);
        const business = context.business && typeof context.business === "object" ? context.business : {};
        const sourceFiles = files && typeof files === "object" && !Array.isArray(files) ? files : {};
        const html = String(sourceFiles["index.html"] || "");
        const hasProject = Object.values(sourceFiles).some((value) => String(value || "").trim());
        const formReady = /<form\b[^>]*\baction=["'][^"']+["']/i.test(html);
        const publishedUrl = String(context.publishedSiteUrl || "").trim();
        const hasPublishedUrl = /^https:\/\/[^\s/]+(?:\/[^\s]*)?$/i.test(publishedUrl);
        const deploymentEvidence = context.deployment && typeof context.deployment === "object" ? context.deployment : {};
        const deploymentVerified = deploymentEvidence.verified === true || deploymentEvidence.status === "verified";
        const currentRevision = String(context.revision || "").trim();
        const evidenceRevision = String(deploymentEvidence.revision || "").trim();
        const evidenceMatches = !currentRevision || !evidenceRevision || currentRevision === evidenceRevision;
        const designAudit = context.designAudit && typeof context.designAudit === "object" ? context.designAudit : {};
        const designScores = designAudit.scores && typeof designAudit.scores === "object" ? designAudit.scores : {};
        const scores = {
            content: Math.max(0, Math.min(100, Number.isFinite(Number(designScores.contentSpecificity)) ? Number(designScores.contentSpecificity) - count("content") * 2 : 100 - count("content") * 8 - (!business.hook ? 12 : 0))),
            clarity: Math.max(0, Math.min(100, Number.isFinite(Number(designScores.firstScreen)) ? Number(designScores.firstScreen) - count("content") * 2 : 100 - count("content") * 8 - (!business.hook ? 12 : 0))),
            conversion: Math.max(0, 100 - count("conversion") * 7 - (!formReady && !business.phone && !business.email ? 25 : 0)),
            accessibility: Math.max(0, 100 - count("accessibility") * 8),
            seo: Math.max(0, 100 - count("seo") * 8),
            performance: Math.max(0, 100 - count("performance") * 8),
            deployment: hasProject
                ? Math.max(0, 100 - blocking.length * 25 - (!hasPublishedUrl ? 10 : 0) - (deploymentEvidence.status && !deploymentVerified ? 20 : 0) - (evidenceMatches ? 0 : 25))
                : 0
        };
        const overall = Math.round(categories.reduce((sum, category) => sum + scores[category], 0) / categories.length);
        const firstBlocker = uniqueFindings.find((item) => item.severity === "blocking" || item.severity === "error");
        return {
            overall,
            scores,
            design: {
                scores: designScores,
                recommendations: Array.isArray(designAudit.recommendations) ? designAudit.recommendations.slice(0, 6) : [],
                rationale: String(designAudit.rationale || "")
            },
            blockers: blocking.map((item) => normalizeFinding(item).message),
            launchGate: {
                state: blocking.length ? "blocked" : "review",
                blocker: firstBlocker ? { code: firstBlocker.code || "QUALITY_FINDING", title: firstBlocker.message, category: firstBlocker.category, impact: firstBlocker.impact } : null,
                evidenceRequired: !hasPublishedUrl ? "Configure an absolute HTTPS published URL and verify the deployed revision." : "Re-run technical checks after material changes.",
                action: firstBlocker?.remediation || (blocking.length ? "Resolve the blocking finding and recheck." : "Complete production evidence before publishing.")
            },
            recommendations: uniqueFindings.filter((item) => !blockerKeys.has(`${item.code || ""}:${item.file || ""}:${item.message}`)).map((item) => item.message),
            evidence: {
                form: formReady ? "Form action is present; confirm technical acceptance and real delivery separately." : "No connected form action detected.",
                publishing: hasPublishedUrl ? "Published HTTPS URL is configured; deployment and real delivery still require confirmation." : "A final HTTPS published URL is required for launch evidence.",
                qualityScope: "Technical readiness evidence only; does not guarantee conversion performance.",
                responsiveScope: "Configured viewport scenarios only; does not represent full device coverage.",
                importScope: "Imported files require visual review; successful import does not prove fidelity.",
                competitorScope: "No external competitor comparison is included.",
                files: Object.keys(sourceFiles).length
            },
            categories
        };
    }

    window.workspaceQualityModel = Object.freeze({ categories, evaluate });
})();
