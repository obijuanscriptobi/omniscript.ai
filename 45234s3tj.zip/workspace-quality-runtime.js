"use strict";

// Browser-safe structural checks shared by the workspace diagnostics UI.
(() => {
    function getStructuralQualityIssues(html = "", css = "") {
        const source = String(html || "");
        const stylesheet = String(css || "");
        const issues = [];
        const headings = [...source.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi)].map((match) => ({
            level: Number(match[1]),
            text: match[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim()
        }));
        const fields = [...source.matchAll(/<(input|textarea|select)\b([^>]*)>/gi)]
            .map((match) => match[2])
            .filter((attrs) => !/\baria-hidden=["']true["']|\btype=["']hidden["']/i.test(attrs));
        const labels = [...source.matchAll(/<label\b[^>]*for=["']([^"']+)["'][^>]*>/gi)].map((match) => match[1]);
        const ids = new Set([...source.matchAll(/\bid=["']([^"']+)["']/gi)].map((match) => match[1]));
        const unnamedButtons = [...source.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/gi)].filter((match) => {
            const text = match[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
            return !text && !/\baria-label=["'][^"']+|\btitle=["'][^"']+/i.test(match[1]);
        });
        const colors = [...stylesheet.matchAll(/(?:color|background(?:-color)?)\s*:\s*(#[0-9a-f]{3,8}|rgba?\([^)]*\)|[a-z]+)/gi)].map((match) => match[1]);
        const lightColor = (value) => /#(?:fff|ffffff|f8fafc|f5fafc|f5f5f5)/i.test(value);

        if (!/<!doctype\s+html\s*>/i.test(source)) issues.push("Structure: Add <!doctype html> so browsers use standards mode.");
        if (!/<head\b[\s\S]*<\/head>/i.test(source) || !/<body\b[\s\S]*<\/body>/i.test(source)) issues.push("Structure: Include complete <head> and <body> elements.");
        if (!/<meta\b[^>]+charset\s*=/i.test(source)) issues.push("Accessibility: Add a UTF-8 charset declaration.");
        if (!/<meta\b[^>]+name=["']viewport["']/i.test(source)) issues.push("Responsive: Add a viewport meta tag for mobile layouts.");
        if (headings.length && headings[0].level !== 1) issues.push("Accessibility: Start the page heading hierarchy with an <h1>.");
        if (headings.some((heading, index) => index > 0 && heading.level - headings[index - 1].level > 1)) issues.push("Accessibility: Avoid skipping heading levels (for example, h2 directly to h4).");
        if (fields.some((attrs) => !/\baria-label=["']|\baria-labelledby=["']|\bid=["']/i.test(attrs))) issues.push("Accessibility: Give every form control an id, label, or accessible name.");
        if (fields.some((attrs) => {
            const id = attrs.match(/\bid=["']([^"']+)["']/i)?.[1];
            return id && !labels.includes(id) && !/\baria-label|\baria-labelledby/i.test(attrs);
        })) issues.push("Accessibility: Associate form controls with visible labels or aria-labels.");
        if (labels.some((id) => !ids.has(id))) issues.push("Accessibility: Fix labels that reference missing form-control IDs.");
        if (unnamedButtons.length) issues.push(`Accessibility: Give ${unnamedButtons.length} button${unnamedButtons.length === 1 ? "" : "s"} an accessible name.`);
        if (!/<link\b[^>]+rel=["'][^"']*canonical/i.test(source)) issues.push("SEO: Add a canonical link when the page can be reached at multiple URLs.");
        if (!/<meta\b[^>]+property=["']og:title["']/i.test(source) || !/<meta\b[^>]+property=["']og:description["']/i.test(source)) issues.push("SEO: Add og:title and og:description metadata for social sharing.");
        if (!/<script\b[^>]+type=["']application\/ld\+json["']/i.test(source)) issues.push("SEO: Consider adding relevant JSON-LD structured data.");
        if (colors.some(lightColor) && colors.some((color) => !lightColor(color))) issues.push("Accessibility: Review text and background color contrast, especially light text on light surfaces.");
        if (/<iframe\b/i.test(source) && !/<iframe\b[^>]+title=["'][^"']+["']/i.test(source)) issues.push("Accessibility: Give every iframe a descriptive title.");

        return issues;
    }

    function getProjectQualityIssues(files = {}) {
        const sourceFiles = files && typeof files === "object" ? files : {};
        const homepage = String(sourceFiles["index.html"] || "");
        const css = String(sourceFiles["style.css"] || "");
        const structural = getStructuralQualityIssues(homepage, css).map((message) => ({
            code: "STRUCTURAL_REVIEW",
            severity: "warning",
            category: "quality",
            file: "index.html",
            message
        }));
        const shared = window.workspaceAudit?.auditProject?.(sourceFiles);
        const responsive = window.workspaceResponsive?.auditResponsiveSource?.(homepage, css) || [];
        const responsiveIssues = responsive.map((entry) => ({
            ...entry,
            file: entry.file || "style.css"
        }));
        const rendered = window.workspaceAudit?.auditRenderedDocument?.(window.document?.querySelector?.("#previewContentIframe")?.contentDocument || null);
        const renderedIssues = (rendered?.issues || []).map((entry) => ({
            ...entry,
            category: entry.category || (entry.code === "LOW_CONTRAST" ? "accessibility" : "performance"),
            file: "preview"
        }));
        const issues = [...structural, ...responsiveIssues, ...renderedIssues, ...(shared?.issues || [])];
        const seen = new Set();
        return issues.filter((entry) => {
            const key = `${entry.code}:${entry.file || ""}:${entry.target || ""}:${entry.message}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    window.workspaceQuality = Object.freeze({ getStructuralQualityIssues, getProjectQualityIssues });
})();
