"use strict";

const MAX_FILES = 40;
const MAX_FILE_BYTES = 1_000_000;
const MAX_TOTAL_BYTES = 5_000_000;
const ALLOWED_FILES = /^(?:[a-z0-9][a-z0-9._-]{0,119}\.(?:html?|css|js|json|toml|txt|xml)|netlify\/functions\/[a-z0-9][a-z0-9._-]{0,119}\.js)$/i;
const NETLIFY_PATH = /^\/(?!\/)[^\s"']+$/;
const NETLIFY_FUNCTION_PATH = /^\/\.netlify\/functions\/[a-z0-9][a-z0-9._-]*$/i;

function validateNetlifyConfig(contents, add) {
    const source = String(contents || "");
    const lines = source.split(/\r?\n/);
    let redirectBlocks = 0;
    let headerBlocks = 0;

    lines.forEach((line, index) => {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) return;
        if (/^\[\[redirects\]\]$/.test(trimmed)) redirectBlocks += 1;
        if (/^\[\[headers\]\]$/.test(trimmed)) headerBlocks += 1;
        const assignment = trimmed.match(/^(from|to|status|force|for)\s*=\s*(.*)$/);
        if (!assignment) return;
        const [, key, rawValue] = assignment;
        const value = rawValue.trim();
        if (!value) add("NETLIFY_EMPTY_VALUE", "error", `Netlify configuration has an empty ${key} value on line ${index + 1}.`, "netlify.toml");
        if (["from", "to", "for"].includes(key) && /^\"/.test(value)) {
            const unquoted = value.replace(/^\"|\"$/g, "");
            if (!NETLIFY_PATH.test(unquoted) && !unquoted.startsWith("/.netlify/functions/")) {
                add("NETLIFY_INVALID_PATH", "error", `Netlify configuration has an invalid ${key} path on line ${index + 1}.`, "netlify.toml");
            }
        }
        if (key === "status" && !/^\"?(?:200|301|302|303|307|308|404)\"?$/.test(value)) {
            add("NETLIFY_INVALID_STATUS", "error", `Netlify configuration has an unsupported redirect status on line ${index + 1}.`, "netlify.toml");
        }
        if (key === "force" && !/^(?:true|false)$/.test(value)) {
            add("NETLIFY_INVALID_FORCE", "error", `Netlify configuration force must be true or false on line ${index + 1}.`, "netlify.toml");
        }
    });

    if (redirectBlocks && !/from\s*=\s*["']\/\*\*["']/.test(source) && !/from\s*=\s*["']\/\*["']/.test(source)) {
        add("NETLIFY_NO_SPA_FALLBACK", "warning", "Single-page applications should include a final /* or /** to /index.html fallback.", "netlify.toml");
    }
    if (headerBlocks && !/Cache-Control/.test(source)) {
        add("NETLIFY_NO_CACHE_POLICY", "warning", "Define explicit cache behavior for HTML, assets, and API responses.", "netlify.toml");
    }
}

function issue(code, severity, message, file = "") {
    return { code, severity, message, ...(file ? { file } : {}) };
}

function validateFiles(input) {
    const files = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const issues = [];
    const normalized = {};
    let totalBytes = 0;
    const names = Object.keys(files);

    if (names.length > MAX_FILES) {
        issues.push(issue("TOO_MANY_FILES", "error", `Projects may contain at most ${MAX_FILES} files.`));
    }

    for (const name of names) {
        const value = files[name];
        if (!ALLOWED_FILES.test(name)) {
            issues.push(issue("INVALID_FILENAME", "error", "The file name or path is not allowed.", name));
            continue;
        }
        if (typeof value !== "string") {
            issues.push(issue("INVALID_FILE", "error", "File contents must be text.", name));
            continue;
        }
        const bytes = Buffer.byteLength(value, "utf8");
        totalBytes += bytes;
        if (bytes > MAX_FILE_BYTES) {
            issues.push(issue("FILE_TOO_LARGE", "error", `The file exceeds ${MAX_FILE_BYTES} bytes.`, name));
            continue;
        }
        normalized[name] = value;
    }

    if (totalBytes > MAX_TOTAL_BYTES) {
        issues.push(issue("PROJECT_TOO_LARGE", "error", `The project exceeds ${MAX_TOTAL_BYTES} total bytes.`));
    }

    return { files: normalized, issues };
}

function qualityReport(input) {
    const { files, issues } = validateFiles(input);
    const report = { blocking: [...issues], issues: [...issues], files: Object.keys(files), summary: {} };
    const add = (code, severity, message, file) => {
        const entry = issue(code, severity, message, file);
        report.issues.push(entry);
        if (severity === "error") report.blocking.push(entry);
    };

    for (const [filename, contents] of Object.entries(files)) {
        if (filename === "netlify.toml") {
            validateNetlifyConfig(contents, add);
        }
        if (/\.html?$/i.test(filename)) {
            if (!/^\s*<!doctype\s+html>/i.test(contents)) add("MISSING_DOCTYPE", "warning", "Use a standards HTML doctype.", filename);
            if (!/<html\b[^>]*\blang=["'][^"']+["']/i.test(contents)) add("MISSING_LANGUAGE", "warning", "Declare the document language on <html>.", filename);
            if (!/<meta\b[^>]*\bname\s*=\s*["']viewport["'][^>]*>/i.test(contents)) add("MISSING_VIEWPORT", "warning", "Add responsive viewport metadata.", filename);
            if (!/<title\b[^>]*>\s*[^<]+/i.test(contents)) add("MISSING_TITLE", "error", "Add a meaningful document title.", filename);
            if (!/<h1\b[^>]*>\s*[^<]+/i.test(contents)) add("MISSING_H1", "warning", "Add one clear primary heading.", filename);
            if (/<img\b(?![^>]*\balt\s*=\s*["'][^"']*["'])[^>]*>/i.test(contents)) add("IMAGE_MISSING_ALT", "error", "Every image needs an alt attribute.", filename);
            if (/<form\b/i.test(contents) && !/<label\b/i.test(contents)) add("FORM_MISSING_LABELS", "warning", "Forms should provide labels for their controls.", filename);
            if (/<script\b[^>]*\bsrc=["']https?:/i.test(contents)) add("EXTERNAL_SCRIPT", "warning", "Prefer trusted local scripts or explicitly review this dependency.", filename);
            if (/<a\b[^>]*href=["']\s*["']/i.test(contents)) add("EMPTY_LINK", "warning", "Remove empty links or give them a valid destination.", filename);
        }
        if (/\.css$/i.test(filename) && /(?:width|height)\s*:\s*\d{4,}px/i.test(contents)) {
            add("OVERSIZED_DIMENSION", "warning", "Review unusually large fixed dimensions for responsive overflow.", filename);
        }
        if (/\.js$/i.test(filename) && /\b(?:eval|new\s+Function)\s*\(/.test(contents)) {
            add("UNSAFE_CODE", "error", "Avoid eval and dynamic Function construction in generated code.", filename);
        }
    }

    if (!Object.keys(files).some((name) => /^index\.html$/i.test(name))) {
        add("MISSING_INDEX", "error", "A project must include index.html.");
    }
    if (!Object.keys(files).some((name) => /\.css$/i.test(name))) {
        add("MISSING_STYLESHEET", "warning", "Consider including a stylesheet for responsive presentation.");
    }

    report.summary = {
        files: report.files.length,
        errors: report.issues.filter((entry) => entry.severity === "error").length,
        warnings: report.issues.filter((entry) => entry.severity === "warning").length,
        passed: report.blocking.length === 0
    };
    return report;
}

module.exports = { MAX_FILES, MAX_FILE_BYTES, MAX_TOTAL_BYTES, qualityReport, validateFiles };
