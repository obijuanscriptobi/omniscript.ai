"use strict";

// Focused regeneration contract. It describes exactly what may change, keeps
// approved evidence immutable, and stores lightweight checkpoints for undo and
// side-by-side comparison without placing generated source in model prompts.
(() => {
    const STORAGE_KEY = "workspace-regeneration-v1";
    const MODES = Object.freeze(["design", "copy", "hero", "sections", "typography-color", "density", "cta", "conversion"]);
    const text = (value, maximum = 100) => String(value ?? "").replace(/[<>\u0000-\u001f]/g, " ").trim().slice(0, maximum);
    const clone = (value) => JSON.parse(JSON.stringify(value ?? null));
    const kindOf = (section, components) => components?.COMPONENTS?.[section?.component]?.kind || text(section?.component).split("-")[0];

    function normalizeControls(raw = {}) {
        const mode = MODES.includes(raw.mode) ? raw.mode : "design";
        return Object.freeze({
            mode,
            preserveCopy: raw.preserveCopy !== false && mode !== "copy",
            preserveDesign: raw.preserveDesign === true || mode === "copy",
            selectedSections: [...new Set((Array.isArray(raw.selectedSections) ? raw.selectedSections : []).map(Number).filter(Number.isInteger).filter((value) => value >= 0).slice(0, 14))],
            lockClaims: raw.lockClaims !== false,
            lockAssets: raw.lockAssets !== false,
            lockSections: [...new Set((Array.isArray(raw.lockSections) ? raw.lockSections : []).map(Number).filter(Number.isInteger).filter((value) => value >= 0).slice(0, 14))],
            density: ["airy", "balanced", "compact"].includes(raw.density) ? raw.density : "",
            ctaProminence: ["standard", "strong", "closing"].includes(raw.ctaProminence) ? raw.ctaProminence : "",
            conversionGoal: text(raw.conversionGoal, 30)
        });
    }

    function lockDimensions(controls) {
        if (controls.preserveDesign) return ["profile", "navigation", "hero", "rhythm", "cards", "imageTreatment", "grid", "ctaPattern", "density", "motion", "motif"];
        if (controls.mode === "typography-color") return ["navigation", "hero", "rhythm", "cards", "imageTreatment", "grid", "ctaPattern", "density", "motion", "motif"];
        if (controls.mode === "hero") return ["profile", "navigation", "rhythm", "cards", "imageTreatment", "grid", "ctaPattern", "density", "motion", "motif"];
        if (controls.mode === "density") return ["profile", "navigation", "hero", "rhythm", "cards", "imageTreatment", "grid", "ctaPattern", "motion", "motif"];
        if (controls.mode === "cta") return ["profile", "navigation", "hero", "rhythm", "cards", "imageTreatment", "grid", "density", "motion", "motif"];
        return [];
    }

    function mergePlan(previous, generated, controls, components) {
        if (!previous?.sections || !generated?.sections) return generated;
        const result = clone(generated);
        const previousByKind = new Map(previous.sections.map((section) => [kindOf(section, components), section]));
        result.sections = result.sections.map((section, index) => {
            const prior = previousByKind.get(kindOf(section, components));
            const locked = controls.lockSections.includes(index) || (controls.mode === "sections" && !controls.selectedSections.includes(index));
            if (locked && previous.sections[index]) return clone(previous.sections[index]);
            if (!prior) return section;
            if (controls.preserveCopy) return { ...section, content: clone(prior.content || {}) };
            if (controls.lockClaims) {
                const content = { ...(section.content || {}) };
                if (prior.content?.factIds) content.factIds = clone(prior.content.factIds);
                if (Array.isArray(prior.content?.items)) content.items = clone(prior.content.items);
                return { ...section, content };
            }
            return section;
        });
        if (controls.preserveDesign) {
            result.designSystem = previous.designSystem;
            result.sections = result.sections.map((section, index) => previous.sections[index] ? { ...section, component: previous.sections[index].component } : section);
        }
        return result;
    }

    function request(current = {}, rawControls = {}) {
        const controls = normalizeControls(rawControls);
        return Object.freeze({
            mode: "regenerate-plan",
            variationId: text(current.variationId),
            controls,
            immutable: Object.freeze({
                factIds: controls.lockClaims ? clone(current.factIds || []) : [],
                assetIds: controls.lockAssets ? clone(current.assetIds || []) : []
            }),
            currentPlan: clone(current.plan),
            currentDesign: clone(current.design),
            instruction: "Return a structured page plan only. Never return HTML, CSS, JavaScript, URLs, or executable code. Change only fields permitted by controls."
        });
    }

    function read(projectId = "project") {
        if (typeof localStorage === "undefined") return { cursor: -1, checkpoints: [] };
        try { const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); const value = all[text(projectId, 80)]; return value && Array.isArray(value.checkpoints) ? value : { cursor: -1, checkpoints: [] }; } catch (_) { return { cursor: -1, checkpoints: [] }; }
    }
    function write(projectId, value) {
        if (typeof localStorage === "undefined") return;
        try { const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); all[text(projectId, 80)] = value; localStorage.setItem(STORAGE_KEY, JSON.stringify(all)); } catch (_) {}
    }
    function checkpoint(projectId, snapshot = {}) {
        const history = read(projectId);
        const checkpoints = history.checkpoints.slice(0, history.cursor + 1);
        checkpoints.push({ id: text(snapshot.variationId || `variant-${Date.now()}`, 100), createdAt: new Date().toISOString(), label: text(snapshot.label || "Generated variant", 80), variationId: text(snapshot.variationId), plan: clone(snapshot.plan), design: clone(snapshot.design), files: clone(snapshot.files), diagnostics: clone(snapshot.diagnostics || {}) });
        while (checkpoints.length > 12) checkpoints.shift();
        const next = { cursor: checkpoints.length - 1, checkpoints };
        write(projectId, next); return clone(checkpoints[next.cursor]);
    }
    function move(projectId, offset) {
        const history = read(projectId);
        const cursor = Math.max(0, Math.min(history.checkpoints.length - 1, history.cursor + offset));
        const next = { ...history, cursor };
        write(projectId, next);
        return history.checkpoints[cursor] ? clone(history.checkpoints[cursor]) : null;
    }
    function compare(projectId, ids = []) {
        const history = read(projectId);
        const selected = ids.length ? history.checkpoints.filter((item) => ids.includes(item.id)) : history.checkpoints.slice(-2);
        return clone(selected.slice(-4));
    }

    const api = Object.freeze({ STORAGE_KEY, MODES, normalizeControls, lockDimensions, mergePlan, request, read, checkpoint, undo: (projectId) => move(projectId, -1), redo: (projectId) => move(projectId, 1), compare });
    if (typeof window !== "undefined") window.workspaceRegeneration = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
