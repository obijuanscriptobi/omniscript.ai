"use strict";

const crypto = require("node:crypto");
const { validateOutput } = require("./workspace-output-contract.js");
const { qualityReport } = require("./workspace-quality.js");
const { auditProject } = require("./workspace-audit.js");
const lifecycle = require("./workspace-lifecycle.js");

function revision(files = {}, formData = {}) {
    return crypto.createHash("sha256").update(JSON.stringify({ files, formData })).digest("hex");
}

function normalize(input = {}) {
    const files = Object.fromEntries(Object.entries(input.files || {}).map(([name, value]) => [String(name), String(value ?? "")]));
    return { ...input, files, formData: input.formData && typeof input.formData === "object" ? input.formData : {}, revision: input.revision || revision(files, input.formData || {}) };
}

function inspect(input = {}) {
    const value = normalize(input);
    const contract = validateOutput(value.files);
    const quality = qualityReport(value.files);
    const audit = auditProject(value.files);
    return { value, contract, quality, audit, ok: contract.ok && !quality.blocking?.length && !audit.blocking?.length };
}

function pipeline(input = {}, adapters = {}) {
    let value = normalize(input);
    for (const step of ["generateOrImport", "normalize", "validate", "audit", "preview", "preflight", "publish"]) {
        if (typeof adapters[step] !== "function") continue;
        value = adapters[step](value);
        if (value?.ok === false) return { ok: false, failedAt: step, ...value };
    }
    const checked = inspect(value);
    return checked.ok ? { ok: true, ...checked } : { ok: false, failedAt: "validate", ...checked };
}

module.exports = { revision, normalize, inspect, pipeline, ...lifecycle };
