"use strict";

(() => {
    const get = (id) => document.getElementById(id);
    const STORAGE_KEY_PREFIX = "studio-release-checkpoints";
    const MAX_CHECKPOINTS = 12;
    let checkpoints = [];

    function projectStorageKey() {
        const project = state();
        const projectId = String(project.projectId || "").trim();
        return `${STORAGE_KEY_PREFIX}:${projectId || "new"}`;
    }

    function state() {
        return window.workspaceAPI?.getState?.() || { files: {}, projectName: "" };
    }

    function canonicalRevision(current) {
        return window.workspaceDomain?.revisionOf?.(current.files || {}) || "";
    }

    function readinessFor(current, report) {
        const revision = canonicalRevision(current);
        const recordedRevision = String(current.revision || "");
        if (recordedRevision && recordedRevision !== revision) return "stale-after-change";
        if (report.blocking) return "technical-blocked";
        if (report.productionEvidenceReady) return "production-ready";
        if (report.results.length) return "technically-passed";
        return "draft";
    }

    function setStatus(id, message, state = "") {
        const element = get(id);
        if (!element) return;
        element.textContent = message;
        if (state) element.dataset.state = state;
        else delete element.dataset.state;
    }

    function load() {
        checkpoints = [];
        try {
            const saved = JSON.parse(localStorage.getItem(projectStorageKey()) || "[]");
            checkpoints = (Array.isArray(saved) ? saved : [])
                .filter((item) => item && typeof item === "object" && item.snapshot && typeof item.snapshot === "object")
                .slice(0, MAX_CHECKPOINTS);
        } catch {
            // Corrupt or unavailable local storage should not prevent release review.
        }
        renderCheckpoints();
    }

    function persist() {
        try {
            localStorage.setItem(projectStorageKey(), JSON.stringify(checkpoints));
            return true;
        } catch {
            setStatus("checkpoint-status", "Checkpoint could not be saved in this browser.", "fail");
            return false;
        }
    }

    function renderCheckpoints() {
        const selector = get("checkpoint-selector");
        if (!selector) return;
        selector.replaceChildren(...(checkpoints.length
            ? checkpoints.map((item) => {
                const option = document.createElement("option");
                option.value = String(item.id || "");
                const createdAt = new Date(item.createdAt);
                const dateLabel = Number.isNaN(createdAt.getTime()) ? "saved date unavailable" : createdAt.toLocaleString();
                option.textContent = `${String(item.name || "Unnamed checkpoint")} · ${dateLabel}`;
                return option;
            })
            : [Object.assign(document.createElement("option"), { value: "", textContent: "No checkpoints saved" })]));
        const restore = get("restore-checkpoint-btn");
        if (restore) restore.disabled = !checkpoints.length || !selector?.value;
    }

    function saveCheckpoint() {
        const snapshot = state();
        if (!Object.keys(snapshot.files || {}).some((name) => /\.html$/i.test(name) && String(snapshot.files[name]).trim())) {
            setStatus("checkpoint-status", "Create or import a website before saving a checkpoint.", "fail");
            return;
        }
        const name = get("checkpoint-name-input")?.value.trim() || `Checkpoint ${checkpoints.length + 1}`;
        let snapshotCopy;
        try {
            snapshotCopy = JSON.parse(JSON.stringify(snapshot));
        } catch {
            setStatus("checkpoint-status", "Checkpoint could not be created from the current project state.", "fail");
            return;
        }
        const previousCheckpoints = checkpoints;
        checkpoints = [{
            id: `checkpoint-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            name,
            createdAt: new Date().toISOString(),
            snapshot: snapshotCopy
        }, ...checkpoints].slice(0, MAX_CHECKPOINTS);
        if (!persist()) {
            checkpoints = previousCheckpoints;
            renderCheckpoints();
            return;
        }
        renderCheckpoints();
        const nameInput = get("checkpoint-name-input");
        if (nameInput) nameInput.value = "";
        setStatus("checkpoint-status", `Saved “${name}”.`, "pass");
    }

    function restoreCheckpoint() {
        const item = checkpoints.find((entry) => entry.id === get("checkpoint-selector")?.value);
        if (!item || !window.workspaceAPI?.applySnapshot) return;
        if (!window.confirm(`Restore “${item.name}”? Current unsaved changes will be replaced.`)) return;
        window.workspaceAPI.applySnapshot(item.snapshot, { dirty: true });
        setStatus("checkpoint-status", `Restored “${item.name}”.`, "pass");
    }

    function releaseReview() {
        const current = state();
        const files = current.files || {};
        const rawProfile = current.businessProfile || window.profileService?.readLocal?.() || null;
        const profile = rawProfile && window.profileService?.normalize?.(rawProfile) || rawProfile;
        const profileValidation = profile && window.businessProfile?.validateProfile
            ? window.businessProfile.validateProfile(profile)
            : null;
        const profileReview = profile && window.profileService?.governance
            ? ["website", "seo"].map((surface) => ({ surface, ...window.profileService.governance(profile, surface) }))
            : [];
        const profileBlockers = profileReview.flatMap((review) => (review.blocking || []).map((item) => ({ ...item, surface: review.surface })));
        const profileValidationIssues = profileValidation && !profileValidation.valid
            ? profileValidation.issues.map((item) => ({ ...item, message: `${item.field || "Profile"} needs attention before publishing.` }))
            : [];
        const htmlFiles = Object.entries(files).filter(([name]) => /\.html$/i.test(name));
        const currentRevision = canonicalRevision(current);
        const results = [];
        const resultKeys = new Set();
        const findingMetadata = (pass, message, priority, key) => {
            const identity = String(key || message || "release-check");
            const fileHints = {
                "references": "index.html",
                "forms": "netlify/functions/submit-form.js",
                "domain": "index.html",
                "production-canonical": "index.html",
                "deployment-verification": "deployment evidence",
                "deployment-revision": "deployment evidence",
                "real-form-delivery": "production form evidence",
                "form-test-revision": "form test evidence",
                "privacy": "privacy.html",
                "structured-data": "index.html",
                "performance-budget": "generated assets",
                "analytics-consent": "index.html"
            };
            const category = identity.includes("form") ? "forms"
                : identity.includes("deploy") || identity.includes("domain") || identity.includes("canonical") ? "deployment"
                    : identity.includes("privacy") ? "privacy"
                        : identity.includes("performance") ? "performance"
                            : identity.includes("profile") ? "business profile"
                                : identity.includes("schema") || identity.includes("structured") ? "metadata" : "quality";
            const stale = ["deployment-revision", "form-test-revision"].includes(identity)
                || (current.revision && current.revision !== currentRevision);
            const evidenceState = stale ? "stale" : pass ? "verified" : "missing";
            const automatic = ["performance-budget", "analytics-consent"].includes(identity);
            return {
                category,
                source: "workspace-release",
                severity: priority === "high" ? "blocking" : priority === "medium" ? "warning" : "recommendation",
                affected: fileHints[identity] || "generated project",
                section: identity.includes("profile") ? "Business profile" : identity.includes("form") ? "Contact form" : "Release review",
                remediation: pass ? "No action required." : message,
                fixType: automatic ? "automatic-or-manual" : "manual",
                evidenceState,
                revisionState: stale ? "stale" : "current",
                revision: currentRevision
            };
        };
        const add = (pass, message, priority = "medium", key = "") => {
            const identity = key || `${priority}:${message}`;
            if (resultKeys.has(identity)) return;
            resultKeys.add(identity);
            results.push({ pass: Boolean(pass), message, priority, key, ...findingMetadata(pass, message, priority, identity) });
        };
        profileValidationIssues.forEach((item) => add(false, `Profile: ${item.message}`, "high", `profile-validation-${item.code}-${item.field || "profile"}`));
        profileBlockers.forEach((item) => add(false, `${item.surface}: ${item.message} ${item.remediation || "Approve or update the claim before publishing."}`, "high", `profile-${item.code}-${item.claimId}-${item.surface}`));
        if (profile && !window.profileService?.governance) add(false, "Canonical profile governance is unavailable. Load the profile service before publishing.", "high", "profile-governance-unavailable");
        const homepage = String(files["index.html"] || "");
        const schemaFindings = window.workspaceSchema?.validate?.(homepage) || [];
        schemaFindings.forEach((item) => add(false, `Schema: ${item.message}`, item.severity === "error" ? "high" : "medium", item.code));
        const formEndpoint = get("input-form-endpoint")?.value.trim() || "/api/submit-form";
        const latestDeployment = current.deploymentHistory?.[0] || null;
        const latestVerification = latestDeployment?.verification || null;
        const verificationRevision = String(latestVerification?.revision || latestDeployment?.manifest?.revision || "");
        const verificationMatchesCurrent = Boolean(verificationRevision && verificationRevision === currentRevision);
        const realDeliveryConfirmed = Boolean(get("production-form-delivery-confirmed")?.checked);
        const formTestRevision = String(current.formTestRevision || "");
        const formEvidenceMatchesCurrent = Boolean(formTestRevision && formTestRevision === currentRevision);
        const publishedUrl = get("published-site-url-input")?.value.trim() || "";
        let validPublishedUrl = false;
        try {
            const parsed = new URL(publishedUrl);
            validPublishedUrl = parsed.protocol === "https:" && Boolean(parsed.hostname) && !parsed.username && !parsed.password && !parsed.search && !parsed.hash;
        } catch {}
        const hasPrivacyPage = Boolean(files["privacy.html"]?.trim());
        const canonicalMatchesProduction = htmlFiles.every(([, html]) => {
            const canonicalMatch = String(html).match(new RegExp(String.raw`<link\b[^>]+rel=["']([^"']*canonical[^"']*)["'][^>]+href=["']([^"']+)["']`, "i"));
            const canonical = canonicalMatch?.[2] || "";
            return /^https:\/\//i.test(canonical) && canonical.startsWith(publishedUrl);
        });
        const performanceBudget = { htmlBytes: 100000, cssBytes: 50000, jsBytes: 75000, imageCount: 12 };
        if (!htmlFiles.length) {
            add(false, "Create or import at least one HTML page.", "high");
        } else {
            add(Boolean(files["index.html"]?.trim()), "Project includes index.html.", "high");
            htmlFiles.forEach(([name, html]) => {
                const source = String(html || "");
                const images = [...source.matchAll(/<img\b[^>]*>/gi)].map((match) => match[0]);
                const externalScripts = /<script\b[^>]+src=["'][^"']*https?:/i.test(source);
                add(!images.some((image) => !/\balt=["']/i.test(image)), `${name}: images have alternative text.`, "high");
                add(!externalScripts, `${name}: no external scripts bypass the generated security boundary.`, "high");
                add(/<meta\b[^>]+name=["']viewport/i.test(source), `${name}: responsive viewport is present.`, "medium");
                add(/<title\b[^>]*>\s*[^<\s][\s\S]*?<\/title>/i.test(source), `${name}: page title is present and non-empty.`, "high");
            });
            const css = String(files["style.css"] || "");
            const js = String(files["script.js"] || "");
            const htmlBytes = new TextEncoder().encode(homepage).length;
            const cssBytes = new TextEncoder().encode(css).length;
            const jsBytes = new TextEncoder().encode(js).length;
            const imageBytes = [...homepage.matchAll(/<img\b[^>]*>/gi)].length;
            const performanceBudgetPasses = htmlBytes <= 100000 && cssBytes <= 50000 && jsBytes <= 75000 && imageBytes <= 12;
            add(performanceBudgetPasses, performanceBudgetPasses
                ? `Generated files are within the launch budgets (${Math.round((htmlBytes + cssBytes + jsBytes) / 1000)} KB source; ${imageBytes} images).`
                : `Performance budget exceeded: ${Math.round(htmlBytes / 1000)} KB HTML, ${Math.round(cssBytes / 1000)} KB CSS, ${Math.round(jsBytes / 1000)} KB JavaScript, or ${imageBytes} images.`, "high", "performance-budget");
            const stylesheetPasses = css.length < 50000;
            add(stylesheetPasses, stylesheetPasses
                ? `Stylesheet is ${Math.round(css.length / 1000)} KB, below the 50 KB review threshold.`
                : `Stylesheet is ${Math.round(css.length / 1000)} KB, exceeding the 50 KB review threshold; reduce unused rules before launch.`, "medium");
            const assetUrls = htmlFiles.flatMap(([, html]) => [...String(html).matchAll(/\b(?:src|href)=["']([^"']+)["']/gi)].map((match) => match[1])).filter((url) => /^https?:\/\//i.test(url));
            const assetCountPasses = assetUrls.length < 25;
            add(assetCountPasses, assetCountPasses
                ? `${assetUrls.length} external assets referenced; keep the page focused and fast.`
                : `${assetUrls.length} external assets are referenced; reduce third-party requests to improve loading speed.`, "low");
            add(Boolean(files["netlify.toml"]?.trim()), "Deployment configuration is included.", "high");
            const privacyMode = get("input-privacy-analytics")?.value || "essential";
            add(privacyMode === "essential" || /morrow-analytics-consent|analytics_events/i.test(homepage), privacyMode === "essential" ? "Analytics is configured for essential-only behavior." : "Analytics is configured with explicit visitor consent.", "medium", "analytics-consent");
            add(Boolean(homepage.match(/<a\b[^>]+href=["'][^"']+(?:#contact|tel:|mailto:|https?:\/\/)[^"']*["']/i) || homepage.match(/<form\b[^>]+action=["'][^"']+["']/i)), "Homepage has a connected primary conversion path.", "high");
            add(Boolean(homepage.match(/dataLayer|site:conversion|cta_click/i)), "Conversion events are wired for CTA measurement.", "medium");
            add(Boolean(homepage.match(/<meta\b[^>]+property=["']og:title["']/i) && homepage.match(/<meta\b[^>]+property=["']og:description["']/i)), "Social sharing metadata is complete.", "medium");
            let structuredDataPasses = false;
            try {
                const structuredDataNode = new DOMParser()
                    .parseFromString(homepage, "text/html")
                    .querySelector('script[type="application/ld+json"]');
                const structured = structuredDataNode ? JSON.parse(structuredDataNode.textContent || "") : null;
                structuredDataPasses = Boolean(structured && structured["@context"] === "https://schema.org" && structured["@type"] && structured.name);
            } catch {}
            add(structuredDataPasses, structuredDataPasses ? "Structured data contains a schema.org context, type, and name." : "Structured data is missing or needs schema.org validation.", "medium", "structured-data");
            const brokenReferences = window.workspaceAudit?.auditProject?.(files)?.blocking?.filter((item) => item.code === "MISSING_LOCAL_REFERENCE") || window.workspaceCore?.brokenLocalReferences?.(files) || [];
            add(!brokenReferences.length,
                brokenReferences.length
                    ? `Missing local references: ${brokenReferences.slice(0, 4).map((item) => `${item.file} → ${item.target || "unknown target"}`).join(", ")}${brokenReferences.length > 4 ? "…" : ""}.`
                    : "Local page and asset references resolve.",
                "high",
                "references"
            );
        }
        const sharedAudit = window.workspaceAudit?.auditProject?.(files);
        const renderedAudit = window.workspaceAudit?.auditRenderedDocument?.(get("previewContentIframe")?.contentDocument || null);
        renderedAudit?.issues?.slice(0, 8).forEach((item) => add(false, item.message, item.severity === "error" ? "high" : "medium", item.code));
        if (sharedAudit?.blocking?.length) {
            sharedAudit.blocking.slice(0, 8).forEach((item) => add(false, item.message, "high", item.code));
        }
        if (sharedAudit?.warnings?.length) {
            sharedAudit.warnings.slice(0, 6).forEach((item) => add(false, item.message, "medium", item.code));
        }
        const generatedFormEndpoint = Boolean(files["netlify/functions/submit-form.js"]?.trim());
        const knownSameOriginEndpoint = /^\/(?:api\/submit-form|\.netlify\/functions\/submit-form)(?:\?.*)?$/i.test(formEndpoint);
        const customEndpointVerified = knownSameOriginEndpoint && generatedFormEndpoint;
        add(
            formEndpoint === "/api/submit-form"
                ? generatedFormEndpoint
                : customEndpointVerified,
            formEndpoint === "/api/submit-form"
                ? "Form route is configured for technical testing; real inbox or CRM delivery still requires confirmation after deployment."
                : customEndpointVerified
                    ? "Custom same-origin form endpoint is recognized for technical testing; confirm real delivery after deployment."
                    : "Form delivery is not verified. Use the generated submit-form route or include and test a matching server function.",
            "high",
            "forms"
        );
                    add(validPublishedUrl, validPublishedUrl ? "Published HTTPS URL is configured." : "Add the final HTTPS published URL before launch.", "high", "domain");
            add(canonicalMatchesProduction, canonicalMatchesProduction ? "Canonical URLs use the configured production domain." : "Replace preview or relative canonical URLs with absolute HTTPS production canonicals before publishing.", "high", "production-canonical");
        if (validPublishedUrl && latestVerification) {
            add(Boolean(latestVerification.success), latestVerification.success ? "Latest published site verification passed." : "Latest published site verification found blocking issues.", "high", "deployment-verification");
            add(verificationMatchesCurrent, verificationMatchesCurrent ? "Verification evidence matches the current project revision." : "Verification evidence is stale or missing a matching project revision. Re-run verification after the latest change.", "high", "deployment-revision");
        } else if (validPublishedUrl) {
            add(false, "Verify the published site before sharing it.", "high", "deployment-verification");
        }
        add(realDeliveryConfirmed, realDeliveryConfirmed
            ? "Real production form delivery was confirmed in the inbox or CRM."
            : "Submit a real production enquiry and confirm inbox or CRM receipt; a technical HTTP test is not enough.", "high", "real-form-delivery");
        add(formEvidenceMatchesCurrent, formEvidenceMatchesCurrent ? "Form test evidence matches the current project revision." : "Form test evidence is stale or missing a matching project revision. Re-run the form test after the latest change.", "high", "form-test-revision");
                    add(hasPrivacyPage, hasPrivacyPage ? "A privacy policy page is included for review." : "Create and review privacy.html before launch.", "high", "privacy");
            const analyticsMode = get("input-privacy-analytics")?.value || "essential";
            const analyticsConfigured = analyticsMode === "essential" || Boolean(homepage.match(/morrow-analytics-consent|analytics_events|dataLayer/i));
            add(analyticsConfigured, analyticsConfigured ? "Analytics behavior is explicit and consent-aware." : "Review analytics settings before publishing; analytics must be explicit and consent-aware.", "medium", "analytics-consent");
        const passed = results.filter((item) => item.pass).length;
        const blocking = results.filter((item) => !item.pass && item.priority === "high");
        const productionEvidenceReady = Boolean(
            !blocking.length &&
            validPublishedUrl &&
            canonicalMatchesProduction &&
            latestVerification?.success &&
            verificationMatchesCurrent &&
            formEvidenceMatchesCurrent &&
            realDeliveryConfirmed
        );
        const score = results.length ? Math.round((passed / results.length) * 100) : 0;
        const report = {
            model: "Evidence",
            version: window.workspaceDomain?.MODEL_VERSION || 1,
            results,
            score,
            passed,
            blocking: blocking.length,
            productionEvidenceReady,
            evidenceLimits: {
                score: "Technical review coverage only; it does not predict conversions or guarantee launch quality.",
                forms: "Endpoint acceptance does not prove inbox or CRM delivery until a real production enquiry is confirmed.",
                responsive: "Rendered checks cover the configured preview scenarios, not every device, browser, or network condition.",
                import: "Import preparation and difference reporting do not prove pixel-perfect visual fidelity.",
                benchmark: "Benchmark results describe this workspace's measured evidence and are not an external competitor ranking.",
                production: "Production-ready requires successful deployment verification and confirmed real form delivery."
            },
            revision: currentRevision,
            readiness: readinessFor(current, { blocking: blocking.length, productionEvidenceReady, results }),
            evidenceKind: "static",
            testedFiles: Object.keys(files),
            limitations: [
                "Technical review coverage only; not a conversion guarantee.",
                "Configured responsive scenarios are not full device coverage.",
                "Technical form acceptance does not prove inbox or CRM delivery."
            ]
        };
        window.dispatchEvent(new CustomEvent("workspace:release-evidence", { detail: report }));
        return report;
    }

    function renderImportDifference(report = null) {
        const score = get("import-difference-score");
        const list = get("import-difference-results");
        if (!report) {
            if (score) score.textContent = "Not available";
            return;
        }
        const items = Array.isArray(report.items) ? report.items : [];
        if (score) score.textContent = `${report.preserved || 0} preserved · ${report.review || 0} review`;
        if (list) list.replaceChildren(...items.map((item) => {
            const row = document.createElement("li");
            row.dataset.state = item.state === "preserved" ? "pass" : "warn";
            row.textContent = `${item.state === "preserved" ? "PRESERVED" : "REVIEW"} — ${item.message}`;
            return row;
        }));
    }

    function renderReview() {
        const report = releaseReview();
        const score = get("release-review-score");
        const list = get("release-review-results");
        if (score) {
            score.textContent = report.results.length ? `${report.score}/100` : "Pending";
            score.title = report.evidenceLimits?.score || "Technical review coverage only; not a conversion guarantee.";
        }
        const gate = get("release-review-gate");
        if (gate) {
            gate.textContent = report.blocking
                ? `${report.blocking} launch blocker${report.blocking === 1 ? "" : "s"}`
                : report.productionEvidenceReady ? "Production evidence complete" : report.score >= 90 ? "Technical review passed" : "Review recommended";
            gate.dataset.state = report.blocking ? "fail" : report.productionEvidenceReady ? "pass" : "warn";
            gate.setAttribute("aria-label", report.blocking ? "Launch review has blocking issues" : report.productionEvidenceReady ? "Production evidence is complete" : "Technical review needs production evidence");
        }
        const nextAction = get("release-review-next-action");
        const firstBlocker = report.results.find((item) => !item.pass);
        if (nextAction) nextAction.textContent = firstBlocker
            ? `Next action: ${firstBlocker.message}`
            : report.productionEvidenceReady
                ? "Production evidence complete. Recheck after any material change."
                : report.results.length
                    ? "Next action: verify the published site and confirm real form delivery."
                    : "Create or import a website first.";
        const actions = get("release-review-actions");
        if (actions) {
            actions.replaceChildren();
            if (firstBlocker) {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "matrix-action-btn variant-outline-row";
                button.textContent = "Open relevant tools";
                button.addEventListener("click", () => get("advanced-workspace-tools")?.removeAttribute("hidden"));
                actions.append(button);
            }
        }
        if (list) list.replaceChildren(...(report.results.length ? report.results : [{ pass: false, message: "Create or import a website first.", priority: "high" }]).map((item) => {
            const row = document.createElement("li");
            row.dataset.state = item.pass ? "pass" : item.priority === "high" ? "fail" : "warn";
            row.textContent = `${item.pass ? "PASS" : "REVIEW"} — ${item.message}`;
            row.title = `${item.severity || "warning"} · ${item.source || "release review"} · ${item.affected || "generated project"} · ${item.evidenceState || "missing"} evidence · ${item.revisionState || "current"} revision · ${item.fixType || "manual"} fix`;
            if (!item.pass) {
                const detail = document.createElement("small");
                detail.textContent = `Fix: ${item.remediation || "Review this finding."}`;
                row.append(document.createElement("br"), detail);
            }
            return row;
        }));
        return report;
    }

    async function assertReleasePublishable(surface = "website") {
        const current = state();
        const rawProfile = current.businessProfile || window.profileService?.readLocal?.() || null;
        if (!rawProfile || !window.profileService?.assertPublishable) {
            throw new Error("A canonical business profile is required before publishing.");
        }
        const profile = window.profileService.normalize(rawProfile);
        return window.profileService.assertPublishable(profile, surface, { actor: "release" });
    }

    function exportReport() {
        const report = renderReview();
        const health = window.projectHealth?.calculate?.() || null;
        const payload = {
            generatedAt: new Date().toISOString(),
            projectName: state().projectName || "Untitled project",
            releaseReview: report,
            evidenceLimits: report.evidenceLimits,
            projectHealth: health,
            files: Object.fromEntries(Object.entries(state().files || {}).map(([name, content]) => [name, { bytes: new TextEncoder().encode(String(content || "")).length }]))
        };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = `${(payload.projectName || "website").replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-health-report.json`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 0);
    }

    async function testFormEndpoint() {
        const endpoint = get("input-form-endpoint")?.value.trim() || "/api/submit-form";
        const sameOriginPath = /^\/(?!\/)[^\s<>"']{1,280}$/.test(endpoint);
        if (!sameOriginPath && !/^https:\/\//i.test(endpoint)) {
            setStatus("form-endpoint-test-status", "Use a same-origin path such as /api/submit-form or an external HTTPS endpoint.", "fail");
            return;
        }
        setStatus("form-endpoint-test-status", "Sending a clearly marked technical test…");
        try {
            const result = sameOriginPath
                ? await fetch(endpoint, {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", Accept: "application/json", "X-Workspace-Test": "true" },
                    body: new URLSearchParams({ name: "Morrow technical test", email: "test@example.invalid", message: "Technical form setup test — no customer action is required.", website: "" }),
                    credentials: "same-origin"
                }).then(async (response) => ({
                    success: response.ok,
                    message: response.ok
                        ? `Built-in form route accepted the technical test (HTTP ${response.status}). Confirm real delivery in the production inbox or CRM.`
                        : `Built-in form route rejected the technical test (HTTP ${response.status}).`
                }))
                : await fetch("/api/test-form-endpoint", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ endpoint }) }).then((response) => response.json().catch(() => ({ success: false, error: `Test route returned HTTP ${response.status}.` })));
            const message = result.message || result.error || (result.success ? "Technical endpoint test passed." : "Technical endpoint test failed.");
            if (result.success) {
                const liveState = window.workspaceAPI?.getState?.();
                const revision = liveState ? canonicalRevision(liveState) : "";
                window.workspaceAPI?.setFormTestRevision?.(revision);
                if (revision) window.dispatchEvent(new CustomEvent("workspace:form-test-complete", { detail: { revision } }));
            }
            setStatus("form-endpoint-test-status", message, result.success ? "pass" : "fail");
        } catch (error) {
            setStatus("form-endpoint-test-status", error?.message || "Technical endpoint test failed.", "fail");
        }
    }

    function testFormSetup() {
        const status = get("form-test-status");
        const files = state().files || {};
        const html = String(files["index.html"] || "");
        const endpoint = get("input-form-endpoint")?.value.trim() || "";
        const hasForm = /<form\b/i.test(html);
        const hasAction = /<form\b[^>]*\baction=["'][^"']+["']/i.test(html);
        const configured = endpoint === "/api/submit-form"
            ? Boolean(files["netlify/functions/submit-form.js"])
            : /^\/(?:api\/submit-form|\.netlify\/functions\/submit-form)(?:\?.*)?$/i.test(endpoint);
        const message = !hasForm ? "No contact form is present to test." : !hasAction ? "The generated form is missing a submission endpoint." : !configured ? "Configure production form delivery before publishing." : "Form setup looks ready. Submit a real test enquiry after deployment.";
        if (status) { status.textContent = message; status.dataset.state = !hasForm || !hasAction || !configured ? "fail" : "pass"; }
        return { hasForm, hasAction, configured };
    }

    function bind() {
        load();
        window.addEventListener("workspace:project-context-cleared", () => {
            checkpoints = [];
            renderCheckpoints();
        });
        window.addEventListener("workspace:project-context-changed", load);
        window.addEventListener("workspace:project-id-change", load);
        get("run-release-review-btn")?.addEventListener("click", renderReview);
        get("verify-deployment-btn")?.addEventListener("click", renderReview);
        get("test-form-setup-btn")?.addEventListener("click", testFormSetup);
        get("test-form-endpoint-btn")?.addEventListener("click", testFormEndpoint);
        get("export-health-report-btn")?.addEventListener("click", exportReport);
        get("save-checkpoint-btn")?.addEventListener("click", saveCheckpoint);
        get("restore-checkpoint-btn")?.addEventListener("click", restoreCheckpoint);
        get("checkpoint-selector")?.addEventListener("change", () => {
            const selector = get("checkpoint-selector");
            const restore = get("restore-checkpoint-btn");
            if (restore) restore.disabled = !selector?.value;
        });
        get("previewContentIframe")?.addEventListener("load", () => setTimeout(renderReview, 150));
        window.addEventListener("workspace:deployment-complete", renderReview);
        renderReview();
        renderImportDifference();
        window.addEventListener("workspace:import-report", (event) => {
            renderImportDifference(event.detail || null);
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true }); else bind();
    window.workspaceRelease = Object.freeze({ releaseReview, renderReview, saveCheckpoint, assertReleasePublishable });
})();
