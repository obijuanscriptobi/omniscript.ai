"use strict";

// Responsive QA for generated projects. The static pass is deterministic and can
// run without an iframe; the runtime pass measures the actual preview document at
// representative fluid viewport widths.
(() => {
    const VIEWPORTS = Object.freeze([320, 360, 375, 414, 480, 600, 768, 834, 1024, 1280, 1440]);
    const MAX_ISSUES = 40;

    const issue = (code, message, severity = "warning", width = null) => ({
        code,
        category: "responsive",
        severity,
        width,
        message
    });

    function auditResponsiveSource(html = "", css = "") {
        const source = String(html || "");
        const stylesheet = String(css || "");
        const issues = [];
        const add = (...args) => {
            if (issues.length < MAX_ISSUES) issues.push(issue(...args));
        };

        if (!/<meta\b[^>]+name=["']viewport["'][^>]+content=["'][^"']*width\s*=\s*device-width/i.test(source)) {
            add("RESPONSIVE_VIEWPORT_META", "Add a device-width viewport declaration for mobile-first scaling.", "error");
        }
        if (/\b(?:width|min-width)\s*:\s*(?:[6-9]\d{2}|[1-9]\d{3,})px\b/i.test(stylesheet)) {
            add("RESPONSIVE_FIXED_WIDTH", "A large fixed width can exceed narrow viewports; use max-width: 100% or a fluid minmax() track.");
        }
        if (/(?:display\s*:\s*grid|display\s*:\s*flex)[\s\S]{0,500}?\b(?:grid-template-columns|flex-wrap)\s*:/i.test(stylesheet) && !/flex-wrap\s*:\s*wrap/i.test(stylesheet)) {
            add("RESPONSIVE_UNWRAPPED_LAYOUT", "A flex/grid-like layout has no visible wrapping fallback; verify it cannot preserve desktop width on mobile.");
        }
        if (/white-space\s*:\s*nowrap/i.test(stylesheet) && !/overflow(?:-x)?\s*:\s*(?:auto|hidden|clip)/i.test(stylesheet)) {
            add("RESPONSIVE_NOWRAP", "nowrap content needs an intentional overflow strategy or it can widen the page.");
        }
        if (/(?:grid-template-columns|grid-template-areas)\s*:[^;{}]*(?:repeat\(\s*\d+\s*,\s*1fr\)|\d+\s*fr)/i.test(stylesheet) && !/@media\s*\([^)]*(?:max-width|width)/i.test(stylesheet)) {
            add("RESPONSIVE_DESKTOP_GRID", "A multi-column grid has no detected narrow-screen rule; add a one-column or auto-fit fallback.");
        }
        if (/<(?:table|pre|code)\b/i.test(source) && !/overflow(?:-x)?\s*:\s*auto/i.test(stylesheet)) {
            add("RESPONSIVE_LONG_CONTENT", "Tables or preformatted content need a bounded overflow container on mobile.");
        }
        if (/<(?:img|video|iframe|svg)\b/i.test(source) && !/(?:img|video|iframe|svg)[^{]*\{[^}]*max-width\s*:\s*100%/is.test(stylesheet)) {
            add("RESPONSIVE_MEDIA_BOUND", "Media elements should have max-width: 100% and height: auto to avoid horizontal overflow.");
        }
        if (/font-size\s*:\s*\d{2,}px/i.test(stylesheet) && !/clamp\(|@media\s*\([^)]*max-width/i.test(stylesheet)) {
            add("RESPONSIVE_TYPE_SCALE", "Large fixed typography should use clamp() or a narrow-screen adjustment so text remains readable.");
        }
        if (/(?:margin|left|right|translate(?:X)?|width)\s*:[^;{}]*(?:100vw|calc\([^)]*100vw)/i.test(stylesheet) && !/max-width\s*:\s*100%/i.test(stylesheet)) {
            add("RESPONSIVE_VIEWPORT_UNIT", "A viewport-sized value may exceed the body when scrollbars or padding are present; pair it with a bounded max-width.");
        }
        return issues;
    }

    function auditPreviewDocument(documentNode, widths = VIEWPORTS) {
        if (!documentNode?.documentElement || !documentNode.body) {
            return [issue("RESPONSIVE_PREVIEW_UNAVAILABLE", "The preview document is not ready for responsive measurement.", "error")];
        }
        const root = documentNode.documentElement;
        const body = documentNode.body;
        const results = [];
        const original = {
            rootWidth: root.style.width,
            bodyWidth: body.style.width,
            bodyOverflow: body.style.overflowX
        };
        const probe = documentNode.defaultView;
        const uniqueWidths = [...new Set(widths.map(Number).filter((width) => width >= 320 && width <= 1440))];

        try {
            uniqueWidths.forEach((width) => {
                root.style.width = `${width}px`;
                body.style.width = "100%";
                body.style.overflowX = "visible";
                const scrollWidth = Math.max(root.scrollWidth || 0, body.scrollWidth || 0);
                const clientWidth = root.clientWidth || width;
                if (scrollWidth > clientWidth + 1) {
                    results.push(issue("RESPONSIVE_HORIZONTAL_OVERFLOW", `Preview content is ${scrollWidth - clientWidth}px wider than the viewport at ${width}px.`, width <= 480 ? "error" : "warning", width));
                }
                const offenders = [...body.querySelectorAll("*")].filter((element) => {
                    const rect = element.getBoundingClientRect();
                    return rect.width > width + 1 || rect.right > width + 1 || rect.left < -1;
                }).slice(0, 5);
                offenders.forEach((element) => {
                    const label = element.id || element.className?.toString?.().split(/\s+/)[0] || element.tagName.toLowerCase();
                    results.push(issue("RESPONSIVE_WIDE_ELEMENT", `${label} exceeds the ${width}px preview viewport.`, width <= 480 ? "error" : "warning", width));
                });
                if (probe) probe.dispatchEvent(new CustomEvent("workspace:responsive-viewport-tested", { detail: { width, overflow: scrollWidth > clientWidth + 1 } }));
            });
        } finally {
            root.style.width = original.rootWidth;
            body.style.width = original.bodyWidth;
            body.style.overflowX = original.bodyOverflow;
        }
        return results.slice(0, MAX_ISSUES);
    }

    function runResponsiveAudit(files = {}, documentNode = null) {
        const sourceIssues = auditResponsiveSource(files["index.html"] || "", files["style.css"] || "");
        const runtimeIssues = documentNode ? auditPreviewDocument(documentNode) : [];
        const all = [...sourceIssues, ...runtimeIssues];
        const seen = new Set();
        return all.filter((entry) => {
            const key = `${entry.code}:${entry.width || ""}:${entry.message}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        }).slice(0, MAX_ISSUES);
    }

    window.workspaceResponsive = Object.freeze({
        VIEWPORTS,
        auditResponsiveSource,
        auditPreviewDocument,
        runResponsiveAudit
    });
})();
