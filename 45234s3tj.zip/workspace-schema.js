"use strict";

(() => {
    const TYPES = new Set(["LocalBusiness", "ProfessionalService", "Restaurant", "Store", "Organization", "Service", "FAQPage", "BreadcrumbList", "WebSite", "WebPage"]);
    const REQUIRED = {
        LocalBusiness: ["name"], ProfessionalService: ["name"], Restaurant: ["name"], Store: ["name"], Organization: ["name"],
        Service: ["name", "description"], FAQPage: ["mainEntity"], BreadcrumbList: ["itemListElement"], WebSite: ["name"], WebPage: ["name"]
    };
    function validate(html = "") {
        const findings = [];
        const scripts = [...String(html).matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)];
        if (!scripts.length) return [{ code: "SCHEMA_MISSING", severity: "warning", message: "Add valid schema.org JSON-LD for search understanding." }];
        scripts.forEach((match, index) => {
            let value;
            try { value = JSON.parse(match[1]); } catch { findings.push({ code: "SCHEMA_INVALID_JSON", severity: "error", message: `Structured-data block ${index + 1} is not valid JSON.` }); return; }
            const items = Array.isArray(value) ? value : value["@graph"] || [value];
            items.forEach((item) => {
                if (!item || item["@context"] !== "https://schema.org") findings.push({ code: "SCHEMA_CONTEXT", severity: "error", message: "Structured data must use the https://schema.org context." });
                if (!TYPES.has(item?.["@type"])) findings.push({ code: "SCHEMA_TYPE", severity: "warning", message: "Use a supported schema.org business type." });
                const type = String(item?.["@type"] || "");
                (REQUIRED[type] || ["name"]).forEach((field) => {
                    const present = item?.[field] !== undefined && item?.[field] !== null && (typeof item[field] !== "string" || item[field].trim());
                    if (!present) findings.push({ code: `SCHEMA_REQUIRED_${field.toUpperCase()}`, severity: "error", message: `${type || "Structured data"} should include ${field}.` });
                });
                if (item?.url && !/^https:\/\//i.test(item.url)) findings.push({ code: "SCHEMA_URL", severity: "warning", message: "Structured-data URLs should use HTTPS." });
                if (item?.image && !(Array.isArray(item.image) ? item.image : [item.image]).every((url) => /^https:\/\//i.test(String(url)))) findings.push({ code: "SCHEMA_IMAGE", severity: "warning", message: "Structured-data image URLs should use HTTPS." });
                if (item?.sameAs && (!Array.isArray(item.sameAs) || !item.sameAs.every((url) => /^https:\/\//i.test(String(url))))) findings.push({ code: "SCHEMA_SAME_AS", severity: "warning", message: "sameAs values should be HTTPS URLs." });
                if (item?.telephone && !/[0-9]{3}/.test(String(item.telephone))) findings.push({ code: "SCHEMA_PHONE", severity: "warning", message: "Review the structured-data telephone value." });
            });
        });
        return [...new Map(findings.map((item) => [item.code, item])).values()];
    }
    window.workspaceSchema = Object.freeze({ validate });
})();
