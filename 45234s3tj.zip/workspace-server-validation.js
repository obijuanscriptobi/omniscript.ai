"use strict";

// This module is shared by the browser editor and Netlify functions. Keep the
// boundary free of Node-only imports so the editor can load it safely.
const SAFE_PATH = /^[a-z0-9][a-z0-9._/-]*$/i;
const RESERVED = /(?:^|\/)\.\.?(?:\/|$)|\\|^\/|(?:^|\/)node_modules(?:\/|$)|^\.env(?:\.|$)/i;
const UNSAFE = /(?:javascript:|vbscript:|data:text\/html|data:application\/javascript)/i;

function textBytes(value) {
    const text = String(value ?? "");
    if (typeof TextEncoder === "function") return new TextEncoder().encode(text).byteLength;
    if (typeof Buffer !== "undefined" && typeof Buffer.byteLength === "function") return Buffer.byteLength(text, "utf8");
    return unescape(encodeURIComponent(text)).length;
}

// FNV-1a is intentionally used instead of a runtime-specific crypto API. It
// is deterministic in both the browser and Node and is used as a revision
// identity, not as a security signature.
function revision(files = {}, metadata = {}) {
    // Revision identity must match workspace-domain-model.revisionOf: file
    // content only. Snapshot metadata is validated separately and must not make
    // an otherwise identical project appear stale across browser/server paths.
    const input = Object.keys(files && typeof files === "object" ? files : {}).sort().map((name) => `${name}\u0000${String(files[name] ?? "")}`).join("\u0001");
    let hash = 2166136261;
    for (let index = 0; index < input.length; index += 1) {
        hash ^= input.charCodeAt(index);
        hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash.toString(16).padStart(8, "0");
}

function validateFiles(files = {}, options = {}) {
    const issues = [];
    if (!files || typeof files !== "object" || Array.isArray(files)) {
        return [{ code: "INVALID_FILES", message: "Project files must be an object." }];
    }
    for (const [name, value] of Object.entries(files)) {
        const source = String(value ?? "");
        if (!name || name.length > 240 || RESERVED.test(name) || !SAFE_PATH.test(name)) {
            issues.push({ code: "UNSAFE_FILE_PATH", file: name, message: `${name || "Unnamed file"} is not a safe project path.` });
        }
        if (textBytes(source) > 2_000_000) issues.push({ code: "FILE_TOO_LARGE", file: name, message: `${name} exceeds the per-file limit.` });
        if (UNSAFE.test(source) || /\bon[a-z]+\s*=/i.test(source) || /<(?:object|embed)\b/i.test(source) || /<script\b[^>]*src=["'](?:https?:|\/\/)/i.test(source)) {
            issues.push({ code: "UNSAFE_CONTENT", file: name, message: `${name} contains unsafe executable content or a dangerous URL.` });
        }
        if (/\.html?$/i.test(name) && /<iframe\b/i.test(source) && !options.allowIframes) {
            issues.push({ code: "UNTRUSTED_EMBED", file: name, message: `${name} contains an iframe that is not approved for deployment.` });
        }
    }
    if (!Object.keys(files).some((name) => /^index\.html$/i.test(name) && String(files[name]).trim())) issues.push({ code: "MISSING_REQUIRED_FILE", file: "index.html", message: "index.html is required for deployment." });
    if (options.requireDeploymentConfig && !String(files["netlify.toml"] || "").trim()) issues.push({ code: "MISSING_REQUIRED_FILE", file: "netlify.toml", message: "netlify.toml is required for deployment." });
    if (options.requireFormHandler && /<form\b/i.test(String(files["index.html"] || "")) && !String(files["netlify/functions/submit-form.js"] || "").trim()) issues.push({ code: "FORM_HANDLER_MISSING", file: "netlify/functions/submit-form.js", message: "A contact form requires the approved submit-form handler." });
    return [...new Map(issues.map((item) => [`${item.code}:${item.file || ""}`, item])).values()];
}

function validateRevision(files, supplied, metadata = {}) {
    const actual = revision(files, metadata);
    return { valid: !supplied || supplied === actual, actual, supplied: String(supplied || "") };
}

const api = { revision, validateFiles, validateRevision };
if (typeof module !== "undefined" && module.exports) module.exports = api;
if (typeof window !== "undefined") window.workspaceServerValidation = Object.freeze(api);
