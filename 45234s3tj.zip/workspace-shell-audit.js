"use strict";

// Dependency-free checks for the editor shell and generated project files.
(() => {
    function auditWorkspaceShell(root = document) {
        const findings = [];
        const add = (severity, message) => findings.push({ severity, message });
        const ids = new Map();

        root.querySelectorAll("[id]").forEach((element) => {
            ids.set(element.id, (ids.get(element.id) || 0) + 1);
        });
        [...ids.entries()].filter(([, count]) => count > 1).forEach(([id, count]) => {
            add("error", `Duplicate id #${id} appears ${count} times.`);
        });

        root.querySelectorAll("input, textarea, select").forEach((control) => {
            if (control.type === "hidden" || control.getAttribute("aria-hidden") === "true") return;
            const labelled = control.labels?.length || control.getAttribute("aria-label") || control.getAttribute("aria-labelledby");
            if (!labelled) add("error", `Form control ${control.id ? `#${control.id}` : control.tagName.toLowerCase()} has no accessible label.`);
        });

        root.querySelectorAll("button, a[href]").forEach((control) => {
            if (control.getAttribute("aria-hidden") === "true") return;
            const accessibleName = control.textContent?.trim()
                || control.getAttribute("aria-label")
                || control.getAttribute("aria-labelledby")
                || control.getAttribute("title");
            if (!accessibleName) {
                add("error", `${control.tagName.toLowerCase()}${control.id ? ` #${control.id}` : ""} has no accessible name.`);
            }
        });

        if (!root.querySelector("main")) add("error", "The workspace shell is missing a main landmark.");
        if (!root.querySelector("h1")) add("warning", "The workspace shell has no primary h1 heading.");
        return findings;
    }

    function auditFiles(files = {}) {
        const findings = [];
        const knownFiles = new Set(Object.keys(files));
        Object.entries(files).filter(([filename]) => /\.html$/i.test(filename)).forEach(([filename, source]) => {
            const links = [...String(source || "").matchAll(/<a\b[^>]*href=["']([^"']+)["']/gi)].map((match) => match[1]);
            links.forEach((href) => {
                const path = href.split(/[?#]/)[0].replace(/^\.\//, "");
                if (/^[^/]+\.html$/i.test(path) && !knownFiles.has(path)) {
                    findings.push({ severity: "error", message: `${filename} links to missing ${path}.` });
                }
            });
        });
        return findings;
    }

    function auditHeadings(files = {}) {
        const findings = [];
        Object.entries(files).filter(([filename]) => /\.html$/i.test(filename)).forEach(([filename, source]) => {
            const headings = [...String(source || "").matchAll(/<h([1-6])\b/gi)].map((match) => Number(match[1]));
            if (headings.length && headings.filter((level) => level === 1).length !== 1) {
                findings.push({ severity: "error", message: `${filename} should contain exactly one h1.` });
            }
            headings.slice(1).forEach((level, index) => {
                if (level - headings[index] > 1) {
                    findings.push({ severity: "warning", message: `${filename} skips from h${headings[index]} to h${level}.` });
                }
            });
        });
        return findings;
    }

    window.workspaceShellAudit = { auditWorkspaceShell, auditFiles, auditHeadings };
})();
