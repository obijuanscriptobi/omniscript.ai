"use strict";

// Browser-safe validation for projects before they enter the workspace state.
(() => {
    const isHtmlFile = (filename) => /\.html?$/i.test(filename || "");
    const sharedAudit = () => window.workspaceAudit || null;
    const isJavaScriptFile = (filename) => /\.js$/i.test(filename || "");
    const pageFiles = (files) => Object.keys(files).filter(isHtmlFile);
    const isLocalReference = (value) => {
        const target = String(value || "").trim();
        return Boolean(target) && target !== "/" && !target.startsWith("#") && !/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(target);
    };
    const resolveReference = (filename, value) => {
        try {
            return decodeURIComponent(new URL(String(value).split(/[?#]/)[0], `https://workspace.invalid/${filename}`).pathname).replace(/^\/+/, "");
        } catch {
            return String(value).split(/[?#]/)[0].replace(/^\.\//, "").replace(/^\/+/, "");
        }
    };

    function addPageIssues(issues, filename, html, files) {
        const label = filename === "index.html" ? "Generated index.html" : `Generated ${filename}`;
        if (!/^<!doctype\s+html>/i.test(html.trim())) {
            issues.push(`Add <!DOCTYPE html> at the top of ${filename} so browsers render in standards mode.`);
        }
        if (!/<html\b[^>]*\blang=["'][^"']+["']/i.test(html)) {
            issues.push(`Add lang="en" (or the page language) to the <html> tag in ${filename} so screen readers pronounce the copy correctly.`);
        }
        if ((html.match(/<h1[\s>]/gi) || []).length !== 1) {
            issues.push(`Give ${filename} exactly one H1 that states the customer outcome, then use H2s for supporting sections.`);
        }
        if (!/<meta\b[^>]+name=["']viewport["']/i.test(html)) {
            issues.push(`Add <meta name="viewport" content="width=device-width, initial-scale=1"> to ${filename} so the layout fits mobile screens.`);
        }
        if (!/<title\b[^>]*>\s*[^<]+/i.test(html)) {
            issues.push(`Add a unique <title> in ${filename} that includes the business name and primary offer.`);
        }

        const images = [...html.matchAll(/<img\b[^>]*>/gi)].map((match) => match[0]);
        if (images.some((image) => !/\balt=["']/i.test(image))) {
            issues.push(`Add alt text to every image in ${filename}. Describe the subject, or use alt="" if the image is decorative.`);
        }
        const forms = [...html.matchAll(/<form\b([^>]*)>/gi)].map((match) => match[1]);
        if (filename === "index.html" && !forms.some((attrs) => /\baction=["'][^"']+["']/i.test(attrs))) {
            issues.push("Set the contact form action in index.html to a same-origin endpoint such as /api/submit-form so enquiries have a destination.");
        }
        if (forms.some((attrs) => !/\baction=["'][^"']+["']/i.test(attrs))) {
            issues.push(`Add an action attribute to every form in ${filename} so submissions have a destination.`);
        }

        const knownFiles = new Set(Object.keys(files));
        const references = [];
        const addReference = (target) => {
            const value = String(target || "").trim();
            if (!isLocalReference(value)) return;
            const resolved = resolveReference(filename, value);
            if (/^[-a-z0-9_./]+\.(?:html?|css|js|json|xml|txt|webp|png|jpe?g|gif|svg|avif|ico|woff2?)$/i.test(resolved) && !knownFiles.has(resolved)) {
                references.push(resolved);
            }
        };
        for (const match of html.matchAll(/\b(?:href|src)=["']([^"']+)["']/gi)) addReference(match[1]);
        for (const match of html.matchAll(/\bsrcset=["']([^"']+)["']/gi)) {
            match[1].split(",").forEach((candidate) => addReference(candidate.trim().split(/\s+/)[0]));
        }
        if (references.length) {
            issues.push(`${label} links to missing file${references.length === 1 ? "" : "s"}: ${[...new Set(references)].join(", ")}.`);
        }
    }

    function addCraftAndSecurityIssues(issues, files) {
        const htmlPages = pageFiles(files);
        const home = String(files["index.html"] || "");
        const css = String(files["style.css"] || "");
        const javascript = Object.entries(files)
            .filter(([filename]) => isJavaScriptFile(filename))
            .map(([, source]) => String(source || ""))
            .join("\n");
        const add = (message) => issues.push(message);

        // Reject common injection, mixed-content, and unsafe navigation patterns.
        if (/<script\b(?![^>]*\bsrc=["'][^"']+["'])[^>]*>[\s\S]*?(?:innerHTML|document\.write|eval\s*\()/i.test(home)) {
            add("Security: avoid unsafe inline DOM sinks in generated page markup.");
        }
        if (/(?:javascript:|data:text\/html|on(?:click|load|error|submit)\s*=)/i.test(Object.values(files).join("\n"))) {
            add("Security: generated files contain an unsafe URL or inline event handler.");
        }
        if (/<script\b[^>]+src=["']https?:/i.test(home) || /@import\s+["']https?:/i.test(css)) {
            add("Security: keep scripts and stylesheet imports same-origin; use approved asset URLs only.");
        }
        if (/<form\b[^>]+action=["'](?:https?:|\/\/)/i.test(home)) {
            add("Security: forms must submit to a same-origin endpoint or an explicitly reviewed provider.");
        }
        if (javascript && /(?:new Function|eval\s*\(|document\.write\s*\()/i.test(javascript)) {
            add("Security: generated JavaScript uses a prohibited dynamic-code API.");
        }

        const source = Object.values(files).join("\n");
        if (/lorem ipsum|coming soon|replace (?:this|with)|awaiting data submission|TODO|FIXME|your (?:business|company) name/i.test(source)) {
            add("Content: generated output contains placeholder or unfinished copy.");
        }
        if (htmlPages.some((filename) => !/<main\b/i.test(String(files[filename] || "")))) {
            add("Accessibility: every generated page needs a main landmark.");
        }
        if (htmlPages.some((filename) => /<img\b/i.test(String(files[filename] || "")) && !/<img\b[^>]+\b(?:width|height)=["']/i.test(String(files[filename] || "")))) {
            add("Performance: generated images need intrinsic dimensions to reduce layout shift.");
        }
        if (css && !/@media\s*\([^)]*max-width/i.test(css)) add("Responsive: generated CSS needs an explicit narrow-screen layout rule.");
        if (css && !/prefers-reduced-motion/i.test(css)) add("Accessibility: generated CSS needs a reduced-motion preference.");
        if (css && !/focus-visible/i.test(css)) add("Accessibility: generated CSS needs a visible keyboard focus treatment.");
        if (htmlPages.some((filename) => /<a\b[^>]+target=["']_blank["']/i.test(String(files[filename] || "")) && !/rel=["'][^"']*noopener/i.test(String(files[filename] || "")))) {
            add("Security: links opening new tabs need rel=\"noopener noreferrer\".");
        }
        if (htmlPages.some((filename) => (String(files[filename] || "").match(/<h[1-6]\b/gi) || []).length < 2)) {
            add("Design: each generated page should have a clear heading hierarchy beyond its page title.");
        }
    }

    function strictProjectIssues(files) {
        const issues = [];
        const entries = Object.entries(files || {});
        const htmlPages = entries.filter(([filename]) => isHtmlFile(filename));
        const cssFiles = entries.filter(([filename]) => /\.css$/i.test(filename));
        const jsFiles = entries.filter(([filename]) => isJavaScriptFile(filename));
        const source = entries.map(([, content]) => String(content || "")).join("\n");
        const add = (message) => issues.push(message);
        const byteLength = (value) => typeof TextEncoder === "function"
            ? new TextEncoder().encode(String(value || "")).length
            : String(value || "").length;

        if (!htmlPages.length) add("Completeness: generated projects need at least one HTML document.");
        if (!cssFiles.length) add("Completeness: generated projects need a CSS stylesheet.");
        if (!jsFiles.length) add("Completeness: generated projects need a JavaScript entry file.");
        htmlPages.forEach(([filename, html]) => {
            const page = String(html || "");
            const label = `Generated ${filename}`;
            if (!/^<!doctype\s+html>/i.test(page.trim()) || !/<html\b/i.test(page) || !/<head\b[\s\S]*<\/head>/i.test(page) || !/<body\b[\s\S]*<\/body>/i.test(page)) add(`Completeness: ${label} must be a complete HTML document.`);
            if (!/<link\b[^>]+rel=["'][^"']*canonical[^"']*\b[^>]+href=["']https:\/\/[^"']+/i.test(page)) add(`SEO: ${label} needs an absolute HTTPS canonical URL.`);
            if (/<form\b/i.test(page) && [...page.matchAll(/<input\b([^>]*)>|<textarea\b([^>]*)>|<select\b([^>]*)>/gi)].some((match) => {
                const attrs = match.slice(1).find(Boolean) || "";
                return !/\btype=["']hidden["']/i.test(attrs) && !/\bid=["'][^"']+["']/i.test(attrs) && !/\baria-label(?:ledby)?=["'][^"']+["']/i.test(attrs);
            })) add(`Accessibility: ${label} contains a form control without an accessible name.`);
            if (/<button\b[^>]*>\s*(?:<[^>]+>\s*)*<\/button>/i.test(page) && !/<button\b[^>]*aria-label=/i.test(page)) add(`Accessibility: ${label} contains an unnamed button.`);
            if (/<(?:video|audio)\b/i.test(page) && !/<(?:video|audio)\b[^>]*controls(?:\s|=|>)/i.test(page)) add(`Accessibility: ${label} contains media without native controls.`);
            if (/<a\b[^>]+target=["']_blank["'][^>]*>/i.test(page) && !/<a\b[^>]+target=["']_blank["'][^>]+rel=["'][^"']*noopener/i.test(page)) add(`Security: ${label} has a new-tab link without rel="noopener noreferrer".`);
            if (/<(?:href|src)=["']http:\/\//i.test(page)) add(`Security: ${label} contains a mixed-content HTTP URL.`);
        });
        if (source && /(?:^|[\s;(])(?:eval|Function)\s*\(/m.test(source) || /document\.write\s*\(/i.test(source)) add("Security: generated source contains a prohibited dynamic-code or document-write API.");
        if (/(?:javascript:|data:text\/html|\bon(?:click|load|error|submit)\s*=)/i.test(source)) add("Security: generated source contains an unsafe URL or inline event handler.");
        if (/<script\b(?![^>]*\bsrc=["'][^"']+["'])[^>]*>[\s\S]*?<\/script>/i.test(source) && /(?:innerHTML|outerHTML|insertAdjacentHTML)\s*=/i.test(source)) add("Security: avoid unsafe inline HTML injection sinks in generated source.");
        if (cssFiles.some(([, css]) => !/@media\s*\([^)]*(?:max-width|width)/i.test(String(css)))) add("Responsive: every generated stylesheet needs a narrow-screen layout rule.");
        if (cssFiles.some(([, css]) => !/prefers-reduced-motion/i.test(String(css)))) add("Accessibility: generated stylesheets need a prefers-reduced-motion rule.");
        if (cssFiles.some(([, css]) => !/focus-visible/i.test(String(css)))) add("Accessibility: generated stylesheets need a visible focus-visible treatment.");
        if (htmlPages.some(([filename, html]) => /<img\b/i.test(html) && [...String(html).matchAll(/<img\b[^>]*>/gi)].some((match) => !/\b(?:width|height)=["']/i.test(match[0])))) add("Performance: every generated image needs intrinsic width and height attributes.");
        const totalBytes = entries.reduce((sum, [, content]) => sum + byteLength(content), 0);
        const htmlBytes = htmlPages.reduce((sum, [, content]) => sum + byteLength(content), 0);
        const cssBytes = cssFiles.reduce((sum, [, content]) => sum + byteLength(content), 0);
        const jsBytes = jsFiles.reduce((sum, [, content]) => sum + byteLength(content), 0);
        if (totalBytes > 5_000_000 || htmlBytes > 150_000 || cssBytes > 100_000 || jsBytes > 150_000) add("Performance: generated files exceed the production source-size budget.");
        const deployment = String(files["netlify.toml"] || "");
        if (!deployment.trim()) add("Completeness: generated projects need a deployment configuration file.");
        if (deployment && !/Content-Security-Policy\s*=/.test(deployment)) add("Security: deployment configuration must include a Content-Security-Policy header.");
        if (deployment && !/X-Content-Type-Options\s*=/.test(deployment)) add("Security: deployment configuration must include X-Content-Type-Options: nosniff.");
        if (deployment && !/Referrer-Policy\s*=/.test(deployment)) add("Security: deployment configuration must include a Referrer-Policy header.");
        if (deployment && /LEADS_WEBHOOK_URL|SUPABASE_SERVICE_ROLE_KEY|NETLIFY_AUTH_TOKEN|SUPABASE_ANON_KEY/.test(deployment)) add("Security: deployment configuration must not contain environment-variable secrets; configure them in the hosting provider.");
        return issues;
    }

    function validateGeneratedProject(files = {}, options = {}) {
        const strict = options === true || options?.strict === true;
        const issues = [];
        const normalizedFiles = files && typeof files === "object" ? files : {};
        if (strict) strictProjectIssues(normalizedFiles).forEach((message) => issues.push(message));
        const sharedIssues = sharedAudit()?.auditProject?.(normalizedFiles)?.issues || [];
        sharedIssues.forEach((entry) => issues.push(entry.message));
        addCraftAndSecurityIssues(issues, normalizedFiles);
        const htmlPages = pageFiles(normalizedFiles);
        const html = String(normalizedFiles["index.html"] || "");

        if (!htmlPages.length || !html.trim()) {
            issues.push("Generated project is missing index.html.");
        }
        htmlPages.forEach((filename) => addPageIssues(issues, filename, String(normalizedFiles[filename] || ""), normalizedFiles));

        Object.entries(normalizedFiles).filter(([filename]) => isJavaScriptFile(filename)).forEach(([filename, source]) => {
            if (!String(source).trim()) return;
            try {
                // Compile without executing when the host policy permits it.
                // Strict CSP can block dynamic compilation even for validation;
                // that policy error must not make every otherwise valid project fail.
                Function(`"use strict";\n${source}`);
            } catch (error) {
                const policyBlocked = ["EvalError", "SecurityError"].includes(error?.name) && /unsafe-eval|content security policy|refused to evaluate|blocked script execution/i.test(error.message || "");
                if (!policyBlocked) {
                    issues.push(`Generated ${filename} has a syntax error: ${error.message || "invalid JavaScript"}`);
                }
            }
        });

        if (html.trim()) {
            try {
                const parsed = new DOMParser().parseFromString(html, "text/html");
                if (parsed.querySelector("parsererror")) {
                    issues.push("Generated HTML could not be parsed safely.");
                }
                const structuredData = parsed.querySelector("script[type='application/ld+json']")?.textContent?.trim();
                if (structuredData) JSON.parse(structuredData);
            } catch {
                issues.push("Generated structured data is not valid JSON.");
            }
        }

        const responsiveAudit = window.workspaceResponsive?.auditResponsiveSource?.(html, String(normalizedFiles["style.css"] || "")) || [];
        responsiveAudit.filter((finding) => finding.severity === "error").forEach((finding) => issues.push(`Responsive: ${finding.message}`));

        const deploymentConfig = String(normalizedFiles["netlify.toml"] || "");
        if (deploymentConfig && !/Content-Security-Policy\s*=/.test(deploymentConfig)) {
            issues.push("Security: deployment configuration must include a Content-Security-Policy header.");
        }
        if (deploymentConfig && !/X-Content-Type-Options\s*=/.test(deploymentConfig)) {
            issues.push("Security: deployment configuration must include X-Content-Type-Options: nosniff.");
        }

        return [...new Set(issues)];
    }

    window.workspaceValidation = Object.freeze({ validateGeneratedProject });
})();
